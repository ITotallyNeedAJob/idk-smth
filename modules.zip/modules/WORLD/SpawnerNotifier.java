// === Kuzi module: SpawnerNotifier ===
// Category   : WORLD
// Description: Shows the chunk + mob type of nearby mob spawners (box/text/tracer/beam)
// Payload    : a.a.a.j.g.aj (verified: False)

package kuzi.modules.world;

import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.b.e;
import kuzi.obf.h.b.v;
import kuzi.obf.m.r;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.Component;
import net.minecraft.Minecraft;
import net.minecraft.Font;
import net.minecraft.Camera;
import net.minecraft.PoseStack;
import net.minecraft.MultiBufferSource;
import net.minecraft.MutableComponent;
import net.minecraft.Axis;
import org.joml.Matrix4f;
import org.joml.Quaternionfc;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class SpawnerNotifier
extends BaseModule {
    private static final int m;
    private static final long n;
    private final SliderSetting range;
    private final BoolSetting spawnerBox;
    private final BoolSetting beaconBeam;
    private final SliderSetting r;
    private final SliderSetting beamOpacity;
    private final BoolSetting outline;
    private final SliderSetting fillOpacity;
    private final BoolSetting mobTypeText;
    private final BoolSetting tracer;
    private final BoolSetting toastNotify;
    private final BoolSetting sound;
    private final e color;
    private final Set A;
    private final List B;
    private long C;
    private long D;
    private static final long E;
    private static final String[] F;
    private static final String[] G;
    private static final Map H;
    private static final long[] I;
    private static final Integer[] J;
    private static final Map K;
    private static final long[] L;
    private static final Long[] M;
    private static final Map N;
    private static final Object[] O;
    private static final String[] P;

    public SpawnerNotifier() {
        long l2;
        long l3 = l2 = E ^ 0x6FFAF3A3BF22L;
        long l4 = l3 ^ 0x71779A5FDBB3L;
        long l5 = l3 ^ 0x203DEEDD978EL;
        super("Spawner Notifier", "Shows the chunk + mob type of nearby mob spawners (box/text/tracer/beam)", Category.WORLD);
        this.range = new SliderSetting("Range", 64.0, 8.0, 256.0, 1.0);
        this.spawnerBox = new BoolSetting("Spawner Box", true);
        this.beaconBeam = new BoolSetting("Beacon Beam", true);
        this.r = new SliderSetting("Beam Height", 320.0, 16.0, 1024.0, 16.0);
        this.beamOpacity = new SliderSetting("Beam Opacity", 200.0, 0.0, 255.0, 5.0);
        this.outline = new BoolSetting("Outline", true);
        this.fillOpacity = new SliderSetting("Fill Opacity", 60.0, 0.0, 255.0, 5.0);
        this.mobTypeText = new BoolSetting("Mob Type Text", true);
        this.tracer = new BoolSetting("Tracer", false);
        this.toastNotify = new BoolSetting("Toast Notify", true);
        this.sound = new BoolSetting("Sound", true);
        this.color = new e("Color", new Color(255, 90, 255));
        this.A = ConcurrentHashMap.newKeySet();
        this.B = new ArrayList();
        this.C = (long)SpawnerNotifier.d("x", (int)30710, (long)(0x6FA1BE539572F6C5L ^ l2));
        this.D = (long)SpawnerNotifier.d("x", (int)6696, (long)(0x587A0DCD0E711B18L ^ l2));
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.range, this.spawnerBox, this.beaconBeam, this.r, this.beamOpacity, this.outline, this.fillOpacity, this.mobTypeText, this.tracer, this.toastNotify, this.sound, this.color};
        objectArray[0] = l5;
        this.l(objectArray);
        WorldRenderEvents.END_MAIN.register(arg_0 -> this.a(l4, arg_0));
    }

    @Override
    public void d() {
        long l2 = E ^ 0x5A9AA751474L;
        this.B.clear();
        this.A.clear();
        this.C = (long)SpawnerNotifier.d("x", (int)6696, (long)(0x587A679E57A7B04EL ^ l2));
        this.D = (long)SpawnerNotifier.d("x", (int)6696, (long)(0x587A679E57A7B04EL ^ l2));
    }

    @Override
    public void h() {
        this.A.clear();
        this.B.clear();
    }

    /*
     * Exception decompiling
     */
    private void a(long var1_1, WorldRenderContext var3_2) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Statement already marked as first in another block
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.markFirstStatementInBlock(Op03SimpleStatement.java:461)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc.markWholeBlock(Misc.java:251)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.considerAsSimpleIf(ConditionalRewriter.java:673)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.identifyNonjumpingConditionals(ConditionalRewriter.java:56)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:722)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private void a(Object[] objectArray) {
        Minecraft mc = (Minecraft)objectArray[0];
        PoseStack poseStack = (PoseStack)objectArray[1];
        MultiBufferSource buffers = (MultiBufferSource)objectArray[2];
        long l2 = (Long)objectArray[3];
        Camera camera = (Camera)objectArray[4];
        double offsetX = (Double)objectArray[5];
        double offsetY = (Double)objectArray[6];
        double offsetZ = (Double)objectArray[7];
        String text = (String)objectArray[8];
        int textColor = (Integer)objectArray[9];
        l2 = E ^ l2;
        Font font = mc.font;
        poseStack.pushPose();
        poseStack.translate(offsetX, offsetY, offsetZ);
        poseStack.mulPose((Quaternionfc)Axis.YP.rotationDegrees(-camera.yRot()));
        poseStack.mulPose((Quaternionfc)Axis.XP.rotationDegrees(camera.xRot()));
        poseStack.scale(-0.025f, -0.025f, 0.025f);
        Matrix4f matrix4f = poseStack.last().pose();
        float textX = (float)(-font.width(text)) / 2.0f;
        MutableComponent mc52502 = Component.literal((String)text);
        Objects.requireNonNull(font);
        font.drawInBatch((Component)mc52502, textX, (float)(-SpawnerNotifier.c("t", (int)31407, (long)(0xFF487B3C7B4B5EEL ^ l2))), textColor, false, matrix4f, buffers, Font.mc6415.SEE_THROUGH, 0, (int)SpawnerNotifier.c("t", (int)6509, (long)(0x7575D1A01C0CD626L ^ l2)));
        poseStack.popPose();
    }

    /*
     * Exception decompiling
     */
    private void b(Object[] var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [22[DOLOOP]], but top level block is 23[WHILELOOP]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:435)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:484)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private static int a(Object[] objectArray) {
        int clamped;
        block6: {
            int value;
            long l2;
            block4: {
                int rawValue;
                block5: {
                    l2 = (Long)objectArray[0];
                    rawValue = (Integer)objectArray[1];
                    l2 = E ^ l2;
                    CallSite callSite = SpawnerNotifier.f("Z", (long)6149164587263886434L, (long)l2);
                    try {
                        try {
                            value = rawValue;
                            if (callSite == null) break block4;
                            if (value >= 0) break block5;
                        }
                        catch (r r2) {
                            throw SpawnerNotifier.f("Z", (Object)r2, (long)6145616659574462308L, (long)l2);
                        }
                        clamped = 0;
                        break block6;
                    }
                    catch (r r3) {
                        throw SpawnerNotifier.f("Z", (Object)r3, (long)6145616659574462308L, (long)l2);
                    }
                }
                value = rawValue;
            }
            clamped = Math.min(value, (int)SpawnerNotifier.c("t", (int)15817, (long)(0x6B35B6DBA7557782L ^ l2)));
        }
        return clamped;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block31: {
            block30: {
                block29: {
                    block28: {
                        block27: {
                            block26: {
                                SpawnerNotifier.E = kuzi.obf.h.b.v.a(-2312353303167600926L, 3059924020997507817L, MethodHandles.lookup().lookupClass()).a(103562562410130L);
                                SpawnerNotifier.O = new Object[75];
                                SpawnerNotifier.P = new String[75];
                                SpawnerNotifier.c();
                                SpawnerNotifier.H = new HashMap<K, V>(13);
                                var22 = SpawnerNotifier.E ^ 5197623338L;
                                var24_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                                v0 = SecretKeyFactory.getInstance("DES");
                                v1 = new byte[8];
                                v2 = v1;
                                v1[0] = (byte)(var22 >>> 56);
                                for (var25_2 = 1; var25_2 < 8; ++var25_2) {
                                    v2 = v2;
                                    v2[var25_2] = (byte)(var22 << var25_2 * 8 >>> 56);
                                }
                                var24_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                                var31_3 = new String[18];
                                var29_4 = 0;
                                var28_5 = "*m\u0006\u009b\u000en\u00e3\u00df\u00ce\u00de\u0093#\u00bf\u000b\u00dbi ~P\u00e6\u00eaF%d\u00c0\u00a2P\u009b\u00d5Fo\u00b2<\u00db\u009a\n\u009b;\u0006kTw\u00d7\u00c9\u00a1_\u0093\u00f4x\u0010)\u00eb\u00c7I\u00f5\u008aOY\u0002\u00ad}\u0096\u00a6\u00c8C.\u0010\u00b2\u0003\u00a1\u00f1\u00dbGD\u00ba\u009f\u00b4\u0099\u0088_\u00a5E\u00ea\u0010\u001f\r\u0016\u00c2\u0094\u00af\u00e1wqs3\u00c4M\u0012.\f \u00a0\u00b4\u0000Qj\u00fc\u001de\u0002$\u008a\u00db\u00cd\u009a2\u00ec\u00bcc \u0015\u00de\u00e3\u0017\u00dc1n\u0098Y\u00d9w^\u008f \u00b0\u001b\u00ecc\u00af\u00de\u0096(\u00d6\u00cb&\u00be\u00ecZ\u0015\u00daYenA\u00d9h\u00cct\u00a1\u000f\u00af\u007fLftR S\u00fe\u00bchB\u00a3\u00a2\u0012r\u0010n\u00a5\u0082\u00f2\u00d3\u0095\u00e1\u00c4\u00cavn;a.;\u00a0\u0097\u00f8v^\u0081\u00dc\u0018B\u00e7\u0080_G\u00bdZ\u0011\u00abd,hm5\u00b3\u0091\u00fdc \u00d2\u00b1\u00d8J7\u0010\u00d1)>\u0086\u00e0\u000b\u000f\u00b0t+\u00eb\u009f\u0018T\u007f\u00df\u0018\u0091Ph\u009b\u0013Sz\u008d\u00c9-p%f\u0086\u00d0\nw\u00dar\u0085q_+\u00d6\u0010\u00df\u0003Z\u00d2\u0015QE\u00ea\u008d\u00ef\u009b\u00a5o\u001c\u00c1\u0013\u0010!\u00e8_W}W\u00f9\u00bfD+\u00be\"\u00c8\u00e0\u00b2D\u0018\u00cc\u0090\u0006\u0012\u009f_ir\u0006J\u00f8\u00a6\u00ab\u00ae\u0012\u00db\u0017\u00a5\u0001\u00e4>\u00b5\u00c1T\u0010\u0095\u008f\u008c\u00bc\u00f7C\u0094a\u0087\u00a1NV\u008a[\u00e0\u0085(K\u0011\u00f0\u00c9\u00e1$\u00e4\u00a4\u0082F\u00c5\u0093\u000f\u0015{L8g\u00a9.^\u009b\u009bC\u0010\u00d0\u00c1\u00c4\u0097\u00c3@\u001b\u0091\u00b6\u00cbT$\u0097F,";
                                var30_6 = "*m\u0006\u009b\u000en\u00e3\u00df\u00ce\u00de\u0093#\u00bf\u000b\u00dbi ~P\u00e6\u00eaF%d\u00c0\u00a2P\u009b\u00d5Fo\u00b2<\u00db\u009a\n\u009b;\u0006kTw\u00d7\u00c9\u00a1_\u0093\u00f4x\u0010)\u00eb\u00c7I\u00f5\u008aOY\u0002\u00ad}\u0096\u00a6\u00c8C.\u0010\u00b2\u0003\u00a1\u00f1\u00dbGD\u00ba\u009f\u00b4\u0099\u0088_\u00a5E\u00ea\u0010\u001f\r\u0016\u00c2\u0094\u00af\u00e1wqs3\u00c4M\u0012.\f \u00a0\u00b4\u0000Qj\u00fc\u001de\u0002$\u008a\u00db\u00cd\u009a2\u00ec\u00bcc \u0015\u00de\u00e3\u0017\u00dc1n\u0098Y\u00d9w^\u008f \u00b0\u001b\u00ecc\u00af\u00de\u0096(\u00d6\u00cb&\u00be\u00ecZ\u0015\u00daYenA\u00d9h\u00cct\u00a1\u000f\u00af\u007fLftR S\u00fe\u00bchB\u00a3\u00a2\u0012r\u0010n\u00a5\u0082\u00f2\u00d3\u0095\u00e1\u00c4\u00cavn;a.;\u00a0\u0097\u00f8v^\u0081\u00dc\u0018B\u00e7\u0080_G\u00bdZ\u0011\u00abd,hm5\u00b3\u0091\u00fdc \u00d2\u00b1\u00d8J7\u0010\u00d1)>\u0086\u00e0\u000b\u000f\u00b0t+\u00eb\u009f\u0018T\u007f\u00df\u0018\u0091Ph\u009b\u0013Sz\u008d\u00c9-p%f\u0086\u00d0\nw\u00dar\u0085q_+\u00d6\u0010\u00df\u0003Z\u00d2\u0015QE\u00ea\u008d\u00ef\u009b\u00a5o\u001c\u00c1\u0013\u0010!\u00e8_W}W\u00f9\u00bfD+\u00be\"\u00c8\u00e0\u00b2D\u0018\u00cc\u0090\u0006\u0012\u009f_ir\u0006J\u00f8\u00a6\u00ab\u00ae\u0012\u00db\u0017\u00a5\u0001\u00e4>\u00b5\u00c1T\u0010\u0095\u008f\u008c\u00bc\u00f7C\u0094a\u0087\u00a1NV\u008a[\u00e0\u0085(K\u0011\u00f0\u00c9\u00e1$\u00e4\u00a4\u0082F\u00c5\u0093\u000f\u0015{L8g\u00a9.^\u009b\u009bC\u0010\u00d0\u00c1\u00c4\u0097\u00c3@\u001b\u0091\u00b6\u00cbT$\u0097F,".length();
                                var27_7 = 16;
                                var26_8 = -1;
lbl23:
                                // 2 sources

                                while (true) {
                                    v3 = ++var26_8;
                                    v4 = var28_5.substring(v3, v3 + var27_7);
                                    v5 = -1;
                                    break block26;
                                    break;
                                }
lbl28:
                                // 1 sources

                                while (true) {
                                    var31_3[var29_4++] = SpawnerNotifier.b(var32_9).intern();
                                    if ((var26_8 += var27_7) < var30_6) {
                                        var27_7 = var28_5.charAt(var26_8);
                                        ** continue;
                                    }
                                    var28_5 = "\u00c8\u00b8\u001a\u00a1\u0017\u0000\u001fU\u00fd\u001c\u00da\u00d4\u00a2\u00db\u008d:\u00a2\u009c\u00c5\u000e\r\u0084E\u00f4x\u00f7V\u00c0\u00e3\u00e2\u00fe\u00e9\u0080\u00d2\u00a2\u00bf\u000f\u00dd\u00e2\tLD\u0001\u00b23\u00b1\u00de\u00f951\u00cc\u00bd%\u0099\u009d#\u00d2v\u00f4\u00d2\u00b2\u00ee\b\u001d\u0091\u00f59tL\u009d\u0096\u00a4\u00efk\u00c3K\u00cb\u00d2;\u00dd\u00a6\u00bfR\u00f7\u00efv{\u0000\u0017\u00b0\u00fb\u00a7Ir\u00a3\u00dc\u00d9\u0088\u00ac5R\u00fd.\u00f2\".\u001fG\u0085\u00e5~D\u00f7\u00b6\u00bc\u009f\\\u0096\u009f\u00d8a\u009d\u00f7\u00f6<\u00d7\u00e1\u00b5[\u00b8\nA\u00eb\u0092\\o,f-\u00c9\u00f5\u0094s\u00a1\u000b\u00c3\u00a0\u00e9vjL~\u00b8\u0002\u000e\u009en>\u00121\u00dd";
                                    var30_6 = "\u00c8\u00b8\u001a\u00a1\u0017\u0000\u001fU\u00fd\u001c\u00da\u00d4\u00a2\u00db\u008d:\u00a2\u009c\u00c5\u000e\r\u0084E\u00f4x\u00f7V\u00c0\u00e3\u00e2\u00fe\u00e9\u0080\u00d2\u00a2\u00bf\u000f\u00dd\u00e2\tLD\u0001\u00b23\u00b1\u00de\u00f951\u00cc\u00bd%\u0099\u009d#\u00d2v\u00f4\u00d2\u00b2\u00ee\b\u001d\u0091\u00f59tL\u009d\u0096\u00a4\u00efk\u00c3K\u00cb\u00d2;\u00dd\u00a6\u00bfR\u00f7\u00efv{\u0000\u0017\u00b0\u00fb\u00a7Ir\u00a3\u00dc\u00d9\u0088\u00ac5R\u00fd.\u00f2\".\u001fG\u0085\u00e5~D\u00f7\u00b6\u00bc\u009f\\\u0096\u009f\u00d8a\u009d\u00f7\u00f6<\u00d7\u00e1\u00b5[\u00b8\nA\u00eb\u0092\\o,f-\u00c9\u00f5\u0094s\u00a1\u000b\u00c3\u00a0\u00e9vjL~\u00b8\u0002\u000e\u009en>\u00121\u00dd".length();
                                    var27_7 = 32;
                                    var26_8 = -1;
lbl37:
                                    // 2 sources

                                    while (true) {
                                        v6 = ++var26_8;
                                        v4 = var28_5.substring(v6, v6 + var27_7);
                                        v5 = 0;
                                        break block26;
                                        break;
                                    }
                                    break;
                                }
lbl42:
                                // 1 sources

                                while (true) {
                                    var31_3[var29_4++] = SpawnerNotifier.b(var32_9).intern();
                                    if ((var26_8 += var27_7) < var30_6) {
                                        var27_7 = var28_5.charAt(var26_8);
                                        ** continue;
                                    }
                                    break block27;
                                    break;
                                }
                            }
                            var32_9 = var24_1.doFinal(v4.getBytes("ISO-8859-1"));
                            switch (v5) {
                                default: {
                                    ** continue;
                                }
                                ** case 0:
lbl54:
                                // 1 sources

                                ** continue;
                            }
                        }
                        SpawnerNotifier.F = var31_3;
                        SpawnerNotifier.G = new String[18];
                        SpawnerNotifier.K = new HashMap<K, V>(13);
                        var11_10 = Cipher.getInstance("DES/CBC/NoPadding");
                        v7 = SecretKeyFactory.getInstance("DES");
                        v8 = new byte[8];
                        v9 = v8;
                        v8[0] = (byte)(var22 >>> 56);
                        for (var12_11 = 1; var12_11 < 8; ++var12_11) {
                            v9 = v9;
                            v9[var12_11] = (byte)(var22 << var12_11 * 8 >>> 56);
                        }
                        var11_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                        var17_12 = new long[21];
                        var14_13 = 0;
                        var15_14 = "\u00db\u00d8\u00cd\u00f6E\u00e0\u0086\u0006XJ\u00d7\u000e\u000b\u0007\u00e6\u0087_|[\u0094\u0006&R\\\n\u00c5Rv\u00e4_'\u00b3\u00b5\u00ea\u00aa\u00b3\u009b\u00a3!\u0086bC9\u00c9\u00d08\u00ad\u0091\u008a\u00bd\u0085\u00f3\u0085l\u0096\u00a1fW\u00c5\u00ae\u00ca\u0012i\u009cg$\u001e\u0006@\u00f2\u0099\u00c6\u00d4\u0000\u001e\u00ef\u0010?i\u00aa\u00a8\u00c8\u00b4F\u0019L:V]\r\u0096\u00d3)\u00a2M\u00d6\u009f\u00feY O*w\u0005\u0090\u00ed\u00f7\u00e6r\u00da;\u00dd\u00e5\u00d9\u00b5\u00e0\\V\u00fe\u00c1[+\u000e\u008a\u00c8\u0082(1\u00d9\u00b2fb \u00c8\u00ad=I\u00b3A\u00e4\u00ba\u00c2\u0097<\"\u00f8C\r`.\u009f$";
                        var16_15 = "\u00db\u00d8\u00cd\u00f6E\u00e0\u0086\u0006XJ\u00d7\u000e\u000b\u0007\u00e6\u0087_|[\u0094\u0006&R\\\n\u00c5Rv\u00e4_'\u00b3\u00b5\u00ea\u00aa\u00b3\u009b\u00a3!\u0086bC9\u00c9\u00d08\u00ad\u0091\u008a\u00bd\u0085\u00f3\u0085l\u0096\u00a1fW\u00c5\u00ae\u00ca\u0012i\u009cg$\u001e\u0006@\u00f2\u0099\u00c6\u00d4\u0000\u001e\u00ef\u0010?i\u00aa\u00a8\u00c8\u00b4F\u0019L:V]\r\u0096\u00d3)\u00a2M\u00d6\u009f\u00feY O*w\u0005\u0090\u00ed\u00f7\u00e6r\u00da;\u00dd\u00e5\u00d9\u00b5\u00e0\\V\u00fe\u00c1[+\u000e\u008a\u00c8\u0082(1\u00d9\u00b2fb \u00c8\u00ad=I\u00b3A\u00e4\u00ba\u00c2\u0097<\"\u00f8C\r`.\u009f$".length();
                        var13_16 = 0;
                        while (true) {
                            var18_17 = var15_14.substring(var13_16, var13_16 += 8).getBytes("ISO-8859-1");
                            v10 = var17_12;
                            v11 = var14_13++;
                            v12 = ((long)var18_17[0] & 255L) << 56 | ((long)var18_17[1] & 255L) << 48 | ((long)var18_17[2] & 255L) << 40 | ((long)var18_17[3] & 255L) << 32 | ((long)var18_17[4] & 255L) << 24 | ((long)var18_17[5] & 255L) << 16 | ((long)var18_17[6] & 255L) << 8 | (long)var18_17[7] & 255L;
                            v13 = -1;
                            break block28;
                            break;
                        }
lbl81:
                        // 1 sources

                        while (true) {
                            v10[v11] = v14;
                            if (var13_16 < var16_15) ** continue;
                            var15_14 = "\u0007\u00efV\u00fa\u00a1&\u00c4\u00d0\u00d0\u00f5\u0000\u0098Y\u0082\u00ca\b";
                            var16_15 = "\u0007\u00efV\u00fa\u00a1&\u00c4\u00d0\u00d0\u00f5\u0000\u0098Y\u0082\u00ca\b".length();
                            var13_16 = 0;
                            while (true) {
                                var18_17 = var15_14.substring(var13_16, var13_16 += 8).getBytes("ISO-8859-1");
                                v10 = var17_12;
                                v11 = var14_13++;
                                v12 = ((long)var18_17[0] & 255L) << 56 | ((long)var18_17[1] & 255L) << 48 | ((long)var18_17[2] & 255L) << 40 | ((long)var18_17[3] & 255L) << 32 | ((long)var18_17[4] & 255L) << 24 | ((long)var18_17[5] & 255L) << 16 | ((long)var18_17[6] & 255L) << 8 | (long)var18_17[7] & 255L;
                                v13 = 0;
                                break block28;
                                break;
                            }
                            break;
                        }
lbl94:
                        // 1 sources

                        while (true) {
                            v10[v11] = v14;
                            if (var13_16 < var16_15) ** continue;
                            break block29;
                            break;
                        }
                    }
                    var19_18 = v12;
                    var21_19 = var11_10.doFinal(new byte[]{(byte)(var19_18 >>> 56), (byte)(var19_18 >>> 48), (byte)(var19_18 >>> 40), (byte)(var19_18 >>> 32), (byte)(var19_18 >>> 24), (byte)(var19_18 >>> 16), (byte)(var19_18 >>> 8), (byte)var19_18});
                    v14 = ((long)var21_19[0] & 255L) << 56 | ((long)var21_19[1] & 255L) << 48 | ((long)var21_19[2] & 255L) << 40 | ((long)var21_19[3] & 255L) << 32 | ((long)var21_19[4] & 255L) << 24 | ((long)var21_19[5] & 255L) << 16 | ((long)var21_19[6] & 255L) << 8 | (long)var21_19[7] & 255L;
                    switch (v13) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl107:
                        // 1 sources

                        ** continue;
                    }
                }
                SpawnerNotifier.I = var17_12;
                SpawnerNotifier.J = new Integer[21];
                SpawnerNotifier.m = 256;
                SpawnerNotifier.N = new HashMap<K, V>(13);
                var0_20 = Cipher.getInstance("DES/CBC/NoPadding");
                v15 = SecretKeyFactory.getInstance("DES");
                v16 = new byte[8];
                v17 = v16;
                v16[0] = (byte)(var22 >>> 56);
                for (var1_21 = 1; var1_21 < 8; ++var1_21) {
                    v17 = v17;
                    v17[var1_21] = (byte)(var22 << var1_21 * 8 >>> 56);
                }
                var0_20.init(2, (Key)v15.generateSecret(new DESKeySpec(v17)), new IvParameterSpec(new byte[8]));
                var6_22 = new long[4];
                var3_23 = 0;
                var4_24 = "\u00b4\u009d\u00d2\u0017\\\u0085\u00d5\u001e\u001aA\u00d5\u009f\f\u0093P\u0094";
                var5_25 = "\u00b4\u009d\u00d2\u0017\\\u0085\u00d5\u001e\u001aA\u00d5\u009f\f\u0093P\u0094".length();
                var2_26 = 0;
                while (true) {
                    var7_27 = var4_24.substring(var2_26, var2_26 += 8).getBytes("ISO-8859-1");
                    v18 = var6_22;
                    v19 = var3_23++;
                    v20 = ((long)var7_27[0] & 255L) << 56 | ((long)var7_27[1] & 255L) << 48 | ((long)var7_27[2] & 255L) << 40 | ((long)var7_27[3] & 255L) << 32 | ((long)var7_27[4] & 255L) << 24 | ((long)var7_27[5] & 255L) << 16 | ((long)var7_27[6] & 255L) << 8 | (long)var7_27[7] & 255L;
                    v21 = -1;
                    break block30;
                    break;
                }
lbl135:
                // 1 sources

                while (true) {
                    v18[v19] = v22;
                    if (var2_26 < var5_25) ** continue;
                    var4_24 = "\u00c7\u0096\u00ee\u0000\u00c6\fO(\u00ec\u00b8\u00d8\u00df\u00ecx\u00b3\u00ea";
                    var5_25 = "\u00c7\u0096\u00ee\u0000\u00c6\fO(\u00ec\u00b8\u00d8\u00df\u00ecx\u00b3\u00ea".length();
                    var2_26 = 0;
                    while (true) {
                        var7_27 = var4_24.substring(var2_26, var2_26 += 8).getBytes("ISO-8859-1");
                        v18 = var6_22;
                        v19 = var3_23++;
                        v20 = ((long)var7_27[0] & 255L) << 56 | ((long)var7_27[1] & 255L) << 48 | ((long)var7_27[2] & 255L) << 40 | ((long)var7_27[3] & 255L) << 32 | ((long)var7_27[4] & 255L) << 24 | ((long)var7_27[5] & 255L) << 16 | ((long)var7_27[6] & 255L) << 8 | (long)var7_27[7] & 255L;
                        v21 = 0;
                        break block30;
                        break;
                    }
                    break;
                }
lbl148:
                // 1 sources

                while (true) {
                    v18[v19] = v22;
                    if (var2_26 < var5_25) ** continue;
                    break block31;
                    break;
                }
            }
            var8_28 = v20;
            var10_29 = var0_20.doFinal(new byte[]{(byte)(var8_28 >>> 56), (byte)(var8_28 >>> 48), (byte)(var8_28 >>> 40), (byte)(var8_28 >>> 32), (byte)(var8_28 >>> 24), (byte)(var8_28 >>> 16), (byte)(var8_28 >>> 8), (byte)var8_28});
            v22 = ((long)var10_29[0] & 255L) << 56 | ((long)var10_29[1] & 255L) << 48 | ((long)var10_29[2] & 255L) << 40 | ((long)var10_29[3] & 255L) << 32 | ((long)var10_29[4] & 255L) << 24 | ((long)var10_29[5] & 255L) << 16 | ((long)var10_29[6] & 255L) << 8 | (long)var10_29[7] & 255L;
            switch (v21) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl161:
                // 1 sources

                ** continue;
            }
        }
        SpawnerNotifier.L = var6_22;
        SpawnerNotifier.M = new Long[4];
        SpawnerNotifier.n = 200L;
    }

    private static Throwable a(Throwable throwable) {
        return throwable;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static String b(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x6FE7;
        if (G[n3] == null) {
            Object[] objectArray;
            try {
                Long l3 = Thread.currentThread().threadId();
                objectArray = (Object[])H.get(l3);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    H.put(l3, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/g/aj", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l2 >>> 56);
            for (int i2 = 1; i2 < 8; ++i2) {
                byArray[i2] = (byte)(l2 << i2 * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = F[n3].getBytes("ISO-8859-1");
            SpawnerNotifier.G[n3] = SpawnerNotifier.b(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return G[n3];
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        String string2 = SpawnerNotifier.b(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static CallSite b(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/aj" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x1F00;
        if (J[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = I[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])K.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    K.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/g/aj", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            SpawnerNotifier.J[n3] = n4;
        }
        return J[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = SpawnerNotifier.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/aj" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static long d(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0xDA8;
        if (M[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = L[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])N.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    N.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/g/aj", exception);
            }
            long l5 = ((long)byArray[0] & 0xFFL) << 56 | ((long)byArray[1] & 0xFFL) << 48 | ((long)byArray[2] & 0xFFL) << 40 | ((long)byArray[3] & 0xFFL) << 32 | ((long)byArray[4] & 0xFFL) << 24 | ((long)byArray[5] & 0xFFL) << 16 | ((long)byArray[6] & 0xFFL) << 8 | (long)byArray[7] & 0xFFL;
            SpawnerNotifier.M[n3] = l5;
        }
        return M[n3];
    }

    private static long d(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        long l3 = SpawnerNotifier.d(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Long.TYPE, l3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return l3;
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_2().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/aj" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (P[n4] != null) {
            return n4;
        }
        Object object = O[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 1;
            case 1 -> 45;
            case 2 -> 12;
            case 3 -> 61;
            case 4 -> 34;
            case 5 -> 31;
            case 6 -> 24;
            case 7 -> 28;
            case 8 -> 52;
            case 9 -> 9;
            case 10 -> 58;
            case 11 -> 44;
            case 12 -> 36;
            case 13 -> 40;
            case 14 -> 59;
            case 15 -> 54;
            case 16 -> 55;
            case 17 -> 25;
            case 18 -> 57;
            case 19 -> 51;
            case 20 -> 46;
            case 21 -> 43;
            case 22 -> 30;
            case 23 -> 16;
            case 24 -> 20;
            case 25 -> 11;
            case 26 -> 8;
            case 27 -> 10;
            case 28 -> 5;
            case 29 -> 49;
            case 30 -> 4;
            case 31 -> 42;
            case 32 -> 0;
            case 33 -> 19;
            case 34 -> 32;
            case 35 -> 35;
            case 36 -> 29;
            case 37 -> 38;
            case 38 -> 56;
            case 39 -> 50;
            case 40 -> 7;
            case 41 -> 18;
            case 42 -> 41;
            case 43 -> 47;
            case 44 -> 26;
            case 45 -> 63;
            case 46 -> 22;
            case 47 -> 53;
            case 48 -> 15;
            case 49 -> 60;
            case 50 -> 37;
            case 51 -> 14;
            case 52 -> 6;
            case 53 -> 21;
            case 54 -> 17;
            case 55 -> 62;
            case 56 -> 48;
            case 57 -> 39;
            case 58 -> 13;
            case 59 -> 3;
            case 60 -> 23;
            case 61 -> 27;
            case 62 -> 2;
            default -> 33;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        SpawnerNotifier.P[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = O;
        O[0] = "\\h|x?\u0018Whzx?\\";
        objectArray[1] = "Q\r\u0001yH`O\u0005\u001b6*|H\u0018";
        objectArray[2] = "QD\\|u;OLF3\b+O";
        objectArray[3] = Long.TYPE;
        SpawnerNotifier.P[3] = "java/lang/Long";
        objectArray[4] = "gc\u000b\u001dW]nc\b\u001dU";
        objectArray[5] = "FV!\"4DOV\"\"0";
        objectArray[6] = ";a.\u0001e]2a\b";
        objectArray[7] = Void.TYPE;
        SpawnerNotifier.P[7] = "java/lang/Void";
        objectArray[8] = "\t\u0010\u001c{7a\u0002\u0010\u001a{76";
        objectArray[9] = Integer.TYPE;
        SpawnerNotifier.P[9] = "java/lang/Integer";
        objectArray[10] = "<g\u0014p2\u00035g\u0017p2";
        objectArray[11] = "\n1o!\u0010\u0012\u0001>~nq\u001c\n5z4";
        objectArray[12] = "\" \u0013\u0013\u001dj+ 4";
        objectArray[13] = "3,\u0000\u0015f)F\f\u000b\u001awf'\u0002\u0000\u0011s<S";
        objectArray[14] = "4_\u0014t|~A\u007f\u001f{m1 q\u0014pikT";
        objectArray[15] = "&h\u0002\u0016C<&h\u0015JO3<#\u0015TO&;RD\f\u001d";
        objectArray[16] = "#@R\u0003Z\t(OCL'\u0011;HJ\u0005";
        objectArray[17] = "&\rh_D\"S-cPUm2#h[Q7F";
        objectArray[18] = "!q\u000eh \u0017TQ\u0005g1X5_\u000el5\u0002A";
        objectArray[19] = "/h\u007f\u000fJ\u001d&h|\u000fF";
        objectArray[20] = "RB\u0010T\u0003iOWHvBdWQ";
        objectArray[21] = "wATtJ!|ARtJK";
        objectArray[22] = "it";
        objectArray[23] = "2\fh_\u0016mG,cP\u0007\"&\"h[\u0003xR";
        objectArray[24] = "L $A \u0000G /";
        objectArray[25] = Boolean.TYPE;
        SpawnerNotifier.P[25] = "java/lang/Boolean";
        objectArray[26] = "\\\u001f.\u0019N\u0015W\u0010?V4\u0011D\u0011/\u0019\u0002\u0015S";
        objectArray[27] = "\u0001>@f7)t\u001eKi&f\u0015\u0010@b\"<a";
        objectArray[28] = "X\u0017\u000b\u0001{\u0007-7\u0000\u000ejHL9\u000b\u0005n\u00128";
        objectArray[29] = "lU\u0017\u000b_\u0019}U\u0017P";
        objectArray[30] = "_\u0007Po\u001f\u0013*'[`\u000e\\K)Pk\n\u0006?";
        objectArray[31] = "t\r\\bHu\u0001-WmY:`#\\f]`\u0014";
        objectArray[32] = "X\u0004e\u000f_3I\u0004j";
        objectArray[33] = "=3\tMm\\H\u0013\u0002B|\u0013)\u001d\tIxI]";
        objectArray[34] = "`D4k\u001a\u0019kD<";
        objectArray[35] = "q\u0016_;;(\u00046T4*ge8_?.=\u0011";
        objectArray[36] = "\u0019}EbfV\u001b-W\u000bf&C\"\\hdW@\u007f\u000fa";
        objectArray[37] = "'+Z\u000evR%{Hg~\"}tC\u0004tS~)\u0010\r";
        objectArray[38] = "&b \\E@$225Z0+h6\u0005Q\r$i \\";
        objectArray[39] = "Bo.\u0007mf@?<nd\u0016\u001807\rog\u001bmd\u0004";
        objectArray[40] = "(\u000eV\u0011%~*^Dx\u0017\u000e3\u0001]\b>6 \u0012\\";
        objectArray[41] = "y?/\u0016;N{o=\u007f1>#5l\u0013\u007fX&a:@";
        objectArray[42] = "v'9K(}tw+\"9\rpx;Imkgpz\u0012Pg(x}L)q~(s\"";
        objectArray[43] = "k.J4\u0004L9h\b%9V3wK:9\u0000m/J<\\@/h\\W";
        objectArray[44] = "Y6\u0015\u0016^K\u00060\u0005\u001denu\u00001.#~<?\u001b\r\u001c\nF`\u001d\u001d\u0017";
        objectArray[45] = ":NURq\u0002y\u0017B\nL\u0015\u0004MC^+Bb\tN\fs";
        objectArray[46] = "t:Y\u0003\u0010n+'W\u0001{uKeE\u0018\u001ag{cBJ\u0005\u001c";
        objectArray[47] = "&}yk\t+\u007fn`35?Ey3w^k#n;6\u0005V&}yk\t+\u007fn`35";
        objectArray[48] = "V#r&tATs`O@1\r-wp<A\u000f*{%";
        objectArray[49] = "X|,AI\rTfsH5^h`sH^\n\u000ew{\t\u00057T98R\bF\u0006\u007fzC5";
        objectArray[50] = "}Z\u00170C4\u007f\n\u0005YpD&T\u0012f\u000b4$S\u001e3";
        objectArray[51] = "HB\u001e3&?DXA:Zox^A:18\u001eII{j\u0005\u0011[\u000e:4y\u001b\u0006\u0002|Z";
        objectArray[52] = ":F6lyUy\u001f!4DE\u0004\u0011ul{G}\u0007#<u";
        objectArray[53] = "cPv#Y(a\u0000dJ^X9\u000fo)[):R< ";
        objectArray[54] = "S\u0014$I``QD6 r\u0010UK&K%vBCg\u0010\u0018-\bE%K}mJ\u00023 ";
        objectArray[55] = "\u0002^q!zQ\u0000\u000ecH~!X\u0001h+xP[\\;\"";
        objectArray[56] = "O/\u0001=C<\fv\u0016e~)q,\u00171\u0019|\u0017h\u001acA";
        objectArray[57] = "|`@U\r\u0006.&\u0002D0\u001c@9\u000bO[J&.\u0003\u000e\u0000w}d\u0005L[\u0012=&BZ0";
        objectArray[58] = "ysY.e={#KGfMtyOwqp{xY.";
        objectArray[59] = "v;,w^6soz$b9M2,i\fj7nt`_P";
        objectArray[60] = "\u0012O01?\u0014DZ6'\u0002A\u007f] =|Q\u0018S3~d+";
        objectArray[61] = "9q, \b\u001c;!>I\u0019l?..\"M\n(&oypR2\"0u\u0016\u0016?phI";
        objectArray[62] = "\u0004Q5\r*!\u0006\u0001'd\u001bQ\\B6\r<m\u0006S6\u0016";
        objectArray[63] = "\u0013[-\u0013Q\u000b\u001bO3\u0017*\u0003|B;\t\u0010\u0006\u0013\u001ez\u0013\u001bo";
        objectArray[64] = ",\f.\u0019y3u\u001f7AE$O\bd\u0005.s)\u001flDuNrUj\u0006.+2\u0017-\u0010E";
        objectArray[65] = "k6<\u001cFZgix\u0006vlKTF)vT40{U\u001fXkta";
        objectArray[66] = "\u0019eDG?p\u001b5V..\u0000\u0019kV\u001f&}\u0013gT_Ga\u0018b\u000eO:k\u0014`N.";
        objectArray[67] = "\u000bESq\u0019bY\u0003\u0011`$y7\u001c\u0018kO.Q\u000b\u0010*\u0014\u0013\nA\u0016hOvJ\u0003Q~$";
        objectArray[68] = "`A\u00197B2b\u0011\u000b^GBmK\u000fnV\u007fbJ\u00197";
        objectArray[69] = "V\u0000f5\"|\u0015Yqm\u001fjh\u0003p9x<\u000eG}k ";
        objectArray[70] = "O\fiA0`M\\{(1\u0010\u0015SpK2a\u0016\u000e#B";
        objectArray[71] = "eZAC&pg\nS*$\u0000hPW\u001a2=gQAC";
        objectArray[72] = "P2(I\u0017\u000bRb: \u0006{Vm*KR\u001dAek\u0010oF\u000bc)K\n\u0006I$? ";
        objectArray[73] = "4}2\r\u0010\f<i,\tk\f[cl\u0011\u0000U=tdP[hf>b\u0012\u0000\r&|%\u0004k";
        Object[] objectArray2 = objectArray;
        objectArray[74] = "Sm'fk\u0018Q=5\u000fmh\t2>li\u0019\nome";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = SpawnerNotifier.e(l2, l3);
            object = O[n2];
            try {
                if (!(object instanceof String)) break block2;
                SpawnerNotifier.O[n2] = clazz = Class.forName(P[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = SpawnerNotifier.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = SpawnerNotifier.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = SpawnerNotifier.e(l2, l3);
        Object object = O[n2];
        if (object instanceof String) {
            String string = P[n2];
            int n3 = string.indexOf(8);
            Class clazz = SpawnerNotifier.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = SpawnerNotifier.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = SpawnerNotifier.c(clazz3, string2, clazz2)) != null) {
                    SpawnerNotifier.O[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = SpawnerNotifier.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        SpawnerNotifier.O[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = SpawnerNotifier.f(783055616307619L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = SpawnerNotifier.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = SpawnerNotifier.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = SpawnerNotifier.e(l2, l3);
        Object object = O[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = P[n2];
                int n4 = string2.indexOf(8);
                clazz3 = SpawnerNotifier.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = SpawnerNotifier.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = SpawnerNotifier.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        SpawnerNotifier.O[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = SpawnerNotifier.f(783055616307619L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = SpawnerNotifier.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        SpawnerNotifier.O[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = SpawnerNotifier.f(783055616307619L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == '\u00ea' || c2 == 'i' || c2 == '\u00ba' || c2 == '\u00a5') {
                field = SpawnerNotifier.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == '\u00ea' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == 'i' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == '\u00ba' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = SpawnerNotifier.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == '\u00b5' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == 'Z' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = SpawnerNotifier.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite f(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_3().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/aj" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(SpawnerNotifier.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(SpawnerNotifier.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_2() {
        try {
            return MethodHandles.lookup().findStatic(SpawnerNotifier.class, "d", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_3() {
        try {
            return MethodHandles.lookup().findStatic(SpawnerNotifier.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

