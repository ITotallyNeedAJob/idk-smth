// === Kuzi module: AntiBaseLeakTexture ===
// Category   : WORLD
// Description: Replaces specified blocks with a chosen block texture (hides base leaks)
// Payload    : a.a.a.j.g.D (verified: True)

package kuzi.modules.world;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.mixin.MixinExposed;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.b.l;
import kuzi.obf.h.b.v;
import kuzi.obf.j.g.aD;
import kuzi.obf.j.g.h;
import kuzi.obf.m.r;
import kuzi.settings.Setting;
import net.minecraft.Blocks;
import net.minecraft.Block;
import net.minecraft.BlockState;
import net.minecraft.Minecraft;
import net.minecraft.LevelRenderer;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class AntiBaseLeakTexture
extends BaseModule {
    private static volatile AntiBaseLeakTexture instance;
    private final l texture;
    private static final Set hiddenBlocks;
    private static final long p;
    private static final String[] q;
    private static final String[] r;
    private static final Map s;
    private static final Object[] t;
    private static final String[] u;

    public AntiBaseLeakTexture() {
        long l2 = p ^ 0xC992BF79B86L;
        long l3 = l2 ^ 0x42C23C61B521L;
        super("AntiBaseLeakTexture", "Replaces specified blocks with a chosen block texture (hides base leaks)", Category.WORLD);
        this.texture = new l("Texture", kuzi.obf.j.g.h.NETHERITE, h.class);
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.texture};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @MixinExposed
    public BlockState a() {
        return ((h)((Object)this.texture.a())).a.defaultBlockState();
    }

    @Override
    public void d() {
        long l2 = p ^ 0x435A09D127FL;
        long l3 = l2 ^ 0x716FCABCBF5FL;
        instance = this;
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.a(objectArray);
    }

    @Override
    public void e() {
        long l2 = p ^ 0x1149B97C7251L;
        long l3 = l2 ^ 0x6413D35DDF71L;
        int[] nArray = aD.b();
        AntiBaseLeakTexture antiBaseLeakTexture = instance;
        if (nArray != null) {
            if (antiBaseLeakTexture == this) {
                instance = null;
            }
            antiBaseLeakTexture = this;
        }
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        antiBaseLeakTexture.a(objectArray);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @MixinExposed
    public static AntiBaseLeakTexture a() {
        AntiBaseLeakTexture antiBaseLeakTexture = instance;
        int[] nArray = aD.b();
        AntiBaseLeakTexture antiBaseLeakTexture2 = antiBaseLeakTexture;
        if (nArray != null) {
            if (antiBaseLeakTexture2 == null) return null;
            antiBaseLeakTexture2 = antiBaseLeakTexture;
        }
        if (nArray == null) return antiBaseLeakTexture2;
        if (!antiBaseLeakTexture2.d()) return null;
        antiBaseLeakTexture2 = antiBaseLeakTexture;
        return antiBaseLeakTexture2;
    }

    private void a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = (l2 = p ^ l2) ^ 0x2F51D8C88012L;
        int[] nArray = aD.b();
        Minecraft mc = BaseModule.a;
        if (nArray != null) {
            if (mc.levelRenderer == null) {
                return;
            }
            mc = BaseModule.a;
        }
        mc.execute(() -> AntiBaseLeakTexture.lambda$invalidateChunks$0(l3));
    }

    @MixinExposed
    public boolean a(Block block) {
        block3: {
            boolean bl;
            block2: {
                int[] nArray = aD.b();
                bl = this.d();
                if (nArray == null) break block2;
                if (bl && block != null) break block3;
                bl = false;
            }
            return bl;
        }
        return hiddenBlocks.contains(block);
    }

    private static void lambda$invalidateChunks$0(long l2) {
        block5: {
            LevelRenderer levelRenderer;
            block4: {
                l2 = p ^ l2;
                CallSite callSite = AntiBaseLeakTexture.c("J", (long)-7456272792928595118L, (long)l2);
                try {
                    try {
                        levelRenderer = ((Minecraft)AntiBaseLeakTexture.c("u", (long)-7456620057918803795L, (long)l2)).levelRenderer;
                        if (callSite == null) break block4;
                        if (levelRenderer == null) break block5;
                    }
                    catch (r r2) {
                        throw AntiBaseLeakTexture.c("J", (Object)r2, (long)-7456420642564839562L, (long)l2);
                    }
                    levelRenderer = ((Minecraft)AntiBaseLeakTexture.c("u", (long)-7456620057918803795L, (long)l2)).levelRenderer;
                }
                catch (r r3) {
                    throw AntiBaseLeakTexture.c("J", (Object)r3, (long)-7456420642564839562L, (long)l2);
                }
            }
            levelRenderer.allChanged();
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block14: {
            block13: {
                block12: {
                    AntiBaseLeakTexture.p = v.a(8673535482326122714L, 5412150230546449009L, MethodHandles.lookup().lookupClass()).a(174311196131153L);
                    var20 = AntiBaseLeakTexture.p ^ 34774163770531L;
                    AntiBaseLeakTexture.t = new Object[30];
                    AntiBaseLeakTexture.u = new String[30];
                    AntiBaseLeakTexture.c();
                    AntiBaseLeakTexture.s = new HashMap<K, V>(13);
                    var11_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                    v0 = SecretKeyFactory.getInstance("DES");
                    v1 = new byte[8];
                    v2 = v1;
                    v1[0] = (byte)(var20 >>> 56);
                    for (var12_2 = 1; var12_2 < 8; ++var12_2) {
                        v2 = v2;
                        v2[var12_2] = (byte)(var20 << var12_2 * 8 >>> 56);
                    }
                    var11_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                    var18_3 = new String[3];
                    var16_4 = 0;
                    var15_5 = "\u00c9\u009cO|\u00fa\u00e8\u0088J\u0002\u00fc2\u008c\u0007\u00ea\\\u0019(\u00e4\u0013E\u00102\u00b1\u00fa\u00cf\u00ac\u00c2+\u00a9Fy.:S\u0080\u0098\u001b\u00c2\u00ab\u00b5\u00a5\u009f\u00e9R\u00d2\u00b6s\u009bR\u00ff\u0082H\u0083z\u00ea\u00ab \u0080\u0099\u0094\u008e\u0095\u00d7\u00c5e|R\u00824j0\u00a2\u00f2m\u00ca\u0081\u00ed\u00f3/\u00ad\u00b4x\u008d\u00ebb\u00e5\u00eb\u0019j\u00a5\u0085\u00c9Rm\u00f5\u0092\u00bc\u00ed\u00d6D\u008e\u00ec\u0094\u0013J\u00a8\u0007R\\\u00bch\u00e0\u00b9\u00fb-\u00c2`&\u00cc\u0000\u00ecr9\u0013 \r\u0081\u0085y4\u00ac]\u000b\u00d8T\u00deH\u00e5\u0006\\\u00f6\u00dew*\u00cd\u00a0\u00deE\u001e\u00ca\u0099\u0095\u00f3\u008a~\u00f9w\u0000\u009a\u0018\u0095\u0089gj*`'g\u00c3sdv\u000eu\u00b3_\u00fecYwq\u0005K\u00edg\u00f8";
                    var17_6 = "\u00c9\u009cO|\u00fa\u00e8\u0088J\u0002\u00fc2\u008c\u0007\u00ea\\\u0019(\u00e4\u0013E\u00102\u00b1\u00fa\u00cf\u00ac\u00c2+\u00a9Fy.:S\u0080\u0098\u001b\u00c2\u00ab\u00b5\u00a5\u009f\u00e9R\u00d2\u00b6s\u009bR\u00ff\u0082H\u0083z\u00ea\u00ab \u0080\u0099\u0094\u008e\u0095\u00d7\u00c5e|R\u00824j0\u00a2\u00f2m\u00ca\u0081\u00ed\u00f3/\u00ad\u00b4x\u008d\u00ebb\u00e5\u00eb\u0019j\u00a5\u0085\u00c9Rm\u00f5\u0092\u00bc\u00ed\u00d6D\u008e\u00ec\u0094\u0013J\u00a8\u0007R\\\u00bch\u00e0\u00b9\u00fb-\u00c2`&\u00cc\u0000\u00ecr9\u0013 \r\u0081\u0085y4\u00ac]\u000b\u00d8T\u00deH\u00e5\u0006\\\u00f6\u00dew*\u00cd\u00a0\u00deE\u001e\u00ca\u0099\u0095\u00f3\u008a~\u00f9w\u0000\u009a\u0018\u0095\u0089gj*`'g\u00c3sdv\u000eu\u00b3_\u00fecYwq\u0005K\u00edg\u00f8".length();
                    var14_7 = 16;
                    var13_8 = -1;
lbl23:
                    // 2 sources

                    while (true) {
                        continue;
                        break;
                    }
lbl25:
                    // 1 sources

                    while (true) {
                        var18_3[var16_4++] = AntiBaseLeakTexture.b(var19_9).intern();
                        if ((var13_8 += var14_7) < var17_6) {
                            var14_7 = var15_5.charAt(var13_8);
                            ** continue;
                        }
                        break block12;
                        break;
                    }
                    v3 = ++var13_8;
                    var19_9 = var11_1.doFinal(var15_5.substring(v3, v3 + var14_7).getBytes("ISO-8859-1"));
                    ** while (true)
                }
                AntiBaseLeakTexture.q = var18_3;
                AntiBaseLeakTexture.r = new String[3];
                var1_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v4 = SecretKeyFactory.getInstance("DES");
                v5 = new byte[8];
                v6 = v5;
                v5[0] = (byte)(var20 >>> 56);
                for (var2_11 = 1; var2_11 < 8; ++var2_11) {
                    v6 = v6;
                    v6[var2_11] = (byte)(var20 << var2_11 * 8 >>> 56);
                }
                var1_10.init(2, (Key)v4.generateSecret(new DESKeySpec(v6)), new IvParameterSpec(new byte[8]));
                var0_12 = new long[26];
                var4_13 = 0;
                var5_14 = "\u00a4#, \u00dc\u00aeYe\u00de\u00a3\u00cb=U\u00ff\u0097a\u0099\u0094\u00c3I\u00ba|QQ\u00cf\u00dd\u00f5\u0011K\u0098b:\u0000\u0006\u0096g]}\u00a2*\u00e5\u0014\u00d4\u00c2pl7+\u00fb\u00c0\u00b5\u0014\u0011>\u00c1\u00f6\u00fb\u00a7\u00f3\u00be\u00dd\u00e7\u00afk\u0087\u00bb[>\u0013x\u00ebw>I@\u00d0\u00dd\u00e1\u00867\u008akG\u00d6,1\u00e4\u00de\u00da\u00a2\u00df6\u009c\u00f4E\u0096\u0012\u001c\u008c\u00170\u001c/Xg\u00ba\u0002\u00b9w\u0015\u00d3r(\u0083\u009e\u00e1\u00b4\u0011\u009d\u0019:g\u00ac\u0092\u0095{Sq\u00b4!\u00deC\u00dfn\u0098q\u00987&S\u0007\n\u0087\u00bd\u00daaD|R\u00a0$\u0085mv\u00c6\u0093\u0082\u00caCY\u00bc\u00ce\u00a2\u0082L^\u000e\u00d7:\u00ec\u00b4\u00c1F)G\u0005\u00b9\r\u00a6xh\u00d8\u001cC\u00b8\u000f\u00fc\u00a9\u00c8\u00fd0\u00d7";
                var6_15 = "\u00a4#, \u00dc\u00aeYe\u00de\u00a3\u00cb=U\u00ff\u0097a\u0099\u0094\u00c3I\u00ba|QQ\u00cf\u00dd\u00f5\u0011K\u0098b:\u0000\u0006\u0096g]}\u00a2*\u00e5\u0014\u00d4\u00c2pl7+\u00fb\u00c0\u00b5\u0014\u0011>\u00c1\u00f6\u00fb\u00a7\u00f3\u00be\u00dd\u00e7\u00afk\u0087\u00bb[>\u0013x\u00ebw>I@\u00d0\u00dd\u00e1\u00867\u008akG\u00d6,1\u00e4\u00de\u00da\u00a2\u00df6\u009c\u00f4E\u0096\u0012\u001c\u008c\u00170\u001c/Xg\u00ba\u0002\u00b9w\u0015\u00d3r(\u0083\u009e\u00e1\u00b4\u0011\u009d\u0019:g\u00ac\u0092\u0095{Sq\u00b4!\u00deC\u00dfn\u0098q\u00987&S\u0007\n\u0087\u00bd\u00daaD|R\u00a0$\u0085mv\u00c6\u0093\u0082\u00caCY\u00bc\u00ce\u00a2\u0082L^\u000e\u00d7:\u00ec\u00b4\u00c1F)G\u0005\u00b9\r\u00a6xh\u00d8\u001cC\u00b8\u000f\u00fc\u00a9\u00c8\u00fd0\u00d7".length();
                var3_16 = 0;
                while (true) {
                    var7_17 = var5_14.substring(var3_16, var3_16 += 8).getBytes("ISO-8859-1");
                    v7 = var0_12;
                    v8 = var4_13++;
                    v9 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                    v10 = -1;
                    break block13;
                    break;
                }
lbl60:
                // 1 sources

                while (true) {
                    v7[v8] = v11;
                    if (var3_16 < var6_15) ** continue;
                    var5_14 = "i\u001d\u00e7<U\u00aan\u00be\u0086\u00c9\u00b6n_\u00c6t\u00f3";
                    var6_15 = "i\u001d\u00e7<U\u00aan\u00be\u0086\u00c9\u00b6n_\u00c6t\u00f3".length();
                    var3_16 = 0;
                    while (true) {
                        var7_17 = var5_14.substring(var3_16, var3_16 += 8).getBytes("ISO-8859-1");
                        v7 = var0_12;
                        v8 = var4_13++;
                        v9 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                        v10 = 0;
                        break block13;
                        break;
                    }
                    break;
                }
lbl73:
                // 1 sources

                while (true) {
                    v7[v8] = v11;
                    if (var3_16 < var6_15) ** continue;
                    break block14;
                    break;
                }
            }
            var8_18 = v9;
            var10_19 = var1_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            v11 = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
            switch (v10) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl86:
                // 1 sources

                ** continue;
            }
        }
        v12 = new Block[(int)var0_12[25]];
        v12[0] = Blocks.DEEPSLATE;
        v12[1] = Blocks.COBBLED_DEEPSLATE;
        v12[2] = Blocks.BEDROCK;
        v12[3] = Blocks.DEEPSLATE_COAL_ORE;
        v12[4] = Blocks.DEEPSLATE_IRON_ORE;
        v12[5] = Blocks.DEEPSLATE_COPPER_ORE;
        v12[(int)var0_12[2]] = Blocks.DEEPSLATE_GOLD_ORE;
        v12[(int)var0_12[17]] = Blocks.DEEPSLATE_REDSTONE_ORE;
        v12[(int)var0_12[21]] = Blocks.DEEPSLATE_LAPIS_ORE;
        v12[(int)var0_12[15]] = Blocks.DEEPSLATE_DIAMOND_ORE;
        v12[(int)var0_12[3]] = Blocks.DEEPSLATE_EMERALD_ORE;
        v12[(int)var0_12[9]] = Blocks.TUFF;
        v12[(int)var0_12[0]] = Blocks.CALCITE;
        v12[(int)var0_12[18]] = Blocks.SMOOTH_BASALT;
        v12[(int)var0_12[16]] = Blocks.GRAVEL;
        v12[(int)var0_12[12]] = Blocks.DIRT;
        v12[(int)var0_12[13]] = Blocks.CLAY;
        v12[(int)var0_12[23]] = Blocks.DRIPSTONE_BLOCK;
        v12[(int)var0_12[7]] = Blocks.POINTED_DRIPSTONE;
        v12[(int)var0_12[24]] = Blocks.MOSS_BLOCK;
        v12[(int)var0_12[1]] = Blocks.GLOW_LICHEN;
        v12[(int)var0_12[6]] = Blocks.AZALEA;
        v12[(int)var0_12[11]] = Blocks.SCULK;
        v12[(int)var0_12[22]] = Blocks.SCULK_VEIN;
        v12[(int)var0_12[10]] = Blocks.SCULK_CATALYST;
        v12[(int)var0_12[14]] = Blocks.SCULK_SENSOR;
        v12[(int)var0_12[19]] = Blocks.SCULK_SHRIEKER;
        v12[(int)var0_12[4]] = Blocks.AMETHYST_BLOCK;
        v12[(int)var0_12[20]] = Blocks.BUDDING_AMETHYST;
        v12[(int)var0_12[5]] = Blocks.OBSIDIAN;
        v12[(int)var0_12[8]] = Blocks.MAGMA_BLOCK;
        AntiBaseLeakTexture.hiddenBlocks = Set.of(v12);
    }

    private static r a(r r2) {
        return r2;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (u[n4] != null) {
            return n4;
        }
        Object object = t[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 7;
            case 1 -> 42;
            case 2 -> 37;
            case 3 -> 59;
            case 4 -> 17;
            case 5 -> 31;
            case 6 -> 43;
            case 7 -> 63;
            case 8 -> 41;
            case 9 -> 38;
            case 10 -> 23;
            case 11 -> 57;
            case 12 -> 61;
            case 13 -> 24;
            case 14 -> 4;
            case 15 -> 11;
            case 16 -> 55;
            case 17 -> 6;
            case 18 -> 0;
            case 19 -> 50;
            case 20 -> 44;
            case 21 -> 46;
            case 22 -> 18;
            case 23 -> 56;
            case 24 -> 19;
            case 25 -> 47;
            case 26 -> 40;
            case 27 -> 25;
            case 28 -> 5;
            case 29 -> 13;
            case 30 -> 62;
            case 31 -> 26;
            case 32 -> 10;
            case 33 -> 58;
            case 34 -> 1;
            case 35 -> 2;
            case 36 -> 54;
            case 37 -> 12;
            case 38 -> 8;
            case 39 -> 27;
            case 40 -> 30;
            case 41 -> 20;
            case 42 -> 60;
            case 43 -> 32;
            case 44 -> 3;
            case 45 -> 35;
            case 46 -> 9;
            case 47 -> 53;
            case 48 -> 14;
            case 49 -> 52;
            case 50 -> 21;
            case 51 -> 28;
            case 52 -> 45;
            case 53 -> 34;
            case 54 -> 49;
            case 55 -> 51;
            case 56 -> 15;
            case 57 -> 29;
            case 58 -> 36;
            case 59 -> 16;
            case 60 -> 33;
            case 61 -> 39;
            case 62 -> 22;
            default -> 48;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        AntiBaseLeakTexture.u[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = t;
        t[0] = "g7&FcVl7-";
        objectArray[1] = ")Po6SI)Pxj_F3\u001bxt_S4j()\u000e";
        objectArray[2] = "=FO}{\u00036FI}^";
        objectArray[3] = "Zr+7=SVr8";
        objectArray[4] = "y=1?Ebr=7?E\b";
        objectArray[5] = "`@";
        objectArray[6] = Boolean.TYPE;
        AntiBaseLeakTexture.u[6] = "java/lang/Boolean";
        objectArray[7] = "-\n#\u00052$3\u00029JO43";
        objectArray[8] = "V> @iy#\u001e+Ox6B\u0010 D|l6";
        objectArray[9] = Void.TYPE;
        AntiBaseLeakTexture.u[9] = "java/lang/Void";
        objectArray[10] = "F\u0003E+/PO\u0003F+\"";
        objectArray[11] = "I\u0001tiWtB\u0001ri^";
        objectArray[12] = "Gx\u0017N^\u001dGx\u0000\u0012R\u0012]3\u0000\fR\u0007ZBQR\u0007L";
        objectArray[13] = "M(%\u001c\u0003gD(&\u001c\u0003";
        objectArray[14] = "_l@k'fTcQ$Fh_hU~";
        objectArray[15] = "(2\u0001[RN#2\t";
        objectArray[16] = "Q\"\u001b\u0011\u001fv$\u0002\u0010\u001e\u000e9E\f\u001b\u0015\nc1";
        objectArray[17] = "cK%\u001bm&dOm\u001aV|Z\u0010?\u001c)\"e\u0017;T(";
        objectArray[18] = "n\"vvXni&>wc7W\u007f67\u001b/()se_";
        objectArray[19] = ".{<\u007fQ1s}g\u0014H\u000e,$;k\u001f5g!gw";
        objectArray[20] = "\"-36\u007fJg*c*\u0011lP\u0017J\u0018KkA\u0006\njw\u0013~%j/pCb";
        objectArray[21] = "HAN\u000e~sOE\u0006\u000fE%q\u0019L\u0010=<\rF\u0006\u0014!LKYW\t50\u0014\u0013S\u0015E";
        objectArray[22] = "EU+\\)H\u0000R{@GAz\u0003~@*S\u0013U{Q6";
        objectArray[23] = "w96/dQ78lw\n_Myvq6E=\"kwz5";
        objectArray[24] = "mU<?\u0015L0SgT\tsjH/m\u001f\f(\f20e";
        objectArray[25] = "](L4VXZ,\u00045m\u000ed Vp\\Z^:S+\u0004gZ.Qz\t\n\u001e.N,m";
        objectArray[26] = "IAybZ;\u001d[1g#\\g{\rT#j@\u00113a\u001b>ZY6";
        objectArray[27] = "PkyKE\u0015Wo1J~Mi4:S\u001e[\u000fhy\u0005\u0000";
        objectArray[28] = "Y\u0003@Pc\u001a\u0003\u0005@S\u0003\thTG\u0001\u007f\u0018VQ\tSb`";
        Object[] objectArray2 = objectArray;
        objectArray[29] = "-ry\u0016\\ept\"}HZ|v(L\u0011`fss\u0014,drq\"\u0019A rnt}";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = AntiBaseLeakTexture.e(l2, l3);
            object = t[n2];
            try {
                if (!(object instanceof String)) break block2;
                AntiBaseLeakTexture.t[n2] = clazz = Class.forName(u[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = AntiBaseLeakTexture.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = AntiBaseLeakTexture.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = AntiBaseLeakTexture.e(l2, l3);
        Object object = t[n2];
        if (object instanceof String) {
            String string = u[n2];
            int n3 = string.indexOf(8);
            Class clazz = AntiBaseLeakTexture.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = AntiBaseLeakTexture.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = AntiBaseLeakTexture.c(clazz3, string2, clazz2)) != null) {
                    AntiBaseLeakTexture.t[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = AntiBaseLeakTexture.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        AntiBaseLeakTexture.t[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = AntiBaseLeakTexture.f(1027262112042654L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = AntiBaseLeakTexture.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = AntiBaseLeakTexture.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = AntiBaseLeakTexture.e(l2, l3);
        Object object = t[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = u[n2];
                int n4 = string2.indexOf(8);
                clazz3 = AntiBaseLeakTexture.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = AntiBaseLeakTexture.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = AntiBaseLeakTexture.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        AntiBaseLeakTexture.t[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = AntiBaseLeakTexture.f(1027262112042654L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = AntiBaseLeakTexture.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        AntiBaseLeakTexture.t[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = AntiBaseLeakTexture.f(1027262112042654L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == '\u00e2' || c2 == 'f' || c2 == 'u' || c2 == '\u00dc') {
                field = AntiBaseLeakTexture.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == '\u00e2' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == 'f' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == 'u' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = AntiBaseLeakTexture.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == '\u00d4' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == 'J' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = AntiBaseLeakTexture.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/D" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(AntiBaseLeakTexture.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

