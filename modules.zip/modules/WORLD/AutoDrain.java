// === Kuzi module: AutoDrain ===
// Category   : WORLD
// Description: Removes water and lava source blocks with cobwebs or an empty bucket.
// Payload    : a.a.a.j.e.y (verified: True)

package kuzi.modules.world;

import a.a.a.j.e.b;
import a.a.a.p.J;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.module.Module;
import kuzi.obf.h.b.l;
import kuzi.obf.h.b.v;
import kuzi.obf.i.k_0;
import kuzi.obf.j.e.am;
import kuzi.obf.j.e.c;
import kuzi.obf.p.aA;
import kuzi.obf.p.ai;
import kuzi.obf.p.aj;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.InteractionHand;
import net.minecraft.Entity;
import net.minecraft.Items;
import net.minecraft.Blocks;
import net.minecraft.BlockPos;
import net.minecraft.Direction;
import net.minecraft.Vec3i;
import net.minecraft.HitResult;
import net.minecraft.Vec3;
import net.minecraft.Minecraft;
import net.minecraft.FluidTags;
import net.minecraft.Mth;
import net.minecraft.FluidState;
import net.minecraft.ClipContext;
import net.minecraft.BlockHitResult;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class AutoDrain
extends BaseModule
implements Module {
    private final l mode;
    private final l liquid;
    private final SliderSetting radius;
    private final SliderSetting blocksPerSecond;
    private final BoolSetting silentRotate;
    private final BoolSetting breakWebs;
    private final BoolSetting switchBack;
    private BlockHitResult targetHit;
    private BlockPos targetPos;
    private float yaw;
    private float pitch;
    private boolean pendingAction;
    private int savedSlot;
    private float savedYaw;
    private float savedPitch;
    private boolean rotationPending;
    private int cooldownTicks;
    private int scanDelayTicks;
    private BlockPos cobwebPos;
    private int cobwebTimeout;
    private static final long G;
    private static final String[] H;
    private static final String[] I;
    private static final Map J;
    private static final long[] K;
    private static final Integer[] L;
    private static final Map M;
    private static final Object[] N;
    private static final String[] O;

    public AutoDrain() {
        long l2 = G ^ 0x289E38CD45FCL;
        long l3 = l2 ^ 0x19E98E502C1BL;
        super("AutoDrain", "Removes water and lava source blocks with cobwebs or an empty bucket.", Category.WORLD);
        this.mode = new l("Mode", kuzi.obf.j.e.c.WEB, c.class);
        this.liquid = new l("Liquid", (Enum)a.a.a.j.e.b.WATER, b.class);
        this.radius = new SliderSetting("Radius", 4.0, 1.0, 6.0, 0.5);
        this.blocksPerSecond = new SliderSetting("Blocks Per Second", 2.0, 0.5, 10.0, 0.5);
        this.silentRotate = new BoolSetting("Silent Rotate", true);
        this.breakWebs = new BoolSetting("Break Webs", false);
        this.switchBack = new BoolSetting("Switch Back", true);
        this.pendingAction = false;
        this.savedSlot = -1;
        this.rotationPending = false;
        this.cooldownTicks = 0;
        this.scanDelayTicks = 0;
        this.cobwebTimeout = 0;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.mode, this.liquid, this.radius, this.blocksPerSecond, this.silentRotate, this.breakWebs, this.switchBack};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        long l2 = G ^ 0x7B190196553FL;
        long l3 = l2 ^ 0x2F55BA988598L;
        Client.a().a(Module.class, this);
        super.d();
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.a(objectArray);
    }

    @Override
    public void e() {
        long l2 = G ^ 0x6E6518773511L;
        long l3 = l2 ^ 0x3A29A379E5B6L;
        Client.a().b(Module.class, this);
        super.e();
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.a(objectArray);
    }

    @Override
    public void h() {
        long l2 = G ^ 0x318818028E0FL;
        long l3 = l2 ^ 0x65C4A30C5EA8L;
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.a(objectArray);
    }

    private void a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = (l2 = G ^ l2) ^ 0x7DDEC68D4400L;
        this.pendingAction = false;
        String string = am.b();
        this.targetHit = null;
        this.targetPos = null;
        this.cobwebPos = null;
        this.cobwebTimeout = 0;
        this.scanDelayTicks = 0;
        this.cooldownTicks = 0;
        if (string != null) {
            if (BaseModule.a.gameMode != null) {
                BaseModule.a.gameMode.stopDestroyBlock();
            }
            Object[] objectArray2 = new Object[1];
            objectArray2[0] = l3;
            this.f(objectArray2);
        }
    }

    @Override
    public void b() {
        block42: {
            AutoDrain autoDrain;
            BlockPos fluidPos;
            long l2;
            block40: {
                block41: {
                    Object object;
                    String string;
                    long l3;
                    block39: {
                        AutoDrain autoDrain2;
                        long l4;
                        long l5;
                        long l6;
                        block31: {
                            block32: {
                                block33: {
                                    AutoDrain autoDrain3;
                                    block34: {
                                        long l7;
                                        block37: {
                                            AutoDrain autoDrain4;
                                            block38: {
                                                block36: {
                                                    Object object2;
                                                    block35: {
                                                        int n2;
                                                        long l8;
                                                        long l9;
                                                        block27: {
                                                            block28: {
                                                                block30: {
                                                                    AutoDrain autoDrain5;
                                                                    block29: {
                                                                        block23: {
                                                                            block26: {
                                                                                AutoDrain autoDrain6;
                                                                                long l10;
                                                                                block24: {
                                                                                    block25: {
                                                                                        block20: {
                                                                                            Minecraft mc3102;
                                                                                            block22: {
                                                                                                block21: {
                                                                                                    block19: {
                                                                                                        long l11;
                                                                                                        long l12 = l11 = G ^ 0x8FA5A0D2A36L;
                                                                                                        l2 = l12 ^ 0x7CBE4EB7F736L;
                                                                                                        l6 = l12 ^ 0x103C7633FD0DL;
                                                                                                        l3 = l12 ^ 0x376921882B35L;
                                                                                                        l5 = l12 ^ 0x68796525491EL;
                                                                                                        l9 = l12 ^ 0x542F7FAB84A1L;
                                                                                                        l7 = l12 ^ 0x53B30829B126L;
                                                                                                        l10 = l12 ^ 0x5CB6E103FA91L;
                                                                                                        l8 = l12 ^ 0x1D14E2A77244L;
                                                                                                        l4 = l12 ^ 0x31FC9A6E4C63L;
                                                                                                        string = am.b();
                                                                                                        mc3102 = BaseModule.a;
                                                                                                        if (string == null) break block19;
                                                                                                        if (mc3102.player == null) break block20;
                                                                                                        mc3102 = BaseModule.a;
                                                                                                    }
                                                                                                    if (string == null) break block21;
                                                                                                    if (mc3102.level == null) break block20;
                                                                                                    mc3102 = BaseModule.a;
                                                                                                }
                                                                                                if (string == null) break block22;
                                                                                                if (mc3102.gameMode == null) break block20;
                                                                                                mc3102 = BaseModule.a;
                                                                                            }
                                                                                            if (mc3102.screen == null) break block23;
                                                                                        }
                                                                                        autoDrain6 = this;
                                                                                        if (string == null) break block24;
                                                                                        if (autoDrain6.pendingAction) break block25;
                                                                                        autoDrain6 = this;
                                                                                        if (string == null) break block24;
                                                                                        if (autoDrain6.cobwebPos == null) break block26;
                                                                                    }
                                                                                    autoDrain6 = this;
                                                                                }
                                                                                Object[] objectArray = new Object[1];
                                                                                objectArray[0] = l10;
                                                                                autoDrain6.a(objectArray);
                                                                            }
                                                                            return;
                                                                        }
                                                                        n2 = this.cooldownTicks--;
                                                                        if (string == null) break block27;
                                                                        if (n2 <= 0) break block28;
                                                                        autoDrain5 = this;
                                                                        if (string == null) break block29;
                                                                        if (autoDrain5.cooldownTicks != 0) break block30;
                                                                        autoDrain5 = this;
                                                                    }
                                                                    Object[] objectArray = new Object[1];
                                                                    objectArray[0] = l4;
                                                                    autoDrain5.f(objectArray);
                                                                }
                                                                return;
                                                            }
                                                            autoDrain2 = this;
                                                            if (string == null) break block31;
                                                            n2 = autoDrain2.pendingAction ? 1 : 0;
                                                        }
                                                        if (n2 == 0) break block32;
                                                        this.pendingAction = false;
                                                        autoDrain3 = this;
                                                        if (string == null) break block33;
                                                        Object[] objectArray = new Object[1];
                                                        objectArray[0] = l9;
                                                        if (!autoDrain3.a(objectArray)) break block34;
                                                        Object[] objectArray2 = new Object[4];
                                                        objectArray2[3] = this.mode.a() == kuzi.obf.j.e.c.WEB;
                                                        objectArray2[2] = l8;
                                                        objectArray2[1] = Float.valueOf(this.pitch);
                                                        objectArray2[0] = Float.valueOf(this.yaw);
                                                        this.d(objectArray2);
                                                        object2 = this.mode.a();
                                                        if (string == null) break block35;
                                                        if (object2 != kuzi.obf.j.e.c.WEB) break block36;
                                                        aA.a(this.targetHit, true);
                                                        autoDrain4 = this;
                                                        if (string == null) break block37;
                                                        object2 = autoDrain4.r.a();
                                                    }
                                                    if (!((Boolean)object2).booleanValue()) break block38;
                                                    this.cobwebPos = this.targetPos;
                                                    this.cobwebTimeout = 100;
                                                    if (string != null) break block38;
                                                }
                                                ((k_0)BaseModule.a).invokeDoItemUse();
                                            }
                                            autoDrain4 = this;
                                        }
                                        Object[] objectArray = new Object[1];
                                        objectArray[0] = l7;
                                        autoDrain4.scanDelayTicks = Math.max(0, this.a(objectArray) - 4);
                                    }
                                    this.targetHit = null;
                                    this.targetPos = null;
                                    autoDrain3 = this;
                                }
                                autoDrain3.cooldownTicks = 2;
                                return;
                            }
                            autoDrain2 = this;
                        }
                        if (string != null) {
                            if (autoDrain2.cobwebPos != null) {
                                AutoDrain autoDrain7 = this;
                                if (string != null) {
                                    Object[] objectArray = new Object[1];
                                    objectArray[0] = l5;
                                    if (autoDrain7.f(objectArray)) {
                                        return;
                                    }
                                    autoDrain7 = this;
                                }
                                Object[] objectArray = new Object[1];
                                objectArray[0] = l4;
                                autoDrain7.f(objectArray);
                            }
                            autoDrain2 = this;
                        }
                        if (string != null) {
                            if (autoDrain2.scanDelayTicks > 0) {
                                --this.scanDelayTicks;
                                return;
                            }
                            autoDrain2 = this;
                        }
                        Object[] objectArray = new Object[1];
                        objectArray[0] = l6;
                        object = fluidPos = autoDrain2.a(objectArray);
                        if (string == null) break block39;
                        if (object == null) {
                            return;
                        }
                        autoDrain = this;
                        if (string == null) break block40;
                        object = autoDrain.mode.a();
                    }
                    if (object != kuzi.obf.j.e.c.WEB) break block41;
                    Object[] objectArray = new Object[2];
                    objectArray[1] = fluidPos;
                    objectArray[0] = l3;
                    this.b(objectArray);
                    if (string != null) break block42;
                }
                autoDrain = this;
            }
            Object[] objectArray = new Object[2];
            objectArray[1] = fluidPos;
            objectArray[0] = l2;
            autoDrain.c(objectArray);
        }
    }

    private void b(Object[] objectArray) {
        BlockHitResult hit;
        long l2 = (Long)objectArray[0];
        BlockPos blockPos = (BlockPos)objectArray[1];
        long l3 = l2 = G ^ l2;
        long l4 = l3 ^ 0x99BA145E86AL;
        long l5 = l3 ^ 0x1A890B3864FBL;
        long l6 = l3 ^ 0xBD02D8E2F68L;
        long l7 = l3 ^ 0x3AE97ECFAB83L;
        long l8 = l3 ^ 0x69ACA1A124E1L;
        Object[] objectArray2 = new Object[2];
        objectArray2[1] = l8;
        objectArray2[0] = Items.COBWEB;
        int slot = this.c(objectArray2);
        String string = am.b();
        if (slot == -1) {
            return;
        }
        Object[] objectArray3 = new Object[1];
        objectArray3[0] = l6;
        Object[] objectArray4 = new Object[3];
        objectArray4[2] = l4;
        objectArray4[1] = this.a(objectArray3);
        objectArray4[0] = blockPos;
        BlockHitResult candidateHit = hit = this.a(objectArray4);
        if (string != null) {
            if (candidateHit == null) {
                return;
            }
            candidateHit = hit;
        }
        float[] angles = aj.a(candidateHit.getLocation());
        Object[] objectArray5 = new Object[4];
        objectArray5[3] = true;
        objectArray5[2] = l7;
        objectArray5[1] = Float.valueOf(angles[1]);
        objectArray5[0] = Float.valueOf(angles[0]);
        this.d(objectArray5);
        this.yaw = angles[0];
        this.pitch = angles[1];
        this.targetHit = hit;
        this.targetPos = blockPos;
        Object[] objectArray6 = new Object[2];
        objectArray6[1] = l5;
        objectArray6[0] = slot;
        this.e(objectArray6);
        this.pendingAction = true;
    }

    private void c(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        BlockPos blockPos = (BlockPos)objectArray[1];
        long l3 = l2 = G ^ l2;
        long l4 = l3 ^ 0x515E6407B8F8L;
        long l5 = l3 ^ 0x713E11F07780L;
        long l6 = l3 ^ 0x227BCE9EF8E2L;
        Object[] objectArray2 = new Object[2];
        objectArray2[1] = l6;
        objectArray2[0] = Items.BUCKET;
        int slot = this.c(objectArray2);
        if (slot == -1) {
            return;
        }
        float[] angles = aj.a(Vec3.atCenterOf((Vec3i)blockPos));
        Object[] objectArray3 = new Object[4];
        objectArray3[3] = false;
        objectArray3[2] = l5;
        objectArray3[1] = Float.valueOf(angles[1]);
        objectArray3[0] = Float.valueOf(angles[0]);
        this.d(objectArray3);
        this.yaw = angles[0];
        this.pitch = angles[1];
        this.targetHit = null;
        this.targetPos = blockPos;
        Object[] objectArray4 = new Object[2];
        objectArray4[1] = l4;
        objectArray4[0] = slot;
        this.e(objectArray4);
        this.pendingAction = true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean a(Object[] objectArray) {
        AutoDrain autoDrain;
        String string;
        long l2;
        long l3;
        block10: {
            Object object;
            block9: {
                l3 = (Long)objectArray[0];
                long l4 = l3 = G ^ l3;
                long l5 = l4 ^ 0x654F57DB42CL;
                l2 = l4 ^ 0x689673AD80FCL;
                string = am.b();
                if (this.targetPos == null) {
                    return false;
                }
                FluidState fluidState = BaseModule.a.level.getFluidState(this.targetPos);
                boolean bl = fluidState.isSource();
                if (string == null) return bl;
                if (!bl) return false;
                object = this;
                if (l3 < 0L || string == null) break block9;
                if (l3 >= 0L) {
                    Object[] objectArray2 = new Object[2];
                    objectArray2[1] = fluidState;
                    objectArray2[0] = l5;
                    if (!((AutoDrain)object).d(objectArray2)) {
                        return false;
                    }
                    autoDrain = this;
                }
                if (l3 <= 0L || string == null) break block10;
                object = autoDrain.mode.a();
            }
            if (object == kuzi.obf.j.e.c.BUCKET) {
                Object[] objectArray3 = new Object[1];
                objectArray3[0] = l2;
                double d2 = BaseModule.a.player.getEyePosition().distanceTo(Vec3.atCenterOf((Vec3i)this.targetPos)) - this.a(objectArray3);
                double d3 = d2 == 0.0 ? 0 : (d2 < 0.0 ? -1 : 1);
                if (string == null) return (boolean)d3;
                d3 = d3 <= 0 ? 1.0 : 0.0;
                return (boolean)d3;
            }
            autoDrain = this;
        }
        if (autoDrain.targetHit == null) return 0 != 0;
        int n2 = BaseModule.a.level.getBlockState(this.targetPos).canBeReplaced();
        String string2 = string;
        if (l3 >= 0L) {
            if (string2 != null) {
                if (n2 == 0) return 0 != 0;
                Object[] objectArray4 = new Object[1];
                objectArray4[0] = l2;
                double d4 = BaseModule.a.player.getEyePosition().distanceTo(this.targetHit.getLocation()) - this.a(objectArray4);
                n2 = d4 == 0.0 ? 0 : (d4 < 0.0 ? -1 : 1);
            }
            string2 = string;
        }
        if (string2 == null) return n2 != 0;
        if (n2 > 0) return 0 != 0;
        return 1 != 0;
    }

    private BlockPos a(Object[] objectArray) {
        BlockPos candidate;
        block5: {
            long l2 = (Long)objectArray[0];
            long l3 = l2 = G ^ l2;
            long l4 = l3 ^ 0x4247FCE5CD80L;
            long l5 = l3 ^ 0x2C857A35F950L;
            Object[] objectArray2 = new Object[1];
            objectArray2[0] = l5;
            double maxDist = this.a(objectArray2);
            Vec3 eyePos = BaseModule.a.player.getEyePosition();
            BlockPos playerPos = BaseModule.a.player.blockPosition();
            String string = am.b();
            int range = Mth.ceil((double)maxDist);
            BlockPos bestPos = null;
            double bestDist = Double.MAX_VALUE;
            for (BlockPos pos : BlockPos.betweenClosed((BlockPos)playerPos.offset(-range, -range, -range), (BlockPos)playerPos.offset(range, range, range))) {
                block9: {
                    double candidateDist;
                    double comparison;
                    double distance;
                    BlockPos currentPos;
                    block8: {
                        Object object;
                        block7: {
                            boolean bl;
                            block6: {
                                if (l2 < 0L || string == null) break block5;
                                currentPos = pos;
                                FluidState fluidState = BaseModule.a.level.getFluidState(currentPos);
                                bl = fluidState.isSource();
                                if (string == null) break block6;
                                if (!bl) continue;
                                object = this;
                                if (l2 < 0L || string == null) break block7;
                                Object[] objectArray3 = new Object[2];
                                objectArray3[1] = fluidState;
                                objectArray3[0] = l4;
                                bl = ((AutoDrain)object).d(objectArray3);
                            }
                            if (!bl) continue;
                            object = this.mode.a();
                        }
                        if (object == kuzi.obf.j.e.c.WEB && !BaseModule.a.level.getBlockState(currentPos).canBeReplaced()) continue;
                        distance = eyePos.distanceTo(Vec3.atCenterOf((Vec3i)currentPos));
                        comparison = distance == maxDist ? 0 : (distance > maxDist ? 1 : -1);
                        if (string == null) break block8;
                        if (comparison > 0) continue;
                        if (l2 <= 0L) break block9;
                        candidateDist = distance;
                        if (string == null) break block9;
                        double diff = candidateDist - bestDist;
                        comparison = diff == 0.0 ? 0 : (diff > 0.0 ? 1 : -1);
                    }
                    if (comparison >= 0) continue;
                    bestPos = currentPos.immutable();
                    candidateDist = bestDist = distance;
                }
                if (l2 < 0L || string != null) continue;
            }
            candidate = bestPos;
        }
        return candidate;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean d(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        FluidState fluidState = (FluidState)objectArray[1];
        l2 = G ^ l2;
        String string = am.b();
        boolean bl = ((b)this.liquid.a()).ordinal();
        if (string != null) {
            switch (bl) {
                default: {
                    throw new MatchException(null, null);
                }
                case 0: {
                    bl = fluidState.is(FluidTags.WATER);
                    return bl;
                }
                case 1: {
                    bl = fluidState.is(FluidTags.LAVA);
                    return bl;
                }
                case 2: {
                    bl = fluidState.is(FluidTags.WATER);
                }
            }
        }
        if (string == null) return bl;
        if (bl) return true;
        bl = fluidState.is(FluidTags.LAVA);
        if (string == null) return bl;
        if (!bl) return false;
        return true;
    }

    private BlockHitResult a(Object[] objectArray) {
        BlockPos blockPos = (BlockPos)objectArray[0];
        double maxDist = (Double)objectArray[1];
        long l2 = (Long)objectArray[2];
        l2 = G ^ l2;
        Vec3 eyePos = BaseModule.a.player.getEyePosition();
        String string = am.b();
        BlockHitResult bestHit = null;
        double bestDist = Double.MAX_VALUE;
        Direction[] directions = Direction.values();
        int count = directions.length;
        int index = 0;
        while (index < count) {
            String string2;
            block5: {
                block4: {
                    block3: {
                        BlockHitResult hit;
                        double dist;
                        block10: {
                            String string3;
                            Vec3 faceCenter;
                            Direction side;
                            BlockPos adjacentPos;
                            block8: {
                                block9: {
                                    BlockHitResult hitResult;
                                    block6: {
                                        block7: {
                                            Direction dir = directions[index];
                                            adjacentPos = blockPos.relative(dir);
                                            if (BaseModule.a.level.getBlockState(adjacentPos).canBeReplaced()) break block3;
                                            side = dir.getOpposite();
                                            faceCenter = Vec3.atCenterOf((Vec3i)adjacentPos).add(Vec3.atLowerCornerOf((Vec3i)side.getUnitVec3i()).scale(0.5));
                                            dist = eyePos.distanceTo(faceCenter);
                                            if (string == null) break block4;
                                            if (dist > maxDist || dist >= bestDist) break block3;
                                            hitResult = BaseModule.a.level.clip(new ClipContext(eyePos, faceCenter, ClipContext.mc3960.OUTLINE, ClipContext.mc242.NONE, (Entity)BaseModule.a.player));
                                            string2 = string;
                                            if (l2 <= 0L) break block5;
                                            if (string2 == null) break block4;
                                            if (hitResult == null) break block3;
                                            hit = hitResult;
                                            string3 = string;
                                            if (l2 <= 0L) break block6;
                                            if (string3 == null) break block7;
                                            if (hit.getType() != HitResult.mc240.BLOCK) break block3;
                                            hit = hitResult;
                                        }
                                        string3 = string;
                                    }
                                    if (l2 < 0L) break block8;
                                    if (string3 == null) break block9;
                                    if (!hit.getBlockPos().equals((Object)adjacentPos)) break block3;
                                    hit = hitResult;
                                }
                                string3 = string;
                            }
                            if (string3 == null) break block10;
                            if (hit.getDirection() != side) break block3;
                            hit = new BlockHitResult(faceCenter, side, adjacentPos, false);
                        }
                        bestHit = hit;
                        bestDist = dist;
                    }
                    ++index;
                }
                string2 = string;
            }
            if (string2 != null) continue;
        }
        return bestHit;
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private boolean f(Object[] var1_1) {
        block11: {
            block12: {
                block9: {
                    block10: {
                        block7: {
                            block8: {
                                block5: {
                                    block6: {
                                        var2_2 = (Long)var1_1[0];
                                        v0 = var2_2 = AutoDrain.G ^ var2_2;
                                        var4_3 = v0 ^ 93185374375235L;
                                        var6_4 = v0 ^ 112121100814760L;
                                        cobwebCenter = Vec3.atCenterOf((Vec3i)this.cobwebPos);
                                        var8_6 = am.b();
                                        v1 = this.cobwebTimeout = this.cobwebTimeout - 1;
                                        if (var8_6 == null) break block5;
                                        if (v1 <= 0) break block6;
                                        v1 = BaseModule.a.level.getBlockState(this.cobwebPos).is(Blocks.COBWEB);
                                        if (var8_6 == null || var2_2 <= 0L) break block5;
                                        if (v1 == 0) break block6;
                                        takePos = BaseModule.a.player.getEyePosition();
                                        if (var8_6 == null) break block7;
                                        v3 = new Object[1];
                                        v3[0] = var4_3;
                                        if (!(takePos.distanceTo(cobwebCenter) > this.a(v3))) break block8;
                                    }
                                    BaseModule.a.gameMode.stopDestroyBlock();
                                    this.cobwebPos = null;
                                    v1 = 0;
                                }
                                return (boolean)v1;
                            }
                            takePos = cobwebCenter;
                        }
                        angles = aj.a(takePos);
                        v4 = new Object[4];
                        v4[3] = false;
                        v4[2] = var6_4;
                        v4[1] = Float.valueOf(angles[1]);
                        v4[0] = Float.valueOf(angles[0]);
                        this.d(v4);
                        v5 = blockHit = BaseModule.a.level.clip(new ClipContext(BaseModule.a.player.getEyePosition(), cobwebCenter, ClipContext.mc3960.OUTLINE, ClipContext.mc242.NONE, (Entity)BaseModule.a.player));
                        v6 = var8_6;
                        if (var2_2 < 0L) break block9;
                        if (v6 == null) break block10;
                        if (v5 == null) ** GOTO lbl-1000
                        v5 = blockHit;
                    }
                    v6 = var8_6;
                }
                if (var2_2 <= 0L) break block11;
                if (v6 == null) break block12;
                if (v5.getType() != HitResult.mc240.BLOCK) ** GOTO lbl-1000
                v5 = blockHit;
            }
            v6 = var8_6;
        }
        if (v6 == null) ** GOTO lbl57
        if (v5.getBlockPos().equals((Object)this.cobwebPos)) {
            v5 = blockHit;
lbl57:
            // 2 sources

            v7 = v5.getDirection();
        } else lbl-1000:
        // 3 sources

        {
            v7 = Direction.UP;
        }
        face = v7;
        BaseModule.a.gameMode.continueDestroyBlock(this.cobwebPos, face);
        BaseModule.a.player.swing(InteractionHand.MAIN_HAND);
        return true;
    }

    /*
     * Unable to fully structure code
     */
    private void d(Object[] var1_1) {
        block9: {
            block8: {
                block6: {
                    block7: {
                        targetYaw = ((Float)var1_1[0]).floatValue();
                        targetPitch = ((Float)var1_1[1]).floatValue();
                        var2_4 = (Long)var1_1[2];
                        useSilent = (Boolean)var1_1[3];
                        var2_4 = AutoDrain.G ^ var2_4;
                        var7_6 = am.b();
                        v0 = useSilent;
                        if (var7_6 == null) break block6;
                        if (!v0) break block7;
                        v0 = (Boolean)this.silentRotate.a();
                        if (var2_4 > 0L && var7_6 != null) {
                            if (v0) {
                                ai.a(targetYaw, targetPitch);
                                return;
                            } else {
                                ** GOTO lbl17
                            }
                        }
                        break block6;
                    }
                    v1 = this;
                    if (var7_6 == null) break block8;
                    v0 = v1.rotationPending;
                }
                if (v0) break block9;
                this.savedYaw = BaseModule.a.player.getYRot();
                this.savedPitch = BaseModule.a.player.getXRot();
                v1 = this;
            }
            v1.rotationPending = true;
        }
        BaseModule.a.player.setYRot(targetYaw);
        BaseModule.a.player.setXRot(targetPitch);
    }

    private void e(Object[] objectArray) {
        block6: {
            int selectedSlot;
            block4: {
                int itemSlot;
                block5: {
                    itemSlot = (Integer)objectArray[0];
                    long l2 = (Long)objectArray[1];
                    l2 = G ^ l2;
                    String string = am.b();
                    selectedSlot = ((Boolean)this.switchBack.a()).booleanValue();
                    if (string == null) break block4;
                    if (selectedSlot == 0) break block5;
                    if (l2 < 0L) break block6;
                    selectedSlot = this.savedSlot;
                    if (string == null) break block4;
                    if (selectedSlot == -1) {
                        this.savedSlot = BaseModule.a.player.getInventory().getSelectedSlot();
                    }
                }
                selectedSlot = itemSlot;
            }
            a.a.a.p.J.a((int)selectedSlot);
        }
    }

    private void f(Object[] objectArray) {
        block4: {
            block7: {
                AutoDrain autoDrain;
                block5: {
                    int n2;
                    block8: {
                        long l2;
                        block6: {
                            l2 = (Long)objectArray[0];
                            l2 = G ^ l2;
                            String string = am.b();
                            ai.a();
                            String string2 = string;
                            if (string2 == null) break block4;
                            if (BaseModule.a.player == null) break block5;
                            n2 = this.rotationPending;
                            if (l2 < 0L || string2 == null) break block6;
                            if (n2 != 0) {
                                BaseModule.a.player.setYRot(this.savedYaw);
                                BaseModule.a.player.setXRot(this.savedPitch);
                            }
                            if (l2 <= 0L) break block4;
                            autoDrain = this;
                            if (string2 == null) break block7;
                            n2 = autoDrain.savedSlot;
                        }
                        if (l2 <= 0L) break block8;
                        if (n2 < 0) break block5;
                        n2 = this.savedSlot;
                    }
                    a.a.a.p.J.a((int)n2);
                }
                this.rotationPending = false;
                autoDrain = this;
            }
            autoDrain.savedSlot = -1;
        }
    }

    private double a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = G ^ l2;
        return Math.min((Double)this.radius.a(), BaseModule.a.player.blockInteractionRange());
    }

    private int a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = G ^ l2;
        return Math.max(1, (int)Math.round(20.0 / (Double)this.blocksPerSecond.a()));
    }

    /*
     * Exception decompiling
     */
    private int c(Object[] var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * java.lang.UnsupportedOperationException
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.considerAsDoLoopStart(LoopIdentifier.java:383)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.identifyLoops1(LoopIdentifier.java:65)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:681)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Unable to fully structure code
     */
    static {
        block21: {
            block20: {
                block19: {
                    block18: {
                        AutoDrain.G = kuzi.obf.h.b.v.a(6177835861405155460L, 2995690498525604217L, MethodHandles.lookup().lookupClass()).a(226392088298538L);
                        AutoDrain.N = new Object[90];
                        AutoDrain.O = new String[90];
                        AutoDrain.c();
                        AutoDrain.J = new HashMap<K, V>(13);
                        var11 = AutoDrain.G ^ 72078787398060L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[9];
                        var18_4 = 0;
                        var17_5 = "\u00c3\u0002LLl\u00d6\u0091\u00e5\u00f3b_w\u00e0U\u00bcr \u0096_5\u00d3\u00ad\u00f1\u00c9\u00ef\u00c0\u00e5\u00b4@r\u00a7k\u0088\u00bb\u00db\u0004\u00d3\u00f2\u001dH\u0011\u00d5#|\u000f\u0083\u00be\u00dd\u009f\u0010\u00b7\u00eb5\u00c8\u00dfp\u00e5-\u00c2n\u00c8\u009a\u00dd\u00e3\u00ab\u0010\u00181\u0090\u00de\u00e0\u00fe\u00f1\b\u009bb\u00a4\u00ac\u001d\u009c\u00efM$0\u00a9\u008f\u00b6Z\u0097m\u00f3p\u00e4| }g9D<\u007f\u00ee\u00b1\u00fb\u00e7s\u00c6rG\u00ccp\u00d16Z\"L\u0011Z\u00a2\u00cbNL\u00fd~\u0085z\u0090\u00e9_)~JCZR\u007f\u00bflL\r\u00ac\u0093\u00fd:m\u00a48\u00c6:h\u00c8$\u007fF\u0002\u00d9q\u00da=)\u0089\u0015\u0006\u00b0^/\u001bE\u0002Y\u00fe5\u00a4Qm\u00eb\u00c83\u00c8\u009d\u00e9\u0091F\u0095\u001dEV\u0099\u00b1i\u00db\u0092M\u0002Ec?\u0094n\u00bb\u009dwY\u00c8 _\t}7y\u00ff\u00cb\u001c.\u00f5k\u00d5a\u00a8R\u0002\u00d3\u00db\u00c96L\u00e0\u000ep\u00bfu\u00f8\u00bc{ \u0088=(iK\n\"x\u009d]\u00ef\u00aa\u0003j\u00e5\u009b\u00f6\u008d\u00b4A\u0010\u0003\u00cbT\u00fa\u00a2L^\u00d0)\u00a4|\f\u00b9\u00a9\u00dcK7\u001bR\u00c4\u001e\u000e";
                        var19_6 = "\u00c3\u0002LLl\u00d6\u0091\u00e5\u00f3b_w\u00e0U\u00bcr \u0096_5\u00d3\u00ad\u00f1\u00c9\u00ef\u00c0\u00e5\u00b4@r\u00a7k\u0088\u00bb\u00db\u0004\u00d3\u00f2\u001dH\u0011\u00d5#|\u000f\u0083\u00be\u00dd\u009f\u0010\u00b7\u00eb5\u00c8\u00dfp\u00e5-\u00c2n\u00c8\u009a\u00dd\u00e3\u00ab\u0010\u00181\u0090\u00de\u00e0\u00fe\u00f1\b\u009bb\u00a4\u00ac\u001d\u009c\u00efM$0\u00a9\u008f\u00b6Z\u0097m\u00f3p\u00e4| }g9D<\u007f\u00ee\u00b1\u00fb\u00e7s\u00c6rG\u00ccp\u00d16Z\"L\u0011Z\u00a2\u00cbNL\u00fd~\u0085z\u0090\u00e9_)~JCZR\u007f\u00bflL\r\u00ac\u0093\u00fd:m\u00a48\u00c6:h\u00c8$\u007fF\u0002\u00d9q\u00da=)\u0089\u0015\u0006\u00b0^/\u001bE\u0002Y\u00fe5\u00a4Qm\u00eb\u00c83\u00c8\u009d\u00e9\u0091F\u0095\u001dEV\u0099\u00b1i\u00db\u0092M\u0002Ec?\u0094n\u00bb\u009dwY\u00c8 _\t}7y\u00ff\u00cb\u001c.\u00f5k\u00d5a\u00a8R\u0002\u00d3\u00db\u00c96L\u00e0\u000ep\u00bfu\u00f8\u00bc{ \u0088=(iK\n\"x\u009d]\u00ef\u00aa\u0003j\u00e5\u009b\u00f6\u008d\u00b4A\u0010\u0003\u00cbT\u00fa\u00a2L^\u00d0)\u00a4|\f\u00b9\u00a9\u00dcK7\u001bR\u00c4\u001e\u000e".length();
                        var16_7 = 16;
                        var15_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block18;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = AutoDrain.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "\u000b\u00c9\u00a2\u00f18\u0092I\u00b0\\=\u00ee\u00caGv\\H \u007f\u00fbAaC\u008f}\b\u00c9\u00e8\u00b76\u00de\u00d7\u00c0\u0080V\u00df|z\u0090\u008a!\u00aeY\u0019\u00d3\u00f5\u0089\u0017\u00eaG";
                            var19_6 = "\u000b\u00c9\u00a2\u00f18\u0092I\u00b0\\=\u00ee\u00caGv\\H \u007f\u00fbAaC\u008f}\b\u00c9\u00e8\u00b76\u00de\u00d7\u00c0\u0080V\u00df|z\u0090\u008a!\u00aeY\u0019\u00d3\u00f5\u0089\u0017\u00eaG".length();
                            var16_7 = 16;
                            var15_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block18;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = AutoDrain.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block19;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                AutoDrain.H = var20_3;
                AutoDrain.I = new String[9];
                AutoDrain.M = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[5];
                var3_13 = 0;
                var4_14 = "\u0093e\u00af\u0099|\u00eb2C\u00b1\u00ba\u00f9\u000b2\u009a\u00e4\u008f^5[O\u001d\u00e7\u0002B";
                var5_15 = "\u0093e\u00af\u0099|\u00eb2C\u00b1\u00ba\u00f9\u000b2\u009a\u00e4\u008f^5[O\u001d\u00e7\u0002B".length();
                var2_16 = 0;
                while (true) {
                    var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                    v10 = var6_12;
                    v11 = var3_13++;
                    v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                    v13 = -1;
                    break block20;
                    break;
                }
lbl81:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    var4_14 = "\u00ca\u00a8}\u00d9\u0012w\u0091\u0012A\u00b3\u00c7\u0090M\u00f2\r.";
                    var5_15 = "\u00ca\u00a8}\u00d9\u0012w\u0091\u0012A\u00b3\u00c7\u0090M\u00f2\r.".length();
                    var2_16 = 0;
                    while (true) {
                        var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                        v10 = var6_12;
                        v11 = var3_13++;
                        v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                        v13 = 0;
                        break block20;
                        break;
                    }
                    break;
                }
lbl94:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    break block21;
                    break;
                }
            }
            var8_18 = v12;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            v14 = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
            switch (v13) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl107:
                // 1 sources

                ** continue;
            }
        }
        AutoDrain.K = var6_12;
        AutoDrain.L = new Integer[5];
    }

    private static MatchException a(MatchException matchException) {
        return matchException;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x2A33;
        if (L[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = K[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])M.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    M.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/e/y", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            AutoDrain.L[n3] = n4;
        }
        return L[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = AutoDrain.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/e/y" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static void c() {
        Object[] objectArray = N;
        N[0] = "h$>_7/c$:_/";
        objectArray[1] = "i\f(C<\u0006\u001c,#L-I}\"(G)\u0013\t";
        objectArray[2] = Void.TYPE;
        AutoDrain.O[2] = "java/lang/Void";
        objectArray[3] = "\t3#6V0\u00183#q";
        objectArray[4] = Integer.TYPE;
        AutoDrain.O[4] = "java/lang/Integer";
        objectArray[5] = "T%oAQd_%kAQ'";
        objectArray[6] = "[LzXmxPCk\u0017\u0010`CDb^";
        objectArray[7] = "GQlM/ELQg";
        objectArray[8] = "\u001d\u0013\u0001<bS\u001d\u0013\u0016`n\\\u0007X\u0016~nI\u0000)F#?";
        objectArray[9] = Float.TYPE;
        AutoDrain.O[9] = "java/lang/Float";
        objectArray[10] = Boolean.TYPE;
        AutoDrain.O[10] = "java/lang/Boolean";
        objectArray[11] = "UAq9XK^N`v;FKCo\u001d\u000eDZPs1\u0019I";
        objectArray[12] = "w\nx;\u0013\u0001f\nS";
        objectArray[13] = "1\u0012.>DY8\u0012->D";
        objectArray[14] = "*\u001e@\u0014K\u0017!\u0011Q[*\u0019*\u001aU\u0001";
        objectArray[15] = "3\u0006\u001ao\u007fp:\u0006\u0019o}";
        objectArray[16] = "\tNd\u0002eA\tNs^iN\u0013\u0005s@i[\u0014t#\u0015>\u001d";
        objectArray[17] = "1OU=S&Do^2Bi%aU9F3Q";
        objectArray[18] = "9\u000ft<\u0012GL/\u007f3\u0003\b-!t8\u0007RY";
        objectArray[19] = "}\u0005e\t1\u001b}\u0005rU=\u0014gNrK=\u0001`?#\u0014oJ";
        objectArray[20] = "P6\u0011l\u001b~%\u0016\u001ac\n1D\u0018\u0011h\u000ek0";
        objectArray[21] = "^\nDDU(O\nD+";
        objectArray[22] = "0_U\nbTE\u007f^\u0005s\u001b$qU\u000ewAP";
        objectArray[23] = "(Ppk%I!Psk(";
        objectArray[24] = "\u0013\u001d\u001et\u0003 f=\u0015{\u0012o\u00073\u001ep\u00165s";
        objectArray[25] = "\"\t\u001c:)NW)\u001758\u00016'\u001c><[B";
        objectArray[26] = "T\\GGu{!|LHd4@rGC`n4";
        objectArray[27] = "\u0000?0P'Cu\u001f;_6\f\u0014\u00110T2V`";
        objectArray[28] = "59~=\nP>9z=\b";
        objectArray[29] = " \rU\u0011\u0000,)\rV\u0011\f";
        objectArray[30] = "Q_\"#dV$\u007f),u\u0019Eq\"'qC1";
        objectArray[31] = "k\u000eX<\"d\u001e.S33+\u007f X87q\u000b";
        objectArray[32] = Double.TYPE;
        AutoDrain.O[32] = "java/lang/Double";
        objectArray[33] = " SB\u007fe\f1SB;";
        objectArray[34] = "\u000b+ \u0019_n\u000b+7ESa\u0011`7[St\u0016\u0011f\u0003\u0001";
        objectArray[35] = "c\u0006";
        objectArray[36] = "yIL\u0002hX\fiG\ry\u0017mgL\u0006}M\u0019";
        objectArray[37] = "\u0014y/ky\\aY$dh\u0013\u0000W/olIt";
        objectArray[38] = "\t(m\u0005\u0015,|\bf\n\u0004c\u001d\u0006m\u0001\u00009i";
        objectArray[39] = "f$5RX\fm$=";
        objectArray[40] = ",dP\u0018o9'dT\u0018l";
        objectArray[41] = "q!\u0001[q\t\u0004\u0001\nT`Fe\u000f\u0001_d\u001c\u0011";
        objectArray[42] = "m+ng\"-f\"t\r3D,h~qd~4+cmX~*svl7<;h;\r";
        objectArray[43] = "Q%\u0019sR\bZ,\u0003\u0019Sa\u0002m\u0011s\u0016Q\u0015l\u0018%";
        objectArray[44] = ";\u0018g\u0018,Q0\u0011}r*8kGj\u001b9\bzNp\u0012";
        objectArray[45] = " \u001ayi$T+\u0013c\u0003\u0017=$Knm7Rp\u0013ce";
        objectArray[46] = "\u0018\r\u001eTl@\u0013\u0004\u0004>\\)\u001cM\u0012\u0007uQ\u001aR\u0019X";
        objectArray[47] = "\u0018\u001c,dXN\u0013\u00156\u000eZ'A\u00119wC\u001cF\u0016-p";
        objectArray[48] = "\\L}V|<WEg<lU\u001d\u000fm@:o\u0005Lp\\\u0006l\u0004\u0000&Xz7^\u0003i<";
        objectArray[49] = "}O\u0005~\u00107vF\u001f\u0014\u0007^<\f\u0015hVd$O\btjg%\u0003^p\u0016<\u007f\u0000\u0011\u0014";
        objectArray[50] = "a=i\u0000\u0014=j4sj\u0002T ~y\u0016Rn8=d\nnj*j:\t\u0016l5aej";
        objectArray[51] = "C!4QA\u0005\u0014~u\u00141\u0012y%+U_\u0012\u0016qsXW{G{6FX\u0014\u0013#;N1B\u001bfzLM\u0019Ae5(";
        objectArray[52] = "%d\u0004e\u0004V.m\u001e\u000f\u0017?d'\u0014sB\u0005|d\to~Szn\u0016wO\u0003 4\u000b\u000f";
        objectArray[53] = "\u0012\u0001\b|6}\u0019\b\u0012\u0016%\u0014SB\u0018jp.K\u0001\u0005vL*YV[u4,F]\u0004\u0016";
        objectArray[54] = "\u0015\u0007s?V\"\u001e\u000eiUEKTDc)\u0010qL\u0007~5,.VWg,].VQ%U";
        objectArray[55] = "\u0005\u007f\u0010M8tU6\fEU#k-\u0010L<%[<\u0019V5JU6\u0018\u001262S)\u0013MUs\t:OO)(S9\u0000+";
        objectArray[56] = "{5_\u000eJ\u001bp<EdNr\u007fdH\nY\u001d+<E\u0002";
        objectArray[57] = "\u001awS6`?\u0011~I\\sV\u001f9\\?~mR!Ka\u001ai_#Z8!$G4\u0004\\";
        objectArray[58] = "hF\\\u0017\u00061*R\u0005Wk4X\u001a\u001c\u0006\u0019<7X\r\u001dT]aB\u001c^\u000f!:\u0018\u001f\u0011k";
        objectArray[59] = "<rQ~zR7{K\u0014N;<>RfaT~/I+";
        objectArray[60] = "^\u0003\u001e;(xU\n\u0004Q9\u0011\u001f@\u000e-n+\u0007\u0003\u00131R(\u0006OE5.s\\L\nQ";
        objectArray[61] = "PTl\u0019\u00160[]vs YP\u0018o\u0001\r6\u0012\ttL";
        objectArray[62] = ",<1[(3 <'\\I=\u001ddtN&0za:ZsT";
        objectArray[63] = "YP\u0016fym\u0006\u0017\u000e0\u0017\u0017fg5\u0014K]YP\u0016fym\u0006\u0017\u000e0";
        objectArray[64] = "OVj+*(D_pA)A\u001c\u001eb+nq\u000b\u001fk}";
        objectArray[65] = "tT2g,>\u007f](\r3W!\u00007p('3\u001bdc";
        objectArray[66] = "\rfz\u0005a-\u0006o`ofD[2+\u0017cu\u000bhq\n";
        objectArray[67] = "Ax^\u000f\u001b9\u0016'\u001fJk.{{C\u000bZ#\u0007 \u0019\b\u0015G";
        objectArray[68] = "&]!Ns\u0005-T;$xl&\u0011\"Vh\u0003d\u00009\u001b";
        objectArray[69] = "\u00004<g/T\u000b=&\r;=Aw,qi\u0007Y41mU\u0003Kcon-\u0005Th0\r";
        objectArray[70] = "p!g\"G\u0016{(}H[\u007f%ub5C\u000f7n1&";
        objectArray[71] = "_\\\u0000+A]]K\u0007(}\bd\u0005\u00039DY_Y\u0015w\u001fb";
        objectArray[72] = "\u0004TD.ThH\u0015\u0002~9c9Y\u0003~D1RU\u0017tV";
        objectArray[73] = "/\u000fs\u0019|?$\u0006isjVnLc\u000f:lv\u000f~\u0013\u0006owC(\u0017z4-@gs";
        objectArray[74] = "#e_yt\u0014$k\u0007xNLFs@xrT|iYt6%!h\r)>C}(ZlN";
        objectArray[75] = "D~>}=KOw$\u00178\"@/)y.M\u0014w$q";
        objectArray[76] = "\u0017\u001b\u001b*di\u0014\u0003U5\u000fZ*\"c\t\u000f\u007f\u000eDH.c|\u0016\nW";
        objectArray[77] = "Z1\u001be\u0005rQ8\u0001\u000f4\u001bZ}\u0018}\u001et\u0018l\u00030";
        objectArray[78] = "fs@\u0010\u0019\u000bmzZz\nb'0P\u0006_X?sM\u001acX!+X\u001b\f\u001a00\u0015z";
        objectArray[79] = "zpeK@Zqy\u007f!T3;3u]\u0006\t#phA:\n\"<>EFQx?q!";
        objectArray[80] = "\u001djzT\bl\u0016c`>\b\u0005N\"rTL5Y#{\u0002";
        objectArray[81] = "o<\u001bP\u00151d5\u0001:\u0006X.\u007f\u000bFSb6<\u0016Zoa7p@^\u0013:ms\u000f:";
        objectArray[82] = "r4uSh\u0000-sm\u0005\u0006o]\u0002\u0015\u000ezP/&%Q=Hy";
        objectArray[83] = "x!\u0017&@&s(\rLJO|a\u001buY7z~\u0010*";
        objectArray[84] = "k\n\u0011VP~`\u0003\u000b<X\u0017o[\u0006RCx;\u0003\u000bZ";
        objectArray[85] = "\u0006a0\u0013tS\f' \u0003\u0004g4\u0002\r \u0004CB.)\noI\u0004>9";
        objectArray[86] = "\u0018mU\u0013z+\u0013dOygBA`@\u0000ayFgT\u0007";
        objectArray[87] = "ag:27xjn X$\u0011 $*$q+8g78M{5197}j<+0X";
        objectArray[88] = "]\u007fFeU\u0007\u0011>\u000058\u0001`4\t$DYZ,J9XeY-\u0006o\\\u0019\u0002w\u0005 8";
        Object[] objectArray2 = objectArray;
        objectArray[89] = "/-K?Et$$QUr\u001dyy\u001a-G,)#@0";
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = AutoDrain.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = AutoDrain.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = AutoDrain.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = AutoDrain.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(AutoDrain.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

