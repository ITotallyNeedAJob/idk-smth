// === Kuzi module: ExtraESP ===
// Category   : WORLD
// Description: Detects various blocks and entities
// Payload    : a.a.a.j.g.O (verified: True)

package kuzi.modules.world;

import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.b.e;
import kuzi.obf.h.b.l;
import kuzi.obf.h.b.v;
import kuzi.obf.j.f.i;
import kuzi.obf.j.g.aD;
import kuzi.obf.j.g.n;
import kuzi.obf.j.g.o;
import kuzi.obf.j.g.p;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import net.minecraft.SimpleSoundInstance;
import net.minecraft.SoundInstance;
import net.minecraft.Entity;
import net.minecraft.Llama;
import net.minecraft.Pillager;
import net.minecraft.ZombieVillager;
import net.minecraft.Villager;
import net.minecraft.ChunkPos;
import net.minecraft.Blocks;
import net.minecraft.BlockPos;
import net.minecraft.BlockState;
import net.minecraft.LevelChunk;
import net.minecraft.Minecraft;
import net.minecraft.SoundEvent;
import net.minecraft.SoundEvents;
import net.minecraft.WanderingTrader;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class ExtraESP
extends BaseModule {
    private static final long m;
    private static final long n;
    private static final long o;
    private static final Set p;
    private final BoolSetting detectVines;
    private final BoolSetting detectKelp;
    private final BoolSetting detectVillagers;
    private final BoolSetting detectZombieVillagers;
    private final BoolSetting detectPillagers;
    private final BoolSetting detectWanderingTraders;
    private final BoolSetting detectDeepslate;
    private final BoolSetting detectRotatedDeepslate;
    private final BoolSetting detectLlamas;
    private final BoolSetting detectAmethyst;
    private final BoolSetting detect1x1Holes;
    private final BoolSetting soundAlert;
    private final BoolSetting tracers;
    private final l scanSpeed;
    private final e vineColor;
    private final e kelpColor;
    private final e deepslateColor;
    private final e rotatedDeepslateColor;
    private final e amethystColor;
    private final e hole1x1Color;
    private final e villagerColor;
    private final e zombieVillagerColor;
    private final e pillagerColor;
    private final e llamaColor;
    private final e wanderingTraderColor;
    private final Map detectedBlocks;
    private final Map detectedEntities;
    private final Set R;
    private final Set S;
    private final Set alertedEntities;
    private final Queue U;
    private ExecutorService scanExecutor;
    private volatile boolean running;
    private long lastCleanupTime;
    private long lastScanTime;
    private long lastValidationTime;
    private long lastMiscScanTime;
    private long lastEntityScanTime;
    private static final long bb;
    private static final String[] db;
    private static final String[] hb;
    private static final Map ib;
    private static final long[] jb;
    private static final Integer[] kb;
    private static final Map lb;
    private static final long[] mb;
    private static final Long[] nb;
    private static final Map ob;
    private static final Object[] pb;
    private static final String[] sb;

    public ExtraESP() {
        long l2;
        long l3 = l2 = bb ^ 0x7580EBA75B90L;
        long l4 = l3 ^ 0x20AAE66E0782L;
        long l5 = l3 ^ 0x2EC57EBF1687L;
        super("ExtraESP", "Detects various blocks and entities", Category.WORLD);
        this.detectVines = new BoolSetting("Detect Vines", true);
        this.detectKelp = new BoolSetting("Detect Kelp", true);
        this.detectVillagers = new BoolSetting("Detect Villagers", true);
        this.detectZombieVillagers = new BoolSetting("Detect Zombie Villagers", true);
        this.detectPillagers = new BoolSetting("Detect Pillagers", true);
        this.detectWanderingTraders = new BoolSetting("Detect Wandering Traders", true);
        this.detectDeepslate = new BoolSetting("Detect Deepslate", true);
        this.detectRotatedDeepslate = new BoolSetting("Detect Rotated Deepslate", true);
        this.detectLlamas = new BoolSetting("Detect Llamas", true);
        this.detectAmethyst = new BoolSetting("Detect Amethyst", true);
        this.detect1x1Holes = new BoolSetting("Detect 1x1 Holes", true);
        this.soundAlert = new BoolSetting("Sound Alert", true);
        this.tracers = new BoolSetting("Tracers", false);
        this.scanSpeed = new l("Scan Speed", kuzi.obf.j.g.p.MEDIUM, p.class);
        this.vineColor = new e("Vine Color", new Color(14, 232, 14, 245));
        this.kelpColor = new e("Kelp Color", new Color(43, 181, 43, 237));
        this.deepslateColor = new e("Deepslate Color", new Color(15, 177, 229, 239));
        this.rotatedDeepslateColor = new e("Rotated Deepslate Color", new Color(255, 192, 203, 150));
        this.amethystColor = new e("Amethyst Color", new Color(99, 12, 230, 219));
        this.hole1x1Color = new e("1x1 Hole Color", new Color(255, 165, 0, 239));
        this.villagerColor = new e("Villager Color", new Color(60, 179, 113, 255));
        this.zombieVillagerColor = new e("Zombie Villager Color", new Color(34, 139, 34, 255));
        this.pillagerColor = new e("Pillager Color", new Color(105, 105, 105, 255));
        this.llamaColor = new e("Llama Color", new Color(222, 184, 135, 255));
        this.wanderingTraderColor = new e("Wandering Trader Color", new Color(30, 144, 255, 255));
        this.detectedBlocks = new ConcurrentHashMap();
        this.detectedEntities = new ConcurrentHashMap();
        this.R = ConcurrentHashMap.newKeySet();
        this.S = ConcurrentHashMap.newKeySet();
        this.alertedEntities = ConcurrentHashMap.newKeySet();
        this.U = new ConcurrentLinkedQueue();
        this.running = false;
        this.lastCleanupTime = 0L;
        this.lastScanTime = 0L;
        this.lastValidationTime = 0L;
        this.lastMiscScanTime = 0L;
        this.lastEntityScanTime = 0L;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.detectVines, this.detectKelp, this.detectVillagers, this.detectZombieVillagers, this.detectPillagers, this.detectWanderingTraders, this.detectDeepslate, this.detectRotatedDeepslate, this.detectLlamas, this.detectAmethyst, this.detect1x1Holes, this.soundAlert, this.tracers, this.scanSpeed, this.vineColor, this.kelpColor, this.deepslateColor, this.rotatedDeepslateColor, this.amethystColor, this.hole1x1Color, this.villagerColor, this.zombieVillagerColor, this.pillagerColor, this.llamaColor, this.wanderingTraderColor};
        objectArray[0] = l5;
        this.l(objectArray);
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l4;
        i.a(objectArray2);
    }

    @Override
    public void d() {
        long l2 = bb ^ 0x112B221371CFL;
        long l3 = l2 ^ 0x9D2EF1F52E7L;
        int[] nArray = aD.b();
        if (nArray != null) {
            if (BaseModule.a.level == null) {
                return;
            }
            Object[] objectArray = new Object[1];
            objectArray[0] = l3;
            this.a(objectArray);
        }
    }

    @Override
    public void g(Object[] objectArray) {
        long l2;
        long l3;
        block4: {
            l3 = (Long)objectArray[0];
            l2 = l3 ^ 0x44F51585BBD4L;
            try {
                try {
                    if (ExtraESP.f("\u00e0", (Object)this, (long)5683942831239878691L, (long)l3) != false && ((Minecraft)ExtraESP.f("\u00dd", (long)5686967293294809136L, (long)l3)).level != null) break block4;
                }
                catch (MatchException matchException) {
                    throw ExtraESP.f("\u00f9", (Object)matchException, (long)5684178261048973954L, (long)l3);
                }
                return;
            }
            catch (MatchException matchException) {
                throw ExtraESP.f("\u00f9", (Object)matchException, (long)5684178261048973954L, (long)l3);
            }
        }
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l2;
        ExtraESP.f("\u00e0", (Object)this, (Object)objectArray2, (long)5686130582507328206L, (long)l3);
    }

    private void a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = l2 = bb ^ l2;
        long l4 = l3 ^ 0x13D3F9CA0323L;
        long l5 = l3 ^ 0x5FA49EEE71C6L;
        long l6 = l3 ^ 0x5982482C6668L;
        long l7 = l3 ^ 0x211D81F81C7EL;
        int[] nArray = aD.b();
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l7;
        this.b(objectArray2);
        this.running = true;
        this.lastCleanupTime = System.currentTimeMillis();
        int[] nArray2 = nArray;
        this.lastScanTime = 0L;
        this.lastValidationTime = 0L;
        this.lastMiscScanTime = 0L;
        this.lastEntityScanTime = 0L;
        Object object = this.scanExecutor;
        if (nArray2 != null) {
            if (object != null) {
                this.scanExecutor.shutdownNow();
                this.scanExecutor = null;
            }
            object = this.scanSpeed.a();
        }
        Object[] objectArray3 = new Object[1];
        objectArray3[0] = l4;
        int n2 = ((p)((Object)object)).a(objectArray3);
        this.scanExecutor = Executors.newFixedThreadPool(n2, arg_0 -> ExtraESP.lambda$startScanner$0(l6, arg_0));
        Object[] objectArray4 = new Object[1];
        objectArray4[0] = l5;
        this.c(objectArray4);
    }

    @Override
    public void e() {
        long l2 = bb ^ 0x4573BF211E1L;
        long l3 = l2 ^ 0x4715E963F8B5L;
        this.running = false;
        int[] nArray = aD.b();
        ExtraESP extraESP = this;
        if (nArray != null) {
            if (extraESP.scanExecutor != null) {
                this.scanExecutor.shutdownNow();
                this.scanExecutor = null;
            }
            extraESP = this;
        }
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        extraESP.b(objectArray);
    }

    @Override
    public void i() {
        block17: {
            long l2;
            long l3;
            long l4;
            long l5;
            long l6;
            block16: {
                int[] nArray;
                long l7;
                long l8;
                long l9;
                long l10;
                long l11;
                block15: {
                    block14: {
                        Minecraft mc;
                        block13: {
                            long l12 = l11 = bb ^ 0x9307687B6E3L;
                            l10 = l12 ^ 0x187366D5DECBL;
                            l6 = l12 ^ 0x4B8319093984L;
                            l9 = l12 ^ 0x1758B102E2EAL;
                            l8 = l12 ^ 0x31DA97A0C762L;
                            l5 = l12 ^ 0x24B4C1BC32DDL;
                            l4 = l12 ^ 0x1D2BD8856934L;
                            l7 = l12 ^ 0x777D011EFE23L;
                            nArray = aD.b();
                            mc = BaseModule.a;
                            if (nArray == null) break block13;
                            if (mc.level == null) break block14;
                            mc = BaseModule.a;
                        }
                        if (mc.player != null) break block15;
                    }
                    return;
                }
                l3 = System.currentTimeMillis();
                Object[] objectArray = new Object[1];
                objectArray[0] = l9;
                long scanIntervalMs = ((p)((Object)this.scanSpeed.a())).a(objectArray);
                long sinceCleanup = l3 - this.lastCleanupTime - ExtraESP.d("y", (int)22496, (long)(0x3EDB264F20A718D0L ^ l11));
                l2 = sinceCleanup == 0L ? 0 : (sinceCleanup < 0L ? -1 : 1);
                if (nArray != null) {
                    long sinceValidation;
                    if (l2 > 0) {
                        Object[] objectArray2 = new Object[1];
                        objectArray2[0] = l7;
                        this.performCleanup(objectArray2);
                        this.lastCleanupTime = l3;
                    }
                    l2 = (sinceValidation = l3 - this.lastValidationTime - ExtraESP.d("y", (int)24789, (long)(0x36383898BF062FE1L ^ l11))) == 0L ? 0 : (sinceValidation < 0L ? -1 : 1);
                }
                if (nArray != null) {
                    long sinceEntityScan;
                    if (l2 > 0) {
                        Object[] objectArray3 = new Object[1];
                        objectArray3[0] = l8;
                        this.validateDetectedBlocks(objectArray3);
                        this.lastValidationTime = l3;
                    }
                    l2 = (sinceEntityScan = l3 - this.lastEntityScanTime - ExtraESP.d("y", (int)15999, (long)(0x15F304484B94F14EL ^ l11))) == 0L ? 0 : (sinceEntityScan < 0L ? -1 : 1);
                }
                if (nArray != null) {
                    long sinceChunkScan;
                    if (l2 > 0) {
                        Object[] objectArray4 = new Object[1];
                        objectArray4[0] = l10;
                        this.scanEntities(objectArray4);
                        this.lastEntityScanTime = l3;
                    }
                    l2 = (sinceChunkScan = l3 - this.lastScanTime - scanIntervalMs) == 0L ? 0 : (sinceChunkScan < 0L ? -1 : 1);
                }
                if (nArray == null) break block16;
                if (l2 <= 0) break block17;
                long sinceMiscScan = l3 - this.lastMiscScanTime - ExtraESP.d("y", (int)26270, (long)(0x4036F29D893729ADL ^ l11));
                l2 = sinceMiscScan == 0L ? 0 : (sinceMiscScan < 0L ? -1 : 1);
            }
            if (l2 > 0) {
                Object[] objectArray = new Object[1];
                objectArray[0] = l4;
                this.m(objectArray);
                this.lastMiscScanTime = l3;
            }
            Object[] objectArray = new Object[1];
            objectArray[0] = l6;
            this.f(objectArray);
            Object[] objectArray5 = new Object[1];
            objectArray5[0] = l5;
            this.n(objectArray5);
            this.lastScanTime = l3;
        }
    }

    private void b(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = bb ^ l2;
        this.detectedBlocks.clear();
        this.detectedEntities.clear();
        this.R.clear();
        this.S.clear();
        this.alertedEntities.clear();
        this.U.clear();
    }

    private void c(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = (l2 = bb ^ l2) ^ 0x6841D5423E92L;
        int[] nArray = aD.b();
        ExecutorService executorService = this.scanExecutor;
        if (nArray != null) {
            if (executorService == null) {
                return;
            }
            executorService = this.scanExecutor;
        }
        executorService.submit(() -> this.lambda$startInitialScan$1(l3));
    }

    /*
     * Exception decompiling
     */
    private void f(Object[] var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * java.lang.UnsupportedOperationException
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.considerAsDoLoopStart(LoopIdentifier.java:383)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.identifyLoops1(LoopIdentifier.java:65)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:681)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    private void m(Object[] var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * java.lang.UnsupportedOperationException
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.considerAsDoLoopStart(LoopIdentifier.java:383)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.identifyLoops1(LoopIdentifier.java:65)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:681)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    private void n(Object[] var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * java.lang.UnsupportedOperationException
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.considerAsDoLoopStart(LoopIdentifier.java:383)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.identifyLoops1(LoopIdentifier.java:65)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:681)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private void d(Object[] objectArray) {
        LevelChunk chunk = (LevelChunk)objectArray[0];
        long l2 = (Long)objectArray[1];
        long l3 = (l2 = bb ^ l2) ^ 0x80A4E45735DL;
        int chunkX = (int)(l3 >>> 48);
        int chunkZ = (int)(l3 << 16 >>> 48);
        int flags = (int)(l3 << 32 >>> 32);
        int[] nArray = aD.b();
        ExecutorService executorService = this.scanExecutor;
        if (nArray != null) {
            if (executorService == null) {
                return;
            }
            executorService = this.scanExecutor;
        }
        executorService.submit(() -> this.lambda$scheduleChunkScan$2(chunk, (char)chunkX, (short)chunkZ, flags));
    }

    private void validateDetectedBlocks(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = (l2 = bb ^ l2) ^ 0x28ACA329C216L;
        int[] nArray = aD.b();
        if (nArray != null) {
            if (BaseModule.a.level == null) {
                return;
            }
            this.detectedBlocks.entrySet().removeIf(arg_0 -> this.lambda$validateDetectedBlocks$3(l3, arg_0));
        }
    }

    private void scanEntities(Object[] objectArray) {
        Minecraft mc;
        int[] nArray;
        long l2;
        long l3;
        block13: {
            block14: {
                block12: {
                    block11: {
                        l3 = (Long)objectArray[0];
                        l2 = (l3 = bb ^ l3) ^ 0x4312E7C65D4BL;
                        nArray = aD.b();
                        mc = BaseModule.a;
                        if (nArray == null) break block11;
                        if (mc.level == null) break block12;
                        mc = BaseModule.a;
                    }
                    if (nArray == null) break block13;
                    if (mc.player != null) break block14;
                }
                return;
            }
            this.detectedEntities.clear();
            mc = BaseModule.a;
        }
        for (Entity entity : mc.level.entitiesForRendering()) {
            block30: {
                block33: {
                    int[] nArray2;
                    boolean alreadyAlerted;
                    block31: {
                        block32: {
                            Object object;
                            block29: {
                                o entityType;
                                block18: {
                                    boolean matched;
                                    block28: {
                                        int[] nArray3;
                                        block27: {
                                            block25: {
                                                block26: {
                                                    int[] nArray4;
                                                    block24: {
                                                        block22: {
                                                            block23: {
                                                                int[] nArray5;
                                                                block21: {
                                                                    block19: {
                                                                        block20: {
                                                                            int[] nArray6;
                                                                            block17: {
                                                                                block15: {
                                                                                    block16: {
                                                                                        double distance;
                                                                                    if (entity == BaseModule.a.player || (distance = (double)BaseModule.a.player.distanceTo(entity)) > 100.0) continue;
                                                                                        entityType = null;
                                                                                        matched = (Boolean)this.detectVillagers.a();
                                                                                        if (nArray == null) break block15;
                                                                                        if (!matched) break block16;
                                                                                        matched = entity instanceof Villager;
                                                                                        nArray6 = nArray;
                                                                                        if (l3 <= 0L) break block17;
                                                                                        if (nArray6 == null) break block15;
                                                                                        if (!matched) break block16;
                                                                                        entityType = kuzi.obf.j.g.o.VILLAGER;
                                                                                        break block18;
                                                                                    }
                                                                                    matched = (Boolean)this.detectZombieVillagers.a();
                                                                                }
                                                                                nArray6 = nArray;
                                                                            }
                                                                            if (nArray6 == null) break block19;
                                                                            if (!matched) break block20;
                                                                            matched = entity instanceof ZombieVillager;
                                                                            nArray5 = nArray;
                                                                            if (l3 < 0L) break block21;
                                                                            if (nArray5 == null) break block19;
                                                                            if (!matched) break block20;
                                                                            entityType = kuzi.obf.j.g.o.ZOMBIE_VILLAGER;
                                                                            break block18;
                                                                        }
                                                                        matched = (Boolean)this.detectPillagers.a();
                                                                    }
                                                                    nArray5 = nArray;
                                                                }
                                                                if (nArray5 == null) break block22;
                                                                if (!matched) break block23;
                                                                matched = entity instanceof Pillager;
                                                                nArray4 = nArray;
                                                                if (l3 <= 0L) break block24;
                                                                if (nArray4 == null) break block22;
                                                                if (!matched) break block23;
                                                                entityType = kuzi.obf.j.g.o.PILLAGER;
                                                                break block18;
                                                            }
                                                            matched = (Boolean)this.detectWanderingTraders.a();
                                                        }
                                                        nArray4 = nArray;
                                                    }
                                                    if (nArray4 == null) break block25;
                                                    if (!matched) break block26;
                                                    matched = entity instanceof WanderingTrader;
                                                    nArray3 = nArray;
                                                    if (l3 <= 0L) break block27;
                                                    if (nArray3 == null) break block25;
                                                    if (!matched) break block26;
                                                    entityType = kuzi.obf.j.g.o.WANDERING_TRADER;
                                                    break block18;
                                                }
                                                matched = (Boolean)this.detectLlamas.a();
                                            }
                                            nArray3 = nArray;
                                        }
                                        if (nArray3 == null) break block28;
                                        if (!matched) break block18;
                                        matched = entity instanceof Llama;
                                    }
                                    if (matched) {
                                        entityType = kuzi.obf.j.g.o.LLAMA;
                                    }
                                }
                                object = entityType;
                                if (l3 < 0L || nArray == null) break block29;
                                if (object == null) break block30;
                                this.detectedEntities.put(entity, entityType);
                                object = this.soundAlert.a();
                            }
                            alreadyAlerted = (Boolean)object;
                            nArray2 = nArray;
                            if (l3 < 0L) break block31;
                            if (nArray2 == null) break block32;
                            if (!alreadyAlerted) break block30;
                            alreadyAlerted = this.alertedEntities.contains(entity);
                        }
                        nArray2 = nArray;
                    }
                    if (nArray2 == null) break block33;
                    if (alreadyAlerted) break block30;
                    alreadyAlerted = this.alertedEntities.add(entity);
                }
                Object[] objectArray2 = new Object[1];
                objectArray2[0] = l2;
                this.q(objectArray2);
            }
            if (nArray != null) continue;
        }
    }

    private void q(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = (l2 = bb ^ l2) ^ 0x3C9192727AB4L;
        int[] nArray = aD.b();
        Minecraft mc = BaseModule.a;
        if (nArray != null) {
            if (mc.player == null) {
                return;
            }
            mc = BaseModule.a;
        }
        mc.execute(() -> ExtraESP.lambda$playFoundSound$4(l3));
    }

    private void performCleanup(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = l2 = bb ^ l2;
        long l4 = l3 ^ 0x46BCDF32ADBEL;
        int n2 = (int)(l4 >>> 48);
        int n3 = (int)(l4 << 16 >>> 32);
        int n4 = (int)(l4 << 48 >>> 48);
        long l5 = l3 ^ 0xEF3BEA19E2CL;
        int n5 = (int)(l5 >>> 48);
        int n6 = (int)(l5 << 16 >>> 32);
        int n7 = (int)(l5 << 48 >>> 48);
        long l6 = l3 ^ 0x1935CAC41B63L;
        long l7 = l3 ^ 0x5C7F527DE032L;
        int[] nArray = aD.b();
        Object object = BaseModule.a.player;
        if (nArray != null) {
            if (object == null) {
                return;
            }
            object = BaseModule.a.options.renderDistance().get();
        }
        int renderDistance = (Integer)object;
        int playerChunkX = BaseModule.a.player.chunkPosition().x;
        int playerChunkZ = BaseModule.a.player.chunkPosition().z;
        this.detectedBlocks.keySet().removeIf(arg_0 -> ExtraESP.lambda$performCleanup$5((char)n5, n6, playerChunkX, (short)n7, playerChunkZ, renderDistance, arg_0));
        this.R.removeIf(arg_0 -> ExtraESP.lambda$performCleanup$6(playerChunkX, (short)n2, n3, (char)n4, playerChunkZ, renderDistance, arg_0));
        this.S.removeIf(arg_0 -> ExtraESP.lambda$performCleanup$7(l7, playerChunkX, playerChunkZ, renderDistance, arg_0));
        this.alertedEntities.removeIf(arg_0 -> ExtraESP.lambda$performCleanup$8(l6, arg_0));
    }

    public Map a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = bb ^ l2;
        return this.detectedBlocks;
    }

    public Map b(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = bb ^ l2;
        return this.detectedEntities;
    }

    public boolean h(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = bb ^ l2;
        return (Boolean)this.tracers.a();
    }

    public String c(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = bb ^ l2;
        return String.valueOf(ExtraESP.f("\u00c0", (Object)this, (long)-419570237432054397L, (long)l2).size() + ExtraESP.f("\u00c0", (Object)this, (long)-417386389379505503L, (long)l2).size());
    }

    public Color a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        n n2 = (n)((Object)objectArray[1]);
        l2 = bb ^ l2;
        return switch (n2.ordinal()) {
            default -> throw new MatchException(null, null);
            case 0 -> this.vineColor.a();
            case 1 -> this.kelpColor.a();
            case 2 -> this.deepslateColor.a();
            case 3 -> this.rotatedDeepslateColor.a();
            case 4 -> this.amethystColor.a();
            case 5 -> this.hole1x1Color.a();
        };
    }

    public Color b(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        o o2 = (o)((Object)objectArray[1]);
        l2 = bb ^ l2;
        return switch (o2.ordinal()) {
            default -> throw new MatchException(null, null);
            case 0 -> this.villagerColor.a();
            case 1 -> this.zombieVillagerColor.a();
            case 2 -> this.pillagerColor.a();
            case 4 -> this.llamaColor.a();
            case 3 -> this.wanderingTraderColor.a();
        };
    }

    private static boolean lambda$performCleanup$8(long l2, Entity entity) {
        double inRange;
        block10: {
            block11: {
                CallSite callSite;
                block9: {
                    boolean alive;
                    block8: {
                        block7: {
                            Entity checkedEntity;
                            block6: {
                                l2 = bb ^ l2;
                                callSite = ExtraESP.f("\u00f9", (long)-8809131804065457163L, (long)l2);
                                try {
                                    checkedEntity = entity;
                                    if (callSite == null) break block6;
                                    if (checkedEntity == null) break block7;
                                }
                                catch (MatchException matchException) {
                                    throw ExtraESP.f("\u00f9", (Object)matchException, (long)-8809751742783254051L, (long)l2);
                                }
                                checkedEntity = entity;
                            }
                            try {
                                alive = checkedEntity.isAlive();
                                if (callSite == null) break block8;
                                if (alive) break block9;
                            }
                            catch (MatchException matchException) {
                                throw ExtraESP.f("\u00f9", (Object)matchException, (long)-8809751742783254051L, (long)l2);
                            }
                        }
                        alive = true;
                    }
                    return alive;
                }
                double distance = ((Minecraft)ExtraESP.f("\u00dd", (long)-8812680343949747345L, (long)l2)).player.distanceTo(entity);
                try {
                    double distanceLimitDiff = distance - 100.0;
                    inRange = distanceLimitDiff == 0.0 ? 0 : (distanceLimitDiff > 0.0 ? 1 : -1);
                    if (callSite == null) break block10;
                    if (inRange <= 0) break block11;
                }
                catch (MatchException matchException) {
                    throw ExtraESP.f("\u00f9", (Object)matchException, (long)-8809751742783254051L, (long)l2);
                }
                inRange = 1.0;
                break block10;
            }
            inRange = 0.0;
        }
        return (boolean)inRange;
    }

    private static boolean lambda$performCleanup$7(long l2, int playerChunkX, int playerChunkZ, int renderDistance, ChunkPos chunkPos) {
        int outOfRange;
        block8: {
            block10: {
                l2 = bb ^ l2;
                int dx = Math.abs(chunkPos.x - playerChunkX);
                CallSite callSite = ExtraESP.f("\u00f9", (long)9146503008382410916L, (long)l2);
                int dz = Math.abs(chunkPos.z - playerChunkZ);
                try {
                    block9: {
                        try {
                            try {
                                try {
                                    outOfRange = dx;
                                    if (callSite == null) break block8;
                                    if (outOfRange > renderDistance + 2) break block9;
                                }
                                catch (MatchException matchException) {
                                    throw ExtraESP.f("\u00f9", (Object)matchException, (long)9145751179542620812L, (long)l2);
                                }
                                outOfRange = dz;
                                if (callSite == null) break block8;
                            }
                            catch (MatchException matchException) {
                                throw ExtraESP.f("\u00f9", (Object)matchException, (long)9145751179542620812L, (long)l2);
                            }
                            if (outOfRange <= renderDistance + 2) break block10;
                        }
                        catch (MatchException matchException) {
                            throw ExtraESP.f("\u00f9", (Object)matchException, (long)9145751179542620812L, (long)l2);
                        }
                    }
                    outOfRange = 1;
                    break block8;
                }
                catch (MatchException matchException) {
                    throw ExtraESP.f("\u00f9", (Object)matchException, (long)9145751179542620812L, (long)l2);
                }
            }
            outOfRange = 0;
        }
        return outOfRange != 0;
    }

    private static boolean lambda$performCleanup$6(int playerChunkX, short keyA, int keyB, char keyC, int playerChunkZ, int renderDistance, ChunkPos chunkPos) {
        int outOfRange;
        block8: {
            block10: {
                long l2 = ((long)keyA << 48 | (long)keyB << 32 >>> 16 | (long)keyC << 48 >>> 48) ^ bb;
                int dx = Math.abs(chunkPos.x - playerChunkX);
                CallSite callSite = ExtraESP.f("\u00f9", (long)3702788771891359016L, (long)l2);
                int dz = Math.abs(chunkPos.z - playerChunkZ);
                try {
                    block9: {
                        try {
                            try {
                                try {
                                    outOfRange = dx;
                                    if (callSite == null) break block8;
                                    if (outOfRange > renderDistance + 2) break block9;
                                }
                                catch (MatchException matchException) {
                                    throw ExtraESP.f("\u00f9", (Object)matchException, (long)3702001767571007232L, (long)l2);
                                }
                                outOfRange = dz;
                                if (callSite == null) break block8;
                            }
                            catch (MatchException matchException) {
                                throw ExtraESP.f("\u00f9", (Object)matchException, (long)3702001767571007232L, (long)l2);
                            }
                            if (outOfRange <= renderDistance + 2) break block10;
                        }
                        catch (MatchException matchException) {
                            throw ExtraESP.f("\u00f9", (Object)matchException, (long)3702001767571007232L, (long)l2);
                        }
                    }
                    outOfRange = 1;
                    break block8;
                }
                catch (MatchException matchException) {
                    throw ExtraESP.f("\u00f9", (Object)matchException, (long)3702001767571007232L, (long)l2);
                }
            }
            outOfRange = 0;
        }
        return outOfRange != 0;
    }

    private static boolean lambda$performCleanup$5(char keyA, int keyB, int playerChunkX, short keyC, int playerChunkZ, int renderDistance, BlockPos pos) {
        int outOfRange;
        block8: {
            block10: {
                long l2 = ((long)keyA << 48 | (long)keyB << 32 >>> 16 | (long)keyC << 48 >>> 48) ^ bb;
                int blockChunkX = pos.getX() >> 4;
                CallSite callSite = ExtraESP.f("\u00f9", (long)67759098215571130L, (long)l2);
                int blockChunkZ = pos.getZ() >> 4;
                int dx = Math.abs(blockChunkX - playerChunkX);
                int dz = Math.abs(blockChunkZ - playerChunkZ);
                try {
                    block9: {
                        try {
                            try {
                                try {
                                    outOfRange = dx;
                                    if (callSite == null) break block8;
                                    if (outOfRange > renderDistance + 3) break block9;
                                }
                                catch (MatchException matchException) {
                                    throw ExtraESP.f("\u00f9", (Object)matchException, (long)68238651798262930L, (long)l2);
                                }
                                outOfRange = dz;
                                if (callSite == null) break block8;
                            }
                            catch (MatchException matchException) {
                                throw ExtraESP.f("\u00f9", (Object)matchException, (long)68238651798262930L, (long)l2);
                            }
                            if (outOfRange <= renderDistance + 3) break block10;
                        }
                        catch (MatchException matchException) {
                            throw ExtraESP.f("\u00f9", (Object)matchException, (long)68238651798262930L, (long)l2);
                        }
                    }
                    outOfRange = 1;
                    break block8;
                }
                catch (MatchException matchException) {
                    throw ExtraESP.f("\u00f9", (Object)matchException, (long)68238651798262930L, (long)l2);
                }
            }
            outOfRange = 0;
        }
        return outOfRange != 0;
    }

    private static void lambda$playFoundSound$4(long l2) {
        l2 = bb ^ l2;
        ExtraESP.f("\u00dd", (long)5748109305778802969L, (long)l2).getSoundManager().play((SoundInstance)SimpleSoundInstance.forUI((SoundEvent)SoundEvents.EXPERIENCE_ORB_PICKUP, (float)1.0f));
    }

    private boolean lambda$validateDetectedBlocks$3(long l2, Map.Entry entry) {
        long l3 = (l2 = bb ^ l2) ^ 0x483614F0BA4CL;
        BlockPos pos = (BlockPos)entry.getKey();
        n blockType = (n)((Object)entry.getValue());
        try {
            boolean stillMatches;
            BlockState blockState = ((Minecraft)ExtraESP.f("\u00dd", (long)7315929188133583707L, (long)l2)).level.getBlockState(pos);
            Object[] objectArray = new Object[4];
            objectArray[3] = l3;
            objectArray[2] = null;
            objectArray[1] = blockState;
            objectArray[0] = pos;
            CallSite callSite = ExtraESP.f("\u00e0", (Object)this, (Object)objectArray, (long)7321418952113913183L, (long)l2);
            try {
                stillMatches = callSite != blockType;
            }
            catch (Exception exception) {
                throw ExtraESP.f("\u00f9", (Object)exception, (long)7316394779344204265L, (long)l2);
            }
            return stillMatches;
        }
        catch (Exception exception) {
            return true;
        }
    }

    private void lambda$scheduleChunkScan$2(LevelChunk chunk, char chunkX, short chunkZ, int flags) {
        long l2;
        long l3 = l2 = ((long)chunkX << 48 | (long)chunkZ << 48 >>> 16 | (long)flags << 32 >>> 32) ^ bb;
        long l4 = l3 ^ 0x1FB639A434C3L;
        long l5 = l3 ^ 0x504DA7691788L;
        try {
            Object[] objectArray = new Object[1];
            objectArray[0] = l5;
            Thread.sleep((long)(ExtraESP.f("\u00e0", (Object)((Object)((p)((Object)ExtraESP.f("\u00e0", (Object)ExtraESP.f("\u00c0", (Object)this, (long)-3914158848488343873L, (long)l2), (long)-3917792380763403241L, (long)l2)))), (Object)objectArray, (long)-3913860350889238233L, (long)l2) / ExtraESP.d("y", (int)31354, (long)(0x219A2695F8A61C19L ^ l2))));
            Object[] objectArray2 = new Object[2];
            objectArray2[1] = l4;
            objectArray2[0] = chunk;
            ExtraESP.f("\u00e0", (Object)this, (Object)objectArray2, (long)-3917291868303256634L, (long)l2);
        }
        catch (InterruptedException interruptedException) {
            Thread.currentThread().interrupt();
        }
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private void lambda$startInitialScan$1(long var1_1) {
        block22: {
            v0 = var1_1 = ExtraESP.bb ^ var1_1;
            var3_2 = v0 ^ 81466006642917L;
            var5_3 = v0 ^ 59107283669263L;
            var7_4 = v0 ^ 134391177720388L;
            var9_5 = ExtraESP.f("\u00f9", (long)7809980138775245352L, (long)var1_1);
            try {
                block21: {
                    block20: {
                        block27: {
                            v1 = ExtraESP.f("\u00dd", (long)7813221065057252018L, (long)var1_1);
                            if (var9_5 == null) break block27;
                            try {
                                block28: {
                                    if (v1.level == null) break block20;
                                    break block28;
                                    catch (InterruptedException v2) {
                                        throw ExtraESP.f("\u00f9", (Object)v2, (long)7809324998541080576L, (long)var1_1);
                                    }
                                }
                                v1 = ExtraESP.f("\u00dd", (long)7813221065057252018L, (long)var1_1);
                            }
                            catch (InterruptedException v3) {
                                throw ExtraESP.f("\u00f9", (Object)v3, (long)7809324998541080576L, (long)var1_1);
                            }
                        }
                        if (v1.player != null) break block21;
                    }
                    return;
                }
                v4 = new Object[1];
                v4[0] = var3_2;
                var10_6 = ExtraESP.f("\u00e0", (Object)this, (Object)v4, (long)7808501152335075003L, (long)var1_1);
                var11_8 = var10_6.iterator();
                while (var11_8.hasNext()) {
                    block25: {
                        block26: {
                            block24: {
                                block23: {
                                    var12_9 = (LevelChunk)var11_8.next();
                                    if (var9_5 == null) break block22;
                                    try {
                                        if (ExtraESP.f("\u00c0", (Object)this, (long)7809912203444317050L, (long)var1_1) == false) {
                                            break;
                                        }
                                        break block23;
                                        catch (InterruptedException v5) {
                                            throw ExtraESP.f("\u00f9", (Object)v5, (long)7809324998541080576L, (long)var1_1);
                                        }
                                    }
                                    catch (InterruptedException v6) {
                                        throw ExtraESP.f("\u00f9", (Object)v6, (long)7809324998541080576L, (long)var1_1);
                                    }
                                }
                                try {
                                    v7 /* !! */  = var12_9;
                                    v8 = var9_5;
                                    if (var1_1 >= 0L) {
                                        if (v8 == null) break block24;
                                        if (v7 /* !! */  == null) break block25;
                                    }
                                    ** GOTO lbl58
                                }
                                catch (InterruptedException v9) {
                                    throw ExtraESP.f("\u00f9", (Object)v9, (long)7809324998541080576L, (long)var1_1);
                                }
                                v7 /* !! */  = var12_9;
                            }
                            v8 = var9_5;
lbl58:
                            // 2 sources

                            if (v8 == null) break block26;
                            try {
                                block29: {
                                    if (v7 /* !! */ .isEmpty()) break block25;
                                    break block29;
                                    catch (InterruptedException v10) {
                                        throw ExtraESP.f("\u00f9", (Object)v10, (long)7809324998541080576L, (long)var1_1);
                                    }
                                }
                                v11 = new Object[2];
                                v11[1] = var5_3;
                                v11[0] = var12_9;
                                ExtraESP.f("\u00e0", (Object)this, (Object)v11, (long)7813413005315782154L, (long)var1_1);
                                v7 /* !! */  = ExtraESP.f("\u00e0", (Object)ExtraESP.f("\u00c0", (Object)this, (long)7809865401170908019L, (long)var1_1), (long)7812934882654169563L, (long)var1_1);
                            }
                            catch (InterruptedException v12) {
                                throw ExtraESP.f("\u00f9", (Object)v12, (long)7809324998541080576L, (long)var1_1);
                            }
                        }
                        v13 = new Object[1];
                        v13[0] = var7_4;
                        Thread.sleep((long)ExtraESP.f("\u00e0", (Object)((p)v7 /* !! */ ), (Object)v13, (long)7810093637299291371L, (long)var1_1));
                    }
                    if (var9_5 != null) continue;
                }
                if (var1_1 > 0L) {
                    // empty if block
                }
            }
            catch (InterruptedException var10_7) {
                Thread.currentThread().interrupt();
            }
        }
    }

    private static Thread lambda$startScanner$0(long l2, Runnable runnable) {
        l2 = bb ^ l2;
        Thread thread = new Thread(runnable, (String)((Object)ExtraESP.b("o", (int)28441, (long)(0x1F7A39470CF505BCL ^ l2))));
        thread.setDaemon(true);
        thread.setPriority(4);
        return thread;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block31: {
            block30: {
                block29: {
                    block28: {
                        block27: {
                            block26: {
                                ExtraESP.bb = kuzi.obf.h.b.v.a(4301180538569121573L, -2428068633464824553L, MethodHandles.lookup().lookupClass()).a(20092731741731L);
                                ExtraESP.pb = new Object[135];
                                ExtraESP.sb = new String[135];
                                ExtraESP.c();
                                ExtraESP.ib = new HashMap<K, V>(13);
                                var22 = ExtraESP.bb ^ 65730784094695L;
                                var24_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                                v0 = SecretKeyFactory.getInstance("DES");
                                v1 = new byte[8];
                                v2 = v1;
                                v1[0] = (byte)(var22 >>> 56);
                                for (var25_2 = 1; var25_2 < 8; ++var25_2) {
                                    v2 = v2;
                                    v2[var25_2] = (byte)(var22 << var25_2 * 8 >>> 56);
                                }
                                var24_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                                var31_3 = new String[28];
                                var29_4 = 0;
                                var28_5 = "\u0097l\u00b7=\u0088l7\u00f5r\u0000\u0090\u0095 8\u00adI Ue'\u0083\u00eaR\\\u00d7\u0081M\u00fe7\u00ab\u00a9\n\u00a6\u00bb9\u0086\u00d8\r\u00b5\u00d0\u00df\u00b6\u001fHj%\u00fav\u0014(\u00f8\u00c8\f\u00de[\u0003\u0090\u00e4\u0005U\u009b\u00fa\u00b4\u00af\u00ab\r\u0003\u00bf $5\u00cfDT\u00dc\u00b5#d\u0014hje\u0083\u00e1\u00ea\u0096\b\u00df\u00c8\u00ed \u00ab\u00af\u00b59\u00add\u00ba\u00d6\u001b\u00da\u00e0f\u00cc\u000fziwv\u00b9\u00f3W\u009bXx\u0005\u0019\u0089\u0082h\u00d7\u007f\u00cd \u00d8\u00cb\u001d}\u00e2\u00fb}\u00ac\u00e9\u00c2\u00e9\u00a86\u00cb\u00b1\u00f9\u00d8\u0001+\u00cb\u00c5\u0085`\u00fc\u00e0GW\u00dd\u0003\u0099C_\u0018\u00c9\u0094f\u00e4\u00b2C\u00b4\u00d8\u00c8E\u001b\u00cd\u00c3\u00e3OO\u00d4\u00d8H\u008cE_\u00c3q\u0018\u00b6\u0091+\u00a8 D\u000b\u0016\u0090\u00e8\u00a1\tU\u0002Bd\u00ac\u00d97\u00b2,o\u00b1=0\u008an\u00b1\u00df\u0083\u0005%/cem\u00cb\u0019\u00bc\u00fd&\u008d}\u00ef\u0005:2I\u00c8\u0083r\u00f6t\u00e3\u008a\u000b\u00cbQ\u00e9\u00c4d\t\u0019\u00dd\u00b3g\u00fd\u0015P\u00b6\u0018\u008b\u00ec \u0014\u00b9\u0011\u00bfD\u009bf\u00a4\u00f9\u00e4r\u0006mW\u0091+Ub\u0000F6\u00c4\u0099\u00b3\f\u008e\u00e0\u00ab\u009f\u00eb\u00d7\u00f4\u0018\u00e8\u00c8v\u00b3\u009dr\"\u00aah\u00db\u00ca\u00ef\u00d76\u0092\u00d5\u009b\u00ba\u00ab{\u00b5\u00edk\u00858\u00fc-\u0004\u000b=\"\"\u0007t\u00c3Z\u00cb\u0004@\u00b2\u00af4\u00e2\u0099\u00b0\u00e0\u00b5\u00ee\u000f\fB\u00c6^\u00c1\u00be\u00f3\u0012\u00b4\u00d7X/\u0013.\u00f3+G\u0098\u00e54\u00a0\u00e4\u0002)H\u00a5\u0004a\u00d8U?^@n\u00c4\u00b4\u00a6\u00d1>!\u00e5\u0006\u0003\u0003\u00f8}\u00f4\u00c7G\r\u0099H\u00fd\u00bb\u00ff\u00a5D\u0098\u00a01\u0085/\u0018\u0085\u0010\u001f]V9\u008d\u00de\u00db=\u0090\u00eah\u00a7\u00ba\u00ce`\u00ea\u00c9\u00bb\u00c4\u0017\u00e9\u00d4\u00ae/\u00ef\u00f1U*k\u009eb\u00c9\u0018\u0003>\u00dd\u00abX\u00fb\u0088\u00f0\u00b74ztl\u00c7t5\u00d5Rk\u00e4Y?!F \u00df\u00d3\u00d0(7\u00f5\u00df\u00acB/M\t\u00e6\u001c\u00f4,\u0005\u0018\u0002J\u0080\u0085\u00176\u00fa\u00b4m^`\u00a3\u00f4\u00bd\u00185bJ\r>\u0085h*/\fZ\u00f4\u00a4\u00ab=LzB2\u009fQ\u001e\u00d5|\u0018\u00bb\u00e7\u00cc\u00d4_\u000e\u00b4\u0017MsU_V\u009cK\u00cfSXyk\u00b9\u0003\u00dd\u0010(\u0005\u00f4\u00c80\u001b\u00a0\u00a5\u00c8\u00e2\u00e5\u00b9\\\u00ba\u0001\u0083\u00af\u008e\u0081\u00b7\u008f\u0014\b\u00c8\u0018\u0006\u00e0\u00d5\u00fc\u00b5\u0092\u008e\u0000i\u0007\u00c4Z.\u00d4\u009c\t(\u00a0Q\u0081v}\u00cb\u00f4\u00e5\u0019\u009c}X\u00a2\u0007\u00a2[\u00dc\u00ee\u00c2\u00a8m(=\u009c\u00d76\u0000\u00b5X\u00ae\u00cf\u00c9\u008e\u0097\u00f9\u0084d<\u00ad\u0003\u0018P\u000e\u00ff\u00c6\u00be\"\u0004\u00b6\u00f5I\u00ffC\u001a\u00c8z\u00c4\u0085\u0096f\u00d69\u00a1\u00f1D(#W+\u00ca&c\u00e5\u00b12\u00e46)y\u00b8\u00fdMX\u0019[Xm\u00da'\u00b8\u0018\u00c0\b\u00ce|\t\u00c4[\u001a\u00a3%v^gi\u00f8 \u00c6\u008c\u00a9\u00fe\u00c0\u00e6O\u0095\u00a4\u00a4\u00ce+\u00f5&\u00f5\u00fc\u0000FF@\u00eb&l\u00f4I\u001e\u00959\u00e6\u00a5\u00fc\u00e9 \u0012I{\u00ac7\u0006\u00c3\u0093\u000f\u00f6\u00e6N\u00e2JK\u00d3H\u00a8\u001a\u008e\u0004\u0000\u00b9j\u008c\u0004\u00a4>zG\u00b3\u00be(\u00b2\u0002H\u00cb\u0019\u00fe\u0007d\u0093V`\u00fb)I*\u009aD\u008c\u0083\u00a8\u0099\u00db\u0015 \u00dc*eC=\u00f8\u00a7b\u00cc!}\u0007]\u00dcc\n(\u00abs\u00de\u00e3\u0006\u00b0\u00ae\u00ccl\u00df\u0084\u00f4\u00b8\u00a8\u009eH\u00e8e\u00e0jE\u009b\u009b\u0083\u00d4\u008a\f\u0015\u00e7,\u00da`O\u00ca\u001c\u00d4\u00b8~\t\u00f2 \u00f1\u00dc\u00d2\u00f9;\u0007>V?\u00ad-\u00f7*\u00f5\u00ef\u001cd\u00fc\u0019OmCCr\u0097'b\u00fa\u00d7Z\u00cdV\u0018\u000eR!\u00e3\u0081FmD\u001e\u00e6\"\u00f8z\u00d7\u00ee\u00f9\u00dc\u00d9\u0081-\u00c4\u00f7\u00c2\u00ad";
                                var30_6 = "\u0097l\u00b7=\u0088l7\u00f5r\u0000\u0090\u0095 8\u00adI Ue'\u0083\u00eaR\\\u00d7\u0081M\u00fe7\u00ab\u00a9\n\u00a6\u00bb9\u0086\u00d8\r\u00b5\u00d0\u00df\u00b6\u001fHj%\u00fav\u0014(\u00f8\u00c8\f\u00de[\u0003\u0090\u00e4\u0005U\u009b\u00fa\u00b4\u00af\u00ab\r\u0003\u00bf $5\u00cfDT\u00dc\u00b5#d\u0014hje\u0083\u00e1\u00ea\u0096\b\u00df\u00c8\u00ed \u00ab\u00af\u00b59\u00add\u00ba\u00d6\u001b\u00da\u00e0f\u00cc\u000fziwv\u00b9\u00f3W\u009bXx\u0005\u0019\u0089\u0082h\u00d7\u007f\u00cd \u00d8\u00cb\u001d}\u00e2\u00fb}\u00ac\u00e9\u00c2\u00e9\u00a86\u00cb\u00b1\u00f9\u00d8\u0001+\u00cb\u00c5\u0085`\u00fc\u00e0GW\u00dd\u0003\u0099C_\u0018\u00c9\u0094f\u00e4\u00b2C\u00b4\u00d8\u00c8E\u001b\u00cd\u00c3\u00e3OO\u00d4\u00d8H\u008cE_\u00c3q\u0018\u00b6\u0091+\u00a8 D\u000b\u0016\u0090\u00e8\u00a1\tU\u0002Bd\u00ac\u00d97\u00b2,o\u00b1=0\u008an\u00b1\u00df\u0083\u0005%/cem\u00cb\u0019\u00bc\u00fd&\u008d}\u00ef\u0005:2I\u00c8\u0083r\u00f6t\u00e3\u008a\u000b\u00cbQ\u00e9\u00c4d\t\u0019\u00dd\u00b3g\u00fd\u0015P\u00b6\u0018\u008b\u00ec \u0014\u00b9\u0011\u00bfD\u009bf\u00a4\u00f9\u00e4r\u0006mW\u0091+Ub\u0000F6\u00c4\u0099\u00b3\f\u008e\u00e0\u00ab\u009f\u00eb\u00d7\u00f4\u0018\u00e8\u00c8v\u00b3\u009dr\"\u00aah\u00db\u00ca\u00ef\u00d76\u0092\u00d5\u009b\u00ba\u00ab{\u00b5\u00edk\u00858\u00fc-\u0004\u000b=\"\"\u0007t\u00c3Z\u00cb\u0004@\u00b2\u00af4\u00e2\u0099\u00b0\u00e0\u00b5\u00ee\u000f\fB\u00c6^\u00c1\u00be\u00f3\u0012\u00b4\u00d7X/\u0013.\u00f3+G\u0098\u00e54\u00a0\u00e4\u0002)H\u00a5\u0004a\u00d8U?^@n\u00c4\u00b4\u00a6\u00d1>!\u00e5\u0006\u0003\u0003\u00f8}\u00f4\u00c7G\r\u0099H\u00fd\u00bb\u00ff\u00a5D\u0098\u00a01\u0085/\u0018\u0085\u0010\u001f]V9\u008d\u00de\u00db=\u0090\u00eah\u00a7\u00ba\u00ce`\u00ea\u00c9\u00bb\u00c4\u0017\u00e9\u00d4\u00ae/\u00ef\u00f1U*k\u009eb\u00c9\u0018\u0003>\u00dd\u00abX\u00fb\u0088\u00f0\u00b74ztl\u00c7t5\u00d5Rk\u00e4Y?!F \u00df\u00d3\u00d0(7\u00f5\u00df\u00acB/M\t\u00e6\u001c\u00f4,\u0005\u0018\u0002J\u0080\u0085\u00176\u00fa\u00b4m^`\u00a3\u00f4\u00bd\u00185bJ\r>\u0085h*/\fZ\u00f4\u00a4\u00ab=LzB2\u009fQ\u001e\u00d5|\u0018\u00bb\u00e7\u00cc\u00d4_\u000e\u00b4\u0017MsU_V\u009cK\u00cfSXyk\u00b9\u0003\u00dd\u0010(\u0005\u00f4\u00c80\u001b\u00a0\u00a5\u00c8\u00e2\u00e5\u00b9\\\u00ba\u0001\u0083\u00af\u008e\u0081\u00b7\u008f\u0014\b\u00c8\u0018\u0006\u00e0\u00d5\u00fc\u00b5\u0092\u008e\u0000i\u0007\u00c4Z.\u00d4\u009c\t(\u00a0Q\u0081v}\u00cb\u00f4\u00e5\u0019\u009c}X\u00a2\u0007\u00a2[\u00dc\u00ee\u00c2\u00a8m(=\u009c\u00d76\u0000\u00b5X\u00ae\u00cf\u00c9\u008e\u0097\u00f9\u0084d<\u00ad\u0003\u0018P\u000e\u00ff\u00c6\u00be\"\u0004\u00b6\u00f5I\u00ffC\u001a\u00c8z\u00c4\u0085\u0096f\u00d69\u00a1\u00f1D(#W+\u00ca&c\u00e5\u00b12\u00e46)y\u00b8\u00fdMX\u0019[Xm\u00da'\u00b8\u0018\u00c0\b\u00ce|\t\u00c4[\u001a\u00a3%v^gi\u00f8 \u00c6\u008c\u00a9\u00fe\u00c0\u00e6O\u0095\u00a4\u00a4\u00ce+\u00f5&\u00f5\u00fc\u0000FF@\u00eb&l\u00f4I\u001e\u00959\u00e6\u00a5\u00fc\u00e9 \u0012I{\u00ac7\u0006\u00c3\u0093\u000f\u00f6\u00e6N\u00e2JK\u00d3H\u00a8\u001a\u008e\u0004\u0000\u00b9j\u008c\u0004\u00a4>zG\u00b3\u00be(\u00b2\u0002H\u00cb\u0019\u00fe\u0007d\u0093V`\u00fb)I*\u009aD\u008c\u0083\u00a8\u0099\u00db\u0015 \u00dc*eC=\u00f8\u00a7b\u00cc!}\u0007]\u00dcc\n(\u00abs\u00de\u00e3\u0006\u00b0\u00ae\u00ccl\u00df\u0084\u00f4\u00b8\u00a8\u009eH\u00e8e\u00e0jE\u009b\u009b\u0083\u00d4\u008a\f\u0015\u00e7,\u00da`O\u00ca\u001c\u00d4\u00b8~\t\u00f2 \u00f1\u00dc\u00d2\u00f9;\u0007>V?\u00ad-\u00f7*\u00f5\u00ef\u001cd\u00fc\u0019OmCCr\u0097'b\u00fa\u00d7Z\u00cdV\u0018\u000eR!\u00e3\u0081FmD\u001e\u00e6\"\u00f8z\u00d7\u00ee\u00f9\u00dc\u00d9\u0081-\u00c4\u00f7\u00c2\u00ad".length();
                                var27_7 = 16;
                                var26_8 = -1;
lbl23:
                                // 2 sources

                                while (true) {
                                    v3 = ++var26_8;
                                    v4 = var28_5.substring(v3, v3 + var27_7);
                                    v5 = -1;
                                    break block26;
                                    break;
                                }
lbl28:
                                // 1 sources

                                while (true) {
                                    var31_3[var29_4++] = ExtraESP.b(var32_9).intern();
                                    if ((var26_8 += var27_7) < var30_6) {
                                        var27_7 = var28_5.charAt(var26_8);
                                        ** continue;
                                    }
                                    var28_5 = "e\u001f\u00f1\u0084\u0093{\u00c3\u0093\u00bc\u00af\u0086\u00f3\u00c1\u00b3\u0091%\n\u00ff\u00b4\u00bd\u00c9W\u0011\u001e(mL\u008b\u0012w7\u001b\u0002\u00ee\u00b9\u0011}\u00fa\u009f\u00db\u00b9\u00d63\u001c\u00d1\u00d4t\u00c0X2-\u009b\u00aaP\u00ccx,\u00113\u00a4b\u0003Q\u00e4j";
                                    var30_6 = "e\u001f\u00f1\u0084\u0093{\u00c3\u0093\u00bc\u00af\u0086\u00f3\u00c1\u00b3\u0091%\n\u00ff\u00b4\u00bd\u00c9W\u0011\u001e(mL\u008b\u0012w7\u001b\u0002\u00ee\u00b9\u0011}\u00fa\u009f\u00db\u00b9\u00d63\u001c\u00d1\u00d4t\u00c0X2-\u009b\u00aaP\u00ccx,\u00113\u00a4b\u0003Q\u00e4j".length();
                                    var27_7 = 24;
                                    var26_8 = -1;
lbl37:
                                    // 2 sources

                                    while (true) {
                                        v6 = ++var26_8;
                                        v4 = var28_5.substring(v6, v6 + var27_7);
                                        v5 = 0;
                                        break block26;
                                        break;
                                    }
                                    break;
                                }
lbl42:
                                // 1 sources

                                while (true) {
                                    var31_3[var29_4++] = ExtraESP.b(var32_9).intern();
                                    if ((var26_8 += var27_7) < var30_6) {
                                        var27_7 = var28_5.charAt(var26_8);
                                        ** continue;
                                    }
                                    break block27;
                                    break;
                                }
                            }
                            var32_9 = var24_1.doFinal(v4.getBytes("ISO-8859-1"));
                            switch (v5) {
                                default: {
                                    ** continue;
                                }
                                ** case 0:
lbl54:
                                // 1 sources

                                ** continue;
                            }
                        }
                        ExtraESP.db = var31_3;
                        ExtraESP.hb = new String[28];
                        ExtraESP.lb = new HashMap<K, V>(13);
                        var11_10 = Cipher.getInstance("DES/CBC/NoPadding");
                        v7 = SecretKeyFactory.getInstance("DES");
                        v8 = new byte[8];
                        v9 = v8;
                        v8[0] = (byte)(var22 >>> 56);
                        for (var12_11 = 1; var12_11 < 8; ++var12_11) {
                            v9 = v9;
                            v9[var12_11] = (byte)(var22 << var12_11 * 8 >>> 56);
                        }
                        var11_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                        var17_12 = new long[63];
                        var14_13 = 0;
                        var15_14 = "Y\u007fE\u0014\u009e\u00a1\u00d5n^6\u00f8\u000f8\u00adS!z\u0092\u001f\u00e9\u001e\u00d2\u000e\u00cf~\u00a3\u00ea$\u00d4Zwt\u0012\u000b( \u0013\u00fa\u00b9F\u00a2w\r\u008b&\u00f4w\u008c\u00af*\np\u0010\u00de\u00983Q\u00dd\u00a3\u001a\u001b\u00f2\u0003\u00ad\u00f7W\u0000\u00e3\u00ad\u00f7.\u0016\u00146\n\u0092\u009f*\u0015:\u00d2\u00beh\u00cf\u00c1UE\u00f7\u0096\u00d1\u00ca\u0002\u00edey\u0005\u00cd\u00026\u00db{\u00c2\u00f5\u0085I\tp\u008c\u009b\u0092\u007f\u00bc\u00c8>\u0099\u0096&I\u0084%\u00f6\u0092\u00b5Wr\u00ednh\n\u001aB\u0081\u00a8\u009cx\u00e5SS[)V\bj\u0000\u001a(+r\u00dcO\u00cbk\u009b}\u00ee\u0092\"\u00edJ\u00df\u00f5T/\u0003\u0099\u0007\u009b\u009c\u00c4\u00f5t\"\u00b3\u0088M'3\u00a8\u00bc\u00e5K{n\u00b1\u00f48K\u00d5\u00c4\u00bc\u00ed,\u0004,\u0011%\u00da\u00f5G%\u00f3S\u0007n\u009f\u00ef\u00d3\u0095D\u00f2\u00b6\u00a0@E\u00b1x\u00d3\bmB\u00b1NE\\\"\u0002\u00e4\u0087\u00c8\u00b9\u0001\u00ffs\u00e6\u00a4>G\t\u00a8\u00fd1p\u00ef9\u00e2\u00ed\u00b7*\u0099\u0088\u0082Zy\u00ee\u00ae\u0006\u0097s\u00f2\u00d9\u00d9\\\u00b3I>Mxy\u00ea\u00a4\u0084\u00ce}1\b\u00d7\u001a\u0006m~\u00df\u0091\u009cb-Ij\u001c\u00d2\u00d3\u00a4\u00c4v\u00d8\u009b%\u00d5\u00f0'\u0096\u00b8\u00bb7#\u00b1\u00c3q\u008c\u0003\u00e2j\u0001\u001e\u000eK1\u00cd\u00b9#zmU3NJ\u00cf\u00c6\u00e4\u00de@\u00e1s\u00ff\u00cf\u0000|\u00aaw{sS\u001c1q\u0090\u00af\u00f8\u00c1\u00b5v=\u0014KI\u0015\u008b\u00cc#\u00c9\u007f\u00aaX\u00b6V\u00ac}\u000f9P\u00f7[ZqH\u00a9>\u00a2\u00d5Q\u00fe\u00e8\u0017\t`!%\u00f9\u00e0>P(\u009d\u00d8y@$\u00f3N\u00f4<?\u0083+\u00c7\u00ac\u00db5\u00b7\u001dK%\u0081\u00f8\u00dc\u009c\u00dd\u00ff\u0006@\u008bF`\u0080\u0084\u00b1/\u000e\u00f4\u0000`\u0015F\u00db\u00cf\u001c\u000e\u00b5\u0080N\u00b4z\u00fa\u00ddv%\u00b9\f\u00c3a$F\u00d5\u0091\u0014\u00e9\u00f1a8\u00e1\u0012m\u001d o\u00ea\u00c2\u00c4\u00b2\u0081\u00b7\u00d5m\u0005Q3\u00edl7b\u00e59\u00bf-\u00f8\u0083W\u00f3+";
                        var16_15 = "Y\u007fE\u0014\u009e\u00a1\u00d5n^6\u00f8\u000f8\u00adS!z\u0092\u001f\u00e9\u001e\u00d2\u000e\u00cf~\u00a3\u00ea$\u00d4Zwt\u0012\u000b( \u0013\u00fa\u00b9F\u00a2w\r\u008b&\u00f4w\u008c\u00af*\np\u0010\u00de\u00983Q\u00dd\u00a3\u001a\u001b\u00f2\u0003\u00ad\u00f7W\u0000\u00e3\u00ad\u00f7.\u0016\u00146\n\u0092\u009f*\u0015:\u00d2\u00beh\u00cf\u00c1UE\u00f7\u0096\u00d1\u00ca\u0002\u00edey\u0005\u00cd\u00026\u00db{\u00c2\u00f5\u0085I\tp\u008c\u009b\u0092\u007f\u00bc\u00c8>\u0099\u0096&I\u0084%\u00f6\u0092\u00b5Wr\u00ednh\n\u001aB\u0081\u00a8\u009cx\u00e5SS[)V\bj\u0000\u001a(+r\u00dcO\u00cbk\u009b}\u00ee\u0092\"\u00edJ\u00df\u00f5T/\u0003\u0099\u0007\u009b\u009c\u00c4\u00f5t\"\u00b3\u0088M'3\u00a8\u00bc\u00e5K{n\u00b1\u00f48K\u00d5\u00c4\u00bc\u00ed,\u0004,\u0011%\u00da\u00f5G%\u00f3S\u0007n\u009f\u00ef\u00d3\u0095D\u00f2\u00b6\u00a0@E\u00b1x\u00d3\bmB\u00b1NE\\\"\u0002\u00e4\u0087\u00c8\u00b9\u0001\u00ffs\u00e6\u00a4>G\t\u00a8\u00fd1p\u00ef9\u00e2\u00ed\u00b7*\u0099\u0088\u0082Zy\u00ee\u00ae\u0006\u0097s\u00f2\u00d9\u00d9\\\u00b3I>Mxy\u00ea\u00a4\u0084\u00ce}1\b\u00d7\u001a\u0006m~\u00df\u0091\u009cb-Ij\u001c\u00d2\u00d3\u00a4\u00c4v\u00d8\u009b%\u00d5\u00f0'\u0096\u00b8\u00bb7#\u00b1\u00c3q\u008c\u0003\u00e2j\u0001\u001e\u000eK1\u00cd\u00b9#zmU3NJ\u00cf\u00c6\u00e4\u00de@\u00e1s\u00ff\u00cf\u0000|\u00aaw{sS\u001c1q\u0090\u00af\u00f8\u00c1\u00b5v=\u0014KI\u0015\u008b\u00cc#\u00c9\u007f\u00aaX\u00b6V\u00ac}\u000f9P\u00f7[ZqH\u00a9>\u00a2\u00d5Q\u00fe\u00e8\u0017\t`!%\u00f9\u00e0>P(\u009d\u00d8y@$\u00f3N\u00f4<?\u0083+\u00c7\u00ac\u00db5\u00b7\u001dK%\u0081\u00f8\u00dc\u009c\u00dd\u00ff\u0006@\u008bF`\u0080\u0084\u00b1/\u000e\u00f4\u0000`\u0015F\u00db\u00cf\u001c\u000e\u00b5\u0080N\u00b4z\u00fa\u00ddv%\u00b9\f\u00c3a$F\u00d5\u0091\u0014\u00e9\u00f1a8\u00e1\u0012m\u001d o\u00ea\u00c2\u00c4\u00b2\u0081\u00b7\u00d5m\u0005Q3\u00edl7b\u00e59\u00bf-\u00f8\u0083W\u00f3+".length();
                        var13_16 = 0;
                        while (true) {
                            var18_17 = var15_14.substring(var13_16, var13_16 += 8).getBytes("ISO-8859-1");
                            v10 = var17_12;
                            v11 = var14_13++;
                            v12 = ((long)var18_17[0] & 255L) << 56 | ((long)var18_17[1] & 255L) << 48 | ((long)var18_17[2] & 255L) << 40 | ((long)var18_17[3] & 255L) << 32 | ((long)var18_17[4] & 255L) << 24 | ((long)var18_17[5] & 255L) << 16 | ((long)var18_17[6] & 255L) << 8 | (long)var18_17[7] & 255L;
                            v13 = -1;
                            break block28;
                            break;
                        }
lbl81:
                        // 1 sources

                        while (true) {
                            v10[v11] = v14;
                            if (var13_16 < var16_15) ** continue;
                            var15_14 = "6\u00fd\u00bdX#\u00c2\u001b\u00b4\u00f2AGy\u0092\u00d7\t(";
                            var16_15 = "6\u00fd\u00bdX#\u00c2\u001b\u00b4\u00f2AGy\u0092\u00d7\t(".length();
                            var13_16 = 0;
                            while (true) {
                                var18_17 = var15_14.substring(var13_16, var13_16 += 8).getBytes("ISO-8859-1");
                                v10 = var17_12;
                                v11 = var14_13++;
                                v12 = ((long)var18_17[0] & 255L) << 56 | ((long)var18_17[1] & 255L) << 48 | ((long)var18_17[2] & 255L) << 40 | ((long)var18_17[3] & 255L) << 32 | ((long)var18_17[4] & 255L) << 24 | ((long)var18_17[5] & 255L) << 16 | ((long)var18_17[6] & 255L) << 8 | (long)var18_17[7] & 255L;
                                v13 = 0;
                                break block28;
                                break;
                            }
                            break;
                        }
lbl94:
                        // 1 sources

                        while (true) {
                            v10[v11] = v14;
                            if (var13_16 < var16_15) ** continue;
                            break block29;
                            break;
                        }
                    }
                    var19_18 = v12;
                    var21_19 = var11_10.doFinal(new byte[]{(byte)(var19_18 >>> 56), (byte)(var19_18 >>> 48), (byte)(var19_18 >>> 40), (byte)(var19_18 >>> 32), (byte)(var19_18 >>> 24), (byte)(var19_18 >>> 16), (byte)(var19_18 >>> 8), (byte)var19_18});
                    v14 = ((long)var21_19[0] & 255L) << 56 | ((long)var21_19[1] & 255L) << 48 | ((long)var21_19[2] & 255L) << 40 | ((long)var21_19[3] & 255L) << 32 | ((long)var21_19[4] & 255L) << 24 | ((long)var21_19[5] & 255L) << 16 | ((long)var21_19[6] & 255L) << 8 | (long)var21_19[7] & 255L;
                    switch (v13) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl107:
                        // 1 sources

                        ** continue;
                    }
                }
                ExtraESP.jb = var17_12;
                ExtraESP.kb = new Integer[63];
                ExtraESP.ob = new HashMap<K, V>(13);
                var0_20 = Cipher.getInstance("DES/CBC/NoPadding");
                v15 = SecretKeyFactory.getInstance("DES");
                v16 = new byte[8];
                v17 = v16;
                v16[0] = (byte)(var22 >>> 56);
                for (var1_21 = 1; var1_21 < 8; ++var1_21) {
                    v17 = v17;
                    v17[var1_21] = (byte)(var22 << var1_21 * 8 >>> 56);
                }
                var0_20.init(2, (Key)v15.generateSecret(new DESKeySpec(v17)), new IvParameterSpec(new byte[8]));
                var6_22 = new long[8];
                var3_23 = 0;
                var4_24 = "\u00a5\u00d5\u0012<\u00d0\u00c8\u00d8\u00a6\u00c8\u00cf\u0080\u008a\u00d3\u00c2@+\u00ad5\u009a\u00a9\u008fO\u0095\u00f53\u0003\u00ae\u001d]v\u00e2\u00c6\u00b6\u000f \u00b7B\f\u000b\u000bQ\u0087\u009b-&\u0095\u0082M";
                var5_25 = "\u00a5\u00d5\u0012<\u00d0\u00c8\u00d8\u00a6\u00c8\u00cf\u0080\u008a\u00d3\u00c2@+\u00ad5\u009a\u00a9\u008fO\u0095\u00f53\u0003\u00ae\u001d]v\u00e2\u00c6\u00b6\u000f \u00b7B\f\u000b\u000bQ\u0087\u009b-&\u0095\u0082M".length();
                var2_26 = 0;
                while (true) {
                    var7_27 = var4_24.substring(var2_26, var2_26 += 8).getBytes("ISO-8859-1");
                    v18 = var6_22;
                    v19 = var3_23++;
                    v20 = ((long)var7_27[0] & 255L) << 56 | ((long)var7_27[1] & 255L) << 48 | ((long)var7_27[2] & 255L) << 40 | ((long)var7_27[3] & 255L) << 32 | ((long)var7_27[4] & 255L) << 24 | ((long)var7_27[5] & 255L) << 16 | ((long)var7_27[6] & 255L) << 8 | (long)var7_27[7] & 255L;
                    v21 = -1;
                    break block30;
                    break;
                }
lbl134:
                // 1 sources

                while (true) {
                    v18[v19] = v22;
                    if (var2_26 < var5_25) ** continue;
                    var4_24 = "\u00d2\t7Q\u00da\u008a6\u00b3\u00e4\u0092\u0010}\u009c\u00d6\u00b41";
                    var5_25 = "\u00d2\t7Q\u00da\u008a6\u00b3\u00e4\u0092\u0010}\u009c\u00d6\u00b41".length();
                    var2_26 = 0;
                    while (true) {
                        var7_27 = var4_24.substring(var2_26, var2_26 += 8).getBytes("ISO-8859-1");
                        v18 = var6_22;
                        v19 = var3_23++;
                        v20 = ((long)var7_27[0] & 255L) << 56 | ((long)var7_27[1] & 255L) << 48 | ((long)var7_27[2] & 255L) << 40 | ((long)var7_27[3] & 255L) << 32 | ((long)var7_27[4] & 255L) << 24 | ((long)var7_27[5] & 255L) << 16 | ((long)var7_27[6] & 255L) << 8 | (long)var7_27[7] & 255L;
                        v21 = 0;
                        break block30;
                        break;
                    }
                    break;
                }
lbl147:
                // 1 sources

                while (true) {
                    v18[v19] = v22;
                    if (var2_26 < var5_25) ** continue;
                    break block31;
                    break;
                }
            }
            var8_28 = v20;
            var10_29 = var0_20.doFinal(new byte[]{(byte)(var8_28 >>> 56), (byte)(var8_28 >>> 48), (byte)(var8_28 >>> 40), (byte)(var8_28 >>> 32), (byte)(var8_28 >>> 24), (byte)(var8_28 >>> 16), (byte)(var8_28 >>> 8), (byte)var8_28});
            v22 = ((long)var10_29[0] & 255L) << 56 | ((long)var10_29[1] & 255L) << 48 | ((long)var10_29[2] & 255L) << 40 | ((long)var10_29[3] & 255L) << 32 | ((long)var10_29[4] & 255L) << 24 | ((long)var10_29[5] & 255L) << 16 | ((long)var10_29[6] & 255L) << 8 | (long)var10_29[7] & 255L;
            switch (v21) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl160:
                // 1 sources

                ** continue;
            }
        }
        ExtraESP.mb = var6_22;
        ExtraESP.nb = new Long[8];
        ExtraESP.o = 250L;
        ExtraESP.n = 1000L;
        ExtraESP.m = 30000L;
        ExtraESP.p = Set.of(Blocks.DEEPSLATE, Blocks.COBBLED_DEEPSLATE, Blocks.POLISHED_DEEPSLATE, Blocks.DEEPSLATE_BRICKS, Blocks.DEEPSLATE_TILES, Blocks.CHISELED_DEEPSLATE);
    }

    private static Exception a(Exception exception) {
        return exception;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static String b(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x79EF;
        if (hb[n3] == null) {
            Object[] objectArray;
            try {
                Long l3 = Thread.currentThread().threadId();
                objectArray = (Object[])ib.get(l3);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    ib.put(l3, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/g/O", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l2 >>> 56);
            for (int i2 = 1; i2 < 8; ++i2) {
                byArray[i2] = (byte)(l2 << i2 * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = db[n3].getBytes("ISO-8859-1");
            ExtraESP.hb[n3] = ExtraESP.b(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return hb[n3];
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        String string2 = ExtraESP.b(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static CallSite b(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/O" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static long d(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x2FD0;
        if (nb[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = mb[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])ob.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    ob.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/g/O", exception);
            }
            long l5 = ((long)byArray[0] & 0xFFL) << 56 | ((long)byArray[1] & 0xFFL) << 48 | ((long)byArray[2] & 0xFFL) << 40 | ((long)byArray[3] & 0xFFL) << 32 | ((long)byArray[4] & 0xFFL) << 24 | ((long)byArray[5] & 0xFFL) << 16 | ((long)byArray[6] & 0xFFL) << 8 | (long)byArray[7] & 0xFFL;
            ExtraESP.nb[n3] = l5;
        }
        return nb[n3];
    }

    private static long d(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        long l3 = ExtraESP.d(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Long.TYPE, l3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return l3;
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/O" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (sb[n4] != null) {
            return n4;
        }
        Object object = pb[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 25;
            case 1 -> 61;
            case 2 -> 2;
            case 3 -> 42;
            case 4 -> 30;
            case 5 -> 4;
            case 6 -> 52;
            case 7 -> 46;
            case 8 -> 26;
            case 9 -> 33;
            case 10 -> 6;
            case 11 -> 58;
            case 12 -> 18;
            case 13 -> 10;
            case 14 -> 16;
            case 15 -> 37;
            case 16 -> 57;
            case 17 -> 27;
            case 18 -> 55;
            case 19 -> 21;
            case 20 -> 56;
            case 21 -> 24;
            case 22 -> 14;
            case 23 -> 62;
            case 24 -> 41;
            case 25 -> 19;
            case 26 -> 54;
            case 27 -> 13;
            case 28 -> 47;
            case 29 -> 1;
            case 30 -> 15;
            case 31 -> 0;
            case 32 -> 60;
            case 33 -> 35;
            case 34 -> 7;
            case 35 -> 53;
            case 36 -> 39;
            case 37 -> 22;
            case 38 -> 31;
            case 39 -> 50;
            case 40 -> 59;
            case 41 -> 20;
            case 42 -> 38;
            case 43 -> 12;
            case 44 -> 29;
            case 45 -> 34;
            case 46 -> 9;
            case 47 -> 36;
            case 48 -> 49;
            case 49 -> 63;
            case 50 -> 28;
            case 51 -> 11;
            case 52 -> 32;
            case 53 -> 51;
            case 54 -> 44;
            case 55 -> 5;
            case 56 -> 17;
            case 57 -> 8;
            case 58 -> 43;
            case 59 -> 23;
            case 60 -> 45;
            case 61 -> 3;
            case 62 -> 40;
            default -> 48;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        ExtraESP.sb[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = pb;
        pb[0] = "l&S3\u0019\u000bg&U37";
        objectArray[1] = "@@0C\tPKO!\fbDID6VNSD";
        objectArray[2] = "\u0019%99D7\u0012%2";
        objectArray[3] = "<\u0017P:!+<\u0017Gf-$&\\Gx-1!-\u0017%|";
        objectArray[4] = "\\\n\u0010|\u000fQ)*\u001bs\u001e\u001eH$\u0010x\u001aD<";
        objectArray[5] = "+\u0017DfWk+\u0017S:[d1\\S$[q6-\u0002~\u00022";
        objectArray[6] = "8qZts`3q\\ts\n";
        objectArray[7] = "\u000e[";
        objectArray[8] = "\u00066r\f:Xs\u0016y\u0003+\u0017\u0012\u0018r\b/Mf";
        objectArray[9] = "^'.1uFU'(1z";
        objectArray[10] = "v}'LoD\u007f}$Lk";
        objectArray[11] = "Wx%\u001aQ|Jm}8\u0010qRk";
        objectArray[12] = "C\u0016\u0002\u0001F<]\u001e\u0018N%(Y";
        objectArray[13] = "oH`\u000f{]dHf\u000fj";
        objectArray[14] = "F/~5&73\u000fu:7xR\u0001~13\"&";
        objectArray[15] = Integer.TYPE;
        ExtraESP.sb[15] = "java/lang/Integer";
        objectArray[16] = "rZK8X0\u0007z@7I\u007fftK<M%\u0012";
        objectArray[17] = Void.TYPE;
        ExtraESP.sb[17] = "java/lang/Void";
        objectArray[18] = Long.TYPE;
        ExtraESP.sb[18] = "java/lang/Long";
        objectArray[19] = "Z}tO!\u0014S}wO,";
        objectArray[20] = Boolean.TYPE;
        ExtraESP.sb[20] = "java/lang/Boolean";
        objectArray[21] = "UsK\u0000/9 S@\u000f>vA]K\u0004:,5";
        objectArray[22] = "\u0002/uO/'\u001c'o\u0000b=\u0006-v\\s7\u0006:-ky7\u000b;wAs\u0001\r<uGb7";
        objectArray[23] = "\u0003$-Aqy\n$.Aq";
        objectArray[24] = "\u001d[7^)U\u0016T&\u0011H[\u001d_\"K";
        objectArray[25] = "JPsV\u0007\u0018TXi\u0019z\bT";
        objectArray[26] = "r~\n^\u0011/lv\u0010\u0011n/}j\u0019";
        objectArray[27] = ".S,(q[[s''`\u0014:},,dNN";
        objectArray[28] = "g S1:$n P18";
        objectArray[29] = "hk\u000bS.c\u001dK\u0000\\?,|E\u000bW;v\b";
        objectArray[30] = "VrYpA\u000b#RR\u007fPDB\\YtT\u001e6";
        objectArray[31] = "vUPx\u001b\u0019\u0003u[w\nVb{P|\u000e\f\u0016";
        objectArray[32] = "D3zU9\u000f1\u0013qZ(@P\u001dzQ,\u001a$";
        objectArray[33] = "3\nV]y^F*]Rh\u0011'$VYlKS";
        objectArray[34] = "S|$\fPFX|\"\f^";
        objectArray[35] = "\"]\bqpTW}\u0003~a\u001b6s\bueAB";
        objectArray[36] = "P\u0010\u0007*S\u001b%0\f%BTD>\u0007.F\u000e0";
        objectArray[37] = "\u0002\u001dk<\u0010rw=`3\u0001=\u00163k8\u0005gb";
        objectArray[38] = "4\u0007\u001dh\u001d\u0013A'\u0016g\f\\ )\u001dl\b\u0006T";
        objectArray[39] = "\u0014VG\u0018^\u0019\n^]W<\u0005\rC";
        objectArray[40] = ":nK\u0017:\u00111nL\u00172";
        objectArray[41] = "lP\"e>m\u0019p)j/\"x~\"a+x\f";
        objectArray[42] = "\r'Q\t\u0006\\\u0006'Y";
        objectArray[43] = "8\u0017\u0007j}+M7\feld,9\u0007nh>X";
        objectArray[44] = "i)k\u0018{\u000b\u001c\t`\u0017jD}\u0007k\u001cn\u001e\t";
        objectArray[45] = "\u007fSnK8_\nseD)\u0010k}nO-J\u001f";
        objectArray[46] = "a9])n\u001e\u0014\u0019V&\u007fQu\u0017]-{\u000b\u0001";
        objectArray[47] = "\u0010H\u0011~\u0007\u001aeh\u001aq\u0016U\u0004f\u0011z\u0012\u000fp";
        objectArray[48] = "H/oBP==\u000fdMAr\\\u0001oFE((";
        objectArray[49] = "{\u0006g#\n'\u000e&l,\u001bho(g'\u001f2\u001b";
        objectArray[50] = "V \u0003\u001aRL#\u0000\b\u0015C\u0003B\u000e\u0003\u001eGY6";
        objectArray[51] = "YzE5am,ZN:p\"MTE1tx9";
        objectArray[52] = "A`2S\\c\u001497jd\u0007\u00119q\u0012^v\u001d`?\u001a";
        objectArray[53] = "(KWjY\u001ce\u001c\u0006+`&T;&\u0007%c(KWjY\u001ce\u001c\u0006+";
        objectArray[54] = "\u0006\u000f2\u0005|TSV7<Y0\tY6E|\fORv]";
        objectArray[55] = ">\u0017c\r:2s@2L\u0003$\u000fY2F<6lKi[lMfH\"A=+cWk\u0000\u0003";
        objectArray[56] = "~o\u0004\u0000ev+6\u00019Y\u0012~7\u0000Xsr#8C\u0002";
        objectArray[57] = ",X\u0018,c'y\u0001\u001d\u0015kCn\u0001_*| |ZBz\u0007.q\u0000]qu(-\u0006\u001d\u0015";
        objectArray[58] = "k\teOb\u0018>P`v{|9K0\u001dl\u00065H6J";
        objectArray[59] = "H\u0018\u001f]&D\u001dA\u001ad+ \nAX[9C\u0018\u001aE\u000bBM\u0015@Z\u00000KIF\u001ad";
        objectArray[60] = "N'j\u001aLg\u001b~o#m\u0003AqnZL?\u0007z.B";
        objectArray[61] = "D\u0012\"W:~\u0011K'n\u001e\u001aKD&\u0017:&\rOf\u000f";
        objectArray[62] = "Nw&l\u0010y\u001b.#U\u001d\u001d\f.aj\u000f~\u001eu|:t#\u0012vj$J\u007f\u00153pU";
        objectArray[63] = "~.< @++w9\u0019\\O.w\u007faB>\".1i";
        objectArray[64] = "kJR$8\u001e7M\u0017>Iz\u0012z\"\b\u0004l\u0002j&\u0019\u0011{\u0011o7\u0019I\u001e9\u001f\u001b%wB>Z\u0001";
        objectArray[65] = "jo-!w6?6(\u0018jR(6j'h1:mww\u00139b8*s|l kc\u0018";
        objectArray[66] = "U~b\u00122v\u0000'g+)\u0012\u0007<7@<h\u000b?1\u0017";
        objectArray[67] = "$eM.5oq<H\u0017\u000b\u000bt<\u000eo7zxe@g";
        objectArray[68] = "JY+*\f~\u001cS.:qt%Vz-\u0012tUMpg\u001f\u001d";
        objectArray[69] = "uT*uQ+ \r/LrOz\u0002.5Qs<\tn-";
        objectArray[70] = "oC1\u0011+O:\u001a4(\f+`\u00155Q+\u0017&\u001euI";
        objectArray[71] = "]\u0012&;krU\f9(Q\u001f|-\u0001\u000b\u001c\u001ae)\u000f\u000e\u0018\u0002v2K,+ JRt$5?Y";
        objectArray[72] = "mN7WbJ0]7\u001b\u001bET\u00159^#\u0010h_eMj";
        objectArray[73] = "\u0012\u0012~\u000eSQGK{7^5PK9\bLVB\u0010$X7\u000eGJ:RUG\\[<7";
        objectArray[74] = "3\u001bo\u0018HVfBj!EX\u0003H.MHWsNo\u0010U";
        objectArray[75] = "\u001cz{nh*I#~WaN^#<hw-Lx!8\f%\u0014-|<cpV~5W";
        objectArray[76] = "]\u0000=\u0013\\s\u001b\u000b}\u000b8&b^>ZA>\u0001Uc\u0007GO";
        objectArray[77] = "}A)a\f\u001f(\u0018,X\u0001\u0012M\u0012h4\f\u001e=\u0014)i\u0011";
        objectArray[78] = "ZUk\r\u00100RKt\u001e*KxfC5*iFBwF\u0015aX]d";
        objectArray[79] = "gZ\\\u0005{32\u0003Y<mW5\u0018\tWu-9\u001b\u000f\u0000";
        objectArray[80] = "!M\u001d\bC!}JX\u00122VZlx8cDC!\u001a\u0014\u000bon\u001fF\u0013Nu";
        objectArray[81] = ".p\u0003V\u001b<{)\u0006o\u0014Xl)DP\u0004;~rY\u0000\u007f3&'\u0004\u0004\u0010fdtMo";
        objectArray[82] = "`\u001bE<)Q5B@\u0005\u000452Y\u0010n'O>Z\u00169";
        objectArray[83] = "\n'{\u000bX^_~~2R:H~<\rGYZ%!]<Q\u0002p|YS\u0004@#52";
        objectArray[84] = "u<dX\u0011\u001f eaa\u001b{7e#^\u000e\u0018%>>\u000eu\u0016(d!\u0005\u0007\u0010tbaa";
        objectArray[85] = "`\u0014o)yQ5Mj\u0010M5;Q?txE=\u0010bi";
        objectArray[86] = "&1\\HXPshYq[4dh\u001bNGWv3\u0006\u001e<_.f[\u001aS\nl5\u0012q";
        objectArray[87] = "-%:\u000e=\fx|?7\u001bh\"s>N=Tdx~V";
        objectArray[88] = "f5\u0017\u000f\u001dS3l\u00126\u00017$lP\t\u0002T67MYy\\nb\u0010]\u0016\t,1Y6";
        objectArray[89] = "B\u001c\u0004aH\u0019\u0017E\u0001Xu}BD\u00009^\u001d\u001fKCc";
        objectArray[90] = ".q\u000fq\u0013o&o\u0010b)\u000f\u0001M.Ms\u0011\u000eD5\\s\u0019\u0004F8\u0000O*%zX?G4:i";
        objectArray[91] = "\u000eBILGI[\u001bLun-\u0001\u0014M\fG\u0011G\u001f\r\u0014";
        objectArray[92] = "e>yRX@0g|kU$'g>TGG5<#\u0004<Omi~\u0000S\u001a/:7k";
        objectArray[93] = "{Y\n\b\u0001K.\u0000\u000f1\u0000/9\u0000M\u000e\u001eL+[P^eDs\u000e\rZ\n\u00111]D1";
        objectArray[94] = "\u007fQbWuG*\bgn`#-\u00137\u0005{Y!\u00101R";
        objectArray[95] = ":e\u0016=,\u0005o<\u0013\u0004\"ax<Q;3\u0002jgLkH\n22\u0011o'_paX\u0004";
        objectArray[96] = ".|\u001f\u0010|]{%\u001a)f9|>JBrCp=L\u0015";
        objectArray[97] = "\n\u000b\u001e\u0002_7_R\u001b;@SXIKPQ)TJM\u0007";
        objectArray[98] = "i\u001eQ'\\b<GT\u001ew\u0006fHUg\\: C\u0015\u007f";
        objectArray[99] = "\u0014V\b\u0014;-A\u000f\r-\u0015IF\u0014]F53J\u0017[\u0011";
        objectArray[100] = "e!Jm3\u001e0xOT\nz4)\tk1J-}L3";
        objectArray[101] = "\u0013vz\\3<F/\u007fe\u0013X\u001c ~\u001c3dZ+>\u0004";
        objectArray[102] = "EO~-1\u000b\u0010\u0016{\u0014:o\u0007\u00169+.\f\u0015M${U\u0002\u0018\u0017;p'\u0004D\u0011{\u0014";
        objectArray[103] = "Yg\n#\u001fZ\f>\u000f\u001a)>\u0002\"Z~\u001eN\u0004c\u0007c";
        objectArray[104] = "e[n\n0Z0\u0002k3(>7\u0019;X>D;\u001a=\u000f";
        objectArray[105] = "(\u0013Jz8>}JOC&ZjJ\r|'9x\u0011\u0010,\\1 DM(3db\u0017\u0004C";
        objectArray[106] = "c\u0016I=&v6OL\u0004\u001c\u0012=I\u00178%qcJ\f<";
        objectArray[107] = "*MLs\tK\u007f\u0014IJ\u0014/x\u000f\u0019!\u0007Ut\f\u001fv";
        objectArray[108] = "c\u0000zv>\u001a?\u0007?lOh\u0010!\u001b]\u000bm\u0001!C8#\u001d-\u001d}d$X7";
        objectArray[109] = "\u0012<L\u001c?\u0019GeI%!}@~\u0019N1\u0007L}\u001f\u0019";
        objectArray[110] = "Uk'c|!\u00002\"ZhE\u0007)r1r?\u000b*tf";
        objectArray[111] = "D\u0011\u0003]/gL\u000f\u001cN\u0015\u0000c/*eZ\u0015xk\bVx)\u0018T\u0000Hg:";
        objectArray[112] = "n=\u0016\u0002\u0012th1D\u0002p-\u0014?\u0018\u0001O?w-C\u001c\u001fD\u007fu\u0016A\u001b+*7E\bp";
        objectArray[113] = ":3RTy\u0005ojWmta35\u0014\t{^jq\u0013\u001d\u001dX4q\n\u000b\"\u0001pv\u001em";
        objectArray[114] = "P\u0012s{\u0002$\u001dE\":;1a\\\"0\u0004 \u0002Ny-T[\bM27\u0005=\rR{v;";
        objectArray[115] = "\u001bN~W0\u0015GI;MAhhf\u001f'\u007fG\u001cR6\u0019#@YH";
        objectArray[116] = "\u0003^TV\u0015\fV\u0007Qo\u0017hA\u0007\u0013P\n\u000bS\\\u000e\u0000q\u0003\u000b\tS\u0004\u001eVIZ\u001ao";
        objectArray[117] = "Z\\\n(\u0018A\u0017\u000b[i!Wk\u0012[c\u001eE\b\u0000\u0000~N>\u0000\u001dV|DN\u0006\\\u000ba!";
        objectArray[118] = "V\tdK.M\n\u000e!Q_4.(\nq\u000e$/#\u0010l\u001f4,(]\u00053J\u0018\u0014cY4\u000f\u0002";
        objectArray[119] = "b*'\n*\u0018j48\u0019\u0010yE\u0014\u000e2_j^P,\u0001}V>o$\u001fbE";
        objectArray[120] = "igV[&7<>Sb\u000eS53\u0003R#1!oV\u000b";
        objectArray[121] = "~6>>\u0015\u001d+o;\u0007.y#cb~\u0015\u000b%?d>";
        objectArray[122] = "AvkosZ\u001bde\u007f\u0017U}0=kmD\u00071|a}?";
        objectArray[123] = "5\u0007s\u0002gh`^v;M\f:QwBg0|Z7Z";
        objectArray[124] = "\r\u000f\r>zf@X\\\u007fCs<A\\u|b_S\u0007h,\u0019WNQj&iQ\u000f\fwC";
        objectArray[125] = "%l\u007f\u000bi&x\u007f\u007fG\u0010,\u001c`p\u001bi$nf,\u001d)@";
        objectArray[126] = "\u0000F\u0014L<W\\AQVM7\u007fl`<s\u0005\u0007Z\\\u0002/\u0002B@";
        objectArray[127] = " \u0006S5\u0005+![\u001bb9\u001d\u001b;-\u001e9>;[\u000enP?f\u0013Y";
        objectArray[128] = "=\u0006\u000f!pyh_\n\u0018_\u001doDZs~gcG\\$";
        objectArray[129] = "\u001c[N\u000eq#I\u0002K7yG^\u0002\t\bn$LY\u0014X\u0015,\u0014\fI\\zyV_\u00007";
        objectArray[130] = "08\u0003\u0004[9ea\u0006=n]k}SYZ-m<\u000eD";
        objectArray[131] = ";&$!tEn\u007f!\u0018V!4p at\u001dr{`y";
        objectArray[132] = "m\u001dt}\fA8DqD3%=D7<\u000eT1\u001dy4";
        objectArray[133] = "G]YG*t\u0012\u0004\\~$\u0010\u0005\u0004\u001eA5s\u0017_\u0003\u0011NjN\t\u0018G\u007ftF\u0007\u0015~";
        Object[] objectArray2 = objectArray;
        objectArray[134] = "-ErV\u001d]pVr\u001ad_\u0014Vq][@wD*@\u000b;\u007f\u001c\u007f\u001d\u000fT*^,Td";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = ExtraESP.e(l2, l3);
            object = pb[n2];
            try {
                if (!(object instanceof String)) break block2;
                ExtraESP.pb[n2] = clazz = Class.forName(sb[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = ExtraESP.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = ExtraESP.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = ExtraESP.e(l2, l3);
        Object object = pb[n2];
        if (object instanceof String) {
            String string = sb[n2];
            int n3 = string.indexOf(8);
            Class clazz = ExtraESP.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = ExtraESP.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = ExtraESP.c(clazz3, string2, clazz2)) != null) {
                    ExtraESP.pb[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = ExtraESP.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        ExtraESP.pb[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = ExtraESP.f(1737142622570175L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = ExtraESP.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = ExtraESP.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = ExtraESP.e(l2, l3);
        Object object = pb[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = sb[n2];
                int n4 = string2.indexOf(8);
                clazz3 = ExtraESP.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = ExtraESP.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = ExtraESP.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        ExtraESP.pb[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = ExtraESP.f(1737142622570175L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = ExtraESP.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        ExtraESP.pb[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = ExtraESP.f(1737142622570175L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == '\u00c0' || c2 == 'v' || c2 == '\u00dd' || c2 == 'N') {
                field = ExtraESP.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == '\u00c0' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == 'v' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == '\u00dd' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = ExtraESP.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == '\u00e0' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == '\u00f9' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = ExtraESP.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite f(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_2().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/O" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(ExtraESP.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(ExtraESP.class, "d", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_2() {
        try {
            return MethodHandles.lookup().findStatic(ExtraESP.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

