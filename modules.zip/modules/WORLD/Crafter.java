// === Kuzi module: Crafter ===
// Category   : WORLD
// Description: Auto-sets an open Crafter's disabled slots to a pattern you pick in a 3x3 grid.
// Payload    : a.a.a.j.e.J (verified: True)

package kuzi.modules.world;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.module.Module;
import kuzi.obf.h.U;
import kuzi.obf.h.b.v;
import kuzi.obf.j.e.am;
import kuzi.obf.m.r;
import kuzi.settings.BoolSetting;
import kuzi.settings.ButtonSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.AbstractContainerMenu;
import net.minecraft.Minecraft;
import net.minecraft.Screen;
import net.minecraft.CrafterMenu;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class Crafter
extends BaseModule
implements Module {
    private final BoolSetting[] m;
    private final SliderSetting delayMs;
    private long o;
    private static final long p;
    private static final String[] q;
    private static final String[] r;
    private static final Map s;
    private static final long[] t;
    private static final Integer[] u;
    private static final Map v;
    private static final Object[] w;
    private static final String[] x;

    public Crafter() {
        block2: {
            long l2;
            long l3 = l2 = p ^ 0x63CAAAF4EB29L;
            long l4 = l3 ^ 0x418A671B91FL;
            long l5 = l3 ^ 0x375F4DAC575EL;
            super("Crafter", "Auto-sets an open Crafter's disabled slots to a pattern you pick in a 3x3 grid.", Category.WORLD);
            String string = am.b();
            this.m = new BoolSetting[9];
            this.delayMs = new SliderSetting("Delay (ms)", 120.0, 0.0, 1000.0, 10.0);
            this.o = 0L;
            Object[] objectArray = new Object[2];
            objectArray[1] = new Setting[]{new ButtonSetting("Edit Slots", Crafter::lambda$new$1)};
            objectArray[0] = l5;
            this.l(objectArray);
            String string2 = string;
            for (int index = 0; index < 9; ++index) {
                this.m[index] = new BoolSetting("Slot " + (index + 1), false);
                Object[] objectArray2 = new Object[2];
                objectArray2[1] = l4;
                objectArray2[0] = true;
                this.m[index].b(objectArray2);
                Object[] objectArray3 = new Object[2];
                objectArray3[1] = new Setting[]{this.m[index]};
                objectArray3[0] = l5;
                this.l(objectArray3);
                if (string2 != null) {
                    if (string2 != null) continue;
                }
                break block2;
            }
            Object[] objectArray4 = new Object[2];
            objectArray4[1] = new Setting[]{this.delayMs};
            objectArray4[0] = l5;
            this.l(objectArray4);
        }
    }

    /*
     * Unable to fully structure code
     */
    public boolean a(Object[] var1_1) {
        block12: {
            block10: {
                block11: {
                    block9: {
                        var2_2 = (Long)var1_1[0];
                        var4_3 = (Integer)var1_1[1];
                        var2_2 = Crafter.p ^ var2_2;
                        var5_4 = Crafter.d("t", (long)5912567012185349122L, (long)var2_2);
                        try {
                            v0 = var4_3;
                            if (var5_4 == null) break block9;
                            if (v0 < 0) break block10;
                        }
                        catch (r v1) {
                            throw Crafter.d("t", (Object)v1, (long)5912425660015693153L, (long)var2_2);
                        }
                        v0 = var4_3;
                    }
                    try {
                        try {
                            v2 = var5_4;
                            if (var2_2 > 0L) {
                                if (v2 == null) break block11;
                                if (v0 > Crafter.c("o", (int)12295, (long)(2730956917553910188L ^ var2_2))) break block10;
                            }
                            ** GOTO lbl32
                        }
                        catch (r v3) {
                            throw Crafter.d("t", (Object)v3, (long)5912425660015693153L, (long)var2_2);
                        }
                        v0 = (int)((Boolean)Crafter.d("g", (Object)Crafter.d("Z", (Object)this, (long)5911801983076501739L, (long)var2_2)[var4_3], (long)5912306907680564111L, (long)var2_2)).booleanValue();
                    }
                    catch (r v4) {
                        throw Crafter.d("t", (Object)v4, (long)5912425660015693153L, (long)var2_2);
                    }
                }
                try {
                    v2 = var5_4;
lbl32:
                    // 2 sources

                    if (v2 == null) break block12;
                    if (v0 == 0) break block10;
                }
                catch (r v5) {
                    throw Crafter.d("t", (Object)v5, (long)5912425660015693153L, (long)var2_2);
                }
                v0 = 1;
                break block12;
            }
            v0 = 0;
        }
        return (boolean)v0;
    }

    public void a(Object[] objectArray) {
        block6: {
            int clampedIndex;
            long l2;
            boolean state;
            int slotIndex;
            block5: {
                slotIndex = (Integer)objectArray[0];
                state = (Boolean)objectArray[1];
                l2 = (Long)objectArray[2];
                l2 = p ^ l2;
                CallSite callSite = Crafter.d("t", (long)-2993291420905596806L, (long)l2);
                try {
                    clampedIndex = slotIndex;
                    if (callSite == null) break block5;
                    if (clampedIndex < 0) break block6;
                }
                catch (r r2) {
                    throw Crafter.d("t", (Object)r2, (long)-2993417248987592423L, (long)l2);
                }
                clampedIndex = slotIndex;
            }
            try {
                if (clampedIndex <= Crafter.c("o", (int)12295, (long)(0x25E657C82C00D5D4L ^ l2))) {
                    Crafter.d("g", (Object)Crafter.d("Z", (Object)this, (long)-2994074048766735213L, (long)l2)[slotIndex], (Object)state, (long)-2993637186064987307L, (long)l2);
                }
            }
            catch (r r3) {
                throw Crafter.d("t", (Object)r3, (long)-2993417248987592423L, (long)l2);
            }
        }
    }

    public void b(Object[] objectArray) {
        block6: {
            int clampedIndex;
            String stringTable;
            int slotIndex;
            long l2;
            block5: {
                l2 = (Long)objectArray[0];
                slotIndex = (Integer)objectArray[1];
                l2 = p ^ l2;
                stringTable = am.b();
                clampedIndex = slotIndex;
                if (stringTable == null) break block5;
                if (clampedIndex < 0) break block6;
                clampedIndex = slotIndex;
            }
            if (clampedIndex <= Crafter.c("o", (int)13001, (long)(0x202558F3B3B4FE5AL ^ l2))) {
                BoolSetting slotSetting = this.m[slotIndex];
                boolean newValue = (Boolean)this.m[slotIndex].a();
                if (stringTable != null) {
                    newValue = !newValue;
                }
                slotSetting.a(newValue);
            }
        }
    }

    @Override
    public void d() {
        Client.a().a(Module.class, this);
        super.d();
    }

    @Override
    public void e() {
        Client.a().b(Module.class, this);
        super.e();
    }

    @Override
    public void b() {
        double slotIndex;
        CrafterMenu crafterMenu;
        String stringTable;
        block19: {
            block18: {
                AbstractContainerMenu currentMenu;
                block17: {
                    AbstractContainerMenu containerMenu;
                    Minecraft mc3102;
                    block15: {
                        block16: {
                            block14: {
                                block13: {
                                    stringTable = am.b();
                                    mc3102 = BaseModule.a;
                                    if (stringTable == null) break block13;
                                    if (mc3102.player == null) break block14;
                                    mc3102 = BaseModule.a;
                                }
                                if (stringTable == null) break block15;
                                if (mc3102.gameMode != null) break block16;
                            }
                            return;
                        }
                        mc3102 = BaseModule.a;
                    }
                    currentMenu = containerMenu = mc3102.player.containerMenu;
                    if (stringTable == null) break block17;
                    if (!(currentMenu instanceof CrafterMenu)) break block18;
                    currentMenu = containerMenu;
                }
                crafterMenu = (CrafterMenu)currentMenu;
                if (stringTable != null) break block19;
            }
            return;
        }
        double elapsed = (double)(System.currentTimeMillis() - this.o) - (Double)this.delayMs.a();
        double comparison = elapsed == 0.0 ? 0 : (elapsed < 0.0 ? -1 : 1);
        if (stringTable != null) {
            if (comparison < 0) {
                return;
            }
            comparison = slotIndex = 0.0;
        }
        while (slotIndex < 9) {
            block21: {
                boolean newState;
                block20: {
                    boolean wanted = (Boolean)this.m[slotIndex].a();
                    newState = crafterMenu.isSlotDisabled((int)slotIndex);
                    if (stringTable == null) break block20;
                    if (newState == wanted) break block21;
                    newState = wanted;
                }
                if (stringTable != null) {
                    newState = !newState;
                }
                boolean stateToApply = newState;
                crafterMenu.setSlotState((int)slotIndex, stateToApply);
                BaseModule.a.gameMode.handleSlotStateChanged((int)slotIndex, crafterMenu.containerId, stateToApply);
                this.o = System.currentTimeMillis();
                return;
            }
            ++slotIndex;
            if (stringTable != null) continue;
        }
    }

    private static void lambda$new$1() {
        Client.e.execute(Crafter::lambda$new$0);
    }

    private static void lambda$new$0() {
        Client.e.setScreen((Screen)new U());
    }

    /*
     * Unable to fully structure code
     */
    static {
        block21: {
            block20: {
                block19: {
                    block18: {
                        Crafter.p = kuzi.obf.h.b.v.a(-445623254087146468L, 2650436517208671453L, MethodHandles.lookup().lookupClass()).a(1368178926988L);
                        Crafter.w = new Object[26];
                        Crafter.x = new String[26];
                        Crafter.c();
                        Crafter.s = new HashMap<K, V>(13);
                        var11 = Crafter.p ^ 127541961882131L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[5];
                        var18_4 = 0;
                        var17_5 = "yt[\u00ba\u0004X\u0097\u0016\u00a1\u00bc\u000b0-\u00be\u001b\u00c8\u00e2\f\r\u00f5\u00ec\u008b\u00ab\u00ca\u00bc\u0000\u00e6Hx\u0092\u0004L <\u001b\u0013\u0088\u00d1$o\u00bc\u00de\u00e9^\u009c\u00c1\u0000w\u00d0\u008c\u00d8\u0015\u00c0\u00e3S\u00e8U\u00ba\u00ed\u00ff\u00b5\u00f7\u00b7\u00a5\u0089\u0080Y\u00cc/\u009b@Z\u0080~o\u00ecy\u00baN\u0091\u00f1p\u00a76\u00beI\u00c7\u00fe\u0098T\u00aeL\u00ccSG\u00963\u00dd\u00b7\u008d\u0002?-X\u00aa\u0086\u0093\u00cbO\u0092\u008b\t\u00bb\u0080\u00aa\u00bb\u00fb\u00f0\u00b9\u0005D\u00b0\u00b6\u00db\u0087\u00cer\u0093C\u0091\u00cc\u00c3\u00c6\u001b\u0082\u0010\u0002B)\u00ca\u00ac\u00ff8\u0099\u009ep\u00a2\t\u00d3)\u0016^\u00c9\u00b8\u0092\u0083\u0099xd'8\u00df9$\u00e4\u001b\u0099\u00f0\u00d2\u00d9L\u0085\u00edu\u00ca\u0085\u0086\u00e2:\fw\u00a9\u00cfY\n\u0088\u009e\u0092i\u00de\u00f1N#O";
                        var19_6 = "yt[\u00ba\u0004X\u0097\u0016\u00a1\u00bc\u000b0-\u00be\u001b\u00c8\u00e2\f\r\u00f5\u00ec\u008b\u00ab\u00ca\u00bc\u0000\u00e6Hx\u0092\u0004L <\u001b\u0013\u0088\u00d1$o\u00bc\u00de\u00e9^\u009c\u00c1\u0000w\u00d0\u008c\u00d8\u0015\u00c0\u00e3S\u00e8U\u00ba\u00ed\u00ff\u00b5\u00f7\u00b7\u00a5\u0089\u0080Y\u00cc/\u009b@Z\u0080~o\u00ecy\u00baN\u0091\u00f1p\u00a76\u00beI\u00c7\u00fe\u0098T\u00aeL\u00ccSG\u00963\u00dd\u00b7\u008d\u0002?-X\u00aa\u0086\u0093\u00cbO\u0092\u008b\t\u00bb\u0080\u00aa\u00bb\u00fb\u00f0\u00b9\u0005D\u00b0\u00b6\u00db\u0087\u00cer\u0093C\u0091\u00cc\u00c3\u00c6\u001b\u0082\u0010\u0002B)\u00ca\u00ac\u00ff8\u0099\u009ep\u00a2\t\u00d3)\u0016^\u00c9\u00b8\u0092\u0083\u0099xd'8\u00df9$\u00e4\u001b\u0099\u00f0\u00d2\u00d9L\u0085\u00edu\u00ca\u0085\u0086\u00e2:\fw\u00a9\u00cfY\n\u0088\u009e\u0092i\u00de\u00f1N#O".length();
                        var16_7 = 32;
                        var15_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block18;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = Crafter.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "\n_\u00fe\u00e0}\u00b0\u00e1\u00f27\u000b<\u00b4\u00ff\u00cb\u0007\u001e\u00106\u00c2\u00a1\u0019\u0016\u00bay\u00fbD\u00aeH\u00d05\u00ce\u00c7\u00dd";
                            var19_6 = "\n_\u00fe\u00e0}\u00b0\u00e1\u00f27\u000b<\u00b4\u00ff\u00cb\u0007\u001e\u00106\u00c2\u00a1\u0019\u0016\u00bay\u00fbD\u00aeH\u00d05\u00ce\u00c7\u00dd".length();
                            var16_7 = 16;
                            var15_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block18;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = Crafter.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block19;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                Crafter.q = var20_3;
                Crafter.r = new String[5];
                Crafter.v = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[4];
                var3_13 = 0;
                var4_14 = "\u001aMM\u008f\u0093\u009cd/;\u00be\u0010\u00d7+6\u00b0\u00fc";
                var5_15 = "\u001aMM\u008f\u0093\u009cd/;\u00be\u0010\u00d7+6\u00b0\u00fc".length();
                var2_16 = 0;
                while (true) {
                    var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                    v10 = var6_12;
                    v11 = var3_13++;
                    v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                    v13 = -1;
                    break block20;
                    break;
                }
lbl81:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    var4_14 = "i\u00fdV<\\R\u00ca\u0086\u00c4\u00a0z\u0094\u00a0\u0090,\u00e5";
                    var5_15 = "i\u00fdV<\\R\u00ca\u0086\u00c4\u00a0z\u0094\u00a0\u0090,\u00e5".length();
                    var2_16 = 0;
                    while (true) {
                        var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                        v10 = var6_12;
                        v11 = var3_13++;
                        v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                        v13 = 0;
                        break block20;
                        break;
                    }
                    break;
                }
lbl94:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    break block21;
                    break;
                }
            }
            var8_18 = v12;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            v14 = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
            switch (v13) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl107:
                // 1 sources

                ** continue;
            }
        }
        Crafter.t = var6_12;
        Crafter.u = new Integer[4];
    }

    private static r a(r value) {
        return value;
    }

    private static String b(byte[] byArray) {
        int outIndex = 0;
        int inputLength = byArray.length;
        char[] cArray = new char[inputLength];
        for (int index = 0; index < inputLength; ++index) {
            char ch;
            int byteValue = 0xFF & byArray[index];
            if (byteValue < 192) {
                cArray[outIndex++] = (char)byteValue;
                continue;
            }
            if (byteValue < 224) {
                ch = (char)((char)(byteValue & 0x1F) << 6);
                byteValue = byArray[++index];
                ch = (char)(ch | (char)(byteValue & 0x3F));
                cArray[outIndex++] = ch;
                continue;
            }
            if (index >= inputLength - 2) continue;
            ch = (char)((char)(byteValue & 0xF) << 12);
            byteValue = byArray[++index];
            ch = (char)(ch | (char)(byteValue & 0x3F) << 6);
            byteValue = byArray[++index];
            ch = (char)(ch | (char)(byteValue & 0x3F));
            cArray[outIndex++] = ch;
        }
        return new String(cArray, 0, outIndex);
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x33A0;
        if (u[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = t[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])v.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    v.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/e/J", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Crafter.u[n3] = n4;
        }
        return u[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = Crafter.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/e/J" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (x[n4] != null) {
            return n4;
        }
        Object object = w[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 46;
            case 1 -> 11;
            case 2 -> 0;
            case 3 -> 53;
            case 4 -> 38;
            case 5 -> 49;
            case 6 -> 61;
            case 7 -> 63;
            case 8 -> 40;
            case 9 -> 47;
            case 10 -> 16;
            case 11 -> 58;
            case 12 -> 60;
            case 13 -> 51;
            case 14 -> 9;
            case 15 -> 18;
            case 16 -> 19;
            case 17 -> 44;
            case 18 -> 23;
            case 19 -> 29;
            case 20 -> 5;
            case 21 -> 25;
            case 22 -> 59;
            case 23 -> 8;
            case 24 -> 10;
            case 25 -> 2;
            case 26 -> 6;
            case 27 -> 42;
            case 28 -> 54;
            case 29 -> 24;
            case 30 -> 1;
            case 31 -> 27;
            case 32 -> 62;
            case 33 -> 15;
            case 34 -> 45;
            case 35 -> 14;
            case 36 -> 36;
            case 37 -> 39;
            case 38 -> 52;
            case 39 -> 17;
            case 40 -> 32;
            case 41 -> 57;
            case 42 -> 21;
            case 43 -> 56;
            case 44 -> 41;
            case 45 -> 43;
            case 46 -> 26;
            case 47 -> 35;
            case 48 -> 50;
            case 49 -> 37;
            case 50 -> 55;
            case 51 -> 4;
            case 52 -> 28;
            case 53 -> 22;
            case 54 -> 31;
            case 55 -> 33;
            case 56 -> 30;
            case 57 -> 12;
            case 58 -> 13;
            case 59 -> 34;
            case 60 -> 7;
            case 61 -> 3;
            case 62 -> 20;
            default -> 48;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        Crafter.x[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = w;
        w[0] = "vo{{\u0011z}o\u007f{:";
        objectArray[1] = ";V\u0013*Kd\u00014\u001a*Hd\u0003!";
        objectArray[2] = "h:Q/r[d:B";
        objectArray[3] = "LfPH$\"GfTH$a";
        objectArray[4] = "hPh^C'c_y\u0011>?pXpX";
        objectArray[5] = "\u001cRZ]\u0000\u001f\u0017RQ";
        objectArray[6] = "M0\n8\u0017\u0005M0\u001dd\u001b\nW{\u001dz\u001b\u001fP\nM'J";
        objectArray[7] = Long.TYPE;
        Crafter.x[7] = "java/lang/Long";
        objectArray[8] = "\\|\u001f*P\u000bU|\u001c*\\";
        objectArray[9] = ")\u0018q]\b] \u0018r]\b";
        objectArray[10] = ";Z\u0011lIp0U\u0000#(~;^\u0004y";
        objectArray[11] = Void.TYPE;
        Crafter.x[11] = "java/lang/Void";
        objectArray[12] = "_kp]3h*K{R\"'KEpY&}?";
        objectArray[13] = "c\u0000!3:Ih\u0000)";
        objectArray[14] = "g..{\f!\u0012\u000e%t\u001dns\u0000.\u007f\u00194\u0007";
        objectArray[15] = "\u0000J\u0000T\nj\t\u0016A$_W\u001d\u001f\f\u0015Dg\u0012FL";
        objectArray[16] = "\u0000'Qf.u\t{\u0010\u0016wHUyYn|7\u0005kY}\u001eq\u0002nXta!\u0010nK\u0016";
        objectArray[17] = "\u0018r4<R!\u0011.uL\u0005\u001cI)#|\u0010p\u0015'*2";
        objectArray[18] = "tzp(\u0017k7io#l1N\">}\\0*c?{\u0002[";
        objectArray[19] = "~(g\u0007!\u0014%3`\u000fQ\u0000Eeo\u0015;\r:50Ph";
        objectArray[20] = "f\u0012lm <oN-\u001dv\u00017Fof)d7Mf%";
        objectArray[21] = "1O6 _\u007f?Jsq<\u007f\u000f\b4}NwfFvwA\u00160Ei*F{v[qs<";
        objectArray[22] = "_A\u0006E+\u0002QDC\u0014H\u0002a\u0006\u0004\u0018:\n\bHF\u00125k";
        objectArray[23] = "\u00114\u0003TVMJ/\u0004\\&T*t\u0015A]UH~TUK0\u00157\u000e\\\\]S)\u0016\u0005&";
        objectArray[24] = "TV0pRmZSu!1nj\u001ftgJa\b\u00155s\\\u0004TV0pRmZSu!1";
        Object[] objectArray2 = objectArray;
        objectArray[25] = "g\u0001#z\"0*\u001ab>Z\f\u0011>[JZb3Xc~9/(\u0019'";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = Crafter.e(l2, l3);
            object = w[n2];
            try {
                if (!(object instanceof String)) break block2;
                Crafter.w[n2] = clazz = Class.forName(x[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = Crafter.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int index = 0; index < classArray.length; ++index) {
                field = Crafter.d(classArray[index], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = Crafter.e(l2, l3);
        Object object = w[n2];
        if (object instanceof String) {
            String string = x[n2];
            int n3 = string.indexOf(8);
            Class clazz = Crafter.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = Crafter.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = Crafter.c(clazz3, string2, clazz2)) != null) {
                    Crafter.w[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int index = 0; index < classArray.length; ++index) {
                        field = Crafter.d(classArray[index], string2, clazz2);
                        if (field == null) continue;
                        Crafter.w[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = Crafter.f(720165598067370L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int parameterCount, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != parameterCount) continue;
            for (int index = 0; index < parameterCount; ++index) {
                if (classArray2[index] != classArray[index]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int parameterCount, Class[] classArray) {
        Method method = Crafter.c(clazz, string, clazz2, parameterCount, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int index = 0; index < classArray2.length; ++index) {
                method = Crafter.d(classArray2[index], string, clazz2, parameterCount, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = Crafter.e(l2, l3);
        Object object = w[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = x[n2];
                int n4 = string2.indexOf(8);
                clazz3 = Crafter.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int paramIndex = 0; paramIndex < n6; ++paramIndex) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = Crafter.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (paramIndex < n3) {
                        classArray2[paramIndex] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = Crafter.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        Crafter.w[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = Crafter.f(720165598067370L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = Crafter.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        Crafter.w[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = Crafter.f(720165598067370L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == 'Z' || c2 == '\u00d8' || c2 == '\u00e0' || c2 == 'E') {
                field = Crafter.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == 'Z' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == '\u00d8' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == '\u00e0' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = Crafter.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == 'g' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == 't' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = Crafter.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/e/J" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Crafter.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(Crafter.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

