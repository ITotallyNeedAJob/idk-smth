// === Kuzi module: AutoMine ===
// Category   : WORLD
// Description: Breaks the block you are looking at with randomised timing.
// Payload    : a.a.a.j.e.B (verified: True)

package kuzi.modules.world;

import java.lang.invoke.LambdaMetafactory;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Random;
import java.util.function.Supplier;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.module.Module;
import kuzi.obf.h.b.k;
import kuzi.obf.j.e.am;
import kuzi.obf.m.r;
import kuzi.obf.p.aA;
import kuzi.obf.p.ah;
import kuzi.obf.p.l_0;
import kuzi.obf.p.m;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.InteractionHand;
import net.minecraft.BlockGetter;
import net.minecraft.Block;
import net.minecraft.BlockPos;
import net.minecraft.Direction;
import net.minecraft.HitResult;
import net.minecraft.Vec3;
import net.minecraft.BlockState;
import net.minecraft.Minecraft;
import net.minecraft.BlockHitResult;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class AutoMine
extends BaseModule
implements Module {
    private final k startDelay;
    private final SliderSetting skipChance;
    private final BoolSetting veinMine;
    private final SliderSetting veinRadius;
    private final BoolSetting rotate;
    private final BoolSetting silentRotate;
    private final SliderSetting rotationSpeed;
    private final SliderSetting pauseRadius;
    private final SliderSetting minDurability;
    private final BoolSetting stopWhenFull;
    private final BoolSetting stopInCombat;
    private final Random random;
    private BlockPos targetPos;
    private Direction targetDirection;
    private long startTime;
    private BlockPos lastMinedPos;
    private BlockPos veinOrigin;
    private Block veinBlock;
    private static final long E = 125396049347304L;
    private static final Object[] L = new Object[]{"R)l@{\u0010Y)h@X", ">\u0015\u0006^])K5\rQLf*;\u0006ZH<^", Void.TYPE, "\u0012Nu4.\n\u0019N~", "5ji\u000bVW5j~WZX/!~IZM(P.\u0014\u000b", "x7g+r\u0016s7c+rU", "v\u0000K:\u0015d}\u000fZuh|n\bS<", "nmE4\u001ff\u007fmEr", ">x)\u0007<75w8H]9>|<\u0012", "4~:O\u001b\u00128~)", "ksh\u000bE\u0018ks\u007fWI\u0017q8\u007fII\u0002vI.\u0017\u001cI", "]\f$K\u0007\u0003(,/D\u0016LI\"$O\u0012\u0016=", Boolean.TYPE, "\u0013h4+\u0017W\u001ah7+\u001b", "n\u000eut\u000bLg\u000evt\u000b", "f\u000ez-\\%f\u000emqP*|EmoP?{4<0\u0002t", "jGg\u001a\u0018}{Gj", "\n\u0006\u000fN\u0003\u0018\u0014\u000e\u0015\u0001K\u0018\u000e\u0004\rFB\u0003N4\f_]\u0001\t\u0002\u000b", Double.TYPE, "jar\u0002g3{a~", "+\u001fwi\\l5\u0017m& x/\u001ane", "bMW]\u000fJ\u0017m\\R\u001e\u0005vcWY\u001a_\u0002", Long.TYPE, "@k24H'5K9;YhTE20]2 ", "Q)|@\u001erX)\u007f@\u001c", "R\u0013s\n\u0016\r'3x\u0005\u0007BF=s\u000e\u0003\u00182", "P&i'0)P&~{<&Jm~e<3M\u001c/:hp", ")0eK'E\\\u0010nD6\n=\u001eeO2PI", "\u0013J\b?Wl\u001aJ\u000b?]", "`\\n\u007f\r\u001b\u0015|ep\u001cTtrn{\u0018\u000e\u0000", "\u0010eZLgPeEQCv\u001f\u0004KZHrEp", "@aPHaB5A[Gp\rTOPLtW ", "9~Ksx\u00182~C", "U@],\u0004\u0019 `V#\u0015VAn](\u0011\f5", "!B=h\u0004\u00020B=\u0007", "\u0004>\u001byf\u0011q\u001e\u0010vw^\u0010\u0010\u001b}s\u0004d", "g,N)b'g,Yun(}gYkn=z\u0016\u000b1:y", "\u0006\u0002\u0012QP\u001a\r\u0014G+cdVCJDQ\u0016S\bA\u0013", "H\u001c\u007f=LEC\n*GN;\u0016\u000b::JJU\\%}", ",2AUEo'$\u0014/Q\u0011$#COP.r)\u0000\u0011:(\"}G_\u0004)3~\u001c/", "\u0012\u001aMDef\u0019\f\u0018>|\u0018L\r\bCci\u000fZ\u0017\u0004", "emV\u001a\u0016rn{\u0003`\u0007\fm|T\u0000\u00033;v\u0017^i<sn[\u000e\u0006n:v\u0017`", "L>\u0017d)-G(B\u001e8SM%Q//,\u001e.\u001bpVjBq\u0011nhkSrJ\u001e", "Kc\u0002rj]\u0014{Co\f]vd[7l\\I2Qt26FzI8bY\u00143Qt\f", "\u000fEa\"H6\u0004S4X^H\u0007Tc8]wQ^ f7x\u0019Fl6X*P^ X", "u8\n}#\u0011~._\u0007#ou/Qnb\u0011+xFl", "RJ\u001eM<m\rR_PZmo\u0017@\u0006&j\u0004QLO%\u0006VK\u0019\f*8WZ\u001aWZ", ",\u0010\rND\u001cz\u0010B\u0003&EKI\u001dLFFt\u001f\u0017\u000f\u0018,,_\u001fH\u0019T-L\u000f\u0017&", "89F\fi\u00063/\u0013v\u007fx0(D\u0016|Gf\"\u0007H\u0016\u0012o)D\u0006+\u0002:#\u0004v", "7{\u0010n9\u00153}\n+REUs\u0012m2Dj%\u0018.l.>h\f0)\u0010-/L>R", "}86m\u0004Wv.c\u0017\u0012)u)4w\u0011\u0016##w){\u0010sw0gE\u0011btk\u0017", "yC*p%\"0B<yG-H\u000e#);(#H/`8D", "oW3>\u001fta\r#tg@B<\u000f\u0007#\u0006oW3>\u001fta\r#t", "_\u0006\u0003\u0015#2T\u0010Vo5L\u000e\u0015\u0002\u0016!,\t\u001aQ\n\\rRJF\u0012<u]\u0019Zo", "|=9v \u0016#%xkF\u0014A`g=:\u0011*&kt9}+ly}>\u000f%6i7F\u0016}lgd%\u00008lc\r-\u0001?>{3>F\u007f0\u0000a)F%l0jv\f-]kq8\u001e:cx6x\u0010Amy\u007fw\u0013.?0g;}q$r<(\u0012#mjpFD c:}xE1`a\r", "Z|,\u0004;iQjy~-\u0017Rm.\u001e.(\u0004gm@DvZ|r\u001d-*H1u~", "d\u0017\u007fw\"8e\u0007jkK)^B<a4~=Fm|)", "$\u0015B\u0001\u0001-\u007f\u0000[\u0017zw\u001f[F\u0002\u000b\"e\u001d\u0001\u0017\u001e\u001d", "n\u0015v\\>7e\u0003#&1Im\u0016wK3,d\u0003/X", "\u000b=t\u001f\u0005U\u0000+!e\u0006+U*1\u0018\u0003Z\u0016}._", "Mu\">c4FcwDVJH<\u007fzlwXiu:", "\u0016M6Gi(\u001d[c=lV\u0016ZmT((H\rzV", "D?\u0000\u0011\u0019\u001cO)Uk\u001db\u001a(E\u0016\u001f\u0013Y\u007fZQ", ",B<;M\u0006'TiA{x-YzpK\u0007~R0/", "\fH~o?JTK2tTp.-H@TJV\u0005og1\u0012UIt", "{O!d!dpYt\u001e;\u001avQ\u007f#5!rWef", "[=\u0018S\u00135P+M)\u000bK[*C@R5\u0005}TB", "`3kJH-k%>0FSez6\u000eGnu/<N", "2\u0018@[039\u000e\u0015!6M2\u000f\u001bHq3lX\fJ", "\t\u0007F:\u001c\n\u0002\u0011\u0013@\u001btW\u0010\u0003=\u001a\u0005\u0014G\u001cz", "8(o\u0004*\n3>:~?t09m\u001e?Kf3.@U\u001eo8m\u000eh\u000e:2-~", "\u001e\u0016\u0016(a\u001c\u0015I\\ Pw7>j\u0010\u0010,\u001e\u0016\u0016(a\u001c\u0015I\\ ", "K\u0014\u000b,S]@\u0002^VR#K\u0003P?\u0012]\u0015TG=", "c=&x *h+s\u0002\u0014Tft{</iv!q|", "\u007f6@:dqt \u0015@i\u000fq(\r\"xf-:@%", "\u0004D\"3$z\u0005T7/Mf>M9|-h\u0001\u001b3?s\u0002\u0007Kgx=<\u0006Zd#M"};
    private static final String[] M = new String[]{null, null, "java/lang/Void", null, null, null, null, null, null, null, null, null, "java/lang/Boolean", null, null, null, null, null, "java/lang/Double", null, null, null, "java/lang/Long", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null};

    public AutoMine() {
        long l2 = E ^ 0x4DD1365E008BL;
        long l3 = l2 ^ 0x1E3E37D9D976L;
        super("AutoMine", "Breaks the block you are looking at with randomised timing.", Category.WORLD);
        this.startDelay = new k("Start Delay", 0.0, 1000.0, 10.0, 90.0, 280.0);
        this.skipChance = new SliderSetting("Skip Chance", 8.0, 0.0, 40.0, 1.0);
        this.veinMine = new BoolSetting("Vein Mine", true);
        this.veinRadius = new SliderSetting("Vein Radius", 2.0, 1.0, 4.0, 1.0);
        this.rotate = new BoolSetting("Rotate", true);
        this.silentRotate = new BoolSetting("Silent Rotate", true);
        this.rotationSpeed = new SliderSetting("Rotation Speed", 4.0, 1.0, 20.0, 0.5);
        this.pauseRadius = new SliderSetting("Pause Radius", 24.0, 0.0, 64.0, 1.0);
        this.minDurability = new SliderSetting("Min Durability", 10.0, 0.0, 100.0, 1.0);
        this.stopWhenFull = new BoolSetting("Stop When Full", true);
        this.stopInCombat = new BoolSetting("Stop In Combat", true);
        this.random = new Random();
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.startDelay, this.skipChance, this.veinMine, this.veinRadius, this.rotate, this.silentRotate, this.rotationSpeed, this.pauseRadius, this.minDurability, this.stopWhenFull, this.stopInCombat};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public boolean b(Object[] objectArray) {
        return true;
    }

    @Override
    public void d() {
        long l2 = E ^ 0x1981B68CE525L;
        long l3 = l2 ^ 0x448657389924L;
        Client.a().a(Module.class, this);
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.c(objectArray);
    }

    @Override
    public void e() {
        long l2;
        long l3 = l2 = E ^ 0xCFDAF6D850BL;
        long l4 = l3 ^ 0x32B2EC104E6FL;
        long l5 = l3 ^ 0x51FA4ED9F90AL;
        Client.a().b(Module.class, this);
        Object[] objectArray = new Object[1];
        objectArray[0] = l5;
        this.c(objectArray);
        BaseModule.a.execute(() -> this.f(l4));
    }

    @Override
    public void h() {
        long l2 = E ^ 0x5310AF183E15L;
        long l3 = l2 ^ 0xE174EAC4214L;
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.c(objectArray);
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    @Override
    public void b() {
        block35: {
            block36: {
                block31: {
                    block32: {
                        block34: {
                            block33: {
                                block28: {
                                    block29: {
                                        block30: {
                                            block26: {
                                                block27: {
                                                    v0 = var1_1 = AutoMine.E ^ 116973117086252L;
                                                    var3_2 = v0 ^ 92555176464712L;
                                                    var5_3 = v0 ^ 42634389833125L;
                                                    var7_4 = v0 ^ 82601358391161L;
                                                    var9_5 = v0 ^ 60907143292461L;
                                                    var11_6 = v0 ^ 89023291999112L;
                                                    var13_7 = v0 ^ 115668792050873L;
                                                    stringTable = am.b();
                                                    v1 = this;
                                                    if (stringTable != null) {
                                                        v2 = new Object[1];
                                                        v2[0] = var13_7;
                                                        if (!v1.f(v2)) {
                                                            this.f(var3_2);
                                                            v3 = new Object[1];
                                                            v3[0] = var9_5;
                                                            this.c(v3);
                                                            return;
                                                        }
                                                        v1 = this;
                                                    }
                                                    v4 = v1.targetPos;
                                                    if (stringTable == null) break block26;
                                                    if (v4 == null) break block27;
                                                    v5 = this;
                                                    if (stringTable == null) break block28;
                                                    v6 = new Object[2];
                                                    v6[1] = this.targetPos;
                                                    v6[0] = var5_3;
                                                    if (v5.a(v6)) break block29;
                                                }
                                                v7 = this;
                                                if (stringTable == null) break block30;
                                                v4 = v7.targetPos;
                                            }
                                            if (v4 != null && BaseModule.a.level.getBlockState(this.targetPos).isAir()) {
                                                this.veinOrigin = this.targetPos;
                                            }
                                            v7 = this;
                                        }
                                        v8 = new Object[1];
                                        v8[0] = var11_6;
                                        v7.a(v8);
                                    }
                                    v5 = this;
                                }
                                v9 /* !! */  = v5.targetPos;
                                if (stringTable != null) {
                                    if (v9 /* !! */  == null) {
                                        this.f(var3_2);
                                        return;
                                    }
                                    v9 /* !! */  = this.rotate.a();
                                }
                                v10 = ((Boolean)v9 /* !! */ ).booleanValue();
                                if (stringTable != null) {
                                    if (v10 != 0) {
                                        var16_9 = this.targetPos;
                                        ah.a(this, l_0.NORMAL, (Supplier<Vec3>)LambdaMetafactory.metafactory(null, null, null, ()Ljava/lang/Object;, lambda$onTick2$0(net.minecraft.BlockPos ), ()Lnet/minecraft/Vec3;)((BlockPos)var16_9), (Double)this.rotationSpeed.a(), kuzi.obf.p.m.SMOOTH, 0.0, (Boolean)this.silentRotate.a(), false);
                                        v11 = new Object[2];
                                        v11[1] = Float.valueOf(2.5f);
                                        v11[0] = var7_4;
                                        v10 = (int)ah.c(v11);
                                        if (stringTable != null) {
                                            if (v10 == 0) {
                                                return;
                                            } else {
                                                ** GOTO lbl-1000
                                            }
                                        }
                                    } else lbl-1000:
                                    // 3 sources

                                    {
                                        v10 = (cfr_temp_0 = System.currentTimeMillis() - this.startTime) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1);
                                    }
                                }
                                if (stringTable != null) {
                                    if (v10 < 0) {
                                        return;
                                    }
                                    v10 = this.random.nextInt(100);
                                }
                                if (stringTable != null) {
                                    if (v10 < ((Double)this.skipChance.a()).intValue()) {
                                        return;
                                    }
                                    v10 = (int)this.targetPos.equals((Object)this.lastMinedPos);
                                }
                                if (stringTable == null) break block31;
                                if (v10 != 0) break block32;
                                v12 = BaseModule.a;
                                if (stringTable == null) break block33;
                                if (!v12.gameMode.startDestroyBlock(this.targetPos, this.targetDirection)) break block34;
                                v12 = BaseModule.a;
                            }
                            v12.player.swing(InteractionHand.MAIN_HAND);
                        }
                        this.lastMinedPos = this.targetPos;
                        if (stringTable != null) break block35;
                    }
                    v13 = BaseModule.a;
                    if (stringTable == null) break block36;
                    v10 = (int)v13.gameMode.continueDestroyBlock(this.targetPos, this.targetDirection);
                }
                if (v10 == 0) break block35;
                v13 = BaseModule.a;
            }
            v13.player.swing(InteractionHand.MAIN_HAND);
        }
    }

    private void a(Object[] objectArray) {
        block21: {
            BlockPos blockPos;
            block19: {
                long l2;
                long l3;
                long l4;
                block20: {
                    AutoMine module;
                    Object object;
                    block18: {
                        String guardCopy;
                        String stringTable;
                        long l5;
                        long l6;
                        block17: {
                            long l7;
                            long l8;
                            block15: {
                                block16: {
                                    block11: {
                                        AutoMine moduleRef;
                                        long l9;
                                        block14: {
                                            String guard;
                                            block12: {
                                                block13: {
                                                    block10: {
                                                        l4 = (Long)objectArray[0];
                                                        long l10 = l4 = E ^ l4;
                                                        l8 = l10 ^ 0x5D334DBCB94FL;
                                                        l6 = l10 ^ 0x2949204D7F44L;
                                                        l7 = l10 ^ 0x159E5FEBE74DL;
                                                        l9 = l10 ^ 0x34973BA8B46FL;
                                                        l5 = l10 ^ 0x611174C24C31L;
                                                        blockPos = null;
                                                        stringTable = am.b();
                                                        moduleRef = this;
                                                        if (stringTable == null) break block10;
                                                        if (!((Boolean)moduleRef.o.a()).booleanValue()) break block11;
                                                        moduleRef = this;
                                                    }
                                                    guard = stringTable;
                                                    if (l4 < 0L) break block12;
                                                    if (guard == null) break block13;
                                                    if (moduleRef.veinOrigin == null) break block11;
                                                    moduleRef = this;
                                                }
                                                guard = stringTable;
                                            }
                                            if (guard == null) break block14;
                                            if (moduleRef.veinBlock == null) break block11;
                                            moduleRef = this;
                                        }
                                        Object[] objectArray2 = new Object[1];
                                        objectArray2[0] = l9;
                                        object = blockPos = moduleRef.a(objectArray2);
                                        guardCopy = stringTable;
                                        if (l4 < 0L) break block15;
                                        if (guardCopy == null) break block16;
                                        if (object == null) {
                                            this.veinOrigin = null;
                                            this.veinBlock = null;
                                        }
                                    }
                                    object = blockPos;
                                }
                                guardCopy = stringTable;
                            }
                            if (l4 < 0L) break block17;
                            if (guardCopy != null) {
                                if (object == null) {
                                    Object[] objectArray3 = new Object[1];
                                    objectArray3[0] = l8;
                                    blockPos = this.b(objectArray3);
                                }
                                Object[] objectArray4 = new Object[1];
                                objectArray4[0] = l7;
                                this.c(objectArray4);
                                object = blockPos;
                            }
                            if (l4 <= 0L) break block18;
                            guardCopy = stringTable;
                        }
                        if (guardCopy == null) break block18;
                        if (object == null) {
                            return;
                        }
                        this.targetPos = blockPos;
                        Object[] objectArray5 = new Object[2];
                        objectArray5[1] = blockPos;
                        objectArray5[0] = l5;
                        this.targetDirection = this.a(objectArray5);
                        module = this;
                        Object[] objectArray6 = new Object[1];
                        objectArray6[0] = l6;
                        l3 = System.currentTimeMillis() + (long)this.startDelay.c(objectArray6);
                        l2 = -2761888358635885896L;
                        if (l4 < 0L) break block19;
                        module.startTime = l3;
                        module = this;
                        if (stringTable == null) break block20;
                        object = module.o.a();
                    }
                    if (!((Boolean)object).booleanValue()) break block21;
                    this.veinOrigin = blockPos;
                    module = this;
                }
                l3 = -2762393857767755819L;
                l2 = l4;
            }
            module.veinBlock = BaseModule.a.level.getBlockState(blockPos).getBlock();
        }
    }

    private BlockPos a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = (l2 = E ^ l2) ^ 0x42A6F5B3B242L;
        int radius = ((Double)this.veinRadius.a()).intValue();
        for (BlockPos blockPos : BlockPos.withinManhattan((BlockPos)this.veinOrigin, (int)radius, (int)radius, (int)radius)) {
            if (l2 >= 0L) {
                Object[] objectArray2 = new Object[2];
                objectArray2[1] = blockPos;
                objectArray2[0] = l3;
                if (!this.a(objectArray2)) continue;
            }
            if (BaseModule.a.level.getBlockState(blockPos).getBlock() != this.veinBlock) continue;
            return blockPos.immutable();
        }
        return null;
    }

    private BlockPos b(Object[] objectArray) {
        HitResult hitResult;
        long l2;
        block4: {
            HitResult hit;
            block5: {
                block3: {
                    String stringTable;
                    block2: {
                        long l3 = (Long)objectArray[0];
                        l2 = (l3 = E ^ l3) ^ 0x2B0283A7BF62L;
                        hit = BaseModule.a.hitResult;
                        stringTable = am.b();
                        hitResult = hit;
                        if (stringTable == null) break block2;
                        if (hitResult == null) break block3;
                        hitResult = hit;
                    }
                    if (stringTable == null) break block4;
                    if (hitResult.getType() == HitResult.mc240.BLOCK) break block5;
                }
                return null;
            }
            hitResult = hit;
        }
        BlockPos blockPos = ((BlockHitResult)hitResult).getBlockPos();
        Object[] objectArray2 = new Object[2];
        objectArray2[1] = blockPos;
        objectArray2[0] = l2;
        return this.a(objectArray2) ? blockPos : null;
    }

    private boolean a(Object[] objectArray) {
        String stringTable;
        BlockPos blockPos;
        block15: {
            boolean bl;
            block14: {
                Minecraft mc;
                long l2;
                block12: {
                    block13: {
                        block11: {
                            block10: {
                                l2 = (Long)objectArray[0];
                                blockPos = (BlockPos)objectArray[1];
                                l2 = E ^ l2;
                                stringTable = am.b();
                                mc = BaseModule.a;
                                if (stringTable == null) break block10;
                                if (mc.level == null) break block11;
                                mc = BaseModule.a;
                            }
                            if (stringTable == null) break block12;
                            if (mc.player != null) break block13;
                        }
                        return false;
                    }
                    mc = BaseModule.a;
                }
                BlockState blockState = mc.level.getBlockState(blockPos);
                bl = blockState.isAir();
                String guard = stringTable;
                if (l2 > 0L) {
                    if (guard != null) {
                        if (bl) {
                            return false;
                        }
                        float destroySpeed = blockState.getDestroySpeed((BlockGetter)BaseModule.a.level, blockPos) - 0.0f;
                        bl = destroySpeed == 0.0f ? 0 : (destroySpeed < 0.0f ? -1 : 1);
                    }
                    guard = stringTable;
                }
                if (guard == null) break block14;
                if (bl >= false) break block15;
                bl = false;
            }
            return bl;
        }
        double interactionRange = BaseModule.a.player.blockInteractionRange();
        double d4 = blockPos.getCenter().distanceToSqr(BaseModule.a.player.getEyePosition()) - interactionRange * interactionRange;
        d4 = d4 == 0.0 ? 0 : (d4 < 0.0 ? -1 : 1);
        if (stringTable != null) {
            d4 = d4 <= 0 ? 1.0 : 0.0;
        }
        return (boolean)d4;
    }

    private Direction a(Object[] objectArray) {
        BlockHitResult mc39652;
        BlockPos blockPos;
        block5: {
            HitResult hitResult;
            block4: {
                long l2 = (Long)objectArray[0];
                blockPos = (BlockPos)objectArray[1];
                l2 = E ^ l2;
                HitResult hit = BaseModule.a.hitResult;
                String stringTable = am.b();
                hitResult = hit;
                if (stringTable == null) break block4;
                if (!(hitResult instanceof BlockHitResult)) break block5;
                hitResult = hit;
            }
            if (blockPos.equals((Object)(mc39652 = (BlockHitResult)hitResult).getBlockPos())) {
                return mc39652.getDirection();
            }
        }
        mc39652 = BaseModule.a.player.getEyePosition().subtract(blockPos.getCenter());
        return Direction.getApproximateNearest((Vec3)mc39652);
    }

    /*
     * Unable to fully structure code
     */
    private boolean f(Object[] var1_1) {
        block63: {
            block64: {
                block62: {
                    block57: {
                        block61: {
                            block58: {
                                block59: {
                                    block60: {
                                        block56: {
                                            block53: {
                                                block54: {
                                                    block55: {
                                                        block52: {
                                                            block51: {
                                                                block48: {
                                                                    block49: {
                                                                        block50: {
                                                                            block45: {
                                                                                block46: {
                                                                                    block47: {
                                                                                        block44: {
                                                                                            var2_2 = (Long)var1_1[0];
                                                                                            var4_3 = (var2_2 = AutoMine.E ^ var2_2) ^ 123636304465121L;
                                                                                            stringTable = am.b();
                                                                                            mc = BaseModule.a;
                                                                                            if (stringTable == null) break block44;
                                                                                            if (mc.player == null) break block45;
                                                                                            mc = BaseModule.a;
                                                                                        }
                                                                                        v1 = stringTable;
                                                                                        if (var2_2 < 0L) break block46;
                                                                                        if (v1 == null) break block47;
                                                                                        if (mc.level == null) break block45;
                                                                                        mc = BaseModule.a;
                                                                                    }
                                                                                    v1 = stringTable;
                                                                                }
                                                                                if (var2_2 <= 0L) break block48;
                                                                                if (v1 == null) break block49;
                                                                                if (mc.gameMode != null) break block50;
                                                                            }
                                                                            return false;
                                                                        }
                                                                        mc = BaseModule.a;
                                                                    }
                                                                    if (var2_2 <= 0L) break block51;
                                                                    v1 = stringTable;
                                                                }
                                                                if (v1 == null) break block51;
                                                                if (mc.screen != null) break block52;
                                                                mc = BaseModule.a;
                                                            }
                                                            v2 = mc.player.isSpectator();
                                                            v3 = stringTable;
                                                            if (var2_2 <= 0L) break block53;
                                                            if (v3 == null) break block54;
                                                            if (v2 == 0) break block55;
                                                        }
                                                        return false;
                                                    }
                                                    cfr_temp_0 = (Double)this.pauseRadius.a() - 0.0;
                                                    v2 = cfr_temp_0 == 0.0 ? 0 : (cfr_temp_0 > 0.0 ? 1 : -1);
                                                }
                                                v3 = stringTable;
                                            }
                                            if (var2_2 <= 0L) break block56;
                                            if (v3 != null) {
                                                if (v2 > 0) {
                                                    v4 = new Object[5];
                                                    v4[4] = true;
                                                    v4[3] = false;
                                                    v4[2] = var4_3;
                                                    v4[1] = Float.valueOf(((Double)this.pauseRadius.a()).floatValue());
                                                    v4[0] = BaseModule.a.player;
                                                    v5 = aA.a(v4);
                                                    if (stringTable != null) {
                                                        if (v5 != null) {
                                                            return false;
                                                        } else {
                                                            ** GOTO lbl-1000
                                                        }
                                                    }
                                                } else lbl-1000:
                                                // 3 sources

                                                {
                                                    v5 = this.stopInCombat.a();
                                                }
                                                v2 = (int)((Boolean)v5).booleanValue();
                                            }
                                            if (var2_2 <= 0L) break block57;
                                            v3 = stringTable;
                                        }
                                        if (v3 == null) break block57;
                                        if (v2 == 0) break block58;
                                        v6 = BaseModule.a.player.hurtTime;
                                        if (stringTable == null) break block59;
                                        if (v6 > 0) break block60;
                                        v7 = BaseModule.a.player.getLastHurtByMob();
                                        if (var2_2 < 0L || stringTable == null) break block61;
                                        if (v7 == null) break block58;
                                    }
                                    v6 = 0;
                                }
                                return (boolean)v6;
                            }
                            v7 = this.stopWhenFull.a();
                        }
                        v8 = (Boolean)v7;
                        if (stringTable == null) break block62;
                        v2 = (int)v8.booleanValue();
                    }
                    if (v2 != 0) {
                        v8 = BaseModule.a.player.getInventory();
                        if (stringTable != null) {
                            if (v8.getFreeSlot() == -1) {
                                return false;
                            } else {
                                ** GOTO lbl-1000
                            }
                        }
                    } else lbl-1000:
                    // 3 sources

                    {
                        v8 = this.minDurability.a();
                    }
                }
                var7_5 = (Double)v8;
                cfr_temp_1 = var7_5 - 0.0;
                v9 = cfr_temp_1 == 0.0 ? 0 : (cfr_temp_1 > 0.0 ? 1 : -1);
                if (stringTable == null) break block63;
                if (v9 <= 0) break block64;
                var9_6 = BaseModule.a.player.getMainHandItem();
                v9 = (double)var9_6.isDamageableItem();
                if (stringTable == null) break block63;
                if (v9 == false) break block64;
                v9 = var9_6.getMaxDamage();
                if (stringTable != null) {
                    if (v9 > 0) {
                        var10_7 = 100.0 * (double)(var9_6.getMaxDamage() - var9_6.getDamageValue()) / (double)var9_6.getMaxDamage();
                        v9 = var10_7 == var7_5 ? 0 : (var10_7 < var7_5 ? -1 : 1);
                        if (stringTable != null) {
                            if (v9 < 0) {
                                return false;
                            } else {
                                ** GOTO lbl114
                            }
                        } else {
                            ** GOTO lbl113
                        }
                    } else {
                        ** GOTO lbl112
                    }
                }
                break block63;
lbl112:
                // 2 sources

                break block64;
lbl113:
                // 2 sources

                break block63;
            }
            v9 = (double)true;
        }
        return (boolean)v9;
    }

    private void c(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = E ^ l2;
        this.targetPos = null;
        this.targetDirection = null;
        this.lastMinedPos = null;
    }

    private void f(long l2) {
        l2 = E ^ l2;
        String stringTable = am.b();
        if (stringTable != null) {
            if (BaseModule.a.gameMode != null) {
                BaseModule.a.gameMode.stopDestroyBlock();
            }
            ah.c(this);
        }
    }

    private static Vec3 lambda$onTick2$0(BlockPos blockPos) {
        return blockPos.getCenter();
    }

    private static r a(r r2) {
        return r2;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = AutoMine.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = AutoMine.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = AutoMine.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = AutoMine.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }
}

