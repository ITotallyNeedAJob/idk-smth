// === Kuzi module: ItemESP ===
// Category   : WORLD
// Description: Clean labels over dropped items (icon + name + count)
// Payload    : a.a.a.j.g.X (verified: True)

package kuzi.modules.world;

import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.mixin.MixinExposed;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.b.e;
import kuzi.obf.h.b.v;
import kuzi.obf.j.g.aD;
import kuzi.obf.m.r;
import kuzi.obf.p.ac_0;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.Entity;
import net.minecraft.ItemEntity;
import net.minecraft.ItemStack;
import net.minecraft.AABB;
import net.minecraft.Vec3;
import net.minecraft.Minecraft;
import net.minecraft.Font;
import net.minecraft.GuiGraphics;
import net.minecraft.Mth;

public class ItemESP
extends BaseModule {
    public final SliderSetting range;
    public final SliderSetting scale;
    public final BoolSetting icon;
    public final BoolSetting name;
    public final BoolSetting count;
    public final e r;
    public final e s;
    public final e t;
    private static final long u;
    private static final String[] v;
    private static final String[] w;
    private static final Map x;
    private static final long[] y;
    private static final Integer[] z;
    private static final Map A;
    private static final Object[] B;
    private static final String[] C;

    public ItemESP() {
        long l2 = u ^ 0x1F171D21E98BL;
        long l3 = l2 ^ 0x784AC289F0B1L;
        super("ItemESP", "Clean labels over dropped items (icon + name + count)", Category.WORLD);
        this.range = new SliderSetting("Range", 128.0, 10.0, 512.0, 10.0);
        this.scale = new SliderSetting("Scale", 1.0, 0.3, 3.0, 0.05);
        this.icon = new BoolSetting("Icon", true);
        this.name = new BoolSetting("Name", true);
        this.count = new BoolSetting("Count", true);
        this.r = new e("Background", new Color(0, 0, 0, 150));
        this.s = new e("Name Color", new Color(255, 255, 255));
        this.t = new e("Count Color", new Color(120, 210, 120));
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.range, this.scale, this.icon, this.name, this.count, this.r, this.s, this.t};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @MixinExposed
    public void a(GuiGraphics graphics, float delta) {
        Object object;
        Minecraft mc;
        int[] nArray;
        long l2;
        long l3;
        block9: {
            block10: {
                block8: {
                    Minecraft mcAlias;
                    block7: {
                        long l4;
                        long l5 = l4 = u ^ 0x36FD689076E8L;
                        l3 = l5 ^ 0x7E442ACD140CL;
                        l2 = l5 ^ 0x123407999469L;
                        nArray = aD.b();
                        if (!this.d()) {
                            return;
                        }
                        mcAlias = mc = Minecraft.getInstance();
                        if (nArray == null) break block7;
                        if (mcAlias.level == null) break block8;
                        mcAlias = mc;
                    }
                    object = mcAlias.player;
                    if (nArray == null) break block9;
                    if (object != null) break block10;
                }
                return;
            }
            object = this.range.a();
        }
        double rangeValue = (Double)object;
        double rangeSquared = rangeValue * rangeValue;
        AABB searchBox = mc.player.getBoundingBox().inflate(rangeValue);
        Font font = mc.font;
        float scaleValue = ((Double)this.scale.a()).floatValue();
        Iterator iterator = mc.level.getEntitiesOfClass(ItemEntity.class, searchBox, ItemESP::lambda$render$0).iterator();
        while (iterator.hasNext()) {
            ItemStack stack;
            ItemEntity itemEntity;
            ItemEntity itemEntity2 = itemEntity = (ItemEntity)iterator.next();
            if (nArray != null) {
                if (itemEntity2.distanceToSqr((Entity)mc.player) > rangeSquared) continue;
                itemEntity2 = itemEntity;
            }
            if ((stack = itemEntity2.getItem()).isEmpty()) continue;
            Vec3 labelPos = new Vec3(Mth.lerp((double)delta, (double)itemEntity.xOld, (double)itemEntity.getX()), Mth.lerp((double)delta, (double)itemEntity.yOld, (double)itemEntity.getY()) + 0.55, Mth.lerp((double)delta, (double)itemEntity.zOld, (double)itemEntity.getZ()));
            Object[] objectArray = new Object[2];
            objectArray[1] = l3;
            objectArray[0] = labelPos;
            float[] screenPos = ac_0.a(objectArray);
            if (nArray != null) {
                if (screenPos == null) continue;
                Object[] objectArray2 = new Object[7];
                objectArray2[6] = Float.valueOf(screenPos[1]);
                objectArray2[5] = Float.valueOf(screenPos[0]);
                objectArray2[4] = stack;
                objectArray2[3] = Float.valueOf(scaleValue);
                objectArray2[2] = font;
                objectArray2[1] = graphics;
                objectArray2[0] = l2;
                this.a(objectArray2);
            }
            if (nArray != null) continue;
        }
    }

    /*
     * Exception decompiling
     */
    private void a(Object[] var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Statement already marked as first in another block
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.markFirstStatementInBlock(Op03SimpleStatement.java:461)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc.markWholeBlock(Misc.java:251)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.considerAsSimpleIf(ConditionalRewriter.java:673)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.identifyNonjumpingConditionals(ConditionalRewriter.java:56)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:722)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private static boolean lambda$render$0(ItemEntity mc15422) {
        return true;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block21: {
            block20: {
                block19: {
                    block18: {
                        ItemESP.u = kuzi.obf.h.b.v.a(-3412260682851430735L, 8769292154743271975L, MethodHandles.lookup().lookupClass()).a(35452465579743L);
                        ItemESP.B = new Object[36];
                        ItemESP.C = new String[36];
                        ItemESP.c();
                        ItemESP.x = new HashMap<K, V>(13);
                        var11 = ItemESP.u ^ 120770516489772L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[10];
                        var18_4 = 0;
                        var17_5 = "\u00e6O$\u00a04\u001e\u008f\u00bb\u00ce\u000b{9t<Y\u00fa\u0010\u00a9\u0093\u009e\u00ae\u00bd\u0081~LB\u00edRX\u00ed\u000b\u008c\u0088 \u00f6H\u0097\u00ac\u000f4\u0000\u00bd\u00be\u00ec\u008d\u00ae\u009f\u0006\u00af\u0098\u0090\u00dc\u00e1\u00a2\u009eG\u00e2\u00e2\u0087\u00ec\u001f\u0012m!T#\u0010\u0000&\u008a\"\u00bfA\u00f2e\u00fe\\\u008dj5\u00ae\u0012f\u0010'\u009aA\u00fa\u000e\u00d3\u00976Ccx]\u00f9\tm\u000f &\u0080D\u000e\u000bSIy\\\u00f8\u00eam\u00d8e/ZG\u009d?HWQ\u0002Cq\u0097\u00dcT|Cc\u00ae \u00f5\u000e\u00ce\u00be@\u00e5\u009f\u00f4f\u0081\u0084Z\u00c2u\u00b5e|\u00c0-e\u00d2\u00db\n\u0083\u00a6\u00d4\u00c7i3\u0082,\u008fP\u0013\u00caw3\u0091f\u00a9\\|\u00a4\u0006\u0003\u008c\u00f3\n0\u00bc\u009a\u00f7\u0099\u00e68\u00d8\u00ab6\b\u00a2IDYn\u00c2t3\u00b7(\u00d4\u00ce\u0086L}\u00e3Q\u00b0\u0016\u00f9\u00c0hJT]\u00be\u00d5\u00d4\u000e\u00ef\u00b9\u0004o\u0002\u0005J\u0093Q\u00da\u0085\u0085\u0088i\u00ef\u00c4\u00c5\u00c5\u0010h\u0090Yk\u0002\u00cf";
                        var19_6 = "\u00e6O$\u00a04\u001e\u008f\u00bb\u00ce\u000b{9t<Y\u00fa\u0010\u00a9\u0093\u009e\u00ae\u00bd\u0081~LB\u00edRX\u00ed\u000b\u008c\u0088 \u00f6H\u0097\u00ac\u000f4\u0000\u00bd\u00be\u00ec\u008d\u00ae\u009f\u0006\u00af\u0098\u0090\u00dc\u00e1\u00a2\u009eG\u00e2\u00e2\u0087\u00ec\u001f\u0012m!T#\u0010\u0000&\u008a\"\u00bfA\u00f2e\u00fe\\\u008dj5\u00ae\u0012f\u0010'\u009aA\u00fa\u000e\u00d3\u00976Ccx]\u00f9\tm\u000f &\u0080D\u000e\u000bSIy\\\u00f8\u00eam\u00d8e/ZG\u009d?HWQ\u0002Cq\u0097\u00dcT|Cc\u00ae \u00f5\u000e\u00ce\u00be@\u00e5\u009f\u00f4f\u0081\u0084Z\u00c2u\u00b5e|\u00c0-e\u00d2\u00db\n\u0083\u00a6\u00d4\u00c7i3\u0082,\u008fP\u0013\u00caw3\u0091f\u00a9\\|\u00a4\u0006\u0003\u008c\u00f3\n0\u00bc\u009a\u00f7\u0099\u00e68\u00d8\u00ab6\b\u00a2IDYn\u00c2t3\u00b7(\u00d4\u00ce\u0086L}\u00e3Q\u00b0\u0016\u00f9\u00c0hJT]\u00be\u00d5\u00d4\u000e\u00ef\u00b9\u0004o\u0002\u0005J\u0093Q\u00da\u0085\u0085\u0088i\u00ef\u00c4\u00c5\u00c5\u0010h\u0090Yk\u0002\u00cf".length();
                        var16_7 = 16;
                        var15_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block18;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = ItemESP.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "'\u00f3\u00e1\u00be\u000b\u0089\u00eb\u009f\u0087\u0013\u00d5\u00a68?\u00e5L\u0010`X9\u00cb\u0014\u0093\u00c5\u000b\u00d8\u00a1\u009e.HO}\u00ff";
                            var19_6 = "'\u00f3\u00e1\u00be\u000b\u0089\u00eb\u009f\u0087\u0013\u00d5\u00a68?\u00e5L\u0010`X9\u00cb\u0014\u0093\u00c5\u000b\u00d8\u00a1\u009e.HO}\u00ff".length();
                            var16_7 = 16;
                            var15_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block18;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = ItemESP.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block19;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                ItemESP.v = var20_3;
                ItemESP.w = new String[10];
                ItemESP.A = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[15];
                var3_13 = 0;
                var4_14 = "\u00d4\u0017;\u00cd.\u009e\n;\u0002\u00adc\u00f1\u000e\u00904\u00b2(\u00d1H\u0094\f\u00879/\u008e\u0010?\u0002\u000b\u00ebV\u00c6\u00b1|\u00ec~~\\q<B@\u00c3R\u0081H\u00965,U\u009a\u00047\u00e2\u00c7[\f\u00ca\u00c0[\u00ee\u00bc/\u0088'7\u0086\u00e4\u00bf\u0004\u00deO\u00a1\u00fa\u00d6X\u000e\u0081W\u0089]f\u000f&gRw4\u00a9\u00b1M\u0096%P0Hg\t\u00c6\u00d0\u00d1A\u00eee";
                var5_15 = "\u00d4\u0017;\u00cd.\u009e\n;\u0002\u00adc\u00f1\u000e\u00904\u00b2(\u00d1H\u0094\f\u00879/\u008e\u0010?\u0002\u000b\u00ebV\u00c6\u00b1|\u00ec~~\\q<B@\u00c3R\u0081H\u00965,U\u009a\u00047\u00e2\u00c7[\f\u00ca\u00c0[\u00ee\u00bc/\u0088'7\u0086\u00e4\u00bf\u0004\u00deO\u00a1\u00fa\u00d6X\u000e\u0081W\u0089]f\u000f&gRw4\u00a9\u00b1M\u0096%P0Hg\t\u00c6\u00d0\u00d1A\u00eee".length();
                var2_16 = 0;
                while (true) {
                    var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                    v10 = var6_12;
                    v11 = var3_13++;
                    v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                    v13 = -1;
                    break block20;
                    break;
                }
lbl81:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    var4_14 = "\u00bd\u00b5\u00f8O%\u0005\u00e2\u0092\u001cK\u00fb\u009d_\u001b\u007f\u00fb";
                    var5_15 = "\u00bd\u00b5\u00f8O%\u0005\u00e2\u0092\u001cK\u00fb\u009d_\u001b\u007f\u00fb".length();
                    var2_16 = 0;
                    while (true) {
                        var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                        v10 = var6_12;
                        v11 = var3_13++;
                        v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                        v13 = 0;
                        break block20;
                        break;
                    }
                    break;
                }
lbl94:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    break block21;
                    break;
                }
            }
            var8_18 = v12;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            v14 = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
            switch (v13) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl107:
                // 1 sources

                ** continue;
            }
        }
        ItemESP.y = var6_12;
        ItemESP.z = new Integer[15];
    }

    private static r a(r r2) {
        return r2;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x3E6E;
        if (z[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = y[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])A.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    A.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/g/X", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            ItemESP.z[n3] = n4;
        }
        return z[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = ItemESP.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/X" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static void c() {
        Object[] objectArray = B;
        B[0] = "\u0010c-_.s\u001bc+_\u0017";
        objectArray[1] = "W!n\u0000#0\"\u0001e\u000f2\u007fC\u000fn\u00046%7";
        objectArray[2] = Void.TYPE;
        ItemESP.C[2] = "java/lang/Void";
        objectArray[3] = "=k)\u0016Uz6k/\u0016U\u0010";
        objectArray[4] = "{O";
        objectArray[5] = "[i=\u0014.3Pi6";
        objectArray[6] = Boolean.TYPE;
        ItemESP.C[6] = "java/lang/Boolean";
        objectArray[7] = "~\u0018\u000e\u0015j\u0015w\u0018\r\u0015f";
        objectArray[8] = "T8wu<b]8tu<";
        objectArray[9] = "\u0013\u0005A<\u0004s\u0018\nPse}\u0013\u0001T)";
        objectArray[10] = "beMu#\u0003ne^";
        objectArray[11] = "Mnm\u001em\u0010\\nmS";
        objectArray[12] = "\"\u0010Cg=~W0Hh,16>Cc(kB";
        objectArray[13] = "X\u0012";
        objectArray[14] = "\u0011Sw\n\u001e~\u0018St\n\u001a";
        objectArray[15] = "61\u007f\u0001:E+$'#{H3\"";
        objectArray[16] = "HGwbz+AGtbx";
        objectArray[17] = "9I]iH/2IU";
        objectArray[18] = "\u000f_\u001c7ghz\u007f\u00178v'\u001bq\u001c3r}o";
        objectArray[19] = ":^S\u001fl\u001f6O\u0010q?'f\b\u0013\t$M1\u000f\tHV\u001ev\b\u001c\u001a(NhYZq";
        objectArray[20] = "#Z\u0019\u001dZi/KZs\u001aQz\u000fZC\t+u\rE\u001c";
        objectArray[21] = "\u001a0B,]7\u00152]s4$s`^cL3Io\fsSM";
        objectArray[22] = ";\u0016\u001b\u000f\u0014q=\u0012\u001a\u0014{x\u0001J\u001e\u001dJ`m\u001bI\u001a\u0006\u0012";
        objectArray[23] = "c4L[DX>s\u000e\u0005{WXp\u001f_@Y:7\u0007V\u0010;";
        objectArray[24] = "$maj\u0013\u000f(|\"\u0004O7)>(y\u0016Mlpnc";
        objectArray[25] = "/\u001d\u00101x\u0012#\fS_;*u\u0018\u0019-9D`\u0016^<";
        objectArray[26] = "[_\u0011UeWB\f\u0004\u001b\u0005uw?.)\u0005A\n\u001eZ\u0005xXY\u000b\u0014";
        objectArray[27] = "Z~ItIKVo\n\u001a\u0016sW-\u0000gL\t\u0012cF}";
        objectArray[28] = "IH\u0000\r?'EYCc~\u001f\u0010\u001dCSle\u001f\u001f\\\f";
        objectArray[29] = "\u000bQ^5JL\u0007@\u001d[\ftR\u0004\u001dk\u0019\u000e]\u0006\u00024";
        objectArray[30] = ",&=\bZ_hr*\u000fcV\u0012&5QSF/w1\u0006^?";
        objectArray[31] = "\u0018}A\\.L\u0014l\u00022}t\u0017.O[.\u0015K{\u001a\\\u0014K\u0017.\u0019\bu\u0017B{\u001e2";
        objectArray[32] = "L\u0003\u0012\"\u0001z@\u0012QL\\B\u0016\u0006\u001b>@,\u0003\b\\/";
        objectArray[33] = "M:;\u001b:~A+xuxF\u0017?2\u0007{(\u00021u\u0016";
        objectArray[34] = "W7\u00065u\u0012Y\"\u0006t\u0010\u0014h$G4h\u000f\u0002s@.)}YxA, \u0000T%\u0002t\u0010";
        Object[] objectArray2 = objectArray;
        objectArray[35] = "\u001f*R\u007f`6Bm\u0010!_1$>Xj''Ni_pfU\u001d.Xe4+M0\t#_";
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = ItemESP.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = ItemESP.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = ItemESP.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = ItemESP.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(ItemESP.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

