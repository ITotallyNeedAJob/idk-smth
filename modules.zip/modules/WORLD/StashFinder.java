// === Kuzi module: StashFinder ===
// Category   : WORLD
// Description: Finds and tracks stashes with webhook support
// Payload    : a.a.a.j.e.ag (verified: True)

package kuzi.modules.world;

import a.a.a.j.e.u;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.b.l;
import kuzi.obf.h.b.v;
import kuzi.obf.j.e.am;
import kuzi.obf.m.r;
import kuzi.obf.p.ay;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import kuzi.settings.StringSetting;
import net.minecraft.ChunkPos;
import net.minecraft.Component;
import net.minecraft.LevelChunk;
import net.minecraft.Minecraft;
import net.minecraft.SoundEvents;
import net.minecraft.ClientLevel;
import net.minecraft.LocalPlayer;

public class StashFinder
extends BaseModule {
    private final BoolSetting chests;
    private final BoolSetting barrels;
    private final BoolSetting shulkers;
    private final BoolSetting enderChests;
    private final BoolSetting furnaces;
    private final BoolSetting dispensers;
    private final BoolSetting hoppers;
    private final BoolSetting spawners;
    private final SliderSetting minStorageCount;
    private final SliderSetting minDistance;
    private final BoolSetting criticalSpawner;
    private final BoolSetting disconnectOnFind;
    private final BoolSetting sendNotifications;
    private final l notificationMode;
    private final BoolSetting enableWebhook;
    private final StringSetting webhookURL;
    private final BoolSetting selfPing;
    private final StringSetting discordID;
    private static final int E;
    private final LinkedHashSet F;
    private ClientLevel lastLevel;
    private static final long H;
    private static final String[] I;
    private static final String[] J;
    private static final Map K;
    private static final long[] L;
    private static final Integer[] M;
    private static final Map N;
    private static final Object[] O;
    private static final String[] P;

    public StashFinder() {
        block0: {
            long l2 = H ^ 0x17EEDCBADBEFL;
            long l3 = l2 ^ 0x5DB9DAAC295CL;
            String string = am.b();
            super("StashFinder", "Finds and tracks stashes with webhook support", Category.WORLD);
            this.chests = new BoolSetting("Chests", true);
            this.barrels = new BoolSetting("Barrels", true);
            this.shulkers = new BoolSetting("Shulkers", true);
            this.enderChests = new BoolSetting("Ender Chests", true);
            this.furnaces = new BoolSetting("Furnaces", true);
            this.dispensers = new BoolSetting("Dispensers/Droppers", true);
            this.hoppers = new BoolSetting("Hoppers", true);
            this.spawners = new BoolSetting("Spawners", true);
            this.minStorageCount = new SliderSetting("Min Storage Count", 4.0, 1.0, 100.0, 1.0);
            this.minDistance = new SliderSetting("Min Distance", 0.0, 0.0, 10000.0, 100.0);
            String string2 = string;
            this.criticalSpawner = new BoolSetting("Critical Spawner", true);
            this.disconnectOnFind = new BoolSetting("Disconnect On Find", false);
            this.sendNotifications = new BoolSetting("Send Notifications", true);
            this.notificationMode = new l("Notification Mode", (Enum)a.a.a.j.e.u.BOTH, u.class);
            this.enableWebhook = new BoolSetting("Enable Webhook", false);
            this.webhookURL = new StringSetting("Webhook URL", "");
            this.selfPing = new BoolSetting("Self Ping", false);
            this.discordID = new StringSetting("Discord ID", "");
            this.F = new LinkedHashSet();
            Setting[] settingArray = new Setting[]{this.chests, this.barrels, this.shulkers, this.enderChests, this.furnaces, this.dispensers, this.hoppers, this.spawners, this.minStorageCount, this.minDistance, this.criticalSpawner, this.disconnectOnFind, this.sendNotifications, this.notificationMode, this.enableWebhook, this.webhookURL, this.selfPing, this.discordID};
            Object[] objectArray = new Object[2];
            objectArray[1] = settingArray;
            objectArray[0] = l3;
            this.l(objectArray);
            if (BaseModule.b() != null) break block0;
            am.b("R4abx");
        }
    }

    @Override
    public void d() {
        super.d();
        this.F.clear();
    }

    @Override
    public void e() {
        super.e();
        this.F.clear();
    }

    @Override
    public void h() {
        this.F.clear();
    }

    @Override
    public void i() {
        Minecraft mc;
        String marker;
        long l2;
        block18: {
            ClientLevel level;
            block16: {
                block17: {
                    block15: {
                        Minecraft snapshotMc;
                        block14: {
                            long l3 = H ^ 0x1822E5890947L;
                            l2 = l3 ^ 0x2A7532826472L;
                            marker = am.b();
                            snapshotMc = BaseModule.a;
                            if (marker == null) break block14;
                            if (snapshotMc.player == null) break block15;
                            snapshotMc = BaseModule.a;
                        }
                        level = snapshotMc.level;
                        if (marker == null) break block16;
                        if (level != null) break block17;
                    }
                    return;
                }
                mc = BaseModule.a;
                if (marker == null) break block18;
                level = mc.level;
            }
            if (level != this.lastLevel) {
                this.lastLevel = BaseModule.a.level;
                this.F.clear();
            }
            mc = BaseModule.a;
        }
        ChunkPos playerChunk = mc.player.chunkPosition();
        int renderDistance = (Integer)BaseModule.a.options.renderDistance().get();
        int dx = -renderDistance;
        while (dx <= renderDistance) {
            block13: {
                int dz = -renderDistance;
                while (dz <= renderDistance) {
                    block19: {
                        block20: {
                            boolean emptyChunk;
                            LevelChunk chunk;
                            block21: {
                                chunk = BaseModule.a.level.getChunkSource().getChunk(playerChunk.x + dx, playerChunk.z + dz, false);
                                if (marker == null) break block13;
                                if (marker == null) break block19;
                                if (chunk == null) break block20;
                                emptyChunk = chunk.isEmpty();
                                if (marker == null) break block21;
                                if (emptyChunk) break block20;
                                emptyChunk = chunk.getBlockEntities().isEmpty();
                            }
                            if (!emptyChunk) {
                                Object[] objectArray = new Object[2];
                                objectArray[1] = chunk;
                                objectArray[0] = l2;
                                this.processChunk(objectArray);
                            }
                        }
                        ++dz;
                    }
                    if (marker != null) continue;
                }
                ++dx;
            }
            if (marker != null) continue;
        }
    }

    /*
     * Exception decompiling
     */
    private void processChunk(Object[] args) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Statement already marked as first in another block
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.markFirstStatementInBlock(Op03SimpleStatement.java:461)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc.markWholeBlock(Misc.java:251)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.considerAsSimpleIf(ConditionalRewriter.java:673)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.identifyNonjumpingConditionals(ConditionalRewriter.java:56)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:722)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Unable to fully structure code
     */
    private void sendWebhookNotification(Object[] var1_1) {
        block59: {
            block58: {
                block56: {
                    block57: {
                        block54: {
                            block55: {
                                block52: {
                                    block53: {
                                        block50: {
                                            block51: {
                                                block48: {
                                                    block49: {
                                                        block46: {
                                                            block47: {
                                                                block44: {
                                                                    block45: {
                                                                        block43: {
                                                                            block41: {
                                                                                block42: {
                                                                                    block39: {
                                                                                        block40: {
                                                                                            block37: {
                                                                                                block38: {
                                                                                                    var2_2 = (Integer)args[0];
                                                                                                    var11_3 = (Integer)args[1];
                                                                                                    var7_4 = (Integer)args[2];
                                                                                                    var3_5 = (Integer)args[3];
                                                                                                    var4_6 = (Integer)args[4];
                                                                                                    var9_7 = (Long)args[5];
                                                                                                    var14_8 = (Integer)args[6];
                                                                                                    var13_9 = (Integer)args[7];
                                                                                                    var6_10 = (Integer)args[8];
                                                                                                    var12_11 = (Integer)args[9];
                                                                                                    var5_12 = (Integer)args[10];
                                                                                                    var15_13 = ((Boolean)args[11]).booleanValue();
                                                                                                    var8_14 = (String)args[12];
                                                                                                    v0 = var9_7 = StashFinder.H ^ var9_7;
                                                                                                    var16_15 = v0 ^ 105222483258611L;
                                                                                                    var18_16 = v0 ^ 74327493098922L;
                                                                                                    var20_17 = v0 ^ 65753749853012L;
                                                                                                    var22_18 = v0 ^ 12853043352037L;
                                                                                                    var24_19 = v0 ^ 6178851870049L;
                                                                                                    var26_20 = v0 ^ 61227391180871L;
                                                                                                    var28_21 = v0 ^ 98711491230137L;
                                                                                                    var30_22 = v0 ^ 70994707667609L;
                                                                                                    var33_23 = ((String)StashFinder.d("\u00d5", (Object)StashFinder.d("\u00c8", (Object)this, (long)429171304268234792L, (long)var9_7), (long)426646851024675953L, (long)var9_7)).trim();
                                                                                                    var32_24 = StashFinder.d("G", (long)426398737129844959L, (long)var9_7);
                                                                                                    try {
                                                                                                        try {
                                                                                                            v1 = var33_23;
                                                                                                            if (var32_24 == null) break block37;
                                                                                                            if (!v1.isEmpty()) break block38;
                                                                                                        }
                                                                                                        catch (r v2) {
                                                                                                            throw StashFinder.d("G", (Object)v2, (long)426290144948235143L, (long)var9_7);
                                                                                                        }
                                                                                                        StashFinder.d("C", (long)426348741655733341L, (long)var9_7).execute((Runnable)LambdaMetafactory.metafactory(null, null, null, ()V, lambda$sendWebhookNotification$2(long ), ()V)((long)var26_20));
                                                                                                        return;
                                                                                                    }
                                                                                                    catch (r v3) {
                                                                                                        throw StashFinder.d("G", (Object)v3, (long)426290144948235143L, (long)var9_7);
                                                                                                    }
                                                                                                }
                                                                                                v1 = "";
                                                                                            }
                                                                                            var34_25 = v1;
                                                                                            try {
                                                                                                try {
                                                                                                    try {
                                                                                                        v4 = ((Boolean)StashFinder.d("\u00d5", (Object)StashFinder.d("\u00c8", (Object)this, (long)429639360053679098L, (long)var9_7), (long)426646851024675953L, (long)var9_7)).booleanValue();
                                                                                                        if (var32_24 == null) break block39;
                                                                                                        if (v4 == 0) break block40;
                                                                                                    }
                                                                                                    catch (r v5) {
                                                                                                        throw StashFinder.d("G", (Object)v5, (long)426290144948235143L, (long)var9_7);
                                                                                                    }
                                                                                                    v4 = (int)((String)StashFinder.d("\u00d5", (Object)StashFinder.d("\u00c8", (Object)this, (long)430092897699680057L, (long)var9_7), (long)426646851024675953L, (long)var9_7)).trim().isEmpty();
                                                                                                    if (var9_7 <= 0L || var32_24 == null) break block39;
                                                                                                }
                                                                                                catch (r v6) {
                                                                                                    throw StashFinder.d("G", (Object)v6, (long)426290144948235143L, (long)var9_7);
                                                                                                }
                                                                                                if (v4 != 0) break block40;
                                                                                            }
                                                                                            catch (r v7) {
                                                                                                throw StashFinder.d("G", (Object)v7, (long)426290144948235143L, (long)var9_7);
                                                                                            }
                                                                                            var34_25 = ((String)StashFinder.d("\u00d5", (Object)StashFinder.d("\u00c8", (Object)this, (long)430092897699680057L, (long)var9_7), (long)426646851024675953L, (long)var9_7)).trim();
                                                                                        }
                                                                                        v4 = var15_13;
                                                                                    }
                                                                                    try {
                                                                                        if (var9_7 < 0L) break block41;
                                                                                        if (v4 == 0) break block42;
                                                                                        v8 = StashFinder.b("f", (int)31519, (long)(5883335788263130444L ^ var9_7));
                                                                                        break block43;
                                                                                    }
                                                                                    catch (r v9) {
                                                                                        throw StashFinder.d("G", (Object)v9, (long)426290144948235143L, (long)var9_7);
                                                                                    }
                                                                                }
                                                                                v4 = 28592;
                                                                            }
                                                                            v8 = StashFinder.b("f", (int)v4, (long)(505047084372120013L ^ var9_7));
                                                                        }
                                                                        var35_26 = v8;
                                                                        var36_27 = String.format((String)StashFinder.b("f", (int)4193, (long)(185098521195097618L ^ var9_7)), new Object[]{var35_26, var2_2, var11_3});
                                                                        var37_28 = new StringBuilder();
                                                                        var38_29 = 0;
                                                                        try {
                                                                            v10 = var5_12;
                                                                            v11 = var32_24;
                                                                            if (var9_7 > 0L) {
                                                                                if (v11 == null) break block44;
                                                                                if (v10 <= 0) break block45;
                                                                            }
                                                                            ** GOTO lbl99
                                                                        }
                                                                        catch (r v12) {
                                                                            throw StashFinder.d("G", (Object)v12, (long)426290144948235143L, (long)var9_7);
                                                                        }
                                                                        var37_28.append((String)StashFinder.b("f", (int)24374, (long)(5469016431609667966L ^ var9_7))).append(var5_12).append("\n");
                                                                        var38_29 += var5_12;
                                                                    }
                                                                    v10 = var7_4;
                                                                }
                                                                try {
                                                                    v11 = var32_24;
lbl99:
                                                                    // 2 sources

                                                                    if (var9_7 >= 0L) {
                                                                        if (v11 == null) break block46;
                                                                        if (v10 <= 0) break block47;
                                                                    }
                                                                    ** GOTO lbl114
                                                                }
                                                                catch (r v13) {
                                                                    throw StashFinder.d("G", (Object)v13, (long)426290144948235143L, (long)var9_7);
                                                                }
                                                                var37_28.append((String)StashFinder.b("f", (int)20649, (long)(1810069734641856226L ^ var9_7))).append(var7_4).append("\n");
                                                                var38_29 += var7_4;
                                                            }
                                                            v10 = var3_5;
                                                        }
                                                        try {
                                                            v11 = var32_24;
lbl114:
                                                            // 2 sources

                                                            if (var9_7 >= 0L) {
                                                                if (v11 == null) break block48;
                                                                if (v10 <= 0) break block49;
                                                            }
                                                            ** GOTO lbl129
                                                        }
                                                        catch (r v14) {
                                                            throw StashFinder.d("G", (Object)v14, (long)426290144948235143L, (long)var9_7);
                                                        }
                                                        var37_28.append((String)StashFinder.b("f", (int)13958, (long)(4311756758985541865L ^ var9_7))).append(var3_5).append("\n");
                                                        var38_29 += var3_5;
                                                    }
                                                    v10 = var4_6;
                                                }
                                                try {
                                                    v11 = var32_24;
lbl129:
                                                    // 2 sources

                                                    if (var9_7 > 0L) {
                                                        if (v11 == null) break block50;
                                                        if (v10 <= 0) break block51;
                                                    }
                                                    ** GOTO lbl144
                                                }
                                                catch (r v15) {
                                                    throw StashFinder.d("G", (Object)v15, (long)426290144948235143L, (long)var9_7);
                                                }
                                                var37_28.append((String)StashFinder.b("f", (int)8727, (long)(4436372203419081818L ^ var9_7))).append(var4_6).append("\n");
                                                var38_29 += var4_6;
                                            }
                                            v10 = var14_8;
                                        }
                                        try {
                                            v11 = var32_24;
lbl144:
                                            // 2 sources

                                            if (var9_7 > 0L) {
                                                if (v11 == null) break block52;
                                                if (v10 <= 0) break block53;
                                            }
                                            ** GOTO lbl159
                                        }
                                        catch (r v16) {
                                            throw StashFinder.d("G", (Object)v16, (long)426290144948235143L, (long)var9_7);
                                        }
                                        var37_28.append((String)StashFinder.b("f", (int)19811, (long)(8200787998861652767L ^ var9_7))).append(var14_8).append("\n");
                                        var38_29 += var14_8;
                                    }
                                    v10 = var13_9;
                                }
                                try {
                                    v11 = var32_24;
lbl159:
                                    // 2 sources

                                    if (var9_7 >= 0L) {
                                        if (v11 == null) break block54;
                                        if (v10 <= 0) break block55;
                                    }
                                    ** GOTO lbl174
                                }
                                catch (r v17) {
                                    throw StashFinder.d("G", (Object)v17, (long)426290144948235143L, (long)var9_7);
                                }
                                var37_28.append((String)StashFinder.b("f", (int)16598, (long)(2558571176395275963L ^ var9_7))).append(var13_9).append("\n");
                                var38_29 += var13_9;
                            }
                            v10 = var6_10;
                        }
                        try {
                            v11 = var32_24;
lbl174:
                            // 2 sources

                            if (var9_7 >= 0L) {
                                if (v11 == null) break block56;
                                if (v10 <= 0) break block57;
                            }
                            ** GOTO lbl190
                        }
                        catch (r v18) {
                            throw StashFinder.d("G", (Object)v18, (long)426290144948235143L, (long)var9_7);
                        }
                        var37_28.append((String)StashFinder.b("f", (int)7242, (long)(719993813498962458L ^ var9_7))).append(var6_10).append("\n");
                        var38_29 += var6_10;
                    }
                    v10 = var12_11;
                }
                try {
                    try {
                        v11 = var32_24;
lbl190:
                        // 2 sources

                        if (v11 == null) break block58;
                        if (v10 <= 0) break block59;
                    }
                    catch (r v19) {
                        throw StashFinder.d("G", (Object)v19, (long)426290144948235143L, (long)var9_7);
                    }
                    var37_28.append((String)StashFinder.b("f", (int)18644, (long)(5750766590035457677L ^ var9_7))).append(var12_11).append("\n");
                    v10 = var38_29 + var12_11;
                }
                catch (r v20) {
                    throw StashFinder.d("G", (Object)v20, (long)426290144948235143L, (long)var9_7);
                }
            }
            var38_29 = v10;
        }
        v21 = new Object[2];
        v21[1] = StashFinder.b("f", (int)2599, (long)(4615335484316791920L ^ var9_7));
        v21[0] = var16_15;
        v22 = new Object[2];
        v22[1] = var30_22;
        v22[0] = var36_27;
        v23 = new Object[2];
        v23[1] = var34_25;
        v23[0] = var24_19;
        v24 = new Object[4];
        v24[3] = false;
        v24[2] = var8_14;
        v24[1] = var22_18;
        v24[0] = StashFinder.b("f", (int)26128, (long)(2328489231005898834L ^ var9_7));
        v25 = new Object[4];
        v25[3] = false;
        v25[2] = String.valueOf(var38_29);
        v25[1] = var22_18;
        v25[0] = StashFinder.b("f", (int)25294, (long)(2660755327751183537L ^ var9_7));
        v26 = new Object[4];
        v26[3] = false;
        v26[2] = var37_28.toString();
        v26[1] = var22_18;
        v26[0] = StashFinder.b("f", (int)5901, (long)(7111718719853341009L ^ var9_7));
        v27 = new Object[4];
        v27[3] = true;
        v27[2] = var2_2 + (String)StashFinder.b("f", (int)9140, (long)(3130508680375508422L ^ var9_7)) + var11_3;
        v27[1] = var22_18;
        v27[0] = StashFinder.b("f", (int)8852, (long)(3319642297323396311L ^ var9_7));
        v28 = new Object[1];
        v28[0] = var28_21;
        v29 = new Object[1];
        v29[0] = var18_16;
        v30 = new Object[1];
        v30[0] = var20_17;
        StashFinder.d("\u00d5", (Object)StashFinder.d("\u00d5", (Object)StashFinder.d("\u00d5", (Object)StashFinder.d("\u00d5", (Object)StashFinder.d("\u00d5", (Object)StashFinder.d("\u00d5", (Object)StashFinder.d("\u00d5", (Object)StashFinder.d("\u00d5", (Object)StashFinder.d("\u00d5", (Object)StashFinder.d("\u00d5", (Object)new ay(var33_23), (Object)v21, (long)427301505389967133L, (long)var9_7), (Object)v22, (long)429942711863032118L, (long)var9_7), (Object)v23, (long)425788649603911141L, (long)var9_7), (Object)v24, (long)429990994646097062L, (long)var9_7), (Object)v25, (long)429990994646097062L, (long)var9_7), (Object)v26, (long)429990994646097062L, (long)var9_7), (Object)v27, (long)429990994646097062L, (long)var9_7), (Object)v28, (long)426017611404324080L, (long)var9_7), (Object)v29, (long)429749992862026972L, (long)var9_7), (Object)v30, (long)427675551397968623L, (long)var9_7);
    }

    private static void lambda$sendWebhookNotification$2(long l2) {
        block5: {
            LocalPlayer player;
            block4: {
                l2 = H ^ l2;
                CallSite callSite = StashFinder.d("G", (long)-8355440097964771010L, (long)l2);
                try {
                    try {
                        player = ((Minecraft)StashFinder.d("C", (long)-8355323066974294596L, (long)l2)).player;
                        if (callSite == null) break block4;
                        if (player == null) break block5;
                    }
                    catch (r r2) {
                        throw StashFinder.d("G", (Object)r2, (long)-8355548694960004506L, (long)l2);
                    }
                    player = ((Minecraft)StashFinder.d("C", (long)-8355323066974294596L, (long)l2)).player;
                }
                catch (r r3) {
                    throw StashFinder.d("G", (Object)r3, (long)-8355548694960004506L, (long)l2);
                }
            }
            player.displayClientMessage(Component.nullToEmpty((String)((Object)StashFinder.b("f", (int)10928, (long)(0x159F15E864D21D04L ^ l2)))), false);
        }
    }

    private void lambda$processChunk$1(long l2) {
        block5: {
            ClientLevel level;
            block4: {
                l2 = H ^ l2;
                CallSite callSite = StashFinder.d("G", (long)-6231887853363782474L, (long)l2);
                StashFinder.d("\u00d5", (Object)this, (long)-6225020058472588342L, (long)l2);
                CallSite callSite2 = callSite;
                try {
                    try {
                        level = ((Minecraft)StashFinder.d("C", (long)-6231981824907573196L, (long)l2)).level;
                        if (callSite2 == null) break block4;
                        if (level == null) break block5;
                    }
                    catch (r r2) {
                        throw StashFinder.d("G", (Object)r2, (long)-6232066234506999826L, (long)l2);
                    }
                    level = ((Minecraft)StashFinder.d("C", (long)-6231981824907573196L, (long)l2)).level;
                }
                catch (r r3) {
                    throw StashFinder.d("G", (Object)r3, (long)-6232066234506999826L, (long)l2);
                }
            }
            level.disconnect((Component)Component.literal((String)((Object)StashFinder.b("f", (int)30610, (long)(0x60BAD6BC3A6265B2L ^ l2)))));
        }
    }

    private static void lambda$processChunk$0(boolean bl, long l2, String string, boolean bl2, String string2) {
        boolean bl3;
        long l3;
        long l4;
        block10: {
            block11: {
                long l5 = l2 = H ^ l2;
                l4 = l5 ^ 0x194A5C064203L;
                l3 = l5 ^ 0x92F920DB02CL;
                CallSite callSite = StashFinder.d("G", (long)-6209389466640114458L, (long)l2);
                try {
                    if (((Minecraft)StashFinder.d("C", (long)-6209408757311305628L, (long)l2)).player == null) {
                        return;
                    }
                }
                catch (r r2) {
                    throw StashFinder.d("G", (Object)r2, (long)-6209493114156873794L, (long)l2);
                }
                try {
                    try {
                        bl3 = bl;
                        if (l2 <= 0L || callSite == null) break block10;
                        if (!bl3) break block11;
                    }
                    catch (r r3) {
                        throw StashFinder.d("G", (Object)r3, (long)-6209493114156873794L, (long)l2);
                    }
                    ((Minecraft)StashFinder.d("C", (long)-6209408757311305628L, (long)l2)).player.displayClientMessage(Component.nullToEmpty((String)((String)((Object)StashFinder.b("f", (int)513, (long)(0x5CB66ACA6833106EL ^ l2))) + string)), false);
                }
                catch (r r4) {
                    throw StashFinder.d("G", (Object)r4, (long)-6209493114156873794L, (long)l2);
                }
            }
            bl3 = bl2;
        }
        try {
            if (bl3) {
                Object[] objectArray = new Object[1];
                objectArray[0] = l4;
                Object[] objectArray2 = new Object[4];
                objectArray2[3] = StashFinder.d("C", (long)-6208763051294147425L, (long)l2);
                objectArray2[2] = (String)((Object)StashFinder.b("f", (int)26111, (long)(0x39F2D608A2A2F783L ^ l2))) + string2;
                objectArray2[1] = StashFinder.b("f", (int)8324, (long)(0x5893152F8A732CDL ^ l2));
                objectArray2[0] = l3;
                StashFinder.d("\u00d5", (Object)StashFinder.d("G", (Object)objectArray, (long)-6209720460324447737L, (long)l2), (Object)objectArray2, (long)-6211177487200899399L, (long)l2);
            }
        }
        catch (r r5) {
            throw StashFinder.d("G", (Object)r5, (long)-6209493114156873794L, (long)l2);
        }
        ((Minecraft)StashFinder.d("C", (long)-6209408757311305628L, (long)l2)).player.playSound(SoundEvents.EXPERIENCE_BOTTLE_THROW, 1.0f, 1.0f);
    }

    /*
     * Unable to fully structure code
     */
    static {
        block21: {
            block20: {
                block19: {
                    block18: {
                        StashFinder.H = kuzi.obf.h.b.v.a(-1469986866406689606L, 8260420051776314698L, MethodHandles.lookup().lookupClass()).a(220761354952167L);
                        StashFinder.O = new Object[80];
                        StashFinder.P = new String[80];
                        StashFinder.c();
                        StashFinder.K = new HashMap<K, V>(13);
                        var11 = StashFinder.H ^ 58074048862050L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[51];
                        var18_4 = 0;
                        var17_5 = "\u00bd/\u00a4z\u00ddW\"\u00e8\u001a\u00c1\u0002\u00b6\u00b4\u0016\u00d2#\u0018\u00ef\u00a1\u0007\u00d7\u001dia\u00de\u00f7\u00e4\u00bb\u009c\u0017\u0001H\u00bcV&\u00d5CS\u0005\u007f[ |I\u00d5\u00c0\u00d7'$/\u0006\u009a\u00a9\u00fc#\u0019\u008c\u00d2\u00f0\u0016rP\u008f2\u00fd]\n\u00f9\u00b6\u00dcc\u00a3\u00c2\u0098(%-\u00c2\u0087A\u00af9\u00b9O\u00a5\u00ea\u00f0\u0088\u00f8\u0019\u000bhx\u008c\"\t\u00e1\u00ebb\u00d3\u008d\u00e3\u0000\u00a4S\u00ddqp\u001e\u00d76\b\u00ba\u0081\u0097\u0018nP\u00cdxb\u00c0gHVI\u00c7\u0018\u00d8\u009a_\u009d\u00b4.\u00faC\u00de\u00c3\u00d60(:\u00dc>;\u00a0\u008e\u00dbi\u0012P\u0018\u00ac\u0081\u00c2}p\u001a\u00df\u00c3}v\u00f0$\u00d3\u00c2\u00a1\u00d4\r\r\\\u00da\u00aex\u00df\u0098\u00a8\u00e0\u0094\u00e8\u0017\u0010\u009d\u00b4\u00cb_X\u00f3\u00aa\u0088\u00e7/1f\u0011\u0088!S\u0018,\u00c5;\u00a1b\u008cR\u0095^\u000e\u00f9GD3\u0007\u00f5\u00c1\u00836}GP\u00d8\u0006H{\u0093@\u00d3\u00a2\u00f4\u00dcV/ \u00ecM\u00ff\u009e\u0018T\u007f\u00a2\"v\u0015\u009c>r\u00b6\u000f!:/N\u00c4\u00f1V\u00a5\u00a2\u00b0\u008a\u00e4H\u00ea\u0092\u00be0\u00a8E\u00d6\u00a3H:\u00d7u\u008c\u00d7\u00cd\u00aat\u00d6\u00d9\u00c3\u0012\u00f8\u00eb\u00d7q\u00e2\u008d\u00fa\u00b4F\u00c7\u000eu\u0018\u0095~dQ\u00f4lh\u0019e/\u00e5\u00b0\t\u0000\u00d3\u00ed\u0011\u007f\u00e5\u00ecx\u00b9\u00e9\u00dc0\u00e6@FP\u00a3be\u00eb\u00f4\u00cd\u008eC\u00a9\u00d2\u00f7\u00aa\u00b7_!\u00eb\u00b7M\b\u00c9'\u00ba'My\u001eC\u0006\u0090\u0013\u00b3,J4\f\nS\u00002 \u009d_s\u00f5(X\u00d0\u00bb\u0091a\u00e2\u0082\u0096\rZ\u00b4\u00ee(\u00ca\"J\\P\b\u00ae\u0086R\u00d6H\u00ea\u0012N\u00ca!-\u008c\u00c2\u00cc9\u00ba\u00fa\u00a4\u00fcu\u00a70\u00c2p\u00dd\u008f\u00dc\u00f2\u0086-f\u00b1\u00e5|\u00bfP0\u00e3\u0013\u00d0>=o\u001c\u00f8\u0099\u00f3\u0087\u0085=&cB&\u00cf\u00d7@\u00b4po\u00eeVr\n\u00a2Qp\u00d9v\u009b(\u00aajV/\u00ef\u008b\u008c\u00a3?fY1\u00be\u008dn\u00c7\u008f\u00c4\u0082\u001ec\u001f\u00a2\u00f8\u0002P\u00a5\u00dba\rJ\u00ae_\u00e6i\u0098\u00b1\u0010F? \u0091\u000b\u000f\u00e2\u00bb<\u000f\u0011\u00d0\"\u008c\u0092\u00ddz\u00f4y$\u0085\u0087\u0093:\u00fc\b\u00ba\u00bf\u00c9_\u0016\u0010\u001c\u00d8\u009e(\u00b06e\u00d8A\u0013h\u0003_\u00a5\u000b\u00ca\u0000]\u0084\u00c1/\u00a2;\u00cf\u00dd3\u0090v\u00a9\u0016i\\\u00d4U\u0091\u0080\u00bd3\u00c6W\u00a4Y\u00f7\u00f2 \u00ab\u00a7eO\u00b9G\u00b4\u00a4\u00a3HTt\u0016\u00d8'\u00a5\u0083\u00d5\u0091(,.\u00c2j\u00fe\u00f1\u00fb~\u00f6<=\u00ad\u0010\u00cd\u00c1E\u00e3\u0092\u00d0.{i\u00d4\u0014l#I\u009d\u0017\u0010\u00bd\u00a8\u00c3 \u00bc\u001c\u00a2-\u00b3\u007f\u008a,\u00eej9\u00b9\u0018\u00a7\u00cf\u00a8<?$\u00ec\u00e4\u00a1\u00b4\u00c9\u0091_\u00d6\u00e2^<\u00a8\u00d3?<\u00ea\u000bm\u0018]H&\u00fehw\u009e\u00cd\u00c1M\u00eb2L\u001bZ\u00d1\u00c8U\u00d8\u009d)X\u00b0+\u0018\u0088\u0011+\u00f3\u00b7^\u000e9\u00c6~\u001a\u00e2\\pFy\u00c6\u00ee\u00a2\u00b5[\u001f\u0012\u00c3 f\u00b1\u00beL\u00e9\u0087Y7\u00c0\u0015\u00fe\u00c6bo\u00e7i7\u0094\u00beV\u00d1*\u00fb\u00ccI\u00ba}\u0097Pzx\u0098\u0010;\u00db\u00eb\u0098t6\u00fc\u00e8|\u0018\u0001\u0097\u00ff\u00b5\u00f7\u0086\u0010l\t\u0001\u00b6\u00c0\u00d29YF\u0010\u0091\u00cax\u0092{| \u001e\u0012\u00d5A\u00ea3}\u00b2\u00c6'h\u00c6\u00fbwQ\u008f\u00e4\u00ec\u0087\u00ecRW:\u00c8P~V'\u00c9(\u00c3$\u0018\u00c9&\u0016^\u008c\u00be&\u0006Y9\u00e0rN@\u00ac\u00be#\u00b6\u001f\u001cs\u0095\u00d9\u00ac\u0010\u00e6h\u00c0\u008fcUR\u008e\u00d7\u008d*\u00f7\u0087\u008d\u00b3\u00b4 \u00c5K6\u00ce\u00f3J\u00a8EB\u00ac\u0012\u00b5\u00f50\u00ab\u008aj\u00d9v\u00dc@6\u0005\u00ea\u00d8\u00a5\u009cZ\u001a\u0000q\u0087(\u007f\b\u00b5\u0007nm\u008b\u00d6k\u00a3\u0019\u001e@3\u00b2?r\u00f5w\u0095\u0004\u008e\u00ac\u00fbY\u001fIYzd\u009b\u0092\u00d9\u00a6Sk_\u0086\u00c9\u0096 \u00ea\u00b7E\u00c6\u00f2\u0019>\u00f8\u0092\u00eb\u00cc`WOm\u00bdP\u0010-\u0092\u00d7\u000f*\u00cf\u00b8\u00ddW\u00c3\u00a7\u00af\u008a:(\u00e6\u00a8\u00d3!a\u00ce\u00d5NlHu\u00c1\u00b1\u0015]\u0089\u00dc\u0081\u0093\u00a7\u007f]\u00ba\u00b9W\u00ec\u009c\u00f1\u00e1\u008d\u00a2\u0082\u0017\u00a9\u00d7\u00a5{\b6[\u0010e \u00c63n\u00db|\u00b1~j\u008c\u00a9\u0006\u0004\u0096\u001e \u00b9\u009d]\u0019\u00a3G\u00d8G\u00ff\u001f\u009dLY\u00a1#&uX\u00e9MRw8iQjZ\u00ae/M^\u00eb(\u00d6\u009e\u00c2Qt\u00ff\u008e_#\u00ae\u000b\u00d5T\u00fdQI\u00c5\u0094j\u00e2\tLI\u00d3T\u00f5X#\u00ae\u0088\u00a6\u00d9\u00b1\u00b4\u00c6 L\u00b4\u009b8(\u0090\u00c5\u00fcKp\u00dc\u00076\u0094w\u00112\u0098\u0092\u0005s\u00fa \u008e`\u001a\u00cd!~\u00b1U\u00f9g\u00ef\u00f0\u0015\u00e0\u0015f;\u0003V\u0094n\u009d {t2\u00b2\u00a0\u00eb\u001b7\u00fc\u0012\u00a6\u007f\u0099H\u0005\u001fM\u00cc)\u0090\u00bbN\u00e3HVW\u009a\u00f5\u00fe\u00acZj\u0010\u00c6\u00fb\u00db\u0082\t\u00c8\u00dbVL\u0088\u00c33=C\u00e1\u0086(\u008b\u00dbV[z\u00a7\u0007\u00cf$g\u00ca\u00cd\u00a9u\u009b\u001f\u008c\u001cF\u00dbkOv\u00ac\"\u00c8\u0097\u00ffG0\u00b7\u00b5\u00ac\u00d5\u00f6\u0081\u00d4\u009b\u00d2>\u0018\u0001\u00d6\u001a7\u0082\u00b4S=\t\u00e2\u00a4\u00d2xIVW\u00a1\u00d1\u00a8\u00e3s9\u00caK\u0018\u00b8c\u0014\u00cd\u00fb'\u00f2\u00a5\u008f$e5\u00e3to\u00e0&\u00b0\u009ae}\u00a9Y9\u0018Us\u00d5\u0013\f\u009d\u00ba@J\u00b0\u00b6\u00cby;fX\u00ef\u007f\u0004\u0088\u00b5\u0019\u00ae\u0003@\u0087[h\"Q\u00be\u00ad\u001e\u00c55W\u00d4g\u001a\u00f1}\u0006\u00813Ul\u009czM\u0092\u00fa\u00bbk\u0091-\u00fcZ\u00a1\u0083W\u00fe\u00bb\u00a7]\u009a\u0085\u000f\u00d0\u0099$\u00f2\u00c8\u00c6\u00016\u00fe\u00c8e|e\u0016n\u00b8\u00dc\u00db8\u00a1\u001d\u00d0 ;M\u00ac\u001b\u00fcq\u00f48l\u00f2\u00101\u00e3\u00b9-q\u0090B\u00c7)<e\u00a6\u00195uT&N(\u0010\u00f4\u0010\u00aeRT\u00c5U\u00eb\u0018\u009dG\u00ee\u00dca\u0091\u0091\u008fi\u0018\u00ba\u008e\u00dc#x\u00f6l\u00f2\u008el\u000f\u00abF\u00d0\u00e9\u00ca\u009c\u0098\u0081\u0084k\u00d0\u000b\u00a98\u0085]\u00eeR\u00fa\u00c5j\u00cee\u00a5\u00e9\u000b\u00f8\u00f4<\u0016%\u00bb\u000e\u00dd\u00d5\u008d\u00f8`\u00b2\u001eF>\u0088C\u00a7=\u00b1\"d5\u00e6\u00a8\u00f8C \u00fb\u008a\u00ec\u00bb\u0084\u00e4\u00c1\u00b7&\u0016e:lH)\u0010\u00d0\u00a6\u00c7g\u00cc\u0014\u00f5zvU\u00cbHa\u0087<C\u0018\"=\u0087\u00fd,\u0018\u00c1~[\u0005\u000bwi\u00c0\u00d7{\u0095\u00b1\u00eb\u000e?\u00a4\u0094>";
                        var19_6 = "\u00bd/\u00a4z\u00ddW\"\u00e8\u001a\u00c1\u0002\u00b6\u00b4\u0016\u00d2#\u0018\u00ef\u00a1\u0007\u00d7\u001dia\u00de\u00f7\u00e4\u00bb\u009c\u0017\u0001H\u00bcV&\u00d5CS\u0005\u007f[ |I\u00d5\u00c0\u00d7'$/\u0006\u009a\u00a9\u00fc#\u0019\u008c\u00d2\u00f0\u0016rP\u008f2\u00fd]\n\u00f9\u00b6\u00dcc\u00a3\u00c2\u0098(%-\u00c2\u0087A\u00af9\u00b9O\u00a5\u00ea\u00f0\u0088\u00f8\u0019\u000bhx\u008c\"\t\u00e1\u00ebb\u00d3\u008d\u00e3\u0000\u00a4S\u00ddqp\u001e\u00d76\b\u00ba\u0081\u0097\u0018nP\u00cdxb\u00c0gHVI\u00c7\u0018\u00d8\u009a_\u009d\u00b4.\u00faC\u00de\u00c3\u00d60(:\u00dc>;\u00a0\u008e\u00dbi\u0012P\u0018\u00ac\u0081\u00c2}p\u001a\u00df\u00c3}v\u00f0$\u00d3\u00c2\u00a1\u00d4\r\r\\\u00da\u00aex\u00df\u0098\u00a8\u00e0\u0094\u00e8\u0017\u0010\u009d\u00b4\u00cb_X\u00f3\u00aa\u0088\u00e7/1f\u0011\u0088!S\u0018,\u00c5;\u00a1b\u008cR\u0095^\u000e\u00f9GD3\u0007\u00f5\u00c1\u00836}GP\u00d8\u0006H{\u0093@\u00d3\u00a2\u00f4\u00dcV/ \u00ecM\u00ff\u009e\u0018T\u007f\u00a2\"v\u0015\u009c>r\u00b6\u000f!:/N\u00c4\u00f1V\u00a5\u00a2\u00b0\u008a\u00e4H\u00ea\u0092\u00be0\u00a8E\u00d6\u00a3H:\u00d7u\u008c\u00d7\u00cd\u00aat\u00d6\u00d9\u00c3\u0012\u00f8\u00eb\u00d7q\u00e2\u008d\u00fa\u00b4F\u00c7\u000eu\u0018\u0095~dQ\u00f4lh\u0019e/\u00e5\u00b0\t\u0000\u00d3\u00ed\u0011\u007f\u00e5\u00ecx\u00b9\u00e9\u00dc0\u00e6@FP\u00a3be\u00eb\u00f4\u00cd\u008eC\u00a9\u00d2\u00f7\u00aa\u00b7_!\u00eb\u00b7M\b\u00c9'\u00ba'My\u001eC\u0006\u0090\u0013\u00b3,J4\f\nS\u00002 \u009d_s\u00f5(X\u00d0\u00bb\u0091a\u00e2\u0082\u0096\rZ\u00b4\u00ee(\u00ca\"J\\P\b\u00ae\u0086R\u00d6H\u00ea\u0012N\u00ca!-\u008c\u00c2\u00cc9\u00ba\u00fa\u00a4\u00fcu\u00a70\u00c2p\u00dd\u008f\u00dc\u00f2\u0086-f\u00b1\u00e5|\u00bfP0\u00e3\u0013\u00d0>=o\u001c\u00f8\u0099\u00f3\u0087\u0085=&cB&\u00cf\u00d7@\u00b4po\u00eeVr\n\u00a2Qp\u00d9v\u009b(\u00aajV/\u00ef\u008b\u008c\u00a3?fY1\u00be\u008dn\u00c7\u008f\u00c4\u0082\u001ec\u001f\u00a2\u00f8\u0002P\u00a5\u00dba\rJ\u00ae_\u00e6i\u0098\u00b1\u0010F? \u0091\u000b\u000f\u00e2\u00bb<\u000f\u0011\u00d0\"\u008c\u0092\u00ddz\u00f4y$\u0085\u0087\u0093:\u00fc\b\u00ba\u00bf\u00c9_\u0016\u0010\u001c\u00d8\u009e(\u00b06e\u00d8A\u0013h\u0003_\u00a5\u000b\u00ca\u0000]\u0084\u00c1/\u00a2;\u00cf\u00dd3\u0090v\u00a9\u0016i\\\u00d4U\u0091\u0080\u00bd3\u00c6W\u00a4Y\u00f7\u00f2 \u00ab\u00a7eO\u00b9G\u00b4\u00a4\u00a3HTt\u0016\u00d8'\u00a5\u0083\u00d5\u0091(,.\u00c2j\u00fe\u00f1\u00fb~\u00f6<=\u00ad\u0010\u00cd\u00c1E\u00e3\u0092\u00d0.{i\u00d4\u0014l#I\u009d\u0017\u0010\u00bd\u00a8\u00c3 \u00bc\u001c\u00a2-\u00b3\u007f\u008a,\u00eej9\u00b9\u0018\u00a7\u00cf\u00a8<?$\u00ec\u00e4\u00a1\u00b4\u00c9\u0091_\u00d6\u00e2^<\u00a8\u00d3?<\u00ea\u000bm\u0018]H&\u00fehw\u009e\u00cd\u00c1M\u00eb2L\u001bZ\u00d1\u00c8U\u00d8\u009d)X\u00b0+\u0018\u0088\u0011+\u00f3\u00b7^\u000e9\u00c6~\u001a\u00e2\\pFy\u00c6\u00ee\u00a2\u00b5[\u001f\u0012\u00c3 f\u00b1\u00beL\u00e9\u0087Y7\u00c0\u0015\u00fe\u00c6bo\u00e7i7\u0094\u00beV\u00d1*\u00fb\u00ccI\u00ba}\u0097Pzx\u0098\u0010;\u00db\u00eb\u0098t6\u00fc\u00e8|\u0018\u0001\u0097\u00ff\u00b5\u00f7\u0086\u0010l\t\u0001\u00b6\u00c0\u00d29YF\u0010\u0091\u00cax\u0092{| \u001e\u0012\u00d5A\u00ea3}\u00b2\u00c6'h\u00c6\u00fbwQ\u008f\u00e4\u00ec\u0087\u00ecRW:\u00c8P~V'\u00c9(\u00c3$\u0018\u00c9&\u0016^\u008c\u00be&\u0006Y9\u00e0rN@\u00ac\u00be#\u00b6\u001f\u001cs\u0095\u00d9\u00ac\u0010\u00e6h\u00c0\u008fcUR\u008e\u00d7\u008d*\u00f7\u0087\u008d\u00b3\u00b4 \u00c5K6\u00ce\u00f3J\u00a8EB\u00ac\u0012\u00b5\u00f50\u00ab\u008aj\u00d9v\u00dc@6\u0005\u00ea\u00d8\u00a5\u009cZ\u001a\u0000q\u0087(\u007f\b\u00b5\u0007nm\u008b\u00d6k\u00a3\u0019\u001e@3\u00b2?r\u00f5w\u0095\u0004\u008e\u00ac\u00fbY\u001fIYzd\u009b\u0092\u00d9\u00a6Sk_\u0086\u00c9\u0096 \u00ea\u00b7E\u00c6\u00f2\u0019>\u00f8\u0092\u00eb\u00cc`WOm\u00bdP\u0010-\u0092\u00d7\u000f*\u00cf\u00b8\u00ddW\u00c3\u00a7\u00af\u008a:(\u00e6\u00a8\u00d3!a\u00ce\u00d5NlHu\u00c1\u00b1\u0015]\u0089\u00dc\u0081\u0093\u00a7\u007f]\u00ba\u00b9W\u00ec\u009c\u00f1\u00e1\u008d\u00a2\u0082\u0017\u00a9\u00d7\u00a5{\b6[\u0010e \u00c63n\u00db|\u00b1~j\u008c\u00a9\u0006\u0004\u0096\u001e \u00b9\u009d]\u0019\u00a3G\u00d8G\u00ff\u001f\u009dLY\u00a1#&uX\u00e9MRw8iQjZ\u00ae/M^\u00eb(\u00d6\u009e\u00c2Qt\u00ff\u008e_#\u00ae\u000b\u00d5T\u00fdQI\u00c5\u0094j\u00e2\tLI\u00d3T\u00f5X#\u00ae\u0088\u00a6\u00d9\u00b1\u00b4\u00c6 L\u00b4\u009b8(\u0090\u00c5\u00fcKp\u00dc\u00076\u0094w\u00112\u0098\u0092\u0005s\u00fa \u008e`\u001a\u00cd!~\u00b1U\u00f9g\u00ef\u00f0\u0015\u00e0\u0015f;\u0003V\u0094n\u009d {t2\u00b2\u00a0\u00eb\u001b7\u00fc\u0012\u00a6\u007f\u0099H\u0005\u001fM\u00cc)\u0090\u00bbN\u00e3HVW\u009a\u00f5\u00fe\u00acZj\u0010\u00c6\u00fb\u00db\u0082\t\u00c8\u00dbVL\u0088\u00c33=C\u00e1\u0086(\u008b\u00dbV[z\u00a7\u0007\u00cf$g\u00ca\u00cd\u00a9u\u009b\u001f\u008c\u001cF\u00dbkOv\u00ac\"\u00c8\u0097\u00ffG0\u00b7\u00b5\u00ac\u00d5\u00f6\u0081\u00d4\u009b\u00d2>\u0018\u0001\u00d6\u001a7\u0082\u00b4S=\t\u00e2\u00a4\u00d2xIVW\u00a1\u00d1\u00a8\u00e3s9\u00caK\u0018\u00b8c\u0014\u00cd\u00fb'\u00f2\u00a5\u008f$e5\u00e3to\u00e0&\u00b0\u009ae}\u00a9Y9\u0018Us\u00d5\u0013\f\u009d\u00ba@J\u00b0\u00b6\u00cby;fX\u00ef\u007f\u0004\u0088\u00b5\u0019\u00ae\u0003@\u0087[h\"Q\u00be\u00ad\u001e\u00c55W\u00d4g\u001a\u00f1}\u0006\u00813Ul\u009czM\u0092\u00fa\u00bbk\u0091-\u00fcZ\u00a1\u0083W\u00fe\u00bb\u00a7]\u009a\u0085\u000f\u00d0\u0099$\u00f2\u00c8\u00c6\u00016\u00fe\u00c8e|e\u0016n\u00b8\u00dc\u00db8\u00a1\u001d\u00d0 ;M\u00ac\u001b\u00fcq\u00f48l\u00f2\u00101\u00e3\u00b9-q\u0090B\u00c7)<e\u00a6\u00195uT&N(\u0010\u00f4\u0010\u00aeRT\u00c5U\u00eb\u0018\u009dG\u00ee\u00dca\u0091\u0091\u008fi\u0018\u00ba\u008e\u00dc#x\u00f6l\u00f2\u008el\u000f\u00abF\u00d0\u00e9\u00ca\u009c\u0098\u0081\u0084k\u00d0\u000b\u00a98\u0085]\u00eeR\u00fa\u00c5j\u00cee\u00a5\u00e9\u000b\u00f8\u00f4<\u0016%\u00bb\u000e\u00dd\u00d5\u008d\u00f8`\u00b2\u001eF>\u0088C\u00a7=\u00b1\"d5\u00e6\u00a8\u00f8C \u00fb\u008a\u00ec\u00bb\u0084\u00e4\u00c1\u00b7&\u0016e:lH)\u0010\u00d0\u00a6\u00c7g\u00cc\u0014\u00f5zvU\u00cbHa\u0087<C\u0018\"=\u0087\u00fd,\u0018\u00c1~[\u0005\u000bwi\u00c0\u00d7{\u0095\u00b1\u00eb\u000e?\u00a4\u0094>".length();
                        var16_7 = 16;
                        var15_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block18;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = StashFinder.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "\r\u00d5\u00ac\u00ca\u00c0C\u00e3\u00bb>K\u00e9\u000e6sw\u00a6Bl\u00f3\u0003\t\u00f7Q\u0091c\u00f4s\u00f7\u00cdn\u00e1$|~!\u0005\u008c*1\u00a8\u008a\u00cc22\u0099\u00abO\fe\u00cbv,\u0091\u0006\u00e1\u00b9o\u008a\u00ea\u0088\u00cey\u00cb\u00c5\u009a\u00f9?\u000e\u0017S\r\u00f7 3Hc\u00eb\u009f\u00a2\u0005\"\u00cd*\u0013\u009cr\u00a5.\u007fT36\u00d44\u00b2\u008f+\u00b1\u00c3\u00ce-0\u00aa\u00e1\u00a4";
                            var19_6 = "\r\u00d5\u00ac\u00ca\u00c0C\u00e3\u00bb>K\u00e9\u000e6sw\u00a6Bl\u00f3\u0003\t\u00f7Q\u0091c\u00f4s\u00f7\u00cdn\u00e1$|~!\u0005\u008c*1\u00a8\u008a\u00cc22\u0099\u00abO\fe\u00cbv,\u0091\u0006\u00e1\u00b9o\u008a\u00ea\u0088\u00cey\u00cb\u00c5\u009a\u00f9?\u000e\u0017S\r\u00f7 3Hc\u00eb\u009f\u00a2\u0005\"\u00cd*\u0013\u009cr\u00a5.\u007fT36\u00d44\u00b2\u008f+\u00b1\u00c3\u00ce-0\u00aa\u00e1\u00a4".length();
                            var16_7 = 72;
                            var15_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block18;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = StashFinder.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block19;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                StashFinder.I = var20_3;
                StashFinder.J = new String[51];
                StashFinder.N = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[17];
                var3_13 = 0;
                var4_14 = "P\u00bf3\u0084\u00f7\u0017\u0000k\u0006gq\u00f5\u0001\u00b9\u00c0U\u00f27l\u0004\t\u0016v\u00c26\u008c\u00df\u00cd\u009e\u00c1\u007f\u008cv\u008cB\u0090\u0082\u0002a2\u00fd\u00fa\u008a\u00f3\u00a5z\u00ea\u00f7j\u00e0\u00e0\u00c2Qcq\u00dd\u009d\u00b9\u00da\u0097\u00bd8\u00bb\u00e3\u0018\u0019\u00d9\u0011t\u00b9=*\u00ff(\u00de+\u0093&\u0018\u0096\u00a6\u00ed\u00fe\u00f0A*\\\u00e6\u00f6\u0005\u00d8\u00fab\u0012\u0004Q=\u00a9\u0083\u00daQ-\u007f\u00ba\u00e67^\u00a4}z\u00e9\u00b7Y,\u00bf\u00e89t\u009dq";
                var5_15 = "P\u00bf3\u0084\u00f7\u0017\u0000k\u0006gq\u00f5\u0001\u00b9\u00c0U\u00f27l\u0004\t\u0016v\u00c26\u008c\u00df\u00cd\u009e\u00c1\u007f\u008cv\u008cB\u0090\u0082\u0002a2\u00fd\u00fa\u008a\u00f3\u00a5z\u00ea\u00f7j\u00e0\u00e0\u00c2Qcq\u00dd\u009d\u00b9\u00da\u0097\u00bd8\u00bb\u00e3\u0018\u0019\u00d9\u0011t\u00b9=*\u00ff(\u00de+\u0093&\u0018\u0096\u00a6\u00ed\u00fe\u00f0A*\\\u00e6\u00f6\u0005\u00d8\u00fab\u0012\u0004Q=\u00a9\u0083\u00daQ-\u007f\u00ba\u00e67^\u00a4}z\u00e9\u00b7Y,\u00bf\u00e89t\u009dq".length();
                var2_16 = 0;
                while (true) {
                    var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                    v10 = var6_12;
                    v11 = var3_13++;
                    v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                    v13 = -1;
                    break block20;
                    break;
                }
lbl81:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    var4_14 = "\u00c5\u00ef\u0001w\u00be\u0087:\u00bf-g\u00fd\u0080h\u001de\u00b6";
                    var5_15 = "\u00c5\u00ef\u0001w\u00be\u0087:\u00bf-g\u00fd\u0080h\u001de\u00b6".length();
                    var2_16 = 0;
                    while (true) {
                        var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                        v10 = var6_12;
                        v11 = var3_13++;
                        v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                        v13 = 0;
                        break block20;
                        break;
                    }
                    break;
                }
lbl94:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    break block21;
                    break;
                }
            }
            var8_18 = v12;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            v14 = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
            switch (v13) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl107:
                // 1 sources

                ** continue;
            }
        }
        StashFinder.L = var6_12;
        StashFinder.M = new Integer[17];
        StashFinder.E = 20000;
    }

    private static r a(r r2) {
        return r2;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static String b(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x3BB8;
        if (J[n3] == null) {
            Object[] objectArray;
            try {
                Long l3 = Thread.currentThread().threadId();
                objectArray = (Object[])K.get(l3);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    K.put(l3, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/e/ag", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l2 >>> 56);
            for (int i2 = 1; i2 < 8; ++i2) {
                byArray[i2] = (byte)(l2 << i2 * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = I[n3].getBytes("ISO-8859-1");
            StashFinder.J[n3] = StashFinder.b(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return J[n3];
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        String string2 = StashFinder.b(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static CallSite b(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/e/ag" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x596A;
        if (M[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = L[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])N.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    N.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/e/ag", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            StashFinder.M[n3] = n4;
        }
        return M[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = StashFinder.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/e/ag" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (P[n4] != null) {
            return n4;
        }
        Object object = O[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 32;
            case 1 -> 23;
            case 2 -> 1;
            case 3 -> 27;
            case 4 -> 17;
            case 5 -> 63;
            case 6 -> 54;
            case 7 -> 3;
            case 8 -> 24;
            case 9 -> 58;
            case 10 -> 35;
            case 11 -> 37;
            case 12 -> 29;
            case 13 -> 18;
            case 14 -> 47;
            case 15 -> 26;
            case 16 -> 56;
            case 17 -> 40;
            case 18 -> 5;
            case 19 -> 44;
            case 20 -> 4;
            case 21 -> 59;
            case 22 -> 53;
            case 23 -> 43;
            case 24 -> 51;
            case 25 -> 22;
            case 26 -> 50;
            case 27 -> 45;
            case 28 -> 39;
            case 29 -> 57;
            case 30 -> 20;
            case 31 -> 33;
            case 32 -> 28;
            case 33 -> 61;
            case 34 -> 2;
            case 35 -> 0;
            case 36 -> 19;
            case 37 -> 62;
            case 38 -> 8;
            case 39 -> 52;
            case 40 -> 34;
            case 41 -> 41;
            case 42 -> 6;
            case 43 -> 60;
            case 44 -> 49;
            case 45 -> 7;
            case 46 -> 21;
            case 47 -> 25;
            case 48 -> 11;
            case 49 -> 30;
            case 50 -> 9;
            case 51 -> 55;
            case 52 -> 42;
            case 53 -> 36;
            case 54 -> 15;
            case 55 -> 12;
            case 56 -> 48;
            case 57 -> 16;
            case 58 -> 38;
            case 59 -> 46;
            case 60 -> 31;
            case 61 -> 14;
            case 62 -> 10;
            default -> 13;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        StashFinder.P[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = O;
        O[0] = "EV<5\u001bvNV85\u001b?";
        objectArray[1] = ">vV ;\u0002 ~LoY\u001e:|E%]\u0016'\u007fs$a";
        objectArray[2] = "Ik8/PgBk</P$";
        objectArray[3] = "BD7BNKIK&\r3SZL/D";
        objectArray[4] = "{NEN>opNN";
        objectArray[5] = "u3qR\u0017'u3f\u000e\u001b(oxf\u0010\u001b=h\t6MJ";
        objectArray[6] = "B\u00152VQz759Y@5V;2RDo\"";
        objectArray[7] = Void.TYPE;
        StashFinder.P[7] = "java/lang/Void";
        objectArray[8] = "\u0017RiXH#\u0017R~\u0004D,\r\u0019~\u001aD9\nh+E\u001d";
        objectArray[9] = ")z5Xs>%z&";
        objectArray[10] = "\u000fnu\fH\u0015\u0006nv\fJ";
        objectArray[11] = "\u0019aJU\u001bG\u0012aNU\u000f";
        objectArray[12] = "\nB=\u000e\u0015\u001c\u0003B>\u000e\u0019";
        objectArray[13] = "<9\fN2D59\u000fN?";
        objectArray[14] = "l\u001c\u000696Qe\u001c\u000596";
        objectArray[15] = "\u00109\u0016\u0016)\u0003\u001b6\u0007YH\r\u0010=\u0003\u0003";
        objectArray[16] = "}#!hW}\b\u0003*gF2i\r!lBh\u001d";
        objectArray[17] = "\u001e\u0011.9a8k1%6pw\n?.=t-~";
        objectArray[18] = Boolean.TYPE;
        StashFinder.P[18] = "java/lang/Boolean";
        objectArray[19] = "g^";
        objectArray[20] = "{0\u0002sSkp0\n";
        objectArray[21] = "8|\u001c\u0013\n@1|\u001f\u0013\u0018";
        objectArray[22] = "*\u001e\u0013\b\u0015O_>\u0018\u0007\u0004\u0000>0\u0013\f\u0000ZJ";
        objectArray[23] = "|\"eb\u0013Mm\"e5";
        objectArray[24] = "BP\u0013T\u0015`7p\u0018[\u0004/V~\u0013P\u0000u\"";
        objectArray[25] = "\u00056\u001ej\u000f\u0015p\u0016\u0015e\u001eZ\u0011\u0018\u001en\u001a\u0000e";
        objectArray[26] = "C5;\r2Z6\u00150\u0002#\u0015W\u001b;\t'O#";
        objectArray[27] = "`-TuIh\u0015\r_zX't\u0003Tq\\}\u0000";
        objectArray[28] = "O!!U\u00182:\u0001*Z\t}[\u000f!Q\r'/";
        objectArray[29] = "\u001e\u0004 TP9k$+[Av\n* PE,~";
        objectArray[30] = "\u0000l?\u0012\u001c.uL4\u001d\ra\u0014B?\u0016\t;`";
        objectArray[31] = " \u0010\u0004\u0015q(1\u0010\u000b";
        objectArray[32] = "AM4\u0002-]PM4Y";
        objectArray[33] = ",Q\u0019\u001e\u0004>Yq\u0012\u0011\u0015q8\u007f\u0019\u001a\u0011+L";
        objectArray[34] = "?\u001a\u0002\u001e3\u0016J:\t\u0011\"Y+4\u0002\u001a&\u0003_";
        objectArray[35] = "/Wy@)^~B:'.b+N#J,\b)\u00040E";
        objectArray[36] = "\u0006F7\u0000r\u0001\u000b\t>]\u001f=q2\u00009\u001fQ\u000b\u0017>\b\u007f\\D\u001ec";
        objectArray[37] = "\u007f3\u0018:\u0002|.&[]\u001a@{*B0\u0007*y`Q?";
        objectArray[38] = "B|\u001d2$DO3\u0014oIo2\b-Wy\u0019\u001e$\u001c7tV\u0017y";
        objectArray[39] = "{a\u001e\u0019\u0004}}e\u001bB8kAa]\u0002\u0006>$+H\f\u0000\u0001|e\u001d\u0007F=#=C\u00168";
        objectArray[40] = ";?X\u0006\bnmn\\AsfT6\u0013DJuh;EA\b\u000fio\u001b\u0007\r367E\u0016s";
        objectArray[41] = "ZkkLjs_\"s^\u000bOb\u001bRpPO?5\"OzuX0kWh";
        objectArray[42] = "r;{Usw#.82hKv\"!_v!th2P";
        objectArray[43] = "?_s\u000e\u001csnJ0i\u001eO;F)\u0004\u0019%9\f:\u000b";
        objectArray[44] = "N\u0017z#\rq\u001f\u00029D\u0002MJ\u000e )\b'HD3&";
        objectArray[45] = "uq\u0005wA,# \u00010:$\u001axN5\u00037&u\u00180AMuq\u0005wA,# \u00010:";
        objectArray[46] = "J\fc'AW\u001b\u0019 @Ak@\u001d&|\u0004\u001b\u000e\u0005;#";
        objectArray[47] = "&C7\u0013{TwVttwh-\u001bs\u0015g\u0012xP>\u001a";
        objectArray[48] = "&\u0018\u0014ibbw\rW\u000eR^m\u001c]4bbzL\u001d";
        objectArray[49] = "\\h9\u0003lY\r}zdmeXqc\ti\u000fZ;p\u0006";
        objectArray[50] = "K\u001c)\u0005\u001b]\u001a\tjb\u001eaO\u0005s\u000f\u001e\u000bMO`\u0000";
        objectArray[51] = "Soa!@\u001f\u0005>ef;\u001f<f*c\u0002\u0004\u0000k|f@~Soa!@\u001f\u0005>ef;";
        objectArray[52] = "D~\u001dy\u0015B\u0015k^\u001e\u001b~@gGs\u0010\u0014B-T|";
        objectArray[53] = "l:\u0006kA\u0012au\u000f6,8\u001b[*\u000e\u001cO0b\u0007n\u0011\u00009?";
        objectArray[54] = "\u0012;b\fuTC.!kBh\u0016\"8\u0006p\u0002\u0014h+\t";
        objectArray[55] = "7*kzv\u001ca{o=\r\u0016X# 84\u0007d.v=v}7*kzv\u001ca{o=\r";
        objectArray[56] = "?G\u001b'_OnRX@\\s5V^|\u001a\u0003{NC#";
        objectArray[57] = "y:/}D\u000f(/l\u001a@3}#uwAY\u007fifx";
        objectArray[58] = "\u0002}dR[b\bs>M4lk$`JIf\u0001-aST\u0005";
        objectArray[59] = "\u0017?5\u000109\r77IS.r?:Aj=N2lD(G\u0017?5\u000109\r77IS";
        objectArray[60] = "lo{R-U=z85:ihc-R<\u0000h=9GSW3i%Z:Wm}05";
        objectArray[61] = "v=6c\u0013\n'(u\u0004\u00156r$li\u0016\\pn\u007ff";
        objectArray[62] = "\u0013\f\u0002\u0011P@\u0015\b\u0007JlV)\fA\nR\u0003LFT\u0004T<";
        objectArray[63] = "k| h\u0016i7pu8-{P,$/Du7/<6L";
        objectArray[64] = "si#QwU/ev\u0001LLH?yV7Pt`!\b&.";
        objectArray[65] = "sv{3\t2/z.c2#Hqt5S\"#-&uQI";
        objectArray[66] = "_3,\n?e\u000e&om(Y\u0002k-T;e\u000f=(\u0016Ad[cn\u0013};\u0003=\u007fm";
        objectArray[67] = "h&H/,R93\u000bH5nl?\u0012%)\u0004nu\u0001*";
        objectArray[68] = "/f^\u0019\u0018<5n\\Q{(JfQYB8vk\u0007\\\u0000Bw?Y\u001a\u0005~(g\u0007\u000b{";
        objectArray[69] = "\u0019G@v0XHR\u0003\u0011\u0001d\u001d\u0015\b\u007f?\u0019\u0013A\u001az";
        objectArray[70] = "5o>\\#E8\u007fd\u0002Za\u001fXK/ZS530\u001a!^%in";
        objectArray[71] = "\u0006Zs*\"\"WO0M\u0016\u001eQIt<0/\rV,(";
        objectArray[72] = "\u001f!LV*ZIpH\u0011QQp(\u0007\u0014hAL%Q\u0011*;\u001f!LV*ZIpH\u0011Q";
        objectArray[73] = "i[\u001bh!28NX\u000f5\u000e4\u0003\u001a6%29U\u001ft_3m\u000bYqcl5UH\u000f";
        objectArray[74] = "\u0019>AfenH+\u0002\u0001WRN-Fpwc\u00122\u001ed";
        objectArray[75] = "\u00118\u0019[}vGi\u001d\u001c\u0006w~1R\u0019?mB<\u0004\u001c}\u0017\u00118\u0019[}vGi\u001d\u001c\u0006";
        objectArray[76] = "o+p\u0004\u001bT>>3c.hk2*\u000e\u001e\u0002ix9\u0001";
        objectArray[77] = "I\u0012[\u0001zx\u0015\u001e\u000eQAgr\u001e\u000e\u0007xyN\u0013X\u0002:\u0003OG\u0006D??\u0010\u001fXUA";
        objectArray[78] = "\u0017\";\u0003\u0012aAs?Dibx+pAPzD&&D\u0012\u0000\u0017\";\u0003\u0012aAs?Di";
        Object[] objectArray2 = objectArray;
        objectArray[79] = "\u0006yy*$OS24%F_7/5s\u007fO\u000b\"cv=5\\.x6 JU$m;F";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = StashFinder.e(l2, l3);
            object = O[n2];
            try {
                if (!(object instanceof String)) break block2;
                StashFinder.O[n2] = clazz = Class.forName(P[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = StashFinder.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = StashFinder.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = StashFinder.e(l2, l3);
        Object object = O[n2];
        if (object instanceof String) {
            String string = P[n2];
            int n3 = string.indexOf(8);
            Class clazz = StashFinder.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = StashFinder.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = StashFinder.c(clazz3, string2, clazz2)) != null) {
                    StashFinder.O[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = StashFinder.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        StashFinder.O[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = StashFinder.f(1074360857680025L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = StashFinder.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = StashFinder.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = StashFinder.e(l2, l3);
        Object object = O[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = P[n2];
                int n4 = string2.indexOf(8);
                clazz3 = StashFinder.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = StashFinder.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = StashFinder.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        StashFinder.O[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = StashFinder.f(1074360857680025L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = StashFinder.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        StashFinder.O[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = StashFinder.f(1074360857680025L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == '\u00c8' || c2 == '\u00ea' || c2 == 'C' || c2 == 'I') {
                field = StashFinder.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == '\u00c8' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == '\u00ea' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == 'C' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = StashFinder.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == '\u00d5' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == 'G' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = StashFinder.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_2().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/e/ag" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(StashFinder.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(StashFinder.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_2() {
        try {
            return MethodHandles.lookup().findStatic(StashFinder.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

