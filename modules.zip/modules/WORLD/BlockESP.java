// === Kuzi module: BlockESP ===
// Category   : WORLD
// Description: Shows selected blocks with ESP
// Payload    : a.a.a.j.g.G (verified: True)

package kuzi.modules.world;

import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.g.a.h;
import kuzi.obf.g.a.j;
import kuzi.obf.g.a.p;
import kuzi.obf.h.b.b;
import kuzi.obf.h.b.e;
import kuzi.obf.h.b.l;
import kuzi.obf.h.b.v;
import kuzi.obf.j.g.aD;
import kuzi.obf.j.g.i;
import kuzi.obf.m.r;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.ChunkPos;
import net.minecraft.Block;
import net.minecraft.BlockPos;
import net.minecraft.Packet;
import net.minecraft.ClientboundBlockUpdatePacket;
import net.minecraft.ClientboundSectionBlocksUpdatePacket;
import net.minecraft.BlockState;
import net.minecraft.LevelChunk;
import net.minecraft.Minecraft;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class BlockESP
extends BaseModule
implements p,
kuzi.obf.g.a.v {
    private static final long m;
    private static final long n;
    private static final long o;
    private static final long p;
    private static final int q;
    private static final int r;
    private final e blockColor;
    private final b selectedBlocks;
    private final BoolSetting fill;
    private final BoolSetting outline;
    private final SliderSetting fillOpacity;
    private final BoolSetting tracers;
    private final l scanSpeed;
    private final Map detectedBlocks;
    private final Set queuedChunks;
    private final Queue chunkQueue;
    private final Map chunkScanTimes;
    private ExecutorService scanExecutor;
    private volatile boolean running;
    private long F;
    private long G;
    private long H;
    private long I;
    private Set selectedSnapshot;
    private ChunkPos lastPlayerChunk;
    private Iterator L;
    private static final long M;
    private static final String[] N;
    private static final String[] O;
    private static final Map P;
    private static final long[] Q;
    private static final Integer[] R;
    private static final Map S;
    private static final long[] T;
    private static final Long[] U;
    private static final Map V;
    private static final Object[] W;
    private static final String[] X;

    public BlockESP() {
        long l2;
        long l3 = l2 = M ^ 0x2738C386AB2FL;
        long l4 = l3 ^ 0x5BDFAF3EB715L;
        long l5 = l3 ^ 0x537754E029EBL;
        long l6 = l3 ^ 0x37C5FBA9DA49L;
        super("BlockESP", "Shows selected blocks with ESP", Category.WORLD);
        this.blockColor = new e("Block Color", new Color(255, 0, 0, 150));
        Object[] objectArray = new Object[2];
        objectArray[1] = l5;
        objectArray[0] = this.blockColor::a;
        this.selectedBlocks = new b("Selected Blocks", new HashSet()).a(objectArray);
        this.fill = new BoolSetting("Fill", true);
        this.outline = new BoolSetting("Outline", true);
        this.fillOpacity = new SliderSetting("Fill Opacity", 90.0, 0.0, 255.0, 5.0);
        this.tracers = new BoolSetting("Tracers", false);
        this.scanSpeed = new l("Scan Speed", i.ULTRA_FAST, i.class);
        this.detectedBlocks = new ConcurrentHashMap();
        this.queuedChunks = ConcurrentHashMap.newKeySet();
        this.chunkQueue = new ConcurrentLinkedQueue();
        this.chunkScanTimes = new ConcurrentHashMap();
        this.running = false;
        this.F = 0L;
        this.G = 0L;
        this.H = 0L;
        this.I = 0L;
        this.selectedSnapshot = new HashSet();
        this.lastPlayerChunk = null;
        Object[] objectArray2 = new Object[2];
        objectArray2[1] = new Setting[]{this.selectedBlocks, this.blockColor, this.fill, this.outline, this.fillOpacity, this.tracers, this.scanSpeed};
        objectArray2[0] = l6;
        this.l(objectArray2);
        Object[] objectArray3 = new Object[1];
        objectArray3[0] = l4;
        kuzi.obf.j.f.e.a(objectArray3);
    }

    @Override
    public void d() {
        long l2 = M ^ 0x5A938F244DBEL;
        long l3 = l2 ^ 0x232098AC9D22L;
        int[] nArray = aD.b();
        if (nArray != null) {
            if (BaseModule.a.level == null) {
                return;
            }
            Client.c.a(p.class, this);
            Client.c.a(kuzi.obf.g.a.v.class, this);
            Object[] objectArray = new Object[1];
            objectArray[0] = l3;
            this.a(objectArray);
        }
    }

    @Override
    public void g(Object[] objectArray) {
        long l2;
        long l3;
        block4: {
            l3 = (Long)objectArray[0];
            l2 = l3 ^ 0x6E0762367411L;
            try {
                try {
                    if (BlockESP.f("p", (Object)this, (long)5687172248611866542L, (long)l3) != false && ((Minecraft)BlockESP.f("P", (long)5687610551893870390L, (long)l3)).level != null) break block4;
                }
                catch (r r2) {
                    throw BlockESP.f("\u00e3", (Object)r2, (long)5689154077453712339L, (long)l3);
                }
                return;
            }
            catch (r r3) {
                throw BlockESP.f("\u00e3", (Object)r3, (long)5689154077453712339L, (long)l3);
            }
        }
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l2;
        BlockESP.f("p", (Object)this, (Object)objectArray2, (long)5687813479161017223L, (long)l3);
    }

    private void a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = l2 = M ^ l2;
        long l4 = l3 ^ 0x6224AA1EDED5L;
        long l5 = l3 ^ 0x140A01590815L;
        long l6 = l3 ^ 0x3C0363DC6146L;
        long l7 = l3 ^ 0x5AB1F5DCA460L;
        long l8 = l3 ^ 0x5866CBA98086L;
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l5;
        this.c(objectArray2);
        this.running = true;
        this.F = System.currentTimeMillis();
        this.I = System.currentTimeMillis();
        this.G = 0L;
        Object[] objectArray3 = new Object[1];
        objectArray3[0] = l6;
        this.selectedSnapshot = new HashSet(this.selectedBlocks.a(objectArray3));
        this.lastPlayerChunk = null;
        int[] nArray = aD.b();
        Object object = this.scanExecutor;
        if (nArray != null) {
            if (object != null) {
                this.scanExecutor.shutdownNow();
                this.scanExecutor = null;
            }
            object = this.scanSpeed.a();
        }
        Object[] objectArray4 = new Object[1];
        objectArray4[0] = l4;
        int n2 = ((i)((Object)object)).a(objectArray4);
        this.scanExecutor = Executors.newFixedThreadPool(n2, arg_0 -> BlockESP.lambda$startScanner$0(l7, arg_0));
        Object[] objectArray5 = new Object[1];
        objectArray5[0] = l8;
        this.f(objectArray5);
    }

    @Override
    public void e() {
        long l2 = M ^ 0x4FEF96C52D90L;
        long l3 = l2 ^ 0x1348B3461F6AL;
        Client.c.b(p.class, this);
        int[] nArray = aD.b();
        Client.c.b(kuzi.obf.g.a.v.class, this);
        this.running = false;
        int[] nArray2 = nArray;
        BlockESP blockESP = this;
        if (nArray2 != null) {
            if (blockESP.scanExecutor != null) {
                this.scanExecutor.shutdownNow();
                this.scanExecutor = null;
            }
            blockESP = this;
        }
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        blockESP.c(objectArray);
    }

    @Override
    public void i() {
        block33: {
            long l2;
            block32: {
                long l3;
                long l4;
                block24: {
                    int[] nArray;
                    long l5;
                    long l6;
                    long l7;
                    long l8;
                    block31: {
                        Set currentSet;
                        Set selected;
                        long l9;
                        block30: {
                            boolean selectionChanged;
                            block29: {
                                long l10;
                                block28: {
                                    block27: {
                                        Minecraft mc3102;
                                        block26: {
                                            long l11 = l8 = M ^ 0x4288DBB08A92L;
                                            l10 = l11 ^ 0x36269CB6D13BL;
                                            l2 = l11 ^ 0x6B1307E604A8L;
                                            l7 = l11 ^ 0x7C9E4889B251L;
                                            l6 = l11 ^ 0x56D8E6317247L;
                                            l9 = l11 ^ 0x524334C330FBL;
                                            l5 = l11 ^ 0x3E4E82B4029L;
                                            nArray = aD.b();
                                            mc3102 = BaseModule.a;
                                            if (nArray == null) break block26;
                                            if (mc3102.level == null) break block27;
                                            mc3102 = BaseModule.a;
                                        }
                                        if (mc3102.player != null) break block28;
                                    }
                                    return;
                                }
                                Object[] objectArray = new Object[1];
                                objectArray[0] = l10;
                                selected = this.selectedBlocks.a(objectArray);
                                selectionChanged = selected.isEmpty();
                                if (nArray == null) break block29;
                                if (selectionChanged) {
                                    this.detectedBlocks.clear();
                                    this.queuedChunks.clear();
                                    this.chunkScanTimes.clear();
                                    this.selectedSnapshot.clear();
                                    return;
                                }
                                currentSet = selected;
                                if (nArray == null) break block30;
                                selectionChanged = currentSet.equals(this.selectedSnapshot);
                            }
                            if (selectionChanged) break block31;
                            currentSet = this.queuedChunks;
                        }
                        currentSet.clear();
                        this.chunkScanTimes.clear();
                        this.selectedSnapshot = new HashSet(selected);
                        Object[] objectArray = new Object[1];
                        objectArray[0] = l9;
                        this.f(objectArray);
                    }
                    l4 = System.currentTimeMillis();
                    long l12 = l4 - this.F - BlockESP.d("a", (int)17537, (long)(0x16497AE3E10710EDL ^ l8));
                    l3 = l12 == 0L ? 0 : (l12 < 0L ? -1 : 1);
                    if (nArray != null) {
                        long l13;
                        if (l3 > 0) {
                            Object[] objectArray = new Object[1];
                            objectArray[0] = l7;
                            this.m(objectArray);
                            this.F = l4;
                        }
                        l3 = (l13 = l4 - this.G - BlockESP.d("a", (int)78, (long)(0x7D9BF1AC6E1A5425L ^ l8))) == 0L ? 0 : (l13 < 0L ? -1 : 1);
                    }
                    if (nArray != null) {
                        long l14;
                        if (l3 > 0) {
                            Object[] objectArray = new Object[1];
                            objectArray[0] = l5;
                            this.p(objectArray);
                            this.G = l4;
                        }
                        l3 = (l14 = l4 - this.I - BlockESP.d("a", (int)8655, (long)(0xD527BBBAABE75A0L ^ l8))) == 0L ? 0 : (l14 < 0L ? -1 : 1);
                    }
                    if (nArray == null) break block24;
                    if (l3 > 0) {
                        this.I = l4;
                        ChunkPos playerChunkPos = BaseModule.a.player.chunkPosition();
                        int offsetX = -2;
                        while (offsetX <= 2) {
                            block25: {
                                l3 = -2;
                                if (nArray == null) break block24;
                                for (long offsetZ = v4130520; offsetZ <= 2; ++offsetZ) {
                                    this.queuedChunks.remove(new ChunkPos(playerChunkPos.x + offsetX, playerChunkPos.z + offsetZ));
                                    if (nArray != null) {
                                        if (nArray != null) continue;
                                    }
                                    break block25;
                                }
                                ++offsetX;
                            }
                            if (nArray != null) continue;
                        }
                        this.H = 0L;
                    }
                    Object[] objectArray = new Object[1];
                    objectArray[0] = l6;
                    this.o(objectArray);
                    if (nArray == null) break block32;
                    long l15 = l4 - this.H - BlockESP.d("a", (int)14753, (long)(0x4F99223B20E36DCFL ^ l8));
                    l3 = l15 == 0L ? 0 : (l15 < 0L ? -1 : 1);
                }
                if (l3 <= 0) break block33;
                this.H = l4;
            }
            Object[] objectArray = new Object[1];
            objectArray[0] = l2;
            this.b(objectArray);
        }
    }

    @Override
    public void a(j j2) {
        ChunkPos playerChunkPos;
        block9: {
            BlockESP blockESP;
            long l2;
            block7: {
                block8: {
                    int[] nArray;
                    block6: {
                        block5: {
                            Minecraft mc;
                            block4: {
                                long l3 = M ^ 0x264BE9A14340L;
                                l2 = l3 ^ 0x5D81B3A8BF2BL;
                                nArray = aD.b();
                                mc = BaseModule.a;
                                if (nArray == null) break block4;
                                if (mc.level == null) break block5;
                                mc = BaseModule.a;
                            }
                            if (mc.player != null && this.running) break block6;
                        }
                        return;
                    }
                    playerChunkPos = BaseModule.a.player.chunkPosition();
                    blockESP = this;
                    if (nArray == null) break block7;
                    if (blockESP.lastPlayerChunk == null) break block8;
                    blockESP = this;
                    if (nArray == null) break block7;
                    if (blockESP.lastPlayerChunk.equals((Object)playerChunkPos)) break block9;
                }
                this.lastPlayerChunk = playerChunkPos;
                blockESP = this;
            }
            Object[] objectArray = new Object[1];
            objectArray[0] = l2;
            blockESP.n(objectArray);
        }
        long l4 = System.currentTimeMillis();
        this.chunkScanTimes.put(playerChunkPos, l4);
    }

    private void b(Object[] objectArray) {
        int[] nArray;
        long l2;
        long l3;
        block16: {
            block15: {
                Minecraft mc3102;
                block14: {
                    l3 = (Long)objectArray[0];
                    l2 = (l3 = M ^ l3) ^ 0x6C2BA8023FE0L;
                    nArray = aD.b();
                    mc3102 = BaseModule.a;
                    if (nArray == null) break block14;
                    if (mc3102.level == null) break block15;
                    mc3102 = BaseModule.a;
                }
                if (mc3102.player != null) break block16;
            }
            return;
        }
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l2;
        Set selected = this.selectedBlocks.a(objectArray2);
        int n2 = selected.isEmpty();
        if (nArray != null) {
            if (n2 != 0) {
                return;
            }
            n2 = (Integer)BaseModule.a.options.renderDistance().get();
        }
        int renderDistance = n2;
        ChunkPos playerChunkPos = BaseModule.a.player.chunkPosition();
        int playerChunkX = playerChunkPos.x;
        int playerChunkZ = playerChunkPos.z;
        int chunkX = playerChunkX - renderDistance;
        while (chunkX <= playerChunkX + renderDistance) {
            int[] nArray2;
            block12: {
                block13: {
                    int chunkZ = playerChunkZ - renderDistance;
                    while (chunkZ <= playerChunkZ + renderDistance) {
                        int[] nArray3;
                        block20: {
                            block17: {
                                block18: {
                                    LevelChunk mc28182;
                                    LevelChunk chunk;
                                    block19: {
                                        chunk = BaseModule.a.level.getChunkSource().getChunkNow(chunkX, chunkZ);
                                        nArray2 = nArray;
                                        if (l3 <= 0L) break block12;
                                        if (nArray2 == null) break block13;
                                        if (nArray == null) break block17;
                                        if (chunk == null) break block18;
                                        mc28182 = chunk;
                                        if (nArray == null) break block19;
                                        if (mc28182.isEmpty()) break block18;
                                        mc28182 = chunk;
                                    }
                                    ChunkPos chunkPos = mc28182.getPos();
                                    nArray3 = nArray;
                                    if (l3 < 0L) break block20;
                                    if (nArray3 == null) break block17;
                                    if (!this.queuedChunks.contains(chunkPos)) {
                                        this.chunkQueue.offer(chunk);
                                        this.queuedChunks.add(chunkPos);
                                    }
                                }
                                ++chunkZ;
                            }
                            nArray3 = nArray;
                        }
                        if (nArray3 != null) continue;
                    }
                    if (l3 >= 0L) {
                        ++chunkX;
                    }
                }
                nArray2 = nArray;
            }
            if (nArray2 != null) continue;
        }
    }

    private void c(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = M ^ l2;
        this.L = null;
        this.detectedBlocks.clear();
        this.queuedChunks.clear();
        this.chunkQueue.clear();
        this.chunkScanTimes.clear();
    }

    private void f(Object[] objectArray) {
        BlockESP blockESP;
        int[] nArray;
        long l2;
        long l3;
        block10: {
            block11: {
                block9: {
                    Minecraft mc3102;
                    block8: {
                        l3 = (Long)objectArray[0];
                        l2 = (l3 = M ^ l3) ^ 0x2007662E54A1L;
                        nArray = aD.b();
                        mc3102 = BaseModule.a;
                        if (nArray == null) break block8;
                        if (mc3102.level == null) break block9;
                        mc3102 = BaseModule.a;
                    }
                    if (mc3102.player == null) break block9;
                    blockESP = this;
                    if (nArray == null) break block10;
                    if (blockESP.D != null) break block11;
                }
                return;
            }
            blockESP = this;
        }
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l2;
        List list = blockESP.b(objectArray2);
        for (LevelChunk mc28182 : list) {
            block14: {
                LevelChunk chunk;
                block15: {
                    int[] nArray2;
                    block12: {
                        block13: {
                            if (l3 >= 0L && !this.running) break;
                            chunk = mc28182;
                            nArray2 = nArray;
                            if (l3 < 0L) break block12;
                            if (nArray2 == null) break block13;
                            if (chunk == null) break block14;
                            chunk = mc28182;
                        }
                        nArray2 = nArray;
                    }
                    if (nArray2 == null) break block15;
                    if (chunk.isEmpty()) break block14;
                    chunk = mc28182;
                }
                ChunkPos chunkPos = chunk.getPos();
                boolean alreadyQueued = this.queuedChunks.contains(chunkPos);
                if (nArray != null && !alreadyQueued) {
                    this.chunkQueue.offer(mc28182);
                    alreadyQueued = this.queuedChunks.add(chunkPos);
                }
            }
            if (nArray != null) continue;
        }
    }

    private void m(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = l2 = M ^ l2;
        long l4 = l3 ^ 0xD4A0B64DCADL;
        long l5 = l3 ^ 0x1B15CACD28EL;
        long l6 = l3 ^ 0x6B3AD55748ADL;
        long l7 = l6 >>> 16;
        int n2 = (int)(l6 << 48 >>> 48);
        int[] nArray = aD.b();
        Object object = BaseModule.a.player;
        if (nArray != null) {
            if (object == null) {
                return;
            }
            object = BaseModule.a.options.renderDistance().get();
        }
        int renderDistance = (Integer)object;
        ChunkPos playerChunkPos = BaseModule.a.player.chunkPosition();
        int playerChunkX = playerChunkPos.x;
        int playerChunkZ = playerChunkPos.z;
        long now = System.currentTimeMillis();
        this.detectedBlocks.keySet().removeIf(arg_0 -> this.lambda$performCleanup$1(l7, (char)n2, playerChunkX, playerChunkZ, renderDistance, now, arg_0));
        this.queuedChunks.removeIf(arg_0 -> BlockESP.lambda$performCleanup$2(playerChunkX, playerChunkZ, l5, renderDistance, arg_0));
        this.chunkScanTimes.entrySet().removeIf(arg_0 -> BlockESP.lambda$performCleanup$3(playerChunkX, playerChunkZ, l4, renderDistance, arg_0));
    }

    /*
     * Exception decompiling
     */
    private void n(Object[] var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * java.lang.UnsupportedOperationException
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.considerAsDoLoopStart(LoopIdentifier.java:383)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.identifyLoops1(LoopIdentifier.java:65)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:681)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    private void o(Object[] var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * java.lang.UnsupportedOperationException
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.considerAsDoLoopStart(LoopIdentifier.java:383)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.identifyLoops1(LoopIdentifier.java:65)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:681)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private void d(Object[] objectArray) {
        LevelChunk mc28182 = (LevelChunk)objectArray[0];
        int n2 = (Integer)objectArray[1];
        long l2 = (Long)objectArray[2];
        long l3 = ((long)n2 << 48 | l2 << 16 >>> 16) ^ M;
        long l4 = l3 ^ 0x27D033B3943FL;
        int n3 = (int)(l4 >>> 56);
        long l5 = l4 << 8 >>> 8;
        int[] nArray = aD.b();
        ExecutorService executorService = this.scanExecutor;
        if (nArray != null) {
            if (executorService == null) {
                return;
            }
            executorService = this.scanExecutor;
        }
        executorService.submit(() -> this.lambda$scheduleChunkScan$4((byte)n3, mc28182, l5));
    }

    /*
     * Exception decompiling
     */
    private void p(Object[] var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * java.lang.UnsupportedOperationException
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.considerAsDoLoopStart(LoopIdentifier.java:383)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.identifyLoops1(LoopIdentifier.java:65)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:681)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    @Override
    public void a(h h2) {
        block7: {
            Packet mc25962;
            Set set;
            int n2;
            int n3;
            int n4;
            block8: {
                boolean bl;
                Packet mc25963;
                block5: {
                    int[] nArray;
                    block6: {
                        long l2;
                        long l3 = l2 = M ^ 0x1C40774B6867L;
                        long l4 = l3 ^ 0x42AB59DEBC90L;
                        long l5 = l3 ^ 0x68EE304D33CEL;
                        long l6 = l3 ^ 0x2968AD943E1L;
                        n4 = (int)(l6 >>> 48);
                        n3 = (int)(l6 << 16 >>> 32);
                        n2 = (int)(l6 << 48 >>> 48);
                        nArray = aD.b();
                        if (!this.d() || BaseModule.a.level == null) {
                            return;
                        }
                        Object[] objectArray = new Object[1];
                        objectArray[0] = l5;
                        set = this.selectedBlocks.a(objectArray);
                        if (set.isEmpty()) {
                            return;
                        }
                        mc25963 = h2.c;
                        bl = mc25963 instanceof ClientboundBlockUpdatePacket;
                        if (nArray == null) break block5;
                        if (!bl) break block6;
                        ClientboundBlockUpdatePacket mc26262 = (ClientboundBlockUpdatePacket)mc25963;
                        Object[] objectArray2 = new Object[4];
                        objectArray2[3] = set;
                        objectArray2[2] = mc26262.getBlockState().getBlock();
                        objectArray2[1] = mc26262.getPos();
                        objectArray2[0] = l4;
                        this.q(objectArray2);
                        if (nArray != null) break block7;
                    }
                    mc25962 = mc25963 = h2.c;
                    if (nArray == null) break block8;
                    bl = mc25962 instanceof ClientboundSectionBlocksUpdatePacket;
                }
                if (!bl) break block7;
                mc25962 = mc25963;
            }
            ClientboundSectionBlocksUpdatePacket mc26372 = (ClientboundSectionBlocksUpdatePacket)mc25962;
            mc26372.runUpdates((arg_0, arg_1) -> this.lambda$onPacketReceive$6((short)n4, n3, set, (short)n2, arg_0, arg_1));
        }
    }

    private void q(Object[] objectArray) {
        block2: {
            Set<Object> selected;
            BlockPos pos;
            block3: {
                long l2 = (Long)objectArray[0];
                pos = (BlockPos)objectArray[1];
                Block block = (Block)objectArray[2];
                Set selection = (Set)objectArray[3];
                l2 = M ^ l2;
                int[] nArray = aD.b();
                selected = selection;
                if (nArray == null) break block2;
                if (!selected.contains(block)) break block3;
                this.detectedBlocks.put(pos.immutable(), block);
                if (nArray != null) break block2;
            }
            selected = this.detectedBlocks.remove(pos);
        }
    }

    private List b(Object[] objectArray) {
        Object object;
        int[] nArray;
        ArrayList<LevelChunk> arrayList;
        long l2;
        block13: {
            block14: {
                block12: {
                    Minecraft mc3102;
                    block11: {
                        l2 = (Long)objectArray[0];
                        l2 = M ^ l2;
                        arrayList = new ArrayList<LevelChunk>();
                        nArray = aD.b();
                        mc3102 = BaseModule.a;
                        if (nArray == null) break block11;
                        if (mc3102.level == null) break block12;
                        mc3102 = BaseModule.a;
                    }
                    object = mc3102.player;
                    if (nArray == null) break block13;
                    if (object != null) break block14;
                }
                return arrayList;
            }
            object = BaseModule.a.options.renderDistance().get();
        }
        int renderDistance = (Integer)object;
        ChunkPos playerChunkPos = BaseModule.a.player.chunkPosition();
        int playerChunkX = playerChunkPos.x;
        int playerChunkZ = playerChunkPos.z;
        int offsetX = -renderDistance;
        while (offsetX <= renderDistance) {
            int[] nArray2;
            block9: {
                block10: {
                    int offsetZ = -renderDistance;
                    while (offsetZ <= renderDistance) {
                        int[] nArray3;
                        block15: {
                            block16: {
                                block17: {
                                    LevelChunk mc28182;
                                    block18: {
                                        LevelChunk chunk;
                                        block19: {
                                            chunk = BaseModule.a.level.getChunkSource().getChunkNow(playerChunkX + offsetX, playerChunkZ + offsetZ);
                                            nArray2 = nArray;
                                            if (l2 <= 0L) break block9;
                                            if (nArray2 == null) break block10;
                                            nArray3 = nArray;
                                            if (l2 < 0L) break block15;
                                            if (nArray3 == null) break block16;
                                            if (chunk == null) break block17;
                                            mc28182 = chunk;
                                            if (l2 < 0L) break block18;
                                            boolean bl = mc28182.isEmpty();
                                            if (nArray == null) break block19;
                                            if (bl) break block17;
                                            bl = arrayList.add(chunk);
                                        }
                                        mc28182 = chunk;
                                    }
                                    ChunkPos chunkPos = mc28182.getPos();
                                    this.chunkScanTimes.put(chunkPos, System.currentTimeMillis());
                                }
                                ++offsetZ;
                            }
                            nArray3 = nArray;
                        }
                        if (nArray3 != null) continue;
                    }
                    if (l2 > 0L) {
                        ++offsetX;
                    }
                }
                nArray2 = nArray;
            }
            if (nArray2 != null) continue;
        }
        return arrayList;
    }

    public Map a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = M ^ l2;
        return this.detectedBlocks;
    }

    public Color a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = M ^ l2;
        return BlockESP.f("p", (Object)BlockESP.f("\u00e1", (Object)this, (long)-4865346013821131206L, (long)l2), (long)-4865452478124237082L, (long)l2);
    }

    public Color b(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        Block block = (Block)objectArray[1];
        long l3 = (l2 = M ^ l2) ^ 0x7456DE8BBC6L;
        Object[] objectArray2 = new Object[2];
        objectArray2[1] = block;
        objectArray2[0] = l3;
        return this.selectedBlocks.a(objectArray2);
    }

    public boolean a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = M ^ l2;
        return (Boolean)this.fill.a();
    }

    public boolean f(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = M ^ l2;
        return (Boolean)this.outline.a();
    }

    public int a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = M ^ l2;
        return ((Double)this.fillOpacity.a()).intValue();
    }

    public boolean g(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = M ^ l2;
        return (Boolean)this.tracers.a();
    }

    private void lambda$onPacketReceive$6(short s2, int n2, Set set, short s3, BlockPos mc23382, BlockState mc26802) {
        long l2 = ((long)s2 << 48 | (long)n2 << 32 >>> 16 | (long)s3 << 48 >>> 48) ^ M;
        long l3 = l2 ^ 0x7123E0551502L;
        Object[] objectArray = new Object[4];
        objectArray[3] = set;
        objectArray[2] = mc26802.getBlock();
        objectArray[1] = mc23382;
        objectArray[0] = l3;
        this.q(objectArray);
    }

    private void lambda$scheduleChunkScan$4(byte by, LevelChunk mc28182, long l2) {
        long l3 = ((long)by << 56 | l2 << 8 >>> 8) ^ M;
        long l4 = l3 ^ 0x51797F114E20L;
        try {
            Object[] objectArray = new Object[2];
            objectArray[1] = mc28182;
            objectArray[0] = l4;
            BlockESP.f("p", (Object)this, (Object)objectArray, (long)-8040510189510433817L, (long)l3);
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private static boolean lambda$performCleanup$3(int n2, int n3, long l2, int n4, Map.Entry entry) {
        int n5;
        block8: {
            block10: {
                l2 = M ^ l2;
                ChunkPos mc19232 = (ChunkPos)entry.getKey();
                CallSite callSite = BlockESP.f("\u00e3", (long)1012331175512009563L, (long)l2);
                int n6 = Math.abs(mc19232.x - n2);
                int n7 = Math.abs(mc19232.z - n3);
                try {
                    block9: {
                        try {
                            try {
                                try {
                                    n5 = n6;
                                    if (callSite == null) break block8;
                                    if (n5 > n4 + 2) break block9;
                                }
                                catch (r r2) {
                                    throw BlockESP.f("\u00e3", (Object)r2, (long)1013533758562024240L, (long)l2);
                                }
                                n5 = n7;
                                if (callSite == null) break block8;
                            }
                            catch (r r3) {
                                throw BlockESP.f("\u00e3", (Object)r3, (long)1013533758562024240L, (long)l2);
                            }
                            if (n5 <= n4 + 2) break block10;
                        }
                        catch (r r4) {
                            throw BlockESP.f("\u00e3", (Object)r4, (long)1013533758562024240L, (long)l2);
                        }
                    }
                    n5 = 1;
                    break block8;
                }
                catch (r r5) {
                    throw BlockESP.f("\u00e3", (Object)r5, (long)1013533758562024240L, (long)l2);
                }
            }
            n5 = 0;
        }
        return n5 != 0;
    }

    private static boolean lambda$performCleanup$2(int n2, int n3, long l2, int n4, ChunkPos mc19232) {
        int n5;
        block8: {
            block10: {
                l2 = M ^ l2;
                int n6 = Math.abs(mc19232.x - n2);
                int n7 = Math.abs(mc19232.z - n3);
                CallSite callSite = BlockESP.f("\u00e3", (long)13380148002448760L, (long)l2);
                try {
                    block9: {
                        try {
                            try {
                                try {
                                    n5 = n6;
                                    if (callSite == null) break block8;
                                    if (n5 > n4 + 2) break block9;
                                }
                                catch (r r2) {
                                    throw BlockESP.f("\u00e3", (Object)r2, (long)14574499227546899L, (long)l2);
                                }
                                n5 = n7;
                                if (callSite == null) break block8;
                            }
                            catch (r r3) {
                                throw BlockESP.f("\u00e3", (Object)r3, (long)14574499227546899L, (long)l2);
                            }
                            if (n5 <= n4 + 2) break block10;
                        }
                        catch (r r4) {
                            throw BlockESP.f("\u00e3", (Object)r4, (long)14574499227546899L, (long)l2);
                        }
                    }
                    n5 = 1;
                    break block8;
                }
                catch (r r5) {
                    throw BlockESP.f("\u00e3", (Object)r5, (long)14574499227546899L, (long)l2);
                }
            }
            n5 = 0;
        }
        return n5 != 0;
    }

    private boolean lambda$performCleanup$1(long l2, char c2, int n2, int n3, int n4, long l3, BlockPos mc23382) {
        int n5;
        block16: {
            block15: {
                CallSite callSite;
                int n6;
                int n7;
                long l4;
                block14: {
                    int n8;
                    block12: {
                        l4 = (l2 << 16 | (long)c2 << 48 >>> 48) ^ M;
                        n7 = mc23382.getX() >> 4;
                        n6 = mc23382.getZ() >> 4;
                        int n9 = Math.abs(n7 - n2);
                        int n10 = Math.abs(n6 - n3);
                        callSite = BlockESP.f("\u00e3", (long)-7346246581701443749L, (long)l4);
                        try {
                            block13: {
                                try {
                                    try {
                                        try {
                                            n8 = n9;
                                            if (callSite == null) break block12;
                                            if (n8 > n4 + 2) break block13;
                                        }
                                        catch (r r2) {
                                            throw BlockESP.f("\u00e3", (Object)r2, (long)-7345179791021625552L, (long)l4);
                                        }
                                        n8 = n10;
                                        if (callSite == null) break block12;
                                    }
                                    catch (r r3) {
                                        throw BlockESP.f("\u00e3", (Object)r3, (long)-7345179791021625552L, (long)l4);
                                    }
                                    if (n8 <= n4 + 2) break block14;
                                }
                                catch (r r4) {
                                    throw BlockESP.f("\u00e3", (Object)r4, (long)-7345179791021625552L, (long)l4);
                                }
                            }
                            n8 = 1;
                        }
                        catch (r r5) {
                            throw BlockESP.f("\u00e3", (Object)r5, (long)-7345179791021625552L, (long)l4);
                        }
                    }
                    return n8 != 0;
                }
                ChunkPos mc19232 = new ChunkPos(n7, n6);
                Long l5 = (Long)BlockESP.f("\u00e1", (Object)this, (long)-7346756583583755352L, (long)l4).get(mc19232);
                try {
                    try {
                        if (l5 == null) break block15;
                        long l6 = l3 - l5 - BlockESP.d("a", (int)16652, (long)(0x5610D1A513256F9AL ^ l4));
                        n5 = l6 == 0L ? 0 : (l6 < 0L ? -1 : 1);
                        if (callSite == null) break block16;
                    }
                    catch (r r6) {
                        throw BlockESP.f("\u00e3", (Object)r6, (long)-7345179791021625552L, (long)l4);
                    }
                    if (n5 <= 0) break block15;
                }
                catch (r r7) {
                    throw BlockESP.f("\u00e3", (Object)r7, (long)-7345179791021625552L, (long)l4);
                }
                n5 = 1;
                break block16;
            }
            n5 = 0;
        }
        return n5 != 0;
    }

    private static Thread lambda$startScanner$0(long l2, Runnable runnable) {
        l2 = M ^ l2;
        Thread thread = new Thread(runnable, (String)((Object)BlockESP.b("n", (int)12139, (long)(0xA48979B0E65E7A8L ^ l2))));
        thread.setDaemon(true);
        thread.setPriority(4);
        return thread;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block31: {
            block30: {
                block29: {
                    block28: {
                        block27: {
                            block26: {
                                BlockESP.M = kuzi.obf.h.b.v.a(7802517332284681381L, -3281320893657321032L, MethodHandles.lookup().lookupClass()).a(10529771361753L);
                                BlockESP.W = new Object[94];
                                BlockESP.X = new String[94];
                                BlockESP.c();
                                BlockESP.P = new HashMap<K, V>(13);
                                var22 = BlockESP.M ^ 137128450279388L;
                                var24_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                                v0 = SecretKeyFactory.getInstance("DES");
                                v1 = new byte[8];
                                v2 = v1;
                                v1[0] = (byte)(var22 >>> 56);
                                for (var25_2 = 1; var25_2 < 8; ++var25_2) {
                                    v2 = v2;
                                    v2[var25_2] = (byte)(var22 << var25_2 * 8 >>> 56);
                                }
                                var24_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                                var31_3 = new String[10];
                                var29_4 = 0;
                                var28_5 = "\u00de\u0087RN\u00ffu<\b@\u00e8\u00ed\u00db(@\u00b9\u0017QZ\u00cb\u00ab_\u00b2\u0090-\u00f4W2\u00bd\u00c4Nhb\u0010\u00fe\\h\u0018\u0096\u00dawqm\u001b\u00e6I\u00b7\u0012\u008b90\u00e8\u00c1Kd\u009e\u00be\u00d0\u0095\u0095\u007f\u00af\u00fdSr!0\u00133m\u00e6N\u00c2\u00e8HM\u00ab8QQ\u00d5\u00e7\u00d7\u00d3\u00ebLAo\n\u001a\u00e3UX0\u00b5\"\u00e2&\u00ef \u00f0[\u00e3\u001e>\u008e\u00d4\u00ce3\u00afV\u0082V\u009ct\u00e0\u00ef_\u0006fe\u00f4\u008b\u00b8:\u008b\u009cL\u0012\u0002\rE\u0010+\u00b1\u00990\u001e\u00e78\u00c0\u0000S\\8\u0006\u0001/u\u0018C\u00fb\"\u00a4\u00db\u00da\u00d8\u00b5\u00c6\\eb\u00a3\n\u009e6\u0090t\u00e8\u00d0~\u00e7\u00e5B\u0018z\u00fc\u0013\u00e3-r\u00ac%\r\u0018\u00fa\u0012I\u000e\u0014\u00c6t\u0089\u00bc'\u00b9\u00f1\u009d\u0084\u0010\u00937\u000f\u00815\u00a8\u0017\u00da\u0086 \u0006\u009c\u00df\u00e4\u00d6\u0080";
                                var30_6 = "\u00de\u0087RN\u00ffu<\b@\u00e8\u00ed\u00db(@\u00b9\u0017QZ\u00cb\u00ab_\u00b2\u0090-\u00f4W2\u00bd\u00c4Nhb\u0010\u00fe\\h\u0018\u0096\u00dawqm\u001b\u00e6I\u00b7\u0012\u008b90\u00e8\u00c1Kd\u009e\u00be\u00d0\u0095\u0095\u007f\u00af\u00fdSr!0\u00133m\u00e6N\u00c2\u00e8HM\u00ab8QQ\u00d5\u00e7\u00d7\u00d3\u00ebLAo\n\u001a\u00e3UX0\u00b5\"\u00e2&\u00ef \u00f0[\u00e3\u001e>\u008e\u00d4\u00ce3\u00afV\u0082V\u009ct\u00e0\u00ef_\u0006fe\u00f4\u008b\u00b8:\u008b\u009cL\u0012\u0002\rE\u0010+\u00b1\u00990\u001e\u00e78\u00c0\u0000S\\8\u0006\u0001/u\u0018C\u00fb\"\u00a4\u00db\u00da\u00d8\u00b5\u00c6\\eb\u00a3\n\u009e6\u0090t\u00e8\u00d0~\u00e7\u00e5B\u0018z\u00fc\u0013\u00e3-r\u00ac%\r\u0018\u00fa\u0012I\u000e\u0014\u00c6t\u0089\u00bc'\u00b9\u00f1\u009d\u0084\u0010\u00937\u000f\u00815\u00a8\u0017\u00da\u0086 \u0006\u009c\u00df\u00e4\u00d6\u0080".length();
                                var27_7 = 32;
                                var26_8 = -1;
lbl23:
                                // 2 sources

                                while (true) {
                                    v3 = ++var26_8;
                                    v4 = var28_5.substring(v3, v3 + var27_7);
                                    v5 = -1;
                                    break block26;
                                    break;
                                }
lbl28:
                                // 1 sources

                                while (true) {
                                    var31_3[var29_4++] = BlockESP.b(var32_9).intern();
                                    if ((var26_8 += var27_7) < var30_6) {
                                        var27_7 = var28_5.charAt(var26_8);
                                        ** continue;
                                    }
                                    var28_5 = "}\u00b2\u00c3F\u007f\u00ff/\u00b3z\u00dfh\u00f1\u00f4Z[\u0012a\u0094\u0005\u00c6\u00c3}\u00a5\u0099|j>X\u00eb\u00e3\u000eF\u0018\u00ecVC\u0092)\u00ae\u0016P\u0094\u00b4\u00b0Iv\u009e\u0011i\u00d6\u0086y0\u00e9\u0084,_";
                                    var30_6 = "}\u00b2\u00c3F\u007f\u00ff/\u00b3z\u00dfh\u00f1\u00f4Z[\u0012a\u0094\u0005\u00c6\u00c3}\u00a5\u0099|j>X\u00eb\u00e3\u000eF\u0018\u00ecVC\u0092)\u00ae\u0016P\u0094\u00b4\u00b0Iv\u009e\u0011i\u00d6\u0086y0\u00e9\u0084,_".length();
                                    var27_7 = 32;
                                    var26_8 = -1;
lbl37:
                                    // 2 sources

                                    while (true) {
                                        v6 = ++var26_8;
                                        v4 = var28_5.substring(v6, v6 + var27_7);
                                        v5 = 0;
                                        break block26;
                                        break;
                                    }
                                    break;
                                }
lbl42:
                                // 1 sources

                                while (true) {
                                    var31_3[var29_4++] = BlockESP.b(var32_9).intern();
                                    if ((var26_8 += var27_7) < var30_6) {
                                        var27_7 = var28_5.charAt(var26_8);
                                        ** continue;
                                    }
                                    break block27;
                                    break;
                                }
                            }
                            var32_9 = var24_1.doFinal(v4.getBytes("ISO-8859-1"));
                            switch (v5) {
                                default: {
                                    ** continue;
                                }
                                ** case 0:
lbl54:
                                // 1 sources

                                ** continue;
                            }
                        }
                        BlockESP.N = var31_3;
                        BlockESP.O = new String[10];
                        BlockESP.S = new HashMap<K, V>(13);
                        var11_10 = Cipher.getInstance("DES/CBC/NoPadding");
                        v7 = SecretKeyFactory.getInstance("DES");
                        v8 = new byte[8];
                        v9 = v8;
                        v8[0] = (byte)(var22 >>> 56);
                        for (var12_11 = 1; var12_11 < 8; ++var12_11) {
                            v9 = v9;
                            v9[var12_11] = (byte)(var22 << var12_11 * 8 >>> 56);
                        }
                        var11_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                        var17_12 = new long[11];
                        var14_13 = 0;
                        var15_14 = "\u00f5\u0012[@1\u008a\u0010\u00ab\u0000\u00daU\u00a0\u0096\u00f9\u00b8 %\u00bc\u00daGD6\u0016#\u001ck\u009dZk-Q>Mh\u00d8\u0004/\u009a\u00d4\u00fcD1\u0003\u00f5\u00e4\t\u00992\u00d9\u00ba\u00be\u00f6\u009c\u00c6\u00e9\f\u0098b^\u00aeq\u0017Z\u00fe\u00dc\u00ac\u00a9D\u009dx\u00b8\u0010";
                        var16_15 = "\u00f5\u0012[@1\u008a\u0010\u00ab\u0000\u00daU\u00a0\u0096\u00f9\u00b8 %\u00bc\u00daGD6\u0016#\u001ck\u009dZk-Q>Mh\u00d8\u0004/\u009a\u00d4\u00fcD1\u0003\u00f5\u00e4\t\u00992\u00d9\u00ba\u00be\u00f6\u009c\u00c6\u00e9\f\u0098b^\u00aeq\u0017Z\u00fe\u00dc\u00ac\u00a9D\u009dx\u00b8\u0010".length();
                        var13_16 = 0;
                        while (true) {
                            var18_17 = var15_14.substring(var13_16, var13_16 += 8).getBytes("ISO-8859-1");
                            v10 = var17_12;
                            v11 = var14_13++;
                            v12 = ((long)var18_17[0] & 255L) << 56 | ((long)var18_17[1] & 255L) << 48 | ((long)var18_17[2] & 255L) << 40 | ((long)var18_17[3] & 255L) << 32 | ((long)var18_17[4] & 255L) << 24 | ((long)var18_17[5] & 255L) << 16 | ((long)var18_17[6] & 255L) << 8 | (long)var18_17[7] & 255L;
                            v13 = -1;
                            break block28;
                            break;
                        }
lbl81:
                        // 1 sources

                        while (true) {
                            v10[v11] = v14;
                            if (var13_16 < var16_15) ** continue;
                            var15_14 = "\u00a1\u00c490K\u00a8\u00d0\u0093\u00b3\u00f2\r\u00f9\u00cf!\u00f7\u0082";
                            var16_15 = "\u00a1\u00c490K\u00a8\u00d0\u0093\u00b3\u00f2\r\u00f9\u00cf!\u00f7\u0082".length();
                            var13_16 = 0;
                            while (true) {
                                var18_17 = var15_14.substring(var13_16, var13_16 += 8).getBytes("ISO-8859-1");
                                v10 = var17_12;
                                v11 = var14_13++;
                                v12 = ((long)var18_17[0] & 255L) << 56 | ((long)var18_17[1] & 255L) << 48 | ((long)var18_17[2] & 255L) << 40 | ((long)var18_17[3] & 255L) << 32 | ((long)var18_17[4] & 255L) << 24 | ((long)var18_17[5] & 255L) << 16 | ((long)var18_17[6] & 255L) << 8 | (long)var18_17[7] & 255L;
                                v13 = 0;
                                break block28;
                                break;
                            }
                            break;
                        }
lbl94:
                        // 1 sources

                        while (true) {
                            v10[v11] = v14;
                            if (var13_16 < var16_15) ** continue;
                            break block29;
                            break;
                        }
                    }
                    var19_18 = v12;
                    var21_19 = var11_10.doFinal(new byte[]{(byte)(var19_18 >>> 56), (byte)(var19_18 >>> 48), (byte)(var19_18 >>> 40), (byte)(var19_18 >>> 32), (byte)(var19_18 >>> 24), (byte)(var19_18 >>> 16), (byte)(var19_18 >>> 8), (byte)var19_18});
                    v14 = ((long)var21_19[0] & 255L) << 56 | ((long)var21_19[1] & 255L) << 48 | ((long)var21_19[2] & 255L) << 40 | ((long)var21_19[3] & 255L) << 32 | ((long)var21_19[4] & 255L) << 24 | ((long)var21_19[5] & 255L) << 16 | ((long)var21_19[6] & 255L) << 8 | (long)var21_19[7] & 255L;
                    switch (v13) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl107:
                        // 1 sources

                        ** continue;
                    }
                }
                BlockESP.Q = var17_12;
                BlockESP.R = new Integer[11];
                BlockESP.q = 2;
                BlockESP.r = 2000;
                BlockESP.V = new HashMap<K, V>(13);
                var0_20 = Cipher.getInstance("DES/CBC/NoPadding");
                v15 = SecretKeyFactory.getInstance("DES");
                v16 = new byte[8];
                v17 = v16;
                v16[0] = (byte)(var22 >>> 56);
                for (var1_21 = 1; var1_21 < 8; ++var1_21) {
                    v17 = v17;
                    v17[var1_21] = (byte)(var22 << var1_21 * 8 >>> 56);
                }
                var0_20.init(2, (Key)v15.generateSecret(new DESKeySpec(v17)), new IvParameterSpec(new byte[8]));
                var6_22 = new long[8];
                var3_23 = 0;
                var4_24 = "-#\u00d8\u00da>R\u00cd\u0019\u00ea\u00e5k\u00d0\u00d9\u000b\u00act\u00afS?\u00bcjh'\u00e7}OT<\u00c7\u0016\u0012\u00f3\u00a1R\u0011'\u008b\u0017K\u00da\u00d53Z\u00f3\u007f\u00e71\u00cf";
                var5_25 = "-#\u00d8\u00da>R\u00cd\u0019\u00ea\u00e5k\u00d0\u00d9\u000b\u00act\u00afS?\u00bcjh'\u00e7}OT<\u00c7\u0016\u0012\u00f3\u00a1R\u0011'\u008b\u0017K\u00da\u00d53Z\u00f3\u007f\u00e71\u00cf".length();
                var2_26 = 0;
                while (true) {
                    var7_27 = var4_24.substring(var2_26, var2_26 += 8).getBytes("ISO-8859-1");
                    v18 = var6_22;
                    v19 = var3_23++;
                    v20 = ((long)var7_27[0] & 255L) << 56 | ((long)var7_27[1] & 255L) << 48 | ((long)var7_27[2] & 255L) << 40 | ((long)var7_27[3] & 255L) << 32 | ((long)var7_27[4] & 255L) << 24 | ((long)var7_27[5] & 255L) << 16 | ((long)var7_27[6] & 255L) << 8 | (long)var7_27[7] & 255L;
                    v21 = -1;
                    break block30;
                    break;
                }
lbl136:
                // 1 sources

                while (true) {
                    v18[v19] = v22;
                    if (var2_26 < var5_25) ** continue;
                    var4_24 = "\u00f0\u0086s!\u00af\u0011\u00ee\u0086<\u0004\u00f0\u008b\u00cb\u0004\u00bf\u00c5";
                    var5_25 = "\u00f0\u0086s!\u00af\u0011\u00ee\u0086<\u0004\u00f0\u008b\u00cb\u0004\u00bf\u00c5".length();
                    var2_26 = 0;
                    while (true) {
                        var7_27 = var4_24.substring(var2_26, var2_26 += 8).getBytes("ISO-8859-1");
                        v18 = var6_22;
                        v19 = var3_23++;
                        v20 = ((long)var7_27[0] & 255L) << 56 | ((long)var7_27[1] & 255L) << 48 | ((long)var7_27[2] & 255L) << 40 | ((long)var7_27[3] & 255L) << 32 | ((long)var7_27[4] & 255L) << 24 | ((long)var7_27[5] & 255L) << 16 | ((long)var7_27[6] & 255L) << 8 | (long)var7_27[7] & 255L;
                        v21 = 0;
                        break block30;
                        break;
                    }
                    break;
                }
lbl149:
                // 1 sources

                while (true) {
                    v18[v19] = v22;
                    if (var2_26 < var5_25) ** continue;
                    break block31;
                    break;
                }
            }
            var8_28 = v20;
            var10_29 = var0_20.doFinal(new byte[]{(byte)(var8_28 >>> 56), (byte)(var8_28 >>> 48), (byte)(var8_28 >>> 40), (byte)(var8_28 >>> 32), (byte)(var8_28 >>> 24), (byte)(var8_28 >>> 16), (byte)(var8_28 >>> 8), (byte)var8_28});
            v22 = ((long)var10_29[0] & 255L) << 56 | ((long)var10_29[1] & 255L) << 48 | ((long)var10_29[2] & 255L) << 40 | ((long)var10_29[3] & 255L) << 32 | ((long)var10_29[4] & 255L) << 24 | ((long)var10_29[5] & 255L) << 16 | ((long)var10_29[6] & 255L) << 8 | (long)var10_29[7] & 255L;
            switch (v21) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl162:
                // 1 sources

                ** continue;
            }
        }
        BlockESP.T = var6_22;
        BlockESP.U = new Long[8];
        BlockESP.o = 600L;
        BlockESP.p = 5000L;
        BlockESP.m = 5000L;
        BlockESP.n = 500L;
    }

    private static Exception a(Exception exception) {
        return exception;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static String b(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x5645;
        if (O[n3] == null) {
            Object[] objectArray;
            try {
                Long l3 = Thread.currentThread().threadId();
                objectArray = (Object[])P.get(l3);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    P.put(l3, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/g/G", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l2 >>> 56);
            for (int i2 = 1; i2 < 8; ++i2) {
                byArray[i2] = (byte)(l2 << i2 * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = N[n3].getBytes("ISO-8859-1");
            BlockESP.O[n3] = BlockESP.b(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return O[n3];
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        String string2 = BlockESP.b(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static CallSite b(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/G" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x550D;
        if (R[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = Q[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])S.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    S.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/g/G", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            BlockESP.R[n3] = n4;
        }
        return R[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = BlockESP.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/G" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static long d(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x348F;
        if (U[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = T[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])V.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    V.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/g/G", exception);
            }
            long l5 = ((long)byArray[0] & 0xFFL) << 56 | ((long)byArray[1] & 0xFFL) << 48 | ((long)byArray[2] & 0xFFL) << 40 | ((long)byArray[3] & 0xFFL) << 32 | ((long)byArray[4] & 0xFFL) << 24 | ((long)byArray[5] & 0xFFL) << 16 | ((long)byArray[6] & 0xFFL) << 8 | (long)byArray[7] & 0xFFL;
            BlockESP.U[n3] = l5;
        }
        return U[n3];
    }

    private static long d(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        long l3 = BlockESP.d(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Long.TYPE, l3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return l3;
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_2().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/G" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (X[n4] != null) {
            return n4;
        }
        Object object = W[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 52;
            case 1 -> 7;
            case 2 -> 17;
            case 3 -> 20;
            case 4 -> 24;
            case 5 -> 54;
            case 6 -> 53;
            case 7 -> 6;
            case 8 -> 33;
            case 9 -> 15;
            case 10 -> 45;
            case 11 -> 39;
            case 12 -> 36;
            case 13 -> 43;
            case 14 -> 22;
            case 15 -> 59;
            case 16 -> 12;
            case 17 -> 1;
            case 18 -> 18;
            case 19 -> 48;
            case 20 -> 26;
            case 21 -> 55;
            case 22 -> 5;
            case 23 -> 19;
            case 24 -> 11;
            case 25 -> 51;
            case 26 -> 4;
            case 27 -> 13;
            case 28 -> 58;
            case 29 -> 46;
            case 30 -> 34;
            case 31 -> 38;
            case 32 -> 9;
            case 33 -> 2;
            case 34 -> 0;
            case 35 -> 30;
            case 36 -> 56;
            case 37 -> 49;
            case 38 -> 31;
            case 39 -> 10;
            case 40 -> 47;
            case 41 -> 25;
            case 42 -> 44;
            case 43 -> 23;
            case 44 -> 27;
            case 45 -> 28;
            case 46 -> 41;
            case 47 -> 16;
            case 48 -> 37;
            case 49 -> 62;
            case 50 -> 21;
            case 51 -> 60;
            case 52 -> 35;
            case 53 -> 40;
            case 54 -> 32;
            case 55 -> 14;
            case 56 -> 29;
            case 57 -> 57;
            case 58 -> 42;
            case 59 -> 63;
            case 60 -> 61;
            case 61 -> 8;
            case 62 -> 50;
            default -> 3;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        BlockESP.X[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = W;
        W[0] = "L\u001f/0\u001b\u0017G\u001f)0=";
        objectArray[1] = Boolean.TYPE;
        BlockESP.X[1] = "java/lang/Boolean";
        objectArray[2] = "`BboFO`Bu3J@z\tu-JU}x'x\u0019\u0015";
        objectArray[3] = "|R<\u0003\u001dZwR7";
        objectArray[4] = "5%!h{K5%64wD/n6*wQ(\u001ffw&";
        objectArray[5] = "1e@L2\u001d:eFL2w";
        objectArray[6] = "\u001df";
        objectArray[7] = "\r!L`\u0010$\u0006.]/{0\u0004%JuW'\t";
        objectArray[8] = "A\u0015;kOR450d^\u001dU;;oZG!";
        objectArray[9] = Void.TYPE;
        BlockESP.X[9] = "java/lang/Void";
        objectArray[10] = "52j;8q+:pt[e/";
        objectArray[11] = "s.\u0002\u0019~Pm&\u0018V3Jw,\u0001\n\"@w;Z=(@z:\u0000\u0017\"v|=\u0002\u00113@";
        objectArray[12] = "m2EXVts:_\u0017)tb&V";
        objectArray[13] = "^`{/\u001dS@ha``C@";
        objectArray[14] = "\fh#\u0000LzyH(\u000f]5\u0018F#\u0004Yol";
        objectArray[15] = "K#;-\u001f&U+!b}:R6";
        objectArray[16] = "\u0001w\u0001u)\u001c\bw\u0002u-";
        objectArray[17] = "-i/\n g0|w(aj(z";
        objectArray[18] = "\u0017fs=\\i\u001efp=\\";
        objectArray[19] = "H2\u000bC*}C=\u001a\fKsH6\u001eV";
        objectArray[20] = "\u001a9-|yT\u00139.|{";
        objectArray[21] = Long.TYPE;
        BlockESP.X[21] = "java/lang/Long";
        objectArray[22] = "\u0016\u0010r\u0002\u0012\u001dc0y\r\u0003R\u0002>r\u0006\u0007\bv";
        objectArray[23] = "!\u000b/\u0006R<T+$\tCs5%/\u0002G)A";
        objectArray[24] = "P4z\u0019\u0012`%\u0014q\u0016\u0003/D\u001az\u001d\u0007u0";
        objectArray[25] = "\u0007z\u0019{oM\u000ez\u001a{l";
        objectArray[26] = "L\\mCU]9|fLD\u0012XrmG@H,";
        objectArray[27] = "Q\u0013OD\u001c\n$3DK\rEE=O@\t\u001f1";
        objectArray[28] = "@\u0016l\u0018\u001ds56g\u0017\f<T8l\u001c\bf ";
        objectArray[29] = "\f\u0017?\u0018\u0006?\u0012\u001f%Wa>\u0003\u0004(\rG8";
        objectArray[30] = "\u0016+?:u*\u001f+<:x";
        objectArray[31] = "eT>F;/\u0010t5I*`qz>B.:\u0005";
        objectArray[32] = "D\u0013V+\u0007uO\u0013P+\u000f";
        objectArray[33] = "\u000e.UQ2n{\u000e^^#!\u001a\u0000UU'{n";
        objectArray[34] = Integer.TYPE;
        BlockESP.X[34] = "java/lang/Integer";
        objectArray[35] = "hb VrY\u001dB+Yc\u0016|L RgL\b";
        objectArray[36] = "4;oc\\\u0000A\u001bdlMO \u0015ogI\u0015T";
        objectArray[37] = "\u001cz{`zg\u0015zx`v";
        objectArray[38] = "]!z\u000f\u0012?(\u0001q\u0000\u0003pI\u000fz\u000b\u0007*=";
        objectArray[39] = "X\u0011\u001a0)\n-1\u0011?8EL?\u001a4<\u001f8";
        objectArray[40] = "gZ\u0018%^p\u0012z\u0013*O?st\u0018!Ke\u0007";
        objectArray[41] = "S\u001b\u001aV?5X\u001b\u001dV;";
        objectArray[42] = "\u001eo27&TkO987\u001b\nA233A~";
        objectArray[43] = "M7>\u00155qF76";
        objectArray[44] = "\u0005\u000ec$l\u0005p.h+}J\u0011 c y\u0010e";
        objectArray[45] = "#{CfX\u007fV[HiI07UCbMjC";
        objectArray[46] = "\u000fo\u000e:0^zO\u00055!\u0011\u001bA\u000e>%Ko";
        objectArray[47] = "viI\fer/-NuV\nto\u0014\u0015ht*|\u0011\u0012";
        objectArray[48] = "\fH\":mmPZ><\u0014<lZv'$2\u001cX&!-U\u0007\u001f%\"*m\u0014I(=\u0014";
        objectArray[49] = "m$\u001b;:;16\u0007=Cj\r6O&sd}4\u001f z\u0003m$\u001b;:;16\u0007=C";
        objectArray[50] = "w\u001el\u0004\u0013A.Zk}\u00119s[lL\u0013Pt\u00015C";
        objectArray[51] = "6K\u001f\u0000\nGo\u000f\u0018y4?`PG\u001e\u0007T7Y\u0003\u001e";
        objectArray[52] = "\u0012\u0004)LO6\u0012\u00045I)\r38\u0015=~\u001e>?\u0013tL0\u0011\\)\u0012L0\rY";
        objectArray[53] = "\u007f\u001b6\u000eO &_1wRX;\\0GX(9\f6N?f:\u000f9\u000eNg6\u00197w";
        objectArray[54] = "sM\u0014\u0018!P*\t\u0013a\u0015(+V\u001d\u001d!P+\n\u001e\u001e";
        objectArray[55] = "\u0016\u001ct(-hOXsQ4\u0010\u0011\u001fh<;!M\u0019`h],P\u0018\u007f7lpV\u0010+Q";
        objectArray[56] = "5\u00029\u0003\u0018`lF>z\u0018\u0018c\u00171\u0005\u0002)?\u0004%G";
        objectArray[57] = "\u001a\u000fH+e\u0005CKORY}\u001e\rE,x\u0013L\u0001Sj";
        objectArray[58] = "\u000b\u000f\u000eR+\u0003RK\t+0{OH\b\u001b<\u000bM\u0018\u000e\u0012[EN\u001b\u0001R*DB\r\u000f+";
        objectArray[59] = "cBCR\u007f\u0010:\u0006D+vh'\u0005E\u001bh\u0018%UC\u0012\u000fV&VLR~W*@B+";
        objectArray[60] = "<q\t\u0004@\u0019/}\u0000O)\nP!\u0006[N\u001f1}WMCc";
        objectArray[61] = "wet@t#.!s9h[3\"r\tc+1rt\u0000\u0004e2q{@ud>gu9";
        objectArray[62] = "aRU,o78\u0016RUbO7G]*u~kTIh";
        objectArray[63] = ".z8UONrh$S6\u001fNhlH\u0006\u0011>j<N\u000fv\u007f-:ZQ\u0004#y,F6";
        objectArray[64] = "\u00125D5g\u0003KqCLZ{X*O\"x\u0004@,M";
        objectArray[65] = "[2$[*a\u001fi(\u000eTpa55\u001bk~\u000en:\u0005=";
        objectArray[66] = "zN~R9b#\ny+\t\u001a,U&L4q{\\bL";
        objectArray[67] = "Ua7\u001d\nF\f%0d\u0002>\u0011&1T\u001dN\u0013v7]z\u0000\u0010u8\u001d\u000b\u0001\u001cc6d";
        objectArray[68] = "rV\u0018\u0019\u0011\u0018+\u0012\u001f`\b`6\u0011\u001eP\u0006\u00104A\u0018Ya^7B\u0017\u0019\u0010_;T\u0019`";
        objectArray[69] = "S?G\u00022<\u0004~\u0013^Hi9-\u0011\u0004->\u0001>G\t2\u0000";
        objectArray[70] = "C,\u0011\u0012.%IfDK@&xbSG&/\u0001aC\u0018.L";
        objectArray[71] = "RJ@izo\u000b\u000eG\u0010q\u0017\u0003MJ|p+T\f\u001e ";
        objectArray[72] = "\u0016\u0005{}OF\r\u0006\u007fx#CjB~`\u0013M\u001a@.f\u001a*TC-iZ[UO;g#";
        objectArray[73] = "\u0018QO\tj&A\u0015Hpk^GDUNwg^V\u0011H";
        objectArray[74] = "+mtG\t\u001er)s>\u0013fo*r\u000e\u001e\u0016mzt\u0007yXny{G\bYbou>";
        objectArray[75] = "b\u00072\u001f\u001b[&\\>JeOXK2N\u000bL'S4Le";
        objectArray[76] = "kB@\u0005=g*OO_]\u0000Pifq]#fQ\u001a]ebk^@";
        objectArray[77] = ";?(\u0012\r\u0013;?4\u0017k\u001f^ wJ[\u0012.\"'LRu9e.NZ\u001ef-4Wk";
        objectArray[78] = "U\u0013SUd_\fWT,^'^\n\\OlH\r\n[\u0012";
        objectArray[79] = "\u001c7HP\u0002\u0017EsO);o\u0016sA[\u0015\u001dJ'WG";
        objectArray[80] = "\u0000\u001e\u0011`Z}\u0000\u001e\re<re\u0001N8\f|\u0015\u0003\u001e>\u0005\u001b\u0002D\u0017<\rp]\f\r%<";
        objectArray[81] = "l^w\u00101D5\u001api></[,P \u0003)OlP";
        objectArray[82] = "5FUkrbl\u0002R\u0012@\u001a?\u0002\\`ehcVJ|";
        objectArray[83] = "\u0004V.b^a]\u0012)\u001bH\u0019@\u0011(+IiBA.\".'AB!b_&MT/\u001b";
        objectArray[84] = ")4\u0000-F\u0005pp\u0007TX}ms\u0006dQ\ro#\u0000m6Cl \u000f-GB`6\u0001T";
        objectArray[85] = "\tmatotP)f\rP\f_v9jbg\b\u007f}j";
        objectArray[86] = "A\u001deokm\u0018Yb\u0016g\u0015\u001a\u000enkb-F\u001crm";
        objectArray[87] = "Hk\u0007:t\u001d\u0011/\u0000Cce\f,\u0001sc\u0015\u000e|\u0007z\u0004[\r\u007f\b:uZ\u0001i\u0006C";
        objectArray[88] = "[`N|\u0017k\u0002$I\u0005\u0002\u0013\u001f'H5\u0000c\u001dwN<g-\u001etA|\u0016,\u0012bO\u0005";
        objectArray[89] = "b]\u0014\u001c\u001dw;\u0019\u0013e&\u000ff\u0018\u0014T\u001dfaBM[";
        objectArray[90] = "uA\u0007/;\t,\u0005\u0000V5q#T\u000f)!@\u007fG\u001bk";
        objectArray[91] = "\ta\u0007l\u0007OM:\u000b9yS3#_0IPC!\u000f6@7\r\"\f9\u0000F\f.\u001a7y";
        objectArray[92] = "iE6S6Y0\u00011*,!-\u00020\u001a!Q/R6\u0013FH5Qm\u0016(K>\\k*";
        Object[] objectArray2 = objectArray;
        objectArray[93] = "4\u0007E1=_mCBH\f'b\u001c\u001d/0L5\u0015Y/";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = BlockESP.e(l2, l3);
            object = W[n2];
            try {
                if (!(object instanceof String)) break block2;
                BlockESP.W[n2] = clazz = Class.forName(X[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = BlockESP.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = BlockESP.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = BlockESP.e(l2, l3);
        Object object = W[n2];
        if (object instanceof String) {
            String string = X[n2];
            int n3 = string.indexOf(8);
            Class clazz = BlockESP.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = BlockESP.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = BlockESP.c(clazz3, string2, clazz2)) != null) {
                    BlockESP.W[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = BlockESP.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        BlockESP.W[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = BlockESP.f(1369467794491679L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = BlockESP.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = BlockESP.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = BlockESP.e(l2, l3);
        Object object = W[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = X[n2];
                int n4 = string2.indexOf(8);
                clazz3 = BlockESP.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = BlockESP.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = BlockESP.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        BlockESP.W[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = BlockESP.f(1369467794491679L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = BlockESP.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        BlockESP.W[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = BlockESP.f(1369467794491679L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == '\u00e1' || c2 == 'z' || c2 == 'P' || c2 == '\u00dc') {
                field = BlockESP.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == '\u00e1' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == 'z' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == 'P' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = BlockESP.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == 'p' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == '\u00e3' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = BlockESP.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite f(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_3().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/G" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(BlockESP.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(BlockESP.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_2() {
        try {
            return MethodHandles.lookup().findStatic(BlockESP.class, "d", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_3() {
        try {
            return MethodHandles.lookup().findStatic(BlockESP.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

