// === Kuzi module: BeehiveESP ===
// Category   : WORLD
// Description: Highlights beehives and bee nests
// Payload    : a.a.a.j.g.F (verified: False)

package kuzi.modules.world;

import java.awt.Color;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.b.e;
import kuzi.obf.j.f.c;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;

public class BeehiveESP
extends BaseModule {
    public final SliderSetting range;
    public final BoolSetting fill;
    public final BoolSetting outline;
    public final BoolSetting tracers;
    public final e q;
    public final e r;
    public final e s;
    public final BoolSetting level0Empty0;
    public final BoolSetting level120Honey;
    public final BoolSetting level240Honey;
    public final BoolSetting level360Honey;
    public final BoolSetting level480Honey;
    public final BoolSetting level5Full100;
    public final BoolSetting beehives;
    public final BoolSetting beeNests;
    private static final long B = 14823794448535L;
    private static final Object[] I = new Object[]{"5}}AhY>}{AO", "X\u0013)WjuQ\u0013*Wh", "}dN\u0000=;tdM\u00009", "\\D#\u0011y\u000fWD+", "~7\u0006d0\u001dw7\u0005d<", "3Ow\u0003h\u00078Op\u0003j", "mC^tt,\u0018cU{ecym^pa9\r", Void.TYPE, "up`'\u000b\u0003~pk", "3\u0006,`p-F&'oab'(,de8S", "\t\u0007exQ\u0016\u0014\u0012=Z\u0010\u001b\f\u0014", " \u0015#^\u0005S+\u001a2\u0011d] \u00116K", "\u0016f\u001b\u000fFtD\u007f\bc_\u001b\u0016=\u0005[QxIbUX", "]t\u007f*d!\u000fmlF\u007fN]/a~s-\u0002p1}", "S\u0019Nm%[\u0001\u0000]\u0001%4SBP92W\f\u001d\u0000:", "\u0017|\bi0VEe\u001b\u0005,9\u0017`\u0013j-\u0002Sc\u0017k", "#^S_wEqG@3h*#BH\\j\u0011gAL]", "Nc\u0006=eF\u001cz\u0015Q{)N8\u0018irJ\u0011gHj", "=\u0012mGA\u0013y\u0011iF:A\u0004V4KXD5ScT[(", "S'p&GA\u0001>cJQ.S|nrPM\f#>q", "Hr\u0016^lK\u001ak\u00052v$H)\b\n{G\u0017vX\t", "yR{z\u0019u+Kh\u0016\u000e\u001ay\te.\u000ey&V5-", "(Q>< Z`[/}CfUf\u0006\fC\u0003\u007f@># KuQ\u007f", "vzHuN\u001a$c[\u0019SuvfSvSN2eWw", "$W;#V\u0010vN(Oy\u007f$\f%wA\u001c{Sut", "}t3id\u0017/m \u0005|x}/-=s\u001b\"p}>", "\u001c\u0007gDp\u001aN\u001et(du\u001c\\y\u0010g\u0016C\u0003)\u0013", "\u001b*`O3\u001aI3s#0u\u0019u\u007fR*\u0004B3sS", "fad\u001ef! #~\b\t0Zbx\u0004ofkbv\u00072Ygfh\u00022=#3e\u000f\t", "`~gzw%2gt\u0016vJ`%y.`)?z)-", "~=\u001a\u001b\r8;;_\u0019p;Cx]\u0002\u0016`rxS\u0001K_~|M\u0004K;:)@\tp"};
    private static final String[] J = new String[]{null, null, null, null, null, null, null, "java/lang/Void", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null};

    public BeehiveESP() {
        long l2;
        long l3 = l2 = B ^ 0x6627AF530675L;
        long l4 = l3 ^ 0x43C7696D97E5L;
        long l5 = l3 ^ 0x4ABFCB2E05F7L;
        super("BeehiveESP", "Highlights beehives and bee nests", Category.WORLD);
        this.range = new SliderSetting("Range", 100.0, 10.0, 256.0, 1.0);
        this.fill = new BoolSetting("Fill", true);
        this.outline = new BoolSetting("Outline", true);
        this.tracers = new BoolSetting("Tracers", false);
        this.q = new e("Fill Color", new Color(255, 200, 0, 50));
        this.r = new e("Outline Color", new Color(255, 200, 0, 200));
        this.s = new e("Tracer Color", new Color(255, 215, 0, 200));
        this.level0Empty0 = new BoolSetting("Level 0 (Empty - 0%)", false);
        this.level120Honey = new BoolSetting("Level 1 (20% Honey)", false);
        this.level240Honey = new BoolSetting("Level 2 (40% Honey)", false);
        this.level360Honey = new BoolSetting("Level 3 (60% Honey)", false);
        this.level480Honey = new BoolSetting("Level 4 (80% Honey)", false);
        this.level5Full100 = new BoolSetting("Level 5 (Full - 100%)", true);
        this.beehives = new BoolSetting("Beehives", true);
        this.beeNests = new BoolSetting("Bee Nests", true);
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.range, this.fill, this.outline, this.tracers, this.q, this.r, this.s, this.level0Empty0, this.level120Honey, this.level240Honey, this.level360Honey, this.level480Honey, this.level5Full100, this.beehives, this.beeNests};
        objectArray[0] = l5;
        this.l(objectArray);
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l4;
        kuzi.obf.j.f.c.a(objectArray2);
    }

    public int a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = B ^ l2;
        return this.q.a().getRGB();
    }

    public int c(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = B ^ l2;
        return this.r.a().getRGB();
    }

    public int d(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = B ^ l2;
        return this.s.a().getRGB();
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = BeehiveESP.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = BeehiveESP.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = BeehiveESP.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = BeehiveESP.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }
}

