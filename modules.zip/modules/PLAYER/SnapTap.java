// === Kuzi module: SnapTap ===
// Category   : PLAYER
// Description: Allows you to strafe freely
// Payload    : a.a.a.j.e.ae (verified: True)

package kuzi.modules.player;

import java.lang.invoke.MethodHandles;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.b.v;

public class SnapTap
extends BaseModule {
    public static long m;
    public static long n;
    public static long o;
    public static long p;
    private static final long q;
    private static final String[] r;
    private static final String[] s;
    private static final Map t;
    private static final Object[] u;
    private static final String[] v;

    public SnapTap() {
        super("SnapTap", "Allows you to strafe freely", Category.PLAYER);
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        q = kuzi.obf.h.b.v.a(6215636379333053144L, 8533371572415818029L, MethodHandles.lookup().lookupClass()).a(74759166098989L);
        long l2 = q ^ 0x3F79861411F9L;
        u = new Object[9];
        v = new String[9];
        SnapTap.c();
        t = new HashMap(13);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l2 >>> 56);
        for (int i2 = 1; i2 < 8; ++i2) {
            byArray2 = byArray2;
            byArray2[i2] = (byte)(l2 << i2 * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
        String[] decodedStrings = new String[2];
        int decodedIndex = 0;
        String payload = "<\u00a9\u00e1>\u00c9\u00da\u00fbg\u0004\u00c4\u00fa\u0085\u00c5l\u00ab\u00e9\f\u00b7\u00dc\u009a\u00e2\u00a3\u008cv\u00fa\u00e3\u00c5\u0088]U5\u009b\u00e9\u0091\u00b1\u00bd\u00f0Je\u0014\u008ei9\u0017\u0095\u00bed-\u001b\u001a\u001d)T\u00fe\u00d9\u00cc\u0010\u00d6\u00be]\u0018,\u0097\u0099b\u0018\u00cf\u008e\u00ae\u00cb\u00c9\u007fN";
        int payloadLength = "<\u00a9\u00e1>\u00c9\u00da\u00fbg\u0004\u00c4\u00fa\u0085\u00c5l\u00ab\u00e9\f\u00b7\u00dc\u009a\u00e2\u00a3\u008cv\u00fa\u00e3\u00c5\u0088]U5\u009b\u00e9\u0091\u00b1\u00bd\u00f0Je\u0014\u008ei9\u0017\u0095\u00bed-\u001b\u001a\u001d)T\u00fe\u00d9\u00cc\u0010\u00d6\u00be]\u0018,\u0097\u0099b\u0018\u00cf\u008e\u00ae\u00cb\u00c9\u007fN".length();
        int chunkSize = 56;
        int offset = -1;
        while (true) {
            int chunkStart = ++offset;
            byte[] chunkBytes = cipher.doFinal(payload.substring(chunkStart, chunkStart + chunkSize).getBytes("ISO-8859-1"));
            decodedStrings[decodedIndex++] = SnapTap.b(chunkBytes).intern();
            if ((offset += chunkSize) >= payloadLength) {
                r = decodedStrings;
                s = new String[2];
                m = 0L;
                n = 0L;
                o = 0L;
                p = 0L;
                return;
            }
            chunkSize = payload.charAt(offset);
        }
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static void c() {
        Object[] objectArray = u;
        u[0] = "G<\\zw\u0012L<T";
        objectArray[1] = "uhLAW\u000f~hHAWD";
        objectArray[2] = Long.TYPE;
        SnapTap.v[2] = "java/lang/Long";
        objectArray[3] = "W\u001a&Y$\u007f\\\u00157\u0016EqW\u001e3L";
        objectArray[4] = ",$\b/\u000f$j$\u000ePm\u0010_E>\n5n&o\fjE(&i";
        objectArray[5] = "\f\u001e_\u0006F\u0014\u0018\u0019FoFxO^K\u0001L\u001aJQ\u001d\u0005";
        objectArray[6] = "l1_k\u0017\u0010x6F\u0002\n|/qKl\u001d\u001e*~\u001dh";
        objectArray[7] = "7~Vj0a#yO\u0003/\rt>Bm:oq1\u0014i";
        Object[] objectArray2 = objectArray;
        objectArray[8] = "pJ\b\u0002ICdM\u0011kW/3\n\u001c\u0005CM6\u0005J\u0001";
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = SnapTap.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = SnapTap.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = SnapTap.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = SnapTap.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }
}

