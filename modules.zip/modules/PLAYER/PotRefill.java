// === Kuzi module: PotRefill ===
// Category   : PLAYER
// Description: Refills a potion into your hotbar/slot/off-hand by opening the inventory (like AutoTotem).
// Payload    : a.a.a.j.e.aa (verified: True)

package kuzi.modules.player;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.module.Module;
import kuzi.obf.h.b.l;
import kuzi.obf.h.b.v;
import kuzi.obf.j.e.am;
import kuzi.obf.j.e.ap;
import kuzi.obf.j.e.r;
import kuzi.obf.j.e.s;
import kuzi.obf.j.e.t;
import kuzi.obf.p.aF;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.Player;
import net.minecraft.ClickType;
import net.minecraft.ItemStack;
import net.minecraft.Items;
import net.minecraft.Minecraft;
import net.minecraft.MouseHandler;
import net.minecraft.Screen;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class PotRefill
extends BaseModule
implements Module {
    private final l m;
    private final l n;
    private final SliderSetting slot;
    private final SliderSetting delay;
    private static final int q;
    private static final int r;
    private r state;
    private int waitTicks;
    private int cooldownTicks;
    private boolean ownScreenOpen;
    private int sourceSlotId;
    private int hotbarButton;
    private static final long y;
    private static final String[] z;
    private static final String[] A;
    private static final Map B;
    private static final long[] C;
    private static final Integer[] D;
    private static final Map E;
    private static final Object[] F;
    private static final String[] G;

    public PotRefill() {
        long l2 = y ^ 0x3D781C573B5BL;
        long l3 = l2 ^ 0x7E04985F4E4DL;
        super("PotRefill", "Refills a potion into your hotbar/slot/off-hand by opening the inventory (like AutoTotem).", Category.PLAYER);
        this.m = new l("Potion Type", kuzi.obf.j.e.s.SPLASH, s.class);
        this.n = new l("Refill To", kuzi.obf.j.e.t.HOTBAR, t.class);
        this.slot = new SliderSetting("Slot", 1.0, 1.0, 9.0, 1.0);
        this.delay = new SliderSetting("Delay", 2.0, 1.0, 20.0, 1.0);
        this.state = kuzi.obf.j.e.r.IDLE;
        this.waitTicks = 0;
        this.cooldownTicks = 0;
        this.ownScreenOpen = false;
        this.sourceSlotId = -1;
        this.hotbarButton = -1;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.m, this.n, this.slot, this.delay};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        long l2 = y ^ 0x912330349CEL;
        long l3 = l2 ^ 0x75F182FEF976L;
        Client.a().a(Module.class, this);
        super.d();
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.c(objectArray);
    }

    @Override
    public void e() {
        long l2;
        long l3 = l2 = y ^ 0x1C6E2AE229E0L;
        long l4 = l3 ^ 0x608D9B1F9958L;
        long l5 = l3 ^ 0xB790E62E23L;
        Client.a().b(Module.class, this);
        super.e();
        Object[] objectArray = new Object[1];
        objectArray[0] = l5;
        this.a(objectArray);
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l4;
        this.c(objectArray2);
    }

    private void a(Object[] objectArray) {
        block2: {
            PotRefill potRefill;
            block3: {
                Minecraft mc;
                long l2;
                int n2;
                block6: {
                    String string;
                    block4: {
                        String string2;
                        block5: {
                            long l3 = (Long)objectArray[0];
                            long l4 = (l3 = y ^ l3) ^ 0x494D92030FE6L;
                            n2 = (int)(l4 >>> 56);
                            l2 = l4 << 8 >>> 8;
                            string2 = am.b();
                            potRefill = this;
                            if (string2 == null) break block2;
                            if (!potRefill.ownScreenOpen) break block3;
                            mc = BaseModule.a;
                            string = string2;
                            if (l3 <= 0L) break block4;
                            if (string == null) break block5;
                            if (!(mc.screen instanceof aF)) break block3;
                            mc = BaseModule.a;
                        }
                        string = string2;
                    }
                    if (string == null) break block6;
                    if (mc.player == null) break block3;
                    mc = BaseModule.a;
                }
                mc.execute(() -> PotRefill.lambda$closeIfOurs$0((byte)n2, l2));
            }
            potRefill = this;
        }
        potRefill.ownScreenOpen = false;
    }

    private void c(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = y ^ l2;
        this.state = kuzi.obf.j.e.r.IDLE;
        this.waitTicks = 0;
        this.cooldownTicks = 0;
        this.ownScreenOpen = false;
        this.sourceSlotId = -1;
        this.hotbarButton = -1;
    }

    @Override
    public void b() {
        long l2;
        block5: {
            block2: {
                long l3;
                block3: {
                    Minecraft mc;
                    block4: {
                        long l4;
                        long l5 = l4 = y ^ 0x7AF1689836C7L;
                        l2 = l5 ^ 0x35702D818C16L;
                        l3 = l5 ^ 0x612D965867FL;
                        String string = am.b();
                        if (string == null) break block2;
                        if (BaseModule.a.player == null) break block3;
                        mc = BaseModule.a;
                        if (string == null) break block4;
                        if (mc.level == null) break block3;
                        mc = BaseModule.a;
                    }
                    if (mc.gameMode != null) break block5;
                }
                Object[] objectArray = new Object[1];
                objectArray[0] = l3;
                this.c(objectArray);
            }
            return;
        }
        Object[] objectArray = new Object[1];
        objectArray[0] = l2;
        this.f(objectArray);
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private void f(Object[] var1_1) {
        var2_2 = (Long)var1_1[0];
        v0 = var2_2 = PotRefill.y ^ var2_2;
        var4_3 = v0 ^ 32976807900373L;
        var6_4 = v0 ^ 119318616851563L;
        var8_5 = v0 ^ 32844362830128L;
        var10_6 = v0 ^ 11927768940651L;
        var12_7 = v0 ^ 54732654138129L;
        var15_8 = Math.max(1, ((Double)this.delay.a()).intValue());
        var14_9 = am.b();
        v1 = this.state.ordinal();
        if (var14_9 == null) ** GOTO lbl20
        switch (v1) {
            case 0: {
                if (var2_2 <= 0L) ** GOTO lbl23
                v2 = this;
                if (var14_9 == null) ** GOTO lbl22
                v1 = v2.cooldownTicks;
lbl20:
                // 2 sources

                if (v1 <= 0) ** GOTO lbl24
                v2 = this;
lbl22:
                // 2 sources

                --v2.cooldownTicks;
lbl23:
                // 2 sources

                return;
lbl24:
                // 1 sources

                if (BaseModule.a.screen != null) {
                    return;
                }
                v3 = new Object[1];
                v3[0] = var6_4;
                var16_10 = this.a(v3);
                v4 = var14_9;
                if (var2_2 <= 0L) ** GOTO lbl43
                if (v4 != null) {
                    if (var16_10 == null) {
                        return;
                    }
                    this.sourceSlotId = var16_10.bI;
                    this.hotbarButton = var16_10.bJ;
                    this.ownScreenOpen = true;
                    BaseModule.a.setScreen((Screen)new aF((Player)BaseModule.a.player));
                    this.waitTicks = var15_8;
                    this.state = kuzi.obf.j.e.r.OPEN_WAIT;
                }
                if (var2_2 < 0L) ** GOTO lbl44
                v4 = var14_9;
lbl43:
                // 2 sources

                if (v4 != null) break;
            }
lbl44:
            // 3 sources

            case 1: {
                v5 /* !! */  = BaseModule.a.screen instanceof aF;
                v6 = var14_9;
                if (var2_2 <= 0L) ** GOTO lbl60
                if (v6 != null) {
                    if (v5 /* !! */  == 0) {
                        v7 = new Object[1];
                        v7[0] = var4_3;
                        this.m(v7);
                        return;
                    }
                    v8 = this.waitTicks;
                    v5 /* !! */  = v8;
                    this.waitTicks = v8 - 1;
                }
                if (var2_2 < 0L) ** GOTO lbl64
                v6 = var14_9;
lbl60:
                // 2 sources

                if (v6 != null) {
                    if (v5 /* !! */  > 0) {
                        return;
                    }
                    v5 /* !! */  = this.hotbarButton;
                }
lbl64:
                // 4 sources

                v9 /* !! */  = PotRefill.c("f", (int)2373, (long)(7974302840563314001L ^ var2_2));
                if (var14_9 == null) ** GOTO lbl71
                if (v5 /* !! */  == v9 /* !! */ ) {
                    v10 /* !! */  = (int)PotRefill.c("f", (int)7994, (long)(4014062246247709479L ^ var2_2));
                } else {
                    v5 /* !! */  = (int)PotRefill.c("f", (int)3058, (long)(3440694067022802919L ^ var2_2));
                    v9 /* !! */  = (CallSite)this.hotbarButton;
lbl71:
                    // 2 sources

                    v10 /* !! */  = v5 /* !! */  + v9 /* !! */ ;
                }
                var16_11 = v10 /* !! */ ;
                v11 = this;
                if (var14_9 == null) ** GOTO lbl100
                if (v11.w < 0) ** GOTO lbl96
                if (var2_2 <= 0L) ** GOTO lbl99
                v12 = this;
                v13 = var16_11;
                if (var14_9 == null) ** GOTO lbl98
                v14 = new Object[2];
                v14[1] = v13;
                v14[0] = var10_6;
                if (!v12.a(v14)) ** GOTO lbl96
                v11 = this;
                if (var2_2 < 0L || var14_9 == null) ** GOTO lbl100
                if (var2_2 < 0L) ** GOTO lbl97
                v15 = new Object[2];
                v15[1] = BaseModule.a.player.inventoryMenu.getSlot(this.sourceSlotId).getItem();
                v15[0] = var8_5;
                if (v11.d(v15)) {
                    BaseModule.a.gameMode.handleInventoryMouseClick(BaseModule.a.player.inventoryMenu.containerId, this.sourceSlotId, this.hotbarButton, ClickType.SWAP, (Player)BaseModule.a.player);
                }
lbl96:
                // 5 sources

                v12 = this;
lbl97:
                // 2 sources

                v13 = var15_8;
lbl98:
                // 2 sources

                v12.waitTicks = v13;
lbl99:
                // 2 sources

                v11 = this;
lbl100:
                // 3 sources

                v11.state = kuzi.obf.j.e.r.MOVE_WAIT;
                if (var2_2 >= 0L && var14_9 != null) break;
            }
            case 2: {
                v16 = BaseModule.a.screen instanceof aF;
                if (var14_9 == null) ** GOTO lbl118
                if (v16 == 0) {
                    v17 = new Object[1];
                    v17[0] = var4_3;
                    this.m(v17);
                    return;
                }
                v18 = this;
                if (var2_2 < 0L) ** GOTO lbl128
                v19 = v18;
                v20 = v18.waitTicks;
                if (var14_9 == null) ** GOTO lbl126
                v16 = v20;
                v19.waitTicks = v20 - 1;
lbl118:
                // 2 sources

                if (v16 > 0) {
                    return;
                }
                v21 = new Object[1];
                v21[0] = var12_7;
                this.a(v21);
                v19 = this;
                v20 = var15_8;
lbl126:
                // 2 sources

                v19.cooldownTicks = v20;
                v18 = this;
lbl128:
                // 2 sources

                v18.state = kuzi.obf.j.e.r.IDLE;
            }
        }
    }

    private void m(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = y ^ l2;
        this.ownScreenOpen = false;
        this.sourceSlotId = -1;
        this.hotbarButton = -1;
        this.waitTicks = 0;
        this.cooldownTicks = Math.max(2, ((Double)this.delay.a()).intValue());
        this.state = kuzi.obf.j.e.r.IDLE;
    }

    private ap a(Object[] objectArray) {
        int n2;
        int n3;
        long l2 = (Long)objectArray[0];
        long l3 = l2 = y ^ l2;
        long l4 = l3 ^ 0x609D025E4F45L;
        long l5 = l3 ^ 0x72C3A096681EL;
        long l6 = l3 ^ 0x4C3AEDE6A03L;
        long l7 = l3 ^ 0x47D23C5D4CCFL;
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l5;
        int n4 = this.a(objectArray2);
        String string = am.b();
        int n5 = n4;
        if (string != null) {
            if (n5 == -1) {
                return null;
            }
            Object[] objectArray3 = new Object[2];
            objectArray3[1] = n4;
            objectArray3[0] = l6;
            n5 = this.a(objectArray3) ? 1 : 0;
        }
        if (string != null) {
            if (n5 == 0) {
                return null;
            }
            Object[] objectArray4 = new Object[2];
            objectArray4[1] = n4;
            objectArray4[0] = l7;
            n5 = this.d(objectArray4);
        }
        int n6 = n3 = n5;
        if (string != null) {
            if (n6 == -1) {
                return null;
            }
            Object[] objectArray5 = new Object[2];
            objectArray5[1] = n4;
            objectArray5[0] = l4;
            n6 = this.c(objectArray5);
        }
        if ((n2 = n6) == -1) {
            return null;
        }
        return new ap(n3, n2);
    }

    /*
     * Exception decompiling
     */
    private int a(Object[] var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * java.lang.UnsupportedOperationException
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.considerAsDoLoopStart(LoopIdentifier.java:383)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.identifyLoops1(LoopIdentifier.java:65)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:681)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private int c(Object[] objectArray) {
        int n2;
        block14: {
            block15: {
                CallSite callSite;
                CallSite callSite2;
                int n3;
                long l2;
                block12: {
                    block13: {
                        l2 = (Long)objectArray[0];
                        n3 = (Integer)objectArray[1];
                        l2 = y ^ l2;
                        callSite2 = PotRefill.d("G", (long)3599675600625021185L, (long)l2);
                        try {
                            try {
                                n2 = n3;
                                callSite = PotRefill.c("f", (int)11269, (long)(0x17DCF7C19592033CL ^ l2));
                                if (callSite2 == null) break block12;
                                if (n2 != callSite) break block13;
                            }
                            catch (MatchException matchException) {
                                throw PotRefill.d("G", (Object)matchException, (long)3600523049110979511L, (long)l2);
                            }
                            return (int)PotRefill.c("f", (int)7171, (long)(0x1AF571CAF03A3332L ^ l2));
                        }
                        catch (MatchException matchException) {
                            throw PotRefill.d("G", (Object)matchException, (long)3600523049110979511L, (long)l2);
                        }
                    }
                    try {
                        n2 = n3;
                        if (callSite2 == null) break block14;
                        callSite = PotRefill.c("f", (int)3058, (long)(0x2FBFC11E382BA4C9L ^ l2));
                    }
                    catch (MatchException matchException) {
                        throw PotRefill.d("G", (Object)matchException, (long)3600523049110979511L, (long)l2);
                    }
                }
                try {
                    try {
                        try {
                            if (n2 < callSite) break block15;
                            n2 = n3;
                            if (callSite2 == null) break block14;
                        }
                        catch (MatchException matchException) {
                            throw PotRefill.d("G", (Object)matchException, (long)3600523049110979511L, (long)l2);
                        }
                        if (n2 > PotRefill.c("f", (int)27904, (long)(0x2336488F1C8A423DL ^ l2))) break block15;
                    }
                    catch (MatchException matchException) {
                        throw PotRefill.d("G", (Object)matchException, (long)3600523049110979511L, (long)l2);
                    }
                    return n3 - PotRefill.c("f", (int)3058, (long)(0x2FBFC11E382BA4C9L ^ l2));
                }
                catch (MatchException matchException) {
                    throw PotRefill.d("G", (Object)matchException, (long)3600523049110979511L, (long)l2);
                }
            }
            n2 = -1;
        }
        return n2;
    }

    private boolean a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        int n2 = (Integer)objectArray[1];
        l2 = y ^ l2;
        String string = am.b();
        int n3 = n2;
        if (string != null) {
            if (n3 < 0) {
                return true;
            }
            n3 = BaseModule.a.player.inventoryMenu.getSlot(n2).getItem().isEmpty() ? 1 : 0;
        }
        return n3 != 0;
    }

    /*
     * Exception decompiling
     */
    private int d(Object[] var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * java.lang.UnsupportedOperationException
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.considerAsDoLoopStart(LoopIdentifier.java:383)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.identifyLoops1(LoopIdentifier.java:65)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:681)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean d(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        ItemStack stack = (ItemStack)objectArray[1];
        l2 = y ^ l2;
        String string = am.b();
        boolean bl = stack.isEmpty();
        if (string != null) {
            if (bl) {
                return false;
            }
            bl = stack.is(Items.SPLASH_POTION);
        }
        boolean bl2 = bl;
        boolean bl3 = stack.is(Items.POTION);
        boolean bl4 = stack.is(Items.LINGERING_POTION);
        boolean bl5 = ((s)((Object)this.m.a())).ordinal();
        String string2 = string;
        if (l2 > 0L) {
            if (string2 != null) {
                switch (bl5) {
                    default: {
                        throw new MatchException(null, null);
                    }
                    case 0: {
                        bl5 = bl2;
                        return bl5;
                    }
                    case 1: {
                        bl5 = bl3;
                        return bl5;
                    }
                    case 2: {
                        bl5 = bl4;
                        return bl5;
                    }
                    case 3: {
                        bl5 = bl2;
                    }
                }
            }
            string2 = string;
        }
        if (string2 == null) return bl5;
        if (bl5) return true;
        bl5 = bl3;
        if (string == null) return bl5;
        if (bl5) return true;
        bl5 = bl4;
        if (string == null) return bl5;
        if (!bl5) return false;
        return true;
    }

    private static void lambda$closeIfOurs$0(byte by, long l2) {
        block11: {
            MouseHandler mouseHandler;
            block10: {
                CallSite callSite;
                CallSite callSite2;
                long l3;
                block8: {
                    block9: {
                        l3 = ((long)by << 56 | l2 << 8 >>> 8) ^ y;
                        callSite2 = PotRefill.d("G", (long)-1860574395499157800L, (long)l3);
                        try {
                            try {
                                callSite = PotRefill.d("B", (long)-1861631220330349662L, (long)l3);
                                if (callSite2 == null) break block8;
                                if (((Minecraft)callSite).player == null) break block9;
                            }
                            catch (MatchException matchException) {
                                throw PotRefill.d("G", (Object)matchException, (long)-1860316285310790546L, (long)l3);
                            }
                            ((Minecraft)PotRefill.d("B", (long)-1861631220330349662L, (long)l3)).player.closeContainer();
                        }
                        catch (MatchException matchException) {
                            throw PotRefill.d("G", (Object)matchException, (long)-1860316285310790546L, (long)l3);
                        }
                    }
                    callSite = PotRefill.d("B", (long)-1861631220330349662L, (long)l3);
                }
                try {
                    try {
                        mouseHandler = ((Minecraft)callSite).mouseHandler;
                        if (callSite2 == null) break block10;
                        if (mouseHandler == null) break block11;
                    }
                    catch (MatchException matchException) {
                        throw PotRefill.d("G", (Object)matchException, (long)-1860316285310790546L, (long)l3);
                    }
                    mouseHandler = ((Minecraft)PotRefill.d("B", (long)-1861631220330349662L, (long)l3)).mouseHandler;
                }
                catch (MatchException matchException) {
                    throw PotRefill.d("G", (Object)matchException, (long)-1860316285310790546L, (long)l3);
                }
            }
            mouseHandler.grabMouse();
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block21: {
            block20: {
                block19: {
                    block18: {
                        PotRefill.y = kuzi.obf.h.b.v.a(6964394624220935716L, 6624127404786414148L, MethodHandles.lookup().lookupClass()).a(32006334498623L);
                        PotRefill.F = new Object[62];
                        PotRefill.G = new String[62];
                        PotRefill.c();
                        PotRefill.B = new HashMap<K, V>(13);
                        var11 = PotRefill.y ^ 24773747443201L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[6];
                        var18_4 = 0;
                        var17_5 = "gR\u00c2\u00ee\u00ab_\u0095b\u00ae\u00978\u00c2\u00b2r\u0092l\u00f6\u00e4\u0084\u001d\u00b4(\u00b9\u00f0\u0098_\u0096\u0081\u0017\u00c07|X\u00dcAI\u0001\u0003\f\u008c\u00b6m\u00d8\u00b2\u0004S\u0086\u00c2\u001bM\u008b\u00e7\u00a6s8!\u008d\u00ba(\u00a4b\u0090\u0096\u00a4\u0084^y\u00c9%%2\u00b9\u00e4\u00faP\u00e8\u000b\u0019\u0080\u0011[\r\u00d1t\u0007\u00d8v/\u00a6\u00e7\u001f\u0016\u00fd\u00ae\u00d20\u00b5\u0011\u0080\u00d2)(\nl\u00d2\"\u00d4\u00ff\u00df\"\\\u000bs<th\u009f=\u0084d\u00b3\u00bd\u0010\u00fcE,\u00ce\u0016F\u00e0\u0092\u00c2\u0013\u0088\u009a\u001b\u00cdi\u007f\u00feDSd\u00cc\u00d4\u0088\u00f2\u0003}\u00e1\u00a5\u00e2\u0017!\u00a6S8\u0011\u00f3\u0012i3\u00eaI%Z \u001c\u0080\u0095\u00cf\u00f6\u0099\u00e6\u00e8X\u009b Jh\u00d6}\u00a1\u00f4\u008aOS\u00f7F;\u00b3$\u0085\u00d7%x\"\u00d0~*\u00b3\u00d7&=\u00f4*\u0003\u00c9\u00cbT\u0010\u0081\u00d0\u0080\u00ea\u00f6p\u00a6\u00f5[ GDjd\u00d4,";
                        var19_6 = "gR\u00c2\u00ee\u00ab_\u0095b\u00ae\u00978\u00c2\u00b2r\u0092l\u00f6\u00e4\u0084\u001d\u00b4(\u00b9\u00f0\u0098_\u0096\u0081\u0017\u00c07|X\u00dcAI\u0001\u0003\f\u008c\u00b6m\u00d8\u00b2\u0004S\u0086\u00c2\u001bM\u008b\u00e7\u00a6s8!\u008d\u00ba(\u00a4b\u0090\u0096\u00a4\u0084^y\u00c9%%2\u00b9\u00e4\u00faP\u00e8\u000b\u0019\u0080\u0011[\r\u00d1t\u0007\u00d8v/\u00a6\u00e7\u001f\u0016\u00fd\u00ae\u00d20\u00b5\u0011\u0080\u00d2)(\nl\u00d2\"\u00d4\u00ff\u00df\"\\\u000bs<th\u009f=\u0084d\u00b3\u00bd\u0010\u00fcE,\u00ce\u0016F\u00e0\u0092\u00c2\u0013\u0088\u009a\u001b\u00cdi\u007f\u00feDSd\u00cc\u00d4\u0088\u00f2\u0003}\u00e1\u00a5\u00e2\u0017!\u00a6S8\u0011\u00f3\u0012i3\u00eaI%Z \u001c\u0080\u0095\u00cf\u00f6\u0099\u00e6\u00e8X\u009b Jh\u00d6}\u00a1\u00f4\u008aOS\u00f7F;\u00b3$\u0085\u00d7%x\"\u00d0~*\u00b3\u00d7&=\u00f4*\u0003\u00c9\u00cbT\u0010\u0081\u00d0\u0080\u00ea\u00f6p\u00a6\u00f5[ GDjd\u00d4,".length();
                        var16_7 = 24;
                        var15_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block18;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = PotRefill.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "\u0090\u009ep|+\u000f\u0012\u00f1\u00ac\u00acnau?:U \u0086\u00c9\u0013\u00fc1\u00e61X\u00d630d\u00ed\u00b3\u00deF|\u00f0p\u00aa\u00a9\u00f8\u00f5s\u00ec\u00dd\"\u00c7\u00e0\u00d1\u00cdy";
                            var19_6 = "\u0090\u009ep|+\u000f\u0012\u00f1\u00ac\u00acnau?:U \u0086\u00c9\u0013\u00fc1\u00e61X\u00d630d\u00ed\u00b3\u00deF|\u00f0p\u00aa\u00a9\u00f8\u00f5s\u00ec\u00dd\"\u00c7\u00e0\u00d1\u00cdy".length();
                            var16_7 = 16;
                            var15_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block18;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = PotRefill.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block19;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                PotRefill.z = var20_3;
                PotRefill.A = new String[6];
                PotRefill.E = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[11];
                var3_13 = 0;
                var4_14 = ".\u0096V\u00ee\u0084c\u0093\u00e8\u00c2\u00cfLf\u00ab\u00c3fS\u00d51\u001f\u00cd)<\u00ca\u009c\u00c3\u001d\u0099g\u00b5\u008d\u0086Dz\u0012T\u0096\u00e5\u00ba\u0084,\u00b8wA\u00a1\u001b2\u00be.\u00df\u00cd\u00c5\u001bp\u00c9G8(\u000fH\u00e6\u0017\u00af\u009c\b\u0086\u00e6AH\u00d0>?\u00c7";
                var5_15 = ".\u0096V\u00ee\u0084c\u0093\u00e8\u00c2\u00cfLf\u00ab\u00c3fS\u00d51\u001f\u00cd)<\u00ca\u009c\u00c3\u001d\u0099g\u00b5\u008d\u0086Dz\u0012T\u0096\u00e5\u00ba\u0084,\u00b8wA\u00a1\u001b2\u00be.\u00df\u00cd\u00c5\u001bp\u00c9G8(\u000fH\u00e6\u0017\u00af\u009c\b\u0086\u00e6AH\u00d0>?\u00c7".length();
                var2_16 = 0;
                while (true) {
                    var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                    v10 = var6_12;
                    v11 = var3_13++;
                    v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                    v13 = -1;
                    break block20;
                    break;
                }
lbl81:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    var4_14 = "\u0083\u008b\u00a4\u00c6\b\u0006\u00f6Z\u0018\u00e6\u0017;\u00db\"\u0096\u00b1";
                    var5_15 = "\u0083\u008b\u00a4\u00c6\b\u0006\u00f6Z\u0018\u00e6\u0017;\u00db\"\u0096\u00b1".length();
                    var2_16 = 0;
                    while (true) {
                        var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                        v10 = var6_12;
                        v11 = var3_13++;
                        v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                        v13 = 0;
                        break block20;
                        break;
                    }
                    break;
                }
lbl94:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    break block21;
                    break;
                }
            }
            var8_18 = v12;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            v14 = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
            switch (v13) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl107:
                // 1 sources

                ** continue;
            }
        }
        PotRefill.C = var6_12;
        PotRefill.D = new Integer[11];
        PotRefill.q = 45;
        PotRefill.r = 40;
    }

    private static MatchException a(MatchException matchException) {
        return matchException;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x1EC6;
        if (D[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = C[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])E.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    E.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/e/aa", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            PotRefill.D[n3] = n4;
        }
        return D[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = PotRefill.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/e/aa" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (G[n4] != null) {
            return n4;
        }
        Object object = F[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 13;
            case 1 -> 15;
            case 2 -> 36;
            case 3 -> 48;
            case 4 -> 24;
            case 5 -> 11;
            case 6 -> 32;
            case 7 -> 1;
            case 8 -> 61;
            case 9 -> 47;
            case 10 -> 54;
            case 11 -> 7;
            case 12 -> 31;
            case 13 -> 60;
            case 14 -> 33;
            case 15 -> 28;
            case 16 -> 55;
            case 17 -> 46;
            case 18 -> 3;
            case 19 -> 17;
            case 20 -> 40;
            case 21 -> 53;
            case 22 -> 35;
            case 23 -> 12;
            case 24 -> 42;
            case 25 -> 57;
            case 26 -> 30;
            case 27 -> 10;
            case 28 -> 21;
            case 29 -> 45;
            case 30 -> 2;
            case 31 -> 56;
            case 32 -> 25;
            case 33 -> 16;
            case 34 -> 22;
            case 35 -> 26;
            case 36 -> 58;
            case 37 -> 51;
            case 38 -> 52;
            case 39 -> 37;
            case 40 -> 27;
            case 41 -> 41;
            case 42 -> 19;
            case 43 -> 39;
            case 44 -> 44;
            case 45 -> 0;
            case 46 -> 18;
            case 47 -> 20;
            case 48 -> 5;
            case 49 -> 9;
            case 50 -> 8;
            case 51 -> 49;
            case 52 -> 62;
            case 53 -> 63;
            case 54 -> 6;
            case 55 -> 59;
            case 56 -> 14;
            case 57 -> 50;
            case 58 -> 23;
            case 59 -> 4;
            case 60 -> 38;
            case 61 -> 29;
            case 62 -> 34;
            default -> 43;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        PotRefill.G[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = F;
        F[0] = "no\u000eGMDeo\nGM\u0007";
        objectArray[1] = "Il5yJaBc$67yQd-\u007f";
        objectArray[2] = "\u0012U!S\u0003n\u0019U*";
        objectArray[3] = "\u001e\u000b'n\u0010.\u001e\u000b02\u001c!\u0004@0,\u001c4\u00031`qM";
        objectArray[4] = "\u0004\t&CQu\u000f\t\"CQ:";
        objectArray[5] = ":YI\u001b/%3YJ\u001b\"";
        objectArray[6] = "/o@L{k&oCLw";
        objectArray[7] = "B-^6!\u0006I\"OyB\u000b\\/@\u0012w\tM<\\>`\u0004";
        objectArray[8] = "qD4\u0013vkxD7\u0013v";
        objectArray[9] = "W4\u0013%sE\\;\u0002j\u0012KW0\u00060";
        objectArray[10] = Boolean.TYPE;
        PotRefill.G[10] = "java/lang/Boolean";
        objectArray[11] = "Z\\\u0013\";\u000b/|\u0018-*DNr\u0013&.\u001e:";
        objectArray[12] = Void.TYPE;
        PotRefill.G[12] = "java/lang/Void";
        objectArray[13] = Integer.TYPE;
        PotRefill.G[13] = "java/lang/Integer";
        objectArray[14] = "\u0019\u0000Pd#\b\u0012\u0000Td0";
        objectArray[15] = "?\u0014u\u0000Q1J4~\u000f@~+:u\u0004D$_";
        objectArray[16] = "GQ\t\u0003\u0019v2q\u0002\f\b9S\u007f\t\u0007\fc'";
        objectArray[17] = "np\b)m6ep\f)mh";
        objectArray[18] = "s\u000f\u0018Px6\u0006/\u0013_iyg!\u0018Tm#\u0013";
        objectArray[19] = "kR9G\u00029\u001er2H\u0013v\u007f|9C\u0017,\u000b";
        objectArray[20] = "J1<8\u001d\u0018?\u001177\fW^\u001f<<\b\r*";
        objectArray[21] = "p/b\u007f\u000bP\u0005\u000fip\u001a\u001fd\u0001b{\u001eE\u0010";
        objectArray[22] = "\u000b/Y\n\tg~\u000fR\u0005\u0018(\u001f\u0001Y\u000e\u001crk";
        objectArray[23] = "Cy'\u0019\u0010U6Y,\u0016\u0001\u001aWW'\u001d\u0005@#";
        objectArray[24] = "W\f_vL\u0004\\\fW";
        objectArray[25] = "Q9)k`+Z9-kr";
        objectArray[26] = "U\u001ef{\u0017)^\u001eb{\u0002";
        objectArray[27] = "xk7\u001bq3\rK<\u0014`|lE7\u001fd&\u0018";
        objectArray[28] = "'1eb\u0001~R\u0011nm\u001013\u001fef\u0014kG";
        objectArray[29] = "V\buw\u0003.\u0011M7s>km\n\u007f!Pb\u0002\t47\u000f";
        objectArray[30] = "JKB\u0006vr\r\u000e\u0000\u0002K0qD\u0014S+-\u001cNCB0";
        objectArray[31] = "{4x0v\u0003<q:4KR@h<n5R<z:;*>\u007fi\"`;O\"o>gK";
        objectArray[32] = "\u000b\t9y,`LL{}\u0011;0\f`1h=QPd'h";
        objectArray[33] = ")q3\n\"Rn4q\u000e\u001f\u0003\u0012-wTa\u0003n?q\u0001~o##fP}\u0002)twK\u001f";
        objectArray[34] = "\u001b(To:\u0012\\m\u0016k\u0007J -\r'~OAq\t1~";
        objectArray[35] = "j >Cc\u000f-e|G^[Q\"u\u00132W=|aD#2mon\u0015;^3{9\u0004^";
        objectArray[36] = "</e\u0011(.c+?AO\u0002U\u0019By\u0010\fL\b\u0004\u001f4$23o@0~b";
        objectArray[37] = "U\u00063s2w\u0012Cqw\u000f!nZw-q&\u0012HqxnJ_Tf)m'U\u0003w2\u000f";
        objectArray[38] = "\u0019+i\u0000\u001c\u000b^n+\u0004!K\"$?UATO.hDZ";
        objectArray[39] = "Z+\u000b\u0015&Z\u001dnI\u0011\u001b\tawOKe\u000b\u001deI\u001ezgQwN\u0011d\\\u001b(R\u0015\u001b";
        objectArray[40] = "\u0012^uu/\u000eU\u001b7q\u0012X)\u00021+l_U\u00107~s3\u0019\u00020qm\bS],u\u0012";
        objectArray[41] = "Vd</)\u001e\u0011!~+\u0014Jm8xqjO\u0011*~$u#]8y+k\u0018\u0017ge/\u0014";
        objectArray[42] = "gb40\u007fF6ln4\u0012^Z87&bE;73=#7";
        objectArray[43] = "e)YMO\u0000\"l\u001bIrA^&\u000f\u0018\u0012_3,X\t\t";
        objectArray[44] = "16X\u0013\u0004D+!E@~\\\u001aM\u0016N\u0011V9 \u001c\u0019\u0000M";
        objectArray[45] = "\u0000Fv!\u0014xG\u00034%)>;I7z\u0016\"P\u00163 F";
        objectArray[46] = "O*k\"\u007f\u001eKweiAzkZE\u001d\u001b\"O*k\"\u007f\u001eKwei";
        objectArray[47] = "~PjT21&\u000bdi$KcZzW,sq\u001cdi";
        objectArray[48] = "Y\u001b\u0000\u0013W3Y\u0013\u0000\u00012b`BX\u0007OtX\u0019X\u0000\u000e";
        objectArray[49] = "$>ceT}c{!ai)\u001fb';\u0017,cp!n\b@u{&n\u00132ol;=i";
        objectArray[50] = "d\u000bA`Gz#N\u0003dz\"_W\u0005>\u0004+#E\u0003k\u001bGoW\u0004d\u0005|%\b\u0018`z";
        objectArray[51] = "\u0015'UT,vRb\u0017P\u0011;.(\u0003\u0001q)C\"T\u0010j";
        objectArray[52] = ")\u0005\u0013Tg\u0005v\u0001I\u0004\u0000+_ ?<_'Y\"rZ{\u000f'\u0019\u0019\u0005\u007fUw";
        objectArray[53] = "\bJP'\baWN\nwoKuu|\u0018^qX\u000eVs\u0001u\u0002^";
        objectArray[54] = "\u0018.]SH\\_k\u001fWu\u0006#,W\u0005\u001b\u0010L/\u001c\u0013D";
        objectArray[55] = "lz\u001f>Y\u0005sdDtb7TFk\u0014\"llz\u001f>Y\u0005sdDt";
        objectArray[56] = "\u0001mc\\e)PpfMTS'VRj\u000e\u0013\u0001mc\\e)PpfM";
        objectArray[57] = "al?pO\u0012&)}trFZ0{.\fC&\"}{\u0013/k>j*\u0010Bai{1r";
        objectArray[58] = "Ji(0\u0016$\r,j4+gqhqjAi\u00005wvF";
        objectArray[59] = "\t\u0001i\n&#ND+\u000e\u001bw2]-TerNO+\u0001z\u001e\r\\3ZkoPZ/]\u001b";
        objectArray[60] = ",\u000fSW\u000f\u000e,\u0007SEjR\u0015\u000eJX\u0014Zi\u001cL\r\u000b6%\u000eK\u0002\u0015\roQW\u0006j";
        Object[] objectArray2 = objectArray;
        objectArray[61] = "\nAEEm{\u0010VX\u0016\u0017c\":\u000b\u0018xi\u0002W\u0001Oir";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = PotRefill.e(l2, l3);
            object = F[n2];
            try {
                if (!(object instanceof String)) break block2;
                PotRefill.F[n2] = clazz = Class.forName(G[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = PotRefill.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = PotRefill.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = PotRefill.e(l2, l3);
        Object object = F[n2];
        if (object instanceof String) {
            String string = G[n2];
            int n3 = string.indexOf(8);
            Class clazz = PotRefill.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = PotRefill.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = PotRefill.c(clazz3, string2, clazz2)) != null) {
                    PotRefill.F[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = PotRefill.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        PotRefill.F[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = PotRefill.f(666639560619189L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = PotRefill.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = PotRefill.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = PotRefill.e(l2, l3);
        Object object = F[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = G[n2];
                int n4 = string2.indexOf(8);
                clazz3 = PotRefill.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = PotRefill.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = PotRefill.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        PotRefill.F[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = PotRefill.f(666639560619189L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = PotRefill.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        PotRefill.F[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = PotRefill.f(666639560619189L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == 'p' || c2 == 's' || c2 == 'B' || c2 == '\u00b5') {
                field = PotRefill.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == 'p' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == 's' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == 'B' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = PotRefill.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == '\u00d0' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == 'G' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = PotRefill.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/e/aa" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(PotRefill.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(PotRefill.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

