// === Kuzi module: CartRefill ===
// Category   : PLAYER
// Description: Refills a TNT minecart into a hotbar slot by opening the inventory (like AutoTotem).
// Payload    : a.a.a.j.e.G (verified: True)

package kuzi.modules.player;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.module.Module;
import kuzi.obf.h.b.v;
import kuzi.obf.j.e.am;
import kuzi.obf.j.e.h;
import kuzi.obf.m.r;
import kuzi.obf.p.aF;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.Player;
import net.minecraft.ClickType;
import net.minecraft.Items;
import net.minecraft.Minecraft;
import net.minecraft.MouseHandler;
import net.minecraft.Screen;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class CartRefill
extends BaseModule
implements Module {
    private final SliderSetting slot;
    private final SliderSetting delay;
    private h state;
    private int waitTicks;
    private int cooldownTicks;
    private boolean inventoryOpened;
    private int targetSlot;
    private static final long t;
    private static final String[] u;
    private static final String[] v;
    private static final Map w;
    private static final long[] x;
    private static final Integer[] y;
    private static final Map z;
    private static final Object[] A;
    private static final String[] B;

    public CartRefill() {
        long l2 = t ^ 0x653BB56D3FDDL;
        long l3 = l2 ^ 0x7539AB90D6BCL;
        super("CartRefill", "Refills a TNT minecart into a hotbar slot by opening the inventory (like AutoTotem).", Category.PLAYER);
        this.slot = new SliderSetting("Slot", 9.0, 1.0, 9.0, 1.0);
        this.delay = new SliderSetting("Delay", 2.0, 1.0, 20.0, 1.0);
        this.state = kuzi.obf.j.e.h.IDLE;
        this.waitTicks = 0;
        this.cooldownTicks = 0;
        this.inventoryOpened = false;
        this.targetSlot = -1;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.slot, this.delay};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        long l2 = t ^ 0x5A6CA9F6D5B9L;
        long l3 = l2 ^ 0x612328DA8755L;
        Client.a().a(Module.class, this);
        super.d();
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.a(objectArray);
    }

    @Override
    public void e() {
        long l2;
        long l3 = l2 = t ^ 0x4F10B017B597L;
        long l4 = l3 ^ 0x745F313BE77BL;
        long l5 = l3 ^ 0x43FF395FC15BL;
        Client.a().b(Module.class, this);
        super.e();
        Object[] objectArray = new Object[1];
        objectArray[0] = l5;
        this.c(objectArray);
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l4;
        this.a(objectArray2);
    }

    private void a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = t ^ l2;
        this.state = kuzi.obf.j.e.h.IDLE;
        this.waitTicks = 0;
        this.cooldownTicks = 0;
        this.inventoryOpened = false;
        this.targetSlot = -1;
    }

    private void c(Object[] objectArray) {
        block2: {
            CartRefill cartRefill;
            block3: {
                Minecraft mc3102;
                int n2;
                int n3;
                int n4;
                block6: {
                    String string;
                    block4: {
                        String string2;
                        block5: {
                            long l2 = (Long)objectArray[0];
                            long l3 = (l2 = t ^ l2) ^ 0x7F0CC19D9F6BL;
                            n4 = (int)(l3 >>> 48);
                            n3 = (int)(l3 << 16 >>> 32);
                            n2 = (int)(l3 << 48 >>> 48);
                            string2 = am.b();
                            cartRefill = this;
                            if (string2 == null) break block2;
                            if (!cartRefill.inventoryOpened) break block3;
                            mc3102 = BaseModule.a;
                            string = string2;
                            if (l2 < 0L) break block4;
                            if (string == null) break block5;
                            if (!(mc3102.screen instanceof aF)) break block3;
                            mc3102 = BaseModule.a;
                        }
                        string = string2;
                    }
                    if (string == null) break block6;
                    if (mc3102.player == null) break block3;
                    mc3102 = BaseModule.a;
                }
                mc3102.execute(() -> CartRefill.lambda$closeIfOurs$0((char)n4, n3, (char)n2));
            }
            cartRefill = this;
        }
        cartRefill.inventoryOpened = false;
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public void b() {
        block29: {
            block26: {
                block27: {
                    block28: {
                        v0 = var1_1 = CartRefill.t ^ 45698224335536L;
                        var3_2 = v0 ^ 20617776724060L;
                        var5_3 = v0 ^ 86003294118402L;
                        var7_4 = v0 ^ 53354372379180L;
                        var9_5 = v0 ^ 22058464921679L;
                        var11_6 = v0 ^ 32839126324048L;
                        var13_7 = v0 ^ 41096313167484L;
                        var15_8 = am.b();
                        if (var15_8 == null) break block26;
                        if (BaseModule.a.player == null) break block27;
                        v1 = BaseModule.a;
                        if (var15_8 == null) break block28;
                        if (v1.level == null) break block27;
                        v1 = BaseModule.a;
                    }
                    if (v1.gameMode != null) break block29;
                }
                v2 = new Object[1];
                v2[0] = var3_2;
                this.a(v2);
            }
            return;
        }
        var16_9 = Math.max(1, ((Double)this.delay.a()).intValue());
        v3 = this.state.ordinal();
        if (var15_8 == null) ** GOTO lbl34
        switch (v3) {
            case 0: {
                v4 = this;
                if (var15_8 == null) ** GOTO lbl36
                v3 = v4.cooldownTicks;
lbl34:
                // 2 sources

                if (v3 <= 0) ** GOTO lbl38
                v4 = this;
lbl36:
                // 2 sources

                --v4.cooldownTicks;
                return;
lbl38:
                // 1 sources

                if (BaseModule.a.screen != null) {
                    return;
                }
                v5 = new Object[1];
                v5[0] = var11_6;
                var17_10 = this.d(v5);
                if (var15_8 != null) {
                    if (var17_10 == -1) {
                        return;
                    }
                    this.targetSlot = var17_10;
                    this.inventoryOpened = true;
                    BaseModule.a.setScreen((Screen)new aF((Player)BaseModule.a.player));
                    this.waitTicks = var16_9;
                    this.state = kuzi.obf.j.e.h.OPEN_WAIT;
                }
                if (var15_8 != null) break;
            }
            case 1: {
                v6 = BaseModule.a.screen instanceof aF;
                if (var15_8 != null) {
                    if (v6 == 0) {
                        v7 = new Object[1];
                        v7[0] = var9_5;
                        this.f(v7);
                        return;
                    }
                    v8 = this.waitTicks;
                    v6 = v8;
                    this.waitTicks = v8 - 1;
                }
                if (var15_8 != null) {
                    if (v6 > 0) {
                        return;
                    }
                    v9 = new Object[1];
                    v9[0] = var7_4;
                    v6 = 36 + this.a(v9);
                }
                var17_10 = v6;
                v10 = this;
                if (var15_8 == null) ** GOTO lbl97
                if (v10.targetSlot < 0) ** GOTO lbl93
                v11 = this;
                v12 = var17_10;
                if (var15_8 == null) ** GOTO lbl95
                v13 = new Object[2];
                v13[1] = v12;
                v13[0] = var5_3;
                if (!v11.a(v13)) ** GOTO lbl93
                v14 = BaseModule.a;
                if (var15_8 == null) ** GOTO lbl89
                if (!v14.player.inventoryMenu.getSlot(this.targetSlot).getItem().is(Items.TNT_MINECART)) ** GOTO lbl93
                v14 = BaseModule.a;
lbl89:
                // 2 sources

                v15 = new Object[1];
                v15[0] = var7_4;
                v14.gameMode.handleInventoryMouseClick(BaseModule.a.player.inventoryMenu.containerId, this.targetSlot, this.a(v15), ClickType.SWAP, (Player)BaseModule.a.player);
lbl93:
                // 4 sources

                v11 = this;
                v12 = var16_9;
lbl95:
                // 2 sources

                v11.waitTicks = v12;
                v10 = this;
lbl97:
                // 2 sources

                v10.state = kuzi.obf.j.e.h.MOVE_WAIT;
                if (var15_8 != null) break;
            }
            case 2: {
                v16 = BaseModule.a.screen instanceof aF;
                if (var15_8 == null) ** GOTO lbl114
                if (v16 == 0) {
                    v17 = new Object[1];
                    v17[0] = var9_5;
                    this.f(v17);
                    return;
                }
                v18 = this;
                v19 = v18;
                v20 = v18.waitTicks;
                if (var15_8 == null) ** GOTO lbl122
                v16 = v20;
                v19.waitTicks = v20 - 1;
lbl114:
                // 2 sources

                if (v16 > 0) {
                    return;
                }
                v21 = new Object[1];
                v21[0] = var13_7;
                this.c(v21);
                v19 = this;
                v20 = var16_9;
lbl122:
                // 2 sources

                v19.cooldownTicks = v20;
                this.state = kuzi.obf.j.e.h.IDLE;
            }
        }
    }

    private void f(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = t ^ l2;
        this.inventoryOpened = false;
        this.targetSlot = -1;
        this.waitTicks = 0;
        this.cooldownTicks = Math.max(2, ((Double)this.delay.a()).intValue());
        this.state = kuzi.obf.j.e.h.IDLE;
    }

    private int a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = t ^ l2;
        return ((Double)this.slot.a()).intValue() - 1;
    }

    private int c(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = (l2 = t ^ l2) ^ 0x3BDDE670F6E4L;
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l3;
        return (int)(CartRefill.c("c", (int)12537, (long)(0x26258166C84A18C8L ^ l2)) + CartRefill.d("K", (Object)this, (Object)objectArray2, (long)-7202579718479566358L, (long)l2));
    }

    private boolean a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        int n2 = (Integer)objectArray[1];
        l2 = t ^ l2;
        String string = am.b();
        int n3 = n2;
        if (string != null) {
            if (n3 < 0) {
                return true;
            }
            n3 = BaseModule.a.player.inventoryMenu.getSlot(n2).getItem().isEmpty() ? 1 : 0;
        }
        return n3 != 0;
    }

    /*
     * Exception decompiling
     */
    private int d(Object[] var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * java.lang.UnsupportedOperationException
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.considerAsDoLoopStart(LoopIdentifier.java:383)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.identifyLoops1(LoopIdentifier.java:65)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:681)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private static void lambda$closeIfOurs$0(char c2, int n2, char c3) {
        block11: {
            MouseHandler mouseHandler;
            block10: {
                CallSite callSite;
                CallSite callSite2;
                long l2;
                block8: {
                    block9: {
                        l2 = ((long)c2 << 48 | (long)n2 << 32 >>> 16 | (long)c3 << 48 >>> 48) ^ t;
                        callSite2 = CartRefill.d("\u00f0", (long)-7361941637644661584L, (long)l2);
                        try {
                            try {
                                callSite = CartRefill.d("n", (long)-7361766349656808475L, (long)l2);
                                if (callSite2 == null) break block8;
                                if (((Minecraft)callSite).player == null) break block9;
                            }
                            catch (r r2) {
                                throw CartRefill.d("\u00f0", (Object)r2, (long)-7362094903268203122L, (long)l2);
                            }
                            ((Minecraft)CartRefill.d("n", (long)-7361766349656808475L, (long)l2)).player.closeContainer();
                        }
                        catch (r r3) {
                            throw CartRefill.d("\u00f0", (Object)r3, (long)-7362094903268203122L, (long)l2);
                        }
                    }
                    callSite = CartRefill.d("n", (long)-7361766349656808475L, (long)l2);
                }
                try {
                    try {
                        mouseHandler = ((Minecraft)callSite).mouseHandler;
                        if (callSite2 == null) break block10;
                        if (mouseHandler == null) break block11;
                    }
                    catch (r r4) {
                        throw CartRefill.d("\u00f0", (Object)r4, (long)-7362094903268203122L, (long)l2);
                    }
                    mouseHandler = ((Minecraft)CartRefill.d("n", (long)-7361766349656808475L, (long)l2)).mouseHandler;
                }
                catch (r r5) {
                    throw CartRefill.d("\u00f0", (Object)r5, (long)-7362094903268203122L, (long)l2);
                }
            }
            mouseHandler.grabMouse();
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block16: {
            block15: {
                block14: {
                    block13: {
                        CartRefill.t = kuzi.obf.h.b.v.a(-2393669605487626932L, 6112090129726804918L, MethodHandles.lookup().lookupClass()).a(232040798508952L);
                        CartRefill.A = new Object[45];
                        CartRefill.B = new String[45];
                        CartRefill.c();
                        CartRefill.w = new HashMap<K, V>(13);
                        var11 = CartRefill.t ^ 65548107828707L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[4];
                        var18_4 = 0;
                        var17_5 = "y\u00c7O\u00d5\u00cd\u007fe\u0083\u00e7\u00dea|\u00cf\u0005[K\u009f\u0096yH\u0000\u00b5\u00cb\u00cez{2\u007f\u00a7\u0094\b\u00a4\u000b9\u00d5\u00d2I\u00d8\u0006\u00b2Lp\t7\u0015\u00be\u009b\u00be\u00ecj\u00c4\u0092\u0083\u0006\u00da@(V_ \u00dfK\u00d7H\u001b\u0015FN[\u0094K\u00c4P\u00a8&\u00a2\u00b0\u0091\u0017\u00841\u00da\u0001'\u0098f\u0092\u0096\u00db\u00a5g\u00d9\u000eM\u00cf4\u00a5~\u00e2\u00a2\u00f5\u00a1)\u0000ez_\u00ab\u00c5\u008a\u00a66\u00e0\u00f1 \u009b\u0001\u009dq\u0015KS\u00be{\u007fo\u0093zz\u001a\u00a0 \u00c3\u00be{\u00c4\u0018\u00d3O\u00aed\u009a/\u00db2\u00d1!E\u00ecy\u0094\u00d2\u00a2?\u001b\u00c1wZ\u00d1\u00c9\u00dc";
                        var19_6 = "y\u00c7O\u00d5\u00cd\u007fe\u0083\u00e7\u00dea|\u00cf\u0005[K\u009f\u0096yH\u0000\u00b5\u00cb\u00cez{2\u007f\u00a7\u0094\b\u00a4\u000b9\u00d5\u00d2I\u00d8\u0006\u00b2Lp\t7\u0015\u00be\u009b\u00be\u00ecj\u00c4\u0092\u0083\u0006\u00da@(V_ \u00dfK\u00d7H\u001b\u0015FN[\u0094K\u00c4P\u00a8&\u00a2\u00b0\u0091\u0017\u00841\u00da\u0001'\u0098f\u0092\u0096\u00db\u00a5g\u00d9\u000eM\u00cf4\u00a5~\u00e2\u00a2\u00f5\u00a1)\u0000ez_\u00ab\u00c5\u008a\u00a66\u00e0\u00f1 \u009b\u0001\u009dq\u0015KS\u00be{\u007fo\u0093zz\u001a\u00a0 \u00c3\u00be{\u00c4\u0018\u00d3O\u00aed\u009a/\u00db2\u00d1!E\u00ecy\u0094\u00d2\u00a2?\u001b\u00c1wZ\u00d1\u00c9\u00dc".length();
                        var16_7 = 136;
                        var15_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block13;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = CartRefill.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "\u0018\u00de\u00a8\u00192\u008f!\u00aa7\u0015\fC\u00da\u00af\u0012\u001a\u0010\u00a7r\u00d8\u00b1\u0018\u00ed\u00c8T\u0083\u00ca\u0005\u00c7\u00c1L\u001d\u0085";
                            var19_6 = "\u0018\u00de\u00a8\u00192\u008f!\u00aa7\u0015\fC\u00da\u00af\u0012\u001a\u0010\u00a7r\u00d8\u00b1\u0018\u00ed\u00c8T\u0083\u00ca\u0005\u00c7\u00c1L\u001d\u0085".length();
                            var16_7 = 16;
                            var15_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block13;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = CartRefill.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block14;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                CartRefill.u = var20_3;
                CartRefill.v = new String[4];
                CartRefill.z = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[3];
                var3_13 = 0;
                var4_14 = "\u0098\u008dH|[\u0085U\u00a9K0~G\u0004G\u00016JO\u0094\u00b90\u00becH";
                var5_15 = "\u0098\u008dH|[\u0085U\u00a9K0~G\u0004G\u00016JO\u0094\u00b90\u00becH".length();
                var2_16 = 0;
                while (true) {
                    break block15;
                    break;
                }
lbl76:
                // 1 sources

                while (true) {
                    var6_12[v10] = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
                    if (var2_16 < var5_15) ** continue;
                    break block16;
                    break;
                }
            }
            var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
            v10 = var3_13++;
            var8_18 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            ** while (true)
        }
        CartRefill.x = var6_12;
        CartRefill.y = new Integer[3];
    }

    private static r a(r r2) {
        return r2;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x343F;
        if (y[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = x[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])z.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    z.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/e/G", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            CartRefill.y[n3] = n4;
        }
        return y[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = CartRefill.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/e/G" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (B[n4] != null) {
            return n4;
        }
        Object object = A[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 18;
            case 1 -> 3;
            case 2 -> 1;
            case 3 -> 38;
            case 4 -> 45;
            case 5 -> 17;
            case 6 -> 27;
            case 7 -> 63;
            case 8 -> 47;
            case 9 -> 33;
            case 10 -> 7;
            case 11 -> 61;
            case 12 -> 36;
            case 13 -> 30;
            case 14 -> 46;
            case 15 -> 28;
            case 16 -> 12;
            case 17 -> 55;
            case 18 -> 2;
            case 19 -> 57;
            case 20 -> 52;
            case 21 -> 6;
            case 22 -> 44;
            case 23 -> 22;
            case 24 -> 41;
            case 25 -> 54;
            case 26 -> 0;
            case 27 -> 49;
            case 28 -> 34;
            case 29 -> 50;
            case 30 -> 35;
            case 31 -> 4;
            case 32 -> 51;
            case 33 -> 9;
            case 34 -> 43;
            case 35 -> 19;
            case 36 -> 24;
            case 37 -> 32;
            case 38 -> 40;
            case 39 -> 42;
            case 40 -> 53;
            case 41 -> 60;
            case 42 -> 21;
            case 43 -> 14;
            case 44 -> 15;
            case 45 -> 23;
            case 46 -> 48;
            case 47 -> 31;
            case 48 -> 8;
            case 49 -> 56;
            case 50 -> 16;
            case 51 -> 13;
            case 52 -> 37;
            case 53 -> 10;
            case 54 -> 11;
            case 55 -> 26;
            case 56 -> 62;
            case 57 -> 29;
            case 58 -> 20;
            case 59 -> 39;
            case 60 -> 5;
            case 61 -> 25;
            case 62 -> 59;
            default -> 58;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        CartRefill.B[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = A;
        A[0] = "L}(-r~G},-T";
        objectArray[1] = "e3Z6S\u0016n3^6Z";
        objectArray[2] = Integer.TYPE;
        CartRefill.B[2] = "java/lang/Integer";
        objectArray[3] = Boolean.TYPE;
        CartRefill.B[3] = "java/lang/Boolean";
        objectArray[4] = "cH\u0010XG<jH\u0013XG";
        objectArray[5] = "\f\"%`\u0014=\u0007-4/u3\f&0u";
        objectArray[6] = "\rAt?\u0012\u0017\u0004Aw?\u001e";
        objectArray[7] = "nT[t}\u000eeTS";
        objectArray[8] = "9\u0018Ercq2\u0018N";
        objectArray[9] = "`GJ1qi\u0015gA>`&tiJ5d|\u0000";
        objectArray[10] = Void.TYPE;
        CartRefill.B[10] = "java/lang/Void";
        objectArray[11] = "T|Mi_A!\\FfN\u000e@RMmJT4";
        objectArray[12] = "\u001f\u000f|wW>j/wxFq\u000b!|sB+\u007f";
        objectArray[13] = "D.y\u001dXU1\u000er\u0012I\u001aP\u0000y\u0019M@$";
        objectArray[14] = "2R:|?/9R>|?l";
        objectArray[15] = "6[\r|&\u0007=T\u001c3[\u001f.S\u0015z";
        objectArray[16] = "({\u001a_\u00048({\r\u0003\b720\r\u001d\b\"5A]@Y";
        objectArray[17] = "-\u0017,RH\u0018X7']YW99,V]\rM";
        objectArray[18] = "\u0003\u0007\u000fC}\u001a\u000f\u0007\u001c";
        objectArray[19] = "\u0015R6F.\u001b`r=I?T\u0001|6B;\u000eu";
        objectArray[20] = "\r/=/Btx\u000f6 S;\u0019\u0001=+Wam";
        objectArray[21] = "1G\tbyvDg\u0002mh9%i\tflcQ";
        objectArray[22] = "\u0001\u001b|] \r\u000fW}'&2\u0017U L8\u0003\u0002Dv";
        objectArray[23] = "&\u0019\u001am14x\u001aBzNU^\".O\u0014\r&\u0019\u001am14x\u001aBz";
        objectArray[24] = "+\u0002/zn5%N.\u0000t\n{S9\u007fvax\u000e.}";
        objectArray[25] = "X5S'r\u0003\u000e`Pv\tX10O7tQ\u000b;B(62";
        objectArray[26] = "+eJ$4aj)\u001b/Ib\u00152B/wpj7T1r";
        objectArray[27] = "\u0002\u0018$M-&\fT%7%\u0019\u0005\u00158Et{\u0011C~\tL'\u001a\u0011\u007f\u000b=t\u0013Wx7";
        objectArray[28] = "i.\u001bGXhgb\u001a=RWn#\u0007O\u00015zuA\u00039nao\u0003DRm<x\u0001=";
        objectArray[29] = "\u000e\u0016\u0018\u0012V\r\u0000Z\u0019h^2\t\u001b\u0004\u001a\u000fP\u001dMBV7\u000b\u0006W\u0000\u0011\\\b[@\u0002h";
        objectArray[30] = "ut\tW}R{8\b-fm&z\u0013Fq\u000fe*TQ";
        objectArray[31] = "\r\u0013$n\u0007d\u0003_%\u0014\u000f[\u000f]./Z'ZS {f0\u001aNx(\u001ae\u0014@,\u0014";
        objectArray[32] = "EV2\u00011HK\u001a3{(w\u0015\u0007$\u0004)\u001c\u0016Z3\u0006";
        objectArray[33] = "4cD]FR:/E'^md2RX^\u0006goEZ";
        objectArray[34] = "\u00051\u000b7\u0015Z\u0010 ]\\-'>\u00020#\u0012P\u00116\u00016\u0003\u0006";
        objectArray[35] = "}<\f*hJsp\rPguz1\u0010\"1\u0017ngVn\tKe5Wlx\u0018lsPP";
        objectArray[36] = "\u0012b+\u0003rI\u001c.*yvvG3.\u0014w\u0004\u001a#q\u0000";
        objectArray[37] = "N\f~\u001fD[@@\u007feLdI\u0001b\u0017\u001d\u0006]W$[%^\u0019Ar\bG\u001dI\u0006ee";
        objectArray[38] = "yD7jr:9\u0001&e\u0018>BF3z(//B3hyW";
        objectArray[39] = "\u0011\u0002\\S52\u001fN])2\rDSYD0\u007f\u0019C\u0006P";
        objectArray[40] = "\u0012@[\u000e7\u001a\u0007Q\re\u000bl3s7:\u0007j1>\u001f\u001bu@\u0014\u000f\n\n#";
        objectArray[41] = "3DIh\u001e?r\b\u0018cc1\r\u0017\u001b|\u0011mo\u0003M:]U3\b\u001f;_$`\u0001Y<c";
        objectArray[42] = "-!CY|\u001b#mB#v$*,_Q%F>z\u0019\u001d\u001d\u001a5(\u0018\u001flI<n\u001f#";
        objectArray[43] = "m\u001b%bI/cW$\u0018D\u0010j\u00169j\u0010r~@\u007f&()eZ=aC*8M?\u0018";
        Object[] objectArray2 = objectArray;
        objectArray[44] = "iWr\u0016aL|F$}_%[o\u001e\"Q<J)6\u0003#\u0016o\u0018#\u0012u";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = CartRefill.e(l2, l3);
            object = A[n2];
            try {
                if (!(object instanceof String)) break block2;
                CartRefill.A[n2] = clazz = Class.forName(B[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = CartRefill.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = CartRefill.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = CartRefill.e(l2, l3);
        Object object = A[n2];
        if (object instanceof String) {
            String string = B[n2];
            int n3 = string.indexOf(8);
            Class clazz = CartRefill.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = CartRefill.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = CartRefill.c(clazz3, string2, clazz2)) != null) {
                    CartRefill.A[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = CartRefill.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        CartRefill.A[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = CartRefill.f(366136324438410L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = CartRefill.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = CartRefill.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = CartRefill.e(l2, l3);
        Object object = A[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = B[n2];
                int n4 = string2.indexOf(8);
                clazz3 = CartRefill.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = CartRefill.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = CartRefill.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        CartRefill.A[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = CartRefill.f(366136324438410L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = CartRefill.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        CartRefill.A[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = CartRefill.f(366136324438410L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == '\u00c9' || c2 == 'h' || c2 == 'n' || c2 == 'A') {
                field = CartRefill.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == '\u00c9' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == 'h' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == 'n' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = CartRefill.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == 'K' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == '\u00f0' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = CartRefill.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/e/G" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(CartRefill.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(CartRefill.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

