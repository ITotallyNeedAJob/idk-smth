// === Kuzi module: AutoJumpReset ===
// Category   : PLAYER
// Description: Jumps on incoming knockback to reduce velocity.
// Payload    : a.a.a.j.c.x (verified: False)

package kuzi.modules.player;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.module.Module;
import kuzi.obf.g.a.h;
import kuzi.obf.g.a.v;
import kuzi.obf.h.b.k;
import kuzi.obf.m.r;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import net.minecraft.Blocks;
import net.minecraft.Packet;
import net.minecraft.ClientboundSetEntityMotionPacket;

public class AutoJumpReset
extends BaseModule
implements v,
Module {
    private final k chanceRange;
    private final k jumpDelay;
    private final BoolSetting liquidCheck;
    private final BoolSetting webCheck;
    private volatile int jumpCountdown;
    private static final long s = 69509711989816L;
    private static final Object[] w = new Object[]{"\u0012\u001b!;!\r\u0019\u001b#;8", Integer.TYPE, "$TYqg5(TJ", "\"=Wf\u0017\u007f+=Tf\u001d", "j^Z\\\u0016\n\u001f~QS\u0007E~pZX\u0003\u001f\n", Double.TYPE, "\u001e=\rz9w\u0015=\u000fz6", "E;,=n\u0012N;$", "\u0002&u *'\u000b&v (", "w\u000bY&ja|\u000bR", "\u001adLZ\u0000\u0017oDGU\u0011X\u000eJL^\u0015\u0002z", Void.TYPE, "58]}wu58J!{z/sJ?{o(\u0002\u001ab*", "M6\u001dm158\u0016\u0016b zY\u0018\u001di$ -", "j+\u001c\u0005\u000eJ\u001f\u000b\u0017\n\u001f\u0005~\u0005\u001c\u0001\u001b_\n", Boolean.TYPE, ">0Rw\u0007\u001070Qw\u0007", "\u0015:\u0013o6V\u001e5\u0002 WX\u0015>\u0006z", "{c\u0016Gpdel\u001f8r\u0007!9K\u0004dm~8\u001d\u0002\u001b=\"9NGqb#oH8", "f_X\bjY#\u0002J^\u0012|\u001fzv+H$f_X\bjY#\u0002J^", "XB9g$TFM0\u0018)7\u0002E`i1OU_b#", "TR\u0019E;l\u0017K_N\u0003}j\u0007\u0002L`p[\n\u0014R`", "\"1\u001cD\u0004P<>\u0015;\u00163\u007f7\u0000\u0003\u001fT=c\u0000X", "\u0017T\n?@=@N\bu>,-Y^-F#\u0015\u0001J>QE\u0014\b\nwN%C\u000e]>>", "uz`\u0006?Rkuiy,1(||A$Vj(|\u001a", "0\b\u0013\u0002\u0007\u007fo\u0006]_ui\fSY\u0002Lsl\u0004_U\u0005\u0003", "7P1\u001cXr`J3V&a\r]e\u000e^l5\u0005q\u001dI\n6NoUJ5qNb\u0002&", "o3;^Y8q<2!U[54bPL#b.`\u001a", "\u001a}}<\u0014gEs3afp&&7<_kFq1k\u0016\u001b", "Wq_gm0Of\u0010c\\6=vOwa'Vz^ae_", ".#Ea\u00105m:\u0003j()\u0010/QoP+(wE|GM x\u0005v\u0018-bzTr(", "\u001d&M55K\u0003)DJ$(D}\u0014s.H\u0013{C:", "u\"9P\u0016ok-0/\u0014\f|(>W\u001b4$<-@}en11M\u0007bl39/"};
    private static final String[] x = new String[]{null, "java/lang/Integer", null, null, null, "java/lang/Double", null, null, null, null, null, "java/lang/Void", null, null, null, "java/lang/Boolean", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null};

    public AutoJumpReset() {
        long l2 = s ^ 0x1EC0A9D820E0L;
        long l3 = l2 ^ 0x145F14B7CDL;
        super("AutoJumpReset", "Jumps on incoming knockback to reduce velocity.", Category.PLAYER);
        this.chanceRange = new k("Chance Range %", 0.0, 100.0, 1.0, 80.0, 100.0);
        this.jumpDelay = new k("Jump Delay (ticks)", 0.0, 5.0, 1.0, 0.0, 2.0);
        this.liquidCheck = new BoolSetting("Liquid Check", true);
        this.webCheck = new BoolSetting("Web Check", true);
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.chanceRange, this.jumpDelay, this.liquidCheck, this.webCheck};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        this.jumpCountdown = 0;
        Client.a().a(v.class, this);
        Client.a().a(Module.class, this);
    }

    @Override
    public void e() {
        Client.a().b(v.class, this);
        Client.a().b(Module.class, this);
        this.jumpCountdown = 0;
    }

    @Override
    public void h() {
        this.jumpCountdown = 0;
    }

    @Override
    public void a(h event) {
        long l2;
        long l3 = l2 = s ^ 0x1269B9A88E2CL;
        long l4 = l3 ^ 0x43938CDD8B1FL;
        long l5 = l3 ^ 0x5980EC3079D1L;
        if (BaseModule.a.player == null) {
            return;
        }
        Packet packet = event.c;
        if (!(packet instanceof ClientboundSetEntityMotionPacket)) {
            return;
        }
        ClientboundSetEntityMotionPacket motionPacket = (ClientboundSetEntityMotionPacket)packet;
        if (motionPacket.getId() != BaseModule.a.player.getId()) {
            return;
        }
        if (this.jumpCountdown > 0) {
            return;
        }
        Object[] objectArray = new Object[1];
        objectArray[0] = l5;
        if (!this.a(objectArray)) {
            return;
        }
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l4;
        this.jumpCountdown = this.jumpDelay.a(objectArray2) + 3;
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public void b() {
        block27: {
            block28: {
                block30: {
                    block29: {
                        block25: {
                            block26: {
                                block24: {
                                    block23: {
                                        block21: {
                                            block22: {
                                                block20: {
                                                    block19: {
                                                        var4_1 = this.jumpCountdown;
                                                        var3_2 = false;
                                                        v0 = var4_1;
                                                        if (!var3_2) {
                                                            if (v0 <= 0) {
                                                                return;
                                                            }
                                                            this.jumpCountdown = var4_1 - 1;
                                                            v0 = var4_1;
                                                        }
                                                        if (v0 > 3) {
                                                            return;
                                                        }
                                                        v1 = BaseModule.a;
                                                        if (var3_2) break block19;
                                                        if (v1.player == null) break block20;
                                                        v1 = BaseModule.a;
                                                    }
                                                    if (var3_2) break block21;
                                                    if (v1.level != null) break block22;
                                                }
                                                this.jumpCountdown = 0;
                                                return;
                                            }
                                            v1 = BaseModule.a;
                                        }
                                        v2 = v1.player.hurtTime;
                                        if (var3_2) break block23;
                                        if (v2 <= 0) break block24;
                                        v2 = (int)BaseModule.a.player.onGround();
                                    }
                                    if (var3_2) break block25;
                                    if (v2 != 0) break block26;
                                }
                                return;
                            }
                            v2 = (int)((Boolean)this.liquidCheck.a()).booleanValue();
                        }
                        if (var3_2) break block27;
                        if (v2 == 0) break block28;
                        v2 = (int)BaseModule.a.player.isInWater();
                        if (var3_2) break block29;
                        if (v2 != 0) break block30;
                        v2 = (int)BaseModule.a.player.isInLava();
                    }
                    if (var3_2) break block27;
                    if (v2 == 0) break block28;
                }
                this.jumpCountdown = 0;
                return;
            }
            v3 = this;
            if (var3_2) ** GOTO lbl61
            v2 = (int)((Boolean)v3.q.a()).booleanValue();
        }
        if (v2 != 0) {
            v4 = BaseModule.a;
            if (!var3_2) {
                if (v4.level.getBlockState(BaseModule.a.player.blockPosition()).is(Blocks.COBWEB)) {
                    this.jumpCountdown = 0;
                    return;
                } else {
                    ** GOTO lbl-1000
                }
            }
        } else lbl-1000:
        // 3 sources

        {
            v3 = this;
lbl61:
            // 2 sources

            v3.jumpCountdown = 0;
            v4 = BaseModule.a;
        }
        v4.player.jumpFromGround();
    }

    private boolean a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = (l2 = s ^ l2) ^ 0x5835C170511DL;
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l3;
        double chancePercent = this.chanceRange.c(objectArray2);
        int n2 = 66;
        double d3 = chancePercent - 100.0;
        double d4 = d3 == 0.0 ? 0 : (d3 > 0.0 ? 1 : -1);
        if (n2 != 0) {
            if (d4 >= 0) {
                return true;
            }
            double d5 = chancePercent - 0.0;
            d4 = d5 == 0.0 ? 0 : (d5 < 0.0 ? -1 : 1);
        }
        int n3 = n2;
        if (l2 > 0L) {
            if (n3 != 0) {
                if (d4 <= 0) {
                    return false;
                }
                double d6 = Math.random() * 100.0 - chancePercent;
                d4 = d6 == 0.0 ? 0 : (d6 < 0.0 ? -1 : 1);
            }
            n3 = n2;
        }
        if (n3 != 0) {
            d4 = d4 < 0 ? 1.0 : 0.0;
        }
        return (boolean)d4;
    }

    private static r a(r r2) {
        return r2;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = AutoJumpReset.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = AutoJumpReset.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = AutoJumpReset.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = AutoJumpReset.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }
}

