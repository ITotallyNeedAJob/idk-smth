// === Kuzi module: HoverTotem ===
// Category   : PLAYER
// Description: Equips a totem in offhand when hovered
// Payload    : a.a.a.j.c.M (verified: True)

package kuzi.modules.player;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.core.Client;
import kuzi.mixin.MixinExposed;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.module.Module;
import kuzi.obf.h.b.v;
import kuzi.obf.i.z_0;
import kuzi.obf.m.r;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.Player;
import net.minecraft.ClickType;
import net.minecraft.InventoryMenu;
import net.minecraft.Slot;
import net.minecraft.ItemStack;
import net.minecraft.Items;
import net.minecraft.Level;
import net.minecraft.ClientboundEntityEventPacket;
import net.minecraft.Minecraft;
import net.minecraft.Screen;
import net.minecraft.InventoryScreen;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class HoverTotem
extends BaseModule
implements Module {
    private final BoolSetting hotbarTotem;
    private final SliderSetting hotbarSlot;
    private final BoolSetting autoSwitchToTotem;
    private final BoolSetting autoInvOpen;
    private boolean inventoryOpenRequested;
    private boolean restoreHandled;
    private boolean restoreRequested;
    private static final long t;
    private static final String[] u;
    private static final String[] v;
    private static final Map w;
    private static final long[] x;
    private static final Integer[] y;
    private static final Map z;
    private static final Object[] A;
    private static final String[] B;

    public HoverTotem() {
        long l2 = t ^ 0x61A9A3D44207L;
        long l3 = l2 ^ 0xDBCDB121332L;
        super("HoverTotem", "Equips a totem in offhand when hovered", Category.PLAYER);
        this.hotbarTotem = new BoolSetting("Hotbar Totem", true);
        this.hotbarSlot = new SliderSetting("Hotbar Slot", 1.0, 1.0, 9.0, 1.0);
        this.autoSwitchToTotem = new BoolSetting("Auto Switch To Totem", false);
        this.autoInvOpen = new BoolSetting("Auto Inv Open", false);
        this.inventoryOpenRequested = false;
        this.restoreHandled = false;
        this.restoreRequested = false;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.hotbarTotem, this.hotbarSlot, this.autoSwitchToTotem, this.autoInvOpen};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        Client.a().a(Module.class, this);
        super.d();
        this.inventoryOpenRequested = false;
        this.restoreHandled = false;
        this.restoreRequested = false;
    }

    @Override
    public void e() {
        Client.a().b(Module.class, this);
        super.e();
        this.inventoryOpenRequested = false;
        this.restoreHandled = false;
        this.restoreRequested = false;
    }

    @Override
    public void b() {
        block15: {
            long l2;
            long l3 = l2 = t ^ 0x5598945612E4L;
            long l4 = l3 ^ 0x14AF664A4426L;
            long l5 = l3 ^ 0x42755E0F7D6BL;
            long l6 = l3 ^ 0x2F762D4066A3L;
            long l7 = l3 ^ 0x2C69E7840B17L;
            long l8 = l3 ^ 0x70F48C53049BL;
            if (BaseModule.a.player == null) {
                return;
            }
            if (((Boolean)this.autoInvOpen.a()).booleanValue() && !BaseModule.a.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) {
                Object[] objectArray = new Object[1];
                objectArray[0] = l5;
                if (this.a(objectArray) && BaseModule.a.screen == null) {
                    this.inventoryOpenRequested = true;
                }
            }
            if (this.inventoryOpenRequested && BaseModule.a.screen == null) {
                Object[] objectArray = new Object[1];
                objectArray[0] = l5;
                if (this.a(objectArray)) {
                    BaseModule.a.execute(() -> this.lambda$onTick2$0(l4));
                } else {
                    this.inventoryOpenRequested = false;
                }
                return;
            }
            Screen screen = BaseModule.a.screen;
            if (!(screen instanceof InventoryScreen)) {
                if (this.restoreRequested && !this.restoreHandled && BaseModule.a.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) {
                    this.restoreHandled = true;
                    this.restoreRequested = false;
                }
                if (this.restoreRequested && !this.restoreHandled) {
                    this.inventoryOpenRequested = true;
                }
                return;
            }
            InventoryScreen inventoryScreen = (InventoryScreen)screen;
            if (((Boolean)this.autoInvOpen.a()).booleanValue() && !this.restoreHandled && BaseModule.a.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) {
                this.restoreHandled = true;
                this.restoreRequested = false;
                BaseModule.a.execute(() -> HoverTotem.lambda$onTick2$1(l7));
                return;
            }
            Slot hoveredSlot = this.a(new Object[]{inventoryScreen});
            if (hoveredSlot == null || hoveredSlot.getContainerSlot() > 35) {
                return;
            }
            if (((Boolean)this.autoSwitchToTotem.a()).booleanValue()) {
                BaseModule.a.player.getInventory().setSelectedSlot(((Double)this.hotbarSlot.a()).intValue() - 1);
            }
            if (!hoveredSlot.getItem().is(Items.TOTEM_OF_UNDYING)) {
                return;
            }
            int containerSlot = hoveredSlot.getContainerSlot();
            int containerId = ((InventoryMenu)inventoryScreen.getMenu()).containerId;
            if (!BaseModule.a.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) {
                Object[] objectArray = new Object[3];
                objectArray[2] = containerSlot;
                objectArray[1] = l8;
                objectArray[0] = containerId;
                this.a(objectArray);
                return;
            }
            if (!((Boolean)this.hotbarTotem.a()).booleanValue()) break block15;
            int hotbarIndex = ((Double)this.hotbarSlot.a()).intValue() - 1;
            if (!BaseModule.a.player.getInventory().getItem(hotbarIndex).is(Items.TOTEM_OF_UNDYING)) {
                Object[] objectArray = new Object[4];
                objectArray[3] = l6;
                objectArray[2] = hotbarIndex;
                objectArray[1] = containerSlot;
                objectArray[0] = containerId;
                this.b(objectArray);
            }
        }
    }

    @MixinExposed
    public void a(Object object) {
        ClientboundEntityEventPacket packet;
        long l2 = t ^ 0x48F98C8C1BF4L;
        long l3 = l2 ^ 0x5F1446D5747BL;
        boolean bl = false;
        if (object instanceof ClientboundEntityEventPacket && (packet = (ClientboundEntityEventPacket)object).getEventId() == 35 && BaseModule.a.player != null && packet.getEntity((Level)BaseModule.a.level) == BaseModule.a.player && ((Boolean)this.autoInvOpen.a()).booleanValue() && BaseModule.a.screen == null) {
            Object[] objectArray = new Object[1];
            objectArray[0] = l3;
            if (this.a(objectArray)) {
                this.inventoryOpenRequested = true;
                this.restoreHandled = false;
                this.restoreRequested = true;
            }
        }
    }

    private boolean a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = t ^ l2;
        int n2 = 66;
        if (BaseModule.a.player == null) {
            return false;
        }
        int n3 = 0;
        while (n3 < HoverTotem.c("h", (int)23880, (long)(0x268B7C52D93778F7L ^ l2))) {
            ItemStack stack = BaseModule.a.player.getInventory().getItem(n3);
            int n4 = n2;
            if (l2 >= 0L) {
                if (n4 != 0) {
                    if (stack.is(Items.TOTEM_OF_UNDYING)) {
                        return true;
                    }
                    ++n3;
                }
                n4 = n2;
            }
            if (n4 != 0) continue;
        }
        return false;
    }

    private void a(Object[] objectArray) {
        int containerId = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int slotId = (Integer)objectArray[2];
        l2 = t ^ l2;
        ((Minecraft)HoverTotem.d("\u00d2", (long)1619731384320584374L, (long)l2)).gameMode.handleInventoryMouseClick(containerId, slotId, (int)HoverTotem.c("h", (int)22340, (long)(0x3624DBEE2A348B09L ^ l2)), ClickType.SWAP, (Player)((Minecraft)HoverTotem.d("\u00d2", (long)1619731384320584374L, (long)l2)).player);
    }

    private void b(Object[] objectArray) {
        int containerId = (Integer)objectArray[0];
        int slotId = (Integer)objectArray[1];
        int hotbarButton = (Integer)objectArray[2];
        long l2 = (Long)objectArray[3];
        l2 = t ^ l2;
        BaseModule.a.gameMode.handleInventoryMouseClick(containerId, slotId, hotbarButton, ClickType.SWAP, (Player)BaseModule.a.player);
    }

    private Slot a(Object[] objectArray) {
        InventoryScreen inventoryScreen = (InventoryScreen)objectArray[0];
        return ((z_0)inventoryScreen).kuzi$getFocusedSlot();
    }

    private static void lambda$onTick2$1(long l2) {
        l2 = t ^ l2;
        BaseModule.a.player.closeContainer();
        BaseModule.a.mouseHandler.grabMouse();
    }

    private void lambda$onTick2$0(long l2) {
        l2 = t ^ l2;
        boolean bl = false;
        if (BaseModule.a.player != null) {
            BaseModule.a.setScreen((Screen)new InventoryScreen((Player)BaseModule.a.player));
            this.inventoryOpenRequested = false;
            this.restoreHandled = false;
            this.restoreRequested = true;
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block21: {
            block20: {
                block19: {
                    block18: {
                        HoverTotem.t = kuzi.obf.h.b.v.a(5849705529979206988L, 4049415475073781120L, MethodHandles.lookup().lookupClass()).a(21669155984941L);
                        HoverTotem.A = new Object[37];
                        HoverTotem.B = new String[37];
                        HoverTotem.c();
                        HoverTotem.w = new HashMap<K, V>(13);
                        var11 = HoverTotem.t ^ 20510875162615L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[6];
                        var18_4 = 0;
                        var17_5 = "\u0018=\u009f\u00a6\u0094\u00a0\u0083>!\t\u008d\u00a3\u00b51\u00b0\u00d4-_\t1<\u0098\u00bb\u0093\nDv\u00b9;\u00ff\u00ca\u008b\u0018\u00df\u00b6B4\u00c1\u0093e\u00ba\u00c5\u001f\u0081X\u00cc\u0013/\\:.\u00d2\u00d8\t\n#O0\u0006\u00fe\u00f6f\u00e7\u0019\u0098X\u00db\u00e8\u00de_\u008e\u00e3\u0011\u00a9\u00a7\u00bc\u00832\u00f1\u00cce\u0098\u0010M\\1#&\u001c\u0019W\u000fc\u00e8\u008d\u0004\nzRr\u00b1zG-&M\u0018\f\u00c3D1j\u008eU?\u00d7\u00cb\u00c9\u00eec<L\u00d8\u00a2\u0004\u00be\u00d3\u0088Ws)";
                        var19_6 = "\u0018=\u009f\u00a6\u0094\u00a0\u0083>!\t\u008d\u00a3\u00b51\u00b0\u00d4-_\t1<\u0098\u00bb\u0093\nDv\u00b9;\u00ff\u00ca\u008b\u0018\u00df\u00b6B4\u00c1\u0093e\u00ba\u00c5\u001f\u0081X\u00cc\u0013/\\:.\u00d2\u00d8\t\n#O0\u0006\u00fe\u00f6f\u00e7\u0019\u0098X\u00db\u00e8\u00de_\u008e\u00e3\u0011\u00a9\u00a7\u00bc\u00832\u00f1\u00cce\u0098\u0010M\\1#&\u001c\u0019W\u000fc\u00e8\u008d\u0004\nzRr\u00b1zG-&M\u0018\f\u00c3D1j\u008eU?\u00d7\u00cb\u00c9\u00eec<L\u00d8\u00a2\u0004\u00be\u00d3\u0088Ws)".length();
                        var16_7 = 32;
                        var15_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block18;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = HoverTotem.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "\u00e4\u00f9\u00b2\u000e\f\u00df\u00f9)\u0081\u0018\u00f7\u00eb\u00f7\u00dcs_\u0012\u00a9\u00bf*\u009f\u0019\u00a0\u000e\u000bIJ\u00de\u001f\u00a4B]3\u00c6\u009d\u00e1\u00ecV\u00cb\u00f9\u00fc\u00ef\u0087aQ\u009d\u009e\u0094\u00ac\tf\u00bf\u00de\u00d5\u00e7\u00fc\u00d6K:Xl\u00b4\u0004\u00e5\u0018\u0012\u00a6)Bj\u0091\u00c7\u008fz\u0018\\\u009a\u0003\u009cCf>&\u00a0\u00c1\u00cf\u00ce|\u009a";
                            var19_6 = "\u00e4\u00f9\u00b2\u000e\f\u00df\u00f9)\u0081\u0018\u00f7\u00eb\u00f7\u00dcs_\u0012\u00a9\u00bf*\u009f\u0019\u00a0\u000e\u000bIJ\u00de\u001f\u00a4B]3\u00c6\u009d\u00e1\u00ecV\u00cb\u00f9\u00fc\u00ef\u0087aQ\u009d\u009e\u0094\u00ac\tf\u00bf\u00de\u00d5\u00e7\u00fc\u00d6K:Xl\u00b4\u0004\u00e5\u0018\u0012\u00a6)Bj\u0091\u00c7\u008fz\u0018\\\u009a\u0003\u009cCf>&\u00a0\u00c1\u00cf\u00ce|\u009a".length();
                            var16_7 = 64;
                            var15_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block18;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = HoverTotem.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block19;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                HoverTotem.u = var20_3;
                HoverTotem.v = new String[6];
                HoverTotem.z = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[4];
                var3_13 = 0;
                var4_14 = "\u00d0\u00b1`7\u00d1\u00a4\u00a1\u00d5\u0089\u00efNE\u00f7~\u0098\u0091";
                var5_15 = "\u00d0\u00b1`7\u00d1\u00a4\u00a1\u00d5\u0089\u00efNE\u00f7~\u0098\u0091".length();
                var2_16 = 0;
                while (true) {
                    var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                    v10 = var6_12;
                    v11 = var3_13++;
                    v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                    v13 = -1;
                    break block20;
                    break;
                }
lbl81:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    var4_14 = "\f\u00a2V\u00e8\u000f\u00f3\u00b4\u00ac\u0001\u0012\u0087R\u009d\u0084\u0010j";
                    var5_15 = "\f\u00a2V\u00e8\u000f\u00f3\u00b4\u00ac\u0001\u0012\u0087R\u009d\u0084\u0010j".length();
                    var2_16 = 0;
                    while (true) {
                        var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                        v10 = var6_12;
                        v11 = var3_13++;
                        v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                        v13 = 0;
                        break block20;
                        break;
                    }
                    break;
                }
lbl94:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    break block21;
                    break;
                }
            }
            var8_18 = v12;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            v14 = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
            switch (v13) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl107:
                // 1 sources

                ** continue;
            }
        }
        HoverTotem.x = var6_12;
        HoverTotem.y = new Integer[4];
    }

    private static r a(r r2) {
        return r2;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x4A32;
        if (y[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = x[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])z.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    z.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/c/M", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            HoverTotem.y[n3] = n4;
        }
        return y[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = HoverTotem.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/c/M" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (B[n4] != null) {
            return n4;
        }
        Object object = A[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 36;
            case 1 -> 51;
            case 2 -> 21;
            case 3 -> 32;
            case 4 -> 12;
            case 5 -> 59;
            case 6 -> 26;
            case 7 -> 40;
            case 8 -> 22;
            case 9 -> 52;
            case 10 -> 8;
            case 11 -> 41;
            case 12 -> 63;
            case 13 -> 46;
            case 14 -> 1;
            case 15 -> 3;
            case 16 -> 19;
            case 17 -> 24;
            case 18 -> 45;
            case 19 -> 13;
            case 20 -> 0;
            case 21 -> 23;
            case 22 -> 39;
            case 23 -> 42;
            case 24 -> 55;
            case 25 -> 14;
            case 26 -> 10;
            case 27 -> 37;
            case 28 -> 5;
            case 29 -> 30;
            case 30 -> 49;
            case 31 -> 34;
            case 32 -> 15;
            case 33 -> 29;
            case 34 -> 47;
            case 35 -> 25;
            case 36 -> 6;
            case 37 -> 44;
            case 38 -> 16;
            case 39 -> 28;
            case 40 -> 27;
            case 41 -> 38;
            case 42 -> 20;
            case 43 -> 31;
            case 44 -> 7;
            case 45 -> 56;
            case 46 -> 50;
            case 47 -> 35;
            case 48 -> 43;
            case 49 -> 62;
            case 50 -> 17;
            case 51 -> 54;
            case 52 -> 53;
            case 53 -> 11;
            case 54 -> 18;
            case 55 -> 57;
            case 56 -> 4;
            case 57 -> 48;
            case 58 -> 33;
            case 59 -> 2;
            case 60 -> 58;
            case 61 -> 9;
            case 62 -> 60;
            default -> 61;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        HoverTotem.B[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = A;
        A[0] = "p0X4Ls{0Z4`";
        objectArray[1] = Boolean.TYPE;
        HoverTotem.B[1] = "java/lang/Boolean";
        objectArray[2] = "]zP\bx\u001eVz[";
        objectArray[3] = "/<UR3J/<B\u000e?E5wB\u0010?P2\u0006\u0012Mn";
        objectArray[4] = "9,}2\r\u00042,\u007f2\u0002";
        objectArray[5] = Integer.TYPE;
        HoverTotem.B[5] = "java/lang/Integer";
        objectArray[6] = "{8!--\u0005w82";
        objectArray[7] = "C\u001d\u0007P\u001ar6=\f_\u000b=W3\u0007T\u000fg#";
        objectArray[8] = Void.TYPE;
        HoverTotem.B[8] = "java/lang/Void";
        objectArray[9] = "~(Nf1Bw(Mf3";
        objectArray[10] = " 0J\r\u000fa)0I\r\u0003";
        objectArray[11] = "{XY\be\"\u000exR\u0007tmovY\fp7\u001b";
        objectArray[12] = "\u0000\u000b\u0004W6;\t\u000b\u0007W6";
        objectArray[13] = "[\u001a\rXH\u000fP\u0015\u001c\u0017)\u0001[\u001e\u0018M";
        objectArray[14] = "u\u0011F\u0018I#\u00001M\u0017Xla?F\u001c\\6\u0015";
        objectArray[15] = "?\u0000\u007f_w'?\u0000h\u0003{(%Kh\u001d{=\"::F){";
        objectArray[16] = "\u0001xOBH\u0000tXDMYO\u0015VOF]\u0015a";
        objectArray[17] = "\u0017\"{_Xw\u001c\"s";
        objectArray[18] = "`\u0001krxX\u0015!`}i\u0017t/kvmM\u0000";
        objectArray[19] = "0.\u0007I^\u0012!bXA55\u001fZlkom0.\u0007I^\u0012!bXA";
        objectArray[20] = "\u000bW\u0002\u0007#kPAUxd\u0010DVV\b!rEK\r";
        objectArray[21] = "F\u0003_\u0004\u001a\u0006N\u0017J\u0007jS\u007fD\u000e\u0011\n\u0005GO\b\u0007\t";
        objectArray[22] = "\u0006Z\r\u001c`F]LZc$=I[Y\u0013b_HF\u0002";
        objectArray[23] = "1z,lH*jl{\u0013\rQ~{xcJ3\u007ff#";
        objectArray[24] = "s,#\u0012J '/ \u001d46H*+BN2vl5\u0018P\\";
        objectArray[25] = "^0xt\u0004y\u0005&/\u000bP\u0002\u00059*l[9S556:<U&,lQcU4+\u000b";
        objectArray[26] = "`d\u0002R}b;rU-&\u0019ns\tP-f;vB\u001d";
        objectArray[27] = "N+\u0003Xg\u0001\u0015=T'!z@<\bZ7\u0005\u00159C\u0017";
        objectArray[28] = "/ J[z|t6\u001d$\"\u0007 g\u0019H+g#0D\u001f";
        objectArray[29] = " \u001fdnqZ{\t3\u0011&!{\u00166v.\u001a-\u001a),O\u001f+\t0v$@+\u001b7\u0011";
        objectArray[30] = "@@0!\r2\u001bVg^ZIL\u0007=.Q%\u0014\u0002o73uN\u0004p<_-KVi^";
        objectArray[31] = "#0s,\u007fm)h -\u0010u\u0013cz;\u007fb*2y  \u001c";
        objectArray[32] = "=\r\u0012?\u0017ni\u000e\u00110iy\u0006\u000b\u001ao\u0013|8M\u00045\r\u0012";
        objectArray[33] = "U\u0000f\u0000\u0016l]\u0014s\u0003f4l\u0016y\u0006\u00011W@u\u0019[PRFf\u0000\u0001;\rFt\u0007f";
        objectArray[34] = ">$P}\u001dAe2\u0007\u0002D:03[\u007fMEe6\u00102";
        objectArray[35] = "{.\u0015\u0003\u0016\" 8B|AY 'G\u001bIbv+XA(3sj\u001e\u0005U$vn@|";
        Object[] objectArray2 = objectArray;
        objectArray[36] = "kW.4Y*0AyK\u000eQ0^|,\u0006jfRcvg.#Jnw\u0005/>\u0011\u001e";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = HoverTotem.e(l2, l3);
            object = A[n2];
            try {
                if (!(object instanceof String)) break block2;
                HoverTotem.A[n2] = clazz = Class.forName(B[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = HoverTotem.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = HoverTotem.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = HoverTotem.e(l2, l3);
        Object object = A[n2];
        if (object instanceof String) {
            String string = B[n2];
            int n3 = string.indexOf(8);
            Class clazz = HoverTotem.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = HoverTotem.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = HoverTotem.c(clazz3, string2, clazz2)) != null) {
                    HoverTotem.A[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = HoverTotem.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        HoverTotem.A[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = HoverTotem.f(979745484999572L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = HoverTotem.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = HoverTotem.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = HoverTotem.e(l2, l3);
        Object object = A[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = B[n2];
                int n4 = string2.indexOf(8);
                clazz3 = HoverTotem.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = HoverTotem.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = HoverTotem.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        HoverTotem.A[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = HoverTotem.f(979745484999572L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = HoverTotem.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        HoverTotem.A[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = HoverTotem.f(979745484999572L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == '\u00e1' || c2 == 'g' || c2 == '\u00d2' || c2 == 'V') {
                field = HoverTotem.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == '\u00e1' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == 'g' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == '\u00d2' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = HoverTotem.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == '\u00c4' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == 'R' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = HoverTotem.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/c/M" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(HoverTotem.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(HoverTotem.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

