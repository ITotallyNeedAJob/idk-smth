// === Kuzi module: AutoEat ===
// Category   : PLAYER
// Description: Automatically eats food when health or hunger is low.
// Payload    : a.a.a.j.c.v (verified: False)

package kuzi.modules.player;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.module.Module;
import kuzi.obf.m.r;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.InteractionHand;
import net.minecraft.Player;
import net.minecraft.ItemStack;
import net.minecraft.FoodProperties;
import net.minecraft.DataComponents;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class AutoEat
extends BaseModule
implements Module {
    private final SliderSetting healthThreshold;
    private final SliderSetting hungerThreshold;
    private boolean eating;
    private int foodSlot;
    private int previousSlot;
    private static final long r = 58264194119123L;
    private static final long v;
    private static final Object[] w;
    private static final String[] x;

    public AutoEat() {
        long l2 = r ^ 0x28C193060C91L;
        long l3 = l2 ^ 0x3DDF28EC6257L;
        super("AutoEat", "Automatically eats food when health or hunger is low.", Category.PLAYER);
        this.healthThreshold = new SliderSetting("Health Threshold", 10.0, 1.0, 19.0, 1.0);
        this.hungerThreshold = new SliderSetting("Hunger Threshold", 16.0, 1.0, 19.0, 1.0);
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.healthThreshold, this.hungerThreshold};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        Client.a().a(Module.class, this);
        super.d();
        this.eating = false;
        this.foodSlot = -1;
        this.previousSlot = -1;
    }

    @Override
    public void e() {
        block3: {
            AutoEat self;
            long l2;
            block2: {
                long l3 = r ^ 0x4A0C15003230L;
                l2 = l3 ^ 0x4A773F8055FCL;
                Client.a().b(Module.class, this);
                super.e();
                boolean bl = false;
                self = this;
                if (bl) break block2;
                if (!self.eating) break block3;
                self = this;
            }
            Object[] objectArray = new Object[1];
            objectArray[0] = l2;
            self.f(objectArray);
        }
    }

    @Override
    public void b() {
        long l2;
        long l3 = l2 = r ^ 0x2C93577A2D17L;
        long l4 = l3 ^ 0x70021A7A0FEEL;
        long l5 = l3 ^ 0x152AE7BA5319L;
        long l6 = l3 ^ 0x62594976A33EL;
        long l7 = l3 ^ 0x2CE87DFA4ADBL;
        long l8 = l3 ^ 0x7A24C0814727L;
        long l9 = l3 ^ 0x2C4DD31C298BL;
        if (BaseModule.a.player == null || BaseModule.a.level == null) {
            return;
        }
        if (this.eating) {
            Object[] objectArray = new Object[1];
            objectArray[0] = l6;
            if (!this.a(objectArray)) {
                Object[] objectArray2 = new Object[1];
                objectArray2[0] = l7;
                this.f(objectArray2);
                return;
            }
            ItemStack stack = BaseModule.a.player.getInventory().getItem(this.foodSlot);
            if (stack.get(DataComponents.FOOD) == null) {
                Object[] objectArray3 = new Object[1];
                objectArray3[0] = l9;
                int n2 = this.a(objectArray3);
                if (n2 == -1) {
                    Object[] objectArray4 = new Object[1];
                    objectArray4[0] = l7;
                    this.f(objectArray4);
                    return;
                }
                Object[] objectArray5 = new Object[2];
                objectArray5[1] = n2;
                objectArray5[0] = l8;
                this.b(objectArray5);
            }
            Object[] objectArray6 = new Object[1];
            objectArray6[0] = l5;
            this.c(objectArray6);
        } else {
            Object[] objectArray = new Object[1];
            objectArray[0] = l6;
            if (this.a(objectArray)) {
                Object[] objectArray7 = new Object[1];
                objectArray7[0] = l4;
                this.a(objectArray7);
            }
        }
    }

    private void a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = (l2 = r ^ l2) ^ 0x51D54D57A924L;
        this.previousSlot = BaseModule.a.player.getInventory().getSelectedSlot();
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l3;
        this.c(objectArray2);
    }

    private void c(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = (l2 = r ^ l2) ^ 0x5BF397ACE1EDL;
        Object[] objectArray2 = new Object[2];
        objectArray2[1] = this.foodSlot;
        objectArray2[0] = l3;
        this.b(objectArray2);
        boolean bl = false;
        BaseModule.a.options.keyUse.setDown(true);
        if (!bl) {
            if (!BaseModule.a.player.isUsingItem()) {
                BaseModule.a.gameMode.useItem((Player)BaseModule.a.player, InteractionHand.MAIN_HAND);
            }
            this.eating = true;
        }
    }

    private void f(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = (l2 = r ^ l2) ^ 0x62310DECF82FL;
        Object[] objectArray2 = new Object[2];
        objectArray2[1] = this.previousSlot;
        objectArray2[0] = l3;
        this.b(objectArray2);
        BaseModule.a.options.keyUse.setDown(false);
        this.eating = false;
    }

    private void b(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        int n2 = (Integer)objectArray[1];
        l2 = r ^ l2;
        BaseModule.a.player.getInventory().setSelectedSlot(n2);
        this.foodSlot = n2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean a(Object[] objectArray) {
        boolean bl;
        boolean bl2;
        FoodProperties food;
        block13: {
            boolean bl3;
            block14: {
                block12: {
                    boolean bl4;
                    boolean bl5;
                    long l2;
                    long l3;
                    block11: {
                        boolean bl6;
                        block10: {
                            l3 = (Long)objectArray[0];
                            l2 = (l3 = r ^ l3) ^ 0x7AE92AFD7F66L;
                            bl3 = 66 != 0;
                            if (BaseModule.a.player == null) {
                                return false;
                            }
                            bl5 = BaseModule.a.player.getHealth() <= ((Double)this.healthThreshold.a()).floatValue();
                            bl4 = BaseModule.a.player.getFoodData().getFoodLevel();
                            bl6 = bl3;
                            if (l3 < 0L) break block10;
                            if (!bl6) break block11;
                            bl6 = ((Double)this.hungerThreshold.a()).intValue();
                        }
                        bl4 = bl4 <= bl6;
                    }
                    boolean bl7 = bl4;
                    Object[] objectArray2 = new Object[1];
                    objectArray2[0] = l2;
                    this.foodSlot = this.a(objectArray2);
                    boolean bl8 = this.foodSlot;
                    boolean bl9 = bl3;
                    if (l3 >= 0L) {
                        if (!bl9) return bl8;
                        bl9 = -1 != 0;
                    }
                    if (bl8 == bl9) {
                        return false;
                    }
                    ItemStack stack = BaseModule.a.player.getInventory().getItem(this.foodSlot);
                    food = (FoodProperties)stack.get(DataComponents.FOOD);
                    if (l3 >= 0L && food == null) {
                        return false;
                    }
                    if (bl5) break block12;
                    bl2 = bl7;
                    bl = bl3;
                    if (l3 <= 0L) break block13;
                    if (!bl) break block14;
                    if (!bl2) return false;
                }
                bl2 = BaseModule.a.player.getFoodData().needsFood();
            }
            bl = bl3;
        }
        if (!bl) return bl2;
        if (bl2) return true;
        if (!food.comp_2493()) return false;
        return true;
    }

    private int a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = r ^ l2;
        int bestSlot = -1;
        boolean bl = false;
        int bestNutrition = -1;
        int slot = 0;
        while (slot < (int)v) {
            boolean bl2;
            block7: {
                block8: {
                    block6: {
                        FoodProperties food;
                        block5: {
                            FoodProperties mc41743;
                            ItemStack stack = BaseModule.a.player.getInventory().getItem(slot);
                            food = mc41743 = (FoodProperties)stack.get(DataComponents.FOOD);
                            if (bl) break block5;
                            if (food == null && l2 > 0L) break block6;
                            food = mc41743;
                        }
                        int nutrition = food.comp_2491();
                        bl2 = bl;
                        if (l2 <= 0L) break block7;
                        if (bl2) break block8;
                        if (nutrition > bestNutrition) {
                            bestSlot = slot;
                            bestNutrition = nutrition;
                        }
                    }
                    ++slot;
                }
                bl2 = bl;
            }
            if (!bl2) continue;
        }
        return bestSlot;
    }

    static {
        w = new Object[]{"f\u000frW=bm\u000fpW*", Boolean.TYPE, "tt7\u0018|-\u007ft<", "\f?D6<W\f?Sj0X\u0016tSt0M\u0011\u0005\u0003)a", "gN7\u000b\u0013`\u0012n<\u0004\u0002/s`7\u000f\u0006u\u0007", Void.TYPE, "F;\u0017\u001c?lJ;\u0004", Integer.TYPE, "sx\u0018C:\u000fxx\u001aC5", "X(9R\n[-\b2]\u001b\u0014L\u00069V\u001fN8", "\u000en3Ybx{N8Vs7\u001a@3]wmn", "\b\n>WN\f}*5X_C\u001c$>S[\u0019h", "1\u0011\u0016*!ED1\u001d%0\n%?\u0016.4PQ", "')V2'\u0003R\t]=6L3\u0007V62\u0016G", "=mcz,|4m`z ", ",\nWd\r+%\nTd\r", "hgT\"b\u0005chEm\u0003\u000bhcA7", "}L\u0004:`\u0004vL\f", "^X\u0006\u00111W+x\r\u001e \u0018Jv\u0006\u0015$B>", "\u000fC}\u0000i\u0007\u0004C,Z\u000b6 e\u001c'Qn\u000fC}\u0000i\u0007\u0004C,Z", "\t8\u001c8QMY1I__$N.\u001fg][Vq\u0019", "Jer\u0004C4\u0012:*L\u007f2s<y\u0007\u0018&\u0014>t\u0003\u0006", "k\u0017B\u001cie;\u001e\u0017{j\f>\u001cFK:gi\t\u0011\u0002\u000077\u0016\u001c\u000191$\u0004\u001f{", "\u007f)\u0005\u0000\u001bq/ Pg\u001b\u0018}1E\b\n'# Z\u0003r$('U\u001fMz98^g", "/\u000b8\fq\u0019\u007f\u0002mk`p-\u000b:\b\u007f\u000b,C{\u0016", "\u001cP]\u001fy9LY\bxyPI[YH*;\u001eN\u000e\u0001\u0010k@Q\u0003\u0002)mSC\u0000x", "r\u0016h \u0012t\"\u001f=G\u0010\u001d'\u001dlwAvp\b;>{&.\u00176=B =\u00055G", "@|}I\u0012mC>}Ux}}85\u0006\u001bp\u00069}G\u0005\u0017", ";\u0019wV\u007f=k\u0010\"1sTl\u0002pZy-bQ'C", "-\u0004\u0017\u0007h#}\rB`oJx\u000f\u0013P;!/\u001aD\u0019\u0001qq\u0005I\u001a8wb\u0017J`", "e +I;p5)~.+\u0019g )M5bfhhS", "h$\nWpV8-_0p?=/\u000e\u0000#Tj:YI\u0019\u0003'hVWb\u0002o)H0", ",\"\u000evl\u001b|+[\u0011lry)\n!?\u0019.<]h\u0005\u000buo\ttz\u0013*i1", "(So\b\tFxZ:o\u0006/\u007fHh\u0004\u000fVq\u001b?\u001d", "V\u000b\u0005{\u001bD\u000e\u001fSnxM?\u001fPh\u0015DP\r\u00010\u0002$", "\u001e\t\u0000(M\u0018\u001dK\u00004'\t#MHgD\u0005XL\u0000&Zb", "[&y\u001cQH\u0003y!TmCb.a_]\u001d\tyt\b\u0014'Y'k\u0005\u0017\u001e_4y\u0006m"};
        x = new String[]{null, "java/lang/Boolean", null, null, null, "java/lang/Void", null, "java/lang/Integer", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null};
        v = 5412251605821030409L;
    }

    private static r a(r value) {
        return value;
    }

    private static Field findDeclaredField(Class ownerClass, String fieldName, Class fieldType) {
        for (Field field : ownerClass.getDeclaredFields()) {
            if (!field.getName().equals(fieldName) || field.getType() != fieldType) continue;
            return field;
        }
        return null;
    }

    private static Field findField(Class ownerClass, String fieldName, Class fieldType) {
        Field field = AutoEat.findDeclaredField(ownerClass, fieldName, fieldType);
        if (field != null) {
            return field;
        }
        Class<?>[] interfaces = ownerClass.getInterfaces();
        if (interfaces != null) {
            for (int index = 0; index < interfaces.length; ++index) {
                field = AutoEat.findField(interfaces[index], fieldName, fieldType);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method findDeclaredMethod(Class ownerClass, String methodName, Class returnType, int parameterCount, Class[] expectedParameterTypes) {
        block0: for (Method method : ownerClass.getDeclaredMethods()) {
            Class<?>[] parameterTypes;
            if (!method.getName().equals(methodName) || method.getReturnType() != returnType || (parameterTypes = method.getParameterTypes()).length != parameterCount) continue;
            for (int index = 0; index < parameterCount; ++index) {
                if (parameterTypes[index] != expectedParameterTypes[index]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method findMethod(Class ownerClass, String methodName, Class returnType, int parameterCount, Class[] expectedParameterTypes) {
        Method method = AutoEat.findDeclaredMethod(ownerClass, methodName, returnType, parameterCount, expectedParameterTypes);
        if (method != null) {
            return method;
        }
        Class<?>[] interfaces = ownerClass.getInterfaces();
        if (interfaces != null) {
            for (int index = 0; index < interfaces.length; ++index) {
                method = AutoEat.findMethod(interfaces[index], methodName, returnType, parameterCount, expectedParameterTypes);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }
}

