// === Kuzi module: TotemRefill ===
// Category   : PLAYER
// Description: Refills a totem into your offhand or a hotbar slot from your inventory.
// Payload    : a.a.a.j.e.ai (verified: True)

package kuzi.modules.player;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.module.Module;
import kuzi.obf.h.b.l;
import kuzi.obf.h.b.v;
import kuzi.obf.j.e.am;
import kuzi.obf.j.e.w;
import kuzi.obf.j.e.x;
import kuzi.obf.m.r;
import kuzi.obf.p.aF;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.Player;
import net.minecraft.ClickType;
import net.minecraft.Items;
import net.minecraft.Minecraft;
import net.minecraft.MouseHandler;
import net.minecraft.Screen;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class TotemRefill
extends BaseModule
implements Module {
    private final l refillTo;
    private final SliderSetting slot;
    private final SliderSetting delay;
    private w state;
    private int stateTicks;
    private int delayTicks;
    private boolean screenOpen;
    private int targetSlot;
    private static final long u;
    private static final String[] v;
    private static final String[] w;
    private static final Map x;
    private static final long[] y;
    private static final Integer[] z;
    private static final Map A;
    private static final Object[] B;
    private static final String[] C;

    public TotemRefill() {
        long l2 = u ^ 0x1C05AB0D854DL;
        long l3 = l2 ^ 0x2310E5D3D16CL;
        super("TotemRefill", "Refills a totem into your offhand or a hotbar slot from your inventory.", Category.PLAYER);
        this.refillTo = new l("Refill To", kuzi.obf.j.e.x.SLOT, x.class);
        this.slot = new SliderSetting("Slot", 9.0, 1.0, 9.0, 1.0);
        this.delay = new SliderSetting("Delay", 2.0, 1.0, 20.0, 1.0);
        this.state = kuzi.obf.j.e.w.IDLE;
        this.stateTicks = 0;
        this.delayTicks = 0;
        this.screenOpen = false;
        this.targetSlot = -1;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.refillTo, this.slot, this.delay};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        long l2 = u ^ 0x757BF9D568F9L;
        long l3 = l2 ^ 0x132061131ED9L;
        Client.a().a(Module.class, this);
        super.d();
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.resetState(objectArray);
    }

    @Override
    public void e() {
        long l2;
        long l3 = l2 = u ^ 0x6007E03408D7L;
        long l4 = l3 ^ 0x29AFB58D93DBL;
        long l5 = l3 ^ 0x65C78F27EF7L;
        Client.a().b(Module.class, this);
        super.e();
        Object[] objectArray = new Object[1];
        objectArray[0] = l4;
        this.closeIfOurs(objectArray);
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l5;
        this.resetState(objectArray2);
    }

    private void resetState(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = u ^ l2;
        this.state = kuzi.obf.j.e.w.IDLE;
        this.stateTicks = 0;
        this.delayTicks = 0;
        this.screenOpen = false;
        this.targetSlot = -1;
    }

    private void closeIfOurs(Object[] objectArray) {
        block2: {
            TotemRefill totemRefill;
            block3: {
                Minecraft minecraft;
                long l2;
                block6: {
                    String string;
                    block4: {
                        String string2;
                        block5: {
                            long l3 = (Long)objectArray[0];
                            l2 = (l3 = u ^ l3) ^ 0x5CBC7838ABB4L;
                            string2 = am.b();
                            totemRefill = this;
                            if (string2 == null) break block2;
                            if (!totemRefill.screenOpen) break block3;
                            minecraft = BaseModule.a;
                            string = string2;
                            if (l3 <= 0L) break block4;
                            if (string == null) break block5;
                            if (!(minecraft.screen instanceof aF)) break block3;
                            minecraft = BaseModule.a;
                        }
                        string = string2;
                    }
                    if (string == null) break block6;
                    if (minecraft.player == null) break block3;
                    minecraft = BaseModule.a;
                }
                minecraft.execute(() -> TotemRefill.lambda$closeIfOurs$0(l2));
            }
            totemRefill = this;
        }
        totemRefill.screenOpen = false;
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public void b() {
        block28: {
            block25: {
                block26: {
                    block27: {
                        v0 = var1_1 = TotemRefill.u ^ 7252627822576L;
                        var3_2 = v0 ^ 33042354709069L;
                        var5_3 = v0 ^ 87071737220348L;
                        var7_4 = v0 ^ 106391616905680L;
                        var9_5 = v0 ^ 93405874386460L;
                        var11_6 = v0 ^ 111698214656069L;
                        var13_7 = v0 ^ 68113095811109L;
                        var15_8 = v0 ^ 36036166088871L;
                        var17_9 = am.b();
                        if (var17_9 == null) break block25;
                        if (BaseModule.a.player == null) break block26;
                        v1 = BaseModule.a;
                        if (var17_9 == null) break block27;
                        if (v1.level == null) break block26;
                        v1 = BaseModule.a;
                    }
                    if (v1.gameMode != null) break block28;
                }
                v2 = new Object[1];
                v2[0] = var7_4;
                this.resetState(v2);
            }
            return;
        }
        waitTicks = Math.max(1, ((Double)this.delay.a()).intValue());
        v3 = this.state.ordinal();
        if (var17_9 == null) ** GOTO lbl35
        switch (v3) {
            case 0: {
                v4 = this;
                if (var17_9 == null) ** GOTO lbl37
                v3 = v4.delayTicks;
lbl35:
                // 2 sources

                if (v3 <= 0) ** GOTO lbl39
                v4 = this;
lbl37:
                // 2 sources

                --v4.delayTicks;
                return;
lbl39:
                // 1 sources

                if (BaseModule.a.screen != null) {
                    return;
                }
                v5 = new Object[1];
                v5[0] = var13_7;
                var19_11 = this.e(v5);
                if (var17_9 != null) {
                    if (var19_11 == -1) {
                        return;
                    }
                    this.targetSlot = var19_11;
                    this.screenOpen = true;
                    BaseModule.a.setScreen((Screen)new aF((Player)BaseModule.a.player));
                    this.stateTicks = waitTicks;
                    this.state = kuzi.obf.j.e.w.OPEN_WAIT;
                }
                if (var17_9 != null) break;
            }
            case 1: {
                v6 = BaseModule.a.screen instanceof aF;
                if (var17_9 != null) {
                    if (v6 == 0) {
                        v7 = new Object[1];
                        v7[0] = var15_8;
                        this.resetWithDelay(v7);
                        return;
                    }
                    v8 = this.stateTicks;
                    v6 = v8;
                    this.stateTicks = v8 - 1;
                }
                if (var17_9 == null) ** GOTO lbl72
                if (v6 > 0) {
                    return;
                }
                v9 = this;
                if (var17_9 == null) ** GOTO lbl96
                v6 = v9.targetSlot;
lbl72:
                // 2 sources

                if (v6 < 0) ** GOTO lbl92
                v10 = this;
                v11 = new Object[1];
                v11[0] = var9_5;
                v12 = this.targetMenuSlot(v11);
                if (var17_9 == null) ** GOTO lbl94
                v13 = new Object[2];
                v13[1] = var11_6;
                v13[0] = v12;
                if (!v10.isSlotEmpty(v13)) ** GOTO lbl92
                v14 = BaseModule.a;
                if (var17_9 == null) ** GOTO lbl88
                if (!v14.player.inventoryMenu.getSlot(this.targetSlot).getItem().is(Items.TOTEM_OF_UNDYING)) ** GOTO lbl92
                v14 = BaseModule.a;
lbl88:
                // 2 sources

                v15 = new Object[1];
                v15[0] = var3_2;
                v14.gameMode.handleInventoryMouseClick(BaseModule.a.player.inventoryMenu.containerId, this.targetSlot, this.swapButton(v15), ClickType.SWAP, (Player)BaseModule.a.player);
lbl92:
                // 4 sources

                v10 = this;
                v12 = waitTicks;
lbl94:
                // 2 sources

                v10.stateTicks = v12;
                v9 = this;
lbl96:
                // 2 sources

                v9.state = kuzi.obf.j.e.w.MOVE_WAIT;
                if (var17_9 != null) break;
            }
            case 2: {
                v16 = BaseModule.a.screen instanceof aF;
                if (var17_9 == null) ** GOTO lbl113
                if (v16 == 0) {
                    v17 = new Object[1];
                    v17[0] = var15_8;
                    this.resetWithDelay(v17);
                    return;
                }
                v18 = this;
                v19 = v18;
                v20 = v18.stateTicks;
                if (var17_9 == null) ** GOTO lbl121
                v16 = v20;
                v19.stateTicks = v20 - 1;
lbl113:
                // 2 sources

                if (v16 > 0) {
                    return;
                }
                v21 = new Object[1];
                v21[0] = var5_3;
                this.closeIfOurs(v21);
                v19 = this;
                v20 = waitTicks;
lbl121:
                // 2 sources

                v19.delayTicks = v20;
                this.state = kuzi.obf.j.e.w.IDLE;
            }
        }
    }

    private void resetWithDelay(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = u ^ l2;
        this.screenOpen = false;
        this.targetSlot = -1;
        this.stateTicks = 0;
        this.delayTicks = Math.max(2, ((Double)this.delay.a()).intValue());
        this.state = kuzi.obf.j.e.w.IDLE;
    }

    private int configuredSlot(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = u ^ l2;
        return ((Double)this.slot.a()).intValue() - 1;
    }

    /*
     * Enabled aggressive block sorting
     */
    private int swapButton(Object[] objectArray) {
        Object object;
        long l2 = (Long)objectArray[0];
        long l3 = (l2 = u ^ l2) ^ 0x70CD7F795D1L;
        String string = am.b();
        TotemRefill totemRefill = this;
        if (string != null) {
            if (totemRefill.refillTo.a() == kuzi.obf.j.e.x.OFFHAND) {
                object = TotemRefill.c("y", (int)20652, (long)(0x4B0616791088D5BL ^ l2));
                return (int)object;
            }
            totemRefill = this;
        }
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l3;
        object = totemRefill.configuredSlot(objectArray2);
        return (int)object;
    }

    private int targetMenuSlot(Object[] objectArray) {
        reference v0;
        block3: {
            long l2;
            long l3;
            block2: {
                l3 = (Long)objectArray[0];
                l2 = (l3 = u ^ l3) ^ 0x4DF22DD14180L;
                try {
                    if (TotemRefill.d("\u00f1", (Object)TotemRefill.d("\u00db", (Object)this, (long)7054855001657433895L, (long)l3), (long)7053809601212151595L, (long)l3) != TotemRefill.d("a", (long)7052774857249933204L, (long)l3)) break block2;
                    v0 = TotemRefill.c("y", (int)15783, (long)(0x32CAA8632A12B404L ^ l3));
                    break block3;
                }
                catch (r r2) {
                    throw TotemRefill.d("\u00d3", (Object)r2, (long)7054664016481921899L, (long)l3);
                }
            }
            Object[] objectArray2 = new Object[1];
            objectArray2[0] = l2;
            v0 = TotemRefill.c("y", (int)7669, (long)(0x52C982C5954D1454L ^ l3)) + TotemRefill.d("\u00f1", (Object)this, (Object)objectArray2, (long)7055485886023013947L, (long)l3);
        }
        return (int)v0;
    }

    private boolean isSlotEmpty(Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        l2 = u ^ l2;
        String string = am.b();
        int n3 = n2;
        if (string != null) {
            if (n3 < 0) {
                return true;
            }
            n3 = BaseModule.a.player.inventoryMenu.getSlot(n2).getItem().isEmpty() ? 1 : 0;
        }
        return n3 != 0;
    }

    /*
     * Exception decompiling
     */
    private int e(Object[] var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * java.lang.UnsupportedOperationException
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.considerAsDoLoopStart(LoopIdentifier.java:383)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.identifyLoops1(LoopIdentifier.java:65)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:681)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private static void lambda$closeIfOurs$0(long l2) {
        block11: {
            MouseHandler OreFeature;
            block10: {
                CallSite callSite;
                CallSite callSite2;
                block8: {
                    block9: {
                        l2 = u ^ l2;
                        callSite2 = TotemRefill.d("\u00d3", (long)-34376824860594973L, (long)l2);
                        try {
                            try {
                                callSite = TotemRefill.d("a", (long)-34288019200020254L, (long)l2);
                                if (callSite2 == null) break block8;
                                if (((Minecraft)callSite).player == null) break block9;
                            }
                            catch (r r2) {
                                throw TotemRefill.d("\u00d3", (Object)r2, (long)-33941911908109045L, (long)l2);
                            }
                            ((Minecraft)TotemRefill.d("a", (long)-34288019200020254L, (long)l2)).player.closeContainer();
                        }
                        catch (r r3) {
                            throw TotemRefill.d("\u00d3", (Object)r3, (long)-33941911908109045L, (long)l2);
                        }
                    }
                    callSite = TotemRefill.d("a", (long)-34288019200020254L, (long)l2);
                }
                try {
                    try {
                        OreFeature = ((Minecraft)callSite).mouseHandler;
                        if (callSite2 == null) break block10;
                        if (OreFeature == null) break block11;
                    }
                    catch (r r4) {
                        throw TotemRefill.d("\u00d3", (Object)r4, (long)-33941911908109045L, (long)l2);
                    }
                    OreFeature = ((Minecraft)TotemRefill.d("a", (long)-34288019200020254L, (long)l2)).mouseHandler;
                }
                catch (r r5) {
                    throw TotemRefill.d("\u00d3", (Object)r5, (long)-33941911908109045L, (long)l2);
                }
            }
            OreFeature.grabMouse();
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block21: {
            block20: {
                block19: {
                    block18: {
                        TotemRefill.u = kuzi.obf.h.b.v.a(9163950260122227552L, 6136586644714645493L, MethodHandles.lookup().lookupClass()).a(96707440918921L);
                        TotemRefill.B = new Object[52];
                        TotemRefill.C = new String[52];
                        TotemRefill.c();
                        TotemRefill.x = new HashMap<K, V>(13);
                        var11 = TotemRefill.u ^ 63595227673926L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[5];
                        var18_4 = 0;
                        var17_5 = "\u0090\u00d0u\u009a\u00d9\u009d\u00db\u008c1\u00bd\u00ec\u00ef\u008a\u00ee\u00d0\u0000\u00cb\\!\u008c\u009d\u00ea\u0086S\u0010\u00fdc?\u00c9\u001f\u0098\u00a7<\u00cfm%\u008e\u00a0\"\u000e\u0085\u0010\u00c4\u00f9\u00a8\u00e05\u00cd>\u00f4\\\u00a4\u00a2\u00c2\u009bgx\u00ac";
                        var19_6 = "\u0090\u00d0u\u009a\u00d9\u009d\u00db\u008c1\u00bd\u00ec\u00ef\u008a\u00ee\u00d0\u0000\u00cb\\!\u008c\u009d\u00ea\u0086S\u0010\u00fdc?\u00c9\u001f\u0098\u00a7<\u00cfm%\u008e\u00a0\"\u000e\u0085\u0010\u00c4\u00f9\u00a8\u00e05\u00cd>\u00f4\\\u00a4\u00a2\u00c2\u009bgx\u00ac".length();
                        var16_7 = 24;
                        var15_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block18;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = TotemRefill.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "8\u00ebP\u00a2\u00f6v\u00d2\u001asY\u0084G\u0098\u009e4hv]\u00d3\u00f1\u0098\u00f4\u00b22\u00d5\tK\u00a0\u00dd>\u00f8>p\u0000o\u0004\u00a1\u00e5\u00f5\u00d8p\u00a1\u0089\u00ccLG_\u00f5\u001e\u00e92P\u0094.4\u00e6\u0086r\u0012\u008f\u00cev\u00f4\u0086E\u001d4k\u00b3b\u00ca\u00b5\u00d7\u00bc\u0080\u00ce\u00143xl\u00db\u00c4\u00ce\u00db\u0099g\u00ba\u00a8\u00fa\u00a4\u00c2\u0094h\u0010\u00f4\u00b11x\u00e1\u00a3x\u00d1`\u0011\u0000\u00d9}\u00e5\u00aalEd\u0089Z\u00ea\u00a2\u009c\u00f6A\u007f5\u00164\u0007\u00e5'@\u00b1/n\u00a2<\u00e9OW\u0016\u00a0,\u0014\u008a\u00ec\u00bb\u0086.\u00e8";
                            var19_6 = "8\u00ebP\u00a2\u00f6v\u00d2\u001asY\u0084G\u0098\u009e4hv]\u00d3\u00f1\u0098\u00f4\u00b22\u00d5\tK\u00a0\u00dd>\u00f8>p\u0000o\u0004\u00a1\u00e5\u00f5\u00d8p\u00a1\u0089\u00ccLG_\u00f5\u001e\u00e92P\u0094.4\u00e6\u0086r\u0012\u008f\u00cev\u00f4\u0086E\u001d4k\u00b3b\u00ca\u00b5\u00d7\u00bc\u0080\u00ce\u00143xl\u00db\u00c4\u00ce\u00db\u0099g\u00ba\u00a8\u00fa\u00a4\u00c2\u0094h\u0010\u00f4\u00b11x\u00e1\u00a3x\u00d1`\u0011\u0000\u00d9}\u00e5\u00aalEd\u0089Z\u00ea\u00a2\u009c\u00f6A\u007f5\u00164\u0007\u00e5'@\u00b1/n\u00a2<\u00e9OW\u0016\u00a0,\u0014\u008a\u00ec\u00bb\u0086.\u00e8".length();
                            var16_7 = 32;
                            var15_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block18;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = TotemRefill.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block19;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                TotemRefill.v = var20_3;
                TotemRefill.w = new String[5];
                TotemRefill.A = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[5];
                var3_13 = 0;
                var4_14 = "M\u00acx\u0085d\u0014-\u0004du\u00c4<rP\u00c27\u00e7W\u00f1\t\u00ae\u001c\u00d78";
                var5_15 = "M\u00acx\u0085d\u0014-\u0004du\u00c4<rP\u00c27\u00e7W\u00f1\t\u00ae\u001c\u00d78".length();
                var2_16 = 0;
                while (true) {
                    var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                    v10 = var6_12;
                    v11 = var3_13++;
                    v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                    v13 = -1;
                    break block20;
                    break;
                }
lbl81:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    var4_14 = "\u0097\u00cf\u00dbIc\u00b4\u00e3\u00ba\u00b1\u00171\u00ef\u00e1DQ\u00e0";
                    var5_15 = "\u0097\u00cf\u00dbIc\u00b4\u00e3\u00ba\u00b1\u00171\u00ef\u00e1DQ\u00e0".length();
                    var2_16 = 0;
                    while (true) {
                        var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                        v10 = var6_12;
                        v11 = var3_13++;
                        v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                        v13 = 0;
                        break block20;
                        break;
                    }
                    break;
                }
lbl94:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    break block21;
                    break;
                }
            }
            var8_18 = v12;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            v14 = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
            switch (v13) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl107:
                // 1 sources

                ** continue;
            }
        }
        TotemRefill.y = var6_12;
        TotemRefill.z = new Integer[5];
    }

    private static r a(r r2) {
        return r2;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x684E;
        if (z[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = y[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])A.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    A.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/e/ai", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            TotemRefill.z[n3] = n4;
        }
        return z[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = TotemRefill.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/e/ai" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (C[n4] != null) {
            return n4;
        }
        Object object = B[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 59;
            case 1 -> 13;
            case 2 -> 51;
            case 3 -> 53;
            case 4 -> 41;
            case 5 -> 47;
            case 6 -> 63;
            case 7 -> 46;
            case 8 -> 32;
            case 9 -> 45;
            case 10 -> 18;
            case 11 -> 16;
            case 12 -> 37;
            case 13 -> 9;
            case 14 -> 35;
            case 15 -> 25;
            case 16 -> 49;
            case 17 -> 60;
            case 18 -> 26;
            case 19 -> 36;
            case 20 -> 33;
            case 21 -> 4;
            case 22 -> 30;
            case 23 -> 17;
            case 24 -> 54;
            case 25 -> 43;
            case 26 -> 48;
            case 27 -> 29;
            case 28 -> 56;
            case 29 -> 52;
            case 30 -> 27;
            case 31 -> 61;
            case 32 -> 28;
            case 33 -> 21;
            case 34 -> 14;
            case 35 -> 62;
            case 36 -> 6;
            case 37 -> 0;
            case 38 -> 22;
            case 39 -> 7;
            case 40 -> 12;
            case 41 -> 42;
            case 42 -> 15;
            case 43 -> 10;
            case 44 -> 5;
            case 45 -> 8;
            case 46 -> 3;
            case 47 -> 19;
            case 48 -> 23;
            case 49 -> 55;
            case 50 -> 40;
            case 51 -> 58;
            case 52 -> 44;
            case 53 -> 24;
            case 54 -> 11;
            case 55 -> 20;
            case 56 -> 38;
            case 57 -> 39;
            case 58 -> 1;
            case 59 -> 50;
            case 60 -> 31;
            case 61 -> 57;
            case 62 -> 2;
            default -> 34;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        TotemRefill.C[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = B;
        B[0] = "i/2q9\u000fb/6q9H";
        objectArray[1] = "dr\u0003EP\u001e\u0011R\bJAQp\\\u0003AE\u000b\u0004";
        objectArray[2] = Integer.TYPE;
        TotemRefill.C[2] = "java/lang/Integer";
        objectArray[3] = "#\u000e\u000e;Sr/\u000e\u001d";
        objectArray[4] = "sqY\u001e\u0014uzqZ\u001e\u0019";
        objectArray[5] = "\"=\u001c##_+=\u001f##";
        objectArray[6] = "SQE+\u001cyX^Td}wSUP>";
        objectArray[7] = " \u001eE\\\u001b#+\u001eA\\\u0002";
        objectArray[8] = "\u000fEW\n\u001e4ze\\\u0005\u000f{\u001bkW\u000e\u000b!o";
        objectArray[9] = Void.TYPE;
        TotemRefill.C[9] = "java/lang/Void";
        objectArray[10] = Boolean.TYPE;
        TotemRefill.C[10] = "java/lang/Boolean";
        objectArray[11] = "&IdYk|-I`Yk?";
        objectArray[12] = "v)S\u0001IM}&BN4Un!K\u0007";
        objectArray[13] = "'\u0002\u001b\bPN,\u0002\u0010";
        objectArray[14] = "\u001d2Tu[0\u001d2C)W?\u0007yC7W*\u0000\b\u0013j\u0006";
        objectArray[15] = "\n\u0003FZe\\\u0003\u0003EZi";
        objectArray[16] = "yB\u0014)Fj\fb\u001f&W%ml\u0014-S\u007f\u0019";
        objectArray[17] = "@\u000bd\u000b%M5+o\u00044\u0002T%d\u000f0X ";
        objectArray[18] = "a\u00110C\u001f\u001b\u00141;L\u000eTu?0G\n\u000e\u0001";
        objectArray[19] = "16s;g\u007f:6{";
        objectArray[20] = "\r\u0002&i\tx\u0006\u0002\"i\u001f";
        objectArray[21] = "S\u0011\u0000d\bu&1\u000bk\u0019:G?\u0000`\u001d`3";
        objectArray[22] = "\t3C\u0013\rD|\u0013H\u001c\u001c\u000b\u001d\u001dC\u0017\u0018Qi";
        objectArray[23] = "D\u0005!`Ib1%*oX-P+!d\\w$";
        objectArray[24] = "\u001e\u0007Oyjvk'Dv{9\n)O}\u007fc~";
        objectArray[25] = "=i9LzU>ln1*;`96W}Bkb.\tC\u0002{w<O?\nz`)1";
        objectArray[26] = "#vMd@C/,\u000fb?)Z[)X\u0002\u0018& \ni\u000eBd&";
        objectArray[27] = "\r{\u000fi;\u0001\u0018v\u0010\"@ 8Y7L\u001f.!Hqv/\u0019\u0012o\u0017c\"\u0006Y";
        objectArray[28] = "E2EZ]_F7\u0012'\u001c1\u00153RU\u001fW\u0000>M\u001e";
        objectArray[29] = "\u0017@)\u0017+h\u0014E~j{\u0006J\u0010&\f,\u007fAK>R\u00128TN=\u0005`{TW$j";
        objectArray[30] = "\u000fl02%g\u001aa/y^@.G\u0003@3n\u001cq5&&c\u0003:";
        objectArray[31] = "TRJ{XSWW\u001d\u0006\u000f=\t\u0002E`_D\u0002Y]>a\u0003\u0017\\^i\u0013@\u0017EG\u0006";
        objectArray[32] = "ElD\u001aIiFi\u0013g\f\u0007Ay]\u000b\u000e{IxJ\u001e";
        objectArray[33] = "[?=\u001dt\u001fZ>i\u0014\u001aM`di\n`\u001e\u001ebl\u000b%$";
        objectArray[34] = "OhAf^pLm\u0016\u001b\u0001\u001e\u001bk\u0016|\f\"\u001baAk";
        objectArray[35] = "c+;\u001b.\u0010`.lfp~7(l\u0001|B7\";\u0016";
        objectArray[36] = "XkV\u0001\u0013c[n\u0001|A\r\u0005;Y\u001a\u0014t\u000e`AD*3\u001beB\u0013Xp\u001b|[|";
        objectArray[37] = "\u0011\u0003\u00043)\u001bC\u000eY)\u0015|9#4\u001cO$\u0011\u0003\u00043)\u001bC\u000eY)";
        objectArray[38] = "\u0014\u001d\u001ak\u0002)\u0017\u0018M\u0016@G\u0016O\nv\u00067D\b\u0003*";
        objectArray[39] = "-\u0013wAy9x\u0004xH\u00065\u0012]s_w#sUe]g_";
        objectArray[40] = "W=\u0011S\u00154\u0002#\u0019\u001dy fj\u0005\u000f\u00182\u001c'\u0002_F";
        objectArray[41] = "vJQV9SuO\u0006+i=+\u001a^M>D AF\u0013\u0000\u0002w]X\u0016pP0T\u0004+";
        objectArray[42] = "%*@9L\u000b&/\u0017D\u0018exzO\"K\u001cs!W|u\\c4E:\tTb#PD";
        objectArray[43] = ",\u007f\u00063>G/zQN})(j\u001f\"yU k\b7";
        objectArray[44] = "3x\u0003\u0013\u0003h0}TnQ\u0006n(\f\b\u0004\u007fes\u0014V:?uf\u0006\u0010F7tq\u0013n";
        objectArray[45] = "32\u0017@n707@=>Y48\u0013P+ej%\u001bXWcj1\u0013Ak=w9\u001b=";
        objectArray[46] = "P<J$I S9\u001dY\u0015NVl@?\t6\u0007\"^a";
        objectArray[47] = "\tg]\b0S\nb\nue=T7R\u00137D_lJM\t\u0004OyX\u000bu\fNnMu";
        objectArray[48] = "c;4$KQoav\"4'\u0010\u001fLQr,^lf \b\u001fo`<b\u000e";
        objectArray[49] = "p%m*5'%;edY>A#:p?d8(ahaZ\u007f=dk6(<=}rY";
        objectArray[50] = "c. \u001c\n4v#?Wq\u0017I\u001f\u00139.\u001bO\u001d^\u0003\u001e,|:8\u0016\u001337";
        Object[] objectArray2 = objectArray;
        objectArray[51] = ".d$xS\u0011-as\u0005\u0013\u007f*q=i\u0014\u0003\"p*|";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = TotemRefill.e(l2, l3);
            object = B[n2];
            try {
                if (!(object instanceof String)) break block2;
                TotemRefill.B[n2] = clazz = Class.forName(C[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = TotemRefill.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = TotemRefill.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = TotemRefill.e(l2, l3);
        Object object = B[n2];
        if (object instanceof String) {
            String string = C[n2];
            int n3 = string.indexOf(8);
            Class clazz = TotemRefill.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = TotemRefill.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = TotemRefill.c(clazz3, string2, clazz2)) != null) {
                    TotemRefill.B[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = TotemRefill.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        TotemRefill.B[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = TotemRefill.f(439525178488915L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = TotemRefill.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = TotemRefill.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = TotemRefill.e(l2, l3);
        Object object = B[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = C[n2];
                int n4 = string2.indexOf(8);
                clazz3 = TotemRefill.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = TotemRefill.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = TotemRefill.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        TotemRefill.B[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = TotemRefill.f(439525178488915L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = TotemRefill.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        TotemRefill.B[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = TotemRefill.f(439525178488915L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == '\u00db' || c2 == '\u00d1' || c2 == 'a' || c2 == '$') {
                field = TotemRefill.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == '\u00db' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == '\u00d1' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == 'a' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = TotemRefill.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == '\u00f1' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == '\u00d3' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = TotemRefill.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/e/ai" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(TotemRefill.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(TotemRefill.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

