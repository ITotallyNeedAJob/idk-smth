// === Kuzi module: AutoSell ===
// Category   : PLAYER
// Description: Automatically sells items through /sell.
// Payload    : a.a.a.j.d.l (verified: True)

package kuzi.modules.player;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.b.l;
import kuzi.obf.h.b.r;
import kuzi.obf.h.b.v;
import kuzi.obf.j.d.b;
import kuzi.obf.j.d.d;
import kuzi.obf.p.am;
import kuzi.obf.p.x_0;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.Player;
import net.minecraft.ChestMenu;
import net.minecraft.ClickType;
import net.minecraft.Item;
import net.minecraft.ItemStack;
import net.minecraft.Identifier;
import net.minecraft.Minecraft;
import net.minecraft.BuiltInRegistries;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class AutoSell
extends BaseModule {
    private static final int m;
    private final l mode;
    private final r items;
    private final SliderSetting delay;
    private final BoolSetting notifications;
    private int cooldown;
    private boolean hasSellableItems;
    private static final long t;
    private static final String[] u;
    private static final String[] v;
    private static final Map w;
    private static final long[] x;
    private static final Integer[] y;
    private static final Map z;
    private static final Object[] A;
    private static final String[] B;

    public AutoSell() {
        long l2 = t ^ 0x214E1A555D94L;
        long l3 = l2 ^ 0x5B1ACEB192B9L;
        super("AutoSell", "Automatically sells items through /sell.", Category.PLAYER);
        this.mode = new l("Mode", kuzi.obf.j.d.d.WHITELIST, d.class);
        this.items = new r("Items", List.of("sea_pickle"));
        this.delay = new SliderSetting("Delay", 1.0, 0.0, 20.0, 1.0);
        this.notifications = new BoolSetting("Notifications", true);
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.mode, this.items, this.delay, this.notifications};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        this.cooldown = 20;
        this.hasSellableItems = false;
    }

    @Override
    public void e() {
        this.hasSellableItems = false;
    }

    @Override
    public void i() {
        block17: {
            int n2;
            ChestMenu currentMenu;
            int n3;
            long l2;
            long l3;
            long l4;
            long l5;
            long l6;
            long l7;
            long l8;
            long l9;
            block23: {
                block22: {
                    AutoSell autoSell;
                    int n4;
                    block21: {
                        block20: {
                            block19: {
                                Minecraft mc;
                                block18: {
                                    long l10;
                                    long l11 = l10 = t ^ 0x2821377B34D9L;
                                    l9 = l11 ^ 0x484744049DDAL;
                                    l8 = l11 ^ 0x341788FCF4D1L;
                                    l7 = l11 ^ 0x2DBC8EDF3EE6L;
                                    l6 = l11 ^ 0x3D2EE616B002L;
                                    l5 = l11 ^ 0x18E218C86568L;
                                    l4 = l11 ^ 0x76EAF2BB4A65L;
                                    l3 = l11 ^ 0x258244FAC5CEL;
                                    l2 = l11 ^ 0x73A3D21D5390L;
                                    n3 = kuzi.obf.j.d.b.b();
                                    mc = BaseModule.a;
                                    if (n3 == 0) break block18;
                                    if (mc.player == null) break block19;
                                    mc = BaseModule.a;
                                }
                                if (mc.gameMode != null) break block20;
                            }
                            return;
                        }
                        n4 = this.cooldown--;
                        if (n3 == 0) break block21;
                        if (n4 > 0) {
                            return;
                        }
                        autoSell = this;
                        if (n3 == 0) break block22;
                        n4 = autoSell.hasSellableItems ? 1 : 0;
                    }
                    if (n4 == 0) break block23;
                    Object[] objectArray = new Object[1];
                    objectArray[0] = l5;
                    am.a(objectArray);
                    this.hasSellableItems = false;
                    autoSell = this;
                }
                autoSell.cooldown = 20;
                return;
            }
            Object[] objectArray = new Object[1];
            objectArray[0] = l8;
            ChestMenu menu = currentMenu = am.a(objectArray);
            if (n3 != 0) {
                if (menu == null) {
                    Object[] objectArray2 = new Object[1];
                    objectArray2[0] = l5;
                    am.a(objectArray2);
                    this.cooldown = 20;
                    return;
                }
                menu = currentMenu;
            }
            Object[] objectArray3 = new Object[2];
            objectArray3[1] = menu;
            objectArray3[0] = l4;
            int n5 = am.c(objectArray3);
            if (n3 != 0) {
                if (n5 < 0) {
                    Object[] objectArray4 = new Object[1];
                    objectArray4[0] = l7;
                    am.b(objectArray4);
                    Object[] objectArray5 = new Object[2];
                    objectArray5[1] = l3;
                    objectArray5[0] = currentMenu;
                    this.hasSellableItems = this.a(objectArray5);
                    AutoSell autoSell = this;
                    if (n3 != 0) {
                        if (!autoSell.hasSellableItems) {
                            Object[] objectArray6 = new Object[1];
                            objectArray6[0] = l6;
                            this.a(objectArray6);
                        }
                        autoSell = this;
                    }
                    autoSell.cooldown = ((Double)this.delay.a()).intValue();
                    return;
                }
                Object[] objectArray7 = new Object[2];
                objectArray7[1] = l9;
                objectArray7[0] = currentMenu;
                n5 = am.a(objectArray7);
            }
            int startSlot = n2 = n5;
            while (startSlot < currentMenu.slots.size()) {
                block24: {
                    block25: {
                        Object delayValue;
                        block26: {
                            ItemStack stack = currentMenu.getSlot(startSlot).getItem();
                            if (n3 == 0) break block17;
                            if (n3 == 0) break block24;
                            if (stack.isEmpty()) break block25;
                            AutoSell autoSell = this;
                            delayValue = stack.getItem();
                            if (n3 == 0) break block26;
                            Object[] objectArray8 = new Object[2];
                            objectArray8[1] = delayValue;
                            objectArray8[0] = l2;
                            if (!autoSell.isAllowedByMode(objectArray8)) break block25;
                            BaseModule.a.gameMode.handleInventoryMouseClick(currentMenu.containerId, startSlot, 0, ClickType.QUICK_MOVE, (Player)BaseModule.a.player);
                            autoSell = this;
                            delayValue = this.delay.a();
                        }
                        autoSell.cooldown = ((Double)delayValue).intValue();
                        return;
                    }
                    ++startSlot;
                }
                if (n3 != 0) continue;
            }
            Object[] objectArray9 = new Object[1];
            objectArray9[0] = l7;
            am.b(objectArray9);
            Object[] objectArray10 = new Object[1];
            objectArray10[0] = l6;
            this.a(objectArray10);
        }
    }

    private void a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = (l2 = t ^ l2) ^ 0x60704E47EEC4L;
        int n2 = kuzi.obf.j.d.b.b();
        AutoSell autoSell = this;
        if (n2 != 0) {
            if (((Boolean)autoSell.q.a()).booleanValue()) {
                Object[] objectArray2 = new Object[2];
                objectArray2[1] = AutoSell.b("p", (int)2884, (long)(0x356E90CF6A9D616DL ^ l2));
                objectArray2[0] = l3;
                x_0.a(objectArray2);
            }
            autoSell = this;
        }
        autoSell.j();
    }

    private boolean a(Object[] objectArray) {
        boolean bl;
        block3: {
            ChestMenu menu = (ChestMenu)objectArray[0];
            long l2 = (Long)objectArray[1];
            long l3 = l2 = t ^ l2;
            long l4 = l3 ^ 0x3672DF670C2CL;
            long l5 = l3 ^ 0xD96497EC266L;
            Object[] objectArray2 = new Object[2];
            objectArray2[1] = l4;
            objectArray2[0] = menu;
            int n2 = am.a(objectArray2);
            int n3 = kuzi.obf.j.d.b.c();
            int n4 = n2;
            while (n4 < menu.slots.size()) {
                int n5;
                block4: {
                    block5: {
                        block6: {
                            boolean matches;
                            block7: {
                                ItemStack stack = menu.getSlot(n4).getItem();
                                n5 = n3;
                                if (l2 <= 0L) break block4;
                                if (n5 != 0) break block5;
                                bl = stack.isEmpty();
                                if (n3 != 0) break block3;
                                if (bl) break block6;
                                Object[] objectArray3 = new Object[2];
                                objectArray3[1] = stack.getItem();
                                objectArray3[0] = l5;
                                matches = this.isAllowedByMode(objectArray3);
                                if (n3 != 0) break block7;
                                if (!matches) break block6;
                                matches = true;
                            }
                            return matches;
                        }
                        ++n4;
                    }
                    n5 = n3;
                }
                if (n5 == 0) continue;
            }
            bl = false;
        }
        return bl;
    }

    private boolean isAllowedByMode(Object[] objectArray) {
        boolean bl;
        long l2 = (Long)objectArray[0];
        Item item = (Item)objectArray[1];
        long l3 = (l2 = t ^ l2) ^ 0x8CD89E5B20DL;
        Object[] objectArray2 = new Object[2];
        objectArray2[1] = item;
        objectArray2[0] = l3;
        boolean bl2 = this.matchesItemFilter(objectArray2);
        int n2 = kuzi.obf.j.d.b.c();
        if (this.mode.a() == kuzi.obf.j.d.d.WHITELIST) {
            bl = bl2;
        } else {
            bl = bl2;
            if (n2 == 0) {
                bl = !bl;
            }
        }
        return bl;
    }

    private boolean matchesItemFilter(Object[] objectArray) {
        int n2;
        block7: {
            long l2 = (Long)objectArray[0];
            Item item = (Item)objectArray[1];
            l2 = t ^ l2;
            Identifier id = BuiltInRegistries.ITEM.getKey((Object)item);
            String path = id.getPath();
            String fullId = id.toString();
            int n3 = kuzi.obf.j.d.b.b();
            Iterator iterator = ((List)this.items.a()).iterator();
            while (iterator.hasNext()) {
                block10: {
                    boolean bl;
                    block8: {
                        block9: {
                            String entry;
                            String entryRef = entry = (String)iterator.next();
                            if (n3 != 0) {
                                if (entryRef == null && l2 > 0L) continue;
                                entryRef = entry.trim().toLowerCase(Locale.ROOT);
                            }
                            String filter = entryRef;
                            bl = filter.equals(path);
                            if (n3 == 0) break block8;
                            if (bl) break block9;
                            bl = filter.equals(fullId);
                            if (n3 == 0) break block8;
                            if (!bl) break block10;
                        }
                        bl = true;
                    }
                    return bl;
                }
                n2 = n3;
                if (l2 > 0L) {
                    if (n2 != 0) continue;
                }
                break block7;
            }
            n2 = 0;
        }
        return n2 != 0;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block16: {
            block15: {
                block14: {
                    block13: {
                        AutoSell.t = kuzi.obf.h.b.v.a(-1531018808810168819L, 3505890134093780187L, MethodHandles.lookup().lookupClass()).a(36834817191928L);
                        AutoSell.A = new Object[55];
                        AutoSell.B = new String[55];
                        AutoSell.c();
                        AutoSell.w = new HashMap<K, V>(13);
                        var11 = AutoSell.t ^ 12444713581663L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[8];
                        var18_4 = 0;
                        var17_5 = "k\u00dc\u008c\u0004x.3\u00ecDl\u0082\u001et\u009d\u0089\u0092\u00b6\u009d\"}\u00dc\u00f3_\u0018\u0000e\u00a9\u00f4\u0017]\u00178)\u008c7\u0016\u00e7\u0087\u00bdO\u00a7\u008e\u00f7\u00f53\u00a7H%\u0001\u0004\u0010I?\u000b\u0086\u0007%U$w\u00b7\u00fe8\u00ba\u0090R\n\u00ff\"\u00144\u00cd\u00fe\u00c4\u0018\u00dc\u0082x\u00bd9\u0010&*\u00a6\\\u00a2\u00d3\u00bfe\u00c9-\u00c5#\u00d2\u00ae?\u008f\u0010\u00f1\u0099\u001d\u007f\u009cR\u00c0\u00eb,gFA9\u009a\u00f5\u00b00\u008d\u0085\u00a6\u0087\u00fb\u00a6L\u0004\u0092\u0087\u000b\u009f?0I|\u00e7\u00a5\u00eb\u0090\u00bb\u001d\u0014%\u0013~fF\u00e5\u008d\u00c1\u00ff\u00f7\u00a9z\u0005,/\u00f3\u00846\u00ec\u0085\u0086\u00e62\u008e\u0098\u0010A\u00f2\u00ea Z\u00c1\u00dd8J\u001a\u00ff\u00bd\u0004\u0084Bz\u00186VO\u00e9?,6\u00b03\u0098\u00ec\u00c7\u009e\u00c3\u000e\u0002\u00faD@4\u00d6\u00a1TV";
                        var19_6 = "k\u00dc\u008c\u0004x.3\u00ecDl\u0082\u001et\u009d\u0089\u0092\u00b6\u009d\"}\u00dc\u00f3_\u0018\u0000e\u00a9\u00f4\u0017]\u00178)\u008c7\u0016\u00e7\u0087\u00bdO\u00a7\u008e\u00f7\u00f53\u00a7H%\u0001\u0004\u0010I?\u000b\u0086\u0007%U$w\u00b7\u00fe8\u00ba\u0090R\n\u00ff\"\u00144\u00cd\u00fe\u00c4\u0018\u00dc\u0082x\u00bd9\u0010&*\u00a6\\\u00a2\u00d3\u00bfe\u00c9-\u00c5#\u00d2\u00ae?\u008f\u0010\u00f1\u0099\u001d\u007f\u009cR\u00c0\u00eb,gFA9\u009a\u00f5\u00b00\u008d\u0085\u00a6\u0087\u00fb\u00a6L\u0004\u0092\u0087\u000b\u009f?0I|\u00e7\u00a5\u00eb\u0090\u00bb\u001d\u0014%\u0013~fF\u00e5\u008d\u00c1\u00ff\u00f7\u00a9z\u0005,/\u00f3\u00846\u00ec\u0085\u0086\u00e62\u008e\u0098\u0010A\u00f2\u00ea Z\u00c1\u00dd8J\u001a\u00ff\u00bd\u0004\u0084Bz\u00186VO\u00e9?,6\u00b03\u0098\u00ec\u00c7\u009e\u00c3\u000e\u0002\u00faD@4\u00d6\u00a1TV".length();
                        var16_7 = 80;
                        var15_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block13;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = AutoSell.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "T\u0097\u00b9x4\u00beaxM^\u00e6\u0096\u00f5\u0095Dt\u00a9a\u00c8\u00da\u00a6\u00f8\u00aa\u00a8\u008b`TY\u008dn\u00cf\u000b \u0011\u00a5'd\u00b5\u0098:^\n\u0093X}e\"\u0097r\u0016\u0098{\u008fw\u008f9T\u0011M*\u000b\u0084\u00d3\u00f8,";
                            var19_6 = "T\u0097\u00b9x4\u00beaxM^\u00e6\u0096\u00f5\u0095Dt\u00a9a\u00c8\u00da\u00a6\u00f8\u00aa\u00a8\u008b`TY\u008dn\u00cf\u000b \u0011\u00a5'd\u00b5\u0098:^\n\u0093X}e\"\u0097r\u0016\u0098{\u008fw\u008f9T\u0011M*\u000b\u0084\u00d3\u00f8,".length();
                            var16_7 = 32;
                            var15_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block13;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = AutoSell.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block14;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                AutoSell.u = var20_3;
                AutoSell.v = new String[8];
                AutoSell.z = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[3];
                var3_13 = 0;
                var4_14 = "X\u00b1\u00a5\u008e\u00b3\u00f3\u009b\u00a9\u0084\u00e7H\u00c3\u00a1oD\u00cd\u0014\u00b4\u00d8!e\u00c1\u00ca{";
                var5_15 = "X\u00b1\u00a5\u008e\u00b3\u00f3\u009b\u00a9\u0084\u00e7H\u00c3\u00a1oD\u00cd\u0014\u00b4\u00d8!e\u00c1\u00ca{".length();
                var2_16 = 0;
                while (true) {
                    break block15;
                    break;
                }
lbl76:
                // 1 sources

                while (true) {
                    var6_12[v10] = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
                    if (var2_16 < var5_15) ** continue;
                    break block16;
                    break;
                }
            }
            var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
            v10 = var3_13++;
            var8_18 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            ** while (true)
        }
        AutoSell.x = var6_12;
        AutoSell.y = new Integer[3];
        AutoSell.m = 20;
    }

    private static kuzi.obf.m.r a(kuzi.obf.m.r r2) {
        return r2;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static String b(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x6EF1;
        if (v[n3] == null) {
            Object[] objectArray;
            try {
                Long l3 = Thread.currentThread().threadId();
                objectArray = (Object[])w.get(l3);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    w.put(l3, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/d/l", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l2 >>> 56);
            for (int i2 = 1; i2 < 8; ++i2) {
                byArray[i2] = (byte)(l2 << i2 * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = u[n3].getBytes("ISO-8859-1");
            AutoSell.v[n3] = AutoSell.b(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return v[n3];
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        String string2 = AutoSell.b(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static CallSite b(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/d/l" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static void c() {
        Object[] objectArray = A;
        A[0] = "wP{)-\u0016fP{j";
        objectArray[1] = "OK\u001a+\"t:k\u0011$3;[e\u001a/7a/";
        objectArray[2] = Integer.TYPE;
        AutoSell.B[2] = "java/lang/Integer";
        objectArray[3] = "jD:Uj+aD?Ug";
        objectArray[4] = "wMYTg\u0018{MJ";
        objectArray[5] = "+Bn)\u0017F Bk)\u0014";
        objectArray[6] = "GS\u001fl/v2s\u0014c>9S}\u001fh:c'";
        objectArray[7] = Boolean.TYPE;
        AutoSell.B[7] = "java/lang/Boolean";
        objectArray[8] = "_\u00166\u0001IYT\u0016>";
        objectArray[9] = "\u001f7L_?A\u00147I_:";
        objectArray[10] = "`\u0017G*I4i\u0017D*D";
        objectArray[11] = "\u00036I\u00163 \n6J\u00161";
        objectArray[12] = "ZB(\u0013G\tSB+\u0013K";
        objectArray[13] = "\u00180K\u0005ew\u00130@";
        objectArray[14] = ".*Ss2\u0015[\nX|#Z:\u0004Sw'\u0000N";
        objectArray[15] = Void.TYPE;
        AutoSell.B[15] = "java/lang/Void";
        objectArray[16] = "\u0017\u0019w\\1\u0013\u001e\u0019t\\\"";
        objectArray[17] = "\t-IY=\r\u0000-JY=";
        objectArray[18] = "(H>(uA#G/g\u0014O(L+=";
        objectArray[19] = "8[c{$e)[z";
        objectArray[20] = "p\u0006uv\u001b1\u0005&~y\n~d(ur\u000e$\u0010";
        objectArray[21] = "kbY\u001d\u001e.kbNA\u0012!q)N_\u00124vX\u001e\u0002C";
        objectArray[22] = "?9Ru7FJ\u0019Yz&\t+\u0017Rq\"S_";
        objectArray[23] = "A\u0010CY-\b40HV<GU>C]8\u001d!";
        objectArray[24] = "_\u0015~3yp*5u<h?K;~7le?";
        objectArray[25] = "F$R\fu\u00183\u0004Y\u0003dWR\nR\b`\r&";
        objectArray[26] = "\u0005l;\t%:\u0005l,U)5\u001f',K) \u0018V~\u0010xd";
        objectArray[27] = "<d\u00118\u001b\nID\u001a7\nE(J\u0011<\u000e\u001f\\";
        objectArray[28] = "!\u0015<HW\rT57GFB5;<LB\u0018A";
        objectArray[29] = "K\u0007-N\u000e\u000b>'&A\u001fD_)-J\u001b\u001e+";
        objectArray[30] = ";~B\u0005sonwVu%Wb-D\u001bs>jp\u0003LLnd`UJ(9b,Bu";
        objectArray[31] = "Bdm\u0017\u000b4\u001dtl\u001da!y!2\u0015\u000bt\u001dv4Y\u001cK";
        objectArray[32] = "_\u0018tR\u0001\u0016\u001e\u0013;\u0012:$!;Xg~::&\u0004\u0014X\u000b\u0019AiUSDY";
        objectArray[33] = "\u0002N\u000fQ>iQ\u001bFSLw8\u0015\u001dG1}U\u0015\u0003Q+";
        objectArray[34] = "N\u001eEP\\Q\u001b\u0017Q \bi\u0017MCN\\\u0000\u001f\u0010\u0004\u0019cP\u0011\u0000R\u001f\u0007\u0007\u0017LE ";
        objectArray[35] = "~]o.lM+T{^:u'\u000ei0l\u001c/S.gS\u001c6\u000e|!bK6Zq^";
        objectArray[36] = "W \u0016\t\u0016w\u0004u_\u000bdwmt\u001b\f\u001alU8\u0001_\r";
        objectArray[37] = "no\t\u0006{k1\u007f\b\f\u0011\u007fU*V\u0004{+1}PHl\u0014";
        objectArray[38] = "`K\u0014mYU3\u001e]o+VZ\u0012\n:M\u0014?\u0016\n~N";
        objectArray[39] = "\u007fhNq V*aZ\u0001vn&;Ho \u0007.f\u000f8\u001f\u000ft{Yet\u001c~b\u000b\u0001";
        objectArray[40] = "q%.7c*\"pg5\u0011;K\"b%\u007fm\"*?b(R\"3b0ncu36=\u0011";
        objectArray[41] = "\u0001\r\n\u0010n2RXC\u0012\u001c$;\nF\u0002ruR\u0002\u001bE%J\u0006\u0006E\u001f%/\u0002\u0006\u0001\u001c\u001c";
        objectArray[42] = "\u0002\u0011\r|\"\u007f\u0012\u001f\u0012%P+h\b\u0001+>/V\u001e\u001e02B";
        objectArray[43] = "pm\u0004m$\u0017#8MoV\u0006JjH\u007f8P#b\u00158oowfKbo\nsf\u000faV";
        objectArray[44] = "\b\u0003%%pt[Vl'\u0002`2\u0004i7l3[\f4p;\f\u000f\bj*;i\u000b\b.)\u0002";
        objectArray[45] = "i \u00102yEk1\u0015q\u0012c\u0010\u0011&NH;i \u00102yEk1\u0015q";
        objectArray[46] = "\u0017Q,C\u0018D\u001f]*RrP{\\s[\u001c\u0006\u0012T.\u001cK9\u0012MsN\r\bEM'Cr";
        objectArray[47] = "\u001dH9h\u007f|R\u0018ea\u0013,,J7jzuO[(jy";
        objectArray[48] = "4\u001dC;mza\u0014WK8BmNE%m+e\u0013\u0002rR+|NP4c||\u001a]K";
        objectArray[49] = "H\u0000*Thn\u0007Pv]\u00045y\u00065\u0007j(HQ5SgW";
        objectArray[50] = "6_4>\u0019\u0007e\n}<k\u0006\f\u0004:l\u0015Dp[~&\n";
        objectArray[51] = "w1e(b9$d,*\u0010(Mn('h=-$l}`Avir9l!<-(1\u0010";
        objectArray[52] = "}\rh#\u0011:.X!!c8GP|:\t}#\u0007zv\u001e";
        objectArray[53] = "i\u0013n*C{&C2#/&X\u001f>?A}1\u0017cx\u0016B1\u000e>*Psf\u000ej'/";
        Object[] objectArray2 = objectArray;
        objectArray[54] = "\u0004wV\u001dNfW\"\u001f\u001f<y>yA\u0013AzBkF\u0019\r";
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = AutoSell.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = AutoSell.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = AutoSell.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = AutoSell.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(AutoSell.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

