// === Kuzi module: FastUse ===
// Category   : PLAYER
// Description: Allows you to use items like the flash
// Payload    : a.a.a.j.e.O (verified: False)

package kuzi.modules.player;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import kuzi.core.Client;
import kuzi.mixin.MixinExposed;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.b.i;
import kuzi.obf.h.b.k;
import kuzi.obf.j.e.am;
import kuzi.obf.m.r;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import net.minecraft.BlockItem;
import net.minecraft.ItemStack;
import net.minecraft.Items;
import net.minecraft.Minecraft;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class FastUse
extends BaseModule {
    private final k delaySetting;
    private final BoolSetting onlyXP;
    private final BoolSetting onlyBlocks;
    private final i blacklist1;
    private final i blacklist2;
    private final i blacklist3;
    private final i blacklist4;
    private final i blacklist5;
    private static final long u = 51011824245396L;
    private static final Object[] B = new Object[]{"s\u0019\u0000_\u0015\u000fx\u0019\u0004_;", "Kl\u001d|\u00135Gl\u000e", "ed\b\u000f|and\f\u000f|\"", ",\f9\u000b'\u000f'\u0003(DZ\u00174\u0004!\r", "e\r,>;\u0003n\r'", "J\u007f}\"\u000b]J\u007fj~\u0007RP4j`\u0007GWE:=V", "lD\rC?\u0001eD\u000eC5", "\n23W\"0\u007f\u00128X3\u007f\u001e\u001c3S7%j", Double.TYPE, "\u0000\u0002v]\rqu\"}R\u001c>\u0014,vY\u0018d`", Boolean.TYPE, "KuN 2\bBuM :", "D\u001cr\"`\u00011<y-qNP2r&u\u0014$", "\u007fg\u001dE^|\u007fg\n\u0019Rse,\n\u0007Rfb]X\\\n'", "\u0018^x-\u001b4\u0011^{-\u001b", "\u0019M\"(5\u000e\u0012B3gT\u0000\u0019I7=", "P>d~;\u0012Y>g~9", "\u007fdA\u001f.EtdI", "L1I2N39\u0011B=_|X\u001fI6[&,", Void.TYPE, "4\u001az|\u001581\u0002:il\u0006\u001a(V]6^4\u001az|\u001581\u0002:i", "?k!\u0003C\u000f.)toW~m+}\u0010N\u0019k{,T>Gi&2\u001fYA9wvo", "\u001c\u0003-TS8^\u00147J!1%@2KX\"J\u0001nW][", "T\u001a-JEzR\u0005\"X>rnQd\u0004\u0000\u007fP\u0005d\u0006\u0002", "]l-x'<L.x\u0014!M\t`zz=}Nj'-", "\"\u0012y>qA3P,Rt0v\u001e.<k\u00001\u0014sk", "FJq\u0007G\u0011\u0001@,P HyP7RKX\u0017W%\u0003R!H\u000b+\u000bO\u0010\u0002Zq\u0015 ", "HN\u0006t\\R\u001bT\u001b22\ttC\u00035Y\u001b\u001aD\u0011d@bJ\u0013\u0001d]\u000b\nQ\u001dn2", "\u0014\"qL\u0017C\u0005`$ \u00032\u0014\"&K\u0013\\\u00130wRj\rD1gZ\u0003\u000bEa# ", "#&AO\u0016Q2d\u0014#\u0012 w*\u0016M\f\u00100 K\u001a", "K.g\u0001 O\u001d|7\u000eN\u001e\"\u007ft\u001f+\u0015\u001fh|\u0005-w", "R\u000bx,]_CI-@G.S\u0010(~EQ[\u0012%1", "v\u0001)lg_gC|\u0000|.w\u001ay>\u007fQ\u007f\u0018tq", "/IV;`a>\u000b\u0003Wg\u0010{E\u00019z <O\\n", "i\r\u001a\u0000$Co\u0012\u0015\u0012_FS\u0016VJ4[=\u0011D\u001b-\"?\u0014\u0017\u0012dK1B\u0014\u0000_", "Iqh\u007f\u0003^X3=\u0013\u001b/\u001ej|i\u0010\u001fMpa/", "\u001ep-\u0011\u0001R\u000f2x}\u0000#J|z\u0013\u001b\u0013\rv'D"};
    private static final String[] C = new String[]{null, null, null, null, null, null, null, null, "java/lang/Double", null, "java/lang/Boolean", null, null, null, null, null, null, null, null, "java/lang/Void", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null};

    public FastUse() {
        long l2 = u ^ 0xD3D4AC81373L;
        long l3 = l2 ^ 0x2BB5C1C52F2L;
        super("FastUse", "Allows you to use items like the flash", Category.PLAYER);
        this.delaySetting = new k("Delay (ticks)", 1.0, 8.0, 1.0, 2.0, 4.0);
        this.onlyXP = new BoolSetting("Only XP", false);
        this.onlyBlocks = new BoolSetting("Only Blocks", false);
        this.blacklist1 = new i("Blacklist 1", Items.AIR);
        this.blacklist2 = new i("Blacklist 2", Items.AIR);
        this.blacklist3 = new i("Blacklist 3", Items.AIR);
        this.blacklist4 = new i("Blacklist 4", Items.AIR);
        this.blacklist5 = new i("Blacklist 5", Items.AIR);
        Setting[] settingArray = new Setting[]{this.delaySetting, this.onlyXP, this.onlyBlocks, this.blacklist1, this.blacklist2, this.blacklist3, this.blacklist4, this.blacklist5};
        Object[] objectArray = new Object[2];
        objectArray[1] = settingArray;
        objectArray[0] = l3;
        this.l(objectArray);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @MixinExposed
    public static FastUse a() {
        String string = am.b();
        kuzi.obf.e.i client = Client.a;
        if (string != null) {
            if (client == null) return null;
            client = Client.a;
        }
        FastUse fastUse = (FastUse)client.a(FastUse.class);
        return fastUse;
    }

    @MixinExposed
    public int a() {
        String string;
        long l2;
        long l3;
        block7: {
            block6: {
                Minecraft minecraft;
                block5: {
                    long l4;
                    long l5 = l4 = u ^ 0x3782E48C31FEL;
                    l3 = l5 ^ 0x61C9C9218F7EL;
                    l2 = l5 ^ 0xA3B6DCD4D8AL;
                    string = am.b();
                    minecraft = BaseModule.a;
                    if (string == null) break block5;
                    if (minecraft == null) break block6;
                    minecraft = BaseModule.a;
                }
                if (minecraft.player != null) break block7;
            }
            return -1;
        }
        Object[] objectArray = new Object[2];
        objectArray[1] = BaseModule.a.player.getMainHandItem();
        objectArray[0] = l3;
        int n2 = this.a(objectArray);
        if (string != null) {
            if (n2 == 0) {
                return -1;
            }
            Object[] objectArray2 = new Object[1];
            objectArray2[0] = l2;
            n2 = Math.max(1, (int)Math.round(this.delaySetting.c(objectArray2)));
        }
        return n2;
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private boolean a(Object[] var1_1) {
        block33: {
            block31: {
                block32: {
                    block30: {
                        block28: {
                            block29: {
                                block27: {
                                    block25: {
                                        block26: {
                                            block24: {
                                                block22: {
                                                    block23: {
                                                        var3_2 = (Long)var1_1[0];
                                                        var2_3 = (ItemStack)var1_1[1];
                                                        var5_4 = (var3_2 = FastUse.u ^ var3_2) ^ 50027266234255L;
                                                        var7_5 = am.b();
                                                        v0 = var2_3;
                                                        if (var7_5 != null) {
                                                            if (v0.isEmpty()) {
                                                                return false;
                                                            }
                                                            v0 = var2_3;
                                                        }
                                                        v1 /* !! */  = var8_6 = v0.getItem();
                                                        v2 = new Object[1];
                                                        v2[0] = var5_4;
                                                        v3 = this.blacklist1.a(v2);
                                                        if (var7_5 == null) break block22;
                                                        if (v1 /* !! */  != v3) break block23;
                                                        v1 /* !! */  = var8_6;
                                                        v3 = Items.AIR;
                                                        v4 = var7_5;
                                                        if (var3_2 <= 0L) break block24;
                                                        if (v4 != null) {
                                                            if (v1 /* !! */  != v3) {
                                                                return false;
                                                            } else {
                                                                ** GOTO lbl27
                                                            }
                                                        }
                                                        break block22;
                                                    }
                                                    v1 /* !! */  = var8_6;
                                                    v5 = new Object[1];
                                                    v5[0] = var5_4;
                                                    v3 = this.blacklist2.a(v5);
                                                }
                                                v4 = var7_5;
                                            }
                                            if (v4 == null) break block25;
                                            if (v1 /* !! */  != v3) break block26;
                                            v1 /* !! */  = var8_6;
                                            v3 = Items.AIR;
                                            v6 = var7_5;
                                            if (var3_2 <= 0L) break block27;
                                            if (v6 != null) {
                                                if (v1 /* !! */  != v3) {
                                                    return false;
                                                } else {
                                                    ** GOTO lbl46
                                                }
                                            }
                                            break block25;
                                        }
                                        v1 /* !! */  = var8_6;
                                        v7 = new Object[1];
                                        v7[0] = var5_4;
                                        v3 = this.blacklist3.a(v7);
                                    }
                                    v6 = var7_5;
                                }
                                if (v6 == null) break block28;
                                if (v1 /* !! */  != v3) break block29;
                                v1 /* !! */  = var8_6;
                                v3 = Items.AIR;
                                v8 = var7_5;
                                if (var3_2 < 0L) break block30;
                                if (v8 != null) {
                                    if (v1 /* !! */  != v3) {
                                        return false;
                                    } else {
                                        ** GOTO lbl65
                                    }
                                }
                                break block28;
                            }
                            v1 /* !! */  = var8_6;
                            v9 = new Object[1];
                            v9[0] = var5_4;
                            v3 = this.blacklist4.a(v9);
                        }
                        v8 = var7_5;
                    }
                    if (v8 == null) break block31;
                    if (v1 /* !! */  != v3) break block32;
                    v1 /* !! */  = var8_6;
                    v3 = Items.AIR;
                    if (var3_2 >= 0L && var7_5 != null) {
                        if (v1 /* !! */  != v3) {
                            return false;
                        } else {
                            ** GOTO lbl82
                        }
                    }
                    break block31;
                }
                v1 /* !! */  = var8_6;
                if (var7_5 == null) break block33;
                v10 = new Object[1];
                v10[0] = var5_4;
                v3 = this.blacklist5.a(v10);
            }
            if (v1 /* !! */  == v3) {
                v1 /* !! */  = var8_6;
                if (var3_2 > 0L && var7_5 != null) {
                    if (v1 /* !! */  != Items.AIR) {
                        return false;
                    } else {
                        ** GOTO lbl-1000
                    }
                }
            } else lbl-1000:
            // 3 sources

            {
                v1 /* !! */  = this.onlyXP.a();
            }
        }
        v11 = (Boolean)v1 /* !! */ ;
        v12 = var7_5;
        if (var3_2 > 0L) {
            if (v12 != null) {
                if (v11) {
                    return var2_3.is(Items.EXPERIENCE_BOTTLE);
                }
                v11 = (Boolean)this.onlyBlocks.a();
            }
            v12 = var7_5;
        }
        if (v12 != null) {
            if (v11) {
                return var2_3.getItem() instanceof BlockItem;
            }
            v11 = true;
        }
        return v11;
    }

    private static r a(r r2) {
        return r2;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = FastUse.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = FastUse.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = FastUse.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = FastUse.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }
}

