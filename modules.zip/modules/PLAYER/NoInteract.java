// === Kuzi module: NoInteract ===
// Category   : PLAYER
// Description: Prevents you from certain actions
// Payload    : a.a.a.j.c.R (verified: True)

package kuzi.modules.player;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.g.a.a;
import kuzi.obf.g.a.c;
import kuzi.obf.g.a.d;
import kuzi.obf.g.a.m;
import kuzi.obf.g.a.o;
import kuzi.obf.p.r;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import net.minecraft.Items;
import net.minecraft.Blocks;
import net.minecraft.HitResult;
import net.minecraft.BlockHitResult;

public final class NoInteract
extends BaseModule
implements kuzi.obf.g.a.r,
m,
o {
    private final BoolSetting doubleGlowstone;
    private final BoolSetting obiPunch;
    private final BoolSetting eChestClick;
    private final BoolSetting anvilClick;
    private static final long q = 4264091001101L;
    private static final Object[] u = new Object[]{"c\u0005n\tb~h\u0005e", "_;$%\u0016__;3y\u001aPEp3g\u001aEB\u0001c:K", "tc\u0000=sc\u007fc\u0002=@", "`_\u001d\u0017&Ki_\u001e\u0017$", "o&\n33\u001e~&\u0019", "\u0007'K1S\rr\u0007@>BB\u0013\tK5F\u0018g", Boolean.TYPE, "I\u0004\n|oK<$\u0001s~\u0004]*\nxz^)", "\u0017J|t~o\u001bJo", "\u00115 \u001dx@\u00185#\u001dx", "ib}TGAbml\u001b&OifhA", "Qt\u000bCbiZt\tCm", Integer.TYPE, "C57e1\u0004H5?", "\u0002\u001aS\t-\u0014w:X\u0006<[\u00164S\r8\u0001b", Void.TYPE, "wE'\u001b@\u00064\u001f2\u0001 \u001aN\u001c1\u000f\u0011\u0003'\u00164Y\\", "1\u001cQ\\T``\u001ePJ(FD;j}r\u001e1\u001cQ\\T``\u001ePJ", "HS1\u0017|\u0000\u0015\u0006&vwcP\u0015\"\u001a.\u001b_Q,", "]\u001bj\u000e8G\u001eA\u007f\u0014XEdB|\u001aiB\rHyL$", "aU\u001bf=1\"\u000f\u000e|],X\f\rrl41\u0006\b$!", "$lXS\rOg6MIm\\\u001d2XH\\G$cZ\u0015\u00105 \u007fH\u0019\u001f\fq}\u0015Um", "e\u0003_=V)'\u0019\r9({[[\u000f=\u0011l6UUrK\u0012", "HHQ\u0005/\n\u0013\u0001\n\u0006F\u0018w\nB[w\u0011\u000eG\u0000[!s", "MjD\fTnOb]\f)\u007fvj]DG/\r=\u0013G\u0018\u0014J!PWP-\r:^\u0002)", "Pg\u000bd[S\u0013=\u001e~;Li>\u001dp\nV\u00004\u0018&G", "\u000e$\u00175+|Sq\u0000T-\u001fZo\u0013:rd\r!\u0010eIv\u0011\"\u0010+4e\u0014t\rT", "J\u000bymc3H\u0003`m\u001e q\u000b`%pr\n\\.&/IM@m6gp\n[cc\u001e"};
    private static final String[] v = new String[]{null, null, null, null, null, null, "java/lang/Boolean", null, null, null, null, null, "java/lang/Integer", null, null, "java/lang/Void", null, null, null, null, null, null, null, null, null, null, null, null};

    public NoInteract() {
        long l2 = q ^ 0x618E5071833L;
        long l3 = l2 ^ 0x241B21DBA22BL;
        super("NoInteract", "Prevents you from certain actions", Category.PLAYER);
        this.doubleGlowstone = new BoolSetting("Double Glowstone", false);
        this.obiPunch = new BoolSetting("Obi Punch", false);
        this.eChestClick = new BoolSetting("E-chest click", false);
        this.anvilClick = new BoolSetting("Anvil click", false);
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.doubleGlowstone, this.obiPunch, this.eChestClick, this.anvilClick};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        Client.c.a(o.class, this);
        Client.c.a(m.class, this);
        Client.c.a(kuzi.obf.g.a.r.class, this);
        super.d();
    }

    @Override
    public void e() {
        Client.c.b(o.class, this);
        Client.c.b(m.class, this);
        Client.c.b(kuzi.obf.g.a.r.class, this);
        super.e();
    }

    @Override
    public void a(a event) {
        block2: {
            boolean shouldCancel;
            block4: {
                int guard;
                block3: {
                    HitResult hitResult;
                    long l2;
                    block1: {
                        long l3 = q ^ 0x47A3776C85B1L;
                        l2 = l3 ^ 0x1A3C3F007E78L;
                        HitResult rawHit = BaseModule.a.hitResult;
                        guard = 66;
                        hitResult = rawHit;
                        if (guard == 0) break block1;
                        if (!(hitResult instanceof BlockHitResult)) break block2;
                        hitResult = rawHit;
                    }
                    BlockHitResult blockHit = (BlockHitResult)hitResult;
                    Object[] objectArray = new Object[3];
                    objectArray[2] = l2;
                    objectArray[1] = Blocks.OBSIDIAN;
                    objectArray[0] = blockHit.getBlockPos();
                    shouldCancel = r.c(objectArray);
                    if (guard == 0) break block3;
                    if (!shouldCancel) break block2;
                    shouldCancel = (Boolean)this.obiPunch.a();
                }
                if (guard == 0) break block4;
                if (!shouldCancel) break block2;
                shouldCancel = BaseModule.a.player.isHolding(Items.END_CRYSTAL);
            }
            if (shouldCancel) {
                event.a();
            }
        }
    }

    @Override
    public void a(c event) {
        block2: {
            boolean shouldCancel;
            block4: {
                int guard;
                block3: {
                    HitResult hitResult;
                    long l2;
                    block1: {
                        long l3 = q ^ 0x373D00E6797EL;
                        l2 = l3 ^ 0x6AA2488A82B7L;
                        HitResult rawHit = BaseModule.a.hitResult;
                        guard = 66;
                        hitResult = rawHit;
                        if (guard == 0) break block1;
                        if (!(hitResult instanceof BlockHitResult)) break block2;
                        hitResult = rawHit;
                    }
                    BlockHitResult blockHit = (BlockHitResult)hitResult;
                    Object[] objectArray = new Object[3];
                    objectArray[2] = l2;
                    objectArray[1] = Blocks.OBSIDIAN;
                    objectArray[0] = blockHit.getBlockPos();
                    shouldCancel = r.c(objectArray);
                    if (guard == 0) break block3;
                    if (!shouldCancel) break block2;
                    shouldCancel = (Boolean)this.obiPunch.a();
                }
                if (guard == 0) break block4;
                if (!shouldCancel) break block2;
                shouldCancel = BaseModule.a.player.isHolding(Items.END_CRYSTAL);
            }
            if (shouldCancel) {
                event.a();
            }
        }
    }

    @Override
    public void a(d event) {
        block12: {
            boolean shouldCancel;
            block17: {
                block18: {
                    BlockHitResult blockHit;
                    int guard;
                    long l2;
                    block15: {
                        block16: {
                            block13: {
                                block14: {
                                    HitResult hitResult;
                                    long l3;
                                    block11: {
                                        long l4;
                                        long l5 = l4 = q ^ 0x14CD97F1A6DEL;
                                        l3 = l5 ^ 0x23F87B9EE8E1L;
                                        l2 = l5 ^ 0x4952DF9D5D17L;
                                        HitResult rawHit = BaseModule.a.hitResult;
                                        guard = 66;
                                        hitResult = rawHit;
                                        if (guard == 0) break block11;
                                        if (!(hitResult instanceof BlockHitResult)) break block12;
                                        hitResult = rawHit;
                                    }
                                    blockHit = (BlockHitResult)hitResult;
                                    Object[] objectArray = new Object[2];
                                    objectArray[1] = blockHit.getBlockPos();
                                    objectArray[0] = l3;
                                    shouldCancel = r.a(objectArray);
                                    if (guard == 0) break block13;
                                    if (!shouldCancel) break block14;
                                    shouldCancel = (Boolean)this.doubleGlowstone.a();
                                    if (guard == 0) break block13;
                                    if (!shouldCancel) break block14;
                                    shouldCancel = BaseModule.a.player.isHolding(Items.GLOWSTONE);
                                    if (guard == 0) break block13;
                                    if (shouldCancel) {
                                        event.a();
                                    }
                                }
                                Object[] objectArray = new Object[3];
                                objectArray[2] = l2;
                                objectArray[1] = Blocks.ENDER_CHEST;
                                objectArray[0] = blockHit.getBlockPos();
                                shouldCancel = r.c(objectArray);
                            }
                            if (guard == 0) break block15;
                            if (!shouldCancel) break block16;
                            shouldCancel = (Boolean)this.eChestClick.a();
                            if (guard == 0) break block15;
                            if (shouldCancel) {
                                event.a();
                            }
                        }
                        Object[] objectArray = new Object[3];
                        objectArray[2] = l2;
                        objectArray[1] = Blocks.ANVIL;
                        objectArray[0] = blockHit.getBlockPos();
                        shouldCancel = r.c(objectArray);
                    }
                    if (guard == 0) break block17;
                    if (shouldCancel) break block18;
                    Object[] objectArray = new Object[3];
                    objectArray[2] = l2;
                    objectArray[1] = Blocks.CHIPPED_ANVIL;
                    objectArray[0] = blockHit.getBlockPos();
                    shouldCancel = r.c(objectArray);
                    if (guard == 0) break block17;
                    if (shouldCancel) break block18;
                    Object[] objectArray2 = new Object[3];
                    objectArray2[2] = l2;
                    objectArray2[1] = Blocks.DAMAGED_ANVIL;
                    objectArray2[0] = blockHit.getBlockPos();
                    shouldCancel = r.c(objectArray2);
                    if (guard == 0) break block17;
                    if (!shouldCancel) break block12;
                }
                shouldCancel = (Boolean)this.anvilClick.a();
            }
            if (shouldCancel) {
                event.a();
            }
        }
    }

    private static kuzi.obf.m.r a(kuzi.obf.m.r r2) {
        return r2;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = NoInteract.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = NoInteract.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = NoInteract.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = NoInteract.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }
}

