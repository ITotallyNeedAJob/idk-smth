// === Kuzi module: NoPause ===
// Category   : PLAYER
// Description: Alt TAB Without Pausing
// Payload    : a.a.a.j.e.W (verified: False)

package kuzi.modules.player;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import kuzi.core.Client;
import kuzi.mixin.MixinExposed;
import kuzi.module.BaseModule;
import kuzi.module.Category;

public class NoPause
extends BaseModule {
    private static final Object[] q = new Object[]{"O^\u000f6\u0015|D^\u0007", "M 2^,3F/#\u0011M=M$'K", "B]\\S\u001e\u001bMQ\u00118,4b`.bt\u0019G\u000e\bR\u001f\u0016KC"};

    public NoPause() {
        super("NoPause", "Alt TAB Without Pausing", Category.PLAYER);
    }

    @MixinExposed
    public static NoPause a() {
        return (NoPause)Client.a.a(NoPause.class);
    }

    private static Field findDeclaredField(Class targetClass, String fieldName, Class fieldType) {
        for (Field field : targetClass.getDeclaredFields()) {
            if (!field.getName().equals(fieldName) || field.getType() != fieldType) continue;
            return field;
        }
        return null;
    }

    private static Field findFieldInClassOrInterfaces(Class targetClass, String fieldName, Class fieldType) {
        Field field = NoPause.findDeclaredField(targetClass, fieldName, fieldType);
        if (field != null) {
            return field;
        }
        Class<?>[] interfaces = targetClass.getInterfaces();
        if (interfaces != null) {
            for (int index = 0; index < interfaces.length; ++index) {
                field = NoPause.findFieldInClassOrInterfaces(interfaces[index], fieldName, fieldType);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method findDeclaredMethod(Class targetClass, String methodName, Class returnType, int parameterCount, Class[] parameterTypes) {
        block0: for (Method method : targetClass.getDeclaredMethods()) {
            Class<?>[] declaredParameterTypes;
            if (!method.getName().equals(methodName) || method.getReturnType() != returnType || (declaredParameterTypes = method.getParameterTypes()).length != parameterCount) continue;
            for (int index = 0; index < parameterCount; ++index) {
                if (declaredParameterTypes[index] != parameterTypes[index]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method findMethodInClassOrInterfaces(Class targetClass, String methodName, Class returnType, int parameterCount, Class[] parameterTypes) {
        Method method = NoPause.findDeclaredMethod(targetClass, methodName, returnType, parameterCount, parameterTypes);
        if (method != null) {
            return method;
        }
        Class<?>[] interfaces = targetClass.getInterfaces();
        if (interfaces != null) {
            for (int index = 0; index < interfaces.length; ++index) {
                method = NoPause.findMethodInClassOrInterfaces(interfaces[index], methodName, returnType, parameterCount, parameterTypes);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }
}

