// === Kuzi module: Macros ===
// Category   : PLAYER
// Description: Multi-step macros: bind a key to a list of item, chat, wait, key and toggle steps.
// Payload    : a.a.a.j.e.U (verified: True)

package kuzi.modules.player;

import a.a.a.h.V;
import a.a.a.j.e.n;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.Reader;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.module.Module;
import kuzi.obf.h.b.v;
import kuzi.obf.j.e.a;
import kuzi.obf.j.e.am;
import kuzi.obf.j.e.an;
import kuzi.obf.j.e.m;
import kuzi.obf.p.L;
import kuzi.settings.ButtonSetting;
import kuzi.settings.Setting;
import net.minecraft.Item;
import net.minecraft.ItemStack;
import net.minecraft.KeyMapping;
import net.minecraft.Minecraft;
import net.minecraft.Screen;
import net.minecraft.LocalPlayer;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class Macros
extends BaseModule
implements Module {
    private static final Gson m;
    private final List macroList;
    private final Set toggledMacros;
    private am activeMacro;
    private int stepIndex;
    private int r;
    private long s;
    private long t;
    private KeyMapping heldKeyMapping;
    private int previousSlot;
    private static final long w;
    private static final String[] x;
    private static final String[] y;
    private static final Map z;
    private static final long[] A;
    private static final Integer[] B;
    private static final Map C;
    private static final long D;
    private static final Object[] E;
    private static final String[] F;

    public Macros() {
        long l2;
        long l3 = l2 = w ^ 0xD31B1D020EEL;
        long l4 = l3 ^ 0xFEE4DB2632CL;
        long l5 = l3 ^ 0x4D40111A6B73L;
        long l6 = l3 ^ 0x7715A219A933L;
        super("Macros", "Multi-step macros: bind a key to a list of item, chat, wait, key and toggle steps.", Category.PLAYER);
        this.macroList = new ArrayList();
        this.toggledMacros = new HashSet();
        this.activeMacro = null;
        this.stepIndex = 0;
        this.r = 0;
        this.s = 0L;
        this.t = 0L;
        this.heldKeyMapping = null;
        this.previousSlot = -1;
        Object[] objectArray = new Object[1];
        objectArray[0] = l4;
        this.s(objectArray);
        Object[] objectArray2 = new Object[2];
        objectArray2[1] = new Setting[]{new ButtonSetting("Edit Macros", () -> this.a(l5))};
        objectArray2[0] = l6;
        this.l(objectArray2);
    }

    private void a(long l2) {
        block5: {
            Minecraft mc;
            Minecraft candidate;
            block4: {
                l2 = w ^ l2;
                String string = am.b();
                Minecraft instance = BaseModule.a;
                if (string != null) {
                    instance = instance != null ? BaseModule.a : Minecraft.getInstance();
                }
                mc = candidate = instance;
                if (string == null) break block4;
                if (mc == null) break block5;
                mc = candidate;
            }
            mc.execute(() -> Macros.lambda$openEditor$0(candidate));
        }
    }

    public List b(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = w ^ l2;
        return Macros.d("\u00e7", (Object)this, (long)5624275211349512840L, (long)l2);
    }

    @Override
    public void d() {
        long l2 = w ^ 0x304AA4C2B505L;
        long l3 = l2 ^ 0x64DFCF9F709CL;
        Client.a().a(Module.class, this);
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.c(objectArray);
        super.d();
    }

    @Override
    public void e() {
        long l2 = w ^ 0x2536BD23D52BL;
        long l3 = l2 ^ 0x71A3D67E10B2L;
        Client.a().b(Module.class, this);
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.c(objectArray);
        super.e();
    }

    @Override
    public void h() {
        long l2 = w ^ 0x7ADBBD566E35L;
        long l3 = l2 ^ 0x2E4ED60BABACL;
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.c(objectArray);
        super.h();
    }

    private void c(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = (l2 = w ^ l2) ^ 0x10B974315B16L;
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l3;
        this.f(objectArray2);
        this.toggledMacros.clear();
    }

    private void f(Object[] objectArray) {
        block5: {
            block2: {
                Macros macros;
                block4: {
                    block3: {
                        LocalPlayer mc7462;
                        block7: {
                            Minecraft mc3102;
                            String string;
                            block6: {
                                long l2 = (Long)objectArray[0];
                                long l3 = (l2 = w ^ l2) ^ 0x1AEAEFDFFAD4L;
                                String string2 = am.b();
                                Object[] objectArray2 = new Object[1];
                                objectArray2[0] = l3;
                                this.m(objectArray2);
                                string = string2;
                                macros = this;
                                if (string == null) break block2;
                                if (macros.p == null) break block3;
                                macros = this;
                                if (string == null) break block2;
                                if (l2 <= 0L) break block4;
                                if (macros.v < 0) break block3;
                                if (l2 <= 0L) break block5;
                                macros = this;
                                if (string == null) break block2;
                                if (l2 <= 0L) break block4;
                                if (macros.v >= Macros.c("n", (int)20678, (long)(0x53FE2F1439BE20FDL ^ l2))) break block3;
                                mc3102 = BaseModule.a;
                                if (l2 < 0L || string == null) break block6;
                                if (mc3102 == null) break block3;
                                mc3102 = BaseModule.a;
                            }
                            mc7462 = mc3102.player;
                            if (string == null) break block7;
                            if (mc7462 == null) break block3;
                            mc7462 = BaseModule.a.player;
                        }
                        mc7462.getInventory().setSelectedSlot(this.previousSlot);
                    }
                    this.activeMacro = null;
                    this.stepIndex = 0;
                    Macros macros2 = this;
                }
                macros2.r = 0;
                macros = this;
            }
            macros.previousSlot = -1;
        }
    }

    private void m(Object[] objectArray) {
        block3: {
            KeyMapping mc3042;
            block2: {
                long l2 = (Long)objectArray[0];
                l2 = w ^ l2;
                String string = am.b();
                mc3042 = this.heldKeyMapping;
                if (string == null) break block2;
                if (mc3042 == null) break block3;
                mc3042 = this.heldKeyMapping;
            }
            mc3042.setDown(false);
            this.heldKeyMapping = null;
        }
    }

    @Override
    public void b() {
        block13: {
            String string;
            long l2;
            long l3;
            int n2;
            int n3;
            int n4;
            block17: {
                block14: {
                    long l4;
                    block15: {
                        Minecraft mc3102;
                        block16: {
                            long l5;
                            long l6 = l5 = w ^ 0x43A9FF59CA0CL;
                            long l7 = l6 ^ 0x42BC7633A0F5L;
                            n4 = (int)(l7 >>> 32);
                            n3 = (int)(l7 << 32 >>> 48);
                            n2 = (int)(l7 << 48 >>> 48);
                            l3 = l6 ^ 0x7EDF828D8439L;
                            l2 = l6 ^ 0x70DC7217261EL;
                            l4 = l6 ^ 0x173C94040F95L;
                            string = am.b();
                            if (string == null) break block14;
                            if (BaseModule.a.player == null) break block15;
                            mc3102 = BaseModule.a;
                            if (string == null) break block16;
                            if (mc3102.level == null) break block15;
                            mc3102 = BaseModule.a;
                        }
                        if (mc3102.gameMode != null) break block17;
                    }
                    Object[] objectArray = new Object[1];
                    objectArray[0] = l4;
                    this.c(objectArray);
                }
                return;
            }
            int canStartMacro = this.activeMacro == null && BaseModule.a.screen == null ? 1 : 0;
            for (am am2 : this.macroList) {
                block20: {
                    int n6;
                    block21: {
                        block18: {
                            int n7;
                            block19: {
                                if (string == null) break block13;
                                int n8 = am2.b;
                                if (string != null) {
                                    if (n8 <= 0) continue;
                                    Object[] objectArray = new Object[2];
                                    objectArray[1] = l2;
                                    objectArray[0] = am2.b;
                                    n8 = L.a(objectArray) ? 1 : 0;
                                }
                                n7 = n8;
                                boolean bl = this.toggledMacros.contains(am2.b);
                                n6 = canStartMacro;
                                if (string == null) break block18;
                                if (n6 == 0) break block19;
                                n6 = am2.d ? 1 : 0;
                                if (string == null) break block18;
                                if (n6 == 0) break block19;
                                n6 = n7;
                                if (string == null) break block18;
                                if (n6 == 0) break block19;
                                n6 = bl ? 1 : 0;
                                if (string == null) break block18;
                                if (n6 == 0) {
                                    Object[] objectArray = new Object[2];
                                    objectArray[1] = am2;
                                    objectArray[0] = l3;
                                    this.a(objectArray);
                                }
                            }
                            n6 = n7;
                        }
                        if (string == null) break block20;
                        if (n6 == 0) break block21;
                        this.toggledMacros.add(am2.b);
                        if (string != null) break block20;
                    }
                    n6 = this.toggledMacros.remove(am2.b) ? 1 : 0;
                }
                if (this.activeMacro != null) {
                    canStartMacro = 0;
                }
                if (string != null) continue;
            }
            Object[] objectArray = new Object[3];
            objectArray[2] = (int)((char)n2);
            objectArray[1] = (int)((short)n3);
            objectArray[0] = n4;
            this.o(objectArray);
        }
    }

    private void a(Object[] objectArray) {
        long l2;
        am am2;
        block4: {
            block3: {
                List list;
                block2: {
                    long l3 = (Long)objectArray[0];
                    am2 = (am)objectArray[1];
                    l2 = (l3 = w ^ l3) ^ 0xBEF722A49A3L;
                    String string = am.b();
                    list = am2.e;
                    if (string == null) break block2;
                    if (list == null) break block3;
                    list = am2.e;
                }
                if (!list.isEmpty()) break block4;
            }
            return;
        }
        this.previousSlot = BaseModule.a.player.getInventory().getSelectedSlot();
        this.activeMacro = am2;
        this.stepIndex = 0;
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l2;
        this.n(objectArray2);
    }

    private void n(Object[] objectArray) {
        block9: {
            block10: {
                int n2;
                int n3;
                String string;
                long l2;
                long l3;
                block12: {
                    String string2;
                    an an2;
                    long l4;
                    block11: {
                        l3 = (Long)objectArray[0];
                        long l5 = l3 = w ^ l3;
                        l4 = l5 ^ 0x5DD3CC669444L;
                        long l6 = l5 ^ 0x4BA2D4727ADDL;
                        l2 = l5 ^ 0x297208268BD1L;
                        string = am.b();
                        Macros macros = this;
                        if (string != null) {
                            Macros macros2;
                            long l7 = 1535800851347142807L;
                            long l8 = l3;
                            if (l3 > 0L) {
                                if (macros.stepIndex >= this.activeMacro.e.size()) {
                                    Object[] objectArray2 = new Object[1];
                                    objectArray2[0] = l2;
                                    this.f(objectArray2);
                                    return;
                                }
                                macros2 = this;
                                l7 = 1534521496089782965L;
                                l8 = l3;
                            }
                            macros = ((am)((Object)Macros.d("\u00e7", (Object)macros2, (long)l7, (long)l8))).e.get(this.stepIndex);
                        }
                        an2 = (an)((Object)macros);
                        if (string == null) break block9;
                        Object[] objectArray3 = new Object[1];
                        objectArray3[0] = l6;
                        if (!an2.a.a(objectArray3)) break block10;
                        string2 = an2.b;
                        if (l3 <= 0L || string == null) break block11;
                        if (string2 == null) break block10;
                        string2 = an2.b;
                    }
                    n3 = string2.isEmpty();
                    if (string == null) break block12;
                    if (n3 != 0) break block10;
                    Object[] objectArray4 = new Object[2];
                    objectArray4[1] = l4;
                    objectArray4[0] = an2;
                    n3 = this.a(objectArray4);
                }
                int n4 = n2 = n3;
                int n5 = -1;
                if (l3 >= 0L && string != null) {
                    if (n4 == n5) {
                        Object[] objectArray5 = new Object[1];
                        objectArray5[0] = l2;
                        this.f(objectArray5);
                        return;
                    }
                    n4 = n2;
                    n5 = BaseModule.a.player.getInventory().getSelectedSlot();
                }
                if (n4 != n5) {
                    BaseModule.a.player.getInventory().setSelectedSlot(n2);
                }
            }
            this.r = 1;
            this.s = System.currentTimeMillis();
        }
    }

    /*
     * Exception decompiling
     */
    private void o(Object[] var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Extractable last case doesn't follow previous, and can't clone.
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.examineSwitchContiguity(SwitchReplacer.java:611)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.SwitchReplacer.replaceRawSwitches(SwitchReplacer.java:94)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:517)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private int a(Object[] objectArray) {
        int n2;
        block5: {
            an an2 = (an)objectArray[0];
            long l2 = (Long)objectArray[1];
            long l3 = (l2 = w ^ l2) ^ 0x7591BC1F2596L;
            Object[] objectArray2 = new Object[1];
            objectArray2[0] = l3;
            Item mc17922 = an2.a(objectArray2);
            int n3 = 0;
            String string = am.b();
            while (n3 < Macros.c("n", (int)11981, (long)(0x605E8878360A4162L ^ l2))) {
                ItemStack mc17992 = BaseModule.a.player.getInventory().getItem(n3);
                String string2 = string;
                if (l2 > 0L) {
                    if (string2 != null) {
                        n2 = mc17992.isEmpty() ? 1 : 0;
                        if (string == null) break block5;
                        if (n2 == 0 && mc17992.getItem() == mc17922) {
                            return n3;
                        }
                        ++n3;
                    }
                    string2 = string;
                }
                if (string2 != null) continue;
            }
            n2 = -1;
        }
        return n2;
    }

    public void r(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = (l2 = w ^ l2) ^ 0x58893B8570E1L;
        int n2 = (int)(l3 >>> 32);
        long l4 = l3 << 32 >>> 32;
        CallSite callSite = Macros.d("\u00e2", (long)7744167917437107163L, (long)l2);
        try {
            CallSite callSite2;
            block14: {
                CallSite callSite3;
                block13: {
                    Object object;
                    block11: {
                        block12: {
                            Object[] objectArray2 = new Object[2];
                            objectArray2[1] = l4;
                            objectArray2[0] = n2;
                            callSite2 = Macros.d("k", (Object)this, (Object)objectArray2, (long)7739099821557628030L, (long)l2);
                            try {
                                object = callSite2;
                                if (callSite == null) break block11;
                                if (object != null) break block12;
                            }
                            catch (Throwable throwable) {
                                throw Macros.d("\u00e2", (Object)throwable, (long)7737420453363349664L, (long)l2);
                            }
                            return;
                        }
                        object = ((File)((Object)callSite2)).getParentFile();
                    }
                    CallSite callSite4 = object;
                    try {
                        callSite3 = callSite4;
                        if (callSite == null) break block13;
                        if (callSite3 == null) break block14;
                    }
                    catch (Throwable throwable) {
                        throw Macros.d("\u00e2", (Object)throwable, (long)7737420453363349664L, (long)l2);
                    }
                    callSite3 = callSite4;
                }
                ((File)((Object)callSite3)).mkdirs();
            }
            try (FileWriter fileWriter = new FileWriter((File)((Object)callSite2));){
                Macros.d("z", (long)7744233465977323608L, (long)l2).toJson(Macros.d("\u00e7", (Object)this, (long)7738372258103097313L, (long)l2), fileWriter);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    /*
     * Unable to fully structure code
     */
    public final void s(Object[] var1_1) {
        block27: {
            var2_2 = (Long)var1_1[0];
            v0 = var2_2 = Macros.w ^ var2_2;
            v1 = v0 ^ 26327916042324L;
            var4_3 = (int)(v1 >>> 32);
            var5_4 = v1 << 32 >>> 32;
            var7_5 = v0 ^ 11273282652515L;
            var9_6 = am.b();
            try {
                block31: {
                    block26: {
                        block25: {
                            v2 = new Object[2];
                            v2[1] = var5_4;
                            v2[0] = var4_3;
                            var10_7 = this.a(v2);
                            try {
                                v3 = var10_7;
                                if (var9_6 == null) break block25;
                                if (v3 == null) break block26;
                            }
                            catch (Throwable v4) {
                                throw Macros.a(v4);
                            }
                            v3 = var10_7;
                        }
                        if (v3.exists()) break block31;
                    }
                    return;
                }
                var11_9 = new FileReader(var10_7);
                try {
                    var12_10 = new a(this).getType();
                    var13_12 = (List)Macros.m.fromJson((Reader)var11_9, var12_10);
                    try {
                        v5 = this.macroList;
                        if (var2_2 >= 0L) {
                            v5.clear();
                            if (var9_6 == null) break block27;
                            v5 = var13_12;
                        }
                        if (v5 == null) break block27;
                    }
                    catch (Throwable v6) {
                        throw Macros.a(v6);
                    }
                    for (am var15_15 : var13_12) {
                        block28: {
                            block29: {
                                block30: {
                                    block32: {
                                        if (var2_2 <= 0L) break block27;
                                        v7 = var9_6;
                                        if (var2_2 <= 0L) ** GOTO lbl52
                                        if (v7 == null) break block27;
                                        v7 = var9_6;
lbl52:
                                        // 2 sources

                                        if (var2_2 < 0L) break block28;
                                        if (v7 == null) break block29;
                                        break block32;
                                        catch (Throwable v8) {
                                            throw Macros.a(v8);
                                        }
                                    }
                                    try {
                                        if (var2_2 < 0L) break block29;
                                        if (var15_15 == null) {
                                            continue;
                                        }
                                        break block30;
                                        catch (Throwable v9) {
                                            throw Macros.a(v9);
                                        }
                                    }
                                    catch (Throwable v10) {
                                        throw Macros.a(v10);
                                    }
                                }
                                v11 = new Object[2];
                                v11[1] = var15_15;
                                v11[0] = var7_5;
                                this.macroList.add(Macros.a(v11));
                            }
                            v7 = var9_6;
                        }
                        if (v7 != null) continue;
                        break;
                    }
                }
                finally {
                    var11_9.close();
                }
            }
            catch (Exception var10_8) {
                // empty catch block
            }
        }
    }

    private static am a(Object[] objectArray) {
        am am22;
        List list;
        String string;
        am am3;
        long l2;
        block38: {
            am am4;
            block40: {
                block39: {
                    l2 = (Long)objectArray[0];
                    am3 = (am)objectArray[1];
                    long l3 = l2 = w ^ l2;
                    long l4 = l3 ^ 0x55862B7E6C52L;
                    long l5 = l3 ^ 0x15B393591B02L;
                    string = am.b();
                    am am5 = am3;
                    if (string != null) {
                        if (am5.a == null) {
                            am3.a = Macros.b("s", (int)5429, (long)(0x7530A9674A97C1D3L ^ l2));
                        }
                        am5 = am3;
                    }
                    list = am5.e;
                    String string2 = string;
                    if (l2 >= 0L) {
                        if (string2 != null) {
                            if (list == null) {
                                am3.e = new ArrayList();
                            }
                            am3.e.removeIf(arg_0 -> Macros.lambda$fixup$1(l4, arg_0));
                            list = am3.e;
                        }
                        string2 = string;
                    }
                    if (string2 == null) break block38;
                    if (!list.isEmpty()) break block39;
                    am4 = am3;
                    if (string == null) break block40;
                    Object[] objectArray2 = new Object[1];
                    objectArray2[0] = l5;
                    if (am4.a(objectArray2)) {
                        an an2 = new an();
                        am am6 = am3;
                        String string3 = string;
                        if (l2 > 0L) {
                            if (string3 != null) {
                                if (am6.h != null) {
                                    an2.a = am3.h;
                                }
                                am6 = am3;
                            }
                            string3 = string;
                        }
                        if (l2 >= 0L) {
                            if (string3 != null) {
                                if (am6.f != null) {
                                    an2.b = am3.f;
                                }
                                am6 = am3;
                            }
                            string3 = string;
                        }
                        if (l2 > 0L) {
                            if (string3 != null) {
                                if (am6.g != null) {
                                    an2.c = am3.g;
                                }
                                am6 = am3;
                            }
                            string3 = string;
                        }
                        if (string3 != null) {
                            if (am6.i != null) {
                                an2.d = am3.i;
                            }
                            am6 = am3;
                        }
                        am6.e.add(an2);
                    }
                }
                am3.f = null;
                am3.g = null;
                am3.h = null;
                am3.i = null;
                am4 = am3;
            }
            list = am4.e;
        }
        block0: for (am am22 : list) {
            do {
                block47: {
                    block46: {
                        an an3;
                        long l6;
                        an an4;
                        block45: {
                            long l7;
                            an an5;
                            block44: {
                                String string4;
                                block43: {
                                    an an6;
                                    block42: {
                                        String string5;
                                        block41: {
                                            an6 = an4 = (an)((Object)am22);
                                            string5 = string;
                                            if (l2 <= 0L) break block41;
                                            if (string5 != null) {
                                                if (an6.a == null) {
                                                    an4.a = kuzi.obf.j.e.m.USE;
                                                }
                                                an6 = an4;
                                            }
                                            if (l2 <= 0L) break block42;
                                            string5 = string;
                                        }
                                        if (string5 != null) {
                                            if (an6.e == null) {
                                                an4.e = a.a.a.j.e.n.USE;
                                            }
                                            an6 = an4;
                                        }
                                    }
                                    string4 = an6.b;
                                    if (l2 < 0L || string == null) break block43;
                                    if (string4 == null) {
                                        an4.b = "";
                                    }
                                    an5 = an4;
                                    if (l2 < 0L || string == null) break block44;
                                    string4 = an5.d;
                                }
                                if (string4 == null) {
                                    an4.d = "";
                                }
                                an5 = an4;
                            }
                            l6 = (l7 = an5.c - 0L) == 0L ? 0 : (l7 < 0L ? -1 : 1);
                            if (string == null) break block45;
                            if (l6 < 0) {
                                an4.c = 0L;
                            }
                            an3 = an4;
                            if (string == null) break block46;
                            long l8 = an3.f - 0L;
                            l6 = l8 == 0L ? 0 : (l8 < 0L ? -1 : 1);
                        }
                        if (l6 >= 0) break block47;
                        an3 = an4;
                    }
                    an3.f = 0L;
                }
                if (string != null) continue block0;
                am22 = am3;
            } while (l2 <= 0L);
        }
        return am22;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private File a(Object[] objectArray) {
        File file;
        CallSite callSite;
        long l2;
        block11: {
            CallSite callSite2;
            CallSite callSite3;
            block10: {
                CallSite callSite4;
                long l3;
                block8: {
                    block9: {
                        int n2 = (Integer)objectArray[0];
                        l3 = (Long)objectArray[1];
                        l2 = ((long)n2 << 32 | l3 << 32 >>> 32) ^ w;
                        callSite3 = Macros.d("\u00e2", (long)671543214588680690L, (long)l2);
                        try {
                            callSite4 = Macros.d("z", (long)671507257274818486L, (long)l2);
                            if (callSite3 == null) break block8;
                            if (callSite4 == null) break block9;
                        }
                        catch (MatchException matchException) {
                            throw Macros.d("\u00e2", (Object)matchException, (long)669300929717148297L, (long)l2);
                        }
                        callSite4 = Macros.d("z", (long)671507257274818486L, (long)l2);
                        break block8;
                    }
                    callSite4 = Minecraft.getInstance();
                }
                callSite = callSite4;
                try {
                    callSite2 = callSite;
                    if (l3 < 0L || callSite3 == null) break block10;
                    if (callSite2 == null) return null;
                }
                catch (MatchException matchException) {
                    throw Macros.d("\u00e2", (Object)matchException, (long)669300929717148297L, (long)l2);
                }
                callSite2 = callSite;
            }
            try {
                try {
                    file = ((Minecraft)callSite2).gameDirectory;
                    if (callSite3 == null) return file;
                    if (file != null) break block11;
                    return null;
                }
                catch (MatchException matchException) {
                    throw Macros.d("\u00e2", (Object)matchException, (long)669300929717148297L, (long)l2);
                }
            }
            catch (MatchException matchException) {
                throw Macros.d("\u00e2", (Object)matchException, (long)669300929717148297L, (long)l2);
            }
        }
        file = new File(((Minecraft)callSite).gameDirectory, (String)((Object)Macros.b("s", (int)12009, (long)(0x15939A341836AB39L ^ l2))));
        return file;
    }

    private static boolean lambda$fixup$1(long l2, an an2) {
        boolean bl;
        l2 = w ^ l2;
        try {
            bl = an2 == null;
        }
        catch (MatchException matchException) {
            throw Macros.d("\u00e2", (Object)matchException, (long)2802582941983323428L, (long)l2);
        }
        return bl;
    }

    private static void lambda$openEditor$0(Minecraft mc3102) {
        mc3102.setScreen((Screen)new V());
    }

    /*
     * Unable to fully structure code
     */
    static {
        block24: {
            block23: {
                block22: {
                    block21: {
                        block20: {
                            Macros.w = kuzi.obf.h.b.v.a(4798746048224822833L, 3132812198443102327L, MethodHandles.lookup().lookupClass()).a(215607757376835L);
                            Macros.E = new Object[102];
                            Macros.F = new String[102];
                            Macros.c();
                            Macros.z = new HashMap<K, V>(13);
                            var16 = Macros.w ^ 35462517830038L;
                            var18_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                            v0 = SecretKeyFactory.getInstance("DES");
                            v1 = new byte[8];
                            v2 = v1;
                            v1[0] = (byte)(var16 >>> 56);
                            for (var19_2 = 1; var19_2 < 8; ++var19_2) {
                                v2 = v2;
                                v2[var19_2] = (byte)(var16 << var19_2 * 8 >>> 56);
                            }
                            var18_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                            var25_3 = new String[5];
                            var23_4 = 0;
                            var22_5 = "\u00d7\u00aft2/\n\u00e6\u00d8\u00bb\u0010\u00ebx\u00db\u00d6Z\u0002(\u00de1\u00d7k\u0095R\u00b4\u00e3\u00dd\u001aJ-\u0099P|;\u0082/\u00b1}\u00e6\u009b\ro\u0003\u00d3;\u0011\f\u0087\u00c0M\r\u0000\u009f\f<s\u0091P \u00e6L\u0092\u00e3\u0085\u00bd\u00c7 \u00d4\u0017\u00bd*\u00fe,)\u00f9Ull\u00cf\u0003\u008b\u00fe\u001bp\u00f6\u00acf\u008e\u00aaA^";
                            var24_6 = "\u00d7\u00aft2/\n\u00e6\u00d8\u00bb\u0010\u00ebx\u00db\u00d6Z\u0002(\u00de1\u00d7k\u0095R\u00b4\u00e3\u00dd\u001aJ-\u0099P|;\u0082/\u00b1}\u00e6\u009b\ro\u0003\u00d3;\u0011\f\u0087\u00c0M\r\u0000\u009f\f<s\u0091P \u00e6L\u0092\u00e3\u0085\u00bd\u00c7 \u00d4\u0017\u00bd*\u00fe,)\u00f9Ull\u00cf\u0003\u008b\u00fe\u001bp\u00f6\u00acf\u008e\u00aaA^".length();
                            var21_7 = 16;
                            var20_8 = -1;
lbl23:
                            // 2 sources

                            while (true) {
                                v3 = ++var20_8;
                                v4 = var22_5.substring(v3, v3 + var21_7);
                                v5 = -1;
                                break block20;
                                break;
                            }
lbl28:
                            // 1 sources

                            while (true) {
                                var25_3[var23_4++] = Macros.b(var26_9).intern();
                                if ((var20_8 += var21_7) < var24_6) {
                                    var21_7 = var22_5.charAt(var20_8);
                                    ** continue;
                                }
                                var22_5 = "\u00e5!\u0098wq\u00d9k\u001c7ll\u00ab\u00ef&\u0018\u008e\u00f7\u009dgn\u00e7\u00c6\u00ffZ\u00ad\u00c2_)\u0005\u0014P\u0089\u00a1\u00fd\u00dc\u00e1:\u00b3)\u008d\\\u00b9\u0017\u00be\u0006\u009a\"\rGN|\u0011\u0019\u0001D\u00c2\u00ee\u00c0FH\u00ce =\u00c02\u000fR\u00c5s\u00bb\u0001\u00b5\u00c9p\u00f4\u0088\u008b\u00e0+\u00a6\u00f5Z\"P\u00d7\u00e9\u00c8e\"%\u00af\u00a2|\u00f8\u00e9\u0095!\u00a1\u00bd\u0014\u0017Q%\u00ed#4\u009b\u00cc\u0088\u000b\u0087\u001ec\u001c\u00f6\u00f2\u00ac\u00c9\u00da\u00bb\u00a6\u00ef7\u0095\u00b0\u0014U\u0099\u00f7\u007f\u00f8\u00c64\u00a2A\u008c\u00ecb\u008b\u00f1\u00d1\u0086\u0013y\u0010\u00f1df\u00cf}\u0017\u008bud(`b\u00f0\u00f6@\u00a4";
                                var24_6 = "\u00e5!\u0098wq\u00d9k\u001c7ll\u00ab\u00ef&\u0018\u008e\u00f7\u009dgn\u00e7\u00c6\u00ffZ\u00ad\u00c2_)\u0005\u0014P\u0089\u00a1\u00fd\u00dc\u00e1:\u00b3)\u008d\\\u00b9\u0017\u00be\u0006\u009a\"\rGN|\u0011\u0019\u0001D\u00c2\u00ee\u00c0FH\u00ce =\u00c02\u000fR\u00c5s\u00bb\u0001\u00b5\u00c9p\u00f4\u0088\u008b\u00e0+\u00a6\u00f5Z\"P\u00d7\u00e9\u00c8e\"%\u00af\u00a2|\u00f8\u00e9\u0095!\u00a1\u00bd\u0014\u0017Q%\u00ed#4\u009b\u00cc\u0088\u000b\u0087\u001ec\u001c\u00f6\u00f2\u00ac\u00c9\u00da\u00bb\u00a6\u00ef7\u0095\u00b0\u0014U\u0099\u00f7\u007f\u00f8\u00c64\u00a2A\u008c\u00ecb\u008b\u00f1\u00d1\u0086\u0013y\u0010\u00f1df\u00cf}\u0017\u008bud(`b\u00f0\u00f6@\u00a4".length();
                                var21_7 = 144;
                                var20_8 = -1;
lbl37:
                                // 2 sources

                                while (true) {
                                    v6 = ++var20_8;
                                    v4 = var22_5.substring(v6, v6 + var21_7);
                                    v5 = 0;
                                    break block20;
                                    break;
                                }
                                break;
                            }
lbl42:
                            // 1 sources

                            while (true) {
                                var25_3[var23_4++] = Macros.b(var26_9).intern();
                                if ((var20_8 += var21_7) < var24_6) {
                                    var21_7 = var22_5.charAt(var20_8);
                                    ** continue;
                                }
                                break block21;
                                break;
                            }
                        }
                        var26_9 = var18_1.doFinal(v4.getBytes("ISO-8859-1"));
                        switch (v5) {
                            default: {
                                ** continue;
                            }
                            ** case 0:
lbl54:
                            // 1 sources

                            ** continue;
                        }
                    }
                    Macros.x = var25_3;
                    Macros.y = new String[5];
                    Macros.C = new HashMap<K, V>(13);
                    var5_10 = Cipher.getInstance("DES/CBC/NoPadding");
                    v7 = SecretKeyFactory.getInstance("DES");
                    v8 = new byte[8];
                    v9 = v8;
                    v8[0] = (byte)(var16 >>> 56);
                    for (var6_11 = 1; var6_11 < 8; ++var6_11) {
                        v9 = v9;
                        v9[var6_11] = (byte)(var16 << var6_11 * 8 >>> 56);
                    }
                    var5_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                    var11_12 = new long[4];
                    var8_13 = 0;
                    var9_14 = "h\u00c79\u0084$j{\u008d\u001b\u00e2\u00e3\u0007\u00187\u00fc\u00df";
                    var10_15 = "h\u00c79\u0084$j{\u008d\u001b\u00e2\u00e3\u0007\u00187\u00fc\u00df".length();
                    var7_16 = 0;
                    while (true) {
                        var12_17 = var9_14.substring(var7_16, var7_16 += 8).getBytes("ISO-8859-1");
                        v10 = var11_12;
                        v11 = var8_13++;
                        v12 = ((long)var12_17[0] & 255L) << 56 | ((long)var12_17[1] & 255L) << 48 | ((long)var12_17[2] & 255L) << 40 | ((long)var12_17[3] & 255L) << 32 | ((long)var12_17[4] & 255L) << 24 | ((long)var12_17[5] & 255L) << 16 | ((long)var12_17[6] & 255L) << 8 | (long)var12_17[7] & 255L;
                        v13 = -1;
                        break block22;
                        break;
                    }
lbl81:
                    // 1 sources

                    while (true) {
                        v10[v11] = v14;
                        if (var7_16 < var10_15) ** continue;
                        var9_14 = "\u0088\u00c4\u001a@2\u001col\u00d6\u00c0dP4\u00bba\u0012";
                        var10_15 = "\u0088\u00c4\u001a@2\u001col\u00d6\u00c0dP4\u00bba\u0012".length();
                        var7_16 = 0;
                        while (true) {
                            var12_17 = var9_14.substring(var7_16, var7_16 += 8).getBytes("ISO-8859-1");
                            v10 = var11_12;
                            v11 = var8_13++;
                            v12 = ((long)var12_17[0] & 255L) << 56 | ((long)var12_17[1] & 255L) << 48 | ((long)var12_17[2] & 255L) << 40 | ((long)var12_17[3] & 255L) << 32 | ((long)var12_17[4] & 255L) << 24 | ((long)var12_17[5] & 255L) << 16 | ((long)var12_17[6] & 255L) << 8 | (long)var12_17[7] & 255L;
                            v13 = 0;
                            break block22;
                            break;
                        }
                        break;
                    }
lbl94:
                    // 1 sources

                    while (true) {
                        v10[v11] = v14;
                        if (var7_16 < var10_15) ** continue;
                        break block23;
                        break;
                    }
                }
                var13_18 = v12;
                var15_19 = var5_10.doFinal(new byte[]{(byte)(var13_18 >>> 56), (byte)(var13_18 >>> 48), (byte)(var13_18 >>> 40), (byte)(var13_18 >>> 32), (byte)(var13_18 >>> 24), (byte)(var13_18 >>> 16), (byte)(var13_18 >>> 8), (byte)var13_18});
                v14 = ((long)var15_19[0] & 255L) << 56 | ((long)var15_19[1] & 255L) << 48 | ((long)var15_19[2] & 255L) << 40 | ((long)var15_19[3] & 255L) << 32 | ((long)var15_19[4] & 255L) << 24 | ((long)var15_19[5] & 255L) << 16 | ((long)var15_19[6] & 255L) << 8 | (long)var15_19[7] & 255L;
                switch (v13) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl107:
                    // 1 sources

                    ** continue;
                }
            }
            Macros.A = var11_12;
            Macros.B = new Integer[4];
            var0_20 = Cipher.getInstance("DES/CBC/NoPadding");
            v15 = SecretKeyFactory.getInstance("DES");
            v16 = new byte[8];
            v17 = v16;
            v16[0] = (byte)(var16 >>> 56);
            for (var1_21 = 1; var1_21 < 8; ++var1_21) {
                v17 = v17;
                v17[var1_21] = (byte)(var16 << var1_21 * 8 >>> 56);
            }
            break block24;
lbl121:
            // 1 sources

            while (true) {
                continue;
                break;
            }
        }
        var0_20.init(2, (Key)v15.generateSecret(new DESKeySpec(v17)), new IvParameterSpec(new byte[8]));
        var2_22 = 1662790974987015680L;
        var4_23 = var0_20.doFinal(new byte[]{(byte)(var2_22 >>> 56), (byte)(var2_22 >>> 48), (byte)(var2_22 >>> 40), (byte)(var2_22 >>> 32), (byte)(var2_22 >>> 24), (byte)(var2_22 >>> 16), (byte)(var2_22 >>> 8), (byte)var2_22});
        ** while (true)
        Macros.D = ((long)var4_23[0] & 255L) << 56 | ((long)var4_23[1] & 255L) << 48 | ((long)var4_23[2] & 255L) << 40 | ((long)var4_23[3] & 255L) << 32 | ((long)var4_23[4] & 255L) << 24 | ((long)var4_23[5] & 255L) << 16 | ((long)var4_23[6] & 255L) << 8 | (long)var4_23[7] & 255L;
        Macros.m = new GsonBuilder().setPrettyPrinting().create();
    }

    private static Throwable a(Throwable throwable) {
        return throwable;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static String b(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0xC8F;
        if (y[n3] == null) {
            Object[] objectArray;
            try {
                Long l3 = Thread.currentThread().threadId();
                objectArray = (Object[])z.get(l3);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    z.put(l3, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/e/U", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l2 >>> 56);
            for (int i2 = 1; i2 < 8; ++i2) {
                byArray[i2] = (byte)(l2 << i2 * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = x[n3].getBytes("ISO-8859-1");
            Macros.y[n3] = Macros.b(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return y[n3];
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        String string2 = Macros.b(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static CallSite b(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/e/U" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x7C7C;
        if (B[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = A[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])C.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    C.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/e/U", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Macros.B[n3] = n4;
        }
        return B[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = Macros.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/e/U" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (F[n4] != null) {
            return n4;
        }
        Object object = E[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 35;
            case 1 -> 57;
            case 2 -> 9;
            case 3 -> 40;
            case 4 -> 31;
            case 5 -> 27;
            case 6 -> 63;
            case 7 -> 3;
            case 8 -> 52;
            case 9 -> 58;
            case 10 -> 24;
            case 11 -> 1;
            case 12 -> 22;
            case 13 -> 20;
            case 14 -> 54;
            case 15 -> 43;
            case 16 -> 21;
            case 17 -> 55;
            case 18 -> 23;
            case 19 -> 32;
            case 20 -> 26;
            case 21 -> 46;
            case 22 -> 34;
            case 23 -> 41;
            case 24 -> 39;
            case 25 -> 61;
            case 26 -> 29;
            case 27 -> 56;
            case 28 -> 19;
            case 29 -> 2;
            case 30 -> 15;
            case 31 -> 11;
            case 32 -> 49;
            case 33 -> 53;
            case 34 -> 51;
            case 35 -> 37;
            case 36 -> 6;
            case 37 -> 33;
            case 38 -> 62;
            case 39 -> 10;
            case 40 -> 60;
            case 41 -> 5;
            case 42 -> 38;
            case 43 -> 13;
            case 44 -> 18;
            case 45 -> 4;
            case 46 -> 0;
            case 47 -> 17;
            case 48 -> 47;
            case 49 -> 45;
            case 50 -> 16;
            case 51 -> 42;
            case 52 -> 36;
            case 53 -> 48;
            case 54 -> 8;
            case 55 -> 14;
            case 56 -> 12;
            case 57 -> 28;
            case 58 -> 59;
            case 59 -> 50;
            case 60 -> 44;
            case 61 -> 30;
            case 62 -> 7;
            default -> 25;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        Macros.F[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = E;
        E[0] = "Kq\u001f\u001bR\u0018@q\u001b\u001bR[";
        objectArray[1] = "$[<\u001d\u0017N/T-RjV<S$\u001b";
        objectArray[2] = "<k9y0K7k2";
        objectArray[3] = "ey\t=\u0017'ey\u001ea\u001b(\u007f2\u001e\u007f\u001b=xCN\"J";
        objectArray[4] = "m\u001d\rSdUf\u001d\tSP";
        objectArray[5] = "q\u0000BhL\fz\u000fS'6\bi\u000eCh\u0000\f~";
        objectArray[6] = ";\u001e-^Sn0\u001e%";
        objectArray[7] = Integer.TYPE;
        Macros.F[7] = "java/lang/Integer";
        objectArray[8] = " \u0001\"a\u0017W \u00015=\u001bX:J5#\u001bM=;e\u007fN";
        objectArray[9] = Long.TYPE;
        Macros.F[9] = "java/lang/Long";
        objectArray[10] = "/\u0002<\u001cXMZ\"7\u0013I\u0002;,<\u0018MXO";
        objectArray[11] = Void.TYPE;
        Macros.F[11] = "java/lang/Void";
        objectArray[12] = "w\u000es^s4\u0002.xQb{c sZf!\u0017";
        objectArray[13] = "B~:-\u0003\u00027^1\"\u0012MVP:)\u0016\u0017\"";
        objectArray[14] = "T9+N\u0010jJ11\u0001rvM,";
        objectArray[15] = "t!\bhR{\u0001\u0001\u0003gC4`\u000f\blGn\u0014";
        objectArray[16] = "f\u0000wur>\u0013 |zcqr.wqg+\u0006";
        objectArray[17] = "UAC\u001e\u0010,KIYQm<K";
        objectArray[18] = "$Dq\u0007\u000e{Qdz\b\u001f40jq\u0003\u001bnD";
        objectArray[19] = "!\u0007\u001d@\bz$H-HJv";
        objectArray[20] = "sCFbT\u0016\u007fKG)\u001d\u001ecCEbt\n\u007fB";
        objectArray[21] = "t>bt$>\u0001\u001ei{5q`\u0010bp1+\u0014";
        objectArray[22] = "L\t#\u0001|4G\t'\u0001|t";
        objectArray[23] = "x|\u0001BE7s|\u0005BI";
        objectArray[24] = "?q\u001f#RpJQ\u0014,C?+_\u001f'Ge_";
        objectArray[25] = Boolean.TYPE;
        Macros.F[25] = "java/lang/Boolean";
        objectArray[26] = "<gkdR37godRr";
        objectArray[27] = "R5";
        objectArray[28] = " j4\u00028wUJ?\r)84D4\u0006-b@";
        objectArray[29] = "H\u0005%p\u0005I=%.\u007f\u0014\u0006\\+%t\u0010\\(";
        objectArray[30] = "\tqa~l\u007f|Qjq}0\u001d_azyji";
        objectArray[31] = "b\u0004f{.n\u0017$mt?!v*f\u007f;{\u0002";
        objectArray[32] = "\b\u0005";
        objectArray[33] = "!;\b,Xc*;\f,W";
        objectArray[34] = "yR\u0018\u0011Zb\fr\u0013\u001eK-m|\u0018\u0015Ow\u0019";
        objectArray[35] = "U9Y\u0006$~ \u0019R\t51A\u0017Y\u00021k5";
        objectArray[36] = "|vL-c\u0019\tVG\"rVhXL)v\f\u001c";
        objectArray[37] = "p.!h/q\u0005\u000e*g>>d\u0000!l:d\u0010";
        objectArray[38] = "~n%qS\f\u000bN.~BCj@%uF\u0019\u001e";
        objectArray[39] = "Y##M[EY#4\u0011WJCh4\u000fW_D\u0019fT\u000f\u001e";
        objectArray[40] = ")zGv*\u0017\"uV9H\u0014-|";
        objectArray[41] = "r2bxy\r\u0007\u0012iwhBf\u001cb|l\u0018\u0012";
        objectArray[42] = "wj:r\u0018]fj\u0017";
        objectArray[43] = "\\\u0016_!q\u001d)6T.`RH8_%d\b<";
        objectArray[44] = "gCe}Td\u0012cnrE+smeyAq\u0007";
        objectArray[45] = "y<ot\\B\f\u001cd{M\rm\u0012opIW\u0019";
        objectArray[46] = "k\u0005\u0005h\u0014|`\n\u0014'urk\u0001\u0010}";
        objectArray[47] = "OHG\\\tFSS\u0012Pr\u001e!^\u001cZ\u0003\u0010HA]\u000eC";
        objectArray[48] = "p*EF\u0014lvp\u0007\u0001rrKkPJ\u0003qtjVFL\u001e{%Z\u0007\u001dn nI\u0001r";
        objectArray[49] = "8\u0011<!\u007f\u0016>K~f\u0019\u0019\u0003\u0013&e{\u000e;\u0011-yw";
        objectArray[50] = "\u0006\u0013w\u001c2LET`d#sF\u0006?\u001b&H\u0000\u0014kU";
        objectArray[51] = "6O \u0001tS0\u0015bF\u0012Y\r\u000e5\rcN2\u000f3\u0001,!=@?@}Qf\u000b,F\u0012";
        objectArray[52] = "1\u00189yJFr_.\u0001Yyc^!?V\bw\u0000wn";
        objectArray[53] = "=\u0001T\u0016\u0007:!\u001a\u0001\u001a|gSAXB\u0001v6GXMD";
        objectArray[54] = "\u0006gR>h\u001cE EFx#\u0004w\u001d;kF\u0002w\u0012~";
        objectArray[55] = "0W\u000f\u001a/\u0003.P\u0005\n\u0017SQ\r\u0013\u001f&A7\nB\u000ef";
        objectArray[56] = "H\u001e3;42NDq|R9s\u001c%ej|\u0019\u001e7|i";
        objectArray[57] = "\u0015jz\u0010q\u0002\u001308W\u0017\u0015.9wDkN\u0017,=Kr";
        objectArray[58] = "7nk\r6ut)|u!J5~$\b5/3~+M";
        objectArray[59] = "\u0014\u000f\u0006H\u0014R\u0012UD\u000fr\\/\u000e\u0013\rL]\u0013R\u0018\u0011\u000e";
        objectArray[60] = "\u0003Qae*xXU)\u007fK\u0011{uAN\u0011I\u0003Qae*xXU)\u007f";
        objectArray[61] = "p9\u001doK5r9T8w3\f Dg\u000653!BkIZl?G0H46:\u0010,w";
        objectArray[62] = "\"?\u0019*\u0006Lax\u000eR\u0012s /V/\u0005\u0016&/Yjx";
        objectArray[63] = "y_.zNn}\u0001~?)=@\u0001\"?O9~\u0006}9I";
        objectArray[64] = "T-\n\"a'RwHe\u0007>ol\u001f.v:Pm\u0019\"9U_\"\u0015ch%\u0004i\u0006e\u0007";
        objectArray[65] = "Dp{\u0006p8B*9A\u0016$\u007f1n\ng%@0h\u0006(JO\u007fdGy:\u00144wA\u0016";
        objectArray[66] = "XT!\u0005Bq^\u000ecB$dc\u00002RU=\u0003PaI_";
        objectArray[67] = "XWAP\u0019LDL\u0014\\b\u00166\u0010MB\\\u0000\nLF^\u001e";
        objectArray[68] = "\u0000u\u0012IUX\u0006/P\u000e3C;4\u0007EBE\u00045\u0001I\r*\u0006 \rL\u000f@\u00042\u0014O3";
        objectArray[69] = "|k\u0015\u0002~\u0018z1WE\u0018\fG*\u0000\u000ei\u0005x+\u0006\u0002&jwd\nCw\u001a,/\u0019E\u0018";
        objectArray[70] = "\u007fy\u0001A\u0013\"y#C\u0006u9D8\u0014M\u0004?{9\u0012AKP(;\u001f\u001f\u000e0=!\u001fDu";
        objectArray[71] = "eeN#d`y~\u001b/\u001f?\u000b\"B1!,7~I-c";
        objectArray[72] = "\u001dfT\u0004XO\u001b<\u0016C>T&'A\bOR\u0019&G\u0004\u0000=\u001d YA@\u0002^gN9";
        objectArray[73] = "\t#Ch`P\u000fy\u0001/\u0006[2bVdwM\rcPh8\"\u0002,\\)iRYgO/\u0006";
        objectArray[74] = "\n}\n%+\u0015\f'HbM\u000e1<\u001f)<\b\u000e=\u0019%sg\u0001r\u0015d\"\u0017Z9\u0006bM";
        objectArray[75] = "m\u0007%#\u0004Oq\u001cp/\u007f\u0013\u0003\u0018| COq\u0018.x@";
        objectArray[76] = "-G\u0016sE\u0019n\u0000\u0001\u000b[&y\u0000\u000bz\\OfA_:";
        objectArray[77] = "\u0017P:\u001dYn\u0011\nxZ?z,\u0006yI\u0001~]\u0012'\u001fP";
        objectArray[78] = "\u0017g\u0018;e\u0007T \u000fCz8\u0015wW>f]\u0013wX{";
        objectArray[79] = "I-\u0019\u0012U[VlMR2o}^u\f\f^Wt\u001c\u0013M\n\u0017";
        objectArray[80] = "\u0000;\u001f{IqC|\b\u0003[N[#\u0004e\b \u0001&Sy";
        objectArray[81] = "p)\\@\u007f\u0002vs\u001e\u0007\u0019\u0015KhILh\u001ftiO@'p{&C\u0001v\u0000 mP\u0007\u0019";
        objectArray[82] = "OY6JP\u001dI\u0003t\r6\u0014t\u0018#FG\u0000K\u0019%J\boDV)\u000bY\u001f\u001f\u001d:\r6";
        objectArray[83] = "/\u000e#=^13\u0015v1%jAN/iX}$H/f\u001d";
        objectArray[84] = "v1Pj9$5vG\u0012.\u001b3!\u0010c($2'\u001c,G{,\"G-)!)u[\u0012";
        objectArray[85] = "(Kk\u001f\u0007;.\u0011)Xa#\u0013\n~\u0013\u0010&,\u000bx\u001f_I#Dt^\u000e9x\u000fgXa";
        objectArray[86] = "suyj?\bu/;-Y\u001dH4lf(\u0015w5jjgzxzf+6\n#1u-Y";
        objectArray[87] = "udS\u0012\u0019\u0019s>\u0011U\u007f\u0013N`V^\u0007\u0015q#\u0011I";
        objectArray[88] = "\u001a\u0007%w,\u001fY@2\u000f8 \u001c\u001477nJ\u001e\u0006.4";
        objectArray[89] = "(>4m5p.dv*Sx\u0013<\"3k>y>0*h";
        objectArray[90] = "\u0000/'\u0005l\n\u0004qw@\u000bR9{|]w_I 7Nq0";
        objectArray[91] = "'n\u000fy$D!4M>B[\u001c/\u001au3Y#.\u001cy|6,a\u00108-Fw*\u0003>B";
        objectArray[92] = "%kwO^\u001c%9/Lo3\u0018\u001a\u001e\u0015S\u0007\u007ffl\u0015\u0001_|";
        objectArray[93] = "\u001d-\u0012\u0002&W\u001bwPE@^&,\u0007G~X\u001ap\f[<";
        objectArray[94] = "\u0018\u0000\u0019\u007f\u0007c\u001eZ[8ax#\u0004\u0006-\u000fh]\u0003\u000b}\u000b\u0011\u0018\\\n,\u0018o\u001fQZ(a";
        objectArray[95] = "\u0003\u0016p^TX\u001d\u0011zNl\u000bbLl[]\u001a\u0004K=J\u001d";
        objectArray[96] = "s'/aeUlf{!\u0002U\u001cg*!sS#f,-<<|x)v=R&}~j\u0002";
        objectArray[97] = "Ned'guR~1+\u001c- bh|m+\u001fcnp\"DZ\"fps<\\dyw\u001c";
        objectArray[98] = "(\\m%[\bk\u001bz]N7sDv;\u001aY)A!'";
        objectArray[99] = "\u0006npbd&\u00020 '\u0003x?trhrs\u0000utd=\u001c\u000f:x%llTqk#\u0003";
        objectArray[100] = "h8$F\u001d@nbf\u0001{LS:2\u0018C\u000e98 \u0001@";
        Object[] objectArray2 = objectArray;
        objectArray[101] = "S!yH-DU{;\u000fK_h`lD:YWajHu6Ux|\u0017!\u000eWs`\u001bK";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = Macros.e(l2, l3);
            object = E[n2];
            try {
                if (!(object instanceof String)) break block2;
                Macros.E[n2] = clazz = Class.forName(F[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = Macros.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = Macros.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = Macros.e(l2, l3);
        Object object = E[n2];
        if (object instanceof String) {
            String string = F[n2];
            int n3 = string.indexOf(8);
            Class clazz = Macros.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = Macros.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = Macros.c(clazz3, string2, clazz2)) != null) {
                    Macros.E[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = Macros.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        Macros.E[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = Macros.f(3265524405501006L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = Macros.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = Macros.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = Macros.e(l2, l3);
        Object object = E[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = F[n2];
                int n4 = string2.indexOf(8);
                clazz3 = Macros.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = Macros.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = Macros.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        Macros.E[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = Macros.f(3265524405501006L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = Macros.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        Macros.E[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = Macros.f(3265524405501006L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == '\u00e7' || c2 == '\u00c9' || c2 == 'z' || c2 == '\u00cc') {
                field = Macros.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == '\u00e7' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == '\u00c9' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == 'z' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = Macros.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == 'k' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == '\u00e2' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = Macros.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_2().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/e/U" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Macros.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(Macros.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_2() {
        try {
            return MethodHandles.lookup().findStatic(Macros.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

