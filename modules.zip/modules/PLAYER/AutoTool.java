// === Kuzi module: AutoTool ===
// Category   : PLAYER
// Description: Automatically switches to the best tool for the job.
// Payload    : a.a.a.j.e.F (verified: True)

package kuzi.modules.player;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.b.v;
import kuzi.obf.j.e.am;
import kuzi.obf.m.r;
import net.minecraft.Inventory;
import net.minecraft.ItemStack;
import net.minecraft.HitResult;
import net.minecraft.BlockState;
import net.minecraft.Minecraft;
import net.minecraft.BlockHitResult;
import net.minecraft.Attributes;
import net.minecraft.MultiPlayerGameMode;
import net.minecraft.Holder;
import net.minecraft.ItemAttributeModifiers;
import net.minecraft.DataComponents;

public class AutoTool
extends BaseModule {
    private static final long m = v.a(5073250958207834321L, -581170518248826769L, MethodHandles.lookup().lookupClass()).a(105829427187122L);
    private static final String[] n;
    private static final String[] o;
    private static final Map p;
    private static final long[] q;
    private static final Integer[] r;
    private static final Map s;
    private static final Object[] t;
    private static final String[] u;

    public AutoTool() {
        super("AutoTool", "Automatically switches to the best tool for the job.", Category.PLAYER);
    }

    @Override
    public void i() {
        block19: {
            Minecraft mc;
            long l2;
            block18: {
                boolean bl;
                block14: {
                    String string;
                    block16: {
                        block15: {
                            HitResult hitResult;
                            long l3;
                            block17: {
                                MultiPlayerGameMode gameMode;
                                block12: {
                                    block13: {
                                        block10: {
                                            Minecraft client;
                                            block11: {
                                                block9: {
                                                    long l4;
                                                    long l5 = l4 = m ^ 0x76DF14FE5D6BL;
                                                    l3 = l5 ^ 0x5A176C172FCFL;
                                                    l2 = l5 ^ 0x1B568D2DEF00L;
                                                    string = am.b();
                                                    client = BaseModule.a;
                                                    if (string == null) break block9;
                                                    if (client.player == null) break block10;
                                                    client = BaseModule.a;
                                                }
                                                if (string == null) break block11;
                                                if (client.level == null) break block10;
                                                client = BaseModule.a;
                                            }
                                            gameMode = client.gameMode;
                                            if (string == null) break block12;
                                            if (gameMode != null) break block13;
                                        }
                                        return;
                                    }
                                    gameMode = BaseModule.a.gameMode;
                                }
                                bl = gameMode.isDestroying();
                                if (string == null) break block14;
                                if (!bl) break block15;
                                mc = BaseModule.a;
                                if (string == null) break block16;
                                HitResult lookedAt = mc.hitResult;
                                if (lookedAt == null) break block15;
                                hitResult = lookedAt;
                                if (string == null) break block17;
                                if (hitResult.getType() != HitResult.mc240.BLOCK) break block15;
                                hitResult = lookedAt;
                            }
                            BlockHitResult blockHit = (BlockHitResult)hitResult;
                            BlockState blockState = BaseModule.a.level.getBlockState(blockHit.getBlockPos());
                            Object[] objectArray = new Object[2];
                            objectArray[1] = l3;
                            objectArray[0] = blockState;
                            this.a(objectArray);
                        }
                        mc = BaseModule.a;
                    }
                    if (string == null) break block18;
                    bl = mc.options.keyAttack.isDown();
                }
                if (!bl) break block19;
                mc = BaseModule.a;
            }
            if (mc.crosshairPickEntity != null) {
                Object[] objectArray = new Object[1];
                objectArray[0] = l2;
                this.b(objectArray);
            }
        }
    }

    private void a(Object[] objectArray) {
        block12: {
            int n2;
            int bestSlot;
            Inventory inventory;
            block7: {
                BlockState blockState = (BlockState)objectArray[0];
                long l2 = (Long)objectArray[1];
                l2 = m ^ l2;
                inventory = BaseModule.a.player.getInventory();
                String string = am.b();
                bestSlot = -1;
                float bestSpeed = 1.0f;
                int slot = 0;
                while (slot < AutoTool.c("e", (int)3175, (long)(0x227E4D6A7C5CB468L ^ l2))) {
                    String string2;
                    block10: {
                        block11: {
                            block9: {
                                ItemStack stack;
                                block8: {
                                    ItemStack stackCopy;
                                    stack = stackCopy = inventory.getItem(slot);
                                    if (string == null) break block8;
                                    n2 = stack.isEmpty() ? 1 : 0;
                                    if (l2 <= 0L || string == null) break block7;
                                    if (n2 != 0 && l2 >= 0L) break block9;
                                    stack = stackCopy;
                                }
                                float speed = stack.getDestroySpeed(blockState);
                                string2 = string;
                                if (l2 < 0L) break block10;
                                if (string2 == null) break block11;
                                if (speed > bestSpeed) {
                                    bestSpeed = speed;
                                    bestSlot = slot;
                                }
                            }
                            ++slot;
                        }
                        string2 = string;
                    }
                    if (string2 != null) continue;
                }
                if (l2 <= 0L) break block12;
                n2 = bestSlot;
            }
            if (n2 != -1) {
                inventory.setSelectedSlot(bestSlot);
            }
        }
    }

    private void b(Object[] objectArray) {
        block15: {
            int n2;
            int bestSlot;
            Inventory inventory;
            block10: {
                long l2 = (Long)objectArray[0];
                l2 = m ^ l2;
                inventory = BaseModule.a.player.getInventory();
                String string = am.b();
                bestSlot = -1;
                double bestDamage = 0.0;
                for (int slot = 0; slot < AutoTool.c("e", (int)6345, (long)(0x56D05E09BAAFE008L ^ l2)); ++slot) {
                    String string2;
                    double d3;
                    double attackDamage;
                    block11: {
                        block12: {
                            ItemStack stack;
                            Object object = stack = inventory.getItem(slot);
                            if (string != null) {
                                n2 = object.isEmpty() ? 1 : 0;
                                if (l2 < 0L || string == null) break block10;
                                if (n2 != 0 && l2 >= 0L) continue;
                                object = stack.get(DataComponents.ATTRIBUTE_MODIFIERS);
                            }
                            ItemAttributeModifiers modifiers = (ItemAttributeModifiers)object;
                            double d5 = 0.0;
                            do {
                                block14: {
                                    ItemAttributeModifiers modifiersCopy;
                                    block13: {
                                        attackDamage = d5;
                                        modifiersCopy = modifiers;
                                        if (string == null) break block13;
                                        if (modifiersCopy == null) break block14;
                                        modifiersCopy = modifiers;
                                    }
                                    for (ItemAttributeModifiers.mc9287 modifier : modifiersCopy.comp_2393()) {
                                        Holder attribute = modifier.comp_2395();
                                        d3 = (double)attribute.equals((Object)Attributes.ATTACK_DAMAGE);
                                        string2 = string;
                                        if (l2 <= 0L) break block11;
                                        if (string2 != null) {
                                            if (d3 != false) {
                                                attackDamage += modifier.comp_2396().comp_2449();
                                            }
                                            if (string != null) continue;
                                        }
                                        break block12;
                                    }
                                }
                                d5 = attackDamage;
                            } while (l2 <= 0L);
                            double d6 = d5 - bestDamage;
                            d3 = d6 == 0.0 ? 0 : (d6 > 0.0 ? 1 : -1);
                        }
                        string2 = string;
                    }
                    if (string2 != null) {
                        if (d3 <= 0) continue;
                        bestDamage = attackDamage;
                        d3 = slot;
                    }
                    bestSlot = (int)d3;
                    if (string != null) continue;
                }
                if (l2 <= 0L) break block15;
                n2 = bestSlot;
            }
            if (n2 != -1) {
                inventory.setSelectedSlot(bestSlot);
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        t = new Object[17];
        u = new String[17];
        AutoTool.c();
        p = new HashMap(13);
        long l2 = m ^ 0x1DADC118970FL;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l2 >>> 56);
        for (int i2 = 1; i2 < 8; ++i2) {
            byArray2 = byArray2;
            byArray2[i2] = (byte)(l2 << i2 * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
        String[] stringArray = new String[2];
        int n2 = 0;
        String string = "\t\u00bb\u0013\u00cf@\u000e\u0085\u0016@;4D\rX\t\u00f7\u00caI\u00ff\u008bq\u00c9)d7\u00c6\u00da0<\u00d4\u00eduX\u001f\u00ba\u0015W\u00a4`\u001e\u0089\u00ec/\u00c6k\u00bc\u0001kZ\u00a4\u00c9\u00f0;\u00c13\u00b7\u00a0\u001a\u00f4`\u00df\u00e6\u00b2E\u00e8M\t\u00ab\u00fa\u001e\u00a3F\u00bd\u00b4*\u00a7q\u00b2\u00f2\u00eaL\u00a3\u001c.\u00b1'[\u00156|\u0091G\u0091$\u00bb \f\u00ee~r)\u000f-ej\u0014B\f\u00e2\u00cd\u0011\u00e1K\u00a9+\u00caV\u008b\u0005\u0085\"";
        int n3 = "\t\u00bb\u0013\u00cf@\u000e\u0085\u0016@;4D\rX\t\u00f7\u00caI\u00ff\u008bq\u00c9)d7\u00c6\u00da0<\u00d4\u00eduX\u001f\u00ba\u0015W\u00a4`\u001e\u0089\u00ec/\u00c6k\u00bc\u0001kZ\u00a4\u00c9\u00f0;\u00c13\u00b7\u00a0\u001a\u00f4`\u00df\u00e6\u00b2E\u00e8M\t\u00ab\u00fa\u001e\u00a3F\u00bd\u00b4*\u00a7q\u00b2\u00f2\u00eaL\u00a3\u001c.\u00b1'[\u00156|\u0091G\u0091$\u00bb \f\u00ee~r)\u000f-ej\u0014B\f\u00e2\u00cd\u0011\u00e1K\u00a9+\u00caV\u008b\u0005\u0085\"".length();
        int n4 = 32;
        int n5 = -1;
        while (true) {
            int n6 = ++n5;
            byte[] byArray3 = cipher.doFinal(string.substring(n6, n6 + n4).getBytes("ISO-8859-1"));
            stringArray[n2++] = AutoTool.b(byArray3).intern();
            if ((n5 += n4) >= n3) break;
            n4 = string.charAt(n5);
        }
        n = stringArray;
        o = new String[2];
        s = new HashMap(13);
        Cipher cipher2 = Cipher.getInstance("DES/CBC/NoPadding");
        SecretKeyFactory secretKeyFactory2 = SecretKeyFactory.getInstance("DES");
        byte[] byArray4 = new byte[8];
        byte[] byArray5 = byArray4;
        byArray4[0] = (byte)(l2 >>> 56);
        for (int i3 = 1; i3 < 8; ++i3) {
            byArray5 = byArray5;
            byArray5[i3] = (byte)(l2 << i3 * 8 >>> 56);
        }
        cipher2.init(2, (Key)secretKeyFactory2.generateSecret(new DESKeySpec(byArray5)), new IvParameterSpec(new byte[8]));
        long[] lArray = new long[2];
        int n7 = 0;
        String string2 = "\u00a4\u00e3n\u007f\u00bf\u00fe\u0092\u00d8\u00ec\u00e3]\u00dc\u00bd\u00ecy\u00c0";
        int n8 = "\u00a4\u00e3n\u007f\u00bf\u00fe\u0092\u00d8\u00ec\u00e3]\u00dc\u00bd\u00ecy\u00c0".length();
        int n9 = 0;
        do {
            byte[] byArray6 = string2.substring(n9, n9 += 8).getBytes("ISO-8859-1");
            int n10 = n7++;
            long l3 = ((long)byArray6[0] & 0xFFL) << 56 | ((long)byArray6[1] & 0xFFL) << 48 | ((long)byArray6[2] & 0xFFL) << 40 | ((long)byArray6[3] & 0xFFL) << 32 | ((long)byArray6[4] & 0xFFL) << 24 | ((long)byArray6[5] & 0xFFL) << 16 | ((long)byArray6[6] & 0xFFL) << 8 | (long)byArray6[7] & 0xFFL;
            byte[] byArray7 = cipher2.doFinal(new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3});
            lArray[n10] = ((long)byArray7[0] & 0xFFL) << 56 | ((long)byArray7[1] & 0xFFL) << 48 | ((long)byArray7[2] & 0xFFL) << 40 | ((long)byArray7[3] & 0xFFL) << 32 | ((long)byArray7[4] & 0xFFL) << 24 | ((long)byArray7[5] & 0xFFL) << 16 | ((long)byArray7[6] & 0xFFL) << 8 | (long)byArray7[7] & 0xFFL;
        } while (n9 < n8);
        q = lArray;
        r = new Integer[2];
    }

    private static r a(r r2) {
        return r2;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x4AAA;
        if (r[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = q[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])s.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    s.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/e/F", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            AutoTool.r[n3] = n4;
        }
        return r[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = AutoTool.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/e/F" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static void c() {
        Object[] objectArray = t;
        t[0] = "\u0012\u0002#Zo\u0003\u0019\u0002'Zo@";
        objectArray[1] = "l4\u0018,\u001f\u0005g;\tcb\u001dt<\u0000*";
        objectArray[2] = ">T\u00127e`5T\u0019";
        objectArray[3] = "d\u000e\u001b^82d\u000e\f\u00024=~E\f\u001c4(y4\\Ae";
        objectArray[4] = "'EQ\bCu,EU\bd";
        objectArray[5] = "vg1{\u007f\u007fzg\"";
        objectArray[6] = "`vUI\t\u0011\u0015V^F\u0018^tXUM\u001c\u0004\u0000";
        objectArray[7] = Void.TYPE;
        AutoTool.u[7] = "java/lang/Void";
        objectArray[8] = "<&wx3iI\u0006|w\"&(\bw|&|\\";
        objectArray[9] = "@\u0017\re\u001bnK\u0017\u0005";
        objectArray[10] = "Y\u0019\u0007i\u0006ER\u0016\u0016&gKY\u001d\u0012|";
        objectArray[11] = "\u0010TYE~-_\u0014\u0003\u001fEDjdh8\u001f\u001c\u0010TYE~-_\u0014\u0003\u001f";
        objectArray[12] = "C;{b}L\u000f5\u000b6F\u001c\u0017:o=#\u0019\u00023v\\";
        objectArray[13] = "T~\nwu\u001a\u00137\bs\n\u0017n}Pp2\u001b\ry\\'v";
        objectArray[14] = "NxVY\bJ\u001dcJKu\u001bt8]\u0016\u001aM\u0013iC\u0016\u001arOx\u001bDJ\u0015\u001ef\u001bDu";
        objectArray[15] = "\u0016\u00052Ms\u0005E\u001e._\u000eT,C$N`\rWE>R4=\u0011D#Zm[VC O\u000e";
        Object[] objectArray2 = objectArray;
        objectArray[16] = "mI\u0003,X<>R\u001f>%nW\u000f\u0015/K4,\t\u000f3\u001f\u0004j\b\u0012;Fb-\u000f\u0011.%";
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = AutoTool.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = AutoTool.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = AutoTool.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = AutoTool.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(AutoTool.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

