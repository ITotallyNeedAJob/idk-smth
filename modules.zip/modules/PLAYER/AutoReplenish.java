// === Kuzi module: AutoReplenish ===
// Category   : PLAYER
// Description: Automatically moves the next stack of the same item into your hotbar when you use the last one.
// Payload    : a.a.a.j.e.D (verified: False)

package kuzi.modules.player;

import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.b.v;
import kuzi.obf.j.e.am;
import kuzi.obf.m.r;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.Player;
import net.minecraft.ClickType;
import net.minecraft.BlockItem;
import net.minecraft.ItemStack;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class AutoReplenish
extends BaseModule {
    private final SliderSetting threshold;
    private final BoolSetting onlyHotbar;
    private final BoolSetting onlyBlocks;
    private int delayTicks;
    private int trackedSlot;
    private int swapState;
    private int s;
    private int t;
    private int cooldownTicks;
    private static final long v;
    private static final String[] w;
    private static final String[] x;
    private static final Map y;
    private static final long[] z;
    private static final Integer[] A;
    private static final Map B;
    private static final Object[] C;
    private static final String[] D;

    public AutoReplenish() {
        long l2 = v ^ 0x47EF533ABBDEL;
        long l3 = l2 ^ 0x1090B22447BEL;
        super("AutoReplenish", "Automatically moves the next stack of the same item into your hotbar when you use the last one.", Category.PLAYER);
        this.threshold = new SliderSetting("Threshold", 1.0, 1.0, 64.0, 1.0);
        this.onlyHotbar = new BoolSetting("Only Hotbar", true);
        this.onlyBlocks = new BoolSetting("Only Blocks", false);
        this.delayTicks = 0;
        this.trackedSlot = -1;
        this.swapState = 0;
        this.s = -1;
        this.t = -1;
        this.cooldownTicks = 0;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.threshold, this.onlyHotbar, this.onlyBlocks};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        super.d();
        this.delayTicks = 0;
        this.trackedSlot = -1;
        this.swapState = 0;
        this.s = -1;
        this.t = -1;
        this.cooldownTicks = 0;
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public void i() {
        block52: {
            block53: {
                block40: {
                    block41: {
                        block48: {
                            block51: {
                                block50: {
                                    block49: {
                                        block47: {
                                            block29: {
                                                block44: {
                                                    block42: {
                                                        block43: {
                                                            block38: {
                                                                block39: {
                                                                    block34: {
                                                                        block35: {
                                                                            block37: {
                                                                                block36: {
                                                                                    block33: {
                                                                                        block31: {
                                                                                            block32: {
                                                                                                block30: {
                                                                                                    v0 = var1_1 = AutoReplenish.v ^ 5540549822356L;
                                                                                                    var3_2 = v0 ^ 109558352175423L;
                                                                                                    var5_3 = v0 ^ 63570519260243L;
                                                                                                    var7_4 = v0 ^ 135468514610717L;
                                                                                                    var9_5 = v0 ^ 101847660143966L;
                                                                                                    var11_6 = v0 ^ 106859616170530L;
                                                                                                    var13_7 = am.b();
                                                                                                    v1 = BaseModule.a;
                                                                                                    if (var13_7 == null) break block30;
                                                                                                    if (v1.player == null) break block31;
                                                                                                    v1 = BaseModule.a;
                                                                                                }
                                                                                                if (var13_7 == null) break block32;
                                                                                                if (v1.level == null) break block31;
                                                                                                v1 = BaseModule.a;
                                                                                            }
                                                                                            if (v1.gameMode != null) break block33;
                                                                                        }
                                                                                        return;
                                                                                    }
                                                                                    v2 = this.swapState;
                                                                                    if (var13_7 == null) break block34;
                                                                                    if (v2 <= 0) break block35;
                                                                                    v3 = this;
                                                                                    if (var13_7 == null) break block36;
                                                                                    if (v3.cooldownTicks <= 0) break block37;
                                                                                    v3 = this;
                                                                                }
                                                                                --v3.cooldownTicks;
                                                                                return;
                                                                            }
                                                                            var14_8 = BaseModule.a.player.inventoryMenu;
                                                                            var15_10 = var14_8.containerId;
                                                                            v4 = this;
                                                                            if (var13_7 == null) ** GOTO lbl42
                                                                            switch (v4.r) {
                                                                                case 1: {
                                                                                    BaseModule.a.execute((Runnable)LambdaMetafactory.metafactory(null, null, null, ()V, lambda$onTick$0(int long ), ()V)((AutoReplenish)this, (int)var15_10, (long)var7_4));
                                                                                    this.swapState = 2;
                                                                                    v4 = this;
lbl42:
                                                                                    // 2 sources

                                                                                    v4.cooldownTicks = 2;
                                                                                    if (var13_7 != null) break;
                                                                                }
                                                                                case 2: {
                                                                                    BaseModule.a.execute((Runnable)LambdaMetafactory.metafactory(null, null, null, ()V, lambda$onTick$1(int long ), ()V)((AutoReplenish)this, (int)var15_10, (long)var3_2));
                                                                                    this.swapState = 3;
                                                                                    this.cooldownTicks = 2;
                                                                                    if (var13_7 != null) break;
                                                                                }
                                                                                case 3: {
                                                                                    BaseModule.a.execute((Runnable)LambdaMetafactory.metafactory(null, null, null, ()V, lambda$onTick$2(long int ), ()V)((AutoReplenish)this, (long)var5_3, (int)var15_10));
                                                                                    this.swapState = 0;
                                                                                    this.delayTicks = 5;
                                                                                    break;
                                                                                }
                                                                            }
                                                                            return;
                                                                        }
                                                                        v2 = this.delayTicks;
                                                                    }
                                                                    if (var13_7 != null) {
                                                                        if (v2 > 0) {
                                                                            --this.delayTicks;
                                                                            return;
                                                                        }
                                                                        v2 = BaseModule.a.player.getInventory().getSelectedSlot();
                                                                    }
                                                                    var14_9 = v2;
                                                                    var15_11 = BaseModule.a.player.getMainHandItem();
                                                                    v5 = var15_11.isEmpty();
                                                                    if (var13_7 == null) break block38;
                                                                    if (v5 != 0) break block39;
                                                                    v6 = var15_11.getCount();
                                                                    v7 = ((Double)this.threshold.a()).intValue();
                                                                    if (var13_7 == null) break block40;
                                                                    if (v6 > v7) break block41;
                                                                }
                                                                v5 = -1;
                                                            }
                                                            var16_12 = v5;
                                                            v8 = var15_11.isEmpty();
                                                            if (var13_7 == null) break block42;
                                                            if (v8 != 0) break block43;
                                                            v9 = new Object[3];
                                                            v9[2] = var9_5;
                                                            v9[1] = var14_9;
                                                            v9[0] = var15_11;
                                                            var16_12 = this.a(v9);
                                                            if (var13_7 != null) break block44;
                                                        }
                                                        v8 = var17_13 = 0;
                                                    }
                                                    while (var17_13 < 9) {
                                                        block46: {
                                                            block45: {
                                                                v10 = var17_13;
                                                                v11 = var14_9;
                                                                if (var13_7 == null) break block29;
                                                                if (v10 == v11) break block45;
                                                                var18_14 = BaseModule.a.player.getInventory().getItem(var17_13);
                                                                if (var13_7 == null) break block46;
                                                                if (!var18_14.isEmpty()) {
                                                                    v12 = new Object[3];
                                                                    v12[2] = var9_5;
                                                                    v12[1] = var14_9;
                                                                    v12[0] = var18_14;
                                                                    var16_12 = this.a(v12);
                                                                    if (var13_7 != null) {
                                                                        if (var16_12 != -1) break;
                                                                    } else {
                                                                        ** GOTO lbl106
                                                                    }
                                                                }
                                                                break block45;
lbl106:
                                                                // 2 sources

                                                                break block46;
                                                            }
                                                            ++var17_13;
                                                        }
                                                        if (var13_7 != null) continue;
                                                    }
                                                }
                                                v10 = var16_12;
                                                v11 = -1;
                                            }
                                            if (var13_7 == null) break block47;
                                            if (v10 == v11) break block48;
                                            v10 = var16_12;
                                            v11 = 9;
                                        }
                                        if (var13_7 == null) break block49;
                                        if (v10 >= v11) break block50;
                                        v10 = var16_12;
                                        v11 = var14_9;
                                    }
                                    if (v10 == v11) break block51;
                                    BaseModule.a.player.getInventory().setSelectedSlot(var16_12);
                                    this.delayTicks = 5;
                                    if (var13_7 != null) break block51;
                                }
                                v13 = new Object[3];
                                v13[2] = var14_9;
                                v13[1] = var16_12;
                                v13[0] = var11_6;
                                this.a(v13);
                            }
                            this.trackedSlot = var14_9;
                        }
                        if (var13_7 != null) break block52;
                    }
                    v6 = this.trackedSlot;
                    v7 = var14_9;
                }
                if (var13_7 == null) break block53;
                if (v6 != v7) break block52;
                v6 = var15_11.getCount();
                v7 = ((Double)this.threshold.a()).intValue();
            }
            if (v6 > v7) {
                this.trackedSlot = -1;
            }
        }
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private int a(Object[] var1_1) {
        block22: {
            var2_2 = (ItemStack)var1_1[0];
            var3_3 = (Integer)var1_1[1];
            var4_4 = (Long)var1_1[2];
            var6_5 = (var4_4 = AutoReplenish.v ^ var4_4) ^ 2596284766773L;
            var8_6 = am.b();
            v0 = var2_2.isEmpty();
            if (var8_6 != null) {
                if (v0 != 0) {
                    return -1;
                }
                v0 = ((Boolean)this.onlyBlocks.a()).booleanValue();
            }
            if (var8_6 != null) {
                if (v0 != 0) {
                    v0 = var2_2.getItem() instanceof BlockItem;
                    if (var8_6 != null) {
                        if (v0 == 0) {
                            return -1;
                        } else {
                            ** GOTO lbl-1000
                        }
                    }
                } else lbl-1000:
                // 3 sources

                {
                    v0 = var9_7 /* !! */  = 0;
                }
            }
            block0: while (var9_7 /* !! */  < AutoReplenish.c("n", (int)10532, (long)(1146301159592990648L ^ var4_4))) {
                v1 = var9_7 /* !! */ ;
                do {
                    block24: {
                        block25: {
                            block29: {
                                block26: {
                                    block27: {
                                        block28: {
                                            block23: {
                                                v2 /* !! */  = var3_3;
                                                if (var8_6 == null) ** GOTO lbl68
                                                if (v1 != v2 /* !! */ ) break block23;
                                                v3 = var8_6;
                                                if (var4_4 < 0L) break block24;
                                                if (v3 != null) break block25;
                                            }
                                            var10_8 = BaseModule.a.player.getInventory().getItem(var9_7 /* !! */ );
                                            v4 = var10_8.isEmpty();
                                            v5 = var8_6;
                                            if (var4_4 < 0L) break block26;
                                            if (v5 == null) break block27;
                                            if (v4 == 0) break block28;
                                            v3 = var8_6;
                                            if (var4_4 <= 0L) break block24;
                                            if (v3 != null) break block25;
                                        }
                                        v6 = new Object[3];
                                        v6[2] = var6_5;
                                        v6[1] = var2_2;
                                        v6[0] = var10_8;
                                        v4 = (int)this.a(v6);
                                    }
                                    v5 = var8_6;
                                }
                                if (v5 == null) break block29;
                                if (v4 == 0) break block25;
                                v4 = var9_7 /* !! */ ;
                            }
                            return v4;
                        }
                        ++var9_7 /* !! */ ;
                        v3 = var8_6;
                    }
                    if (v3 != null) continue block0;
                    v7 = (Boolean)this.onlyHotbar.a();
                } while (var4_4 <= 0L);
            }
            if (var8_6 == null) break block22;
            if (v7) ** GOTO lbl102
            var9_7 /* !! */  = (int)AutoReplenish.c("n", (int)5149, (long)(8306893586010614410L ^ var4_4));
            block2: while (true) {
                v1 = var9_7 /* !! */ ;
                v2 /* !! */  = (int)AutoReplenish.c("n", (int)2493, (long)(8130572993504360229L ^ var4_4));
lbl68:
                // 2 sources

                if (v1 >= v2 /* !! */ ) ** GOTO lbl102
                do {
                    block33: {
                        block34: {
                            block35: {
                                block30: {
                                    block31: {
                                        block32: {
                                            var10_8 = BaseModule.a.player.getInventory().getItem(var9_7 /* !! */ );
                                            v8 = (int)var10_8.isEmpty();
                                            v9 = var8_6;
                                            if (var4_4 > 0L) {
                                                if (v9 == null) break block22;
                                                v9 = var8_6;
                                            }
                                            if (var4_4 <= 0L) break block30;
                                            if (v9 == null || var4_4 < 0L) break block31;
                                            if (v8 == 0) break block32;
                                            v10 = var8_6;
                                            if (var4_4 < 0L) break block33;
                                            if (v10 != null) break block34;
                                        }
                                        v11 = new Object[3];
                                        v11[2] = var6_5;
                                        v11[1] = var2_2;
                                        v11[0] = var10_8;
                                        v12 /* !! */  = (int)this.a(v11);
                                    }
                                    v9 = var8_6;
                                }
                                if (v9 == null) break block35;
                                if (v12 /* !! */  == false) break block34;
                                v12 /* !! */  = var9_7 /* !! */ ;
                            }
                            return v12 /* !! */ ;
                        }
                        ++var9_7 /* !! */ ;
                        v10 = var8_6;
                    }
                    if (v10 != null) continue block2;
lbl102:
                    // 3 sources

                } while (var4_4 < 0L);
                break;
            }
            v8 = -1;
        }
        return v8;
    }

    private boolean a(Object[] objectArray) {
        ItemStack mc17992;
        ItemStack mc17993;
        block4: {
            ItemStack mc17994;
            block5: {
                boolean bl;
                block2: {
                    block3: {
                        mc17994 = (ItemStack)objectArray[0];
                        mc17993 = (ItemStack)objectArray[1];
                        long l2 = (Long)objectArray[2];
                        l2 = v ^ l2;
                        String string = am.b();
                        bl = mc17994.isEmpty();
                        if (string == null) break block2;
                        if (bl) break block3;
                        mc17992 = mc17993;
                        if (l2 <= 0L || string == null) break block4;
                        if (!mc17992.isEmpty()) break block5;
                    }
                    bl = false;
                }
                return bl;
            }
            mc17992 = mc17994;
        }
        return mc17992.getItem() == mc17993.getItem();
    }

    /*
     * Unable to fully structure code
     */
    private void a(Object[] var1_1) {
        block22: {
            block21: {
                block20: {
                    block19: {
                        block18: {
                            var3_2 = (Long)var1_1[0];
                            var5_3 = (Integer)var1_1[1];
                            var2_4 = (Integer)var1_1[2];
                            var3_2 = AutoReplenish.v ^ var3_2;
                            var6_5 = AutoReplenish.d("c", (long)8480370344855388210L, (long)var3_2);
                            try {
                                try {
                                    try {
                                        v0 = var5_3;
                                        v1 = AutoReplenish.c("n", (int)5149, (long)(8306957841685478902L ^ var3_2));
                                        if (var6_5 == null) break block18;
                                        if (v0 >= v1) {
                                        }
                                        ** GOTO lbl47
                                    }
                                    catch (r v2) {
                                        throw AutoReplenish.d("c", (Object)v2, (long)8484228739184148217L, (long)var3_2);
                                    }
                                    v0 = var5_3;
                                    v3 = var6_5;
                                    if (var3_2 >= 0L) {
                                        if (v3 == null) break block19;
                                    }
                                    ** GOTO lbl37
                                }
                                catch (r v4) {
                                    throw AutoReplenish.d("c", (Object)v4, (long)8484228739184148217L, (long)var3_2);
                                }
                                v1 = AutoReplenish.c("n", (int)9733, (long)(4535870047272292326L ^ var3_2));
                            }
                            catch (r v5) {
                                throw AutoReplenish.d("c", (Object)v5, (long)8484228739184148217L, (long)var3_2);
                            }
                        }
                        if (v0 >= v1) ** GOTO lbl47
                        v0 = var2_4;
                    }
                    try {
                        if (var3_2 <= 0L) break block20;
                        v3 = var6_5;
lbl37:
                        // 2 sources

                        if (v3 == null) break block20;
                        if (v0 >= 0) {
                        }
                        ** GOTO lbl47
                    }
                    catch (r v6) {
                        throw AutoReplenish.d("c", (Object)v6, (long)8484228739184148217L, (long)var3_2);
                    }
                    v0 = var2_4;
                }
                try {
                    if (v0 < AutoReplenish.c("n", (int)5149, (long)(8306957841685478902L ^ var3_2))) break block21;
lbl47:
                    // 4 sources

                    return;
                }
                catch (r v7) {
                    throw AutoReplenish.d("c", (Object)v7, (long)8484228739184148217L, (long)var3_2);
                }
            }
            try {
                if (var3_2 <= 0L) break block22;
                if (AutoReplenish.d("\u00e1", (long)8481291764077284421L, (long)var3_2).player.inventoryMenu == null) {
                    return;
                }
            }
            catch (r v8) {
                throw AutoReplenish.d("c", (Object)v8, (long)8484228739184148217L, (long)var3_2);
            }
            AutoReplenish.d("n", (Object)this, (int)var5_3, (long)8480305327076708893L, (long)var3_2);
            AutoReplenish.d("n", (Object)this, (int)(AutoReplenish.c("n", (int)9733, (long)(4535870047272292326L ^ var3_2)) + var2_4), (long)8480506783754410904L, (long)var3_2);
            AutoReplenish.d("n", (Object)this, (int)1, (long)8480818091633917604L, (long)var3_2);
            AutoReplenish.d("n", (Object)this, (int)0, (long)8480636015787069000L, (long)var3_2);
        }
    }

    private void lambda$onTick$2(long l2, int n2) {
        l2 = v ^ l2;
        BaseModule.a.gameMode.handleInventoryMouseClick(n2, this.s, 0, ClickType.PICKUP, (Player)BaseModule.a.player);
    }

    private void lambda$onTick$1(int n2, long l2) {
        l2 = v ^ l2;
        BaseModule.a.gameMode.handleInventoryMouseClick(n2, this.t, 0, ClickType.PICKUP, (Player)BaseModule.a.player);
    }

    private void lambda$onTick$0(int n2, long l2) {
        l2 = v ^ l2;
        BaseModule.a.gameMode.handleInventoryMouseClick(n2, this.s, 0, ClickType.PICKUP, (Player)BaseModule.a.player);
    }

    /*
     * Unable to fully structure code
     */
    static {
        block21: {
            block20: {
                block19: {
                    block18: {
                        AutoReplenish.v = kuzi.obf.h.b.v.a(-5403749805471849242L, -1734228289578492975L, MethodHandles.lookup().lookupClass()).a(130437136957642L);
                        AutoReplenish.C = new Object[36];
                        AutoReplenish.D = new String[36];
                        AutoReplenish.c();
                        AutoReplenish.y = new HashMap<K, V>(13);
                        var11 = AutoReplenish.v ^ 108629924543842L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[5];
                        var18_4 = 0;
                        var17_5 = "\u00d7@\u00a6^;D\u00b4\u001eJ*WS\u000e\u00ee\n\u000e\u001agU\u00ccy\u0094\u0094\u00fa\u0018\u0093\u00bac\u001a\u00ef\u00c5\u00f1\u009000\u00c5]\u00fc`<\u00a4\u0012Dg9\u00f3r\u00ef\u00f1\u0090\u00eb\\\u00f0mJ\u0005\u009eX\u00cf\f\u00cf\u00bei\u0090\u00c2\u00a1\u00f5\u00e8\u00b60\u00cf]\u00fdmm\u008d\u0001(\u00b6\u00b8\u00df\u0088\u0084e\u00b4u\u00ad'\u00d5l\u0087\u00d0\u0011\u00f0\u00f5\u00fd>\u00f5\u0002n\u00bbD\u008bt\t\u00ea\u0005\u00bbM\u00c9\u001b\u0092pf\u009f\u008a\u00b3\u0019\u008a\u0012\u00d2\u00be\u00a9E\u00bf\u008dp\u009b\u00ffby\u00aa\u008cR\u00f0E\u00bf~\u009bQ\n;\u009e\u00fd\u008b\u00f1\u0089\u00d2\u0080\u00d1\f(SG\u00a3\u00f3f\u0083\u000b|\u00e4\u00f0kZj\u00a7u\u001e\u0010\u00c1^\u00cc/)\u00e3d\n`&I\u00b1\u001d\u0083\u00de\u00f5\u00f4\u0090Rw\u00f0<r#\u00f5";
                        var19_6 = "\u00d7@\u00a6^;D\u00b4\u001eJ*WS\u000e\u00ee\n\u000e\u001agU\u00ccy\u0094\u0094\u00fa\u0018\u0093\u00bac\u001a\u00ef\u00c5\u00f1\u009000\u00c5]\u00fc`<\u00a4\u0012Dg9\u00f3r\u00ef\u00f1\u0090\u00eb\\\u00f0mJ\u0005\u009eX\u00cf\f\u00cf\u00bei\u0090\u00c2\u00a1\u00f5\u00e8\u00b60\u00cf]\u00fdmm\u008d\u0001(\u00b6\u00b8\u00df\u0088\u0084e\u00b4u\u00ad'\u00d5l\u0087\u00d0\u0011\u00f0\u00f5\u00fd>\u00f5\u0002n\u00bbD\u008bt\t\u00ea\u0005\u00bbM\u00c9\u001b\u0092pf\u009f\u008a\u00b3\u0019\u008a\u0012\u00d2\u00be\u00a9E\u00bf\u008dp\u009b\u00ffby\u00aa\u008cR\u00f0E\u00bf~\u009bQ\n;\u009e\u00fd\u008b\u00f1\u0089\u00d2\u0080\u00d1\f(SG\u00a3\u00f3f\u0083\u000b|\u00e4\u00f0kZj\u00a7u\u001e\u0010\u00c1^\u00cc/)\u00e3d\n`&I\u00b1\u001d\u0083\u00de\u00f5\u00f4\u0090Rw\u00f0<r#\u00f5".length();
                        var16_7 = 24;
                        var15_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block18;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = AutoReplenish.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "\u00ed\u001d\u00ca\u00b8oQS\u00f3\u00f6\u00920i}\u00da\u00e8\u00f9\u00b4\u00a5G\u00d4A\u009an\u00e23B\u00c1\u0082w\u00bfl\u009e U\u00bf\u00db[q\u00e2\u0091\u008ccgn\u00b7\u0085v\u00d0\u0014\u008a\u00bb\u00c9%QA\u00b9;a3\u0005\u00dfD\u0080\u00a0\u008c";
                            var19_6 = "\u00ed\u001d\u00ca\u00b8oQS\u00f3\u00f6\u00920i}\u00da\u00e8\u00f9\u00b4\u00a5G\u00d4A\u009an\u00e23B\u00c1\u0082w\u00bfl\u009e U\u00bf\u00db[q\u00e2\u0091\u008ccgn\u00b7\u0085v\u00d0\u0014\u008a\u00bb\u00c9%QA\u00b9;a3\u0005\u00dfD\u0080\u00a0\u008c".length();
                            var16_7 = 32;
                            var15_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block18;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = AutoReplenish.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block19;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                AutoReplenish.w = var20_3;
                AutoReplenish.x = new String[5];
                AutoReplenish.B = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[9];
                var3_13 = 0;
                var4_14 = "Q\u00c0o=/!-'\u0006/p\u00a5\u0082\u00c8\u008aX\n\u0081\u0085\u00d5Y\u00b6\u00acC\u009f{\u00b96O\u00c7Z\u0090?\u00e6\u0082\u00e0\u00eb#\u00b0V{\u0014\u0097\u00a6\u0090S\u0097Kw\u00a8\u00ce\u00d7z\u00e6\u00f6\u00df";
                var5_15 = "Q\u00c0o=/!-'\u0006/p\u00a5\u0082\u00c8\u008aX\n\u0081\u0085\u00d5Y\u00b6\u00acC\u009f{\u00b96O\u00c7Z\u0090?\u00e6\u0082\u00e0\u00eb#\u00b0V{\u0014\u0097\u00a6\u0090S\u0097Kw\u00a8\u00ce\u00d7z\u00e6\u00f6\u00df".length();
                var2_16 = 0;
                while (true) {
                    var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                    v10 = var6_12;
                    v11 = var3_13++;
                    v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                    v13 = -1;
                    break block20;
                    break;
                }
lbl81:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    var4_14 = "\u00e7\u00cf\u00e3\u00e5\u00f1v\u00derq<zz\u0015\u0094C\u0012";
                    var5_15 = "\u00e7\u00cf\u00e3\u00e5\u00f1v\u00derq<zz\u0015\u0094C\u0012".length();
                    var2_16 = 0;
                    while (true) {
                        var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                        v10 = var6_12;
                        v11 = var3_13++;
                        v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                        v13 = 0;
                        break block20;
                        break;
                    }
                    break;
                }
lbl94:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    break block21;
                    break;
                }
            }
            var8_18 = v12;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            v14 = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
            switch (v13) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl107:
                // 1 sources

                ** continue;
            }
        }
        AutoReplenish.z = var6_12;
        AutoReplenish.A = new Integer[9];
    }

    private static r a(r r2) {
        return r2;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x1C55;
        if (A[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = z[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])B.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    B.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/e/D", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            AutoReplenish.A[n3] = n4;
        }
        return A[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = AutoReplenish.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/e/D" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (D[n4] != null) {
            return n4;
        }
        Object object = C[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 61;
            case 1 -> 50;
            case 2 -> 47;
            case 3 -> 59;
            case 4 -> 34;
            case 5 -> 5;
            case 6 -> 30;
            case 7 -> 52;
            case 8 -> 58;
            case 9 -> 13;
            case 10 -> 45;
            case 11 -> 9;
            case 12 -> 6;
            case 13 -> 11;
            case 14 -> 42;
            case 15 -> 36;
            case 16 -> 18;
            case 17 -> 4;
            case 18 -> 62;
            case 19 -> 60;
            case 20 -> 27;
            case 21 -> 24;
            case 22 -> 44;
            case 23 -> 63;
            case 24 -> 43;
            case 25 -> 12;
            case 26 -> 31;
            case 27 -> 56;
            case 28 -> 57;
            case 29 -> 53;
            case 30 -> 51;
            case 31 -> 40;
            case 32 -> 29;
            case 33 -> 38;
            case 34 -> 19;
            case 35 -> 41;
            case 36 -> 32;
            case 37 -> 21;
            case 38 -> 25;
            case 39 -> 46;
            case 40 -> 35;
            case 41 -> 7;
            case 42 -> 54;
            case 43 -> 49;
            case 44 -> 20;
            case 45 -> 48;
            case 46 -> 1;
            case 47 -> 33;
            case 48 -> 15;
            case 49 -> 55;
            case 50 -> 16;
            case 51 -> 22;
            case 52 -> 0;
            case 53 -> 2;
            case 54 -> 3;
            case 55 -> 8;
            case 56 -> 23;
            case 57 -> 39;
            case 58 -> 17;
            case 59 -> 10;
            case 60 -> 28;
            case 61 -> 37;
            case 62 -> 14;
            default -> 26;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        AutoReplenish.D[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = C;
        C[0] = "\u0018Gg,RO\u0013Gl";
        objectArray[1] = "\ni |EX\ni7 IW\u0010\"7>IB\u0017Sgc\u0018";
        objectArray[2] = "\u00011z\u0002\u0014\b\n1~\u00021";
        objectArray[3] = Integer.TYPE;
        AutoReplenish.D[3] = "java/lang/Integer";
        objectArray[4] = "vjP\u001b>B}jT\u001b>\u0001";
        objectArray[5] = "\bRE@:\u0000\u0003]T\u000fG\u0018\u0010Z]F";
        objectArray[6] = "\u0011E\u0005]\u001bAde\u000eR\n\u000e\u0005k\u0005Y\u000eTq";
        objectArray[7] = "\u00172G>o\u0014\u001e2D>c";
        objectArray[8] = "yn_F\u0013\u0019pn\\F\u0013";
        objectArray[9] = "\u0000f\u0011k\u0001\u0012\u000bi\u0000$`\u001c\u0000b\u0004~";
        objectArray[10] = "\u001e\b\u001e+L;\u0012\b\r";
        objectArray[11] = "KTa\nU*>tj\u0005De_za\u000e@?+";
        objectArray[12] = Void.TYPE;
        AutoReplenish.D[12] = "java/lang/Void";
        objectArray[13] = "\u0000&8TV\u0003\t&;TT";
        objectArray[14] = ",\r\n`Eg'\r\u0002";
        objectArray[15] = "K9*k+>>\u0019!d:q_\u0017*o>++";
        objectArray[16] = "6\u001d|93\u001cC=w6\"S\"3|=&\tV";
        objectArray[17] = Boolean.TYPE;
        AutoReplenish.D[17] = "java/lang/Boolean";
        objectArray[18] = "H\u0014\u0016<l/\tJ\u0010;S9qDJ'+n\u001d\u0013\f29";
        objectArray[19] = "9\u007fN4'#/ NvC\u0018\u0014\u0007$\u0002\u0019@9\u007fN4'#/ Nv";
        objectArray[20] = "p|[J_i1\"]M`~I,\u0007Q\u0018(%{AD\n";
        objectArray[21] = "S8't\u007f\u0016\u0012f!s@\u000fj3-x>\u0019\u00045=j f\u00017;,.\u0002\u0006>)\u007f@";
        objectArray[22] = "Oua\u00056*\u000e+g\u0002\t\"v.o\nd?Jmj\tj";
        objectArray[23] = "E~F\u0006,h\u0017\u007f\u001288Q\u0011)\u001b\t?aX0\nH";
        objectArray[24] = "C\u0016kK\u000bL\u001fK9Rh\u001bx@dJ\u0017K\u0004\u0015{@\u0017q";
        objectArray[25] = "F\u0018RF\u0010{\u0007FTA/p\u007fC\\IBnC\u0000YJL";
        objectArray[26] = "s_Ma\u0011\u00002\u0001Kf.\fJ\u0004CnC\u0015vGFmM";
        objectArray[27] = "\u0013rR\u0007\\yR,T\u0000c`*yX\u000b\u001dvD\u007fH\u0019\u0003\t\u0010z[\u000b\u00065S\u007fX\u0005c";
        objectArray[28] = "Ln\u001c\u000f\n<\r0\u001a\b51u5\u0012\u0000X)Iv\u0017\u0003V";
        objectArray[29] = "+\u0017Ahs.jIGoL;\u0012JTg(;vNOkp";
        objectArray[30] = "\nJ=#Z\u0011K\u0014;$e\u001b3\u00113,\b\u0004\u000fR6/\u0006";
        objectArray[31] = "\u0005\u0018:#hlDF<$We<C4,:y\u0000\u00001/4";
        objectArray[32] = "_\u000bsC 9\u001a\b&I\u001b:a\u000f|H'(\u0018@vW%S";
        objectArray[33] = "\\f\t\u0010io\u001d8\u000f\u0017Vve8\u0002\u00166a\u0001h\n\u00110\u001fZk\t\u0011({\nc\u000e\u0017V";
        objectArray[34] = "\t\u0006?jl![\u0007kTu\u0018\u000eWo*nv\bG}4\u0011(\u000bUe*{r\u000bS9T";
        Object[] objectArray2 = objectArray;
        objectArray[35] = "_dpd6\r\u001e:vc\t\u0014fozhw\u0002\bijzi}Vjxbw\u0017\fj~>\t";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = AutoReplenish.e(l2, l3);
            object = C[n2];
            try {
                if (!(object instanceof String)) break block2;
                AutoReplenish.C[n2] = clazz = Class.forName(D[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = AutoReplenish.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = AutoReplenish.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = AutoReplenish.e(l2, l3);
        Object object = C[n2];
        if (object instanceof String) {
            String string = D[n2];
            int n3 = string.indexOf(8);
            Class clazz = AutoReplenish.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = AutoReplenish.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = AutoReplenish.c(clazz3, string2, clazz2)) != null) {
                    AutoReplenish.C[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = AutoReplenish.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        AutoReplenish.C[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = AutoReplenish.f(641499492751746L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = AutoReplenish.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = AutoReplenish.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = AutoReplenish.e(l2, l3);
        Object object = C[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = D[n2];
                int n4 = string2.indexOf(8);
                clazz3 = AutoReplenish.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = AutoReplenish.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = AutoReplenish.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        AutoReplenish.C[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = AutoReplenish.f(641499492751746L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = AutoReplenish.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        AutoReplenish.C[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = AutoReplenish.f(641499492751746L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == '\u00d3' || c2 == 'n' || c2 == '\u00e1' || c2 == 'F') {
                field = AutoReplenish.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == '\u00d3' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == 'n' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == '\u00e1' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = AutoReplenish.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == 'D' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == 'c' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = AutoReplenish.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/e/D" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(AutoReplenish.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(AutoReplenish.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

