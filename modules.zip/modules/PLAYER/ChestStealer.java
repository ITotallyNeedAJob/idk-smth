// === Kuzi module: ChestStealer ===
// Category   : PLAYER
// Description: Automatically loots chests
// Payload    : a.a.a.j.e.I (verified: False)

package kuzi.modules.player;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.module.Module;
import kuzi.obf.j.e.am;
import kuzi.obf.m.r;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.Player;
import net.minecraft.AbstractContainerMenu;
import net.minecraft.ChestMenu;
import net.minecraft.ClickType;
import net.minecraft.Slot;
import net.minecraft.ItemStack;
import net.minecraft.LocalPlayer;

public class ChestStealer
extends BaseModule
implements Module {
    private final SliderSetting delay;
    private long lastStealTime;
    private static final long o = 84688255152816L;
    private static final long s;
    private static final Object[] t;
    private static final String[] u;

    public ChestStealer() {
        long l2 = o ^ 0x1E3F21FDD05BL;
        long l3 = l2 ^ 0x72DA2FDD39FEL;
        super("Chest Stealer", "Automatically loots chests", Category.PLAYER);
        this.delay = new SliderSetting("Delay", 100.0, 0.0, 1000.0, 10.0);
        this.lastStealTime = 0L;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.delay};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        Client.a().a(Module.class, this);
        super.d();
    }

    @Override
    public void e() {
        Client.a().b(Module.class, this);
        super.e();
    }

    @Override
    public void b() {
        block11: {
            double slotIndex;
            AbstractContainerMenu menu;
            String string;
            block12: {
                AbstractContainerMenu containerMenu;
                string = am.b();
                LocalPlayer player = BaseModule.a.player;
                if (string != null) {
                    if (player == null) {
                        return;
                    }
                    player = BaseModule.a.player;
                }
                menu = containerMenu = player.containerMenu;
                if (string == null) break block12;
                if (!(menu instanceof ChestMenu)) break block11;
                menu = containerMenu;
            }
            ChestMenu chestMenu = (ChestMenu)menu;
            double elapsed = (double)(System.currentTimeMillis() - this.lastStealTime) - (Double)this.delay.a();
            double comparison = elapsed == 0.0 ? 0 : (elapsed < 0.0 ? -1 : 1);
            if (string != null) {
                if (comparison < 0) {
                    return;
                }
                comparison = slotIndex = 0.0;
            }
            while (slotIndex < chestMenu.getRowCount() * (int)s) {
                Slot slot = chestMenu.getSlot((int)slotIndex);
                ItemStack stack = slot.getItem();
                if (string != null) {
                    if (string != null) {
                        if (!stack.isEmpty()) {
                            BaseModule.a.gameMode.handleInventoryMouseClick(chestMenu.containerId, (int)slotIndex, 0, ClickType.QUICK_MOVE, (Player)BaseModule.a.player);
                            this.lastStealTime = System.currentTimeMillis();
                            return;
                        }
                        ++slotIndex;
                    }
                    if (string != null) continue;
                }
                break block11;
            }
            BaseModule.a.player.closeContainer();
        }
    }

    static {
        t = new Object[]{"\u0006\u001fl7[(\r\u001fh7s", "'\u0014e\bC~.\u0014f\bO", "\u001a'\u001c8{\u0002\u0011'\u00188{A", "I| hagBs1'\u001c\u007fQt8n", "e\u001cM9 \u0018n\u001cF", "\u001a 02EF\u001a 'nII\u0000k'pI\\\u0007\u001aw-\u0018", Long.TYPE, "oRZGA\u001fcRI", "h\b{j+va\bxj+", "\u001c\u007fD\r>\u0003\u0017pUB_\r\u001c{Q\u0018", "\u0011UjT\u0000y\u001aUb", "D:B\\8u1\u001aIS):P\u0014BX-`$", Void.TYPE, "T\t<\u0017\u0006.\u0013\u001e<\u000efK/*\u000b:<\u0013T\t<\u0017\u0006.\u0013\u001e<\u000e", "G5g\u0001\u001cABg&n@<\u000b y\u0017\u001bU\u0018\"\u007f", "\u0017p$\u0013C6\u0012bw[=c.**\u0010_n\\)wPM\t", "Y<\bA\nb\u001ev\u0011\u00197ocu\u001c\u0000MfY \u0012\u001cN", "\u0001H\u0019\u0012\u0011!\u0004\u001aX}A\\\u0003QS\u0003X3GYXE(`O\u001a\u0016\rG$G\u0011P}", "nX\u007f\u0003\u0017#1@pY.+S\u0017o\u0017\u001f}<\u0013/\u001dCB", "\u001bxS\u0006\u001c\u0000\\2J^!\u0000!:\u0017]Q\u001dH5D\u0005\u001bd\u0011rDR\\[YmTS!", "'(%yJ/\"zd\u0016\u0015R%9,)\u001a>x+kp"};
        u = new String[]{null, null, null, null, null, null, "java/lang/Long", null, null, null, null, null, "java/lang/Void", null, null, null, null, null, null, null, null};
        s = -5396393654556295159L;
    }

    private static r a(r r2) {
        return r2;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = ChestStealer.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = ChestStealer.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = ChestStealer.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = ChestStealer.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }
}

