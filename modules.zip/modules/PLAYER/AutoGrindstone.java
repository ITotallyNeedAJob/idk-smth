// === Kuzi module: AutoGrindstone ===
// Category   : PLAYER
// Description: Auto-disenchants/repairs items in an open grindstone.
// Payload    : a.a.a.j.e.z (verified: True)

package kuzi.modules.player;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.module.Module;
import kuzi.obf.h.b.l;
import kuzi.obf.h.b.v;
import kuzi.obf.j.e.am;
import kuzi.obf.j.e.d;
import kuzi.obf.m.r;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.Player;
import net.minecraft.ClickType;
import net.minecraft.ItemStack;
import net.minecraft.GrindstoneMenu;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class AutoGrindstone
extends BaseModule
implements Module {
    private static final int n;
    private final l source;
    private final BoolSetting takeOutput;
    private final SliderSetting delayMs;
    private long lastActionTime;
    private static final long s;
    private static final String[] t;
    private static final String[] u;
    private static final Map v;
    private static final long[] w;
    private static final Integer[] x;
    private static final Map y;
    private static final Object[] z;
    private static final String[] A;

    public AutoGrindstone() {
        long l2 = s ^ 0x2BD750CE2B97L;
        long l3 = l2 ^ 0x5E72CDB9E80L;
        super("AutoGrindstone", "Auto-disenchants/repairs items in an open grindstone.", Category.PLAYER);
        this.source = new l("Source", kuzi.obf.j.e.d.HELD, d.class);
        this.takeOutput = new BoolSetting("Take Output", true);
        this.delayMs = new SliderSetting("Delay (ms)", 120.0, 0.0, 1000.0, 10.0);
        this.lastActionTime = 0L;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.source, this.takeOutput, this.delayMs};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        Client.a().a(Module.class, this);
        super.d();
    }

    @Override
    public void e() {
        Client.a().b(Module.class, this);
        super.e();
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public void b() {
        block29: {
            block28: {
                block27: {
                    block26: {
                        block25: {
                            block23: {
                                block24: {
                                    block22: {
                                        block21: {
                                            var1_1 = AutoGrindstone.s ^ 26102940956358L;
                                            var3_2 = var1_1 ^ 108377099882690L;
                                            stringTable = am.b();
                                            mc = BaseModule.a;
                                            if (stringTable == null) break block21;
                                            if (mc.player == null) break block22;
                                            mc = BaseModule.a;
                                        }
                                        if (stringTable == null) break block23;
                                        if (mc.gameMode != null) break block24;
                                    }
                                    return;
                                }
                                mc = BaseModule.a;
                            }
                            menu = containerMenu = mc.player.containerMenu;
                            if (stringTable == null) break block25;
                            if (!(menu instanceof GrindstoneMenu)) break block26;
                            menu = containerMenu;
                        }
                        grindstoneMenu = (GrindstoneMenu)menu;
                        if (stringTable != null) break block27;
                    }
                    return;
                }
                delayDelta = (double)(System.currentTimeMillis() - this.lastActionTime) - (Double)this.delayMs.a();
                v2 = delayDelta == 0.0 ? 0 : (delayDelta < 0.0 ? -1 : 1);
                if (stringTable != null) {
                    if (v2 < 0) {
                        return;
                    }
                    v2 = (double)((Boolean)this.takeOutput.a()).booleanValue();
                }
                if (stringTable != null) {
                    if (v2 != false) {
                        v2 = (double)grindstoneMenu.getSlot(2).getItem().isEmpty();
                        if (stringTable != null) {
                            if (v2 == false) {
                                BaseModule.a.gameMode.handleInventoryMouseClick(grindstoneMenu.containerId, 2, 0, ClickType.QUICK_MOVE, (Player)BaseModule.a.player);
                                this.lastActionTime = System.currentTimeMillis();
                                return;
                            } else {
                                ** GOTO lbl-1000
                            }
                        }
                    } else lbl-1000:
                    // 3 sources

                    {
                        v2 = (double)grindstoneMenu.getSlot(0).getItem().isEmpty();
                    }
                }
                if (stringTable != null) {
                    if (v2 == false) {
                        return;
                    }
                    objectArray = new Object[2];
                    objectArray[1] = var3_2;
                    objectArray[0] = grindstoneMenu;
                    v2 = slotIndex = (double)this.a(objectArray);
                }
                if (stringTable == null) break block28;
                if (slotIndex == -1) break block29;
                BaseModule.a.gameMode.handleInventoryMouseClick(grindstoneMenu.containerId, (int)slotIndex, 0, ClickType.QUICK_MOVE, (Player)BaseModule.a.player);
            }
            this.lastActionTime = System.currentTimeMillis();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private int a(Object[] objectArray) {
        GrindstoneMenu menu = (GrindstoneMenu)objectArray[0];
        long l2 = (Long)objectArray[1];
        long l3 = (l2 = s ^ l2) ^ 0x1CE28CC0FA7AL;
        String stringTable = am.b();
        if (this.source.a() == kuzi.obf.j.e.d.HELD) {
            int heldSlot = menu.slots.size() - AutoGrindstone.c("o", (int)24327, (long)(0x3964EBF431B11FD7L ^ l2)) + BaseModule.a.player.getInventory().getSelectedSlot();
            Object[] objectArray2 = new Object[2];
            objectArray2[1] = menu.getSlot(heldSlot).getItem();
            objectArray2[0] = l3;
            int matchedSlot = this.a(objectArray2);
            if (stringTable == null) return matchedSlot;
            if (matchedSlot == 0) return -1;
            matchedSlot = heldSlot;
            return matchedSlot;
        }
        block0: for (int slot = 3; slot < menu.slots.size(); ++slot) {
            do {
                int foundSlot;
                Object[] objectArray3 = new Object[2];
                objectArray3[1] = menu.getSlot(slot).getItem();
                objectArray3[0] = l3;
                int isMatch = this.a(objectArray3) ? 1 : 0;
                String guard = stringTable;
                if (l2 >= 0L) {
                    if (guard == null) return isMatch;
                    guard = stringTable;
                }
                if (guard == null) return foundSlot;
                if (isMatch == 0) continue block0;
                foundSlot = slot;
                return foundSlot;
            } while (l2 < 0L);
        }
        return -1;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        ItemStack itemStack = (ItemStack)objectArray[1];
        l2 = s ^ l2;
        String stringTable = am.b();
        boolean matches = itemStack.isEmpty();
        if (stringTable != null) {
            if (matches) return false;
            matches = itemStack.isEnchanted();
        }
        if (stringTable == null) return matches;
        if (matches) return true;
        matches = itemStack.isDamaged();
        if (stringTable == null) return matches;
        if (!matches) return false;
        return true;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block16: {
            block15: {
                block14: {
                    block13: {
                        AutoGrindstone.s = kuzi.obf.h.b.v.a(9222863457300970210L, 6888475748544822063L, MethodHandles.lookup().lookupClass()).a(136694158716399L);
                        AutoGrindstone.z = new Object[33];
                        AutoGrindstone.A = new String[33];
                        AutoGrindstone.c();
                        AutoGrindstone.v = new HashMap<K, V>(13);
                        var11 = AutoGrindstone.s ^ 90953026472702L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[5];
                        var18_4 = 0;
                        var17_5 = "\u00ac\u00aaW\u00ed?h\u00e6\u0016\u00fb\u009d86-\u00db\u0010\u00e5\t\u001cK`g\u00f3\u00cdY1\u00db\u0082\u00e3>qQH \u001b\u009e\u001c;\u009a\u0091{\u0084\u0081\u008e\u00dc}\u00b8jH\u00814\u00c6\u0092\u0002w\u0086\u00be\u00b8\u00ec-\u00ba\u0096g\u00f4\u00cb\u0083P0\u008b\u00b5\u00c7\u00ce@\u00e1b[\u00d9\u00d9O\u009d\u00ff\u00e8Ee\u00fd\u00cc\u0089\u00dcR\u0011\u0010\u00e1V\u00f9\u00a6\u0000.s\u00ef?`\u009dt\u00c4\u008ecb\u001a\u00b8\u00bb\u00e4\u00f3\u00f6\u00a9xA\u00c8\u0006\u009fSDt}\u00a6*\u00e2\u00be|>\u0097\u00b8\u00e00\u009d~s\"\u0094\u00e5{\u009e\u00db\u00d5Y\u00b4\u00dc\u000b";
                        var19_6 = "\u00ac\u00aaW\u00ed?h\u00e6\u0016\u00fb\u009d86-\u00db\u0010\u00e5\t\u001cK`g\u00f3\u00cdY1\u00db\u0082\u00e3>qQH \u001b\u009e\u001c;\u009a\u0091{\u0084\u0081\u008e\u00dc}\u00b8jH\u00814\u00c6\u0092\u0002w\u0086\u00be\u00b8\u00ec-\u00ba\u0096g\u00f4\u00cb\u0083P0\u008b\u00b5\u00c7\u00ce@\u00e1b[\u00d9\u00d9O\u009d\u00ff\u00e8Ee\u00fd\u00cc\u0089\u00dcR\u0011\u0010\u00e1V\u00f9\u00a6\u0000.s\u00ef?`\u009dt\u00c4\u008ecb\u001a\u00b8\u00bb\u00e4\u00f3\u00f6\u00a9xA\u00c8\u0006\u009fSDt}\u00a6*\u00e2\u00be|>\u0097\u00b8\u00e00\u009d~s\"\u0094\u00e5{\u009e\u00db\u00d5Y\u00b4\u00dc\u000b".length();
                        var16_7 = 32;
                        var15_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block13;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = AutoGrindstone.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "\u00a1\u00ed?g\u00b9\f|\u00c4\nv\u001e.\u00dee\u0081G \u00e3\u00d6\u0017\u00a8\t.\u00f0]o\u00a4\u0092Q\u00d6\u00907}\u00fcZc{\u00bf4.S\u0083\u0092.q\u00a0\u00f3\u0099\u0006";
                            var19_6 = "\u00a1\u00ed?g\u00b9\f|\u00c4\nv\u001e.\u00dee\u0081G \u00e3\u00d6\u0017\u00a8\t.\u00f0]o\u00a4\u0092Q\u00d6\u00907}\u00fcZc{\u00bf4.S\u0083\u0092.q\u00a0\u00f3\u0099\u0006".length();
                            var16_7 = 16;
                            var15_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block13;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = AutoGrindstone.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block14;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                AutoGrindstone.t = var20_3;
                AutoGrindstone.u = new String[5];
                AutoGrindstone.y = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[2];
                var3_13 = 0;
                var4_14 = "\u00b7$\u0085\u007f\u00e3\u00e2_\u0094\u00017\u00d73\u00d6\u00dac\u0006";
                var5_15 = "\u00b7$\u0085\u007f\u00e3\u00e2_\u0094\u00017\u00d73\u00d6\u00dac\u0006".length();
                var2_16 = 0;
                while (true) {
                    break block15;
                    break;
                }
lbl76:
                // 1 sources

                while (true) {
                    var6_12[v10] = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
                    if (var2_16 < var5_15) ** continue;
                    break block16;
                    break;
                }
            }
            var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
            v10 = var3_13++;
            var8_18 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            ** while (true)
        }
        AutoGrindstone.w = var6_12;
        AutoGrindstone.x = new Integer[2];
        AutoGrindstone.n = 2;
    }

    private static r a(r r2) {
        return r2;
    }

    private static String b(byte[] byArray) {
        int charCount = 0;
        int length = byArray.length;
        char[] chars = new char[length];
        for (int index = 0; index < length; ++index) {
            char character;
            int byteValue = 0xFF & byArray[index];
            if (byteValue < 192) {
                chars[charCount++] = (char)byteValue;
                continue;
            }
            if (byteValue < 224) {
                character = (char)((char)(byteValue & 0x1F) << 6);
                byteValue = byArray[++index];
                character = (char)(character | (char)(byteValue & 0x3F));
                chars[charCount++] = character;
                continue;
            }
            if (index >= length - 2) continue;
            character = (char)((char)(byteValue & 0xF) << 12);
            byteValue = byArray[++index];
            character = (char)(character | (char)(byteValue & 0x3F) << 6);
            byteValue = byArray[++index];
            character = (char)(character | (char)(byteValue & 0x3F));
            chars[charCount++] = character;
        }
        return new String(chars, 0, charCount);
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x66D5;
        if (x[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = w[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])y.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    y.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/e/z", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            AutoGrindstone.x[n3] = n4;
        }
        return x[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = AutoGrindstone.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/e/z" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static void c() {
        Object[] objectArray = z;
        z[0] = "\\\r#\u0014\\3W\r'\u0014Y";
        objectArray[1] = ")\u0007ilj&\"\u0007a";
        objectArray[2] = "D\u007fVj\u001cZO\u007fRj\u0007";
        objectArray[3] = Long.TYPE;
        AutoGrindstone.A[3] = "java/lang/Long";
        objectArray[4] = "8h\u001bj&41h\u0018j+";
        objectArray[5] = "\u0018@zdA^\u0011@ydM";
        objectArray[6] = "\u001eHv?9]\u0017Hu?;";
        objectArray[7] = "\u0016L\u001dZ{(\u001dL\u0016";
        objectArray[8] = "w\u0019\u0019\u0010;4\u00029\u0012\u001f*{c7\u0019\u0014.!\u0017";
        objectArray[9] = Void.TYPE;
        AutoGrindstone.A[9] = "java/lang/Void";
        objectArray[10] = "\u0010\u0000g\u0005\u001aW\u001c\u0000t";
        objectArray[11] = "\\hy\rB(Wh}\rBk";
        objectArray[12] = "h!\u001c \nAc.\rowYp)\u0004&";
        objectArray[13] = "\u0011ERC^\b\u0011EE\u001fR\u0007\u000b\u000eE\u0001R\u0012\f\u007f\u0015\\\u0003";
        objectArray[14] = "o\u0017q\bE\f\u001a7z\u0007TC{9q\fP\u0019\u000f";
        objectArray[15] = Boolean.TYPE;
        AutoGrindstone.A[15] = "java/lang/Boolean";
        objectArray[16] = "z:EU0As:FU0";
        objectArray[17] = "A4\u0012XCmJ;\u0003\u0017\"cA0\u0007M";
        objectArray[18] = "w#wQ^\u0017\u0002\u0003|^OXc\rwUK\u0002\u0017";
        objectArray[19] = Integer.TYPE;
        AutoGrindstone.A[19] = "java/lang/Integer";
        objectArray[20] = "13g3\fA/g`]&=\u001bG\u000b3^\u001c1a:-\n\u001b";
        objectArray[21] = "r#_\"\u001ai4?_'#\t\u000f\u0006kSyQr#_\"\u001ai4?_'";
        objectArray[22] = "]\u0011jy\u0016J^\u001a*,q\u001adN,/\u001c\f\u001b\u001c.a\u001bs[M/}\u000e\f\tOazq";
        objectArray[23] = "xGQm1\u00038\r\u000ft[\u0004G\u0005[t*\u0001?K\racn";
        objectArray[24] = ">\u0005\u0007{`7?\b\u0010e\t8\u0002D\u0015\u007fco`\u0007\rk1";
        objectArray[25] = "goi#\u001c#dd)v{`^5j#\u0012\"c\u007flp\u0015";
        objectArray[26] = "']P\bRF$V\u0010]5\u0018\u001e\u0006\u001a\u0011PEyO\u0010\u000eE";
        objectArray[27] = "\u00111P|\u001fV\u0012:\u0010)x\u0016(jXd\u0001\tR>\u001b*\u001e";
        objectArray[28] = "6 x\n\u001fk5+8_x*\u000f|=\u0004G+a8r\u0012A";
        objectArray[29] = "\u0010\r$\u001a#\u0001\u0013\u0006dODQ)\u0006#L{[M]8L>8@\u00172\u001c)S@\u001f%\u0018D";
        objectArray[30] = "50O>\u000eC6;\u000fki\u0013\f;HhV\u0019h`Sh\u0013z`6P/\u0011\u0004s=Eji";
        objectArray[31] = "u\u00151A\u000b\u001cv\u0010&\u0001n\u0017\u001f\u001a;\u0016U\u0013v\u0014vAW~";
        Object[] objectArray2 = objectArray;
        objectArray[32] = "\\/V\u0011\u0005!]\"A\u000fl#`4[NS$\u0004o@N\u0016G^9W\u001c\u0001'\n&Z\u0013l";
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = AutoGrindstone.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = AutoGrindstone.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = AutoGrindstone.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = AutoGrindstone.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(AutoGrindstone.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

