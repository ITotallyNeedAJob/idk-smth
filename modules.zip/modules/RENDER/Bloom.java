// === Kuzi module: Bloom ===
// Category   : RENDER
// Description: Bright parts of the world glow, ESP included
// Payload    : a.a.a.j.g.J (verified: True)

package kuzi.modules.render;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderPass;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.b.e;
import kuzi.obf.h.b.v;
import kuzi.obf.l.a.b;
import kuzi.obf.l.a.c;
import kuzi.obf.l.a.d;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.GpuSampler;
import net.minecraft.RenderTarget;
import net.minecraft.TextureTarget;

public class Bloom
extends BaseModule
implements d {
    public final SliderSetting threshold;
    public final SliderSetting intensity;
    public final SliderSetting spread;
    public final SliderSetting saturation;
    public final BoolSetting tint;
    public final e r;
    private static final b s;
    private final TextureTarget[] bloomTargets;
    private static final long u;
    private static final String[] v;
    private static final String[] w;
    private static final Map x;
    private static final long[] y;
    private static final Integer[] z;
    private static final Map A;
    private static final Object[] B;
    private static final String[] C;

    public Bloom() {
        long l2;
        long l3 = l2 = u ^ 0x16FA923F839AL;
        long l4 = l3 ^ 0x7935A784184AL;
        long l5 = l3 ^ 0x54C55B67097L;
        long l6 = l3 ^ 0x2DDBB6CB22B2L;
        super("Bloom", "Bright parts of the world glow, ESP included", Category.RENDER);
        this.threshold = new SliderSetting("Threshold", 0.8, 0.0, 1.0, 0.01);
        this.intensity = new SliderSetting("Intensity", 1.0, 0.0, 3.0, 0.05);
        this.spread = new SliderSetting("Spread", 4.0, 1.0, 5.0, 1.0);
        this.saturation = new SliderSetting("Saturation", 1.0, 0.0, 2.0, 0.05);
        this.tint = new BoolSetting("Tint", false);
        this.r = new e("Tint Color", new Color(120, 160, 255));
        this.bloomTargets = new TextureTarget[6];
        Object[] objectArray = new Object[2];
        objectArray[1] = this.tint::a;
        objectArray[0] = l5;
        this.r.a(objectArray);
        Object[] objectArray2 = new Object[2];
        objectArray2[1] = new Setting[]{this.threshold, this.intensity, this.spread, this.saturation, this.tint, this.r};
        objectArray2[0] = l6;
        this.l(objectArray2);
        kuzi.obf.l.a.c.a(this, l4);
    }

    @Override
    public int a() {
        return 100;
    }

    @Override
    public boolean a(short s2, int n2, int n3) {
        long l2 = (long)s2 << 48 | (long)n2 << 32 >>> 16 | (long)n3 << 48 >>> 48;
        return (boolean)Bloom.d("L", (Object)this, (long)7733135221251730889L, (long)l2);
    }

    /*
     * Exception decompiling
     */
    @Override
    public void a(int var1_1, char var2_2, int var3_3) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [26[DOLOOP]], but top level block is 10[TRYBLOCK]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:435)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:484)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private void lambda$apply$3(long l2, RenderPass renderPass) {
        long l3 = (l2 = u ^ l2) ^ 0x10D1E02AC68BL;
        int n2 = (int)(l3 >>> 32);
        int n3 = (int)(l3 << 32 >>> 48);
        int n4 = (int)(l3 << 48 >>> 48);
        renderPass.bindTexture((String)((Object)Bloom.b("p", (int)24844, (long)(0x3B2BCCE1207EBE9AL ^ l2))), Bloom.d("\u00fc", (Object)this, (long)-6952309899653810534L, (long)l2)[0].getColorTextureView(), (GpuSampler)Bloom.d("K", (long)-6953410931434693227L, (long)l2));
        renderPass.setUniform((String)((Object)Bloom.b("p", (int)6587, (long)(0x4C6BF89083A6C625L ^ l2))), (GpuBuffer)Bloom.d("L", (Object)Bloom.d("\u00a5", (long)-6952365044310623503L, (long)l2), (int)n2, (int)n3, (int)n4, (long)-6953138961157868735L, (long)l2));
    }

    private static void lambda$apply$2(long l2, TextureTarget source, RenderPass renderPass) {
        l2 = u ^ l2;
        renderPass.bindTexture((String)((Object)Bloom.b("p", (int)6754, (long)(0x5AC4510AFB7A1161L ^ l2))), source.getColorTextureView(), (GpuSampler)Bloom.d("K", (long)-3810411704574867189L, (long)l2));
    }

    private static void lambda$apply$1(TextureTarget source, long l2, RenderPass renderPass) {
        l2 = u ^ l2;
        renderPass.bindTexture((String)((Object)Bloom.b("p", (int)6754, (long)(0x5AC437FBF5610818L ^ l2))), source.getColorTextureView(), (GpuSampler)Bloom.d("K", (long)-3285423966524010382L, (long)l2));
    }

    private static void lambda$apply$0(RenderTarget source, long l2, RenderPass renderPass) {
        long l3 = (l2 = u ^ l2) ^ 0x6A02734872E0L;
        int n2 = (int)(l3 >>> 32);
        int n3 = (int)(l3 << 32 >>> 48);
        int n4 = (int)(l3 << 48 >>> 48);
        renderPass.bindTexture((String)((Object)Bloom.b("p", (int)17200, (long)(0x268AB153309A28C3L ^ l2))), source.getColorTextureView(), (GpuSampler)Bloom.d("K", (long)3164903859368159742L, (long)l2));
        renderPass.setUniform((String)((Object)Bloom.b("p", (int)6387, (long)(0x6F88ED994E6F731AL ^ l2))), (GpuBuffer)Bloom.d("L", (Object)Bloom.d("\u00a5", (long)3165826029992742554L, (long)l2), (int)n2, (int)n3, (int)n4, (long)3164348456263419690L, (long)l2));
    }

    /*
     * Unable to fully structure code
     */
    static {
        block21: {
            block20: {
                block19: {
                    block18: {
                        Bloom.u = kuzi.obf.h.b.v.a(-7642356370681920537L, -3970657074421935175L, MethodHandles.lookup().lookupClass()).a(47905180085160L);
                        var20 = Bloom.u ^ 78042143007367L;
                        Bloom.B = new Object[61];
                        Bloom.C = new String[61];
                        Bloom.c();
                        Bloom.x = new HashMap<K, V>(13);
                        var11_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var20 >>> 56);
                        for (var12_2 = 1; var12_2 < 8; ++var12_2) {
                            v2 = v2;
                            v2[var12_2] = (byte)(var20 << var12_2 * 8 >>> 56);
                        }
                        var11_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var18_3 = new String[19];
                        var16_4 = 0;
                        var15_5 = "K\u00f0Nl\u0004\u00b7\u00888\u0089%\u00aaP\u00ea\u00e7\u008at}\u00cd4]\u001c\u00c5\u0003\u00abZ\u00e4\u00e4\u00c2\u0004\u00b1\u00f0\u00a5\u0094En\u009ac\u00d0F\u0090\u00cd\u00a7\u00af\u0006\u00e0bn5C=l\u00f6\u009e\u00a8\u00e0]K?\u00c9O\u00d8\u00df\u000e\u00110Y\u00cd\u0010A\u001fx}(bL*\u0091^K\u00ea\u0094\u000f\u00bd\u00b2\u0016|\u00a5m\u0018\u00b0\u0083\u00ef\u00fdEd\u00c3\u0097\u0000j\u00bf.-\u00f9j\u00b2<;\u00c3\u00f6@\u0006\u00aa\u001b X5\u00c4-\u00e8\u00a0)\u00ec.|\u00d5Q=\u008fvF\u000bps&\u00f2\u00cb\u00ec\u00bd\u00ce\u008a\u00d6\"\u00f5\b_5 _t\u00aa\u0002\u00e1z:CDh\u00dfpjA\u00d8\u00ab\u0099~\u0018\u00cfR\u0006*\u00ae\u00ef\u00f2\u00f0\u00b5\u008e\r9\u00a6 \u00ec\u00ea\u00f5\u0095m}\u008a\u00e8\u0098\u00deSX\u00a1\u00ae\u0019/H\u00d7\u0084\u00f9\u00b5\u00e5\u009e\u00b9:\u00f2\u00e6\u00caU\u000e\u00d7x \u00e4#L-\u0004\u00eb!\u00d0\u0097\u00ee\u0019\u001e\"O`\u0012&\u00a3z\u0001\u00a6\ntF^\u00f8,\u0084\u009a\u00e8\u0005V\u0010\u00b9c%>\u001f\u00f5\u0095\u00d9\u00f3Fm>,\u00c6\u0087g\u0010o\u00f8q*\u00ce6S,\u008fj\u00cc\u00a1)y\u0013T\u0010\u009d\u00c2\u00f1L\u00d7\u0099\u008f\u0091\u00882\u00b8e\nr\u0014\u008d\u0018\u00d4\u0096#)\u00c8\u008c\u00c3\u001b\u00e7\u0090;\u00dah\u0087\u00df*0\u001a\u00d2\u001a\u008f7\u00dc\u00e9\u0010\u00bb4v\u0092|8g\u008f\u00de\u001f|\u00da\u00c7\u0006!\u00c8(\u0096\u009e\u00ad\u00c2\u00af\u00e2\u0098>\u00c7\u00b0\u00d2\u00ad4\u0082=Z\u00ef\u009f\u00ea\u00f1\u00b0\u00b7yB\u0014l\u00c4\u001d\u0003\u0094U\u00fbO\u0017\u00d1,\u00e6\u0097i\u008c _!\u00d9\u00c4Q\u0087MR\u0011\u00d3 \u00f4\u0081o\u00a5p-12@d\u00f3\u00ec\u00c7\u00a6\u0086\u001e\u00a5\u00eb\u001c\u00aat\u0010|\u00b9\u00db~\u00e2\u00b5\u00c6Y\\\u00bb{\u0018If\u00f9\u00b5\u0018\u00b7&w\u00a6\u0098\u0011\u008d\u00a9\u00c6\u00e6\u00f6\u00d0\u0097\u0084\u00d3\u00db]\u00ff\u0084\u0018\u00fc\u00cc\u00b2' \u00b6I,\\i\u00ce\u00efX\u00d3\u0097\u00e0[\u00d1\u00b7\u00da\u00195\u00edr>\u00f5\u0095\u00bfs\u00ce\u00b7\u00cc%jN\u00db1\u0010~\u00182\u009d\u0080%\u008aX\u00c7H\u00e3t\u00f5\u009ep\u00d4";
                        var17_6 = "K\u00f0Nl\u0004\u00b7\u00888\u0089%\u00aaP\u00ea\u00e7\u008at}\u00cd4]\u001c\u00c5\u0003\u00abZ\u00e4\u00e4\u00c2\u0004\u00b1\u00f0\u00a5\u0094En\u009ac\u00d0F\u0090\u00cd\u00a7\u00af\u0006\u00e0bn5C=l\u00f6\u009e\u00a8\u00e0]K?\u00c9O\u00d8\u00df\u000e\u00110Y\u00cd\u0010A\u001fx}(bL*\u0091^K\u00ea\u0094\u000f\u00bd\u00b2\u0016|\u00a5m\u0018\u00b0\u0083\u00ef\u00fdEd\u00c3\u0097\u0000j\u00bf.-\u00f9j\u00b2<;\u00c3\u00f6@\u0006\u00aa\u001b X5\u00c4-\u00e8\u00a0)\u00ec.|\u00d5Q=\u008fvF\u000bps&\u00f2\u00cb\u00ec\u00bd\u00ce\u008a\u00d6\"\u00f5\b_5 _t\u00aa\u0002\u00e1z:CDh\u00dfpjA\u00d8\u00ab\u0099~\u0018\u00cfR\u0006*\u00ae\u00ef\u00f2\u00f0\u00b5\u008e\r9\u00a6 \u00ec\u00ea\u00f5\u0095m}\u008a\u00e8\u0098\u00deSX\u00a1\u00ae\u0019/H\u00d7\u0084\u00f9\u00b5\u00e5\u009e\u00b9:\u00f2\u00e6\u00caU\u000e\u00d7x \u00e4#L-\u0004\u00eb!\u00d0\u0097\u00ee\u0019\u001e\"O`\u0012&\u00a3z\u0001\u00a6\ntF^\u00f8,\u0084\u009a\u00e8\u0005V\u0010\u00b9c%>\u001f\u00f5\u0095\u00d9\u00f3Fm>,\u00c6\u0087g\u0010o\u00f8q*\u00ce6S,\u008fj\u00cc\u00a1)y\u0013T\u0010\u009d\u00c2\u00f1L\u00d7\u0099\u008f\u0091\u00882\u00b8e\nr\u0014\u008d\u0018\u00d4\u0096#)\u00c8\u008c\u00c3\u001b\u00e7\u0090;\u00dah\u0087\u00df*0\u001a\u00d2\u001a\u008f7\u00dc\u00e9\u0010\u00bb4v\u0092|8g\u008f\u00de\u001f|\u00da\u00c7\u0006!\u00c8(\u0096\u009e\u00ad\u00c2\u00af\u00e2\u0098>\u00c7\u00b0\u00d2\u00ad4\u0082=Z\u00ef\u009f\u00ea\u00f1\u00b0\u00b7yB\u0014l\u00c4\u001d\u0003\u0094U\u00fbO\u0017\u00d1,\u00e6\u0097i\u008c _!\u00d9\u00c4Q\u0087MR\u0011\u00d3 \u00f4\u0081o\u00a5p-12@d\u00f3\u00ec\u00c7\u00a6\u0086\u001e\u00a5\u00eb\u001c\u00aat\u0010|\u00b9\u00db~\u00e2\u00b5\u00c6Y\\\u00bb{\u0018If\u00f9\u00b5\u0018\u00b7&w\u00a6\u0098\u0011\u008d\u00a9\u00c6\u00e6\u00f6\u00d0\u0097\u0084\u00d3\u00db]\u00ff\u0084\u0018\u00fc\u00cc\u00b2' \u00b6I,\\i\u00ce\u00efX\u00d3\u0097\u00e0[\u00d1\u00b7\u00da\u00195\u00edr>\u00f5\u0095\u00bfs\u00ce\u00b7\u00cc%jN\u00db1\u0010~\u00182\u009d\u0080%\u008aX\u00c7H\u00e3t\u00f5\u009ep\u00d4".length();
                        var14_7 = 72;
                        var13_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var13_8;
                            v4 = var15_5.substring(v3, v3 + var14_7);
                            v5 = -1;
                            break block18;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var18_3[var16_4++] = Bloom.b(var19_9).intern();
                            if ((var13_8 += var14_7) < var17_6) {
                                var14_7 = var15_5.charAt(var13_8);
                                ** continue;
                            }
                            var15_5 = "\u0018\u0096]\b\u00c5\u00c6\u00b1\u001c\u00e8:\u00d2\u00af\u00e5b1\u00bb+\u008cI+\u00a2\u00a8`z\u0082\u00c1\u0092\u009cKj\u00f8S \u00e4\u007f\u001c[\u00e8C=\u00f2\u000f\u009f\u00ac\u0012\u00a3j\u000e\u00e7$\u00f0\u007f-7+ )\u00b7\u00c4\u00a8\u00b7M\u00fe$P";
                            var17_6 = "\u0018\u0096]\b\u00c5\u00c6\u00b1\u001c\u00e8:\u00d2\u00af\u00e5b1\u00bb+\u008cI+\u00a2\u00a8`z\u0082\u00c1\u0092\u009cKj\u00f8S \u00e4\u007f\u001c[\u00e8C=\u00f2\u000f\u009f\u00ac\u0012\u00a3j\u000e\u00e7$\u00f0\u007f-7+ )\u00b7\u00c4\u00a8\u00b7M\u00fe$P".length();
                            var14_7 = 32;
                            var13_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var13_8;
                                v4 = var15_5.substring(v6, v6 + var14_7);
                                v5 = 0;
                                break block18;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var18_3[var16_4++] = Bloom.b(var19_9).intern();
                            if ((var13_8 += var14_7) < var17_6) {
                                var14_7 = var15_5.charAt(var13_8);
                                ** continue;
                            }
                            break block19;
                            break;
                        }
                    }
                    var19_9 = var11_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                Bloom.v = var18_3;
                Bloom.w = new String[19];
                Bloom.A = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var20 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var20 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[9];
                var3_13 = 0;
                var4_14 = "\u00ff\u00ec\u00cag\u00e6\u00b5\u00a4\u00ca2\u00ee\u00d8\u00ee2;\u00e2\u00b5W\u00bdGA&\u00be2\u009fos\u00f5\u00d0\u00d8Y\u00a6\u0014d\u00d3\u008a\u00dc7#\u00d1Q;\u00d6\u00f3%\u00c7l\u00ce\u00f4\u0095N\u0090\u00c9\u00b2\u00f7\u00ae3";
                var5_15 = "\u00ff\u00ec\u00cag\u00e6\u00b5\u00a4\u00ca2\u00ee\u00d8\u00ee2;\u00e2\u00b5W\u00bdGA&\u00be2\u009fos\u00f5\u00d0\u00d8Y\u00a6\u0014d\u00d3\u008a\u00dc7#\u00d1Q;\u00d6\u00f3%\u00c7l\u00ce\u00f4\u0095N\u0090\u00c9\u00b2\u00f7\u00ae3".length();
                var2_16 = 0;
                while (true) {
                    var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                    v10 = var6_12;
                    v11 = var3_13++;
                    v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                    v13 = -1;
                    break block20;
                    break;
                }
lbl81:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    var4_14 = "\u00bc\u001c\u00e7%%\u00cd\u00a5\u000e\u00b1\u000e\u0011\u0082\u00da\u00f6\u00b7\f";
                    var5_15 = "\u00bc\u001c\u00e7%%\u00cd\u00a5\u000e\u00b1\u000e\u0011\u0082\u00da\u00f6\u00b7\f".length();
                    var2_16 = 0;
                    while (true) {
                        var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                        v10 = var6_12;
                        v11 = var3_13++;
                        v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                        v13 = 0;
                        break block20;
                        break;
                    }
                    break;
                }
lbl94:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    break block21;
                    break;
                }
            }
            var8_18 = v12;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            v14 = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
            switch (v13) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl107:
                // 1 sources

                ** continue;
            }
        }
        Bloom.y = var6_12;
        Bloom.z = new Integer[9];
        Bloom.s = new b("Kuzi bloom", 2);
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static String b(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x401A;
        if (w[n3] == null) {
            Object[] objectArray;
            try {
                Long l3 = Thread.currentThread().threadId();
                objectArray = (Object[])x.get(l3);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    x.put(l3, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/g/J", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l2 >>> 56);
            for (int i2 = 1; i2 < 8; ++i2) {
                byArray[i2] = (byte)(l2 << i2 * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = v[n3].getBytes("ISO-8859-1");
            Bloom.w[n3] = Bloom.b(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return w[n3];
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        String string2 = Bloom.b(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static CallSite b(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/J" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x6DDA;
        if (z[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = y[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])A.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    A.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/g/J", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Bloom.z[n3] = n4;
        }
        return z[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = Bloom.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/J" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (C[n4] != null) {
            return n4;
        }
        Object object = B[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 8;
            case 1 -> 33;
            case 2 -> 60;
            case 3 -> 39;
            case 4 -> 11;
            case 5 -> 41;
            case 6 -> 28;
            case 7 -> 45;
            case 8 -> 43;
            case 9 -> 37;
            case 10 -> 21;
            case 11 -> 29;
            case 12 -> 44;
            case 13 -> 49;
            case 14 -> 7;
            case 15 -> 19;
            case 16 -> 20;
            case 17 -> 51;
            case 18 -> 62;
            case 19 -> 38;
            case 20 -> 48;
            case 21 -> 1;
            case 22 -> 35;
            case 23 -> 24;
            case 24 -> 31;
            case 25 -> 30;
            case 26 -> 63;
            case 27 -> 23;
            case 28 -> 10;
            case 29 -> 55;
            case 30 -> 56;
            case 31 -> 9;
            case 32 -> 17;
            case 33 -> 27;
            case 34 -> 22;
            case 35 -> 16;
            case 36 -> 59;
            case 37 -> 34;
            case 38 -> 50;
            case 39 -> 40;
            case 40 -> 6;
            case 41 -> 57;
            case 42 -> 46;
            case 43 -> 4;
            case 44 -> 42;
            case 45 -> 25;
            case 46 -> 3;
            case 47 -> 2;
            case 48 -> 58;
            case 49 -> 32;
            case 50 -> 53;
            case 51 -> 12;
            case 52 -> 0;
            case 53 -> 52;
            case 54 -> 61;
            case 55 -> 36;
            case 56 -> 15;
            case 57 -> 14;
            case 58 -> 54;
            case 59 -> 18;
            case 60 -> 47;
            case 61 -> 13;
            case 62 -> 26;
            default -> 5;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        Bloom.C[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = B;
        B[0] = "\u0000:9}\th\r:9}\n";
        objectArray[1] = Integer.TYPE;
        Bloom.C[1] = "java/lang/Integer";
        objectArray[2] = "'#Q|-;.-R5n6(-F7s0j.I4&16?\u0012\u00150!\u00069Z4%&";
        objectArray[3] = "\fdtYpw\u0007drY[";
        objectArray[4] = "W\u0010\u0002\u0003zBZ\u0010\u0002\u0003z";
        objectArray[5] = "2M\u0006\u0017qS2M\u0011K}\\(\u0006\u0011U}I/wC\u000b-\tk";
        objectArray[6] = "\n\u0010`6W\u0007<5`6@[0:z}@E0/}\f\u0015\u001agk5";
        objectArray[7] = "&4\u0005r>\u001d-4\u000e";
        objectArray[8] = Boolean.TYPE;
        Bloom.C[8] = "java/lang/Boolean";
        objectArray[9] = "G\u001bG\u0015pZG\u001bPI|U]PPW|@Z!\u0005\b+\u0004";
        objectArray[10] = Long.TYPE;
        Bloom.C[10] = "java/lang/Long";
        objectArray[11] = "f@g.7WmOvaJO~H\u007f(";
        objectArray[12] = "t],o}&}]/o\u007f";
        objectArray[13] = "x[\u001c\tAEq[\u001f\tE";
        objectArray[14] = "P die+M5<K$&U3";
        objectArray[15] = "}\bHBSCv\bNBS)";
        objectArray[16] = ",Y";
        objectArray[17] = "*yACQO!yGCQ\u0010";
        objectArray[18] = "%\u00055pc=,\u000b69 0*\u000b\";=6h\u001a1.k>/\u0004=p\\7(\u000e=,^;6\u000f47`7";
        objectArray[19] = Void.TYPE;
        Bloom.C[19] = "java/lang/Void";
        objectArray[20] = "]n\"q9vTn!q5";
        objectArray[21] = "Pa\u0007nN\u0014Yo\u0004'\r\u0019_o\u0010%\u0010\u001f\u001dz\u000f8W\u000eAk\u0019nd\u000bFZ\u000f8W\u000eAk<)F\f";
        objectArray[22] = "J7.\"EPT?4m\rPN5,*\u0004K\u000e\u00157-\u0018PM3*";
        objectArray[23] = "\u007fz\u007f%v,|t'\u0006!6pY|\">'g";
        objectArray[24] = "\u001a?<'y\u0007\u0013??'y";
        objectArray[25] = "qv@;|RzyQt\u001d\\qrU.";
        objectArray[26] = "*S&5~\u0006&S5";
        objectArray[27] = "Ig>^\u0016\bIg)\u0002\u001a\u0007S,)\u001c\u001a\u0012T]xGM";
        objectArray[28] = "\nR_\u0014*T\u0001RW";
        objectArray[29] = "\u001bJCjs&\u0016JCjq";
        objectArray[30] = "\"j1\"\u000f\u001f/j1\"\n";
        objectArray[31] = "ebl\u001dEo\u0010Bg\u0012T qLl\u0019Pz\u0005";
        objectArray[32] = "\u0013hXrNjfHS}_%\u0007FXv[\u007fs";
        objectArray[33] = "\u000f8|\u0004\u001dsJiwFek4i9\\\u00073Qh|Z\u001a\u0002\u000bl7\u0006\u0007yIj9Pe2\u00040wE]gR-><\\nYj}M\u001dz\u000ejF\u0005\to\tl7D\u001d8\tWx\u0000TgVl'_\u000584i9\\\u00073Qh|Z\u001a\u0002";
        objectArray[34] = "H^w\u0017y6\u0014\bt\u0013\u001f&r\u0000lNca\u0011Zn\u0015t";
        objectArray[35] = "Lz-c^7D}=?nj')m1\u0017{Xz6.\u0010";
        objectArray[36] = "\u0015\u0000u!HRPQ~c0J._\u007f~\u0001Z\u0016\n)cH#C\u0017,hU\u001cL\u0017u(0\u001d\u0012^*{\u000bBM\u000fu\u0019\\\u0019C\u00162f\u000fB\\\u0011OwZ\u001aW\u0014tcLSEop\"A\u0019L\u00142$OO.\u0003#p\\\u001c\u0013\u000bpf\b#";
        objectArray[37] = "\u0005Tj42M\u0000\u0006{Y7(\u0005\rjc<SG\u000bd5^G\n\fq%#\u0010JZaY";
        objectArray[38] = "'U\u0019-v\u001d'PF%\u0019JHUO9tBx]\u0011>\u007f#'U\u0019-v\u001d'PF%\u0019";
        objectArray[39] = "\u007fb!\u001aNF#4\"\u001e(TE`=\u0018RO:5&\u0017\u0013";
        objectArray[40] = "[v9Anl[sfI\u0001;4s,W94\u000bhcYcR";
        objectArray[41] = "\n\\Z)e]V\nY-\u0003R0^F+yTO\u000b]$8";
        objectArray[42] = "WdGE\u001f1\u000b2DAy2mj\\X\u0010;\u0016pCCC[\flEO\u0019 \u0016s^\u001cy";
        objectArray[43] = "dX[R\u0007k!\tP\u0010\u007fs_\f\u001b\u000f\u001ds!\u000b\u0010\u0013\u001b\u001a";
        objectArray[44] = "\u0015\u001e\u00104VI\u0010L\u0001YS,\u0013\u0010\fd\u0001]R\u0004[d:\u0015F\u0011\\bKTRF\\Y\u0003@GAZ(BT\u0010Aac\u0000\u0010PEQdSKO|";
        objectArray[45] = "s`\u0013\\.3!fHUB\u0017\\\\b`\u0018Ms`\u0013\\.3!fHU";
        objectArray[46] = "\u0015\u0019\u007fbHTIO|f.G/FcpJNALon\u0015";
        objectArray[47] = "d\u0001X\u001e$R>\u0003\u0003\t\u0019XU\u000f\u000e\bk\u0001*\u0017\u000eYv1";
        objectArray[48] = ",\u001eLQ5Z+\u0014\u001cA\nYO\u0010QQ;\f(CQY{0pH\\\u0000hK2NRV\n\\#\u001aA\u00057Tp\f\u0015:";
        objectArray[49] = " \u0017\u0004<w=7\u0001\u0006x\u0018mI\u0000\u0013iu8-U\u0015e&\u0007";
        objectArray[50] = "{\"L%:\u0018s%\\y\nB\u0010q\fwsTo\"Wht";
        objectArray[51] = "RY\u0002\u0015N7SB\u0002Yvao\rG\u0018\u0013oTR\u0018IL\r";
        objectArray[52] = "\n\b#=\u0011\u0015\u000fZ2P\u0014p\nQ#j\u001f\u000bHW-<}\u001cY\u0003>o@\u0014\n\u0015jP";
        objectArray[53] = "pve\u000f\u001c0xquS,h\u001b%%]U|dv~BR";
        objectArray[54] = ";GS0t3g\u0011P4\u0012>\u0001EO2h:~\u0010T=)";
        objectArray[55] = "O\u0002c\u0004\u0014\tG\u0005sX$R$Q#V]E[\u0002xIZ";
        objectArray[56] = "i'>oK\u00015q=k-\u0017St?6A\u0019?w&tK";
        objectArray[57] = "\u0015[\u0010)J7I\r\u0013-,&/\u000b\u000e;A1J\u000e\\*";
        objectArray[58] = "~\u0010a\u0004\u0018)\"Fb\u0000~%D\u0012}\u0006\u0004 ;Gf\tE";
        objectArray[59] = "K%3w\b\u0018J>3;0Fv*{']CF\"% V\"\u001a##'\u000f\u001f\u0012p5s0";
        Object[] objectArray2 = objectArray;
        objectArray[60] = "[{Q>W4\u001e*Z|/,`u\u0016|]:\u001b%\u0010jWE";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = Bloom.e(l2, l3);
            object = B[n2];
            try {
                if (!(object instanceof String)) break block2;
                Bloom.B[n2] = clazz = Class.forName(C[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = Bloom.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = Bloom.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = Bloom.e(l2, l3);
        Object object = B[n2];
        if (object instanceof String) {
            String string = C[n2];
            int n3 = string.indexOf(8);
            Class clazz = Bloom.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = Bloom.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = Bloom.c(clazz3, string2, clazz2)) != null) {
                    Bloom.B[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = Bloom.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        Bloom.B[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = Bloom.f(1826434976378311L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = Bloom.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = Bloom.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = Bloom.e(l2, l3);
        Object object = B[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = C[n2];
                int n4 = string2.indexOf(8);
                clazz3 = Bloom.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = Bloom.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = Bloom.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        Bloom.B[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = Bloom.f(1826434976378311L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = Bloom.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        Bloom.B[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = Bloom.f(1826434976378311L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == '\u00fc' || c2 == '\u00ec' || c2 == '\u00a5' || c2 == 'R') {
                field = Bloom.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == '\u00fc' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == '\u00ec' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == '\u00a5' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = Bloom.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == 'L' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == 'K' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = Bloom.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_2().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/J" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Bloom.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(Bloom.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_2() {
        try {
            return MethodHandles.lookup().findStatic(Bloom.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

