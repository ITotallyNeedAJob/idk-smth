// === Kuzi module: Trails ===
// Category   : RENDER
// Description: Motion-trail ribbon behind players
// Payload    : a.a.a.j.g.an (verified: True)

package kuzi.modules.render;

import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.b.e;
import kuzi.obf.h.b.v;
import kuzi.obf.m.r;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.Player;
import net.minecraft.Vec3;
import net.minecraft.Minecraft;
import net.minecraft.Mth;
import net.minecraft.VertexConsumer;
import org.joml.Matrix4f;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class Trails
extends BaseModule {
    private final BoolSetting players;
    private final BoolSetting friendsOnly;
    private final BoolSetting invisibles;
    private final BoolSetting self;
    private final e q;
    private final SliderSetting r;
    private final SliderSetting gradientSpeed;
    private final Map t;
    private static final long u;
    private static final String[] v;
    private static final String[] w;
    private static final Map x;
    private static final long[] y;
    private static final Integer[] z;
    private static final Map A;
    private static final Object[] B;
    private static final String[] C;

    public Trails() {
        long l2;
        long l3 = l2 = u ^ 0x179967C0F937L;
        long l4 = l3 ^ 0x5580A889A2F3L;
        long l5 = l3 ^ 0x74488B604C3EL;
        super("Trails", "Motion-trail ribbon behind players", Category.RENDER);
        this.players = new BoolSetting("Players", true);
        this.friendsOnly = new BoolSetting("Friends Only", false);
        this.invisibles = new BoolSetting("Invisibles", false);
        this.self = new BoolSetting("Self", false);
        this.q = new e("Color", new Color(120, 180, 255));
        this.r = new SliderSetting("Length", 3.0, 1.0, 8.0, 0.5);
        this.gradientSpeed = new SliderSetting("Gradient Speed", 5.0, 0.0, 10.0, 1.0);
        this.t = new HashMap();
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.players, this.friendsOnly, this.invisibles, this.self, this.q, this.r, this.gradientSpeed};
        objectArray[0] = l5;
        this.l(objectArray);
        WorldRenderEvents.END_MAIN.register(arg_0 -> this.a(l4, arg_0));
    }

    @Override
    public void e() {
        super.e();
        this.t.clear();
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private boolean a(Object[] var1_1) {
        block27: {
            block28: {
                block25: {
                    block26: {
                        block23: {
                            block24: {
                                block21: {
                                    block22: {
                                        player = (Player)var1_1[0];
                                        var3_3 = (Long)var1_1[1];
                                        var2_4 = (Minecraft)var1_1[2];
                                        var3_3 = Trails.u ^ var3_3;
                                        var6_5 = Trails.d("i", (long)2326238075062830260L, (long)var3_3);
                                        try {
                                            try {
                                                v0 /* !! */  = player;
                                                if (var6_5 == null) break block21;
                                                if (v0 /* !! */  != var2_4.player) break block22;
                                            }
                                            catch (r v1) {
                                                throw Trails.d("i", (Object)v1, (long)2326252848331561628L, (long)var3_3);
                                            }
                                            return (Boolean)Trails.d("a", (Object)Trails.d("d", (Object)this, (long)2325860980360689836L, (long)var3_3), (long)2326944736215190650L, (long)var3_3);
                                        }
                                        catch (r v2) {
                                            throw Trails.d("i", (Object)v2, (long)2326252848331561628L, (long)var3_3);
                                        }
                                    }
                                    v0 /* !! */  = Trails.d("a", (Object)Trails.d("d", (Object)this, (long)2327006504085002539L, (long)var3_3), (long)2326944736215190650L, (long)var3_3);
                                }
                                try {
                                    try {
                                        v3 /* !! */  = (Boolean)v0 /* !! */ ;
                                        if (var6_5 == null) break block23;
                                        if (v3 /* !! */ ) break block24;
                                    }
                                    catch (r v4) {
                                        throw Trails.d("i", (Object)v4, (long)2326252848331561628L, (long)var3_3);
                                    }
                                    return false;
                                }
                                catch (r v5) {
                                    throw Trails.d("i", (Object)v5, (long)2326252848331561628L, (long)var3_3);
                                }
                            }
                            v3 /* !! */  = Trails.d("i", player.getGameProfile().name(), (long)2326397309476365718L, (long)var3_3);
                        }
                        var7_6 = v3 /* !! */ ;
                        try {
                            try {
                                v6 = (Boolean)Trails.d("a", (Object)Trails.d("d", (Object)this, (long)2326345588932362539L, (long)var3_3), (long)2326944736215190650L, (long)var3_3);
                                v7 = var6_5;
                                if (var3_3 > 0L) {
                                    if (v7 == null) break block25;
                                    if (!v6) break block26;
                                }
                                ** GOTO lbl58
                            }
                            catch (r v8) {
                                throw Trails.d("i", (Object)v8, (long)2326252848331561628L, (long)var3_3);
                            }
                            return var7_6;
                        }
                        catch (r v9) {
                            throw Trails.d("i", (Object)v9, (long)2326252848331561628L, (long)var3_3);
                        }
                    }
                    v6 = (Boolean)Trails.d("a", (Object)Trails.d("d", (Object)this, (long)2325925634626116191L, (long)var3_3), (long)2326944736215190650L, (long)var3_3);
                }
                try {
                    try {
                        try {
                            try {
                                v7 = var6_5;
lbl58:
                                // 2 sources

                                if (v7 == null) break block27;
                                if (v6) break block28;
                            }
                            catch (r v10) {
                                throw Trails.d("i", (Object)v10, (long)2326252848331561628L, (long)var3_3);
                            }
                            v6 = player.isInvisible();
                            if (var6_5 == null) break block27;
                        }
                        catch (r v11) {
                            throw Trails.d("i", (Object)v11, (long)2326252848331561628L, (long)var3_3);
                        }
                        if (!v6) break block28;
                    }
                    catch (r v12) {
                        throw Trails.d("i", (Object)v12, (long)2326252848331561628L, (long)var3_3);
                    }
                    return false;
                }
                catch (r v13) {
                    throw Trails.d("i", (Object)v13, (long)2326252848331561628L, (long)var3_3);
                }
            }
            v6 = true;
        }
        return v6;
    }

    /*
     * Exception decompiling
     */
    private void a(long var1_1, WorldRenderContext var3_2) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [14[WHILELOOP]], but top level block is 2[TRYBLOCK]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:435)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:484)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private static void a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        VertexConsumer vertexConsumer = (VertexConsumer)objectArray[1];
        Matrix4f matrix4f = (Matrix4f)objectArray[2];
        Vec3 startPos = (Vec3)objectArray[3];
        Vec3 endPos = (Vec3)objectArray[4];
        float height = ((Float)objectArray[5]).floatValue();
        int startColor = (Integer)objectArray[6];
        int endColor = (Integer)objectArray[7];
        long l3 = (l2 = u ^ l2) ^ 0x34EA1E2B4827L;
        Object[] objectArray2 = new Object[7];
        objectArray2[6] = startColor;
        objectArray2[5] = startPos.z;
        objectArray2[4] = startPos.y;
        objectArray2[3] = l3;
        objectArray2[2] = startPos.x;
        objectArray2[1] = matrix4f;
        objectArray2[0] = vertexConsumer;
        Trails.d("i", (Object)objectArray2, (long)-6397134717656535260L, (long)l2);
        Object[] objectArray3 = new Object[7];
        objectArray3[6] = startColor;
        objectArray3[5] = startPos.z;
        objectArray3[4] = startPos.y + (double)height;
        objectArray3[3] = l3;
        objectArray3[2] = startPos.x;
        objectArray3[1] = matrix4f;
        objectArray3[0] = vertexConsumer;
        Trails.d("i", (Object)objectArray3, (long)-6397134717656535260L, (long)l2);
        Object[] objectArray4 = new Object[7];
        objectArray4[6] = endColor;
        objectArray4[5] = endPos.z;
        objectArray4[4] = endPos.y + (double)height;
        objectArray4[3] = l3;
        objectArray4[2] = endPos.x;
        objectArray4[1] = matrix4f;
        objectArray4[0] = vertexConsumer;
        Trails.d("i", (Object)objectArray4, (long)-6397134717656535260L, (long)l2);
        Object[] objectArray5 = new Object[7];
        objectArray5[6] = endColor;
        objectArray5[5] = endPos.z;
        objectArray5[4] = endPos.y;
        objectArray5[3] = l3;
        objectArray5[2] = endPos.x;
        objectArray5[1] = matrix4f;
        objectArray5[0] = vertexConsumer;
        Trails.d("i", (Object)objectArray5, (long)-6397134717656535260L, (long)l2);
        Object[] objectArray6 = new Object[7];
        objectArray6[6] = endColor;
        objectArray6[5] = endPos.z;
        objectArray6[4] = endPos.y;
        objectArray6[3] = l3;
        objectArray6[2] = endPos.x;
        objectArray6[1] = matrix4f;
        objectArray6[0] = vertexConsumer;
        Trails.d("i", (Object)objectArray6, (long)-6397134717656535260L, (long)l2);
        Object[] objectArray7 = new Object[7];
        objectArray7[6] = endColor;
        objectArray7[5] = endPos.z;
        objectArray7[4] = endPos.y + (double)height;
        objectArray7[3] = l3;
        objectArray7[2] = endPos.x;
        objectArray7[1] = matrix4f;
        objectArray7[0] = vertexConsumer;
        Trails.d("i", (Object)objectArray7, (long)-6397134717656535260L, (long)l2);
        Object[] objectArray8 = new Object[7];
        objectArray8[6] = startColor;
        objectArray8[5] = startPos.z;
        objectArray8[4] = startPos.y + (double)height;
        objectArray8[3] = l3;
        objectArray8[2] = startPos.x;
        objectArray8[1] = matrix4f;
        objectArray8[0] = vertexConsumer;
        Trails.d("i", (Object)objectArray8, (long)-6397134717656535260L, (long)l2);
        Object[] objectArray9 = new Object[7];
        objectArray9[6] = startColor;
        objectArray9[5] = startPos.z;
        objectArray9[4] = startPos.y;
        objectArray9[3] = l3;
        objectArray9[2] = startPos.x;
        objectArray9[1] = matrix4f;
        objectArray9[0] = vertexConsumer;
        Trails.d("i", (Object)objectArray9, (long)-6397134717656535260L, (long)l2);
    }

    private static int a(Object[] objectArray) {
        int alpha;
        int n3;
        int n4;
        long l2;
        block5: {
            int n5;
            block4: {
                l2 = (Long)objectArray[0];
                Color color = (Color)objectArray[1];
                n4 = (Integer)objectArray[2];
                n3 = (Integer)objectArray[3];
                float fade = ((Float)objectArray[4]).floatValue();
                l2 = u ^ l2;
                alpha = (int)(Mth.clamp((float)(fade * 1.4f), (float)0.0f, (float)1.0f) * (float)color.getAlpha());
                CallSite callSite = Trails.d("i", (long)1396733784387680158L, (long)l2);
                try {
                    try {
                        n5 = n4;
                        if (callSite == null) break block4;
                        if (n5 > 0) break block5;
                    }
                    catch (r r2) {
                        throw Trails.d("i", (Object)r2, (long)1396897009073793462L, (long)l2);
                    }
                    n5 = alpha << Trails.c("m", (int)22452, (long)(0x31773D49F86F681AL ^ l2)) | color.getRGB() & Trails.c("m", (int)30469, (long)(0x52F100DB0BCEC8AAL ^ l2));
                }
                catch (r r3) {
                    throw Trails.d("i", (Object)r3, (long)1396897009073793462L, (long)l2);
                }
            }
            return n5;
        }
        float hue = ((float)System.currentTimeMillis() / (110.0f - (float)n4 * 10.0f) + (float)n3 * 12.0f) % 360.0f / 360.0f;
        int rainbowRgb = Color.HSBtoRGB(hue, 0.75f, 1.0f) & Trails.c("m", (int)16366, (long)(0x1D5CB4DD70B8804AL ^ l2));
        return alpha << Trails.c("m", (int)22452, (long)(0x31773D49F86F681AL ^ l2)) | rainbowRgb;
    }

    private static boolean lambda$render$1(List list, long l2, Player player) {
        boolean bl;
        block6: {
            block8: {
                block7: {
                    l2 = u ^ l2;
                    CallSite callSite = Trails.d("i", (long)-7602818191407353215L, (long)l2);
                    try {
                        try {
                            try {
                                bl = list.contains(player);
                                if (callSite == null) break block6;
                                if (!bl) break block7;
                            }
                            catch (r r2) {
                                throw Trails.d("i", (Object)r2, (long)-7602732900007957335L, (long)l2);
                            }
                            bl = player.isRemoved();
                            if (callSite == null) break block6;
                        }
                        catch (r r3) {
                            throw Trails.d("i", (Object)r3, (long)-7602732900007957335L, (long)l2);
                        }
                        if (!bl) break block8;
                    }
                    catch (r r4) {
                        throw Trails.d("i", (Object)r4, (long)-7602732900007957335L, (long)l2);
                    }
                }
                bl = true;
                break block6;
            }
            bl = false;
        }
        return bl;
    }

    private static Deque lambda$render$0(Player player) {
        return new ArrayDeque();
    }

    /*
     * Unable to fully structure code
     */
    static {
        block21: {
            block20: {
                block19: {
                    block18: {
                        Trails.u = kuzi.obf.h.b.v.a(-6627514652858876983L, -7004239352988924663L, MethodHandles.lookup().lookupClass()).a(12037224823177L);
                        Trails.B = new Object[48];
                        Trails.C = new String[48];
                        Trails.c();
                        Trails.x = new HashMap<K, V>(13);
                        var11 = Trails.u ^ 97622944226248L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[9];
                        var18_4 = 0;
                        var17_5 = "z\u00ff\u001bl\u00c7\u00f1u\u00f1S\u00ac*F\u0004FC\b\u0010\u0015\u00cd9rzMY\u001a[JJ\u00b6Ko\u008e\u00b2\u0010\u008b\u00c9\u00f4\u0001\u0005pV\u00a6=\u00ef\u00bb\u00f1 \u00aa>\u00f0\u0010\u0089\u00e6\u00c9\u00e7\n\u00ea\u00a9B\u009csoZ|.\u00ae\u00da \u00df\u0083E\u0080\u0010\u0081\u001c\u00c9\u00ac|\u00ee\u00f76\u00b8=\u00b7\u009e\u0015\u00fc\u00ff\u0081\u00ad\u00b5\u00f1\u00e8)\u0087\u00bd\u00c0\u00e8\u00b6h $\u00db\u00adM\u00ea\u00bf\u0099\u0010\u00ae/\u0015+\u008a\u0097\u00e4!\u00ab\u00b4I7\u00bd0\u00cc\u00ad\u00ed\u00ad`\u00ea\u0005\u00c7Lb \u0094\u00d3\u00d4\u00e4\u0084\u0002U\u00eay\u0090C`\u0017L\u00c4\u00ba\u000e8\u0014\u00b5\u00d4\u00a2y:\u00d1\u0012\u00da\u00de\u009e\u00f8\u008e\u00bd";
                        var19_6 = "z\u00ff\u001bl\u00c7\u00f1u\u00f1S\u00ac*F\u0004FC\b\u0010\u0015\u00cd9rzMY\u001a[JJ\u00b6Ko\u008e\u00b2\u0010\u008b\u00c9\u00f4\u0001\u0005pV\u00a6=\u00ef\u00bb\u00f1 \u00aa>\u00f0\u0010\u0089\u00e6\u00c9\u00e7\n\u00ea\u00a9B\u009csoZ|.\u00ae\u00da \u00df\u0083E\u0080\u0010\u0081\u001c\u00c9\u00ac|\u00ee\u00f76\u00b8=\u00b7\u009e\u0015\u00fc\u00ff\u0081\u00ad\u00b5\u00f1\u00e8)\u0087\u00bd\u00c0\u00e8\u00b6h $\u00db\u00adM\u00ea\u00bf\u0099\u0010\u00ae/\u0015+\u008a\u0097\u00e4!\u00ab\u00b4I7\u00bd0\u00cc\u00ad\u00ed\u00ad`\u00ea\u0005\u00c7Lb \u0094\u00d3\u00d4\u00e4\u0084\u0002U\u00eay\u0090C`\u0017L\u00c4\u00ba\u000e8\u0014\u00b5\u00d4\u00a2y:\u00d1\u0012\u00da\u00de\u009e\u00f8\u008e\u00bd".length();
                        var16_7 = 16;
                        var15_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block18;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = Trails.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "\u00ebl\n\u00f8!\u00ba\u00d8\u00cem\\\u00f3\u00ce\u00b5\u00b5\u00f5\u00e4@\u0018\u009e\u00e37\u000b=MB\u00ac>O\u000b\u00bc\u0082\u00f9+tt\u00d6\u009a[\u00eb\u00fe\r\u00e7\u00bfv\u00fd\r\u00b0.f\u0087nH\u0080?\u00b8@\u0013W\u00b6\u00eb\u008e\u00bf\u00d0T\u0007\u00cd\u0086\u009e\u009cX\u0099\u00ee\u0085\u00cd\u00d7\rm]\u00d56v";
                            var19_6 = "\u00ebl\n\u00f8!\u00ba\u00d8\u00cem\\\u00f3\u00ce\u00b5\u00b5\u00f5\u00e4@\u0018\u009e\u00e37\u000b=MB\u00ac>O\u000b\u00bc\u0082\u00f9+tt\u00d6\u009a[\u00eb\u00fe\r\u00e7\u00bfv\u00fd\r\u00b0.f\u0087nH\u0080?\u00b8@\u0013W\u00b6\u00eb\u008e\u00bf\u00d0T\u0007\u00cd\u0086\u009e\u009cX\u0099\u00ee\u0085\u00cd\u00d7\rm]\u00d56v".length();
                            var16_7 = 16;
                            var15_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block18;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = Trails.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block19;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                Trails.v = var20_3;
                Trails.w = new String[9];
                Trails.A = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[12];
                var3_13 = 0;
                var4_14 = "\u00ae\u0014\u00cb*\bV'\u00b2\u0019S\u0093\u001b\u00c4[\u00b3J\u00bf\u0096\u0019\u0086\u00e0\u00f6\u00e1\\\u00f9\u00c6\u00de\u0085\u0080l \u0082\u00a6\u0089S\u00c7\u00ac\u00f1XGB\u00c7\u00d9\u00d5\u00c6S0\u00dbd\u00eb\u0004\u00f4n\u00dc\u0014&\u00fe[\u00816\u00bfCxu\u00dd6\b\u0098\u00eet'F\u00ab\u0095\u00b9\f\u00af&v\u00db";
                var5_15 = "\u00ae\u0014\u00cb*\bV'\u00b2\u0019S\u0093\u001b\u00c4[\u00b3J\u00bf\u0096\u0019\u0086\u00e0\u00f6\u00e1\\\u00f9\u00c6\u00de\u0085\u0080l \u0082\u00a6\u0089S\u00c7\u00ac\u00f1XGB\u00c7\u00d9\u00d5\u00c6S0\u00dbd\u00eb\u0004\u00f4n\u00dc\u0014&\u00fe[\u00816\u00bfCxu\u00dd6\b\u0098\u00eet'F\u00ab\u0095\u00b9\f\u00af&v\u00db".length();
                var2_16 = 0;
                while (true) {
                    var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                    v10 = var6_12;
                    v11 = var3_13++;
                    v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                    v13 = -1;
                    break block20;
                    break;
                }
lbl81:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    var4_14 = "\u00fd\u00b9\u0014\u0015\u00aa\u00ed\u00be\f\u009b7\u00a3V\u0080\u00877\u00e4";
                    var5_15 = "\u00fd\u00b9\u0014\u0015\u00aa\u00ed\u00be\f\u009b7\u00a3V\u0080\u00877\u00e4".length();
                    var2_16 = 0;
                    while (true) {
                        var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                        v10 = var6_12;
                        v11 = var3_13++;
                        v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                        v13 = 0;
                        break block20;
                        break;
                    }
                    break;
                }
lbl94:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    break block21;
                    break;
                }
            }
            var8_18 = v12;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            v14 = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
            switch (v13) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl107:
                // 1 sources

                ** continue;
            }
        }
        Trails.y = var6_12;
        Trails.z = new Integer[12];
    }

    private static r a(r r2) {
        return r2;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x2CC4;
        if (z[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = y[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])A.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    A.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/g/an", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Trails.z[n3] = n4;
        }
        return z[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = Trails.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/an" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (C[n4] != null) {
            return n4;
        }
        Object object = B[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 25;
            case 1 -> 36;
            case 2 -> 44;
            case 3 -> 63;
            case 4 -> 20;
            case 5 -> 27;
            case 6 -> 56;
            case 7 -> 52;
            case 8 -> 39;
            case 9 -> 35;
            case 10 -> 45;
            case 11 -> 48;
            case 12 -> 34;
            case 13 -> 22;
            case 14 -> 50;
            case 15 -> 40;
            case 16 -> 49;
            case 17 -> 55;
            case 18 -> 0;
            case 19 -> 29;
            case 20 -> 26;
            case 21 -> 42;
            case 22 -> 43;
            case 23 -> 32;
            case 24 -> 7;
            case 25 -> 23;
            case 26 -> 19;
            case 27 -> 58;
            case 28 -> 57;
            case 29 -> 17;
            case 30 -> 46;
            case 31 -> 37;
            case 32 -> 59;
            case 33 -> 38;
            case 34 -> 14;
            case 35 -> 1;
            case 36 -> 9;
            case 37 -> 60;
            case 38 -> 62;
            case 39 -> 21;
            case 40 -> 6;
            case 41 -> 31;
            case 42 -> 5;
            case 43 -> 2;
            case 44 -> 28;
            case 45 -> 8;
            case 46 -> 33;
            case 47 -> 30;
            case 48 -> 10;
            case 49 -> 47;
            case 50 -> 3;
            case 51 -> 15;
            case 52 -> 61;
            case 53 -> 53;
            case 54 -> 16;
            case 55 -> 51;
            case 56 -> 11;
            case 57 -> 24;
            case 58 -> 18;
            case 59 -> 13;
            case 60 -> 4;
            case 61 -> 54;
            case 62 -> 41;
            default -> 12;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        Trails.C[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = B;
        B[0] = "$_eU\\5/_cU\\u";
        objectArray[1] = ";l8\ty~NL3\u0006h1/B8\rlk[";
        objectArray[2] = Void.TYPE;
        Trails.C[2] = "java/lang/Void";
        objectArray[3] = "GE\u0011'\u0019\u0014NE\u0012'\u001b";
        objectArray[4] = "=*\n2|s6*\f2|\u0019";
        objectArray[5] = "_\u0003";
        objectArray[6] = ".Kg\u0013'\u0005\"Kt";
        objectArray[7] = "Jl#rsK[l\u0004";
        objectArray[8] = "e\u0000\u001e\t[3n\u000f\u000fF&+}\b\u0006\u000f";
        objectArray[9] = Boolean.TYPE;
        Trails.C[9] = "java/lang/Boolean";
        objectArray[10] = "yM\n#x\u0018pM\t#x";
        objectArray[11] = "JeD>AwAjUq yJaQ+";
        objectArray[12] = "toLkQJjgV$2^n";
        objectArray[13] = "@|\r\u001c\t~K|\u0005";
        objectArray[14] = "K\u0005Q-FUB\u0005R-B";
        objectArray[15] = "U\u0005>Rp>\\\u0005=R|";
        objectArray[16] = "QC\"M\u0006jZC)";
        objectArray[17] = "p\u0004q\u0004$H\u0005$z\u000b5\u0007d*q\u00001]\u0010";
        objectArray[18] = "-w9H\u0004\u001bXW2G\u0015T9Y9L\u0011\u000eM";
        objectArray[19] = "\u001a{nP_Qo[e_N\u001e\u000eUnTJDz";
        objectArray[20] = "0tSt$r-a\u000bVe\u007f5g";
        objectArray[21] = "\u0018b2x;Y\u0013b4x;4";
        objectArray[22] = "\u0010\u000f\u000bsU`\u0010\u000f\u001c/Yo\nD\u001c1Yz\r5Mi\u000b";
        objectArray[23] = "|6\u0012],\u007f\t\u0016\u0019R=0h\u0018\u0012Y9j\u001c";
        objectArray[24] = Integer.TYPE;
        Trails.C[24] = "java/lang/Integer";
        objectArray[25] = Long.TYPE;
        Trails.C[25] = "java/lang/Long";
        objectArray[26] = "\u0004jn7F}Rj:b<_x\u0013\u0012\u0011f\u0005\u0004jn7F}Rj:b";
        objectArray[27] = "*r\u00109y2*}P\u0004vVy}\u001e?|1-w\u001da\u001foij\u0005df)gy\u0002\u0004";
        objectArray[28] = "\u0007+Dp`%\u0007$\u0004M~A\u0001,\u0004<z}]3\u000bu";
        objectArray[29] = "\u001d\u007fL\u000f\u0003t\u001dp\f2\u0002\u0010\u001bx\fC\u0019,Gg\u0003\n";
        objectArray[30] = "b-\\%\u0000}b\"\u001c\u0018\u000f\u00191\"R#\u0005~e(Q}f'85X|\ni''M\u0018";
        objectArray[31] = "eOBG\t\u001ee@\u0002z\u0005z6@LA\f\u001dbJO\u001foC&WW\u001a\u0016\u0005(DPz";
        objectArray[32] = ">4\u001fJ+!ivI\u000bB1\u000f!\u0001@#\"j\"\u0019\u001b$X";
        objectArray[33] = ")21U\u0018<oco\r$5\u0012e#\\T.u\"aD\\_";
        objectArray[34] = "\u0010\u000f@B:W\u0010\u0000\u0000\u007f53\u0010RD\u00158\t\u0016^\u0002\u000e\\\u000f\u0011\u0014U\u001bf\t\u001dRN\u007f";
        objectArray[35] = "u\u0005`\r[2u\n 0[Vs\u0002 AAj/\u001d/\b";
        objectArray[36] = "\u001dI\u001bv[\u001eF\u0004N~kO!\u0006L'Q\u001dMH\u0013)\u000b&\u001f^\nb\u000fJQA\u0018wk";
        objectArray[37] = ":\u007fW\u0015i$m\u007f\u0013I\u00162P#M\bm:<mR\u001ax^";
        objectArray[38] = "FU\u0004w(+\u0011I\fdP++G\u0007 o>\u001bE\u001ft?";
        objectArray[39] = "\u0003\rbZ;m\u0003\u0002\"g$\t\u000e\u0014rW4pYV$\u0016";
        objectArray[40] = "+\u001c.:2`+\u0013n\u0007=\u0004x\u0013 <7c,\u0019#bTkf\u001c#>7j'\u0003=\u0007";
        objectArray[41] = "B7\u0011L\u0012\u0012\u0015+\u0019_j\u0011/+\u0010X\u000b\u0015\u00115\u0006@\u0014";
        objectArray[42] = "\u0001\u0013\u0018\u0019\u0002%\u0001\u001cX$\u001eAT\u000e\u0003\\TzM\u0018\u001fY";
        objectArray[43] = "jJ\b^\"R%G\u001f\bAJU\u0019\u001f\u00038\u0018<\\T\u0005(#";
        objectArray[44] = "SA\u0007'(SSNG\u001a+7UFGk2\u000b\tYH\"";
        objectArray[45] = "\u0006YC_\u0012EQY\u0007\u0003m[lTPKV\\\u000b\u0000ZH\b?UDGP\rF\u0013JTWm";
        objectArray[46] = "B2rpCsB=2MY\u0017N20wNx\u00067w,";
        Object[] objectArray2 = objectArray;
        objectArray[47] = "3E\u001c[]>3J\\f@ZfX\u0007\u001e\u000ba\u007fN\u001b\u001b";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = Trails.e(l2, l3);
            object = B[n2];
            try {
                if (!(object instanceof String)) break block2;
                Trails.B[n2] = clazz = Class.forName(C[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = Trails.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = Trails.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = Trails.e(l2, l3);
        Object object = B[n2];
        if (object instanceof String) {
            String string = C[n2];
            int n3 = string.indexOf(8);
            Class clazz = Trails.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = Trails.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = Trails.c(clazz3, string2, clazz2)) != null) {
                    Trails.B[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = Trails.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        Trails.B[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = Trails.f(788870471597866L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = Trails.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = Trails.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = Trails.e(l2, l3);
        Object object = B[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = C[n2];
                int n4 = string2.indexOf(8);
                clazz3 = Trails.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = Trails.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = Trails.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        Trails.B[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = Trails.f(788870471597866L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = Trails.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        Trails.B[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = Trails.f(788870471597866L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == 'd' || c2 == 'l' || c2 == 'B' || c2 == '\u00c8') {
                field = Trails.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == 'd' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == 'l' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == 'B' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = Trails.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == 'a' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == 'i' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = Trails.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/an" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Trails.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(Trails.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

