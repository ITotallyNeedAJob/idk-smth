// === Kuzi module: TotemAlartor ===
// Category   : RENDER
// Description: Shows a semi-transparent screen overlay when you don't have a totem in your offhand
// Payload    : a.a.a.j.g.am (verified: True)

package kuzi.modules.render;

import java.awt.Color;
import java.lang.invoke.MethodHandles;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.mixin.MixinExposed;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.b.e;
import kuzi.obf.h.b.v;
import kuzi.obf.h.q_0;
import kuzi.obf.h.r_0;
import kuzi.obf.j.g.aD;
import kuzi.obf.m.r;
import kuzi.obf.p.f.a;
import kuzi.settings.Setting;
import net.minecraft.Items;
import net.minecraft.Minecraft;
import net.minecraft.GuiGraphics;

public final class TotemAlartor
extends BaseModule {
    private final e overlayColor;
    private static final long n = kuzi.obf.h.b.v.a(3327501683841104009L, -8320416240559898784L, MethodHandles.lookup().lookupClass()).a(25927989107217L);
    private static final String[] o;
    private static final String[] p;
    private static final Map q;
    private static final long[] r;
    private static final Integer[] s;
    private static final Map t;
    private static final Object[] u;
    private static final String[] v;

    public TotemAlartor() {
        long l2 = n ^ 0x3A49C14CB9B1L;
        long l3 = l2 ^ 0x1C7ACC2A4301L;
        super("TotemAlartor", "Shows a semi-transparent screen overlay when you don't have a totem in your offhand", Category.RENDER);
        this.overlayColor = new e("Overlay Color", new Color(255, 255, 255, 76));
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.overlayColor};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        super.d();
    }

    @Override
    public void e() {
        super.e();
    }

    @MixinExposed
    public void a(GuiGraphics graphics) {
        block9: {
            Minecraft minecraft;
            block7: {
                block8: {
                    block5: {
                        boolean skipRender;
                        block6: {
                            Minecraft mc;
                            int[] nArray;
                            block4: {
                                nArray = aD.b();
                                if (!this.c) {
                                    return;
                                }
                                mc = BaseModule.a;
                                if (nArray == null) break block4;
                                if (mc.player == null) break block5;
                                mc = BaseModule.a;
                            }
                            skipRender = mc.screen instanceof r_0;
                            if (nArray == null) break block6;
                            if (skipRender) break block5;
                            minecraft = BaseModule.a;
                            if (nArray == null) break block7;
                            skipRender = minecraft.screen instanceof q_0;
                        }
                        if (!skipRender) break block8;
                    }
                    return;
                }
                minecraft = BaseModule.a;
            }
            if (minecraft.player.getOffhandItem().getItem() == Items.TOTEM_OF_UNDYING) break block9;
            kuzi.obf.p.f.a.a(new Object[0]);
            Object[] objectArray = new Object[6];
            objectArray[5] = this.overlayColor.a().getRGB();
            objectArray[4] = BaseModule.a.getWindow().getScreenHeight();
            objectArray[3] = BaseModule.a.getWindow().getScreenWidth();
            objectArray[2] = 0;
            objectArray[1] = 0;
            objectArray[0] = graphics;
            kuzi.obf.p.f.a.d(objectArray);
            kuzi.obf.p.f.a.b(new Object[0]);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        u = new Object[28];
        v = new String[28];
        TotemAlartor.c();
        q = new HashMap(13);
        long l2 = n ^ 0x70F4B45E610L;
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] keyBytes = new byte[8];
        byte[] keyBytesAlias = keyBytes;
        keyBytes[0] = (byte)(l2 >>> 56);
        for (int i2 = 1; i2 < 8; ++i2) {
            keyBytesAlias = keyBytesAlias;
            keyBytesAlias[i2] = (byte)(l2 << i2 * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(keyBytesAlias)), new IvParameterSpec(new byte[8]));
        String[] decodedStrings = new String[3];
        int chunkIndex = 0;
        String cipherText = "^\u00e1j\u001f\u00b9\u00c64\u00f7\u00a7\u00cc\u00fd\u0088'`\u00bc\bO\u00d8\u00bb}\u00fd\u00c4\u00bdz\u0010\u00bb\u00a2\u009c\u00ad\u001f\u0017\u00cc\u0088\u00e086\u009ew\u0005\u00ae$\u00d7\u00ab\u009bR\u00e6\u00e0M\u00af\u001eI\u0004t\u0002\u001a\u00c6\u00efP!\u00a2M\u00fd#{\u00c9W%\u00d5\u00d1\u00d9\u00fd\u00d1z\f\u00ee\u00f7U:\u00a8\u0000Tr?B\u0088\u00e7b\u0084!\u00c4\u00a4\u00ec\u0099\u0019\u00008S\u001e4C\u001aEB\u00aa\u001a\u00c2.Y\u0006\u0089\u001c\u00fecx\u00d5\u0087\u0095\u00ffN\u00d9W:\u00b3\u00bfKN\u00c0\u001c\u008bp,\u00e3I\u00dbK#> )8%\u0013\u00cduKe\u00bc\u000eDS\u00a9\u0097Q\u00b2B\u00b7\u00cdF\u00b2\u008c5\u00ac\u00d2@\u0098\u0001{\u00a2\u00c1 \u00a1\u001bf\u00c4\u00d0/\u00a3\u00ee\u00f2\u008b\u00e7\u00ef\u0090-\u00f4\u001bvxt_\u00cc\u00b1\u00a1]\n#+\u0011\u0096\u00c5m\u0092";
        int encodedLength = "^\u00e1j\u001f\u00b9\u00c64\u00f7\u00a7\u00cc\u00fd\u0088'`\u00bc\bO\u00d8\u00bb}\u00fd\u00c4\u00bdz\u0010\u00bb\u00a2\u009c\u00ad\u001f\u0017\u00cc\u0088\u00e086\u009ew\u0005\u00ae$\u00d7\u00ab\u009bR\u00e6\u00e0M\u00af\u001eI\u0004t\u0002\u001a\u00c6\u00efP!\u00a2M\u00fd#{\u00c9W%\u00d5\u00d1\u00d9\u00fd\u00d1z\f\u00ee\u00f7U:\u00a8\u0000Tr?B\u0088\u00e7b\u0084!\u00c4\u00a4\u00ec\u0099\u0019\u00008S\u001e4C\u001aEB\u00aa\u001a\u00c2.Y\u0006\u0089\u001c\u00fecx\u00d5\u0087\u0095\u00ffN\u00d9W:\u00b3\u00bfKN\u00c0\u001c\u008bp,\u00e3I\u00dbK#> )8%\u0013\u00cduKe\u00bc\u000eDS\u00a9\u0097Q\u00b2B\u00b7\u00cdF\u00b2\u008c5\u00ac\u00d2@\u0098\u0001{\u00a2\u00c1 \u00a1\u001bf\u00c4\u00d0/\u00a3\u00ee\u00f2\u008b\u00e7\u00ef\u0090-\u00f4\u001bvxt_\u00cc\u00b1\u00a1]\n#+\u0011\u0096\u00c5m\u0092".length();
        int chunkSize = 32;
        int offset = -1;
        while (true) {
            int chunkStart = ++offset;
            byte[] chunkBytes = cipher.doFinal(cipherText.substring(chunkStart, chunkStart + chunkSize).getBytes("ISO-8859-1"));
            decodedStrings[chunkIndex++] = TotemAlartor.b(chunkBytes).intern();
            if ((offset += chunkSize) >= encodedLength) break;
            chunkSize = cipherText.charAt(offset);
        }
        o = decodedStrings;
        p = new String[3];
        t = new HashMap(13);
        Cipher cipher2 = Cipher.getInstance("DES/CBC/NoPadding");
        SecretKeyFactory secretKeyFactory2 = SecretKeyFactory.getInstance("DES");
        byte[] keyBytes2 = new byte[8];
        byte[] keyBytes2Alias = keyBytes2;
        keyBytes2[0] = (byte)(l2 >>> 56);
        for (int i3 = 1; i3 < 8; ++i3) {
            keyBytes2Alias = keyBytes2Alias;
            keyBytes2Alias[i3] = (byte)(l2 << i3 * 8 >>> 56);
        }
        cipher2.init(2, (Key)secretKeyFactory2.generateSecret(new DESKeySpec(keyBytes2Alias)), new IvParameterSpec(new byte[8]));
        long[] decodedKeys = new long[3];
        int keyIndex = 0;
        String cipherText2 = "iEM~KV3\u0013\u00f0'\u00c6A\bD1\u0080#\u0002\u0082k\\`\u00d1H";
        int encodedLength2 = "iEM~KV3\u0013\u00f0'\u00c6A\bD1\u0080#\u0002\u0082k\\`\u00d1H".length();
        int position = 0;
        do {
            byte[] blockBytes = cipherText2.substring(position, position += 8).getBytes("ISO-8859-1");
            int keySlot = keyIndex++;
            long l3 = ((long)blockBytes[0] & 0xFFL) << 56 | ((long)blockBytes[1] & 0xFFL) << 48 | ((long)blockBytes[2] & 0xFFL) << 40 | ((long)blockBytes[3] & 0xFFL) << 32 | ((long)blockBytes[4] & 0xFFL) << 24 | ((long)blockBytes[5] & 0xFFL) << 16 | ((long)blockBytes[6] & 0xFFL) << 8 | (long)blockBytes[7] & 0xFFL;
            byte[] decodedBytes = cipher2.doFinal(new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3});
            decodedKeys[keySlot] = ((long)decodedBytes[0] & 0xFFL) << 56 | ((long)decodedBytes[1] & 0xFFL) << 48 | ((long)decodedBytes[2] & 0xFFL) << 40 | ((long)decodedBytes[3] & 0xFFL) << 32 | ((long)decodedBytes[4] & 0xFFL) << 24 | ((long)decodedBytes[5] & 0xFFL) << 16 | ((long)decodedBytes[6] & 0xFFL) << 8 | (long)decodedBytes[7] & 0xFFL;
        } while (position < encodedLength2);
        r = decodedKeys;
        s = new Integer[3];
    }

    private static r a(r r2) {
        return r2;
    }

    private static String b(byte[] bytes) {
        int outputIndex = 0;
        int inputLength = bytes.length;
        char[] decoded = new char[inputLength];
        for (int i2 = 0; i2 < inputLength; ++i2) {
            char decodedChar;
            int codeUnit = 0xFF & bytes[i2];
            if (codeUnit < 192) {
                decoded[outputIndex++] = (char)codeUnit;
                continue;
            }
            if (codeUnit < 224) {
                decodedChar = (char)((char)(codeUnit & 0x1F) << 6);
                codeUnit = bytes[++i2];
                decodedChar = (char)(decodedChar | (char)(codeUnit & 0x3F));
                decoded[outputIndex++] = decodedChar;
                continue;
            }
            if (i2 >= inputLength - 2) continue;
            decodedChar = (char)((char)(codeUnit & 0xF) << 12);
            codeUnit = bytes[++i2];
            decodedChar = (char)(decodedChar | (char)(codeUnit & 0x3F) << 6);
            codeUnit = bytes[++i2];
            decodedChar = (char)(decodedChar | (char)(codeUnit & 0x3F));
            decoded[outputIndex++] = decodedChar;
        }
        return new String(decoded, 0, outputIndex);
    }

    private static void c() {
        Object[] objectArray = u;
        u[0] = "'o\b&5\f,o\u000e&5O";
        objectArray[1] = "}\u007f>aB\u000et\u007f=aF";
        objectArray[2] = "[\tw_BJP\t|";
        objectArray[3] = "&J.a\u0018\u0007&J9=\u0014\b<\u00019#\u0014\u001d;pi~E";
        objectArray[4] = "_>\u00176!\tN>\u00106!";
        objectArray[5] = "b\u0017a8qC\u00177j7`\fv9a<dV\u0002";
        objectArray[6] = Void.TYPE;
        TotemAlartor.v[6] = "java/lang/Void";
        objectArray[7] = "#c&~'\u0013VC-q6\\7M&z2\u0006C";
        objectArray[8] = "Q>=w\u00161L+eUW<T-";
        objectArray[9] = "s;|?L\u0000x;z?Lj";
        objectArray[10] = " K";
        objectArray[11] = "t0\u001e$yR\u0001\u0010\u0015+h\u001d`\u001e\u001e lG\u0014";
        objectArray[12] = Boolean.TYPE;
        TotemAlartor.v[12] = "java/lang/Boolean";
        objectArray[13] = "X\u0017\u0011\u0011;BT\u0017\u0002";
        objectArray[14] = "J1\r6\u0013CA1\u0005";
        objectArray[15] = "#7\u000bf\u0006>V\u0017\u0000i\u0017q7\u0019\u000bb\u0013+C";
        objectArray[16] = "h&I|*\u0019c)X3K\u0017h\"\\i";
        objectArray[17] = "\u0019\u0019\u000f\u001a\u0017{Q\u0003Y\u001an\u001ae&zj4@\u0019\u0019\u000f\u001a\u0017{Q\u0003Y\u001a";
        objectArray[18] = "LzeP`vL#;4i\u0014Z\"6Imz\u001f%)";
        objectArray[19] = "\u0010\u001e\u0019I<DSXU\u001c\\A)Z\nAeHR\u0007\u0016A,";
        objectArray[20] = ">=\u0012`z0i2\\>F?\u0004)\u000ef84f#\u0012$'U8<\u00056|8v:\u001e%F";
        objectArray[21] = "\u001bywuQ*Lv9+m#!mks\u0013.Cgw1\fO\u001dx`#W\"S~{0m";
        objectArray[22] = "xBz\u001a_x=EegW\u0016;\u0011%\u0007Fdg\u001ac\u001f>";
        objectArray[23] = "T1J-v\u0017U7O6\u001fAjm\u00138!B\u001bc\u00128n+";
        objectArray[24] = "h\u0010=<r\u0003?\u001fsbN\u000fR\u0004!:0\u00070\u000e=x/fn\u0011*jt\u000b \u00171yN";
        objectArray[25] = "Oo\u0014\u001ci&\f)XI\t!v!\u001c\u000fl!\u001d*\u0014\u001ek";
        objectArray[26] = "|&nx\u000eF|\u007f0\u001c\u000b$&q-{\u0000\u001fiba%b\u0015{o8~YZh#f\u001c";
        Object[] objectArray2 = objectArray;
        objectArray[27] = "t#a\u001d!%7e-HA-M4rL?(/>n\u000e Iq!y\u001c{$?'b\u000fA";
    }

    private static Field findDeclaredField(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field findFieldInHierarchy(Class clazz, String string, Class clazz2) {
        Field field = TotemAlartor.findDeclaredField(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = TotemAlartor.findFieldInHierarchy(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method findDeclaredMethod(Class clazz, String string, Class clazz2, int parameterCount, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != parameterCount) continue;
            for (int i2 = 0; i2 < parameterCount; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method findMethodInHierarchy(Class clazz, String string, Class clazz2, int parameterCount, Class[] classArray) {
        Method method = TotemAlartor.findDeclaredMethod(clazz, string, clazz2, parameterCount, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = TotemAlartor.findMethodInHierarchy(classArray2[i2], string, clazz2, parameterCount, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }
}

