// === Kuzi module: MotionBlur ===
// Category   : RENDER
// Description: Smears the screen when you turn fast
// Payload    : a.a.a.j.g.ab (verified: False)

package kuzi.modules.render;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.textures.GpuTextureView;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.b.v;
import kuzi.obf.j.g.aD;
import kuzi.obf.l.a.a;
import kuzi.obf.l.a.b;
import kuzi.obf.l.a.c;
import kuzi.obf.l.a.d;
import kuzi.obf.m.r;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.UniformType;
import net.minecraft.GpuSampler;
import net.minecraft.RenderTarget;
import net.minecraft.Minecraft;
import net.minecraft.TextureTarget;

public class MotionBlur
extends BaseModule
implements d {
    private static final RenderPipeline pipeline;
    private static final b n;
    public final SliderSetting strength;
    private TextureTarget p;
    private boolean q;
    private long r;
    private static final long s;
    private static final String[] t;
    private static final String[] u;
    private static final Map v;
    private static final long w;
    private static final Object[] x;
    private static final String[] y;

    public MotionBlur() {
        long l2;
        long l3 = l2 = s ^ 0x42B71EAD025EL;
        long l4 = l3 ^ 0x785C3C5C199EL;
        long l5 = l3 ^ 0x2CB22D132366L;
        super("MotionBlur", "Smears the screen when you turn fast", Category.RENDER);
        this.strength = new SliderSetting("Strength", 0.6, 0.1, 0.95, 0.05);
        this.q = true;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.strength};
        objectArray[0] = l5;
        this.l(objectArray);
        kuzi.obf.l.a.c.a(this, l4);
    }

    @Override
    public void d() {
        super.d();
        this.q = true;
    }

    @Override
    public void e() {
        block3: {
            TextureTarget target;
            block2: {
                int[] nArray = aD.b();
                super.e();
                int[] nArray2 = nArray;
                target = this.p;
                if (nArray2 == null) break block2;
                if (target == null) break block3;
                target = this.p;
            }
            target.destroyBuffers();
            this.p = null;
        }
    }

    @Override
    public int a() {
        return (int)w;
    }

    @Override
    public boolean a(short s2, int n2, int n3) {
        boolean bl;
        block5: {
            block4: {
                long l2 = (long)s2 << 48 | (long)n2 << 32 >>> 16 | (long)n3 << 48 >>> 48;
                try {
                    try {
                        if (MotionBlur.c("\u00fe", (Object)this, (long)7733018272798830070L, (long)l2) == false || ((Minecraft)MotionBlur.c("Z", (long)7734400841450784241L, (long)l2)).level == null) break block4;
                    }
                    catch (r r2) {
                        throw MotionBlur.c("D", (Object)r2, (long)7733995308121349725L, (long)l2);
                    }
                    bl = true;
                    break block5;
                }
                catch (r r3) {
                    throw MotionBlur.c("D", (Object)r3, (long)7733995308121349725L, (long)l2);
                }
            }
            bl = false;
        }
        return bl;
    }

    @Override
    public void a(int n2, char c2, int n3) {
        CallSite callSite;
        float elapsedSeconds;
        int n4;
        int n5;
        CallSite callSite2;
        long l2;
        long l3;
        long l4;
        long l5;
        long l6;
        long l7;
        long l8;
        block17: {
            block18: {
                block14: {
                    MotionBlur motionBlur;
                    block15: {
                        MotionBlur motionBlur2;
                        CallSite callSite3;
                        long l9;
                        block12: {
                            block13: {
                                long l10 = l8 = (long)n2 << 32 | (long)c2 << 48 >>> 32 | (long)n3 << 48 >>> 48;
                                l7 = l10 ^ 0x5F372AD64AF8L;
                                l6 = l10 ^ 0x1527AC598503L;
                                l5 = l10 ^ 0x2995213AAB0DL;
                                l4 = l10 ^ 0x44C5C4EFF6B8L;
                                l9 = l10 ^ 0x5580C14F3380L;
                                l3 = l10 ^ 0x184308D2ECFEL;
                                l2 = l10 ^ 0x6B27462E321FL;
                                callSite2 = MotionBlur.c("D", (long)1675294486159555327L, (long)l8);
                                n5 = ((RenderTarget)callSite2).width;
                                n4 = ((RenderTarget)callSite2).height;
                                callSite3 = MotionBlur.c("D", (long)1673552888452515470L, (long)l8);
                                long nowNanos = System.nanoTime();
                                elapsedSeconds = (float)(nowNanos - MotionBlur.c("l", (Object)this, (long)1672432283456115092L, (long)l8)) / 1.0E9f;
                                try {
                                    try {
                                        motionBlur2 = this;
                                        if (callSite3 == null) break block12;
                                        MotionBlur.c("\u00e9", (Object)motionBlur2, (long)nowNanos, (long)1672432283456115092L, (long)l8);
                                        if (!(elapsedSeconds > 0.25f)) break block13;
                                    }
                                    catch (r r2) {
                                        throw MotionBlur.c("D", (Object)r2, (long)1674118317424452146L, (long)l8);
                                    }
                                    MotionBlur.c("\u00e9", (Object)this, (boolean)true, (long)1673756003667185838L, (long)l8);
                                }
                                catch (r r3) {
                                    throw MotionBlur.c("D", (Object)r3, (long)1674118317424452146L, (long)l8);
                                }
                            }
                            motionBlur2 = this;
                        }
                        CallSite callSite4 = MotionBlur.c("l", (Object)motionBlur2, (long)1675130288731790206L, (long)l8);
                        try {
                            block16: {
                                try {
                                    try {
                                        try {
                                            MotionBlur.c("\u00e9", (Object)this, (TextureTarget)MotionBlur.c("D", (Object)MotionBlur.c("l", (Object)this, (long)1675130288731790206L, (long)l8), (long)l9, (Object)MotionBlur.b("q", (int)8263, (long)(0x2B185F9DBD2725BL ^ l8)), (int)n5, (int)n4, (boolean)false, (long)1672488202186282957L, (long)l8), (long)1675130288731790206L, (long)l8);
                                            if (n3 < 0) break block14;
                                            motionBlur = this;
                                            if (callSite3 == null) break block15;
                                            if (MotionBlur.c("l", (Object)motionBlur, (long)1673756003667185838L, (long)l8) != false) break block16;
                                        }
                                        catch (r r4) {
                                            throw MotionBlur.c("D", (Object)r4, (long)1674118317424452146L, (long)l8);
                                        }
                                        callSite = MotionBlur.c("l", (Object)this, (long)1675130288731790206L, (long)l8);
                                        if (callSite3 == null) break block17;
                                    }
                                    catch (r r5) {
                                        throw MotionBlur.c("D", (Object)r5, (long)1674118317424452146L, (long)l8);
                                    }
                                    if (callSite == callSite4) break block18;
                                }
                                catch (r r6) {
                                    throw MotionBlur.c("D", (Object)r6, (long)1674118317424452146L, (long)l8);
                                }
                            }
                            Object[] objectArray = new Object[4];
                            objectArray[3] = n4;
                            objectArray[2] = l6;
                            objectArray[1] = n5;
                            objectArray[0] = callSite2;
                            MotionBlur.c("\u00fe", (Object)this, (Object)objectArray, (long)1673108821048558660L, (long)l8);
                            motionBlur = this;
                        }
                        catch (r r7) {
                            throw MotionBlur.c("D", (Object)r7, (long)1674118317424452146L, (long)l8);
                        }
                    }
                    MotionBlur.c("\u00e9", (Object)motionBlur, (boolean)false, (long)1673756003667185838L, (long)l8);
                }
                return;
            }
            callSite = MotionBlur.c("\u00fe", (Object)MotionBlur.c("l", (Object)this, (long)1673930383009655757L, (long)l8), (long)1673186156169608439L, (long)l8);
        }
        float blurFactor = (float)Math.pow((Double)((Object)callSite), Math.max(0.0f, elapsedSeconds) * 60.0f);
        CallSite callSite5 = MotionBlur.c("\u00fe", (Object)MotionBlur.c("Z", (long)1674155638291816881L, (long)l8), (long)l7, (long)1674046037120733163L, (long)l8);
        ((ByteBuffer)((Object)callSite5)).putFloat(blurFactor).putFloat(0.0f).putFloat(0.0f).putFloat(0.0f);
        MotionBlur.c("\u00fe", (Object)MotionBlur.c("Z", (long)1674155638291816881L, (long)l8), (long)l4, (long)1675029531527104101L, (long)l8);
        CallSite callSite6 = MotionBlur.c("D", (long)l5, (long)1673667404136013316L, (long)l8);
        GpuTextureView gpuTextureView = MotionBlur.c("l", (Object)this, (long)1675130288731790206L, (long)l8).getColorTextureView();
        MotionBlur.c("D", (Object)MotionBlur.b("q", (int)14311, (long)(0x5BEC0BF7DD2065F0L ^ l8)), (Object)callSite2.getColorTextureView(), (boolean)false, (Object)MotionBlur.c("Z", (long)1674905333374794499L, (long)l8), arg_0 -> MotionBlur.lambda$apply$0((GpuTextureView)callSite6, gpuTextureView, l3, arg_0), (long)l2, (long)1673838551827216844L, (long)l8);
        Object[] objectArray = new Object[4];
        objectArray[3] = n4;
        objectArray[2] = l6;
        objectArray[1] = n5;
        objectArray[0] = callSite2;
        MotionBlur.c("\u00fe", (Object)this, (Object)objectArray, (long)1673108821048558660L, (long)l8);
    }

    private static void lambda$apply$0(GpuTextureView gpuTextureView, GpuTextureView gpuTextureView2, long l2, RenderPass renderPass) {
        long l3 = (l2 = s ^ l2) ^ 0x49827BFE18E0L;
        int n2 = (int)(l3 >>> 32);
        int n3 = (int)(l3 << 32 >>> 48);
        int n4 = (int)(l3 << 48 >>> 48);
        renderPass.bindTexture((String)((Object)MotionBlur.b("q", (int)20708, (long)(0x1429D5D47A56D42AL ^ l2))), gpuTextureView, (GpuSampler)MotionBlur.c("D", (long)4750053936193941935L, (long)l2));
        renderPass.bindTexture((String)((Object)MotionBlur.b("q", (int)2009, (long)(0x1B379A27D4BB0319L ^ l2))), gpuTextureView2, (GpuSampler)MotionBlur.c("D", (long)4750053936193941935L, (long)l2));
        renderPass.setUniform((String)((Object)MotionBlur.b("q", (int)22068, (long)(0x13389569429652FDL ^ l2))), (GpuBuffer)MotionBlur.c("\u00fe", (Object)MotionBlur.c("Z", (long)4749217381996869474L, (long)l2), (int)n2, (int)n3, (int)n4, (long)4750150282237761153L, (long)l2));
    }

    /*
     * Unable to fully structure code
     */
    static {
        block14: {
            block13: {
                block12: {
                    MotionBlur.s = kuzi.obf.h.b.v.a(5528384124670813966L, 2222285130686673398L, MethodHandles.lookup().lookupClass()).a(97510152422837L);
                    var14 = MotionBlur.s ^ 107164487026536L;
                    var16_1 = var14 ^ 80854746547935L;
                    MotionBlur.x = new Object[55];
                    MotionBlur.y = new String[55];
                    MotionBlur.c();
                    MotionBlur.v = new HashMap<K, V>(13);
                    var5_2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                    v0 = SecretKeyFactory.getInstance("DES");
                    v1 = new byte[8];
                    v2 = v1;
                    v1[0] = (byte)(var14 >>> 56);
                    for (var6_3 = 1; var6_3 < 8; ++var6_3) {
                        v2 = v2;
                        v2[var6_3] = (byte)(var14 << var6_3 * 8 >>> 56);
                    }
                    var5_2.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                    var12_4 = new String[13];
                    var10_5 = 0;
                    var9_6 = "\u0092\u00c1\u0006\u00d5h\u00b1b\u008aT\u00f2+A\u00c9\u0096\u007f\u001b\u0018\u00b82\u00c4,1\u000e\u00f4+K\u00a5\u0014\u00afq\u007f\u0019\u000b\u00b0\u00db\u00faq\u00fa\u00cb\u00b8R@[4\u00b3\u00b0\u0019\u00d0{\u00d1\u0001\u00e6%\u0014\u00a9Mc\u00f7\u0098\u00fc\u00c4\u0099\u00ba\u00ebU\u00eeR\u0000\u00ab\u00e7\u00a0V\f\f\u00c4\"\u00ea~kd\u0015\u009f\u00c3\u00cb\u0096\u00ca\u00bb_?\u009b~X&i*\u00f6 \u00c6\u00b3\u00f9\u00f4\u00bd\u00dfg\u00d4 \u0010\u00f8wh\u00e8%vi\u00ddZ\u00dd+86O\u00a2B J\u00b5\u00b1\u00bfl\u00c5J~\u00d3\u00ef\u00b0\u00bd\u00f9f\u0014g\u001ao\u0092\u001f\u00cfX>\u001a:>\u00a3i\u00b7\u00e9\u00f1\u000f i\u00de\u00bb\u00e8\u0082\u008c#\u0016|\u00e9\u0015V\u0002|P \u00c3\u0003\u00d8\u00cc\\\u00ba\u009a\u00bbf\u00e2jx\u00e1|2F\u0010\u00bd\u00ed\u00f6\u00fa\u0095\u001d\u00bf\u00f5\u00bci\u008f\u00db\u00fc$Q\u00cb8\b49Q\u00cd\u0099%c\u00be\u00c8X \u001f\u00cf\u0083\u00b8B)\u00fd|\u00ae\u00a6\u008c\u00f8\u00b9\u009d\u008d9iFK\u0010\u00df\u00c4q\u00c3\u00ee\u00a1\u00d1\u00c3\u00b5^\u0007s\u00f5\u001eU\u00bf\u00dcV\u00ca\u0012\u00b7LH\u00da\u0010\u00aeD\u008d\u00b3\\\u008b\u00fa:U9Ug,\u00fbr\u00ae 4\u00d5\u00f5}\u0088L\u00df\u00a9\u00d9k\u00a7\u00f6\u00fd\f\u0010\u009e8NsT1z\u0014\b\u000e\u0005#ro\u0001\u0098](\u00f5{\u00d9j\n0EpD9\u00e7v\u00f9\u00c2>\u00bf\u00fa\u00c1\u00c9\u009a\u009d\u00a8\u00deE\u0095\u0087>D\u00a4;\u00d4pW\u00d0\u0004\u00f8\u0091\u0095w\u009a";
                    var11_7 = "\u0092\u00c1\u0006\u00d5h\u00b1b\u008aT\u00f2+A\u00c9\u0096\u007f\u001b\u0018\u00b82\u00c4,1\u000e\u00f4+K\u00a5\u0014\u00afq\u007f\u0019\u000b\u00b0\u00db\u00faq\u00fa\u00cb\u00b8R@[4\u00b3\u00b0\u0019\u00d0{\u00d1\u0001\u00e6%\u0014\u00a9Mc\u00f7\u0098\u00fc\u00c4\u0099\u00ba\u00ebU\u00eeR\u0000\u00ab\u00e7\u00a0V\f\f\u00c4\"\u00ea~kd\u0015\u009f\u00c3\u00cb\u0096\u00ca\u00bb_?\u009b~X&i*\u00f6 \u00c6\u00b3\u00f9\u00f4\u00bd\u00dfg\u00d4 \u0010\u00f8wh\u00e8%vi\u00ddZ\u00dd+86O\u00a2B J\u00b5\u00b1\u00bfl\u00c5J~\u00d3\u00ef\u00b0\u00bd\u00f9f\u0014g\u001ao\u0092\u001f\u00cfX>\u001a:>\u00a3i\u00b7\u00e9\u00f1\u000f i\u00de\u00bb\u00e8\u0082\u008c#\u0016|\u00e9\u0015V\u0002|P \u00c3\u0003\u00d8\u00cc\\\u00ba\u009a\u00bbf\u00e2jx\u00e1|2F\u0010\u00bd\u00ed\u00f6\u00fa\u0095\u001d\u00bf\u00f5\u00bci\u008f\u00db\u00fc$Q\u00cb8\b49Q\u00cd\u0099%c\u00be\u00c8X \u001f\u00cf\u0083\u00b8B)\u00fd|\u00ae\u00a6\u008c\u00f8\u00b9\u009d\u008d9iFK\u0010\u00df\u00c4q\u00c3\u00ee\u00a1\u00d1\u00c3\u00b5^\u0007s\u00f5\u001eU\u00bf\u00dcV\u00ca\u0012\u00b7LH\u00da\u0010\u00aeD\u008d\u00b3\\\u008b\u00fa:U9Ug,\u00fbr\u00ae 4\u00d5\u00f5}\u0088L\u00df\u00a9\u00d9k\u00a7\u00f6\u00fd\f\u0010\u009e8NsT1z\u0014\b\u000e\u0005#ro\u0001\u0098](\u00f5{\u00d9j\n0EpD9\u00e7v\u00f9\u00c2>\u00bf\u00fa\u00c1\u00c9\u009a\u009d\u00a8\u00deE\u0095\u0087>D\u00a4;\u00d4pW\u00d0\u0004\u00f8\u0091\u0095w\u009a".length();
                    var8_8 = 16;
                    var7_9 = -1;
lbl25:
                    // 2 sources

                    while (true) {
                        v3 = ++var7_9;
                        v4 = var9_6.substring(v3, v3 + var8_8);
                        v5 = -1;
                        break block12;
                        break;
                    }
lbl30:
                    // 1 sources

                    while (true) {
                        var12_4[var10_5++] = MotionBlur.b(var13_10).intern();
                        if ((var7_9 += var8_8) < var11_7) {
                            var8_8 = var9_6.charAt(var7_9);
                            ** continue;
                        }
                        var9_6 = "\u00d7\u00c1\u00b5\u00dc\u00a7\u00ad\u00d4\u00fd\u0013\u00bc\u00a8\u00b9Pv\u00ea\u008a\u00c2a`\u0095\u00c3\u00c1\u0080\u00dc(i{G\u009eyn\u0010\u00cd\u00fa\u00b8\u00e7\u0096]\u00b5\u00d6\u0001i\u00caY\u00f7\f{\u00df\u0000\u00e4\u00ba\u00bb\u0088\u00816/\u00fa\u008d*k\u00f6\u00ba\u00daC ";
                        var11_7 = "\u00d7\u00c1\u00b5\u00dc\u00a7\u00ad\u00d4\u00fd\u0013\u00bc\u00a8\u00b9Pv\u00ea\u008a\u00c2a`\u0095\u00c3\u00c1\u0080\u00dc(i{G\u009eyn\u0010\u00cd\u00fa\u00b8\u00e7\u0096]\u00b5\u00d6\u0001i\u00caY\u00f7\f{\u00df\u0000\u00e4\u00ba\u00bb\u0088\u00816/\u00fa\u008d*k\u00f6\u00ba\u00daC ".length();
                        var8_8 = 24;
                        var7_9 = -1;
lbl39:
                        // 2 sources

                        while (true) {
                            v6 = ++var7_9;
                            v4 = var9_6.substring(v6, v6 + var8_8);
                            v5 = 0;
                            break block12;
                            break;
                        }
                        break;
                    }
lbl44:
                    // 1 sources

                    while (true) {
                        var12_4[var10_5++] = MotionBlur.b(var13_10).intern();
                        if ((var7_9 += var8_8) < var11_7) {
                            var8_8 = var9_6.charAt(var7_9);
                            ** continue;
                        }
                        break block13;
                        break;
                    }
                }
                var13_10 = var5_2.doFinal(v4.getBytes("ISO-8859-1"));
                switch (v5) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl56:
                    // 1 sources

                    ** continue;
                }
            }
            MotionBlur.t = var12_4;
            MotionBlur.u = new String[13];
            var0_11 = Cipher.getInstance("DES/CBC/NoPadding");
            v7 = SecretKeyFactory.getInstance("DES");
            v8 = new byte[8];
            v9 = v8;
            v8[0] = (byte)(var14 >>> 56);
            for (var1_12 = 1; var1_12 < 8; ++var1_12) {
                v9 = v9;
                v9[var1_12] = (byte)(var14 << var1_12 * 8 >>> 56);
            }
            break block14;
lbl70:
            // 1 sources

            while (true) {
                continue;
                break;
            }
        }
        var0_11.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
        var2_13 = -1693589397109984178L;
        var4_14 = var0_11.doFinal(new byte[]{(byte)(var2_13 >>> 56), (byte)(var2_13 >>> 48), (byte)(var2_13 >>> 40), (byte)(var2_13 >>> 32), (byte)(var2_13 >>> 24), (byte)(var2_13 >>> 16), (byte)(var2_13 >>> 8), (byte)var2_13});
        ** while (true)
        MotionBlur.w = ((long)var4_14[0] & 255L) << 56 | ((long)var4_14[1] & 255L) << 48 | ((long)var4_14[2] & 255L) << 40 | ((long)var4_14[3] & 255L) << 32 | ((long)var4_14[4] & 255L) << 24 | ((long)var4_14[5] & 255L) << 16 | ((long)var4_14[6] & 255L) << 8 | (long)var4_14[7] & 255L;
        MotionBlur.pipeline = kuzi.obf.l.a.a.a(kuzi.obf.l.a.a.a(var16_1, "motion_blur").withSampler("Scene").withSampler("History").withUniform("KuziMotionBlur", UniformType.UNIFORM_BUFFER));
        MotionBlur.n = new b("Kuzi motion blur", 1);
    }

    private static r a(r r2) {
        return r2;
    }

    private static String b(byte[] bytes) {
        int outIndex = 0;
        int length = bytes.length;
        char[] chars = new char[length];
        for (int i2 = 0; i2 < length; ++i2) {
            char decodedChar;
            int byteValue = 0xFF & bytes[i2];
            if (byteValue < 192) {
                chars[outIndex++] = (char)byteValue;
                continue;
            }
            if (byteValue < 224) {
                decodedChar = (char)((char)(byteValue & 0x1F) << 6);
                byteValue = bytes[++i2];
                decodedChar = (char)(decodedChar | (char)(byteValue & 0x3F));
                chars[outIndex++] = decodedChar;
                continue;
            }
            if (i2 >= length - 2) continue;
            decodedChar = (char)((char)(byteValue & 0xF) << 12);
            byteValue = bytes[++i2];
            decodedChar = (char)(decodedChar | (char)(byteValue & 0x3F) << 6);
            byteValue = bytes[++i2];
            decodedChar = (char)(decodedChar | (char)(byteValue & 0x3F));
            chars[outIndex++] = decodedChar;
        }
        return new String(chars, 0, outIndex);
    }

    private static String b(int n2, long l2) {
        int cacheIndex = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x4529;
        if (u[cacheIndex] == null) {
            Object[] threadCaches;
            try {
                Long threadId = Thread.currentThread().threadId();
                threadCaches = (Object[])v.get(threadId);
                if (threadCaches == null) {
                    threadCaches = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    v.put(threadId, threadCaches);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/g/ab", exception);
            }
            byte[] keyBytes = new byte[8];
            keyBytes[0] = (byte)(l2 >>> 56);
            for (int i2 = 1; i2 < 8; ++i2) {
                keyBytes[i2] = (byte)(l2 << i2 * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(keyBytes);
            SecretKey secretKey = ((SecretKeyFactory)threadCaches[1]).generateSecret(dESKeySpec);
            ((Cipher)threadCaches[0]).init(2, (Key)secretKey, (IvParameterSpec)threadCaches[2]);
            byte[] encryptedBytes = t[cacheIndex].getBytes("ISO-8859-1");
            MotionBlur.u[cacheIndex] = MotionBlur.b(((Cipher)threadCaches[0]).doFinal(encryptedBytes));
        }
        return u[cacheIndex];
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        String string2 = MotionBlur.b(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static CallSite b(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/ab" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int decodeIndex(long l2, long l3) {
        int n2;
        int n3;
        int tableIndex = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (y[tableIndex] != null) {
            return tableIndex;
        }
        Object entry = x[tableIndex];
        if (!(entry instanceof String)) {
            return tableIndex;
        }
        int decodeOffset = 0;
        decodeOffset = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 22;
            case 1 -> 41;
            case 2 -> 59;
            case 3 -> 14;
            case 4 -> 30;
            case 5 -> 6;
            case 6 -> 27;
            case 7 -> 21;
            case 8 -> 1;
            case 9 -> 19;
            case 10 -> 40;
            case 11 -> 36;
            case 12 -> 46;
            case 13 -> 34;
            case 14 -> 31;
            case 15 -> 28;
            case 16 -> 13;
            case 17 -> 3;
            case 18 -> 26;
            case 19 -> 9;
            case 20 -> 38;
            case 21 -> 53;
            case 22 -> 48;
            case 23 -> 2;
            case 24 -> 10;
            case 25 -> 17;
            case 26 -> 47;
            case 27 -> 8;
            case 28 -> 0;
            case 29 -> 24;
            case 30 -> 55;
            case 31 -> 11;
            case 32 -> 62;
            case 33 -> 49;
            case 34 -> 52;
            case 35 -> 12;
            case 36 -> 57;
            case 37 -> 37;
            case 38 -> 18;
            case 39 -> 23;
            case 40 -> 7;
            case 41 -> 63;
            case 42 -> 39;
            case 43 -> 60;
            case 44 -> 54;
            case 45 -> 51;
            case 46 -> 61;
            case 47 -> 5;
            case 48 -> 33;
            case 49 -> 35;
            case 50 -> 25;
            case 51 -> 32;
            case 52 -> 29;
            case 53 -> 43;
            case 54 -> 56;
            case 55 -> 45;
            case 56 -> 4;
            case 57 -> 50;
            case 58 -> 44;
            case 59 -> 15;
            case 60 -> 42;
            case 61 -> 16;
            case 62 -> 58;
            default -> 20;
        };
        int[] keyBytes = new int[6];
        int keyIndex = 0;
        while (keyIndex < 6) {
            n3 = 7 * (5 - keyIndex);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= decodeOffset) < 0) {
                n2 += 128;
            }
            keyBytes[keyIndex] = n2;
            ++keyIndex;
        }
        char[] chars = ((String)entry).toCharArray();
        n3 = 0;
        while (n3 < chars.length) {
            n2 = keyBytes[n3 % keyBytes.length];
            if (n2 == 0) break;
            chars[n3] = (char)(chars[n3] ^ n2);
            ++n3;
        }
        MotionBlur.y[tableIndex] = new String(chars);
        return tableIndex;
    }

    private static void c() {
        Object[] objectArray = x;
        x[0] = "x\u0004\u0003\u001fK-u\u0004\u0003\u001fK";
        objectArray[1] = "2h\u0007+$};f\u0004bgp=f\u0010`zv\u007fw\u0003u,~8i\u000f+\u001bw?c\u000fw\u0019{!b\u0006l'wuE\u001fl%v4u";
        objectArray[2] = "EUS;:?L[Pry2J[Dpd4\bJWe2<OT[;\u00055H^[g\u00079V_R|95";
        objectArray[3] = Long.TYPE;
        MotionBlur.y[3] = "java/lang/Long";
        objectArray[4] = "9Dn$\bE2K\u007fku]!Lv\"";
        objectArray[5] = "p,\u0010\u0012J\u0010},\u0010\u0012I";
        objectArray[6] = Integer.TYPE;
        MotionBlur.y[6] = "java/lang/Integer";
        objectArray[7] = "\u0010hC{\u000f\b\u0019f@2L\u0005\u001ffT0Q\u0003]e[3\u0004\u0002\u0001t\u0000\u0012\u0012\u00121rH3\u0007\u0015";
        objectArray[8] = "N/#\u0014T5E/%\u0014Ty";
        objectArray[9] = "QI'\u0004\u007f\u0000QI0Xs\u000fK\u00020Fs\u001aLsb\u0018#Z\b";
        objectArray[10] = "&V65/=&V!i#2<\u001d!w#';lt(tc";
        objectArray[11] = "0\u001a\f\u00150u;\u001a\u0004";
        objectArray[12] = "Mzr\u0015(L@zr\u0015*";
        objectArray[13] = "BU\n\u001e{\tOU\n\u001e~";
        objectArray[14] = Void.TYPE;
        MotionBlur.y[14] = "java/lang/Void";
        objectArray[15] = Boolean.TYPE;
        MotionBlur.y[15] = "java/lang/Boolean";
        objectArray[16] = "\u000b7tc.z\u00027wc\"";
        objectArray[17] = "|:\ro\u0011pw:\u0006";
        objectArray[18] = "gR\u0011#+\\\u0012r\u001a,:\u0013s|\u0011'>I\u0007";
        objectArray[19] = "\nK`\"\u0013)\u0001Kf\"\u0013C";
        objectArray[20] = "Z\u001a";
        objectArray[21] = "#q\u0010\u0003{u/q\u0003";
        objectArray[22] = "U\u001f\u000bPCoU\u001f\u001c\fO`OT\u001c\u0012OuH%LO\u001e";
        objectArray[23] = "Y\u0017;\u007f(eP\u001986khV\u0019,4vn\u0014\f3)1\u007fH\u001d%\u007f\u0002zO,3)1\u007fH\u001d\u00008 }";
        objectArray[24] = "wm0\u0016J\u0010ie*Y\u0002\u0010so2\u001e\u000b\u000b3O)\u0019\u0017\u0010pi4";
        objectArray[25] = "Iw]\u0006%hJy\u0005%rrFT^\u0001mcQ";
        objectArray[26] = "\u001d/\u0002UZa\u0014/\u0001UZ";
        objectArray[27] = "V%T\u000e\u0012\u001c]*EAs\u0012V!A\u001b";
        objectArray[28] = ">8X-\u000eEK\u0018S\"\u001f\n*\u0016X)\u001bP^";
        objectArray[29] = "-Ff(o\u001b-Fqtc\u00147\rqjc\u00010| 14";
        objectArray[30] = "\u0007]\u001e2\u000b\b\u001dR\u001f\n\u001bpR\u0006W2\u0013\u001a\u0007OPvrJ\u0014M\u001e:\u001f\u001d\u0010[_\nH\fW\u0001Nx\u0003\u0011\u0015G/6\u0011\u000b\u0011\u0004VpM\u0000\u0013=\u0013i\t\fTDU5\u0002\u000emTQd\u0015M\u001fLB2\rpR\u0006W2\u0013\u001a\u0007OPvr";
        objectArray[31] = "V#4\b\u00001S#'Wx{kz CI1\u0006-$U\b";
        objectArray[32] = "OQ4~\n?JQ'!rvr['+\u00152\u0000C4}\r";
        objectArray[33] = "\u001frXmcF\u0005}YUs>Ok\u0019d*S\u0018o\u000f%\u001aP\u0004n\u00036%D\u001arVU";
        objectArray[34] = " \u0014k\u0001Ky%\u0014x^3.\u001d\u001dg\\W0r\u001ekAU";
        objectArray[35] = "W0p\fC#M?q4S[\u0007,{\b[)L19N:5L,+W\u0005!R0~4S%S7|FK6\u0005/A\r_?G)8\tQ`\fP.ID1@>z^A1=j8D\u000bkP=<RJ[T`\u007f\r\nf\fh,F:";
        objectArray[36] = "0A\u0013N^:2\u0019\u0018G#2\u000b\u0018\u0006\u0007\u0012kfO\u0002\u0011S[k_\u0006IJ+rH\u0010\u0012#";
        objectArray[37] = "i\u0010@\u000e8`s\u001fA6(\u00189\t\u0001\u0007qun\r\u0017FA\"\u007fJMW3ib\b\u000b6x$a\u001c\u0003Y:s|Iq";
        objectArray[38] = "|NToJhyNG02>A\u0016Z8\u000b% \u0014\u00023\u0002";
        objectArray[39] = "&S$\u001aOm#S7E74\u001b]8_\u0006\"{_8P\u000b]vA7\u0010H=tA8\u001d7";
        objectArray[40] = "MyRH1BLtE\u0013LS,q\nK5]\\a_Hs:";
        objectArray[41] = "Gm\bcnVBm\u001b<\u0016\u000fzm\\$t]D3\u0005;if\u0013>[a&[K6\b*\u0016";
        objectArray[42] = ">&<4*9$)=\f9Aj(|w/\u007fj,|jS";
        objectArray[43] = "yR\u0001:~T{\n\n3\u0003\\B\r\u000ex\u007f\f;KRs}5~R\u0016\u007f:L8\u000e\u001d}\u0003\t!J\u0011:zO}A\u0013\u0003?G#T\u0016?aV}[m";
        objectArray[44] = "be\\|\u001d4bcG,`\u0000\u001f\u001dt\\:Zbe\\|\u001d4bcG,";
        objectArray[45] = ")iKKaR2\u007f\u0003\u000b[CBiRC?U?z\u000b\u000e0";
        objectArray[46] = "T-\u0006B\u0010a\u0004o\b@owdc\u0003\u0000\t`\u0003(\u0002V\u0016\u001e^+\u0014\u000e_s\t/\u0002OowTl]\u000fR/\\?\u0016?";
        objectArray[47] = "J]\u0005m\roWI\u0004>cf&ZJ?\u001d2G\u0007Vm\u000e\f";
        objectArray[48] = "Kv'FmNNv4\u0019\u0015\u001bv,/\u0019o\u0007\u000f(!F$";
        objectArray[49] = "zxy\u001f6Ran1_\fF\u0011\u007fwIk\u0017cgd\u001fs*";
        objectArray[50] = "\u0007\u0013=.e,\u0005K6'\u0018$<J(g)}Q\u001d,qhMU@o.(p\rH<e\u0018";
        objectArray[51] = ")VS4w,3YR\fgTz\n\u0000`|;8]\u001d5\u000em&R\u0018uwi(\rS\f";
        objectArray[52] = "\u001bO\u0007[\f\b\u001eO\u0014\u0004t@&\u0013Q\u0018LYLF\u0018\u001f\b";
        objectArray[53] = "*. S\u001fy18h\u0013%eA#i\u0017G:\u007f}0\bZ\u0001(pnR\u0015<px=\u0019%";
        Object[] objectArray2 = objectArray;
        objectArray[54] = "\".s(EV8!r\u0010U.++=,@\u00131w|y<";
    }

    private static Class resolveClass(long l2, long l3) {
        Object entry;
        Class<?> clazz;
        block2: {
            clazz = null;
            int tableIndex = MotionBlur.decodeIndex(l2, l3);
            entry = x[tableIndex];
            try {
                if (!(entry instanceof String)) break block2;
                MotionBlur.x[tableIndex] = clazz = Class.forName(y[tableIndex]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)entry;
        return clazz;
    }

    private static Field findDeclaredField(Class ownerClass, String memberName, Class memberType) {
        for (Field field : ownerClass.getDeclaredFields()) {
            if (!field.getName().equals(memberName) || field.getType() != memberType) continue;
            return field;
        }
        return null;
    }

    private static Field findField(Class ownerClass, String memberName, Class memberType) {
        Field field = MotionBlur.findDeclaredField(ownerClass, memberName, memberType);
        if (field != null) {
            return field;
        }
        Class<?>[] interfaces = ownerClass.getInterfaces();
        if (interfaces != null) {
            for (int index = 0; index < interfaces.length; ++index) {
                field = MotionBlur.findField(interfaces[index], memberName, memberType);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field resolveField(long l2, long l3) {
        int tableIndex = MotionBlur.decodeIndex(l2, l3);
        Object entry = x[tableIndex];
        if (entry instanceof String) {
            String descriptor = y[tableIndex];
            int separatorIndex = descriptor.indexOf(8);
            Class clazz = MotionBlur.resolveClass(Long.parseLong(descriptor.substring(0, separatorIndex), 36), 0L);
            int nextSeparatorIndex = descriptor.indexOf(8, ++separatorIndex);
            String memberName = descriptor.substring(separatorIndex, nextSeparatorIndex);
            Class clazz2 = MotionBlur.resolveClass(Long.parseLong(descriptor.substring(++nextSeparatorIndex), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = MotionBlur.findDeclaredField(clazz3, memberName, clazz2)) != null) {
                    MotionBlur.x[tableIndex] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = MotionBlur.findField(classArray[i2], memberName, clazz2);
                        if (field == null) continue;
                        MotionBlur.x[tableIndex] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = MotionBlur.resolveClass(1950933969774079L, 0L);
            }
            StringBuffer errorMessage = new StringBuffer();
            errorMessage.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(memberName);
            throw new RuntimeException(errorMessage.toString());
        }
        return (Field)entry;
    }

    private static Method findDeclaredMethod(Class ownerClass, String memberName, Class returnType, int parameterCount, Class[] expectedParameterTypes) {
        block0: for (Method method : ownerClass.getDeclaredMethods()) {
            Class<?>[] parameterTypes;
            if (!method.getName().equals(memberName) || method.getReturnType() != returnType || (parameterTypes = method.getParameterTypes()).length != parameterCount) continue;
            for (int index = 0; index < parameterCount; ++index) {
                if (parameterTypes[index] != expectedParameterTypes[index]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method findMethod(Class ownerClass, String memberName, Class returnType, int parameterCount, Class[] expectedParameterTypes) {
        Method method = MotionBlur.findDeclaredMethod(ownerClass, memberName, returnType, parameterCount, expectedParameterTypes);
        if (method != null) {
            return method;
        }
        Class<?>[] interfaces = ownerClass.getInterfaces();
        if (interfaces != null) {
            for (int index = 0; index < interfaces.length; ++index) {
                method = MotionBlur.findMethod(interfaces[index], memberName, returnType, parameterCount, expectedParameterTypes);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method resolveMethod(long l2, long l3) {
        int tableIndex = MotionBlur.decodeIndex(l2, l3);
        Object entry = x[tableIndex];
        if (entry instanceof String) {
            Class<?>[] interfaces;
            Class clazz;
            Class clazz2;
            Class[] parameterTypes;
            int parameterCount;
            String methodName;
            Class clazz3;
            block10: {
                String descriptor = y[tableIndex];
                int firstSeparatorIndex = descriptor.indexOf(8);
                clazz3 = MotionBlur.resolveClass(Long.parseLong(descriptor.substring(0, firstSeparatorIndex), 36), 0L);
                int secondSeparatorIndex = descriptor.indexOf(8, ++firstSeparatorIndex);
                methodName = descriptor.substring(firstSeparatorIndex, secondSeparatorIndex);
                int separatorCount = -1;
                int scanIndex = secondSeparatorIndex;
                do {
                    ++separatorCount;
                    ++scanIndex;
                } while ((scanIndex = descriptor.indexOf(8, scanIndex)) > -1);
                parameterCount = separatorCount - 1;
                parameterTypes = new Class[parameterCount];
                clazz2 = null;
                scanIndex = secondSeparatorIndex + 1;
                for (int i2 = 0; i2 < separatorCount; ++i2) {
                    int nextSeparatorIndex = descriptor.indexOf(8, scanIndex);
                    clazz2 = MotionBlur.resolveClass(Long.parseLong(descriptor.substring(scanIndex, nextSeparatorIndex), 36), 0L);
                    if (i2 < parameterCount) {
                        parameterTypes[i2] = clazz2;
                    }
                    scanIndex = nextSeparatorIndex + 1;
                }
                clazz = clazz3;
                do {
                    if ((interfaces = MotionBlur.findDeclaredMethod(clazz, methodName, clazz2, parameterCount, parameterTypes)) != null) {
                        MotionBlur.x[tableIndex] = interfaces;
                        return interfaces;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = MotionBlur.resolveClass(1950933969774079L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((interfaces = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < interfaces.length; ++i3) {
                        Method method = MotionBlur.findMethod(interfaces[i3], methodName, clazz2, parameterCount, parameterTypes);
                        if (method == null) continue;
                        MotionBlur.x[tableIndex] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = MotionBlur.resolveClass(1950933969774079L, 0L);
            }
            StringBuffer errorMessage = new StringBuffer();
            errorMessage.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(methodName).append('(');
            int parameterIndex = 0;
            while (parameterIndex < parameterCount) {
                errorMessage.append(parameterTypes[parameterIndex].getName());
                if (++parameterIndex >= parameterCount) continue;
                errorMessage.append(", ");
            }
            errorMessage.append(')');
            throw new RuntimeException(errorMessage.toString());
        }
        return (Method)entry;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == 'l' || c2 == '\u00e9' || c2 == 'Z' || c2 == 'c') {
                field = MotionBlur.resolveField(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == 'l' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == '\u00e9' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == 'Z' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = MotionBlur.resolveMethod(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == '\u00fe' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == 'D' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = MotionBlur.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/ab" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(MotionBlur.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(MotionBlur.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

