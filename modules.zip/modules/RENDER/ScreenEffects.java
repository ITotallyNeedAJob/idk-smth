// === Kuzi module: ScreenEffects ===
// Category   : RENDER
// Description: Color grading, vignette, chromatic aberration, film grain and sharpen
// Payload    : a.a.a.j.g.ai (verified: False)

package kuzi.modules.render;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.textures.GpuTextureView;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.b.e;
import kuzi.obf.h.b.v;
import kuzi.obf.l.a.a;
import kuzi.obf.l.a.b;
import kuzi.obf.l.a.c;
import kuzi.obf.l.a.d;
import kuzi.obf.m.r;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.UniformType;
import net.minecraft.GpuSampler;
import net.minecraft.RenderTarget;

public class ScreenEffects
extends BaseModule
implements d {
    private static final RenderPipeline screenFxPipeline;
    private static final b n;
    public final BoolSetting colorGrading;
    public final SliderSetting brightness;
    public final SliderSetting contrast;
    public final SliderSetting r;
    public final SliderSetting hueShift;
    public final e t;
    public final SliderSetting tintAmount;
    public final BoolSetting vignette;
    public final SliderSetting vignetteStrength;
    public final SliderSetting vignetteSize;
    public final BoolSetting chromaticAberration;
    public final SliderSetting aberrationStrength;
    public final BoolSetting filmGrain;
    public final SliderSetting grainStrength;
    public final BoolSetting sharpen;
    public final SliderSetting sharpenStrength;
    private static final long E;
    private static final String[] F;
    private static final String[] G;
    private static final Map H;
    private static final long[] I;
    private static final Integer[] J;
    private static final Map K;
    private static final Object[] L;
    private static final String[] M;

    public ScreenEffects() {
        long l2;
        long l3 = l2 = E ^ 0x66EBB52EA2FEL;
        long l4 = l3 ^ 0x78A5B3065343L;
        long l5 = l3 ^ 0x4DC41343B9EL;
        long l6 = l3 ^ 0x2C4BA24969BBL;
        super("Screen Effects", "Color grading, vignette, chromatic aberration, film grain and sharpen", Category.RENDER);
        this.colorGrading = new BoolSetting("Color Grading", false);
        this.brightness = new SliderSetting("Brightness", 0.0, -0.5, 0.5, 0.01);
        this.contrast = new SliderSetting("Contrast", 1.0, 0.5, 2.0, 0.01);
        this.r = new SliderSetting("Saturation", 1.0, 0.0, 2.0, 0.05);
        this.hueShift = new SliderSetting("Hue Shift", 0.0, -180.0, 180.0, 1.0);
        this.t = new e("Tint Color", new Color(255, 170, 110));
        this.tintAmount = new SliderSetting("Tint Amount", 0.0, 0.0, 1.0, 0.01);
        this.vignette = new BoolSetting("Vignette", false);
        this.vignetteStrength = new SliderSetting("Vignette Strength", 0.5, 0.0, 1.0, 0.01);
        this.vignetteSize = new SliderSetting("Vignette Size", 0.45, 0.0, 1.0, 0.01);
        this.chromaticAberration = new BoolSetting("Chromatic Aberration", false);
        this.aberrationStrength = new SliderSetting("Aberration Strength", 0.3, 0.0, 1.0, 0.01);
        this.filmGrain = new BoolSetting("Film Grain", false);
        this.grainStrength = new SliderSetting("Grain Strength", 0.25, 0.0, 1.0, 0.01);
        this.sharpen = new BoolSetting("Sharpen", false);
        this.sharpenStrength = new SliderSetting("Sharpen Strength", 0.3, 0.0, 1.0, 0.01);
        Object[] objectArray = new Object[2];
        objectArray[1] = this.colorGrading::a;
        objectArray[0] = l5;
        this.brightness.a(objectArray);
        Object[] objectArray2 = new Object[2];
        objectArray2[1] = this.colorGrading::a;
        objectArray2[0] = l5;
        this.contrast.a(objectArray2);
        Object[] objectArray3 = new Object[2];
        objectArray3[1] = this.colorGrading::a;
        objectArray3[0] = l5;
        this.r.a(objectArray3);
        Object[] objectArray4 = new Object[2];
        objectArray4[1] = this.colorGrading::a;
        objectArray4[0] = l5;
        this.hueShift.a(objectArray4);
        Object[] objectArray5 = new Object[2];
        objectArray5[1] = this.colorGrading::a;
        objectArray5[0] = l5;
        this.t.a(objectArray5);
        Object[] objectArray6 = new Object[2];
        objectArray6[1] = this.colorGrading::a;
        objectArray6[0] = l5;
        this.tintAmount.a(objectArray6);
        Object[] objectArray7 = new Object[2];
        objectArray7[1] = this.vignette::a;
        objectArray7[0] = l5;
        this.vignetteStrength.a(objectArray7);
        Object[] objectArray8 = new Object[2];
        objectArray8[1] = this.vignette::a;
        objectArray8[0] = l5;
        this.vignetteSize.a(objectArray8);
        Object[] objectArray9 = new Object[2];
        objectArray9[1] = this.chromaticAberration::a;
        objectArray9[0] = l5;
        this.aberrationStrength.a(objectArray9);
        Object[] objectArray10 = new Object[2];
        objectArray10[1] = this.filmGrain::a;
        objectArray10[0] = l5;
        this.grainStrength.a(objectArray10);
        Object[] objectArray11 = new Object[2];
        objectArray11[1] = this.sharpen::a;
        objectArray11[0] = l5;
        this.sharpenStrength.a(objectArray11);
        Object[] objectArray12 = new Object[2];
        objectArray12[1] = new Setting[]{this.colorGrading, this.brightness, this.contrast, this.r, this.hueShift, this.t, this.tintAmount, this.vignette, this.vignetteStrength, this.vignetteSize, this.chromaticAberration, this.aberrationStrength, this.filmGrain, this.grainStrength, this.sharpen, this.sharpenStrength};
        objectArray12[0] = l6;
        this.l(objectArray12);
        kuzi.obf.l.a.c.a(this, l4);
    }

    @Override
    public int a() {
        return 200;
    }

    @Override
    public boolean a(short s2, int n2, int n3) {
        Object object;
        block24: {
            block23: {
                block25: {
                    CallSite callSite;
                    long l2;
                    block22: {
                        l2 = (long)s2 << 48 | (long)n2 << 32 >>> 16 | (long)n3 << 48 >>> 48;
                        callSite = ScreenEffects.d("k", (long)7733582190476891568L, (long)l2);
                        try {
                            try {
                                object = ScreenEffects.d("K", (Object)this, (long)7733382064179297839L, (long)l2);
                                if (callSite == null) break block22;
                                if (object == false) break block23;
                            }
                            catch (r r2) {
                                throw ScreenEffects.d("k", (Object)r2, (long)7734104063383373764L, (long)l2);
                            }
                            object = (Boolean)((Object)ScreenEffects.d("K", (Object)ScreenEffects.d("d", (Object)this, (long)7732957720535981942L, (long)l2), (long)7734636593565531741L, (long)l2));
                        }
                        catch (r r3) {
                            throw ScreenEffects.d("k", (Object)r3, (long)7734104063383373764L, (long)l2);
                        }
                    }
                    try {
                        try {
                            try {
                                try {
                                    try {
                                        try {
                                            try {
                                                try {
                                                    try {
                                                        if (callSite == null) break block24;
                                                        if (object != false) break block25;
                                                    }
                                                    catch (r r4) {
                                                        throw ScreenEffects.d("k", (Object)r4, (long)7734104063383373764L, (long)l2);
                                                    }
                                                    object = (Boolean)((Object)ScreenEffects.d("K", (Object)ScreenEffects.d("d", (Object)this, (long)7733847483441021897L, (long)l2), (long)7734636593565531741L, (long)l2));
                                                    if (callSite == null) break block24;
                                                }
                                                catch (r r5) {
                                                    throw ScreenEffects.d("k", (Object)r5, (long)7734104063383373764L, (long)l2);
                                                }
                                                if (object != false) break block25;
                                            }
                                            catch (r r6) {
                                                throw ScreenEffects.d("k", (Object)r6, (long)7734104063383373764L, (long)l2);
                                            }
                                            object = (Boolean)((Object)ScreenEffects.d("K", (Object)ScreenEffects.d("d", (Object)this, (long)7733281656575185429L, (long)l2), (long)7734636593565531741L, (long)l2));
                                            if (callSite == null) break block24;
                                        }
                                        catch (r r7) {
                                            throw ScreenEffects.d("k", (Object)r7, (long)7734104063383373764L, (long)l2);
                                        }
                                        if (object != false) break block25;
                                    }
                                    catch (r r8) {
                                        throw ScreenEffects.d("k", (Object)r8, (long)7734104063383373764L, (long)l2);
                                    }
                                    object = (Boolean)((Object)ScreenEffects.d("K", (Object)ScreenEffects.d("d", (Object)this, (long)7734834802970565417L, (long)l2), (long)7734636593565531741L, (long)l2));
                                    if (callSite == null) break block24;
                                }
                                catch (r r9) {
                                    throw ScreenEffects.d("k", (Object)r9, (long)7734104063383373764L, (long)l2);
                                }
                                if (object != false) break block25;
                            }
                            catch (r r10) {
                                throw ScreenEffects.d("k", (Object)r10, (long)7734104063383373764L, (long)l2);
                            }
                            object = (Boolean)((Object)ScreenEffects.d("K", (Object)ScreenEffects.d("d", (Object)this, (long)7732103466207151844L, (long)l2), (long)7734636593565531741L, (long)l2));
                            if (callSite == null) break block24;
                        }
                        catch (r r11) {
                            throw ScreenEffects.d("k", (Object)r11, (long)7734104063383373764L, (long)l2);
                        }
                        if (object == false) break block23;
                    }
                    catch (r r12) {
                        throw ScreenEffects.d("k", (Object)r12, (long)7734104063383373764L, (long)l2);
                    }
                }
                object = true;
                break block24;
            }
            object = false;
        }
        return (boolean)object;
    }

    @Override
    public void a(int n2, char c2, int n3) {
        Object object;
        Object object2;
        CallSite callSite;
        CallSite callSite2;
        long l2;
        long l3;
        long l4;
        long l5;
        long l6;
        block48: {
            block50: {
                ScreenEffects screenEffects;
                long l7;
                block49: {
                    CallSite callSite3;
                    CallSite callSite4;
                    block45: {
                        block47: {
                            ScreenEffects screenEffects2;
                            block46: {
                                block42: {
                                    block44: {
                                        ScreenEffects screenEffects3;
                                        block43: {
                                            Object object3;
                                            Object object4;
                                            block39: {
                                                block41: {
                                                    ScreenEffects screenEffects4;
                                                    block40: {
                                                        block37: {
                                                            block38: {
                                                                float f2;
                                                                Object object5;
                                                                boolean bl;
                                                                block35: {
                                                                    block36: {
                                                                        block33: {
                                                                            block34: {
                                                                                block31: {
                                                                                    block32: {
                                                                                        block30: {
                                                                                            block29: {
                                                                                                long l8 = l6 = (long)n2 << 32 | (long)c2 << 48 >>> 32 | (long)n3 << 48 >>> 48;
                                                                                                long l9 = l8 ^ 0x5F372AD64AF8L;
                                                                                                long l10 = l8 ^ 0x2995213AAB0DL;
                                                                                                l7 = l8 ^ 0x10C3927753C1L;
                                                                                                l5 = l8 ^ 0x44C5C4EFF6B8L;
                                                                                                l4 = l8 ^ 0x609206165453L;
                                                                                                l3 = l8 ^ 0x6B27462E321FL;
                                                                                                l2 = l8 ^ 0x631C8F0E98C2L;
                                                                                                callSite2 = ScreenEffects.d("k", (long)1667276012651000746L, (long)l6);
                                                                                                callSite = ScreenEffects.d("k", (long)l10, (long)1674145028217911269L, (long)l6);
                                                                                                callSite4 = ScreenEffects.d("k", (long)1674273066969655775L, (long)l6);
                                                                                                bl = (Boolean)((Object)ScreenEffects.d("K", (Object)ScreenEffects.d("d", (Object)this, (long)1675337341628719897L, (long)l6), (long)1673634253556318770L, (long)l6));
                                                                                                callSite3 = ScreenEffects.d("K", (Object)ScreenEffects.d("Q", (long)1673504618972354071L, (long)l6), (long)l9, (long)1673153131075478730L, (long)l6);
                                                                                                try {
                                                                                                    object5 = callSite3;
                                                                                                    if (!bl) break block29;
                                                                                                    Object[] objectArray = new Object[2];
                                                                                                    objectArray[1] = l7;
                                                                                                    objectArray[0] = ScreenEffects.d("d", (Object)this, (long)1667457397120333117L, (long)l6);
                                                                                                    f2 = (float)ScreenEffects.d("k", (Object)objectArray, (long)1673915060019857230L, (long)l6);
                                                                                                    break block30;
                                                                                                }
                                                                                                catch (r r2) {
                                                                                                    throw ScreenEffects.d("k", (Object)r2, (long)1673664332649233323L, (long)l6);
                                                                                                }
                                                                                            }
                                                                                            f2 = 0.0f;
                                                                                        }
                                                                                        try {
                                                                                            if (n3 <= 0) break block31;
                                                                                            object5 = ((ByteBuffer)object5).putFloat(f2);
                                                                                            if (!bl) break block32;
                                                                                            Object[] objectArray = new Object[2];
                                                                                            objectArray[1] = l7;
                                                                                            objectArray[0] = ScreenEffects.d("d", (Object)this, (long)1667215487929666902L, (long)l6);
                                                                                            f2 = (float)ScreenEffects.d("k", (Object)objectArray, (long)1673915060019857230L, (long)l6);
                                                                                            break block31;
                                                                                        }
                                                                                        catch (r r3) {
                                                                                            throw ScreenEffects.d("k", (Object)r3, (long)1673664332649233323L, (long)l6);
                                                                                        }
                                                                                    }
                                                                                    f2 = 1.0f;
                                                                                }
                                                                                try {
                                                                                    if (n2 <= 0) break block33;
                                                                                    object5 = ((ByteBuffer)object5).putFloat(f2);
                                                                                    if (!bl) break block34;
                                                                                    Object[] objectArray = new Object[2];
                                                                                    objectArray[1] = l7;
                                                                                    objectArray[0] = ScreenEffects.d("d", (Object)this, (long)1673555940920252233L, (long)l6);
                                                                                    f2 = (float)ScreenEffects.d("k", (Object)objectArray, (long)1673915060019857230L, (long)l6);
                                                                                    break block33;
                                                                                }
                                                                                catch (r r4) {
                                                                                    throw ScreenEffects.d("k", (Object)r4, (long)1673664332649233323L, (long)l6);
                                                                                }
                                                                            }
                                                                            f2 = 1.0f;
                                                                        }
                                                                        try {
                                                                            if (c2 <= '\u0000') break block35;
                                                                            object5 = ((ByteBuffer)object5).putFloat(f2);
                                                                            if (!bl) break block36;
                                                                            Object[] objectArray = new Object[2];
                                                                            objectArray[1] = l7;
                                                                            objectArray[0] = ScreenEffects.d("d", (Object)this, (long)1674080391189651707L, (long)l6);
                                                                            f2 = (float)Math.toRadians((double)ScreenEffects.d("k", (Object)objectArray, (long)1673915060019857230L, (long)l6));
                                                                            break block35;
                                                                        }
                                                                        catch (r r5) {
                                                                            throw ScreenEffects.d("k", (Object)r5, (long)1673664332649233323L, (long)l6);
                                                                        }
                                                                    }
                                                                    f2 = 0.0f;
                                                                }
                                                                ((ByteBuffer)object5).putFloat(f2);
                                                                CallSite callSite5 = ScreenEffects.d("K", (Object)ScreenEffects.d("d", (Object)this, (long)1674050540812128982L, (long)l6), (long)1675206630579409210L, (long)l6);
                                                                try {
                                                                    try {
                                                                        object4 = ((ByteBuffer)((Object)callSite3)).putFloat((float)((Color)((Object)callSite5)).getRed() / 255.0f).putFloat((float)((Color)((Object)callSite5)).getGreen() / 255.0f);
                                                                        int n4 = ((Color)((Object)callSite5)).getBlue();
                                                                        if (c2 > '\u0000') {
                                                                            object3 = (float)n4 / 255.0f;
                                                                            if (callSite4 == null) break block37;
                                                                            object4 = ((ByteBuffer)object4).putFloat((float)object3);
                                                                            n4 = bl ? 1 : 0;
                                                                        }
                                                                        if (n4 == 0) break block38;
                                                                    }
                                                                    catch (r r6) {
                                                                        throw ScreenEffects.d("k", (Object)r6, (long)1673664332649233323L, (long)l6);
                                                                    }
                                                                    Object[] objectArray = new Object[2];
                                                                    objectArray[1] = l7;
                                                                    objectArray[0] = ScreenEffects.d("d", (Object)this, (long)1674971154951024886L, (long)l6);
                                                                    object3 = ScreenEffects.d("k", (Object)objectArray, (long)1673915060019857230L, (long)l6);
                                                                    break block37;
                                                                }
                                                                catch (r r7) {
                                                                    throw ScreenEffects.d("k", (Object)r7, (long)1673664332649233323L, (long)l6);
                                                                }
                                                            }
                                                            object3 = 0.0f;
                                                        }
                                                        try {
                                                            try {
                                                                if (n3 < 0) break block39;
                                                                ((ByteBuffer)object4).putFloat((float)object3);
                                                                object4 = callSite3;
                                                                screenEffects4 = this;
                                                                if (callSite4 == null) break block40;
                                                                if (!((Boolean)((Object)ScreenEffects.d("K", (Object)ScreenEffects.d("d", (Object)screenEffects4, (long)1673974788652957606L, (long)l6), (long)1673634253556318770L, (long)l6))).booleanValue()) break block41;
                                                            }
                                                            catch (r r8) {
                                                                throw ScreenEffects.d("k", (Object)r8, (long)1673664332649233323L, (long)l6);
                                                            }
                                                            screenEffects4 = this;
                                                        }
                                                        catch (r r9) {
                                                            throw ScreenEffects.d("k", (Object)r9, (long)1673664332649233323L, (long)l6);
                                                        }
                                                    }
                                                    Object[] objectArray = new Object[2];
                                                    objectArray[1] = l7;
                                                    objectArray[0] = ScreenEffects.d("d", (Object)screenEffects4, (long)1667018212272749340L, (long)l6);
                                                    object3 = ScreenEffects.d("k", (Object)objectArray, (long)1673915060019857230L, (long)l6);
                                                    break block39;
                                                }
                                                object3 = 0.0f;
                                            }
                                            try {
                                                try {
                                                    object2 = ((ByteBuffer)object4).putFloat((float)object3);
                                                    Object[] objectArray = new Object[2];
                                                    objectArray[1] = l7;
                                                    objectArray[0] = ScreenEffects.d("d", (Object)this, (long)1674866063298768385L, (long)l6);
                                                    object = ScreenEffects.d("k", (Object)objectArray, (long)1673915060019857230L, (long)l6);
                                                    if (n2 < 0) break block42;
                                                    object2 = ((ByteBuffer)object2).putFloat((float)object);
                                                    screenEffects3 = this;
                                                    if (callSite4 == null) break block43;
                                                    if (!((Boolean)((Object)ScreenEffects.d("K", (Object)ScreenEffects.d("d", (Object)screenEffects3, (long)1674530702720642682L, (long)l6), (long)1673634253556318770L, (long)l6))).booleanValue()) break block44;
                                                }
                                                catch (r r10) {
                                                    throw ScreenEffects.d("k", (Object)r10, (long)1673664332649233323L, (long)l6);
                                                }
                                                screenEffects3 = this;
                                            }
                                            catch (r r11) {
                                                throw ScreenEffects.d("k", (Object)r11, (long)1673664332649233323L, (long)l6);
                                            }
                                        }
                                        Object[] objectArray = new Object[2];
                                        objectArray[1] = l7;
                                        objectArray[0] = ScreenEffects.d("d", (Object)screenEffects3, (long)1673836181575429368L, (long)l6);
                                        object = ScreenEffects.d("k", (Object)objectArray, (long)1673915060019857230L, (long)l6);
                                        break block42;
                                    }
                                    object = 0.0f;
                                }
                                try {
                                    try {
                                        if (c2 <= '\u0000') break block45;
                                        object2 = ((ByteBuffer)object2).putFloat((float)object);
                                        screenEffects2 = this;
                                        if (callSite4 == null) break block46;
                                        if (!((Boolean)((Object)ScreenEffects.d("K", (Object)ScreenEffects.d("d", (Object)screenEffects2, (long)1673268926981662534L, (long)l6), (long)1673634253556318770L, (long)l6))).booleanValue()) break block47;
                                    }
                                    catch (r r12) {
                                        throw ScreenEffects.d("k", (Object)r12, (long)1673664332649233323L, (long)l6);
                                    }
                                    screenEffects2 = this;
                                }
                                catch (r r13) {
                                    throw ScreenEffects.d("k", (Object)r13, (long)1673664332649233323L, (long)l6);
                                }
                            }
                            Object[] objectArray = new Object[2];
                            objectArray[1] = l7;
                            objectArray[0] = ScreenEffects.d("d", (Object)screenEffects2, (long)1674464120395924341L, (long)l6);
                            object = ScreenEffects.d("k", (Object)objectArray, (long)1673915060019857230L, (long)l6);
                            break block45;
                        }
                        object = 0.0f;
                    }
                    try {
                        try {
                            if (n2 < 0) break block48;
                            ((ByteBuffer)object2).putFloat((float)object);
                            object2 = callSite3;
                            screenEffects = this;
                            if (callSite4 == null) break block49;
                            if (!((Boolean)((Object)ScreenEffects.d("K", (Object)ScreenEffects.d("d", (Object)screenEffects, (long)1667160198794148491L, (long)l6), (long)1673634253556318770L, (long)l6))).booleanValue()) break block50;
                        }
                        catch (r r14) {
                            throw ScreenEffects.d("k", (Object)r14, (long)1673664332649233323L, (long)l6);
                        }
                        screenEffects = this;
                    }
                    catch (r r15) {
                        throw ScreenEffects.d("k", (Object)r15, (long)1673664332649233323L, (long)l6);
                    }
                }
                Object[] objectArray = new Object[2];
                objectArray[1] = l7;
                objectArray[0] = ScreenEffects.d("d", (Object)screenEffects, (long)1674637233213074581L, (long)l6);
                object = ScreenEffects.d("k", (Object)objectArray, (long)1673915060019857230L, (long)l6);
                break block48;
            }
            object = 0.0f;
        }
        ((ByteBuffer)object2).putFloat((float)object).putFloat((float)ScreenEffects.d("k", (long)l4, (long)1675163075642356636L, (long)l6)).putFloat(1.0f / (float)((RenderTarget)callSite2).width).putFloat(1.0f / (float)((RenderTarget)callSite2).height);
        ScreenEffects.d("K", (Object)ScreenEffects.d("Q", (long)1673504618972354071L, (long)l6), (long)l5, (long)1674385742774614533L, (long)l6);
        ScreenEffects.d("k", (Object)ScreenEffects.b("q", (int)6178, (long)(0x180064984F9A0D7CL ^ l6)), (Object)callSite2.getColorTextureView(), (boolean)false, (Object)ScreenEffects.d("Q", (long)1666898538708268299L, (long)l6), arg_0 -> ScreenEffects.lambda$apply$0((GpuTextureView)callSite, l2, arg_0), (long)l3, (long)1673161372391614878L, (long)l6);
    }

    private static void lambda$apply$0(GpuTextureView gpuTextureView, long l2, RenderPass renderPass) {
        long l3 = (l2 = E ^ l2) ^ 0x1678D8FB86A1L;
        int n2 = (int)(l3 >>> 32);
        int n3 = (int)(l3 << 32 >>> 48);
        int n4 = (int)(l3 << 48 >>> 48);
        renderPass.bindTexture((String)((Object)ScreenEffects.b("q", (int)23533, (long)(0x9F476960AED8620L ^ l2))), gpuTextureView, (GpuSampler)ScreenEffects.d("k", (long)-2329460738410305342L, (long)l2));
        renderPass.setUniform((String)((Object)ScreenEffects.b("q", (int)5783, (long)(0x5E84838A6D27CB44L ^ l2))), (GpuBuffer)ScreenEffects.d("K", (Object)ScreenEffects.d("Q", (long)-2329641070733402491L, (long)l2), (int)n2, (int)n3, (int)n4, (long)-2329236844359077280L, (long)l2));
    }

    /*
     * Unable to fully structure code
     */
    static {
        block21: {
            block20: {
                block19: {
                    block18: {
                        ScreenEffects.E = kuzi.obf.h.b.v.a(7783421835418955904L, 802103312701850897L, MethodHandles.lookup().lookupClass()).a(211865347042248L);
                        var20 = ScreenEffects.E ^ 65794481306084L;
                        var22_1 = var20 ^ 61080997630510L;
                        ScreenEffects.L = new Object[71];
                        ScreenEffects.M = new String[71];
                        ScreenEffects.c();
                        ScreenEffects.H = new HashMap<K, V>(13);
                        var11_2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var20 >>> 56);
                        for (var12_3 = 1; var12_3 < 8; ++var12_3) {
                            v2 = v2;
                            v2[var12_3] = (byte)(var20 << var12_3 * 8 >>> 56);
                        }
                        var11_2.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var18_4 = new String[25];
                        var16_5 = 0;
                        var15_6 = "o\u00e2\u0011\u00cc\u00e3\u0093\u00d4l7u\u0090e3\u00cf\u0012\u00f5\u00c0\u0099\u00ea&I\u00a1\u00d2M\u00e0\u00d4V\u00ebp\u00c6\u00afup\u00bd\t8\u0089\u00db\u00f9\u001f\u00a9\u00eb\u0011x\u008ae\u00f2\u0090\u000fK\\\u0092\u00e7\u0011\u0088\u00c0HD\u0094O\u00bd\n|\u00cd\u008c\u008c\u0084\u00e2\u00f0^e\u0012i!5h\u0011{\u00a4b\u009e\u00b5\t\u00a8\u00a3\u0094N\u00be\u0083\u00f6\u00a7\u00a5G\u00e3\u00a6\u00fd\u00e7b\u00db\u00b2\u00c3A\u0015\u00f6\u00a3\u009e\u00fe\u00d7\u00b8E\u0093\u00cf\u0099YwFG\u00f1\u009ej\u00c6\t\u00be\u00cb\u00da\r\u00c5\u00d2gY@l\u0006&\u00cf\u00ed\u009e\u00e3\u0018m[\u00b8V-\u0088(\u0001Zp_\u0099\u009e7\u00cf4\u0096\u00ca\u001c\u00f3\u00f2\"2\u00e0]<\u0010@S\u00c0\u00e5Z\u00cb\u00da\u009ddV;\u00c0\u00ab\u0091\u00ad\u000eg\u00c5\u00c2l \u00d1\u0094\u0010\u00d2\u008a\u00b7\u001a\u0096\u009c\u00c5\u00f0\f1\u00d5*\u00fb\u00a6X/K\u00d8~\u0090 \u0003\u00d2\u0017_y\u008e\r0\u0018\u00a2Q/\u00c5j^x\u00a6\u00f0\\\u00da\u0087\u00c6\u0018\"m\u0011\u008b1\\_\u00c0\u009b\u0084 J\u00b0w4x.2\u00ad\u00bb\u0010\u00ccd!\u0014\u009fJA\u00f7\u00aa]\u00aa)\u00d6\u001d\u00af6\u0007#\u0089\u0000\u008b\u0087 U\u00f7\u00b7\u0007\u00f9\u00cf\u00f6j\u00f0\u0003\u0007\na\u00a0\u00b6\u00df\u00e2\u00c6-\u00b9\u00adz\u00d7t\u008d,KG\u00a6\u00b7\u0087\u0084(\u00ae4\u009ax\u0085\u0002\\F\u0080P\u001c\u00f4}k%j\u00b3\u000e2\u00ee\u00e5\b\u0011L\u0082\u00acM\u009c\u0005\u00c8\u00f2&n`\u00eb\u001e*=0\u0011 4\u00fe%QJ:\u00a0\u008b\u00c9\u0002:2\u00e7H\u00bdx^\u00d4Gy'R\u0098\u0085\u00acE\u00ba[\u00d5\u00db\u0002\u00b7 d#\u0013\u0096M\u00ba\u00dd\u00f3\u0086\u0086#\u008c\u0092\u00dd\u0015\u0017\u00e0/\u000e\u0019\u00c0\u0006\u009e\u00a3\u00e5\u00fe\u0016t_n\u0091?\u0010\u008b\u0007*7!\u009b\u00d5\u0005\rC\u00bbx3P\u00f7\u008a px\f\u0088\u00d3\u00df)\u0081\u00ed\u001e\u001bC\u00ef^k\u00bdF\u00b2\u00baO\u00fc=\u00a5\u00a7\u008em\u00c7\u0094\u00e8\u000f\u00ce\u00a7 \u00fd\u00c8\u00ba%\u00c6\u008d\u000fmx\u0018\u0095\u00a8\u00a8\u00cd\u007f\u00da\u00ba\u00b8\u00f9\u0088Bs\u00a5\u00cf\u00ef\u00f6\u00ce7\u00e9bA\u00a6(\u00ed\u0010\u00b3\"\u00bf\u00d0\u00eafG\u00b9\u008ct\u0085\u00b4\u00cdHB\u00b4\u0088\u00b0p\u00a5@,T\u0084\"\u0080C\u00c7\u00a4\u00a1\u000bg\u00ed\u00a6\u00ddIHV\u0018\u00ad\u0097dQH%\u0098\u00d8:\u00ef\u000e\u00d6\u0090!\u00de\u009c\u00e9%e\u00a1U\u00aa\u00c6[\u0018\u0001\u00f5\u00b8E\u00c8\u0000n\u0000\u00b0\u001f\u00ba\u0095\u0094`Y\u00b2\u00d4Y\u00fdWs<Q\u00bf j\u00a93P\u0088Mx\u00dd;\u00885\u0015=\u00e6\u00da\u00fe\b/\u00e5\u00949\u00b7\u00d6\u0099\u00ca\u00b1\u00985\u0091<;\u00c7\u0010jY\u00ff\u008b\u0084\u00e4e\u0083\u00ed\u0097nD?\u0013d\u0010\u0018\u00bf\u00b1%\u0000\u00b6\u001a\u00eb\u00bc\\y\u00f7\u009a#\u00e5\u00ec\u00a9\u0006\u008f}\u00b8\u00f4l=\u00cd 3O\u001a&\u0001\u00bb\u00f9F\u0084\u001cA7\u00cbV3\u00c9z\u00b5\u00e5J\u00f4\u008f\u00ddYq\u0015\u008c\u009c\u00c4HCB \u00a6\u0015f\u00e5H\u00cf\u00e1{A\u00e2\u00cd\u00bd\u00b3\u00bf\u008b\u00b9\u00ba\u00a9\u00d1\u0086\u001at\u00b3\u00c5GR\u00e8\u009e\u00d2yT\u00a0 \u00d4\u001c\u0081;.\u00af\u007f\u00fa\u0003\u0005*W\u00a2\u00afY\u0007\u0017\u00e3\u00f8\u00c4,\u00fbC<\u00f0t\u0087i\u001f\u0010\u00d5\u001f\u0010%\u001e\u00bd\u0012@=\u00b0\u0087\u0006b\u009c\u00d4I\u00dd\u00c2\u00ee";
                        var17_7 = "o\u00e2\u0011\u00cc\u00e3\u0093\u00d4l7u\u0090e3\u00cf\u0012\u00f5\u00c0\u0099\u00ea&I\u00a1\u00d2M\u00e0\u00d4V\u00ebp\u00c6\u00afup\u00bd\t8\u0089\u00db\u00f9\u001f\u00a9\u00eb\u0011x\u008ae\u00f2\u0090\u000fK\\\u0092\u00e7\u0011\u0088\u00c0HD\u0094O\u00bd\n|\u00cd\u008c\u008c\u0084\u00e2\u00f0^e\u0012i!5h\u0011{\u00a4b\u009e\u00b5\t\u00a8\u00a3\u0094N\u00be\u0083\u00f6\u00a7\u00a5G\u00e3\u00a6\u00fd\u00e7b\u00db\u00b2\u00c3A\u0015\u00f6\u00a3\u009e\u00fe\u00d7\u00b8E\u0093\u00cf\u0099YwFG\u00f1\u009ej\u00c6\t\u00be\u00cb\u00da\r\u00c5\u00d2gY@l\u0006&\u00cf\u00ed\u009e\u00e3\u0018m[\u00b8V-\u0088(\u0001Zp_\u0099\u009e7\u00cf4\u0096\u00ca\u001c\u00f3\u00f2\"2\u00e0]<\u0010@S\u00c0\u00e5Z\u00cb\u00da\u009ddV;\u00c0\u00ab\u0091\u00ad\u000eg\u00c5\u00c2l \u00d1\u0094\u0010\u00d2\u008a\u00b7\u001a\u0096\u009c\u00c5\u00f0\f1\u00d5*\u00fb\u00a6X/K\u00d8~\u0090 \u0003\u00d2\u0017_y\u008e\r0\u0018\u00a2Q/\u00c5j^x\u00a6\u00f0\\\u00da\u0087\u00c6\u0018\"m\u0011\u008b1\\_\u00c0\u009b\u0084 J\u00b0w4x.2\u00ad\u00bb\u0010\u00ccd!\u0014\u009fJA\u00f7\u00aa]\u00aa)\u00d6\u001d\u00af6\u0007#\u0089\u0000\u008b\u0087 U\u00f7\u00b7\u0007\u00f9\u00cf\u00f6j\u00f0\u0003\u0007\na\u00a0\u00b6\u00df\u00e2\u00c6-\u00b9\u00adz\u00d7t\u008d,KG\u00a6\u00b7\u0087\u0084(\u00ae4\u009ax\u0085\u0002\\F\u0080P\u001c\u00f4}k%j\u00b3\u000e2\u00ee\u00e5\b\u0011L\u0082\u00acM\u009c\u0005\u00c8\u00f2&n`\u00eb\u001e*=0\u0011 4\u00fe%QJ:\u00a0\u008b\u00c9\u0002:2\u00e7H\u00bdx^\u00d4Gy'R\u0098\u0085\u00acE\u00ba[\u00d5\u00db\u0002\u00b7 d#\u0013\u0096M\u00ba\u00dd\u00f3\u0086\u0086#\u008c\u0092\u00dd\u0015\u0017\u00e0/\u000e\u0019\u00c0\u0006\u009e\u00a3\u00e5\u00fe\u0016t_n\u0091?\u0010\u008b\u0007*7!\u009b\u00d5\u0005\rC\u00bbx3P\u00f7\u008a px\f\u0088\u00d3\u00df)\u0081\u00ed\u001e\u001bC\u00ef^k\u00bdF\u00b2\u00baO\u00fc=\u00a5\u00a7\u008em\u00c7\u0094\u00e8\u000f\u00ce\u00a7 \u00fd\u00c8\u00ba%\u00c6\u008d\u000fmx\u0018\u0095\u00a8\u00a8\u00cd\u007f\u00da\u00ba\u00b8\u00f9\u0088Bs\u00a5\u00cf\u00ef\u00f6\u00ce7\u00e9bA\u00a6(\u00ed\u0010\u00b3\"\u00bf\u00d0\u00eafG\u00b9\u008ct\u0085\u00b4\u00cdHB\u00b4\u0088\u00b0p\u00a5@,T\u0084\"\u0080C\u00c7\u00a4\u00a1\u000bg\u00ed\u00a6\u00ddIHV\u0018\u00ad\u0097dQH%\u0098\u00d8:\u00ef\u000e\u00d6\u0090!\u00de\u009c\u00e9%e\u00a1U\u00aa\u00c6[\u0018\u0001\u00f5\u00b8E\u00c8\u0000n\u0000\u00b0\u001f\u00ba\u0095\u0094`Y\u00b2\u00d4Y\u00fdWs<Q\u00bf j\u00a93P\u0088Mx\u00dd;\u00885\u0015=\u00e6\u00da\u00fe\b/\u00e5\u00949\u00b7\u00d6\u0099\u00ca\u00b1\u00985\u0091<;\u00c7\u0010jY\u00ff\u008b\u0084\u00e4e\u0083\u00ed\u0097nD?\u0013d\u0010\u0018\u00bf\u00b1%\u0000\u00b6\u001a\u00eb\u00bc\\y\u00f7\u009a#\u00e5\u00ec\u00a9\u0006\u008f}\u00b8\u00f4l=\u00cd 3O\u001a&\u0001\u00bb\u00f9F\u0084\u001cA7\u00cbV3\u00c9z\u00b5\u00e5J\u00f4\u008f\u00ddYq\u0015\u008c\u009c\u00c4HCB \u00a6\u0015f\u00e5H\u00cf\u00e1{A\u00e2\u00cd\u00bd\u00b3\u00bf\u008b\u00b9\u00ba\u00a9\u00d1\u0086\u001at\u00b3\u00c5GR\u00e8\u009e\u00d2yT\u00a0 \u00d4\u001c\u0081;.\u00af\u007f\u00fa\u0003\u0005*W\u00a2\u00afY\u0007\u0017\u00e3\u00f8\u00c4,\u00fbC<\u00f0t\u0087i\u001f\u0010\u00d5\u001f\u0010%\u001e\u00bd\u0012@=\u00b0\u0087\u0006b\u009c\u00d4I\u00dd\u00c2\u00ee".length();
                        var14_8 = 32;
                        var13_9 = -1;
lbl25:
                        // 2 sources

                        while (true) {
                            v3 = ++var13_9;
                            v4 = var15_6.substring(v3, v3 + var14_8);
                            v5 = -1;
                            break block18;
                            break;
                        }
lbl30:
                        // 1 sources

                        while (true) {
                            var18_4[var16_5++] = ScreenEffects.b(var19_10).intern();
                            if ((var13_9 += var14_8) < var17_7) {
                                var14_8 = var15_6.charAt(var13_9);
                                ** continue;
                            }
                            var15_6 = "K\u00fb|Q/\u009a|\u00e8\u009c\u008d\u00e5\\\u00b4\u00e2Db\u00d6\u00e72]\u00ac\u00a8\u008c!2\u00c7\u009d~p\u001d\u00f7^(\u0093t\u00f6\u00b6\u00b9\u00bf\u0084\u009cs\u00ecq\u001cs\u0082\u0016\u00e3\u0091l\u00fc\u0011\u0081'\u0086\u0007y\u00bcT\u00fb2\u0098\u00ec`\u00906\u0097\u009a\u00bcIf\u00c7";
                            var17_7 = "K\u00fb|Q/\u009a|\u00e8\u009c\u008d\u00e5\\\u00b4\u00e2Db\u00d6\u00e72]\u00ac\u00a8\u008c!2\u00c7\u009d~p\u001d\u00f7^(\u0093t\u00f6\u00b6\u00b9\u00bf\u0084\u009cs\u00ecq\u001cs\u0082\u0016\u00e3\u0091l\u00fc\u0011\u0081'\u0086\u0007y\u00bcT\u00fb2\u0098\u00ec`\u00906\u0097\u009a\u00bcIf\u00c7".length();
                            var14_8 = 32;
                            var13_9 = -1;
lbl39:
                            // 2 sources

                            while (true) {
                                v6 = ++var13_9;
                                v4 = var15_6.substring(v6, v6 + var14_8);
                                v5 = 0;
                                break block18;
                                break;
                            }
                            break;
                        }
lbl44:
                        // 1 sources

                        while (true) {
                            var18_4[var16_5++] = ScreenEffects.b(var19_10).intern();
                            if ((var13_9 += var14_8) < var17_7) {
                                var14_8 = var15_6.charAt(var13_9);
                                ** continue;
                            }
                            break block19;
                            break;
                        }
                    }
                    var19_10 = var11_2.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl56:
                        // 1 sources

                        ** continue;
                    }
                }
                ScreenEffects.F = var18_4;
                ScreenEffects.G = new String[25];
                ScreenEffects.K = new HashMap<K, V>(13);
                var0_11 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var20 >>> 56);
                for (var1_12 = 1; var1_12 < 8; ++var1_12) {
                    v9 = v9;
                    v9[var1_12] = (byte)(var20 << var1_12 * 8 >>> 56);
                }
                var0_11.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_13 = new long[15];
                var3_14 = 0;
                var4_15 = "\u00819\u0092\u00c1\u00a82\u0019\u001e:\u00cf\u008c\u007f\u00f96,Bb|\u009f\u0005.j\u001f\u00df\u00d0\u00a2On\u00d0\u0082\u00bd\u0097\u00c6\u00be\u00ff\u0087\u00b4\u00fb\u00b3H\r\u0092\u00ad<!\u0001\u0017\u00dd\u00d8\u00c9M\u0094S\u0091\u00ed\u001b\u00dd\u001d\u009en\u00b7c\u00ac\u00b8\u00fb\u00b1=0:)\u00a0\u00b8\u00db\u0010\u00c2\u00ab\u00e8\u00da\u00b7\u0086?\u00f2p\u00ef\u00d9\u00a0\u0088\u007f\u0010\u0014! \u00ff'\u00e6!\u0097b\u00e1{w&\u00cf8";
                var5_16 = "\u00819\u0092\u00c1\u00a82\u0019\u001e:\u00cf\u008c\u007f\u00f96,Bb|\u009f\u0005.j\u001f\u00df\u00d0\u00a2On\u00d0\u0082\u00bd\u0097\u00c6\u00be\u00ff\u0087\u00b4\u00fb\u00b3H\r\u0092\u00ad<!\u0001\u0017\u00dd\u00d8\u00c9M\u0094S\u0091\u00ed\u001b\u00dd\u001d\u009en\u00b7c\u00ac\u00b8\u00fb\u00b1=0:)\u00a0\u00b8\u00db\u0010\u00c2\u00ab\u00e8\u00da\u00b7\u0086?\u00f2p\u00ef\u00d9\u00a0\u0088\u007f\u0010\u0014! \u00ff'\u00e6!\u0097b\u00e1{w&\u00cf8".length();
                var2_17 = 0;
                while (true) {
                    var7_18 = var4_15.substring(var2_17, var2_17 += 8).getBytes("ISO-8859-1");
                    v10 = var6_13;
                    v11 = var3_14++;
                    v12 = ((long)var7_18[0] & 255L) << 56 | ((long)var7_18[1] & 255L) << 48 | ((long)var7_18[2] & 255L) << 40 | ((long)var7_18[3] & 255L) << 32 | ((long)var7_18[4] & 255L) << 24 | ((long)var7_18[5] & 255L) << 16 | ((long)var7_18[6] & 255L) << 8 | (long)var7_18[7] & 255L;
                    v13 = -1;
                    break block20;
                    break;
                }
lbl83:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_17 < var5_16) ** continue;
                    var4_15 = "FA\f\u00c2\u00fcf\u001b\u001c\u0096U\u00a1\u0012O\u0003\u00d1K";
                    var5_16 = "FA\f\u00c2\u00fcf\u001b\u001c\u0096U\u00a1\u0012O\u0003\u00d1K".length();
                    var2_17 = 0;
                    while (true) {
                        var7_18 = var4_15.substring(var2_17, var2_17 += 8).getBytes("ISO-8859-1");
                        v10 = var6_13;
                        v11 = var3_14++;
                        v12 = ((long)var7_18[0] & 255L) << 56 | ((long)var7_18[1] & 255L) << 48 | ((long)var7_18[2] & 255L) << 40 | ((long)var7_18[3] & 255L) << 32 | ((long)var7_18[4] & 255L) << 24 | ((long)var7_18[5] & 255L) << 16 | ((long)var7_18[6] & 255L) << 8 | (long)var7_18[7] & 255L;
                        v13 = 0;
                        break block20;
                        break;
                    }
                    break;
                }
lbl96:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_17 < var5_16) ** continue;
                    break block21;
                    break;
                }
            }
            var8_19 = v12;
            var10_20 = var0_11.doFinal(new byte[]{(byte)(var8_19 >>> 56), (byte)(var8_19 >>> 48), (byte)(var8_19 >>> 40), (byte)(var8_19 >>> 32), (byte)(var8_19 >>> 24), (byte)(var8_19 >>> 16), (byte)(var8_19 >>> 8), (byte)var8_19});
            v14 = ((long)var10_20[0] & 255L) << 56 | ((long)var10_20[1] & 255L) << 48 | ((long)var10_20[2] & 255L) << 40 | ((long)var10_20[3] & 255L) << 32 | ((long)var10_20[4] & 255L) << 24 | ((long)var10_20[5] & 255L) << 16 | ((long)var10_20[6] & 255L) << 8 | (long)var10_20[7] & 255L;
            switch (v13) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl109:
                // 1 sources

                ** continue;
            }
        }
        ScreenEffects.I = var6_13;
        ScreenEffects.J = new Integer[15];
        ScreenEffects.screenFxPipeline = kuzi.obf.l.a.a.a(kuzi.obf.l.a.a.a(var22_1, "screen_fx").withSampler("Scene").withUniform("KuziScreenFx", UniformType.UNIFORM_BUFFER));
        ScreenEffects.n = new b("Kuzi screen fx", 4);
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static String b(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x27C;
        if (G[n3] == null) {
            Object[] objectArray;
            try {
                Long l3 = Thread.currentThread().threadId();
                objectArray = (Object[])H.get(l3);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    H.put(l3, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/g/ai", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l2 >>> 56);
            for (int i2 = 1; i2 < 8; ++i2) {
                byArray[i2] = (byte)(l2 << i2 * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = F[n3].getBytes("ISO-8859-1");
            ScreenEffects.G[n3] = ScreenEffects.b(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return G[n3];
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        String string2 = ScreenEffects.b(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static CallSite b(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/ai" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (M[n4] != null) {
            return n4;
        }
        Object object = L[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 34;
            case 1 -> 10;
            case 2 -> 47;
            case 3 -> 38;
            case 4 -> 52;
            case 5 -> 22;
            case 6 -> 13;
            case 7 -> 55;
            case 8 -> 30;
            case 9 -> 31;
            case 10 -> 36;
            case 11 -> 50;
            case 12 -> 19;
            case 13 -> 9;
            case 14 -> 14;
            case 15 -> 12;
            case 16 -> 3;
            case 17 -> 5;
            case 18 -> 61;
            case 19 -> 23;
            case 20 -> 59;
            case 21 -> 28;
            case 22 -> 11;
            case 23 -> 43;
            case 24 -> 39;
            case 25 -> 54;
            case 26 -> 7;
            case 27 -> 25;
            case 28 -> 6;
            case 29 -> 20;
            case 30 -> 1;
            case 31 -> 56;
            case 32 -> 16;
            case 33 -> 57;
            case 34 -> 24;
            case 35 -> 29;
            case 36 -> 40;
            case 37 -> 8;
            case 38 -> 27;
            case 39 -> 58;
            case 40 -> 60;
            case 41 -> 2;
            case 42 -> 44;
            case 43 -> 48;
            case 44 -> 18;
            case 45 -> 41;
            case 46 -> 32;
            case 47 -> 21;
            case 48 -> 0;
            case 49 -> 4;
            case 50 -> 17;
            case 51 -> 42;
            case 52 -> 49;
            case 53 -> 35;
            case 54 -> 51;
            case 55 -> 46;
            case 56 -> 63;
            case 57 -> 33;
            case 58 -> 53;
            case 59 -> 15;
            case 60 -> 26;
            case 61 -> 37;
            case 62 -> 62;
            default -> 45;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        ScreenEffects.M[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = L;
        L[0] = "Z(~\u0000|IW(~\u0000\u007f";
        objectArray[1] = Integer.TYPE;
        ScreenEffects.M[1] = "java/lang/Integer";
        objectArray[2] = "s\u0019E\u0011j\u0004z\u0017FX)\t|\u0017RZ4\u000f>\u0014]Ya\u000eb\u0005\u0006xw\u001eR\u0003NYb\u0019";
        objectArray[3] = "\u001cV\u001b\u0001>\u0012\u0017V\u001d\u0001>U";
        objectArray[4] = "EteWc\u0012HteWc";
        objectArray[5] = "cR\u00010J#cR\u0016lF,y\u0019\u0016rF9~hD,\u0016y:";
        objectArray[6] = "\u001b\u001a\u00029\u0017i\u0012\u0014\u0001pTd\u0014\u0014\u0015rIbV\u0005\u0006g\u001fj\u0011\u001b\n9(c\u0016\u0011\ne*o\b\u0010\u0003~\u0014c\\7\u001a~\u0016b\u001d\u0007";
        objectArray[7] = "^\u007f7FlPWq4\u000f/]Qq \r2[\u0013`3\u0018dST~?FSZSt?\u001aQVMu6\u0001oZ";
        objectArray[8] = Long.TYPE;
        ScreenEffects.M[8] = "java/lang/Long";
        objectArray[9] = "e@\u0003'<\u001bnO\u0012hA\u0003}H\u001b!";
        objectArray[10] = "\u0003{A8=C\n{B8=";
        objectArray[11] = ":\u00182:_B1\u0017#u>L:\u001c'/";
        objectArray[12] = "\u007fSchZbsSp";
        objectArray[13] = "{5\u000edBV\u000e\u0015\u0005kS\u0019o\u001b\u000e`WC\u001b";
        objectArray[14] = Float.TYPE;
        ScreenEffects.M[14] = "java/lang/Float";
        objectArray[15] = "XXi\u0019@QQXj\u0019L";
        objectArray[16] = "HkEe5yAkFe1";
        objectArray[17] = "}\u0016\u001f\u000e\u0006Dt\u0016\u001c\u000e\u0004";
        objectArray[18] = "veg\u0003\u0014\u0006\u007fkdJW\u000bykpHJ\r;~oU\r\u001cgoy\u0003>\u0019`^oU\r\u001cgo\\D\u001c\u001e";
        objectArray[19] = Boolean.TYPE;
        ScreenEffects.M[19] = "java/lang/Boolean";
        objectArray[20] = "}K4&r[cC.i:[yI6.3@9i-)/[zO0";
        objectArray[21] = Void.TYPE;
        ScreenEffects.M[21] = "java/lang/Void";
        objectArray[22] = "AKp_\u0018WBE(|OMNhsXP\\Y";
        objectArray[23] = ")dO>\b\u00074q\u0017\u001cI\n,w";
        objectArray[24] = "9}>\u0000\u0003F2}8\u0000\u0003,";
        objectArray[25] = "]S";
        objectArray[26] = "t3\u001d{\u007f)t3\n's&nx\n9s3i\t[b$";
        objectArray[27] = "zJD\u0014\u0000^qJL";
        objectArray[28] = "\u0015\u007f*|F\u0016\u0018\u007f*|D";
        objectArray[29] = "!\u000ev;J(,\u000ev;O";
        objectArray[30] = "05[\u001be#E\u0015P\u0014tl$\u001b[\u001fp6P";
        objectArray[31] = "<\u001e^ \u0006\u00177\u001eU";
        objectArray[32] = "L\u00186H4\u001c98=G%SX66L!\t,";
        objectArray[33] = "?)@9+~i$D![r\u0005z\u001070&d4\u0006;a\u001b5&\u00100fz{0\u001ca[";
        objectArray[34] = "JpHE{2\u001c}L]\u000b>pv\u0015\u001d5iAu\u0013GdWAcHY0i\b/DX\u000b";
        objectArray[35] = "8\u0001|\u001e,Jn\fx\u0006\\]\u0002\u000b<\u0015cV2\u000b\"\u001c7";
        objectArray[36] = "dl5\u007f/]2a1g_D^eh%<\u0002!?hl2";
        objectArray[37] = "Viyl>d\u0000d}tN\u007fla*a-`\u001cz|h+";
        objectArray[38] = "\u0000\u007f\u0017^B)T|VY$#;(XGZ:_zN\u001fNJPdXJN$\n.DO$";
        objectArray[39] = "\u0002l$yIfTa a9x8fdr\u0006z\bfz{R";
        objectArray[40] = "jW_3\u001fK>T\u001e4yAQ\u0003\u0004\"\u0014Fi\u0003\\3\u001d(:L\u0010'\u0013F`\u0006\f\"yDo\u0003\u0010\"\u001f\u0015.M]ND\u00103\\\u0013(\u0016\u0013(]b#B\u0017#^Z2BY:=_<\u001dV!Y\r*EBQS\\,\u001eP5\u0001[?\u0010(";
        objectArray[41] = "\u0000\u0014bC\u0012A\r\\!#\u0003{ZW?]\u001a\u001f\bAgIj\u0015\rG<\u001d\u0003\u0018\u0007F:#";
        objectArray[42] = "\u00026\u001dj\u001cl\u0004=\u0011v{t=1\u0015(E#\f2\u0013r\u0014\u001d\u00026\u001dj\u001cl\u0004=\u0011v{";
        objectArray[43] = "I\u0005\b\u0012U,\u001f\b\f\n%\u0000s\r[\u001fF(\u0003\u0016\r\u0016@";
        objectArray[44] = "C\tlr\u0000v\u0015\u0004hjpuy\ra)\u0010kC\u0000)j";
        objectArray[45] = "aC\u001bF)65@ZAO<Z\u0014T_1%>FB\u0007%UdOJV!md\u0017[_Oi=I^]+$4Y\u001a;";
        objectArray[46] = ">?i%b\u001a84e9\u0005\u0002\u0001bq!u\u0001\u007f#b>~k";
        objectArray[47] = ",\u0013_N%5z\u001e[VU*\u0016\u0019\u001fEj)&\u0019\u0001L>";
        objectArray[48] = "Lp0.8l\u001a}46Hyvzp%wpFzn,#";
        objectArray[49] = "g9n3)P3:/4OZ\\h\"%r\u0002e6+()3";
        objectArray[50] = "\b\u0019\u001c=#\n\u0005Q_]20VA\u001a68Y\u0012MY![\t\u0006\u0017N>2M\nTY]bYPCF4&U\u0013T%d?B\u000eHWd6JP(";
        objectArray[51] = "I!m.]w\u001f,i6-os+-%\u0012kC+3,F";
        objectArray[52] = "jk\u000f2E{>hN5#qQ<@+]h5nVsI\u0018`q\u000e1\u0018&)=\u00020#";
        objectArray[53] = "\u000e~ ]rv\n9,\f\u0014N\"DQ-N\u0014\u000e~ ]rv\n9,\f";
        objectArray[54] = "\u0006Wm\u001a vPZi\u0002Pt<_>\u00173rLDh\u001e5";
        objectArray[55] = "X~F\u0007|=\u0002~\u000f\tF+2p\u001b\u000b)'S&G\u0019,B";
        objectArray[56] = "\u0018gz-7T\u0013e*%X\u0000zy!}&RCty?<iGht8(\r\u0015~,,X\u0007Dxw><UCkyF";
        objectArray[57] = "axF$xY?\"\u0007vHR\u0001#Zu5Fjr\u0007\"18";
        objectArray[58] = "A+/\u007fuA\u0017&+g\u0005n{!ot:]K!q}n";
        objectArray[59] = "7.\u0014}kJ:fW\u001dzpmmIcc\u0014?{\u0011w\u0013\u001en}JewLinD\u001d";
        objectArray[60] = "\bRJVq'\u0013M\u001cR\u00004lE\u001eSr4\n\u0014_\u001d?X";
        objectArray[61] = "W^~/?p\u0001Sz7OdmV-\",t\u001dM{+*";
        objectArray[62] = "X4u\u0018\u0017C\f74\u001fqIcb/\u0005\tF\u0007/&\u0015M ^f*\u0004\u0000F\fe1\u0005q";
        objectArray[63] = " e}L2\u0017vhyTB>\u001ao=G}\u000b*o#N)";
        objectArray[64] = "Z1F\u001aJe\f<B\u0002:\u007f`;\u0006\u0011\u0005yP;\u0018\u0018Q";
        objectArray[65] = "\u001f<2\u0001tlI16\u0019\u0004l%b6\u0001exC05\u001ad";
        objectArray[66] = "7QIBFqa\\MZ6_\rY\u001aOUu}BLFS";
        objectArray[67] = "=wPH26&h\u0006LC-Yi[I}whj]\u0013,I72X\u0014;-e5K\u001aC";
        objectArray[68] = "s\n,bD\u0012'\tme\"\u0018H\u0001-.Y\u00112XwsAq";
        objectArray[69] = "`wU\u0016qT6zQ\u000e\u0001HZ}\u0015\u001d>Hj}\u000b\u0014j";
        Object[] objectArray2 = objectArray;
        objectArray[70] = "^\u001e3CL\u0012\b\u00137[<\u000fd\u0014sH\u0003\u000eT\u0014mAW";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = ScreenEffects.e(l2, l3);
            object = L[n2];
            try {
                if (!(object instanceof String)) break block2;
                ScreenEffects.L[n2] = clazz = Class.forName(M[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = ScreenEffects.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = ScreenEffects.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = ScreenEffects.e(l2, l3);
        Object object = L[n2];
        if (object instanceof String) {
            String string = M[n2];
            int n3 = string.indexOf(8);
            Class clazz = ScreenEffects.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = ScreenEffects.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = ScreenEffects.c(clazz3, string2, clazz2)) != null) {
                    ScreenEffects.L[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = ScreenEffects.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        ScreenEffects.L[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = ScreenEffects.f(809182546776028L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = ScreenEffects.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = ScreenEffects.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = ScreenEffects.e(l2, l3);
        Object object = L[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = M[n2];
                int n4 = string2.indexOf(8);
                clazz3 = ScreenEffects.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = ScreenEffects.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = ScreenEffects.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        ScreenEffects.L[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = ScreenEffects.f(809182546776028L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = ScreenEffects.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        ScreenEffects.L[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = ScreenEffects.f(809182546776028L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == 'd' || c2 == 'P' || c2 == 'Q' || c2 == 'J') {
                field = ScreenEffects.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == 'd' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == 'P' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == 'Q' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = ScreenEffects.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == 'K' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == 'k' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = ScreenEffects.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/ai" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(ScreenEffects.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(ScreenEffects.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

