// === Kuzi module: Glint ===
// Category   : RENDER
// Description: Re-skins the enchantment glint on items, armour and hands.
// Payload    : a.a.a.j.g.Q (verified: False)

package kuzi.modules.render;

import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.b.e;
import kuzi.obf.h.b.l;
import kuzi.obf.h.b.v;
import kuzi.obf.j.g.aD;
import kuzi.obf.j.g.aL;
import kuzi.obf.j.g.q;
import kuzi.obf.m.r;
import kuzi.obf.p.x_0;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.NativeImage;
import net.minecraft.AbstractTexture;
import net.minecraft.TextureManager;
import net.minecraft.GpuSampler;
import net.minecraft.Identifier;
import net.minecraft.ItemRenderer;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class Glint
extends BaseModule {
    private static final q defaultStyle;
    private final l styleSetting;
    private final BoolSetting items;
    private final BoolSetting armor;
    private final BoolSetting tintEnabled;
    private final e tintColor;
    private final SliderSetting tintStrength;
    private final BoolSetting debug;
    private final SliderSetting brightness;
    private String appliedSettingsKey;
    private AbstractTexture w;
    private AbstractTexture x;
    private int ticksSinceRebuild;
    private static final int z;
    private static final long A;
    private static final String[] B;
    private static final String[] C;
    private static final Map D;
    private static final long[] E;
    private static final Integer[] F;
    private static final Map G;
    private static final Object[] H;
    private static final String[] I;

    public Glint() {
        long l2 = A ^ 0x11F57F7E563BL;
        long l3 = l2 ^ 0x6A49DB04DC9CL;
        super("Glint", "Re-skins the enchantment glint on items, armour and hands.", Category.RENDER);
        this.styleSetting = new l("Style", defaultStyle, q.class);
        this.items = new BoolSetting("Items", true);
        this.armor = new BoolSetting("Armor", true);
        this.tintEnabled = new BoolSetting("Tint", false);
        this.tintColor = new e("Tint Color", new Color(255, 80, 255));
        this.tintStrength = new SliderSetting("Tint Strength", 50.0, 0.0, 100.0, 1.0);
        this.debug = new BoolSetting("Debug", false);
        this.brightness = new SliderSetting("Brightness", 100.0, 25.0, 400.0, 5.0);
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.styleSetting, this.items, this.armor, this.tintEnabled, this.tintColor, this.tintStrength, this.brightness, this.debug};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        this.appliedSettingsKey = null;
    }

    @Override
    public void e() {
        long l2 = A ^ 0x24AE0A90D651L;
        long l3 = l2 ^ 0x6326D3BE8C5CL;
        this.appliedSettingsKey = null;
        this.w = null;
        this.x = null;
        BaseModule.a.execute(() -> this.lambda$onDisable$0(l3));
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    @Override
    public void i() {
        var1_1 = Glint.A ^ 45944471384403L;
        var3_2 = var1_1 ^ 66071623427404L;
        var5_3 = aD.b();
        v0 /* !! */  = BaseModule.a;
        if (var5_3 != null) {
            if (v0 /* !! */  == null) {
                return;
            }
            v0 /* !! */  = this.styleSetting.a();
        }
        settingsKey = ((q)v0 /* !! */ ).name() + "|" + String.valueOf(this.items.a()) + "|" + String.valueOf(this.armor.a()) + "|" + String.valueOf(this.tintEnabled.a()) + "|" + this.tintColor.a().getRGB() + "|" + String.valueOf(this.tintStrength.a()) + "|" + String.valueOf(this.brightness.a());
        v1 = settingsKey.equals(this.appliedSettingsKey);
        if (var5_3 != null) {
            v1 = settingsChanged = v1 == false;
        }
        if (var5_3 != null) {
            if (!settingsChanged) {
                v2 = this;
                v3 = v2;
                v4 = v2.ticksSinceRebuild + 1;
                if (var5_3 != null) {
                    v3.ticksSinceRebuild = v4;
                    if (v4 < 20) {
                        return;
                    } else {
                        ** GOTO lbl-1000
                    }
                }
            } else lbl-1000:
            // 3 sources

            {
                v3 = this;
                v4 = 0;
            }
            v3.ticksSinceRebuild = v4;
            this.appliedSettingsKey = settingsKey;
        }
        glintId = ((q)this.styleSetting.a()).b;
        BaseModule.a.execute((Runnable)LambdaMetafactory.metafactory(null, null, null, ()V, lambda$onTick$1(boolean long net.minecraft.Identifier ), ()V)((Glint)this, (boolean)settingsChanged, (long)var3_2, (Identifier)glintId));
    }

    /*
     * Unable to fully structure code
     */
    private boolean a(Object[] args) {
        block20: {
            block18: {
                block19: {
                    block16: {
                        var2_2 = (Long)args[0];
                        var2_2 = Glint.A ^ var2_2;
                        var5_3 = Glint.d("I", (long)3159421491617009916L, (long)var2_2).getTextureManager();
                        var4_4 = Glint.d("\u00d2", (long)3154343115885616973L, (long)var2_2);
                        try {
                            block17: {
                                try {
                                    try {
                                        try {
                                            v0 = Glint.d("\u00c7", (Object)this, (long)3153798657636273786L, (long)var2_2);
                                            if (var4_4 == null) break block16;
                                            if (v0 == null) break block17;
                                        }
                                        catch (r v1) {
                                            throw Glint.d("\u00d2", (Object)v1, (long)3160529892531771451L, (long)var2_2);
                                        }
                                        v0 = var5_3.getTexture(ItemRenderer.ENCHANTED_GLINT_ITEM);
                                        v2 = var4_4;
                                        if (var2_2 > 0L) {
                                            if (v2 == null) break block16;
                                        }
                                        ** GOTO lbl38
                                    }
                                    catch (r v3) {
                                        throw Glint.d("\u00d2", (Object)v3, (long)3160529892531771451L, (long)var2_2);
                                    }
                                    if (v0 != Glint.d("\u00c7", (Object)this, (long)3153798657636273786L, (long)var2_2)) break block18;
                                }
                                catch (r v4) {
                                    throw Glint.d("\u00d2", (Object)v4, (long)3160529892531771451L, (long)var2_2);
                                }
                            }
                            v0 = Glint.d("\u00c7", (Object)this, (long)3159731696725673655L, (long)var2_2);
                        }
                        catch (r v5) {
                            throw Glint.d("\u00d2", (Object)v5, (long)3160529892531771451L, (long)var2_2);
                        }
                    }
                    try {
                        try {
                            if (var2_2 < 0L) break block19;
                            v2 = var4_4;
lbl38:
                            // 2 sources

                            if (v2 == null) break block19;
                            if (v0 != null) {
                            }
                            ** GOTO lbl51
                        }
                        catch (r v6) {
                            throw Glint.d("\u00d2", (Object)v6, (long)3160529892531771451L, (long)var2_2);
                        }
                        v0 = var5_3.getTexture(ItemRenderer.ENCHANTED_GLINT_ARMOR);
                    }
                    catch (r v7) {
                        throw Glint.d("\u00d2", (Object)v7, (long)3160529892531771451L, (long)var2_2);
                    }
                }
                try {
                    if (v0 != Glint.d("\u00c7", (Object)this, (long)3159731696725673655L, (long)var2_2)) break block18;
lbl51:
                    // 2 sources

                    v8 = true;
                    break block20;
                }
                catch (r v9) {
                    throw Glint.d("\u00d2", (Object)v9, (long)3160529892531771451L, (long)var2_2);
                }
            }
            v8 = false;
        }
        return v8;
    }

    /*
     * Loose catch block
     */
    private AbstractTexture a(Object[] objectArray) {
        CallSite callSite;
        Identifier mc29602;
        long l2;
        long l3;
        Identifier mc29603;
        long l4;
        block24: {
            Object object;
            long l5;
            block23: {
                CallSite callSite2;
                long l6;
                Identifier mc29604;
                block22: {
                    block25: {
                        Identifier mc29605;
                        long l7;
                        block20: {
                            block21: {
                                l4 = (Long)objectArray[0];
                                mc29603 = (Identifier)objectArray[1];
                                mc29604 = (Identifier)objectArray[2];
                                long l8 = l4 = A ^ l4;
                                l7 = l8 ^ 0x646DA1DBA3CL;
                                l6 = l8 ^ 0xE7276F0745FL;
                                l5 = l8 ^ 0x6E4CB0EABDBFL;
                                l3 = l8 ^ 0x326977C2F6E7L;
                                l2 = l8 ^ 0x32DF7B38FE7FL;
                                callSite2 = Glint.d("\u00d2", (long)-2611711784289013942L, (long)l4);
                                try {
                                    if (Glint.d("I", (long)-2603174340730101509L, (long)l4) == null) {
                                        return null;
                                    }
                                }
                                catch (Throwable throwable) {
                                    throw Glint.d("\u00d2", (Object)throwable, (long)-2604388381063124932L, (long)l4);
                                }
                                try {
                                    mc29605 = mc29604;
                                    if (callSite2 == null) break block20;
                                    if (mc29605 == null) break block21;
                                }
                                catch (Throwable throwable) {
                                    throw Glint.d("\u00d2", (Object)throwable, (long)-2604388381063124932L, (long)l4);
                                }
                                mc29605 = mc29604;
                                break block20;
                            }
                            mc29605 = mc29603;
                        }
                        mc29602 = mc29605;
                        Object[] objectArray2 = new Object[2];
                        objectArray2[1] = mc29602;
                        objectArray2[0] = l7;
                        callSite = Glint.d("\u00c4", (Object)this, (Object)objectArray2, (long)-2611206140649843116L, (long)l4);
                        if (callSite2 == null) break block25;
                        try {
                            block26: {
                                if (callSite != null) break block22;
                                break block26;
                                catch (Throwable throwable) {
                                    throw Glint.d("\u00d2", (Object)throwable, (long)-2604388381063124932L, (long)l4);
                                }
                            }
                            Object[] objectArray3 = new Object[2];
                            objectArray3[1] = l3;
                            objectArray3[0] = (String)((Object)Glint.b("l", (int)20066, (long)(0x3A0509753FD08BBDL ^ l4))) + String.valueOf(mc29602) + (String)((Object)Glint.b("l", (int)22906, (long)(0x2950EEF453EE9CACL ^ l4)));
                            Glint.d("\u00d2", (Object)objectArray3, (long)-2611952969434448497L, (long)l4);
                        }
                        catch (Throwable throwable) {
                            throw Glint.d("\u00d2", (Object)throwable, (long)-2604388381063124932L, (long)l4);
                        }
                    }
                    return null;
                }
                object = mc29604;
                if (l4 <= 0L || callSite2 == null) break block23;
                try {
                    block27: {
                        if (object == null) break block24;
                        break block27;
                        catch (Throwable throwable) {
                            throw Glint.d("\u00d2", (Object)throwable, (long)-2604388381063124932L, (long)l4);
                        }
                    }
                    Object[] objectArray4 = new Object[2];
                    objectArray4[1] = callSite;
                    objectArray4[0] = l6;
                    Glint.d("\u00c4", (Object)this, (Object)objectArray4, (long)-2611539601138805554L, (long)l4);
                    object = Glint.d("\u00c4", (Object)Glint.d("\u00c7", (Object)this, (long)-2604431491681502864L, (long)l4), (long)-2604116087491654759L, (long)l4);
                }
                catch (Throwable throwable) {
                    throw Glint.d("\u00d2", (Object)throwable, (long)-2604388381063124932L, (long)l4);
                }
            }
            try {
                if (((Boolean)object).booleanValue()) {
                    Object[] objectArray5 = new Object[4];
                    objectArray5[3] = Float.valueOf((float)((Double)((Object)Glint.d("\u00c4", (Object)Glint.d("\u00c7", (Object)this, (long)-2603427453537140829L, (long)l4), (long)-2604116087491654759L, (long)l4)) / 100.0));
                    objectArray5[2] = ((Color)((Object)Glint.d("\u00c4", (Object)Glint.d("\u00c7", (Object)this, (long)-2604035824527719218L, (long)l4), (long)-2611754109310985360L, (long)l4))).getRGB();
                    objectArray5[1] = callSite;
                    objectArray5[0] = l5;
                    Glint.d("\u00d2", (Object)objectArray5, (long)-2604554271458525592L, (long)l4);
                }
            }
            catch (Throwable throwable) {
                throw Glint.d("\u00d2", (Object)throwable, (long)-2604388381063124932L, (long)l4);
            }
        }
        aL aL2 = null;
        try {
            GpuSampler mc121372;
            CallSite callSite3;
            Identifier mc29606;
            aL aL3;
            aL aL4;
            TextureManager textureManager = Glint.d("I", (long)-2603174340730101509L, (long)l4).getTextureManager();
            AbstractTexture baseTexture = textureManager.getTexture(mc29603);
            try {
                aL aL5;
                aL4 = aL5;
                aL3 = aL5;
                mc29606 = mc29603;
                callSite3 = callSite;
                mc121372 = baseTexture != null ? baseTexture.getSampler() : null;
            }
            catch (Throwable throwable) {
                throw Glint.d("\u00d2", (Object)throwable, (long)-2604388381063124932L, (long)l4);
            }
            aL4(mc29606, (NativeImage)callSite3, mc121372);
            aL2 = aL3;
            textureManager.release(mc29603);
            textureManager.register(mc29603, (AbstractTexture)aL2);
            return aL2;
        }
        catch (Throwable throwable) {
            Object[] objectArray6 = new Object[2];
            objectArray6[1] = l2;
            objectArray6[0] = aL2;
            Glint.d("\u00d2", (Object)objectArray6, (long)-2611852739382486630L, (long)l4);
            Object[] objectArray7 = new Object[2];
            objectArray7[1] = l2;
            objectArray7[0] = callSite;
            Glint.d("\u00d2", (Object)objectArray7, (long)-2611852739382486630L, (long)l4);
            Object[] objectArray8 = new Object[2];
            objectArray8[1] = l3;
            objectArray8[0] = (String)((Object)Glint.b("l", (int)23487, (long)(0x9BA05DF261A1E6DL ^ l4))) + String.valueOf(mc29602) + (String)((Object)Glint.b("l", (int)26648, (long)(0x1E703BD8A48EADC4L ^ l4))) + String.valueOf(throwable);
            Glint.d("\u00d2", (Object)objectArray8, (long)-2611952969434448497L, (long)l4);
            return null;
        }
    }

    private void lambda$onTick$1(boolean bl, long l2, Identifier glintId) {
        Glint glint;
        long l3;
        long l4;
        block7: {
            block6: {
                boolean bl2;
                block5: {
                    long l5 = l2 = A ^ l2;
                    long l6 = l5 ^ 0x51149F01AE7BL;
                    l4 = l5 ^ 0x60A1A76BFE00L;
                    l3 = l5 ^ 0x7EB55CCE5E7CL;
                    int[] nArray = aD.b();
                    bl2 = bl;
                    if (nArray == null) break block5;
                    if (bl2) break block6;
                    glint = this;
                    if (l2 < 0L || nArray == null) break block7;
                    Object[] objectArray = new Object[1];
                    objectArray[0] = l6;
                    bl2 = glint.a(objectArray);
                }
                if (bl2) {
                    return;
                }
            }
            glint = this;
        }
        Glint glint2 = this;
        Identifier textureId = ItemRenderer.ENCHANTED_GLINT_ITEM;
        Object targetId = (Boolean)this.items.a() != false ? glintId : null;
        if (l2 >= 0L) {
            Object[] objectArray = new Object[3];
            objectArray[2] = targetId;
            objectArray[1] = textureId;
            objectArray[0] = l3;
            glint.w = glint2.a(objectArray);
            glint = this;
            glint2 = this;
            textureId = ItemRenderer.ENCHANTED_GLINT_ARMOR;
            targetId = (Boolean)this.armor.a() != false ? glintId : null;
        }
        Object[] objectArray = new Object[3];
        objectArray[2] = targetId;
        objectArray[1] = textureId;
        objectArray[0] = l3;
        glint.x = glint2.a(objectArray);
        if (((Boolean)this.debug.a()).booleanValue()) {
            TextureManager textureManager = BaseModule.a.getTextureManager();
            boolean bl3 = textureManager.getTexture(ItemRenderer.ENCHANTED_GLINT_ARMOR) == this.x;
            boolean bl4 = this.x != null;
            boolean bl5 = textureManager.getTexture(ItemRenderer.ENCHANTED_GLINT_ITEM) == this.w;
            boolean bl6 = this.w != null;
            String string = String.valueOf(this.styleSetting.a());
            Object[] objectArray2 = new Object[2];
            objectArray2[1] = (String)((Object)Glint.b("l", (int)16084, (long)(0x2039CFFF09B1B4D4L ^ l2))) + string + (String)((Object)Glint.b("l", (int)17610, (long)(0x49FB7DECA24E4ED5L ^ l2))) + bl6 + (String)((Object)Glint.b("l", (int)9834, (long)(0x4CEFF44DFDF6AC71L ^ l2))) + bl5 + (String)((Object)Glint.b("l", (int)6187, (long)(0x398D392411479238L ^ l2))) + bl4 + (String)((Object)Glint.b("l", (int)17538, (long)(0x1FFFFFD9867ECE83L ^ l2))) + bl3;
            objectArray2[0] = l4;
            x_0.a(objectArray2);
        }
    }

    private void lambda$onDisable$0(long l2) {
        long l3 = (l2 = A ^ l2) ^ 0x2CE3BDA1906EL;
        Object[] objectArray = new Object[3];
        objectArray[2] = null;
        objectArray[1] = ItemRenderer.ENCHANTED_GLINT_ITEM;
        objectArray[0] = l3;
        this.a(objectArray);
        Object[] objectArray2 = new Object[3];
        objectArray2[2] = null;
        objectArray2[1] = ItemRenderer.ENCHANTED_GLINT_ARMOR;
        objectArray2[0] = l3;
        this.a(objectArray2);
    }

    /*
     * Unable to fully structure code
     */
    static {
        block21: {
            block20: {
                block19: {
                    block18: {
                        Glint.A = kuzi.obf.h.b.v.a(-5446979465394717522L, 8350311508903754394L, MethodHandles.lookup().lookupClass()).a(198435821714214L);
                        var20 = Glint.A ^ 90267301731089L;
                        Glint.H = new Object[76];
                        Glint.I = new String[76];
                        Glint.c();
                        Glint.D = new HashMap<K, V>(13);
                        var11_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var20 >>> 56);
                        for (var12_2 = 1; var12_2 < 8; ++var12_2) {
                            v2 = v2;
                            v2[var12_2] = (byte)(var20 << var12_2 * 8 >>> 56);
                        }
                        var11_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var18_3 = new String[19];
                        var16_4 = 0;
                        var15_5 = "3\u00dcj\t\u00928mi$1R\u00f5\u0011\u0094S\u00ca\u0092\u00b5\u00a7r\u00d3\u008d\u00dd_\u0014\n\u0004\u0006|Q\f\u000b\u0000H\u0016\u0098Z\u0001GI\u0010\u0088\u0088\u00bci\u00e2M\u00ec\u008f\u0094\u008c\u00a6\u0092\u0081\u00c0\u00bbJ\u0018\u00c2\u001cD\u00c2\u001e\u00ed\u0082JLJG\u00abo\u00cci\u00d3\u00fa\u001d\u00f01\u00c5\u00ca6\u0012\u0010|@`\u00d3\u009a\u0087\u00b4\u00f8\u00d5\u0001\u0089\u00da\u00be\u0088D\u009bh\u00e9p_\u00fc\u00de\u00aa\u00cd\u00d5u\bYR\u00ac\u0016\u00a5H\u00d2v\u00ad\u00f7\u00afu$=b\u009cR\u0092[\u00f5s\u00dc\u00b1Nr\u00aeD}8\u00d4\u00adQ!\u00efH^\u00a6\u009e.\u00e5\u00bd\f\u00fa\u0089\u008c*Rw\u00cb\u0094\u00b2&\u00cb`\u00d0q\u0001!\u0017\u001bI\u00c6\u0013\u00a5\u0014\u00d6D\u0097_F\"\u009d\u00d5V9\"9m8\u00cd\u001e\u007f\u0013\u007f\u0004\u00a9X\u00a3\n9ZA\u00cc\u0085\u0010\u00e62\u00b1\u00fd{\u0098\u0098\u0086e\u0019ZT\u008f\u0010e\u008b\u0010l()Q\u0018\u00e3\u0097\u00e5\u0012\u0015P\u0002(\u00a4\u000b\u008c\u0010\u00a9\u00bc#\u00a84\u0003\u00b1\u00a2\u0091}\u0096=\u0010\u0087m>\u0018\u001a\u009b\u00e0\u00d0\u00cdt#<\u0082\u00a4;\u0086\u00b3q\u00b88n\t\u00ba\u00a0\u008f\b\u00ea\u00c38\u001aIV(\u00ca\u00f4\u00bf2\u00a1\u00e9\u0017O \u00e8\u009f\u00fd\u007f\u00d7\u00b7\u00ab\u0017\r\u0002\u0012{\u00c2\u0012\u00a6R\u00dc\u0003m\u00e7\u00c4\u00b0\u00ac\u00ad\u00cc\u00dc\u00d9\u00d6\"\u0004\u00cf\u001d\u00b3O\u0090X\u0098\u0016b\u009c\u00e1!\u0017\u0010\u008fL\u00ca&\u0001\u00faM>\u009d\u00eb0\u00d1\u0012\u0013\u007f+ \u00b2\u009fl\u009f\u00d3y\u0004e\u0015\u00c75\u00cb\u009eUR\u00de\f\u008a\u008c\u00dc\u00b9\u00b8\u0007\u00a6\u00d72\u00ef\u00d4\u00ec\u00d5\u00ed)\u0010\u0081Z\u0097}\u00da\u00f0y\u0012\u0016\u00f6C\u00d3U\u00c18\u008d000.?>\u0015\u00c1'\u00e4j\u008e\u00d7\u0017X\u0088\u00f0\u00ed\u00faM\u00caa\u00bc'\u0007\r\u00f4\u00f5\u00a7\u0017\u00f7C.\u008cz\u00f5\u00ab\u008a\u00e9\u00a6rvF\u00b7\u0003\u0084}\u0089k \u00c9\u001b\u00ec\u00a4R\u0082\u0084Z\u00dc?\u00e5\u00da_1\u0096\u00f4/\rH.[\u00e3rD\u00f8\u0012\u00a4\u0010\u00c0l\u0093\u00c0\u0010\u00c5\u00ae,\u0001\u0018W\u00b2,\u0090}\u008c5_\u0015U\u000b\u0010hK\u00d3\u0006<\u0087[3%v+\"\u00e1\u00ff\u00f0`";
                        var17_6 = "3\u00dcj\t\u00928mi$1R\u00f5\u0011\u0094S\u00ca\u0092\u00b5\u00a7r\u00d3\u008d\u00dd_\u0014\n\u0004\u0006|Q\f\u000b\u0000H\u0016\u0098Z\u0001GI\u0010\u0088\u0088\u00bci\u00e2M\u00ec\u008f\u0094\u008c\u00a6\u0092\u0081\u00c0\u00bbJ\u0018\u00c2\u001cD\u00c2\u001e\u00ed\u0082JLJG\u00abo\u00cci\u00d3\u00fa\u001d\u00f01\u00c5\u00ca6\u0012\u0010|@`\u00d3\u009a\u0087\u00b4\u00f8\u00d5\u0001\u0089\u00da\u00be\u0088D\u009bh\u00e9p_\u00fc\u00de\u00aa\u00cd\u00d5u\bYR\u00ac\u0016\u00a5H\u00d2v\u00ad\u00f7\u00afu$=b\u009cR\u0092[\u00f5s\u00dc\u00b1Nr\u00aeD}8\u00d4\u00adQ!\u00efH^\u00a6\u009e.\u00e5\u00bd\f\u00fa\u0089\u008c*Rw\u00cb\u0094\u00b2&\u00cb`\u00d0q\u0001!\u0017\u001bI\u00c6\u0013\u00a5\u0014\u00d6D\u0097_F\"\u009d\u00d5V9\"9m8\u00cd\u001e\u007f\u0013\u007f\u0004\u00a9X\u00a3\n9ZA\u00cc\u0085\u0010\u00e62\u00b1\u00fd{\u0098\u0098\u0086e\u0019ZT\u008f\u0010e\u008b\u0010l()Q\u0018\u00e3\u0097\u00e5\u0012\u0015P\u0002(\u00a4\u000b\u008c\u0010\u00a9\u00bc#\u00a84\u0003\u00b1\u00a2\u0091}\u0096=\u0010\u0087m>\u0018\u001a\u009b\u00e0\u00d0\u00cdt#<\u0082\u00a4;\u0086\u00b3q\u00b88n\t\u00ba\u00a0\u008f\b\u00ea\u00c38\u001aIV(\u00ca\u00f4\u00bf2\u00a1\u00e9\u0017O \u00e8\u009f\u00fd\u007f\u00d7\u00b7\u00ab\u0017\r\u0002\u0012{\u00c2\u0012\u00a6R\u00dc\u0003m\u00e7\u00c4\u00b0\u00ac\u00ad\u00cc\u00dc\u00d9\u00d6\"\u0004\u00cf\u001d\u00b3O\u0090X\u0098\u0016b\u009c\u00e1!\u0017\u0010\u008fL\u00ca&\u0001\u00faM>\u009d\u00eb0\u00d1\u0012\u0013\u007f+ \u00b2\u009fl\u009f\u00d3y\u0004e\u0015\u00c75\u00cb\u009eUR\u00de\f\u008a\u008c\u00dc\u00b9\u00b8\u0007\u00a6\u00d72\u00ef\u00d4\u00ec\u00d5\u00ed)\u0010\u0081Z\u0097}\u00da\u00f0y\u0012\u0016\u00f6C\u00d3U\u00c18\u008d000.?>\u0015\u00c1'\u00e4j\u008e\u00d7\u0017X\u0088\u00f0\u00ed\u00faM\u00caa\u00bc'\u0007\r\u00f4\u00f5\u00a7\u0017\u00f7C.\u008cz\u00f5\u00ab\u008a\u00e9\u00a6rvF\u00b7\u0003\u0084}\u0089k \u00c9\u001b\u00ec\u00a4R\u0082\u0084Z\u00dc?\u00e5\u00da_1\u0096\u00f4/\rH.[\u00e3rD\u00f8\u0012\u00a4\u0010\u00c0l\u0093\u00c0\u0010\u00c5\u00ae,\u0001\u0018W\u00b2,\u0090}\u008c5_\u0015U\u000b\u0010hK\u00d3\u0006<\u0087[3%v+\"\u00e1\u00ff\u00f0`".length();
                        var14_7 = 40;
                        var13_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var13_8;
                            v4 = var15_5.substring(v3, v3 + var14_7);
                            v5 = -1;
                            break block18;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var18_3[var16_4++] = Glint.b(var19_9).intern();
                            if ((var13_8 += var14_7) < var17_6) {
                                var14_7 = var15_5.charAt(var13_8);
                                ** continue;
                            }
                            var15_5 = "\u00f0\u00c2P1n\u00d0_\u00f72\u00df5`5W\u00ab\u00af\u0018h5:3\u00ff_Y>\u00adN\u00c0\u0094\u00d2|\u00f2B\u00eb\"\u00bcL\u00baj,\u009b";
                            var17_6 = "\u00f0\u00c2P1n\u00d0_\u00f72\u00df5`5W\u00ab\u00af\u0018h5:3\u00ff_Y>\u00adN\u00c0\u0094\u00d2|\u00f2B\u00eb\"\u00bcL\u00baj,\u009b".length();
                            var14_7 = 16;
                            var13_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var13_8;
                                v4 = var15_5.substring(v6, v6 + var14_7);
                                v5 = 0;
                                break block18;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var18_3[var16_4++] = Glint.b(var19_9).intern();
                            if ((var13_8 += var14_7) < var17_6) {
                                var14_7 = var15_5.charAt(var13_8);
                                ** continue;
                            }
                            break block19;
                            break;
                        }
                    }
                    var19_9 = var11_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                Glint.B = var18_3;
                Glint.C = new String[19];
                Glint.G = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var20 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var20 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[17];
                var3_13 = 0;
                var4_14 = "\u0014\u0085\u0087\u008e=^\u00deQe\u00f5+!dV\u009fI\u00ee\u00ab\u008284H\f\u009c\u00d6\u00ed]\u00e86\u001e\u00d3\u007f\u007fF%\u009e\u00e8:\u00aa\u008a@7B8^q\u008fm\u00b6\u00a8\u0093\u008c\u008eqn(G\u00e3^\u001d\u0000o\u0099|\u00e4\u00ca\u00f4\u0098\u00e1%\u00e9I\u0014{\u00feYh\u00a1M\u00bd\u00a0E\u00ba@`\u00b8'@\u00b3\u009c\u0007\u00c3\u00f6\u00db\u0001#\u00c3\u0000\u0095\u00e5\u00c0\u008c1\u00e6\n\u00cb*\u0015*lMfS\u00ab\u00e7\u0085\u000ent ";
                var5_15 = "\u0014\u0085\u0087\u008e=^\u00deQe\u00f5+!dV\u009fI\u00ee\u00ab\u008284H\f\u009c\u00d6\u00ed]\u00e86\u001e\u00d3\u007f\u007fF%\u009e\u00e8:\u00aa\u008a@7B8^q\u008fm\u00b6\u00a8\u0093\u008c\u008eqn(G\u00e3^\u001d\u0000o\u0099|\u00e4\u00ca\u00f4\u0098\u00e1%\u00e9I\u0014{\u00feYh\u00a1M\u00bd\u00a0E\u00ba@`\u00b8'@\u00b3\u009c\u0007\u00c3\u00f6\u00db\u0001#\u00c3\u0000\u0095\u00e5\u00c0\u008c1\u00e6\n\u00cb*\u0015*lMfS\u00ab\u00e7\u0085\u000ent ".length();
                var2_16 = 0;
                while (true) {
                    var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                    v10 = var6_12;
                    v11 = var3_13++;
                    v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                    v13 = -1;
                    break block20;
                    break;
                }
lbl81:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    var4_14 = "\u00e7\u00f7\u008aU\u0083N\u00ed\u00b4\"0\u00d3\u0011\u00e4\u00bf\u0014q";
                    var5_15 = "\u00e7\u00f7\u008aU\u0083N\u00ed\u00b4\"0\u00d3\u0011\u00e4\u00bf\u0014q".length();
                    var2_16 = 0;
                    while (true) {
                        var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                        v10 = var6_12;
                        v11 = var3_13++;
                        v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                        v13 = 0;
                        break block20;
                        break;
                    }
                    break;
                }
lbl94:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    break block21;
                    break;
                }
            }
            var8_18 = v12;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            v14 = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
            switch (v13) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl107:
                // 1 sources

                ** continue;
            }
        }
        Glint.E = var6_12;
        Glint.F = new Integer[17];
        Glint.z = 20;
        Glint.defaultStyle = kuzi.obf.j.g.q.RAINBOW;
    }

    private static Throwable a(Throwable throwable) {
        return throwable;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static String b(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x1E0E;
        if (C[n3] == null) {
            Object[] objectArray;
            try {
                Long l3 = Thread.currentThread().threadId();
                objectArray = (Object[])D.get(l3);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    D.put(l3, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/g/Q", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l2 >>> 56);
            for (int i2 = 1; i2 < 8; ++i2) {
                byArray[i2] = (byte)(l2 << i2 * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = B[n3].getBytes("ISO-8859-1");
            Glint.C[n3] = Glint.b(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return C[n3];
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        String string2 = Glint.b(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static CallSite b(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/Q" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (I[n4] != null) {
            return n4;
        }
        Object object = H[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 22;
            case 1 -> 15;
            case 2 -> 4;
            case 3 -> 30;
            case 4 -> 10;
            case 5 -> 45;
            case 6 -> 27;
            case 7 -> 0;
            case 8 -> 63;
            case 9 -> 55;
            case 10 -> 52;
            case 11 -> 57;
            case 12 -> 16;
            case 13 -> 21;
            case 14 -> 40;
            case 15 -> 44;
            case 16 -> 20;
            case 17 -> 8;
            case 18 -> 47;
            case 19 -> 18;
            case 20 -> 13;
            case 21 -> 61;
            case 22 -> 59;
            case 23 -> 28;
            case 24 -> 50;
            case 25 -> 49;
            case 26 -> 17;
            case 27 -> 29;
            case 28 -> 9;
            case 29 -> 34;
            case 30 -> 48;
            case 31 -> 23;
            case 32 -> 39;
            case 33 -> 58;
            case 34 -> 35;
            case 35 -> 36;
            case 36 -> 56;
            case 37 -> 43;
            case 38 -> 19;
            case 39 -> 11;
            case 40 -> 32;
            case 41 -> 24;
            case 42 -> 33;
            case 43 -> 42;
            case 44 -> 60;
            case 45 -> 62;
            case 46 -> 54;
            case 47 -> 37;
            case 48 -> 6;
            case 49 -> 53;
            case 50 -> 26;
            case 51 -> 1;
            case 52 -> 2;
            case 53 -> 5;
            case 54 -> 31;
            case 55 -> 51;
            case 56 -> 38;
            case 57 -> 46;
            case 58 -> 41;
            case 59 -> 25;
            case 60 -> 12;
            case 61 -> 14;
            case 62 -> 3;
            default -> 7;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        Glint.I[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = H;
        H[0] = "7`?xO><`9x\u007f";
        objectArray[1] = "2O:\u0001B@9@+N8D*A;\u0001\u000e@=";
        objectArray[2] = "%\u001d\u001fB\u0019X.\u001d\u0014";
        objectArray[3] = "\\L\u0017Z#o\\L\u0000\u0006/`F\u0007\u0000\u0018/uAvPE~";
        objectArray[4] = "b$)wu\u007fi$/wu\u0015";
        objectArray[5] = "w\"";
        objectArray[6] = "K\u0011|Df(B\u0011\u007fDd";
        objectArray[7] = "F\u0013>\t\u000fKM\u001c/FrS^\u001b&\u000f";
        objectArray[8] = "jw^\"\u0013@cw]\"\u001f";
        objectArray[9] = "\u0014S~ExZ\u001dS}E|";
        objectArray[10] = "\u001cp=VN\u0015\u0001eet\u000f\u0018\u0019c";
        objectArray[11] = Integer.TYPE;
        Glint.I[11] = "java/lang/Integer";
        objectArray[12] = "z'UiZ\u001bs'ViW";
        objectArray[13] = "n\u001e\u000b\f\u0005Be\u001e\r\f\u0015";
        objectArray[14] = "Y.2po^Y.%,cQCe%2cDD\u0014tg4\u0007";
        objectArray[15] = "\u007fN\u001cnp\u001dvN\u001fnp";
        objectArray[16] = ";\u0006`|me0\tq3\fk;\u0002ui";
        objectArray[17] = "2\u0011/8OsG1$7^<&?/<ZfR";
        objectArray[18] = "x\u0014e5_~x\u0014riSqb_rwSde. +\u0006#";
        objectArray[19] = "xN/KrZ\rn$Dc\u0015l`/OgO\u0018";
        objectArray[20] = "+\u0002\\,LG^\"W#]\b?,\\(YRK";
        objectArray[21] = "\u001f\fr,zZj,y#k\u0015\u000b\"r(oO\u007f";
        objectArray[22] = Float.TYPE;
        Glint.I[22] = "java/lang/Float";
        objectArray[23] = "T\u0007mk!\u0003!'fd0L@)mo4\u00164";
        objectArray[24] = "#\b";
        objectArray[25] = "|PU\u001d]o\tp^\u0012L h~U\u0019Hz\u001c";
        objectArray[26] = "nHX\t8}eHP";
        objectArray[27] = "\u0004vY\u0015T:qVR\u001aEu\u0010XY\u0011A/d";
        objectArray[28] = Void.TYPE;
        Glint.I[28] = "java/lang/Void";
        objectArray[29] = "\t\u001eyD;\u0001\u0018\u001e`";
        objectArray[30] = "G*;.8\u001c2\n0!)SS\u0004;*-\t'";
        objectArray[31] = "3k2P\u0002nFK9_\u0013!'E2T\u0017{S";
        objectArray[32] = "\u000e]-~`N{}&qq\u0001\u001as-zu[n";
        objectArray[33] = Boolean.TYPE;
        Glint.I[33] = "java/lang/Boolean";
        objectArray[34] = "~1\u001eq~\u0001\u000b\u0011\u0015~oNj\u001f\u001euk\u0014\u001e";
        objectArray[35] = "\rM\fV\u000fXxm\u0007Y\u001e\u0017\u0019c\fR\u001aMm";
        objectArray[36] = "#\u0007\u007fI^jV'tFO%7)\u007fMK\u007fC";
        objectArray[37] = "O\r>>\u0018\u0015:-51\tZ[#>:\r\u0000/";
        objectArray[38] = ")=\u0014,\u0002`\\\u001d\u001f#\u0013/=\u0013\u0014(\u0017uI";
        objectArray[39] = "Xf\u0016\u007f0KXf\u0001#<DB-\u0001=<QE\\Sal\u0013";
        objectArray[40] = "_\u00070Q_~]\bx?^\u0003\u0003S'XWl\u0002\u0002\"C";
        objectArray[41] = "\u000bS\u0006=&)\t\\NS7TR\t\nmc=WU\u001b3^m[DIn7h\u0007U\u0017S";
        objectArray[42] = "8g[\u000f~9:h\u0013axDelO\u000f9:%7R\b";
        objectArray[43] = "6A\u001cW/K4NT9>6/L\u0004K/X4W\t\tW\u0006o\u001a\b\u0002)\u00076N]9";
        objectArray[44] = "\u0013;go:S\u00114/\u0001+.\n6\u007fs:@\u0011-r1B@\u00185gh:I\u0010>z\u0001";
        objectArray[45] = "GTB\u001a7FE[\nt3;\u001b\u0000U\u0013?T\u001aQP\b";
        objectArray[46] = "\u001f9{%~ \u001d63Ko]\u00064c9~3\u001d/n{\u0006;\u0015mewv:\u0004jrK";
        objectArray[47] = ",Z\u0002\"OX.UJL\\%5W\u001a>OK.L\u0017|7G6\r\u000f1Z\u001d)\nIL";
        objectArray[48] = "s\";=iLr:'fVg\u000b\u0003\f\u0015\u0011bBs*.4\u00023r22o";
        objectArray[49] = "3\u0018hc\u0006\u00181\u0017 \r\u0019eoL\u007fj\u000e\nn\u001dzq";
        objectArray[50] = "{I{\u0004d7yF3jzJ+^iP\u007f{\"_s\u0006";
        objectArray[51] = "Y\u0000\r!\u0013:[\u000fEO\u000eG\b\n\r-T6\t\u0012\u0011v";
        objectArray[52] = "N.\u0015nH;O6\t5w \u007f'Yr\ft\u001e0X`K";
        objectArray[53] = "Oh\u007f\u0019[p^k \u001dfw&ow\u001b\u0003n\u001bibP^\u001e";
        objectArray[54] = "wcAom\u000bul\t\u0001ov)rIaz\u001d|9]<";
        objectArray[55] = "k-\u0007`O\fi\"O\u000eOq7y\u0010iG\u001e6(\u0015r";
        objectArray[56] = "]u\nvk#R)\u0014)\u0006\u0014qR*]\\N]u\nvk#R)\u0014)";
        objectArray[57] = "`)N\u0004\b\u000fi?H\f1W\u0003<\u0014\bCFm'\u000f\u0005\u0001>a?N\u001dLS; I[1";
        objectArray[58] = "o>\u001er\bc9-]<kvVfR5\u0000d$-\u001b S";
        objectArray[59] = "B\u0012;\u001b*c@\u001dsu9\u001e[\u001f#\u0007*p@\u0004.ER.\u001bI/N,/B\u001dzu";
        objectArray[60] = "z[<2E\u0012xTt\\TocV$.E\u0001xM)l=\u0004dR67WU'Ov\\";
        objectArray[61] = "\u0013~\f\u007f\u0014?\u0011qD\u0011\u0000B\ns\u0014c\u0014,\u0011h\u0019!lrJ%\u0018*\u0012s\u0013qM\u0011";
        objectArray[62] = "f\u0016'\u0010COd\u0019o~K2m\u00025\u0005PX<A(E";
        objectArray[63] = "@xpgJ\u0011Bw8\tIl\u001dk8u\u000e\u0010\u001c+f9";
        objectArray[64] = "\u007f%c#fB*nw~\t@Aaw1`U:ea<t)";
        objectArray[65] = "Zj\u000b\u000bR\u0007\u000bj\u0004\u001e0\b`-\u0012\u0018Z]YqY\u0014]b";
        objectArray[66] = "Y\u0007M\u0015\u0010\u001c[\b\u0005{\u0019a\tT\r\u001eS\u001f\b\rYK";
        objectArray[67] = "\u00063Iyhl\u0004<\u0001\u0017y\u0011\u001f>Qeh\u007f\u0004%\\'\u0010s\u001cdDj})\u0003c\u0002\u0017";
        objectArray[68] = "J3N\u00044KH<\u0006j!6S>V\u00184XH%[ZL\u0006\u0013hZQ2\u0007J<\u000fj";
        objectArray[69] = "-7N%,\u0016$!H-\u0015LN\"\u0014)g_ 9\u000f$%',!N<hJv>Iz\u0015";
        objectArray[70] = "\u000e!a|\u001af\f.)\u0012\u001f\u001bS2)n^gRrw\"";
        objectArray[71] = "\u0018\u0004\u0000p&h\u001a\u000bH\u001e4\u0015\u0001\t\u0018l&{\u001a\u0012\u0015.^w\u0002S\rc3-\u001dTK\u001e";
        objectArray[72] = "{(b2a\u000ey'*\\psb%z.a\u001dy>wl\u0019\t\" ,=h\u001fg:p\\";
        objectArray[73] = "0~aX<s2q)6-\u000e)syD<`2ht\u0006Da*pwI~q5$}6";
        objectArray[74] = "dY\u001a\u0001PtfVRoW\toM\b\u0014Cc>\u000e\u0015T";
        Object[] objectArray2 = objectArray;
        objectArray[75] = "\u001cP\u0012Vl:JCQ\u0018\u000f\"%K\b\u0000}>KP\u0013\r?FGHR\u0015r+\u001dWUS\u000f";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = Glint.e(l2, l3);
            object = H[n2];
            try {
                if (!(object instanceof String)) break block2;
                Glint.H[n2] = clazz = Class.forName(I[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = Glint.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = Glint.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = Glint.e(l2, l3);
        Object object = H[n2];
        if (object instanceof String) {
            String string = I[n2];
            int n3 = string.indexOf(8);
            Class clazz = Glint.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = Glint.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = Glint.c(clazz3, string2, clazz2)) != null) {
                    Glint.H[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = Glint.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        Glint.H[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = Glint.f(1155999678213924L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = Glint.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = Glint.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = Glint.e(l2, l3);
        Object object = H[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = I[n2];
                int n4 = string2.indexOf(8);
                clazz3 = Glint.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = Glint.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = Glint.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        Glint.H[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = Glint.f(1155999678213924L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = Glint.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        Glint.H[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = Glint.f(1155999678213924L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == '\u00c7' || c2 == 'G' || c2 == 'I' || c2 == '\u00c1') {
                field = Glint.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == '\u00c7' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == 'G' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == 'I' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = Glint.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == '\u00c4' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == '\u00d2' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = Glint.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/Q" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Glint.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(Glint.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

