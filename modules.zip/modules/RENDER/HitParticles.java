// === Kuzi module: HitParticles ===
// Category   : RENDER
// Description: Particles burst from players when they take damage
// Payload    : a.a.a.j.g.U (verified: True)

package kuzi.modules.render;

import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.b.e;
import kuzi.obf.h.b.k;
import kuzi.obf.h.b.l;
import kuzi.obf.h.b.v;
import kuzi.obf.j.g.ar;
import kuzi.obf.l.d.b;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.Vec3;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class HitParticles
extends BaseModule {
    private final l m;
    private final e n;
    private final l o;
    private final SliderSetting scale;
    private final SliderSetting speed;
    private final SliderSetting amount;
    private final SliderSetting timeBeforeDisappear;
    private final BoolSetting onlySelf;
    private final k u;
    private final BoolSetting glow;
    private final List w;
    private final Map x;
    private final Random y;
    private long z;
    private static final long A;
    private static final String[] B;
    private static final String[] C;
    private static final Map D;
    private static final long[] E;
    private static final Integer[] F;
    private static final Map G;
    private static final Object[] H;
    private static final String[] I;

    public HitParticles() {
        long l2;
        long l3 = l2 = A ^ 0x7E1F17D9166CL;
        long l4 = l3 ^ 0x6C67547C20B7L;
        long l5 = l3 ^ 0x6618355F38C1L;
        super("HitParticles", "Particles burst from players when they take damage", Category.RENDER);
        this.m = new l("Particles", kuzi.obf.l.d.b.STARS, b.class);
        this.n = new e("Color", new Color(255, 80, 80));
        this.o = new l("Physics", kuzi.obf.j.g.v.BURST, kuzi.obf.j.g.v.class);
        this.scale = new SliderSetting("Scale", 0.3, 0.05, 1.5, 0.05);
        this.speed = new SliderSetting("Speed", 3.0, 1.0, 15.0, 1.0);
        this.amount = new SliderSetting("Amount", 2.0, 1.0, 8.0, 1.0);
        this.timeBeforeDisappear = new SliderSetting("Time Before Disappear", 3.0, 1.0, 10.0, 1.0);
        this.onlySelf = new BoolSetting("Only Self", false);
        this.u = new k("Rotation Speed", 0.0, 60.0, 1.0, 0.0, 60.0);
        this.glow = new BoolSetting("Glow", true);
        this.w = new ArrayList();
        this.x = new HashMap();
        this.y = new Random();
        this.z = 0L;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.m, this.n, this.o, this.scale, this.speed, this.amount, this.timeBeforeDisappear, this.onlySelf, this.u, this.glow};
        objectArray[0] = l5;
        this.l(objectArray);
        WorldRenderEvents.END_MAIN.register(arg_0 -> this.a(l4, arg_0));
    }

    @Override
    public void e() {
        super.e();
        this.w.clear();
        this.x.clear();
    }

    /*
     * Exception decompiling
     */
    private Vec3 a(Object[] var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 2[SWITCH]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:435)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:484)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    private void a(long var1_1, WorldRenderContext var3_2) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [14[UNCONDITIONALDOLOOP]], but top level block is 30[SIMPLE_IF_TAKEN]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:435)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:484)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private static float a(Object[] objectArray) {
        long l2;
        long l3;
        block4: {
            long l4;
            block5: {
                l4 = (Long)objectArray[0];
                l3 = (Long)objectArray[1];
                long l5 = (Long)objectArray[2];
                l5 = A ^ l5;
                CallSite callSite = HitParticles.d("r", (long)8642239210623128725L, (long)l5);
                try {
                    try {
                        l2 = l3;
                        if (callSite == null) break block4;
                        if (l2 > 0L) break block5;
                    }
                    catch (MatchException matchException) {
                        throw HitParticles.d("r", (Object)matchException, (long)8642543121126978209L, (long)l5);
                    }
                    return 0.0f;
                }
                catch (MatchException matchException) {
                    throw HitParticles.d("r", (Object)matchException, (long)8642543121126978209L, (long)l5);
                }
            }
            l2 = l4;
        }
        float f2 = (float)l2 / (float)l3;
        return Math.max(0.0f, Math.min(1.0f, Math.min(f2 / 0.1f, (1.0f - f2) / 0.3f)));
    }

    private float b(Object[] objectArray) {
        double min = (Double)objectArray[0];
        long l2 = (Long)objectArray[1];
        double max = (Double)objectArray[2];
        l2 = A ^ l2;
        return (float)(min + ((Random)((Object)HitParticles.d("Y", (Object)this, (long)8843988245165475312L, (long)l2))).nextDouble() * (max - min));
    }

    private static boolean lambda$render$0(long l2, char c2, long l3, ar ar2) {
        long l4;
        block2: {
            block3: {
                long l5 = ((long)c2 << 48 | l3 << 16 >>> 16) ^ A;
                CallSite callSite = HitParticles.d("r", (long)8058158347638197422L, (long)l5);
                try {
                    long l6 = l2 - HitParticles.d("Y", (Object)ar2, (long)8056473543863079019L, (long)l5) - HitParticles.d("Y", (Object)ar2, (long)8058794388858830196L, (long)l5);
                    l4 = l6 == 0L ? 0 : (l6 < 0L ? -1 : 1);
                    if (callSite == null) break block2;
                    if (l4 < 0) break block3;
                }
                catch (MatchException matchException) {
                    throw HitParticles.d("r", (Object)matchException, (long)8055613417554373274L, (long)l5);
                }
                l4 = 1;
                break block2;
            }
            l4 = 0;
        }
        return (boolean)l4;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block21: {
            block20: {
                block19: {
                    block18: {
                        HitParticles.A = kuzi.obf.h.b.v.a(-622178318289240969L, -3518216186396126967L, MethodHandles.lookup().lookupClass()).a(157375491994495L);
                        HitParticles.H = new Object[78];
                        HitParticles.I = new String[78];
                        HitParticles.c();
                        HitParticles.D = new HashMap<K, V>(13);
                        var11 = HitParticles.A ^ 57850830849028L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[12];
                        var18_4 = 0;
                        var17_5 = "\u00e1\\\u00a9\u00db{&\u0089\u00ef\u00bf\u0097\u00ab]Ld\u00f6\u00d2\u0010\u00c4\u00b6d\u009e\u00b9\u00e4\u0098H\u0003\u00da\u0095\u00b2\u0007c~\u0010 \u00d9\u009b\u0094\u00d6\u00f9\u00e5\u00e0\u00f2\u0086N\u00910)\u0019\u0080\u00c8\u00afA\u0007\u00ef\u00db\u0019\u00d9o\u00c9~\t\u00a0\u0093X\u00a96\u0018Y\u00c9#\u0017\u00fc\u00b1\u00aeE\u00af\u00ec@\u00cb\u00f4}\u00ed\u00a2`\u00bf\u00db\u0090\u00ce\u00c6\u0091\u00ea\u00108\u00eai\u009c]`\u0090\u0018}l\u00a2y-z%\u00c2(\u00d6\u0099ehI6]\u000b,%\u00c63\u0012 2\u0015V\n\u00eb\u009a'\u00d5\u00cd\u00d6[\u00c9\u009ax.w\u00e4\r\u00b4\u00e3\u00c1I\u00b1\u00a2\u00a0\u00a0\u0018\u009a~\u00d0\u0089\u00f6{W@\u00b6\u00b8\u00d9j\u001a\u007fe&\u00d7\u00f8?[\u0081\u0007\u00ac\u00ad\u0010>\u00ce\u0082e\u0090X\u0087\u00d7M@C\u0082\u008c\u008aP:\u0010m|f~\u0018\u00f5\u00d1\u00bf\u00fd\u0093=\rTQ\u00021\u0010C\u00ba\u009b\u00fe\u0081\u00e6\u00e0\u00bd-\u00aa4\u0004)p\u00a5\u00a7";
                        var19_6 = "\u00e1\\\u00a9\u00db{&\u0089\u00ef\u00bf\u0097\u00ab]Ld\u00f6\u00d2\u0010\u00c4\u00b6d\u009e\u00b9\u00e4\u0098H\u0003\u00da\u0095\u00b2\u0007c~\u0010 \u00d9\u009b\u0094\u00d6\u00f9\u00e5\u00e0\u00f2\u0086N\u00910)\u0019\u0080\u00c8\u00afA\u0007\u00ef\u00db\u0019\u00d9o\u00c9~\t\u00a0\u0093X\u00a96\u0018Y\u00c9#\u0017\u00fc\u00b1\u00aeE\u00af\u00ec@\u00cb\u00f4}\u00ed\u00a2`\u00bf\u00db\u0090\u00ce\u00c6\u0091\u00ea\u00108\u00eai\u009c]`\u0090\u0018}l\u00a2y-z%\u00c2(\u00d6\u0099ehI6]\u000b,%\u00c63\u0012 2\u0015V\n\u00eb\u009a'\u00d5\u00cd\u00d6[\u00c9\u009ax.w\u00e4\r\u00b4\u00e3\u00c1I\u00b1\u00a2\u00a0\u00a0\u0018\u009a~\u00d0\u0089\u00f6{W@\u00b6\u00b8\u00d9j\u001a\u007fe&\u00d7\u00f8?[\u0081\u0007\u00ac\u00ad\u0010>\u00ce\u0082e\u0090X\u0087\u00d7M@C\u0082\u008c\u008aP:\u0010m|f~\u0018\u00f5\u00d1\u00bf\u00fd\u0093=\rTQ\u00021\u0010C\u00ba\u009b\u00fe\u0081\u00e6\u00e0\u00bd-\u00aa4\u0004)p\u00a5\u00a7".length();
                        var16_7 = 16;
                        var15_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block18;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = HitParticles.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "\u0004\"y77\u008b2\u00e1j\u0096V\u00a5\u00c7\u00ca.~\u00d2\u00e9\u00a6\u00b6.U\u0013\u0005^\u0089b\u009a|KKTt5\u00ff\u00f9:.\u00cdNP\u00dd\u00ed\u00b8~~\u00d3\u00bb@?\u0016\u00b6\u009b\u00f4\u008a\u008e\u008b\n.\u0096\u0010s\u0098\u0010\u007f\u00dc\u0017F\u00d5K\u00ccBL\u0086;\tsGV\u0085\u00c2\u00be\u00c2\u00d0\u0092\b\u001cw\u0018\u009e\u00d3\u00f8\n\u00cc$=T\u00a1\u00dc\u00b7r3\u00e0\u009b\u0088\u0091\u00e5o#\u0019\u0099m\"";
                            var19_6 = "\u0004\"y77\u008b2\u00e1j\u0096V\u00a5\u00c7\u00ca.~\u00d2\u00e9\u00a6\u00b6.U\u0013\u0005^\u0089b\u009a|KKTt5\u00ff\u00f9:.\u00cdNP\u00dd\u00ed\u00b8~~\u00d3\u00bb@?\u0016\u00b6\u009b\u00f4\u008a\u008e\u008b\n.\u0096\u0010s\u0098\u0010\u007f\u00dc\u0017F\u00d5K\u00ccBL\u0086;\tsGV\u0085\u00c2\u00be\u00c2\u00d0\u0092\b\u001cw\u0018\u009e\u00d3\u00f8\n\u00cc$=T\u00a1\u00dc\u00b7r3\u00e0\u009b\u0088\u0091\u00e5o#\u0019\u0099m\"".length();
                            var16_7 = 88;
                            var15_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block18;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = HitParticles.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block19;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                HitParticles.B = var20_3;
                HitParticles.C = new String[12];
                HitParticles.G = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[11];
                var3_13 = 0;
                var4_14 = "\u00c7\u0003\u0014w\u00ff\u00ben\u00d4\u00ac\u00db?\u00d1\u00f3\u00e0\u00cd\u00bbwx)\u001d%\u00c1\u00fe\u00f0\u00a5\u0004{jNP\u008d'\u00e7\u00d68\u00a0\u00f0\u009e6\u008ft\u00f1E\u00ac\u00b8<pKG\u0090ff\u00c7n{\u009cb\u0099\u00f3],\f\u0001\u0095\u00c27\u009ftJ\u0092\u00a2\u00cb";
                var5_15 = "\u00c7\u0003\u0014w\u00ff\u00ben\u00d4\u00ac\u00db?\u00d1\u00f3\u00e0\u00cd\u00bbwx)\u001d%\u00c1\u00fe\u00f0\u00a5\u0004{jNP\u008d'\u00e7\u00d68\u00a0\u00f0\u009e6\u008ft\u00f1E\u00ac\u00b8<pKG\u0090ff\u00c7n{\u009cb\u0099\u00f3],\f\u0001\u0095\u00c27\u009ftJ\u0092\u00a2\u00cb".length();
                var2_16 = 0;
                while (true) {
                    var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                    v10 = var6_12;
                    v11 = var3_13++;
                    v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                    v13 = -1;
                    break block20;
                    break;
                }
lbl81:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    var4_14 = "\u0016\u0018.%r\u00c1W\u00a7UW:\u0095\u00be\u0007\u008d'";
                    var5_15 = "\u0016\u0018.%r\u00c1W\u00a7UW:\u0095\u00be\u0007\u008d'".length();
                    var2_16 = 0;
                    while (true) {
                        var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                        v10 = var6_12;
                        v11 = var3_13++;
                        v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                        v13 = 0;
                        break block20;
                        break;
                    }
                    break;
                }
lbl94:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    break block21;
                    break;
                }
            }
            var8_18 = v12;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            v14 = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
            switch (v13) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl107:
                // 1 sources

                ** continue;
            }
        }
        HitParticles.E = var6_12;
        HitParticles.F = new Integer[11];
    }

    private static MatchException a(MatchException matchException) {
        return matchException;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x53DF;
        if (F[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = E[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])G.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    G.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/g/U", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            HitParticles.F[n3] = n4;
        }
        return F[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = HitParticles.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/U" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (I[n4] != null) {
            return n4;
        }
        Object object = H[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 22;
            case 1 -> 36;
            case 2 -> 45;
            case 3 -> 28;
            case 4 -> 6;
            case 5 -> 23;
            case 6 -> 61;
            case 7 -> 31;
            case 8 -> 21;
            case 9 -> 32;
            case 10 -> 13;
            case 11 -> 12;
            case 12 -> 37;
            case 13 -> 1;
            case 14 -> 16;
            case 15 -> 53;
            case 16 -> 41;
            case 17 -> 44;
            case 18 -> 26;
            case 19 -> 46;
            case 20 -> 27;
            case 21 -> 42;
            case 22 -> 43;
            case 23 -> 24;
            case 24 -> 62;
            case 25 -> 30;
            case 26 -> 15;
            case 27 -> 0;
            case 28 -> 2;
            case 29 -> 11;
            case 30 -> 5;
            case 31 -> 49;
            case 32 -> 47;
            case 33 -> 50;
            case 34 -> 29;
            case 35 -> 52;
            case 36 -> 48;
            case 37 -> 35;
            case 38 -> 19;
            case 39 -> 56;
            case 40 -> 10;
            case 41 -> 51;
            case 42 -> 9;
            case 43 -> 38;
            case 44 -> 7;
            case 45 -> 39;
            case 46 -> 25;
            case 47 -> 57;
            case 48 -> 3;
            case 49 -> 63;
            case 50 -> 33;
            case 51 -> 14;
            case 52 -> 8;
            case 53 -> 40;
            case 54 -> 34;
            case 55 -> 55;
            case 56 -> 18;
            case 57 -> 59;
            case 58 -> 60;
            case 59 -> 58;
            case 60 -> 4;
            case 61 -> 17;
            case 62 -> 20;
            default -> 54;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        HitParticles.I[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = H;
        H[0] = "\\MgB\u001ePWMaB*";
        objectArray[1] = "\r^IP!\"\u0013VS\u001f]6\t[P\\";
        objectArray[2] = "lDl\b+6gDj\b+j";
        objectArray[3] = Long.TYPE;
        HitParticles.I[3] = "java/lang/Long";
        objectArray[4] = "#H\u0013\u007fC\u0018(G\u00020 \u0015=J\r[\u0015\u0017,Y\u0011w\u0002\u001a";
        objectArray[5] = "i19W8kb1?W8\u0001";
        objectArray[6] = "i1";
        objectArray[7] = "A\f\u001et\u001d0H\f\u001dt\u0010";
        objectArray[8] = "M%\u0004w\u000fID%\u0007w\u000f";
        objectArray[9] = "^\f4I| U\u0003%\u0006\u001d.^\b!\\";
        objectArray[10] = "Y\b#X1<,((W sM&#\\$)9";
        objectArray[11] = Float.TYPE;
        HitParticles.I[11] = "java/lang/Float";
        objectArray[12] = "\u0014u\u0015%\u0004O\u001fu\u001d";
        objectArray[13] = "d\u0010-\u001aw3m\u0010.\u001au";
        objectArray[14] = "=O\u0017-\u001b04O\u0014-\u0017";
        objectArray[15] = "\u0002H$Y8@\tH\"Y/";
        objectArray[16] = "\rkEWBk\u0004kFWF";
        objectArray[17] = "+G\u001e|^n\"G\u001d|T";
        objectArray[18] = "\u001e\u000e},^G\u0015\u000ev";
        objectArray[19] = "xy0\r\u001d\\\rY;\u0002\f\u0013lW0\t\bI\u0018";
        objectArray[20] = Void.TYPE;
        HitParticles.I[20] = "java/lang/Void";
        objectArray[21] = "F_B7\u0000\u0005K_G7\u0003";
        objectArray[22] = "\"Z\u0014s$X<R\u000e<GL8";
        objectArray[23] = "\u000ebxO\u0015%{Bs@\u0004j\u001aLxK\u00000n";
        objectArray[24] = "}0=ap\r}0*=|\u0002g{*#|\u0017`\n{v+T";
        objectArray[25] = "#$E6Q&V\u0004N9@i7\nE2D3C";
        objectArray[26] = Double.TYPE;
        HitParticles.I[26] = "java/lang/Double";
        objectArray[27] = "l\nF($`a\nC(#";
        objectArray[28] = "aC\u001b|K4aC\f G;{\b\f>G.|y[g\u001fj";
        objectArray[29] = "\u000e<%\u0005K\u0018\u000e<2YG\u0017\u0014w2GG\u0002\u0013\u0006e\u001e\u001eI";
        objectArray[30] = "\u0012u:dN#gU1k_l\u0006[:`[6r";
        objectArray[31] = ",-E$w\u0005,-Rx{\n6fRf{\u001f1\u0017\u0003>)";
        objectArray[32] = "mN<_}\u0001sF&\u0010\u001f\u001dt[";
        objectArray[33] = "\u0014\u0019MnQ\f\t\f\u0015L\u0010\u0001\u0011\n";
        objectArray[34] = Boolean.TYPE;
        HitParticles.I[34] = "java/lang/Boolean";
        objectArray[35] = "[$6\u0017\u0015\u0016[$!K\u0019\u0019Ao!U\u0019\fF\u001ev\f@H";
        objectArray[36] = Integer.TYPE;
        HitParticles.I[36] = "java/lang/Integer";
        objectArray[37] = "y.\u0013aM\by.\u0004=A\u0007ce\u0004#A\u0012d\u0014S~\u0018U";
        objectArray[38] = Character.TYPE;
        HitParticles.I[38] = "java/lang/Character";
        objectArray[39] = Short.TYPE;
        HitParticles.I[39] = "java/lang/Short";
        objectArray[40] = "6\u0019MK'\u00001\u000bABB\u0019\u000fC\u0017K%\u0014o\u0015VU9";
        objectArray[41] = "rZV7[d\"\u000b\u0005\u0006^\u001a|\f\u0005kXu5\u001f^|";
        objectArray[42] = ")\u001b\u0002/ijyJQ\u001e`\u0014xH\ra\u007fh*M@a";
        objectArray[43] = "\u0018e$\b\u0003uH4w9\u0013\u000bC`iKD:\u001d\"(\u0004z4Vf{R\u0015nJ=i9";
        objectArray[44] = "tu\u007fz<\u001b}5b>MB\u00197&#*Myag=6+v|#&)Dtvm8M";
        objectArray[45] = "/19,2\u000b.s4wX\fDi;:*Yu7y{eg%ix\" Xt}b>X";
        objectArray[46] = "0e\u000eF`.`4]w\u007fPe1ZF~ daSM";
        objectArray[47] = "6nXq>~f?\u000b@?\u0000`eT=xahl\u0006q";
        objectArray[48] = "\"'B\t\u0016_rv\u00118\u001e!$\"\u0019@\u0003\\d%\u0014B";
        objectArray[49] = "\u0010]4Q'J@\fg`$4FV8\u001daUN_jQ";
        objectArray[50] = ">\u0015cw\u0012ve\u0005mt`|_\u0007kb\u000fxa\u0001a&\u001f\u0015e^vz\u0006u3\u001fhf`v<\u000f}$\u001b(b\th\u001d";
        objectArray[51] = "z`\u0016iM\u0003}r\u001a`(\u001eC?\u00065G\u001a,e\u001anU";
        objectArray[52] = "\u0019&7/\u00031E*<>c $i5.\u0013;\u001c/f4[I";
        objectArray[53] = "=TNq\u0003Cm\u0005\u001d@\u0010=fQ\u00032D\f8\u0013B}z\u0002sW\u0011+\u0015Xo\f\u0003@";
        objectArray[54] = "dab]y\u007f401l}\u00010go\u0007jm1%b\\";
        objectArray[55] = "mM.4c\r=\u001c}\u0005ss6Hcw$Bh\n\"8\u001a\u00173L{<v\u00176Mx\u0005";
        objectArray[56] = "6Rh RN1@d)7V\u000fVh~R\u0005cVm\u007fQ";
        objectArray[57] = "/zl'\b7'$ o4SR^\u0011\u001an\t/zl'\b7'$ o";
        objectArray[58] = "\u0001k&w\n\u0016Q:uF\rh\u000f=u+\t\u0007F..<";
        objectArray[59] = "6u\u001fYa-1g\u0013P\u00042\u000f*\u000f\u0005k4`p\u0013^y";
        objectArray[60] = "H\u001c^\u0017\u000f$\u0018M\r&\u001fZM[\t\u001c\u001fkHGS\u001av`\nATOGe\u0016\u001bR&";
        objectArray[61] = "P^p|}\f\u0000\u000f#McrR\u000e**zMS\u000f8(";
        objectArray[62] = "\u0004ly\u0017?MT=*&93^;%\u001c4JWl0\u001d";
        objectArray[63] = "=3\\\u000eT\f<cU\u00053\u0015W;TB\tD;`GUC|";
        objectArray[64] = "\"&Ba[7bmBw)'\u0019h[pI7d+Z\u007f\u0015M";
        objectArray[65] = "Rtd-\"x\tdj.Pr3fl8?v\r`f|/\u001b\\u*'4t^\u007fd9PxPnz~+&\u000ehoG";
        objectArray[66] = "vo\u001b*n\u000b&>H\u001blu d\u0017f(\u0014(mE*";
        objectArray[67] = "'Ua,Low]2.}3LQ$+\u001b> F%0\u000f_";
        objectArray[68] = "\u0016q\\_I8\u0011cPV,#/u\\\u0001IsCuY\u0000J";
        objectArray[69] = "{yr\f>\u0017-',\u0016N!OEJ1N\u0002t|p\u001d2T*\"j";
        objectArray[70] = "Z~!*2F\n/r\u001b98_\u007ft|-X\t>j`";
        objectArray[71] = "\u0001\u001b\u0011GxcQJBvd\u001d\u0003KK\u0011\u007f\"\u0002JY\u0013";
        objectArray[72] = "m\u000f\u0002zZR=^QKZ,;\u0004\u000e6\u001cM3\r\\z";
        objectArray[73] = "\u001f\\MM\u0004^OT\u001eO5\ntZO\\GPE\u0004\r\u001d\bn\u0019U\u001ePRS\u000bC\u001d\u00115";
        objectArray[74] = "F503N\"Ou-w?Iw\u0004\bT?\u007fS/n~\u000fv\u00132*";
        objectArray[75] = "P4XELVW&TL)Hin\u0002ENB\t8C[R";
        objectArray[76] = "n\u0006%I:\u0001i\u0014)@_\u001dWY5\u00150\u00188\u0003)N\"";
        Object[] objectArray2 = objectArray;
        objectArray[77] = "b/]H\u0004=9?SKv7\u00038GP\u0007 m\"QB\u001f^`<GLO%>bAYv&goHO\u000f l2R\"\u000e&j\"\u0015P\u00152~b-C\u0012\"f'\u0012\u0012\u00068z_LF\n;{`\u001dR\u0010'\u0003>I^\u0013&<o]D\u000f^<.\u0014M\u001d1f2O_v'`&G[H%<;\u0010\"I/:0FM\u00133a\"-XFde>\u0010D\b1>_UFF;n&SM\u001b!\u00032FL\u00079> POF^";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = HitParticles.e(l2, l3);
            object = H[n2];
            try {
                if (!(object instanceof String)) break block2;
                HitParticles.H[n2] = clazz = Class.forName(I[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = HitParticles.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = HitParticles.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = HitParticles.e(l2, l3);
        Object object = H[n2];
        if (object instanceof String) {
            String string = I[n2];
            int n3 = string.indexOf(8);
            Class clazz = HitParticles.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = HitParticles.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = HitParticles.c(clazz3, string2, clazz2)) != null) {
                    HitParticles.H[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = HitParticles.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        HitParticles.H[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = HitParticles.f(666717895275876L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = HitParticles.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = HitParticles.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = HitParticles.e(l2, l3);
        Object object = H[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = I[n2];
                int n4 = string2.indexOf(8);
                clazz3 = HitParticles.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = HitParticles.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = HitParticles.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        HitParticles.H[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = HitParticles.f(666717895275876L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = HitParticles.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        HitParticles.H[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = HitParticles.f(666717895275876L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == 'Y' || c2 == '\u00d9' || c2 == '\u00ec' || c2 == 'y') {
                field = HitParticles.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == 'Y' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == '\u00d9' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == '\u00ec' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = HitParticles.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == 'R' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == 'r' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = HitParticles.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/U" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(HitParticles.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(HitParticles.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

