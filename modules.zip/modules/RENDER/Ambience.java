// === Kuzi module: Ambience ===
// Category   : RENDER
// Description: Custom skies, time, weather and fog
// Payload    : a.a.a.j.g.B (verified: False)

package kuzi.modules.render;

import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import java.util.function.BooleanSupplier;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.core.Client;
import kuzi.mixin.MixinExposed;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.aa;
import kuzi.obf.h.b.e;
import kuzi.obf.h.b.l;
import kuzi.obf.h.b.v;
import kuzi.obf.i.ac;
import kuzi.obf.j.g.aD;
import kuzi.obf.j.g.b;
import kuzi.obf.j.g.c;
import kuzi.obf.j.g.d;
import kuzi.obf.j.g.f;
import kuzi.obf.j.g.g;
import kuzi.obf.l.e.a;
import kuzi.settings.BoolSetting;
import kuzi.settings.ButtonSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.Minecraft;
import net.minecraft.ClientLevel;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class Ambience
extends BaseModule {
    public final BoolSetting changeTime;
    public final l n;
    public final l o;
    public final SliderSetting timeValue;
    public final BoolSetting changeWeather;
    public final l r;
    public final l s;
    private final ButtonSetting chooseSky;
    public final e u;
    public final e v;
    public final e w;
    public final SliderSetting skySpeed;
    public final SliderSetting skyScale;
    public final SliderSetting skyIntensity;
    public final l A;
    public final SliderSetting skyOpacity;
    public final SliderSetting planetSize;
    public final BoolSetting meteors;
    public final SliderSetting meteorRate;
    public final BoolSetting hideSunMoon;
    public final l G;
    public final e H;
    public final SliderSetting fogDistance;
    private boolean weatherOverridden;
    private float savedRainLevel;
    private float savedThunderLevel;
    private static final long M;
    private static final String[] N;
    private static final String[] O;
    private static final Map P;
    private static final long[] Q;
    private static final Integer[] R;
    private static final Map S;
    private static final long[] T;
    private static final Long[] U;
    private static final Map V;
    private static final Object[] W;
    private static final String[] X;

    public Ambience() {
        block3: {
            block2: {
                long l2;
                long l3 = l2 = M ^ 0x4F965FBEA2BBL;
                long l4 = l3 ^ 0x311B4EB7B2DCL;
                int n2 = (int)(l4 >>> 48);
                int n3 = (int)(l4 << 16 >>> 48);
                int n4 = (int)(l4 << 32 >>> 32);
                long l5 = l3 ^ 0x3DFF0F328ED6L;
                long l6 = l3 ^ 0x3392D7CC54F3L;
                long l7 = l3 ^ 0x192F24FE265DL;
                long l8 = l3 ^ 0x4DBE2D4EE9AL;
                int n5 = (int)(l8 >>> 32);
                int n6 = (int)(l8 << 32 >>> 48);
                int n7 = (int)(l8 << 48 >>> 48);
                long l9 = l3 ^ 0x6D74F8228AEFL;
                int n8 = (int)(l9 >>> 32);
                int n9 = (int)(l9 << 32 >>> 48);
                int n10 = (int)(l9 << 48 >>> 48);
                long l10 = l3 ^ 0x16FE491CDDD5L;
                long l11 = l3 ^ 0x68909C42B80EL;
                long l12 = l3 ^ 0x31B8C7837478L;
                int[] nArray = aD.b();
                super("Ambience", "Custom skies, time, weather and fog", Category.RENDER);
                this.changeTime = new BoolSetting("Change Time", false);
                this.n = new l("Time Mode", kuzi.obf.j.g.e.PRESETS, kuzi.obf.j.g.e.class);
                int[] nArray2 = nArray;
                this.o = new l("Time", kuzi.obf.j.g.f.NIGHT, f.class);
                this.timeValue = new SliderSetting("Time Value", 1000.0, 0.0, 24000.0, 100.0);
                this.changeWeather = new BoolSetting("Change Weather", false);
                this.r = new l("Weather", kuzi.obf.j.g.g.CLEAR, g.class);
                this.s = new l("Sky", kuzi.obf.j.g.d.OFF, d.class);
                this.chooseSky = new ButtonSetting("Choose Sky", aa::a);
                this.u = new e("Sky Color 1", new Color(120, 80, 255));
                this.v = new e("Sky Color 2", new Color(40, 200, 255));
                this.w = new e("Sky Color 3", new Color(8, 10, 30));
                this.skySpeed = new SliderSetting("Sky Speed", 1.0, 0.0, 5.0, 0.1);
                this.skyScale = new SliderSetting("Sky Scale", 1.0, 0.3, 3.0, 0.05);
                this.skyIntensity = new SliderSetting("Sky Intensity", 1.0, 0.0, 3.0, 0.05);
                this.A = new l("Sky Fog", kuzi.obf.j.g.c.MATCH, c.class);
                this.skyOpacity = new SliderSetting("Sky Opacity", 1.0, 0.1, 1.0, 0.05);
                this.planetSize = new SliderSetting("Planet Size", 1.0, 0.4, 3.0, 0.05);
                this.meteors = new BoolSetting("Meteors", true);
                this.meteorRate = new SliderSetting("Meteor Rate", 1.0, 0.2, 5.0, 0.1);
                this.hideSunMoon = new BoolSetting("Hide Sun & Moon", false);
                this.G = new l("Fog", kuzi.obf.j.g.b.NONE, b.class);
                this.H = new e("Fog Color", new Color(88, 148, 255, 180));
                this.fogDistance = new SliderSetting("Fog Distance", 1.0, 0.05, 1.0, 0.05);
                this.weatherOverridden = false;
                Object[] objectArray = new Object[2];
                objectArray[1] = new Setting[]{this.changeTime, this.n, this.o, this.timeValue, this.changeWeather, this.r, this.chooseSky, this.s, this.A, this.u, this.v, this.w, this.skySpeed, this.skyScale, this.skyIntensity, this.skyOpacity, this.planetSize, this.meteors, this.meteorRate, this.hideSunMoon, this.G, this.H, this.fogDistance};
                objectArray[0] = l12;
                this.l(objectArray);
                BooleanSupplier booleanSupplier = () -> this.g(l6);
                for (Setting setting : new Setting[]{this.u, this.v, this.w, this.skySpeed, this.skyScale, this.skyIntensity, this.skyOpacity, this.A, this.hideSunMoon}) {
                    Object[] objectArray2 = new Object[2];
                    objectArray2[1] = booleanSupplier;
                    objectArray2[0] = l7;
                    setting.a(objectArray2);
                    if (nArray2 != null) {
                        if (nArray2 != null) continue;
                    }
                    break block2;
                }
                Object[] objectArray3 = new Object[2];
                objectArray3[1] = () -> this.lambda$new$0(l5);
                objectArray3[0] = l7;
                this.planetSize.a(objectArray3);
                Object[] objectArray4 = new Object[2];
                objectArray4[1] = () -> this.lambda$new$1(n8, (short)n9, n10);
                objectArray4[0] = l7;
                this.meteors.a(objectArray4);
                Object[] objectArray5 = new Object[2];
                objectArray5[1] = () -> this.lambda$new$2(l11);
                objectArray5[0] = l7;
                this.meteorRate.a(objectArray5);
                Object[] objectArray6 = new Object[2];
                objectArray6[1] = this.changeTime::a;
                objectArray6[0] = l7;
                this.n.a(objectArray6);
                Object[] objectArray7 = new Object[2];
                objectArray7[1] = () -> this.lambda$new$3((short)n2, (short)n3, n4);
                objectArray7[0] = l7;
                this.o.a(objectArray7);
                Object[] objectArray8 = new Object[2];
                objectArray8[1] = () -> this.lambda$new$4(n5, (short)n6, (short)n7);
                objectArray8[0] = l7;
                this.timeValue.a(objectArray8);
                Object[] objectArray9 = new Object[2];
                objectArray9[1] = this.changeWeather::a;
                objectArray9[0] = l7;
                this.r.a(objectArray9);
                Object[] objectArray10 = new Object[2];
                objectArray10[1] = () -> this.lambda$new$5(l10);
                objectArray10[0] = l7;
                this.H.a(objectArray10);
            }
            if (BaseModule.b() != null) break block3;
            aD.b(new int[2]);
        }
    }

    @Override
    public void e() {
        block2: {
            block4: {
                Minecraft mc;
                float f2;
                float f3;
                Minecraft clientMc;
                long l2;
                block3: {
                    long l3 = M ^ 0x213C36D78A35L;
                    l2 = l3 ^ 0xE3BA310CD83L;
                    int[] nArray = aD.b();
                    super.e();
                    int[] nArray2 = nArray;
                    if (!this.weatherOverridden) break block2;
                    clientMc = Client.e;
                    f3 = this.savedRainLevel;
                    f2 = this.savedThunderLevel;
                    mc = clientMc;
                    if (nArray2 == null) break block3;
                    if (mc == null) break block4;
                    mc = clientMc;
                }
                mc.execute(() -> Ambience.lambda$onDisable$6(l2, clientMc, f3, f2));
            }
            this.weatherOverridden = false;
        }
    }

    @Override
    public void h() {
        this.weatherOverridden = false;
    }

    @Override
    public void i() {
        Minecraft mc;
        Minecraft clientMc;
        long l2;
        block5: {
            block6: {
                block3: {
                    int[] nArray;
                    block4: {
                        block2: {
                            long l3 = M ^ 0x2C5B7BA22D37L;
                            l2 = l3 ^ 0x3D7A4EF1E0D9L;
                            clientMc = Client.e;
                            nArray = aD.b();
                            mc = clientMc;
                            if (nArray == null) break block2;
                            if (mc == null) break block3;
                            mc = clientMc;
                        }
                        if (nArray == null) break block4;
                        if (mc.level == null) break block3;
                        mc = clientMc;
                    }
                    if (nArray == null) break block5;
                    if (mc.player != null) break block6;
                }
                return;
            }
            mc = clientMc;
        }
        ClientLevel level = mc.level;
        clientMc.execute(() -> this.lambda$onTick$7(l2, clientMc, level));
    }

    /*
     * Exception decompiling
     */
    private long a(Object[] var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [3[TRYBLOCK]], but top level block is 4[SWITCH]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:435)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:484)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @MixinExposed
    public boolean a() {
        int[] nArray = aD.b();
        boolean bl = this.d();
        if (nArray != null) {
            if (!bl) return false;
            bl = (Boolean)this.changeTime.a();
        }
        if (nArray == null) return bl;
        if (!bl) return false;
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @MixinExposed
    public boolean f() {
        long l2 = M ^ 0x19F679971550L;
        long l3 = l2 ^ 0x65F2F1E5E318L;
        int[] nArray = aD.b();
        boolean bl = this.d();
        if (nArray != null) {
            if (!bl) return false;
            bl = this.g(l3);
        }
        if (nArray == null) return bl;
        if (!bl) return false;
        return true;
    }

    private boolean g(long l2) {
        long l3 = (l2 = M ^ l2) ^ 0x324419EABB42L;
        int[] nArray = aD.b();
        Object[] objectArray = new Object[2];
        objectArray[1] = Ambience.b("i", (int)26626, (long)(0x2B26D2D68CD59544L ^ l2));
        objectArray[0] = l3;
        boolean bl = this.a(objectArray);
        if (nArray != null) {
            bl = !bl;
        }
        return bl;
    }

    private boolean a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        String string = (String)objectArray[1];
        l2 = M ^ l2;
        return ((d)((Object)Ambience.f("h", (Object)Ambience.f("\u00cb", (Object)this, (long)56912235465261839L, (long)l2), (long)58653526475018267L, (long)l2))).name().equals(string);
    }

    @MixinExposed
    public a a() {
        try {
            return kuzi.obf.l.e.a.valueOf(((d)((Object)this.s.a())).name());
        }
        catch (IllegalArgumentException illegalArgumentException) {
            return kuzi.obf.l.e.a.NEBULA;
        }
    }

    @MixinExposed
    public kuzi.obf.l.e.c a() {
        return new kuzi.obf.l.e.c(((Double)this.skySpeed.a()).floatValue(), ((Double)this.skyScale.a()).floatValue(), ((Double)this.skyIntensity.a()).floatValue(), ((Double)this.skyOpacity.a()).floatValue(), this.u.a().getRGB(), this.v.a().getRGB(), this.w.a().getRGB(), (Boolean)this.meteors.a(), ((Double)this.meteorRate.a()).floatValue(), ((Double)this.planetSize.a()).floatValue());
    }

    @MixinExposed
    public boolean h() {
        return (Boolean)this.hideSunMoon.a();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @MixinExposed
    public boolean i() {
        int[] nArray = aD.b();
        boolean bl = this.f();
        if (nArray != null) {
            if (!bl) return false;
            bl = ((c)((Object)this.A.a())).name().equals("CLEAR");
        }
        if (nArray == null) return bl;
        if (!bl) return false;
        return true;
    }

    /*
     * Enabled aggressive block sorting
     */
    @MixinExposed
    public float[] a() {
        int n2;
        float[] skyColor1;
        float[] skyColor2;
        float[] skyColor3;
        block37: {
            Ambience ambience;
            int[] nArray;
            long l2;
            block36: {
                boolean bl;
                block35: {
                    long l3 = M ^ 0x7B96634E75E6L;
                    l2 = l3 ^ 0x78F2B814C2A0L;
                    nArray = aD.b();
                    bl = this.f();
                    if (nArray == null) break block35;
                    if (!bl) return null;
                    ambience = this;
                    if (nArray == null) break block36;
                    bl = ((c)((Object)ambience.A.a())).name().equals("MATCH");
                }
                if (!bl) {
                    return null;
                }
                ambience = this;
            }
            Object[] objectArray = new Object[2];
            objectArray[1] = ambience.u;
            objectArray[0] = l2;
            skyColor1 = Ambience.a(objectArray);
            Object[] objectArray2 = new Object[2];
            objectArray2[1] = this.v;
            objectArray2[0] = l2;
            skyColor2 = Ambience.a(objectArray2);
            Object[] objectArray3 = new Object[2];
            objectArray3[1] = this.w;
            objectArray3[0] = l2;
            skyColor3 = Ambience.a(objectArray3);
            String skyName = ((d)((Object)this.s.a())).name();
            int n3 = -1;
            n2 = skyName.hashCode();
            if (nArray == null) break block37;
            switch (n2) {
                case 65310691: {
                    n2 = skyName.equals("DREAM") ? 1 : 0;
                    if (nArray != null) {
                        if (n2 == 0) break;
                        n3 = 0;
                        if (nArray != null) break;
                    }
                    break block37;
                }
                case 148295273: {
                    n2 = skyName.equals("PILLARS") ? 1 : 0;
                    if (nArray != null) {
                        if (n2 == 0) break;
                        n3 = 1;
                        if (nArray != null) break;
                    }
                    break block37;
                }
                case -1996120257: {
                    n2 = skyName.equals("NEBULA") ? 1 : 0;
                    if (nArray != null) {
                        if (n2 == 0) break;
                        n3 = 2;
                        if (nArray != null) break;
                    }
                    break block37;
                }
                case 1993660458: {
                    n2 = skyName.equals("COSMOS") ? 1 : 0;
                    if (nArray != null) {
                        if (n2 == 0) break;
                        n3 = 3;
                        if (nArray != null) break;
                    }
                    break block37;
                }
                case 62083256: {
                    n2 = skyName.equals("ABYSS") ? 1 : 0;
                    if (nArray != null) {
                        if (n2 == 0) break;
                        n3 = 4;
                        if (nArray != null) break;
                    }
                    break block37;
                }
                case -1196160473: {
                    n2 = skyName.equals("ECLIPSE") ? 1 : 0;
                    if (nArray != null) {
                        if (n2 == 0) break;
                        n3 = 5;
                        if (nArray != null) break;
                    }
                    break block37;
                }
                case 79219777: {
                    n2 = skyName.equals("STARS") ? 1 : 0;
                    if (nArray != null) {
                        if (n2 == 0) break;
                        n3 = 6;
                        if (nArray != null) break;
                    }
                    break block37;
                }
                case 2630674: {
                    n2 = skyName.equals("VEIL") ? 1 : 0;
                    if (nArray != null) {
                        if (n2 == 0) break;
                        n3 = 7;
                        if (nArray != null) break;
                    }
                    break block37;
                }
                case 2515269: {
                    n2 = skyName.equals("RIFT") ? 1 : 0;
                    if (nArray != null) {
                        if (n2 == 0) break;
                        n3 = 8;
                        if (nArray != null) break;
                    }
                    break block37;
                }
                case 224087483: {
                    n2 = skyName.equals("PLANETS") ? 1 : 0;
                    if (nArray == null) break block37;
                    if (n2 == 0) break;
                    n3 = 9;
                }
            }
            n2 = n3;
        }
        switch (n2) {
            case 0: {
                float[] fArray4 = skyColor2;
                return fArray4;
            }
            case 1: {
                Object[] objectArray = new Object[2];
                objectArray[1] = Float.valueOf(0.5f);
                objectArray[0] = skyColor3;
                Object[] objectArray4 = new Object[3];
                objectArray4[2] = Float.valueOf(0.2f);
                objectArray4[1] = skyColor1;
                objectArray4[0] = Ambience.b(objectArray);
                float[] fArray4 = Ambience.c(objectArray4);
                return fArray4;
            }
            case 2: 
            case 3: 
            case 4: {
                Object[] objectArray = new Object[2];
                objectArray[1] = Float.valueOf(0.45f);
                objectArray[0] = skyColor3;
                float[] fArray4 = Ambience.b(objectArray);
                return fArray4;
            }
            case 5: {
                Object[] objectArray = new Object[2];
                objectArray[1] = Float.valueOf(0.4f);
                objectArray[0] = skyColor3;
                float[] fArray4 = Ambience.b(objectArray);
                return fArray4;
            }
            case 6: 
            case 7: {
                Object[] objectArray = new Object[2];
                objectArray[1] = Float.valueOf(0.35f);
                objectArray[0] = skyColor3;
                float[] fArray4 = Ambience.b(objectArray);
                return fArray4;
            }
            case 8: {
                Object[] objectArray = new Object[2];
                objectArray[1] = Float.valueOf(0.25f);
                objectArray[0] = skyColor3;
                float[] fArray4 = Ambience.b(objectArray);
                return fArray4;
            }
            case 9: {
                Object[] objectArray = new Object[2];
                objectArray[1] = Float.valueOf(0.1f);
                objectArray[0] = skyColor3;
                float[] fArray4 = Ambience.b(objectArray);
                return fArray4;
            }
        }
        return null;
    }

    private static float[] a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        e e2 = (e)objectArray[1];
        l2 = M ^ l2;
        Color color = e2.a();
        return new float[]{(float)color.getRed() / 255.0f, (float)color.getGreen() / 255.0f, (float)color.getBlue() / 255.0f};
    }

    private static float[] b(Object[] objectArray) {
        float[] fArray = (float[])objectArray[0];
        float f2 = ((Float)objectArray[1]).floatValue();
        return new float[]{fArray[0] * f2, fArray[1] * f2, fArray[2] * f2};
    }

    private static float[] c(Object[] objectArray) {
        float[] fArray = (float[])objectArray[0];
        float[] fArray2 = (float[])objectArray[1];
        float f2 = ((Float)objectArray[2]).floatValue();
        return new float[]{fArray[0] + (fArray2[0] - fArray[0]) * f2, fArray[1] + (fArray2[1] - fArray[1]) * f2, fArray[2] + (fArray2[2] - fArray[2]) * f2};
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @MixinExposed
    public boolean j() {
        int[] nArray = aD.b();
        boolean bl = this.d();
        if (nArray != null) {
            if (!bl) return false;
            bl = ((b)((Object)this.G.a())).name().equals("OVERRIDE");
        }
        if (nArray == null) return bl;
        if (!bl) return false;
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @MixinExposed
    public boolean k() {
        int[] nArray = aD.b();
        boolean bl = this.d();
        if (nArray != null) {
            if (!bl) return false;
            bl = ((b)((Object)this.G.a())).name().equals("CLEAR");
        }
        if (nArray == null) return bl;
        if (!bl) return false;
        return true;
    }

    @MixinExposed
    public Color a() {
        return this.H.a();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @MixinExposed
    public float a() {
        int[] nArray = aD.b();
        Object object = this;
        if (nArray != null) {
            if (!((BaseModule)object).d()) return 1.0f;
            object = this.fogDistance.a();
        }
        float f2 = ((Double)object).floatValue();
        return f2;
    }

    private void lambda$onTick$7(long l2, Minecraft mc, ClientLevel level) {
        block15: {
            float f2;
            block16: {
                float f3;
                int[] nArray;
                int n2;
                int[] nArray2;
                block13: {
                    block14: {
                        long l3 = (l2 = M ^ l2) ^ 0x6DBC1D4E34E3L;
                        nArray2 = aD.b();
                        Object object = mc.level;
                        if (nArray2 != null) {
                            if (object == null) {
                                return;
                            }
                            object = this.changeTime.a();
                        }
                        n2 = ((Boolean)object).booleanValue();
                        nArray = nArray2;
                        if (l2 >= 0L) {
                            if (nArray != null) {
                                if (n2 != 0) {
                                    Object[] objectArray = new Object[1];
                                    objectArray[0] = l3;
                                    level.setTimeFromServer(level.getGameTime(), this.a(objectArray), false);
                                }
                                n2 = ((Boolean)this.changeWeather.a()).booleanValue();
                            }
                            nArray = nArray2;
                        }
                        if (l2 <= 0L) break block13;
                        if (nArray == null) break block14;
                        if (n2 == 0) break block15;
                        n2 = this.weatherOverridden;
                    }
                    nArray = nArray2;
                }
                if (nArray != null) {
                    if (n2 == 0) {
                        this.savedRainLevel = level.getRainLevel(1.0f);
                        this.savedThunderLevel = level.getThunderLevel(1.0f);
                        this.weatherOverridden = true;
                    }
                    n2 = ((g)((Object)this.r.a())).ordinal();
                }
                switch (n2) {
                    case 0: {
                        f3 = 0.0f;
                        f2 = 0.0f;
                        if (l2 > 0L) {
                            if (nArray2 != null) break;
                        }
                        break block16;
                    }
                    case 2: {
                        f3 = 1.0f;
                        f2 = 1.0f;
                        if (l2 >= 0L) {
                            if (nArray2 != null) break;
                        }
                        break block16;
                    }
                    default: {
                        f3 = 1.0f;
                        f2 = 0.0f;
                    }
                }
                level.setRainLevel(f3);
                level.setThunderLevel(f2);
                ((ac)level).kuzi$setLastRainGradient(f3);
            }
            ((ac)level).kuzi$setLastThunderGradient(f2);
        }
    }

    private static void lambda$onDisable$6(long l2, Minecraft mc, float f2, float f3) {
        l2 = M ^ l2;
        int[] nArray = aD.b();
        ClientLevel level = mc.level;
        if (nArray != null) {
            if (level == null) {
                return;
            }
            mc.level.setRainLevel(f2);
            mc.level.setThunderLevel(f3);
            ((ac)mc.level).kuzi$setLastRainGradient(f2);
            level = mc.level;
        }
        ((ac)level).kuzi$setLastThunderGradient(f3);
    }

    private boolean lambda$new$5(long l2) {
        l2 = M ^ l2;
        return this.G.a() == kuzi.obf.j.g.b.OVERRIDE;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean lambda$new$4(int n2, short s2, short s3) {
        long l2 = ((long)n2 << 32 | (long)s2 << 48 >>> 32 | (long)s3 << 48 >>> 48) ^ M;
        int[] nArray = aD.b();
        Object object = (Boolean)this.changeTime.a();
        if (nArray != null) {
            if (!((Boolean)object).booleanValue()) return false;
            object = this.n.a();
        }
        if (object != kuzi.obf.j.g.e.CUSTOM) return false;
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean lambda$new$3(short s2, short s3, int n2) {
        long l2 = ((long)s2 << 48 | (long)s3 << 48 >>> 16 | (long)n2 << 32 >>> 32) ^ M;
        int[] nArray = aD.b();
        Object object = (Boolean)this.changeTime.a();
        if (nArray != null) {
            if (!((Boolean)object).booleanValue()) return false;
            object = this.n.a();
        }
        if (object != kuzi.obf.j.g.e.PRESETS) return false;
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean lambda$new$2(long l2) {
        long l3 = (l2 = M ^ l2) ^ 0x6946526457BFL;
        int[] nArray = aD.b();
        Object[] objectArray = new Object[2];
        objectArray[1] = Ambience.b("i", (int)4302, (long)(0xBC469C80F95816AL ^ l2));
        objectArray[0] = l3;
        boolean bl = this.a(objectArray);
        if (nArray != null) {
            if (!bl) return false;
            bl = (Boolean)this.meteors.a();
        }
        if (nArray == null) return bl;
        if (!bl) return false;
        return true;
    }

    private boolean lambda$new$1(int n2, short s2, int n3) {
        long l2 = ((long)n2 << 32 | (long)s2 << 48 >>> 32 | (long)n3 << 48 >>> 48) ^ M;
        long l3 = l2 ^ 0x6CA23604655EL;
        Object[] objectArray = new Object[2];
        objectArray[1] = Ambience.b("i", (int)25815, (long)(0x5356A18AE17AC782L ^ l2));
        objectArray[0] = l3;
        return this.a(objectArray);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean lambda$new$0(long l2) {
        long l3 = (l2 = M ^ l2) ^ 0x3C29C1146167L;
        int[] nArray = aD.b();
        Object[] objectArray = new Object[2];
        objectArray[1] = Ambience.b("i", (int)25815, (long)(0x5356F101166AC3BBL ^ l2));
        objectArray[0] = l3;
        boolean bl = this.a(objectArray);
        if (nArray == null) return bl;
        if (bl) return true;
        Object[] objectArray2 = new Object[2];
        objectArray2[1] = Ambience.b("i", (int)7064, (long)(0x3387314DF7813CE1L ^ l2));
        objectArray2[0] = l3;
        bl = this.a(objectArray2);
        if (nArray == null) return bl;
        if (!bl) return false;
        return true;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block31: {
            block30: {
                block29: {
                    block28: {
                        block27: {
                            block26: {
                                Ambience.M = kuzi.obf.h.b.v.a(-4467064259336163458L, -1925744391811336151L, MethodHandles.lookup().lookupClass()).a(237672356147958L);
                                Ambience.W = new Object[93];
                                Ambience.X = new String[93];
                                Ambience.c();
                                Ambience.P = new HashMap<K, V>(13);
                                var22 = Ambience.M ^ 76610797280929L;
                                var24_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                                v0 = SecretKeyFactory.getInstance("DES");
                                v1 = new byte[8];
                                v2 = v1;
                                v1[0] = (byte)(var22 >>> 56);
                                for (var25_2 = 1; var25_2 < 8; ++var25_2) {
                                    v2 = v2;
                                    v2[var25_2] = (byte)(var22 << var25_2 * 8 >>> 56);
                                }
                                var24_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                                var31_3 = new String[42];
                                var29_4 = 0;
                                var28_5 = "\u0085;\u00e0\u00b4\u0014\u00f8\u00b2`\u000f\u00e6\u00b3F\u00a1A\u0004!X\u00f3S\u00dcD\u001d\u00f3i\u0010\u00f6\u00b1\u0001\u00b5\u00da\u008f\u00e7\u0084\u00dcA\u00b9\u0093\u008df<\u00c9\u0010\u00a5\u00ab\u00af\u00b9\u008e\u00c1>\u00cb\u001b\u00e9\u00f1M`>?\b\u0010\u00b6\u0018en\u00d1\\j\u0095\u00cc\u00efmYlP\u001c\u009a ,\tJ\u00dc\u00ff\u00c1`E\u0087\u00fc\u00dd\u00df\u00bb\u0090\u00d8\u0017_nl\"v\u00f4\u00b1\u00d4\u00b0\u0099/\\X\u001c\u0080\u0097 \u00db\u00bd\u00c1>\u0016\r\u00d2\u0085\u00d65\u00fd\u007f\u001f\u0086\u00b5\u00a3\u00969\u00cf*\u00c88K\u0096\u00c9\u0083\u00b0\u00f0R\u0010\u00f2\u00b8\u0018\u00d3\u001b!#%R\u00e1\b\u00b4\u009fo\u00eb\u00e0\u00ca\u00eb\u00af\u00c3]\u00cf\u00f5V4\u009c\u00fc\u0010\"\u00b1\u0097\u00f7=4\u00d2\u00d2\u00e9\u009a\u00ec\u00af8\u00b6\u00dc\u00f3\u0010\u0089\u00cf\u0096:;\u00c4\u00015\u0012~\u00ce#\u00f4\u00c2\u00b5\u00a3 e\u00df\u0001\u0001\u00e1\u00ad\u009a\u0094\u00a3T1\u0003\u0095S\u0086S|f\t\u00f0\u0019\u001f\u00fa\u001a\u00f9\u00db\u00ee\u0002\u00f7\u0004\u009a\"  \u00cc\u0081\u0001l'\u00a5\u0013>y!\u00c4\u00cb\u0012\u0011\u008a\u00ea\u0095=\u0004!e\u00d6\u00d5\u001fs\u00d2b\u0091\u00af<\u0004@\u00aae\u00ac\u0004\u00c5\u009a\u0018AA\u00e9\u00a1\u0087\u00e6\u0081N\u00f9\u0014\u00c6Y\u00ba\u00eaQ\u0003;\u0090B\nk\u00faSu\u00d9\u00b8\u00d1\u00cd\u00bc\u0007\u0095\u000e\u00c3\u000e\"\u0005\u00fd\u009db\u00fc\u00de\u00e1\u0013\u00ba\"\u00c2\u001bH8\u001a=^9~\u00b2\u00a1b\u0018\u00f4\u00ca_\u00cf\u00a4\u00ce\f\u00b2\u00e2\u0004V\u00a9\u0002q\u008b\u00ae\u00a6\u00c2\u00e0^\u0014\u001e\u00f1\u001b\u00100\u00e8f\u009b\u00b7\u0007\u000e!\u0004\u00c2\u00d8\\\u00a1\u00fc}\u009d\u0010j\u00fc\u00ad}\u00d76Q^\u0087\u0010\u00cc\u00ea\u00e0\u0089?\u00d0\u0010\u00b5_\u00d7\u00c7\u00e4\u0093\u00d4m\u00c8D1L\u0084\u001ddO\u0010\u0082\u00c8\u00d5\\o\u008a\u008c\u00a5\u00be\u00e3\u00e9\u00dd\u00c6\u0011\u00fa:\u0018\u00d6\u00cf\u00da\u00fd5\u00e0\u00fd\u00fdjI@\n\u0003#\u00ed;\u0015\u00ee\u009d\u00c0\u008e.\u00df\u00c2\u0010]\u00a7$\u00d4\u00d4I\u0010\u00c5\u00c7\u00f7%\u0004\u00b5\"B\u00a1 D\u009c/,d|l\u00a9n\u00bcf\u00e8\u00e2\u00ee\u00e6\u00fd\u00dc4e\u00b28\u00e7_\u0084J\u0089\u00ba\u00bf\u00c2\"\u00d2\u0000 \u00d0\u0086\u00d6V\u00d3\u00d7a\u00f2\u008b\u0082.\u00e5Oh\u00fd\u00eaw\u0093\u0002%\u0003 \u00ef\u00c9\u00cc\u00bd`\u0005\u0091\u00c8*\u00f1 \u0012`\u0087:F+H\u00b6C\u00d7\u001alO\u00ba\u00db)s\u0088v\u001b6\u0086!\u0084\u0005\re\u00b7\u00e9\u009b#\u00ce\u0010<\u0018\u00e3=n\u00f4o@?\u0006dyb\u00c1\"\u00f0\u0010\u00c7\u0082rJ\u0098\u0007\u00a5J\u00cdo/\u0082\u00c9\u000e\u00cb; \u00bf\u00aa:\u00b0~\u007f\u00ef\u00cb\u008aW\u00c1\u00b4\u00cb\u00eb\u00d7s\u00d5\u0082\u00e7\u00efz\u00e8vm\u00fe\u00ce\u00f7go\u0003\u00e3\u00e3 \\\u0019x\u00b6)\u00f4\u00b5-\u00f4\u008cLi\u00de\u00888W\u00e2\u0013\u0098'\u000bVzu\u00dc\u00faL\u00c6\u00fb\u0004w,\u0010!\u0090\u00adt\u00a8\u00abg\u00a7F\u00bf\u001d\u00fc$\u00d1\u009f-\u0018\u00c3\u0007\u00b3\f{\u00d9s]#+%\u0088\u00be\u0011\u00f0\u00804kHg\u0091f\u00d0\u001f\u0018\u0018$\u00cf]\n\u00bb\u009f?z\u0019\u0086\u0015\u00dd\rU\u00ca[ iN\u009d\u00ce\n \u0010\u001e\u00ef'`\t\u00a2\u00e4y_\u001c\u0017\u0093.\u00d0\u00e7\u008e\u0010\u0087\u00c7\u00c4\u00af\u00ff\u0016\u001b\u0099\u0004\u00d4\u00b8\u00dc\u00e2\u0092\u00ad5\u0018\u0019&\u0083w\u00e2f\u00d1\u00c0\u00a3\u00b8\u00f1$\u00a1\u00d3\u00f5\u0018[\u009a\u00bf\u0094V\u008c:\u00bb \u0003\u00a8\\\u00d0\u00e5An\u0091\u0099\u00baM\u009b\u00c5P\u00f5\b\u00feF\u00e0\u00efR\u00e5#s\u00e5\u00ee\u00a0J\u00a9t\u00e42\u0010\u00a8\u00a6]\u008d\u00ben\u0011\u001b%\u00e1\u0017\u00e2\u00e5\u0001b]\u0010\t\u0016\u00fb6#\u00a5\u008a\\\u00ae\u007f\u0000\u00f1\u00d0I\u001b\u00de\u0010\u00f3F\u0084\u0005\u00e2\u00ae\u00b3vx\u00d3\u00c3c\u0007@\u00df\u00a8\u0010\u00d4\u00f3\u00f3\u00da\u00c5aC\u00c8\u00ce\u00aaSW\u00ec\u00ed\u0082\u0018\u0010\u000f]\u00db\u00c6iF\u009aV\u00d7\u0082.\u00f3=\u00bc\u00b8\u00d5\u0010\u00bc\u00afR=\u008e0\u00c41d\u00c3j'\u008f2\u00e6\u00c7 <\u00ae^\u00ee/\u00ae/u\u0094\u0093\u00d9\u009a\u00819\u00a6\u00bc]\u00fc=\u00c4xG\u00e1\u00f4\u00e6Nh)N\u00b7\u0015\u00c8";
                                var30_6 = "\u0085;\u00e0\u00b4\u0014\u00f8\u00b2`\u000f\u00e6\u00b3F\u00a1A\u0004!X\u00f3S\u00dcD\u001d\u00f3i\u0010\u00f6\u00b1\u0001\u00b5\u00da\u008f\u00e7\u0084\u00dcA\u00b9\u0093\u008df<\u00c9\u0010\u00a5\u00ab\u00af\u00b9\u008e\u00c1>\u00cb\u001b\u00e9\u00f1M`>?\b\u0010\u00b6\u0018en\u00d1\\j\u0095\u00cc\u00efmYlP\u001c\u009a ,\tJ\u00dc\u00ff\u00c1`E\u0087\u00fc\u00dd\u00df\u00bb\u0090\u00d8\u0017_nl\"v\u00f4\u00b1\u00d4\u00b0\u0099/\\X\u001c\u0080\u0097 \u00db\u00bd\u00c1>\u0016\r\u00d2\u0085\u00d65\u00fd\u007f\u001f\u0086\u00b5\u00a3\u00969\u00cf*\u00c88K\u0096\u00c9\u0083\u00b0\u00f0R\u0010\u00f2\u00b8\u0018\u00d3\u001b!#%R\u00e1\b\u00b4\u009fo\u00eb\u00e0\u00ca\u00eb\u00af\u00c3]\u00cf\u00f5V4\u009c\u00fc\u0010\"\u00b1\u0097\u00f7=4\u00d2\u00d2\u00e9\u009a\u00ec\u00af8\u00b6\u00dc\u00f3\u0010\u0089\u00cf\u0096:;\u00c4\u00015\u0012~\u00ce#\u00f4\u00c2\u00b5\u00a3 e\u00df\u0001\u0001\u00e1\u00ad\u009a\u0094\u00a3T1\u0003\u0095S\u0086S|f\t\u00f0\u0019\u001f\u00fa\u001a\u00f9\u00db\u00ee\u0002\u00f7\u0004\u009a\"  \u00cc\u0081\u0001l'\u00a5\u0013>y!\u00c4\u00cb\u0012\u0011\u008a\u00ea\u0095=\u0004!e\u00d6\u00d5\u001fs\u00d2b\u0091\u00af<\u0004@\u00aae\u00ac\u0004\u00c5\u009a\u0018AA\u00e9\u00a1\u0087\u00e6\u0081N\u00f9\u0014\u00c6Y\u00ba\u00eaQ\u0003;\u0090B\nk\u00faSu\u00d9\u00b8\u00d1\u00cd\u00bc\u0007\u0095\u000e\u00c3\u000e\"\u0005\u00fd\u009db\u00fc\u00de\u00e1\u0013\u00ba\"\u00c2\u001bH8\u001a=^9~\u00b2\u00a1b\u0018\u00f4\u00ca_\u00cf\u00a4\u00ce\f\u00b2\u00e2\u0004V\u00a9\u0002q\u008b\u00ae\u00a6\u00c2\u00e0^\u0014\u001e\u00f1\u001b\u00100\u00e8f\u009b\u00b7\u0007\u000e!\u0004\u00c2\u00d8\\\u00a1\u00fc}\u009d\u0010j\u00fc\u00ad}\u00d76Q^\u0087\u0010\u00cc\u00ea\u00e0\u0089?\u00d0\u0010\u00b5_\u00d7\u00c7\u00e4\u0093\u00d4m\u00c8D1L\u0084\u001ddO\u0010\u0082\u00c8\u00d5\\o\u008a\u008c\u00a5\u00be\u00e3\u00e9\u00dd\u00c6\u0011\u00fa:\u0018\u00d6\u00cf\u00da\u00fd5\u00e0\u00fd\u00fdjI@\n\u0003#\u00ed;\u0015\u00ee\u009d\u00c0\u008e.\u00df\u00c2\u0010]\u00a7$\u00d4\u00d4I\u0010\u00c5\u00c7\u00f7%\u0004\u00b5\"B\u00a1 D\u009c/,d|l\u00a9n\u00bcf\u00e8\u00e2\u00ee\u00e6\u00fd\u00dc4e\u00b28\u00e7_\u0084J\u0089\u00ba\u00bf\u00c2\"\u00d2\u0000 \u00d0\u0086\u00d6V\u00d3\u00d7a\u00f2\u008b\u0082.\u00e5Oh\u00fd\u00eaw\u0093\u0002%\u0003 \u00ef\u00c9\u00cc\u00bd`\u0005\u0091\u00c8*\u00f1 \u0012`\u0087:F+H\u00b6C\u00d7\u001alO\u00ba\u00db)s\u0088v\u001b6\u0086!\u0084\u0005\re\u00b7\u00e9\u009b#\u00ce\u0010<\u0018\u00e3=n\u00f4o@?\u0006dyb\u00c1\"\u00f0\u0010\u00c7\u0082rJ\u0098\u0007\u00a5J\u00cdo/\u0082\u00c9\u000e\u00cb; \u00bf\u00aa:\u00b0~\u007f\u00ef\u00cb\u008aW\u00c1\u00b4\u00cb\u00eb\u00d7s\u00d5\u0082\u00e7\u00efz\u00e8vm\u00fe\u00ce\u00f7go\u0003\u00e3\u00e3 \\\u0019x\u00b6)\u00f4\u00b5-\u00f4\u008cLi\u00de\u00888W\u00e2\u0013\u0098'\u000bVzu\u00dc\u00faL\u00c6\u00fb\u0004w,\u0010!\u0090\u00adt\u00a8\u00abg\u00a7F\u00bf\u001d\u00fc$\u00d1\u009f-\u0018\u00c3\u0007\u00b3\f{\u00d9s]#+%\u0088\u00be\u0011\u00f0\u00804kHg\u0091f\u00d0\u001f\u0018\u0018$\u00cf]\n\u00bb\u009f?z\u0019\u0086\u0015\u00dd\rU\u00ca[ iN\u009d\u00ce\n \u0010\u001e\u00ef'`\t\u00a2\u00e4y_\u001c\u0017\u0093.\u00d0\u00e7\u008e\u0010\u0087\u00c7\u00c4\u00af\u00ff\u0016\u001b\u0099\u0004\u00d4\u00b8\u00dc\u00e2\u0092\u00ad5\u0018\u0019&\u0083w\u00e2f\u00d1\u00c0\u00a3\u00b8\u00f1$\u00a1\u00d3\u00f5\u0018[\u009a\u00bf\u0094V\u008c:\u00bb \u0003\u00a8\\\u00d0\u00e5An\u0091\u0099\u00baM\u009b\u00c5P\u00f5\b\u00feF\u00e0\u00efR\u00e5#s\u00e5\u00ee\u00a0J\u00a9t\u00e42\u0010\u00a8\u00a6]\u008d\u00ben\u0011\u001b%\u00e1\u0017\u00e2\u00e5\u0001b]\u0010\t\u0016\u00fb6#\u00a5\u008a\\\u00ae\u007f\u0000\u00f1\u00d0I\u001b\u00de\u0010\u00f3F\u0084\u0005\u00e2\u00ae\u00b3vx\u00d3\u00c3c\u0007@\u00df\u00a8\u0010\u00d4\u00f3\u00f3\u00da\u00c5aC\u00c8\u00ce\u00aaSW\u00ec\u00ed\u0082\u0018\u0010\u000f]\u00db\u00c6iF\u009aV\u00d7\u0082.\u00f3=\u00bc\u00b8\u00d5\u0010\u00bc\u00afR=\u008e0\u00c41d\u00c3j'\u008f2\u00e6\u00c7 <\u00ae^\u00ee/\u00ae/u\u0094\u0093\u00d9\u009a\u00819\u00a6\u00bc]\u00fc=\u00c4xG\u00e1\u00f4\u00e6Nh)N\u00b7\u0015\u00c8".length();
                                var27_7 = 24;
                                var26_8 = -1;
lbl23:
                                // 2 sources

                                while (true) {
                                    v3 = ++var26_8;
                                    v4 = var28_5.substring(v3, v3 + var27_7);
                                    v5 = -1;
                                    break block26;
                                    break;
                                }
lbl28:
                                // 1 sources

                                while (true) {
                                    var31_3[var29_4++] = Ambience.b(var32_9).intern();
                                    if ((var26_8 += var27_7) < var30_6) {
                                        var27_7 = var28_5.charAt(var26_8);
                                        ** continue;
                                    }
                                    var28_5 = "\u00db\u0013\u00b9\u0087\u0017\u00b4\u00c7H\u00bb\u001e*:\u00db\u00a4\u008b\u0093\u00f78{\u00ebj\u00b0\u0086\u00e4\u00e1\u00c3\n\u0001d5US\u0010\u00dc\u00b6\u00963\u0018\u0019\u00ba\u00f5BKmX\u00a1SD\u00e2";
                                    var30_6 = "\u00db\u0013\u00b9\u0087\u0017\u00b4\u00c7H\u00bb\u001e*:\u00db\u00a4\u008b\u0093\u00f78{\u00ebj\u00b0\u0086\u00e4\u00e1\u00c3\n\u0001d5US\u0010\u00dc\u00b6\u00963\u0018\u0019\u00ba\u00f5BKmX\u00a1SD\u00e2".length();
                                    var27_7 = 32;
                                    var26_8 = -1;
lbl37:
                                    // 2 sources

                                    while (true) {
                                        v6 = ++var26_8;
                                        v4 = var28_5.substring(v6, v6 + var27_7);
                                        v5 = 0;
                                        break block26;
                                        break;
                                    }
                                    break;
                                }
lbl42:
                                // 1 sources

                                while (true) {
                                    var31_3[var29_4++] = Ambience.b(var32_9).intern();
                                    if ((var26_8 += var27_7) < var30_6) {
                                        var27_7 = var28_5.charAt(var26_8);
                                        ** continue;
                                    }
                                    break block27;
                                    break;
                                }
                            }
                            var32_9 = var24_1.doFinal(v4.getBytes("ISO-8859-1"));
                            switch (v5) {
                                default: {
                                    ** continue;
                                }
                                ** case 0:
lbl54:
                                // 1 sources

                                ** continue;
                            }
                        }
                        Ambience.N = var31_3;
                        Ambience.O = new String[42];
                        Ambience.S = new HashMap<K, V>(13);
                        var11_10 = Cipher.getInstance("DES/CBC/NoPadding");
                        v7 = SecretKeyFactory.getInstance("DES");
                        v8 = new byte[8];
                        v9 = v8;
                        v8[0] = (byte)(var22 >>> 56);
                        for (var12_11 = 1; var12_11 < 8; ++var12_11) {
                            v9 = v9;
                            v9[var12_11] = (byte)(var22 << var12_11 * 8 >>> 56);
                        }
                        var11_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                        var17_12 = new long[34];
                        var14_13 = 0;
                        var15_14 = "1\u00f7,tey\u00ce\u00833\u00a9bn\u001dE\u0000\u00e7\u00e8\u0098\u0003\u00d3S\u00f1\u00c7\u00b3lB\u00a6`q^m\u0018\u00e0\u00e8B&\u001d\u00ae3e\u008c\u00dd\u00d2\u00ba\u00b6W\u00fa6\u00a5\u00acD\u00acZZ\u0091\u008d\u00bal?Q'\u008f\u0090\u00d2\u00b7\u00f3n\n\u00d2\u0084\u00a46Uv\u00ea\u008f{\u00e5*\u00a7\u0082\u00d2r\u00f5ST\u00f2w}^\u0005;~r\u00e3\u009dZ\u00cb\u00d5g\u000b!\u0088\u00a6j|\u00ccYk\u0097\u00bd\u00ef\u0088\u00d1\u00df:\u00depK\\\u0006\b\u00b0\u001f\u00da\u0085\u0095_\u00be\u0011\u00a6\u0080\u00e6\u0090\u001d\u0097\u00d7\fN\u008f\u0085,\u00ae\u0084\u00d9\u000b\u0019$\u00f3)\u00f1\u00f5\u0001\u00f7\u00a0\u0083\u00bc\u00c4\u00e6O\u00e9_5\u00e2\u001fC\u0010U^U\u00a5\u009d6JY\u00e1O@j\u00d3dh\u00ba,\u00fe\u00d9\u0018\u00f4\u00024\u00a4\u0096\u00b1\u0011\u00f9,#\u0011,M\\4\u0002\u001d\u0017\u00a3a\u0085.\u00ad5\u001c\u00b1\u00b7\u00b4K\u00c4\u00cf\u00d5\u00abR\u0092\u00b7_\u00f4\u001cN\u007f\u00ce\u00acD\u0011\u0001\u000f^\u0095\u0019\u0080\u00aec\u00b7\u0090l\u00a8\u009f\u00036\u0095\u00ee\u00ce\u0083\u00c2\u00b92\u0003u";
                        var16_15 = "1\u00f7,tey\u00ce\u00833\u00a9bn\u001dE\u0000\u00e7\u00e8\u0098\u0003\u00d3S\u00f1\u00c7\u00b3lB\u00a6`q^m\u0018\u00e0\u00e8B&\u001d\u00ae3e\u008c\u00dd\u00d2\u00ba\u00b6W\u00fa6\u00a5\u00acD\u00acZZ\u0091\u008d\u00bal?Q'\u008f\u0090\u00d2\u00b7\u00f3n\n\u00d2\u0084\u00a46Uv\u00ea\u008f{\u00e5*\u00a7\u0082\u00d2r\u00f5ST\u00f2w}^\u0005;~r\u00e3\u009dZ\u00cb\u00d5g\u000b!\u0088\u00a6j|\u00ccYk\u0097\u00bd\u00ef\u0088\u00d1\u00df:\u00depK\\\u0006\b\u00b0\u001f\u00da\u0085\u0095_\u00be\u0011\u00a6\u0080\u00e6\u0090\u001d\u0097\u00d7\fN\u008f\u0085,\u00ae\u0084\u00d9\u000b\u0019$\u00f3)\u00f1\u00f5\u0001\u00f7\u00a0\u0083\u00bc\u00c4\u00e6O\u00e9_5\u00e2\u001fC\u0010U^U\u00a5\u009d6JY\u00e1O@j\u00d3dh\u00ba,\u00fe\u00d9\u0018\u00f4\u00024\u00a4\u0096\u00b1\u0011\u00f9,#\u0011,M\\4\u0002\u001d\u0017\u00a3a\u0085.\u00ad5\u001c\u00b1\u00b7\u00b4K\u00c4\u00cf\u00d5\u00abR\u0092\u00b7_\u00f4\u001cN\u007f\u00ce\u00acD\u0011\u0001\u000f^\u0095\u0019\u0080\u00aec\u00b7\u0090l\u00a8\u009f\u00036\u0095\u00ee\u00ce\u0083\u00c2\u00b92\u0003u".length();
                        var13_16 = 0;
                        while (true) {
                            var18_17 = var15_14.substring(var13_16, var13_16 += 8).getBytes("ISO-8859-1");
                            v10 = var17_12;
                            v11 = var14_13++;
                            v12 = ((long)var18_17[0] & 255L) << 56 | ((long)var18_17[1] & 255L) << 48 | ((long)var18_17[2] & 255L) << 40 | ((long)var18_17[3] & 255L) << 32 | ((long)var18_17[4] & 255L) << 24 | ((long)var18_17[5] & 255L) << 16 | ((long)var18_17[6] & 255L) << 8 | (long)var18_17[7] & 255L;
                            v13 = -1;
                            break block28;
                            break;
                        }
lbl81:
                        // 1 sources

                        while (true) {
                            v10[v11] = v14;
                            if (var13_16 < var16_15) ** continue;
                            var15_14 = "ocl\u0093\u00cd\u00e7C1\u008c\u001a0\u00cd\u00c6\u0084\u00b2\u00cc";
                            var16_15 = "ocl\u0093\u00cd\u00e7C1\u008c\u001a0\u00cd\u00c6\u0084\u00b2\u00cc".length();
                            var13_16 = 0;
                            while (true) {
                                var18_17 = var15_14.substring(var13_16, var13_16 += 8).getBytes("ISO-8859-1");
                                v10 = var17_12;
                                v11 = var14_13++;
                                v12 = ((long)var18_17[0] & 255L) << 56 | ((long)var18_17[1] & 255L) << 48 | ((long)var18_17[2] & 255L) << 40 | ((long)var18_17[3] & 255L) << 32 | ((long)var18_17[4] & 255L) << 24 | ((long)var18_17[5] & 255L) << 16 | ((long)var18_17[6] & 255L) << 8 | (long)var18_17[7] & 255L;
                                v13 = 0;
                                break block28;
                                break;
                            }
                            break;
                        }
lbl94:
                        // 1 sources

                        while (true) {
                            v10[v11] = v14;
                            if (var13_16 < var16_15) ** continue;
                            break block29;
                            break;
                        }
                    }
                    var19_18 = v12;
                    var21_19 = var11_10.doFinal(new byte[]{(byte)(var19_18 >>> 56), (byte)(var19_18 >>> 48), (byte)(var19_18 >>> 40), (byte)(var19_18 >>> 32), (byte)(var19_18 >>> 24), (byte)(var19_18 >>> 16), (byte)(var19_18 >>> 8), (byte)var19_18});
                    v14 = ((long)var21_19[0] & 255L) << 56 | ((long)var21_19[1] & 255L) << 48 | ((long)var21_19[2] & 255L) << 40 | ((long)var21_19[3] & 255L) << 32 | ((long)var21_19[4] & 255L) << 24 | ((long)var21_19[5] & 255L) << 16 | ((long)var21_19[6] & 255L) << 8 | (long)var21_19[7] & 255L;
                    switch (v13) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl107:
                        // 1 sources

                        ** continue;
                    }
                }
                Ambience.Q = var17_12;
                Ambience.R = new Integer[34];
                Ambience.V = new HashMap<K, V>(13);
                var0_20 = Cipher.getInstance("DES/CBC/NoPadding");
                v15 = SecretKeyFactory.getInstance("DES");
                v16 = new byte[8];
                v17 = v16;
                v16[0] = (byte)(var22 >>> 56);
                for (var1_21 = 1; var1_21 < 8; ++var1_21) {
                    v17 = v17;
                    v17[var1_21] = (byte)(var22 << var1_21 * 8 >>> 56);
                }
                var0_20.init(2, (Key)v15.generateSecret(new DESKeySpec(v17)), new IvParameterSpec(new byte[8]));
                var6_22 = new long[9];
                var3_23 = 0;
                var4_24 = "i\u00b7\u00ab\u0096C\u00f3\u001c$V\u00da\u00b2\u00f8\u0007*C\u0005f\u00ef\u00c8\u001b\u00dfdUt#1\u00a6\u00d6\u00032\u00af\u00b4\u0090\u00f3c\u00ab\u00ced\u00f4\u00d4I\u00aa\u00a5/\u00eb:\u00ff\u001dH\u0011~n\u00b7\u008e\u00e7)";
                var5_25 = "i\u00b7\u00ab\u0096C\u00f3\u001c$V\u00da\u00b2\u00f8\u0007*C\u0005f\u00ef\u00c8\u001b\u00dfdUt#1\u00a6\u00d6\u00032\u00af\u00b4\u0090\u00f3c\u00ab\u00ced\u00f4\u00d4I\u00aa\u00a5/\u00eb:\u00ff\u001dH\u0011~n\u00b7\u008e\u00e7)".length();
                var2_26 = 0;
                while (true) {
                    var7_27 = var4_24.substring(var2_26, var2_26 += 8).getBytes("ISO-8859-1");
                    v18 = var6_22;
                    v19 = var3_23++;
                    v20 = ((long)var7_27[0] & 255L) << 56 | ((long)var7_27[1] & 255L) << 48 | ((long)var7_27[2] & 255L) << 40 | ((long)var7_27[3] & 255L) << 32 | ((long)var7_27[4] & 255L) << 24 | ((long)var7_27[5] & 255L) << 16 | ((long)var7_27[6] & 255L) << 8 | (long)var7_27[7] & 255L;
                    v21 = -1;
                    break block30;
                    break;
                }
lbl134:
                // 1 sources

                while (true) {
                    v18[v19] = v22;
                    if (var2_26 < var5_25) ** continue;
                    var4_24 = "\u00d8\u008a=\u0099\u000e\u00d2\u00eb\u00ec\u00acL\u009es\u00b7\u0001\u000e\u0098";
                    var5_25 = "\u00d8\u008a=\u0099\u000e\u00d2\u00eb\u00ec\u00acL\u009es\u00b7\u0001\u000e\u0098".length();
                    var2_26 = 0;
                    while (true) {
                        var7_27 = var4_24.substring(var2_26, var2_26 += 8).getBytes("ISO-8859-1");
                        v18 = var6_22;
                        v19 = var3_23++;
                        v20 = ((long)var7_27[0] & 255L) << 56 | ((long)var7_27[1] & 255L) << 48 | ((long)var7_27[2] & 255L) << 40 | ((long)var7_27[3] & 255L) << 32 | ((long)var7_27[4] & 255L) << 24 | ((long)var7_27[5] & 255L) << 16 | ((long)var7_27[6] & 255L) << 8 | (long)var7_27[7] & 255L;
                        v21 = 0;
                        break block30;
                        break;
                    }
                    break;
                }
lbl147:
                // 1 sources

                while (true) {
                    v18[v19] = v22;
                    if (var2_26 < var5_25) ** continue;
                    break block31;
                    break;
                }
            }
            var8_28 = v20;
            var10_29 = var0_20.doFinal(new byte[]{(byte)(var8_28 >>> 56), (byte)(var8_28 >>> 48), (byte)(var8_28 >>> 40), (byte)(var8_28 >>> 32), (byte)(var8_28 >>> 24), (byte)(var8_28 >>> 16), (byte)(var8_28 >>> 8), (byte)var8_28});
            v22 = ((long)var10_29[0] & 255L) << 56 | ((long)var10_29[1] & 255L) << 48 | ((long)var10_29[2] & 255L) << 40 | ((long)var10_29[3] & 255L) << 32 | ((long)var10_29[4] & 255L) << 24 | ((long)var10_29[5] & 255L) << 16 | ((long)var10_29[6] & 255L) << 8 | (long)var10_29[7] & 255L;
            switch (v21) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl160:
                // 1 sources

                ** continue;
            }
        }
        Ambience.T = var6_22;
        Ambience.U = new Long[9];
    }

    private static MatchException a(MatchException matchException) {
        return matchException;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static String b(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0xB06;
        if (O[n3] == null) {
            Object[] objectArray;
            try {
                Long l3 = Thread.currentThread().threadId();
                objectArray = (Object[])P.get(l3);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    P.put(l3, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/g/B", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l2 >>> 56);
            for (int i2 = 1; i2 < 8; ++i2) {
                byArray[i2] = (byte)(l2 << i2 * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = N[n3].getBytes("ISO-8859-1");
            Ambience.O[n3] = Ambience.b(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return O[n3];
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        String string2 = Ambience.b(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static CallSite b(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/B" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static long d(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x230;
        if (U[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = T[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])V.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    V.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/g/B", exception);
            }
            long l5 = ((long)byArray[0] & 0xFFL) << 56 | ((long)byArray[1] & 0xFFL) << 48 | ((long)byArray[2] & 0xFFL) << 40 | ((long)byArray[3] & 0xFFL) << 32 | ((long)byArray[4] & 0xFFL) << 24 | ((long)byArray[5] & 0xFFL) << 16 | ((long)byArray[6] & 0xFFL) << 8 | (long)byArray[7] & 0xFFL;
            Ambience.U[n3] = l5;
        }
        return U[n3];
    }

    private static long d(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        long l3 = Ambience.d(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Long.TYPE, l3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return l3;
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/B" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (X[n4] != null) {
            return n4;
        }
        Object object = W[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 3;
            case 1 -> 14;
            case 2 -> 59;
            case 3 -> 16;
            case 4 -> 31;
            case 5 -> 58;
            case 6 -> 45;
            case 7 -> 32;
            case 8 -> 53;
            case 9 -> 63;
            case 10 -> 47;
            case 11 -> 57;
            case 12 -> 11;
            case 13 -> 40;
            case 14 -> 1;
            case 15 -> 61;
            case 16 -> 35;
            case 17 -> 48;
            case 18 -> 24;
            case 19 -> 18;
            case 20 -> 62;
            case 21 -> 38;
            case 22 -> 0;
            case 23 -> 37;
            case 24 -> 27;
            case 25 -> 19;
            case 26 -> 5;
            case 27 -> 6;
            case 28 -> 36;
            case 29 -> 26;
            case 30 -> 21;
            case 31 -> 22;
            case 32 -> 52;
            case 33 -> 44;
            case 34 -> 46;
            case 35 -> 51;
            case 36 -> 4;
            case 37 -> 7;
            case 38 -> 12;
            case 39 -> 56;
            case 40 -> 49;
            case 41 -> 54;
            case 42 -> 29;
            case 43 -> 39;
            case 44 -> 60;
            case 45 -> 41;
            case 46 -> 42;
            case 47 -> 23;
            case 48 -> 33;
            case 49 -> 9;
            case 50 -> 28;
            case 51 -> 30;
            case 52 -> 50;
            case 53 -> 25;
            case 54 -> 13;
            case 55 -> 17;
            case 56 -> 15;
            case 57 -> 10;
            case 58 -> 34;
            case 59 -> 55;
            case 60 -> 2;
            case 61 -> 43;
            case 62 -> 8;
            default -> 20;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        Ambience.X[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = W;
        W[0] = "\nb\u007fv\u0005\u0007\u0001byv\u0005m";
        objectArray[1] = "b\r";
        objectArray[2] = "r\u0016\u000f\f6Iy\u0016\u0004";
        objectArray[3] = Boolean.TYPE;
        Ambience.X[3] = "java/lang/Boolean";
        objectArray[4] = "K\u0007ATU0@\u0007GTv";
        objectArray[5] = "\u0011m&\u0001\u000e8\u001ab7Nm5\u000fo8%X7\u001e|$\tO:";
        objectArray[6] = "6[&r\u0017<?[%r\u0015";
        objectArray[7] = "S;8!>kZ;;!>";
        objectArray[8] = "nYBF\u0019IeVS\txGn]WS";
        objectArray[9] = "\u0012:Q\u001eSm\u001b:R\u001eW";
        objectArray[10] = ". `r\u001d4358P\\9+3";
        objectArray[11] = ";4~6VS64z6V";
        objectArray[12] = "V$\u0004\u007f\u001f\u0004]+\u00150b\u001cN,\u001cy";
        objectArray[13] = "Ybx]d_Pb{]i";
        objectArray[14] = "\u0014_1\u001c\u000eAa\u007f:\u0013\u001f\u000e\u0000q1\u0018\u001bTt";
        objectArray[15] = "M2\u001d=zoF2\u001b=|";
        objectArray[16] = "*nfje5!n`jf";
        objectArray[17] = "\u0015[5\u0016ci\u001c[6\u0016o";
        objectArray[18] = "nd\u000ew?\u001c\u001bD\u0005x.SzJ\u000es*\t\u000e";
        objectArray[19] = "T\u001d@-p2_\u001dH";
        objectArray[20] = "$lem\u001cB/lcm\u0019";
        objectArray[21] = "=Q";
        objectArray[22] = "12x~h!:2~~o";
        objectArray[23] = "\u0018\u0007\u0019\u0017&n\u0011\u0007\u001a\u0017#";
        objectArray[24] = "k\u0014\u001993f`\u0014\u001f91";
        objectArray[25] = "8[";
        objectArray[26] = Void.TYPE;
        Ambience.X[26] = "java/lang/Void";
        objectArray[27] = "J,w~1\b?\f|q G^\u0002wz$\u001d*";
        objectArray[28] = "6\u0018*[pf=\u0018,[t";
        objectArray[29] = "f7M*4~\u0013\u0017F%%1r\u0019M.!k\u0006";
        objectArray[30] = Long.TYPE;
        Ambience.X[30] = "java/lang/Long";
        objectArray[31] = Float.TYPE;
        Ambience.X[31] = "java/lang/Float";
        objectArray[32] = "\u0002VpZf/wv{Uw`\u0016xp^s:b";
        objectArray[33] = "`\u001cQ,2>\u0015<Z##qt2Q('+\u0000";
        objectArray[34] = "=d";
        objectArray[35] = "^M*JWZ+m!EF\u0015Jc*NBO>";
        objectArray[36] = "qR";
        objectArray[37] = "\"lSW^\u001cWLXXOS6BSSK\tB";
        objectArray[38] = "|#";
        objectArray[39] = "p\\/r$\u0001r\u00055nD ]u\u0004JD\u0002}Z/p.\u0000$@3";
        objectArray[40] = "=\u0002\u0010&`T\u007f^WzYT\u0006EY.'@}\u0000Pwi=<[W.=PgPR1Y";
        objectArray[41] = "\u00142> \u001aFVny|#V/186XM\u001ft{!\u0019";
        objectArray[42] = "Zy@|1oZ:_&SXwFi\u00169gTjFg9$K0";
        objectArray[43] = "w\u001bRk\n65G\u001573\u0013L\u0018T}H=|]\u0017j\t";
        objectArray[44] = "\u0016\t#yJUTUd%sw-\\c~\u0014WUFhk\n";
        objectArray[45] = "\n:}\u0011Q\rHf:Mh&1? \u0000\r\u0000\\d+\u0005\u0012";
        objectArray[46] = "Ur\bbc}\u0017.O>ZjnsW2bd_<Li+";
        objectArray[47] = "\u001e\u0018L+Ih\u001e[Sq+^*,r\u001bjU9aB8Os\u0016\u0010B{P)";
        objectArray[48] = "$RJpIH&\u0017PhqB\u0019\u0016A|\u000fVbSH%A+$RJpIH&\u0017Phq";
        objectArray[49] = "Ze\u0011\u0015MHX \u000b\ruBgd\u0019\u0011\u0013T\u0000'V\u001aE+";
        objectArray[50] = "%[\u0000\b<8g\u0007GT\u0005?\u001e^]\u0019`5s\u0005V\u001c\u007fQ";
        objectArray[51] = "t\tqtg#}\u0001n!\u0002&M\u0018ozc,r\u0015\u007f*eL";
        objectArray[52] = "y\u0010GaDl6\u000b\u001c(44GK\u0018`[ 9\u000b\u001faI]";
        objectArray[53] = " 4?r\"Wbhx.\u001b~\u001b5`\"#N*z{yj";
        objectArray[54] = "Q\u001773k1\u0013KpoR1j\u0013p176\u0006Di#4XQTc;<4\u0006Mq8R";
        objectArray[55] = "1\nb\u0006*\u000esV%Z\u0013\u0017\n_\"\u0001t\frE)\u0014j";
        objectArray[56] = "csJ\"{m!/\r~BxX#\u001b52e>}\u0003u#";
        objectArray[57] = "\n5 aYG\nu)fcr#P\b\\cWSo>&\u0013W\u0013f9";
        objectArray[58] = "\u0002(GrA@@t\u0000.xc9}\u0007u\u001fBAg\f`\u0001";
        objectArray[59] = "\u0000$<?\u0005xBx{c<l;%co\u0004a\njx4M";
        objectArray[60] = "t\u0010f\u001b\u001bZ6L!G\"TO\u001e3IRC/PcJA";
        objectArray[61] = "a\u0017E\u007f\u007fG<\u000eFw\u0005pY$dBYs\u0003\u000bAuuRlVXv}";
        objectArray[62] = "xkygi\u0015:7>;P\u0004C>9`7\u0017;$2u)";
        objectArray[63] = "\f\u0003\u000b'-SN_L{\u0014y7XL7{T^\u0005Azf";
        objectArray[64] = "\u007fN6v,P=\u0012q*\u0015SD\t\u007f~kD?Lv'%9>I5po^y\u001fg~\u0015";
        objectArray[65] = "U\f}C_`\u0000\u001b$T/q\u0003\u0013aShajGaAMc\u0000Md@\u0010\u000fU\f}C_`\u0000\u001b$T/";
        objectArray[66] = "RMX[+0\u0010\u0011\u001f\u0007\u0012\u0016iC\r\tb)\t\r]\nq";
        objectArray[67] = "?,st\u001bOb5p|ak\u0000\tUC$ ?,st\u001bOb5p|";
        objectArray[68] = ":qWPC\u0015of\u000eG3<H@kizz:qWPC\u0015of\u000eG";
        objectArray[69] = "K]o^\r\u0019\t\u0001(\u000249pS:\fD\u0000\u0010\u001dj\u000fW";
        objectArray[70] = "\tzL-J\u0014K&\u000bqs\u00172=\u0005%\r\u0000Ix\f|C}V/\t&\r\u0003\r)\u000f2s";
        objectArray[71] = "a\u000fo\u001c:A#S(@\u0003NZ\u0001:NsX:OjM`";
        objectArray[72] = "'\u0018V-<NeD\u0011q\u0005N\u001c_\u001f%{Zg\u001a\u0016|5'xM\u0013&{Y#K\u00152\u0005";
        objectArray[73] = "[zUkf\u0012\u0019&\u00127_6`/\u0015l8\u0010\u00185\u001ey&";
        objectArray[74] = "x${-+\u001a:x<q\u0012\u001cC\u007f*>t\r=$,8`sy}<%v\u001e\"v9:\u0012";
        objectArray[75] = "\u0019ti]\u0019\u0016DvtRe/8UHq?u\u0019ti]\u0019\u0016DvtR";
        objectArray[76] = "\u0012RE \u0002\u0006P\u000e\u0002|;!)QC6@\r\u0019\u0014\u0000!\u0001";
        objectArray[77] = "\u001a12/[.Xmusb.!v{'\u001c:Z3r~RG[61)\u0018 \u001c`c'b";
        objectArray[78] = "sUL&J.1\t\u000bzs\u0006H\u0000\f!\u0014,0\u001a\u00074\n";
        objectArray[79] = "*6\u0019ltohj^0MB\u0011m^|\"hx0S1?";
        objectArray[80] = "\u0017o:|\u0012B\u0002+f{#\u007f4\u001d\n,\u001f\bGbp9[T@";
        objectArray[81] = "#c\u0011y?\u0015a?V%\u0006\u0017\u0018$Xqx\u0001caQ(6|bd\u0012\u007f|\u001b%2@q\u0006";
        objectArray[82] = "\u0007VKU4l\u0012W\u001d';\u0010\tGBF1/\u0004W\u0012@Q";
        objectArray[83] = ",cuf\u000e;n?2:7-\u0017b*6\u000f\"&-1mF";
        objectArray[84] = "\u001db~T\u000bm\u001a:&\nv\u00122I\u000f1v:\u00177v\u0010O=Oo(";
        objectArray[85] = ">^zcMv7Ve6(u\u0007\u0015c!M}jNh$R\u0019";
        objectArray[86] = "E\u0000x@0\u0013\u0007\\?\u001c\t\u000b~U8Gn\u0011\u0006O3Rp";
        objectArray[87] = "\u000fZQ\u0013\u001dnM\u0006\u0016O$u4\u000f\u0011\u0014ClL\u0015\u001a\u0001]";
        objectArray[88] = "[\u0016</c\u007f\u0019J{sZm`\u0018i}*f\u0000V9~9";
        objectArray[89] = "[n}Q\u0016k\u00192:\r/x``(\u0003_r\u0000.x\u0000L";
        objectArray[90] = "\u000b\u0017\u0006\u0018\u0013\u0017IKAD*\u001b0\u0014\u0000\u000eQ\u001c\u0000QC\u0019\u0010";
        objectArray[91] = "a\u0006X\f\u0005|t\u0007\u000e~\n\u0000o\u0017Q\u001f\u0000?b\u0007\u0001\u0019`a?\u0011\u0006O\fxo\u0011^~";
        Object[] objectArray2 = objectArray;
        objectArray[92] = "\u0012W44.F\u001b_+aKM+^9o5TP\u001b06{)J\u0016,mzESF,5K";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = Ambience.e(l2, l3);
            object = W[n2];
            try {
                if (!(object instanceof String)) break block2;
                Ambience.W[n2] = clazz = Class.forName(X[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = Ambience.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = Ambience.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = Ambience.e(l2, l3);
        Object object = W[n2];
        if (object instanceof String) {
            String string = X[n2];
            int n3 = string.indexOf(8);
            Class clazz = Ambience.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = Ambience.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = Ambience.c(clazz3, string2, clazz2)) != null) {
                    Ambience.W[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = Ambience.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        Ambience.W[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = Ambience.f(604866661170020L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = Ambience.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = Ambience.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = Ambience.e(l2, l3);
        Object object = W[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = X[n2];
                int n4 = string2.indexOf(8);
                clazz3 = Ambience.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = Ambience.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = Ambience.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        Ambience.W[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = Ambience.f(604866661170020L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = Ambience.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        Ambience.W[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = Ambience.f(604866661170020L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == '\u00cb' || c2 == '\u00c0' || c2 == '\u00d2' || c2 == 'I') {
                field = Ambience.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == '\u00cb' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == '\u00c0' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == '\u00d2' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = Ambience.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == 'h' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == 'o' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = Ambience.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite f(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_2().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/B" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Ambience.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(Ambience.class, "d", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_2() {
        try {
            return MethodHandles.lookup().findStatic(Ambience.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

