// === Kuzi module: Waypoints ===
// Category   : RENDER
// Description: Mark spots (traps/pressure plates) with a box, beam and label.
// Payload    : a.a.a.j.g.ao (verified: True)

package kuzi.modules.render;

import a.a.a.j.g.a;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.awt.Color;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.Reader;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.core.Client;
import kuzi.mixin.MixinExposed;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.module.Module;
import kuzi.obf.h.Y;
import kuzi.obf.h.b.e;
import kuzi.obf.h.b.v;
import kuzi.obf.j.g.aD;
import kuzi.obf.p.L;
import kuzi.obf.p.ac_0;
import kuzi.settings.BoolSetting;
import kuzi.settings.ButtonSetting;
import kuzi.settings.KeyBinding;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.BlockPos;
import net.minecraft.HitResult;
import net.minecraft.Vec3;
import net.minecraft.Minecraft;
import net.minecraft.Font;
import net.minecraft.GuiGraphics;
import net.minecraft.BlockHitResult;
import net.minecraft.Screen;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class Waypoints
extends BaseModule
implements Module {
    private final KeyBinding addKey;
    private final KeyBinding clearKey;
    private final BoolSetting box;
    private final BoolSetting beam;
    private final SliderSetting beamHeight;
    private final BoolSetting fill2;
    private final SliderSetting fillOpacity;
    private final BoolSetting label;
    private final BoolSetting distance;
    private final e color;
    private final ButtonSetting editWaypoints;
    private static final Gson GSON;
    private final List waypoints;
    private boolean addKeyDown;
    private boolean clearKeyDown;
    private int nextWaypointNumber;
    private static final long C;
    private static final String[] D;
    private static final String[] E;
    private static final Map F;
    private static final long[] G;
    private static final Integer[] H;
    private static final Map I;
    private static final Object[] J;
    private static final String[] K;

    public Waypoints() {
        long l2;
        long l3 = l2 = C ^ 0x4C78EAC58A0AL;
        long l4 = l3 ^ 0x5F29BCDA1E15L;
        long l5 = l3 ^ 0x4D0CB3F4346EL;
        long l6 = l3 ^ 0x7B08C78F0B14L;
        long l7 = l3 ^ 0x2DDCE541B910L;
        long l8 = l7 >>> 16;
        int n2 = (int)(l7 << 48 >>> 48);
        super("Waypoints", "Mark spots (traps/pressure plates) with a box, beam and label.", Category.RENDER);
        this.addKey = new KeyBinding("Add Key", -1);
        this.clearKey = new KeyBinding("Clear Key", -1);
        this.box = new BoolSetting("Box", true);
        this.beam = new BoolSetting("Beam", true);
        this.beamHeight = new SliderSetting("Beam Height", 24.0, 2.0, 128.0, 1.0);
        this.fill2 = new BoolSetting("Fill", true);
        this.fillOpacity = new SliderSetting("Fill Opacity", 60.0, 0.0, 255.0, 5.0);
        this.label = new BoolSetting("Label", true);
        this.distance = new BoolSetting("Distance", true);
        this.color = new e("Color", new Color(120, 200, 255));
        this.editWaypoints = new ButtonSetting("Edit Waypoints", () -> this.a(l5));
        this.waypoints = new ArrayList();
        this.nextWaypointNumber = 1;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.addKey, this.clearKey, this.box, this.beam, this.beamHeight, this.fill2, this.fillOpacity, this.label, this.distance, this.color, this.editWaypoints};
        objectArray[0] = l6;
        this.l(objectArray);
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l4;
        this.m(objectArray2);
        WorldRenderEvents.END_MAIN.register(arg_0 -> this.a(l8, (short)n2, arg_0));
    }

    private void a(long l2) {
        block5: {
            Minecraft mc;
            Minecraft mcSnapshot;
            block4: {
                l2 = C ^ l2;
                int[] nArray = aD.b();
                Minecraft mcOrInstance = BaseModule.a;
                if (nArray != null) {
                    mcOrInstance = mcOrInstance != null ? BaseModule.a : Minecraft.getInstance();
                }
                mc = mcSnapshot = mcOrInstance;
                if (nArray == null) break block4;
                if (mc == null) break block5;
                mc = mcSnapshot;
            }
            mc.execute(() -> Waypoints.lambda$openEditor$0(mcSnapshot));
        }
    }

    public List b(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = C ^ l2;
        return this.waypoints;
    }

    public int a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = C ^ l2;
        return ((Color)((Object)Waypoints.d("\u00c9", (Object)Waypoints.d("$", (Object)this, (long)5859714745254680035L, (long)l2), (long)5858681948731145520L, (long)l2))).getRGB() & Waypoints.c("v", (int)28846, (long)(0x244246927DC9F5A7L ^ l2));
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    public aD a(Object[] var1_1) {
        block3: {
            var2_2 = (Long)var1_1[0];
            var4_3 = (var2_2 = Waypoints.C ^ var2_2) ^ 110127688494974L;
            var6_4 = aD.b();
            waypointList = this.waypoints;
            if (var6_4 != null && waypointList.size() >= Waypoints.c("v", (int)11016, (long)(6594193413469419640L ^ var2_2))) {
                waypointList = this.waypoints.remove(0);
            }
            v1 = BaseModule.a;
            if (var2_2 < 0L || var6_4 == null) break block3;
            if (v1 == null) ** GOTO lbl-1000
            v1 = BaseModule.a;
        }
        v2 = v1.player;
        if (var6_4 == null) ** GOTO lbl18
        if (v2 != null) {
            v2 = BaseModule.a.player;
lbl18:
            // 2 sources

            v3 = v2.blockPosition();
        } else lbl-1000:
        // 2 sources

        {
            v3 = new BlockPos(0, 0, 0);
        }
        pos = v3;
        waypoint = new aD(pos, (String)Waypoints.b("p", (int)30860, (long)(246336350383605533L ^ var2_2)) + this.nextWaypointNumber++);
        this.waypoints.add(waypoint);
        v4 = new Object[1];
        v4[0] = var4_3;
        this.f(v4);
        return waypoint;
    }

    @Override
    public void d() {
        Client.a().a(Module.class, this);
        super.d();
    }

    @Override
    public void e() {
        Client.a().b(Module.class, this);
        super.e();
    }

    @Override
    public void b() {
        block16: {
            boolean clearKeyPressed;
            block18: {
                Waypoints waypoints;
                block17: {
                    int[] nArray;
                    long l2;
                    block14: {
                        boolean flag;
                        boolean addKeyPressed;
                        long l3;
                        block15: {
                            long l4;
                            block13: {
                                block12: {
                                    Minecraft mc;
                                    block11: {
                                        long l5;
                                        long l6 = l5 = C ^ 0xEFDC1DAC2CFL;
                                        l2 = l6 ^ 0x6588AAECB096L;
                                        l3 = l6 ^ 0x2AED8F7DFB4AL;
                                        l4 = l6 ^ 0x55EE045A50C2L;
                                        nArray = aD.b();
                                        mc = BaseModule.a;
                                        if (nArray == null) break block11;
                                        if (mc.player == null) break block12;
                                        mc = BaseModule.a;
                                    }
                                    if (mc.level != null) break block13;
                                }
                                return;
                            }
                            Object[] objectArray = new Object[2];
                            objectArray[1] = l3;
                            objectArray[0] = this.addKey;
                            flag = addKeyPressed = this.a(objectArray);
                            if (nArray == null) break block14;
                            if (!flag) break block15;
                            flag = this.addKeyDown;
                            if (nArray == null) break block14;
                            if (!flag) {
                                Object[] objectArray2 = new Object[1];
                                objectArray2[0] = l4;
                                this.c(objectArray2);
                                Object[] objectArray3 = new Object[1];
                                objectArray3[0] = l2;
                                this.f(objectArray3);
                            }
                        }
                        this.addKeyDown = addKeyPressed;
                        Object[] objectArray = new Object[2];
                        objectArray[1] = l3;
                        objectArray[0] = this.clearKey;
                        flag = clearKeyPressed = this.a(objectArray);
                    }
                    if (nArray == null) break block16;
                    if (!clearKeyPressed) break block17;
                    waypoints = this;
                    if (nArray == null) break block18;
                    if (!waypoints.clearKeyDown) {
                        this.waypoints.clear();
                        Object[] objectArray = new Object[1];
                        objectArray[0] = l2;
                        this.f(objectArray);
                    }
                }
                waypoints = this;
            }
            waypoints.clearKeyDown = clearKeyPressed;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean a(Object[] objectArray) {
        KeyBinding keyBinding = (KeyBinding)objectArray[0];
        long l2 = (Long)objectArray[1];
        long l3 = (l2 = C ^ l2) ^ 0x4CA2DB5DC75FL;
        int keyCode = (Integer)keyBinding.a();
        int[] nArray = aD.b();
        if (keyCode <= 0) return false;
        if (BaseModule.a.screen != null) return false;
        Object[] objectArray2 = new Object[2];
        objectArray2[1] = l3;
        objectArray2[0] = keyCode;
        boolean pressed = L.a(objectArray2);
        if (nArray == null) return pressed;
        if (!pressed) return false;
        return true;
    }

    private void c(Object[] objectArray) {
        int[] nArray;
        int n2;
        BlockPos targetPos;
        long l2;
        block10: {
            int[] nArray2;
            block11: {
                Object entry;
                Object waypoint;
                long l3;
                block16: {
                    BlockPos pos;
                    block15: {
                        block13: {
                            BlockHitResult hitResult;
                            block14: {
                                HitResult hit;
                                block12: {
                                    l2 = (Long)objectArray[0];
                                    l3 = (l2 = C ^ l2) ^ 0x78DB4F81EDE5L;
                                    waypoint = BaseModule.a.hitResult;
                                    nArray2 = aD.b();
                                    hit = waypoint;
                                    if (nArray2 == null) break block12;
                                    if (!(hit instanceof BlockHitResult)) break block13;
                                    hit = waypoint;
                                }
                                BlockHitResult blockHit = (BlockHitResult)hit;
                                hitResult = blockHit;
                                if (nArray2 == null) break block14;
                                if (hitResult.getType() != HitResult.mc240.BLOCK) break block13;
                                hitResult = blockHit;
                            }
                            pos = hitResult.getBlockPos();
                            if (l2 <= 0L) break block15;
                            targetPos = pos;
                            if (nArray2 != null) break block16;
                        }
                        pos = BaseModule.a.player.blockPosition();
                    }
                    targetPos = pos;
                }
                block0: for (Object candidate : this.waypoints) {
                    do {
                        waypoint = (aD)candidate;
                        Object[] objectArray2 = new Object[1];
                        objectArray2[0] = l3;
                        n2 = ((aD)waypoint).a(objectArray2).equals((Object)targetPos) ? 1 : 0;
                        nArray = nArray2;
                        if (l2 < 0L) break block10;
                        if (nArray != null) {
                            if (n2 != 0) {
                                return;
                            }
                            if (nArray2 != null) continue block0;
                        }
                        break block11;
                        entry = this.waypoints;
                    } while (l2 < 0L);
                }
                n2 = entry.size();
            }
            nArray = nArray2;
        }
        if (nArray != null) {
            if (n2 >= Waypoints.c("v", (int)12659, (long)(0x59B418A9C1DFF72AL ^ l2))) {
                this.waypoints.remove(0);
            }
            n2 = this.waypoints.add(new aD(targetPos, (String)((Object)Waypoints.b("p", (int)30860, (long)(0x36B6B4792A0D23CL ^ l2))) + this.nextWaypointNumber++)) ? 1 : 0;
        }
    }

    /*
     * Exception decompiling
     */
    private void a(long var1_1, short var3_2, WorldRenderContext var4_3) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Statement already marked as first in another block
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.markFirstStatementInBlock(Op03SimpleStatement.java:461)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc.markWholeBlock(Misc.java:251)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.considerAsSimpleIf(ConditionalRewriter.java:673)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.identifyNonjumpingConditionals(ConditionalRewriter.java:56)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:722)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    @MixinExposed
    public void a(GuiGraphics graphics, float f2) {
        Minecraft mc;
        Minecraft mcSnapshot;
        int[] nArray;
        long l2;
        block16: {
            block17: {
                block15: {
                    block14: {
                        block13: {
                            block11: {
                                boolean shouldRender;
                                block12: {
                                    block10: {
                                        long l3 = C ^ 0x216DF2836B0L;
                                        l2 = l3 ^ 0x1A826F97CC70L;
                                        nArray = aD.b();
                                        shouldRender = this.d();
                                        if (nArray == null) break block10;
                                        if (!shouldRender) break block11;
                                        shouldRender = (Boolean)this.label.a();
                                    }
                                    if (nArray == null) break block12;
                                    if (!shouldRender) break block11;
                                    shouldRender = this.waypoints.isEmpty();
                                }
                                if (!shouldRender) break block13;
                            }
                            return;
                        }
                        mc = mcSnapshot = Minecraft.getInstance();
                        if (nArray == null) break block14;
                        if (mc.level == null) break block15;
                        mc = mcSnapshot;
                    }
                    if (nArray == null) break block16;
                    if (mc.player != null) break block17;
                }
                return;
            }
            mc = mcSnapshot;
        }
        Font font = mc.font;
        int baseColor = this.color.a().getRGB() & 0xFFFFFF;
        for (aD waypoint : this.waypoints) {
            int n3;
            int waypointColor = waypoint.e;
            if (nArray != null) {
                waypointColor = waypointColor != 0 ? waypoint.e : baseColor;
            }
            int textColor = 0xFF000000 | waypointColor & 0xFFFFFF;
            Vec3 labelPos = new Vec3((double)waypoint.a + 0.5, (double)waypoint.b + 1.3, (double)waypoint.c + 0.5);
            Object[] objectArray = new Object[2];
            objectArray[1] = l2;
            objectArray[0] = labelPos;
            float[] fArray = ac_0.a(objectArray);
            if (fArray == null) continue;
            Object labelText = waypoint.d;
            int n6 = ((Boolean)this.distance.a()).booleanValue();
            if (nArray != null) {
                if (n6 != 0) {
                    n3 = (int)Math.round(Math.sqrt(mcSnapshot.player.distanceToSqr(labelPos)));
                    labelText = (String)labelText + "  " + n3 + "m";
                }
                n6 = font.width((String)labelText);
            }
            n3 = n6;
            graphics.pose().pushMatrix();
            graphics.pose().translate(fArray[0], fArray[1]);
            int boxLeft = -n3 / 2 - 2;
            int boxRight = n3 / 2 + 2;
            Objects.requireNonNull(font);
            graphics.fill(boxLeft, -1, boxRight, 9 + 1, -1728053248);
            graphics.drawString(font, (String)labelText, -n3 / 2, 0, textColor, false);
            graphics.pose().popMatrix();
            if (nArray != null) continue;
        }
    }

    public void f(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = (l2 = C ^ l2) ^ 0x6784A48D72C1L;
        int[] nArray = aD.b();
        try {
            File file;
            block14: {
                File file2;
                block13: {
                    File file3;
                    block11: {
                        block12: {
                            Object[] objectArray2 = new Object[1];
                            objectArray2[0] = l3;
                            file = this.a(objectArray2);
                            try {
                                file3 = file;
                                if (nArray == null) break block11;
                                if (file3 != null) break block12;
                            }
                            catch (Throwable throwable) {
                                throw Waypoints.a(throwable);
                            }
                            return;
                        }
                        file3 = file.getParentFile();
                    }
                    File file4 = file3;
                    try {
                        file2 = file4;
                        if (nArray == null) break block13;
                        if (file2 == null) break block14;
                    }
                    catch (Throwable throwable) {
                        throw Waypoints.a(throwable);
                    }
                    file2 = file4;
                }
                file2.mkdirs();
            }
            try (FileWriter fileWriter = new FileWriter(file);){
                GSON.toJson((Object)this.waypoints, (Appendable)fileWriter);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    /*
     * Unable to fully structure code
     */
    public final void m(Object[] var1_1) {
        block27: {
            var2_2 = (Long)var1_1[0];
            var4_3 = (var2_2 = Waypoints.C ^ var2_2) ^ 34774632928391L;
            var6_4 = aD.b();
            try {
                block32: {
                    block26: {
                        block25: {
                            v0 = new Object[1];
                            v0[0] = var4_3;
                            var7_5 = this.a(v0);
                            try {
                                v1 = var7_5;
                                if (var6_4 == null) break block25;
                                if (v1 == null) break block26;
                            }
                            catch (Throwable v2) {
                                throw Waypoints.a(v2);
                            }
                            v1 = var7_5;
                        }
                        if (v1.exists()) break block32;
                    }
                    return;
                }
                var8_7 = new FileReader(var7_5);
                try {
                    var9_8 = new a(this).getType();
                    var10_10 = (List)Waypoints.GSON.fromJson((Reader)var8_7, var9_8);
                    try {
                        v3 = this.waypoints;
                        if (var2_2 > 0L) {
                            v3.clear();
                            if (var6_4 == null) break block27;
                            v3 = var10_10;
                        }
                        if (v3 == null) break block27;
                    }
                    catch (Throwable v4) {
                        throw Waypoints.a(v4);
                    }
                    var11_12 = var10_10.iterator();
                    block19: while (true) {
                        v5 = var11_12.hasNext();
                        while (v5) {
                            block31: {
                                block30: {
                                    block28: {
                                        block29: {
                                            var12_13 = (aD)var11_12.next();
                                            if (var2_2 <= 0L || var6_4 == null) break block27;
                                            try {
                                                block33: {
                                                    v6 = var12_13;
                                                    v7 = var6_4;
                                                    if (var2_2 < 0L) ** GOTO lbl64
                                                    if (v7 == null) break block28;
                                                    break block33;
                                                    catch (Throwable v8) {
                                                        throw Waypoints.a(v8);
                                                    }
                                                }
                                                if (v6 != null) break block29;
                                            }
                                            catch (Throwable v9) {
                                                throw Waypoints.a(v9);
                                            }
                                            if (var2_2 >= 0L) continue block19;
                                        }
                                        v6 = var12_13;
                                    }
                                    v7 = var6_4;
lbl64:
                                    // 2 sources

                                    if (v7 == null) break block30;
                                    try {
                                        block34: {
                                            if (v6.d != null) break block31;
                                            break block34;
                                            catch (Throwable v10) {
                                                throw Waypoints.a(v10);
                                            }
                                        }
                                        v6 = var12_13;
                                    }
                                    catch (Throwable v11) {
                                        throw Waypoints.a(v11);
                                    }
                                }
                                v6.d = Waypoints.b("p", (int)5602, (long)(265161402140899656L ^ var2_2));
                            }
                            v5 = this.waypoints.add(var12_13);
                            if (var2_2 <= 0L) continue;
                            this.nextWaypointNumber = Math.max(this.nextWaypointNumber, this.waypoints.size() + 1);
                            if (var6_4 == null) break block19;
                            continue block19;
                        }
                        break block27;
                        break;
                    }
                    {
                        break block27;
                        break;
                    }
                }
                finally {
                    var8_7.close();
                }
            }
            catch (Exception var7_6) {
                // empty catch block
            }
        }
    }

    private File a(Object[] objectArray) {
        File file;
        block6: {
            Minecraft mc3102;
            long l2;
            block7: {
                block5: {
                    Minecraft MonsterRoomFeature;
                    int[] nArray;
                    block4: {
                        l2 = (Long)objectArray[0];
                        l2 = C ^ l2;
                        nArray = aD.b();
                        Minecraft SaveAllCommand = BaseModule.a;
                        if (nArray != null) {
                            SaveAllCommand = SaveAllCommand != null ? BaseModule.a : Minecraft.getInstance();
                        }
                        MonsterRoomFeature = mc3102 = SaveAllCommand;
                        if (l2 <= 0L || nArray == null) break block4;
                        if (MonsterRoomFeature == null) break block5;
                        MonsterRoomFeature = mc3102;
                    }
                    file = MonsterRoomFeature.gameDirectory;
                    if (nArray == null) break block6;
                    if (file != null) break block7;
                }
                return null;
            }
            file = new File(mc3102.gameDirectory, (String)((Object)Waypoints.b("p", (int)15142, (long)(0x14D2244B08A61901L ^ l2))));
        }
        return file;
    }

    private static void lambda$openEditor$0(Minecraft mc3102) {
        mc3102.setScreen((Screen)new Y());
    }

    /*
     * Unable to fully structure code
     */
    static {
        block21: {
            block20: {
                block19: {
                    block18: {
                        Waypoints.C = kuzi.obf.h.b.v.a(-467339491829822338L, -2336456431135377069L, MethodHandles.lookup().lookupClass()).a(61252015702347L);
                        Waypoints.J = new Object[79];
                        Waypoints.K = new String[79];
                        Waypoints.c();
                        Waypoints.F = new HashMap<K, V>(13);
                        var11 = Waypoints.C ^ 140440893371731L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[17];
                        var18_4 = 0;
                        var17_5 = "\u00d2\u00df\u0007w\u00a6\u0016\u00dcK\u00fc\u009e\u00dc\u00e5u\u00a1\u00ea\u00eb\u0018\u00a0f\u0080O/B\u0095\u00d8Ez\u0014sIc\u0091\u00f3}\u00d7\u000blA\u0005u\u00f7\u0010\u00bb;\u00b6\u00d6>\u00d5H\u00de{\u00f8Q\u00df\u00f3\u00e0\u00f7\u00f6(v\u00c6g \u009c\u00fb\u00e9\u00b9W>;g\u00f2tU\u009c\u0017^I\u009f\u00b9A@S6T;\u00bb\u0003\u000b\u00fb\u00e7{@h`\u0080\u0016d\u0012\u0018\u00e5 \u001a\u0083\u001fK>,\u00f9\u00d1\u008d\u00a7\u00c7?\u00d5L\u009d\u0012w\u00f4V\u00e7u\u0097\u0010]\u0012\u00da8\u0083\u0010\u001c\u00ce79h\u000e*\u00b3\u0002W\u0018\u00ee\u0003\u00bd\u00f9/\u0010T\f\u00c5S\u00fb\u00f7\u00b7\u0002g\u00e1\u00ee0R1\u001bB\u00d3b\u0018\u00fc\u00a7\u00ef\u00f1\u00fb\u00d0\u00ac\u00bd\u00b5\u00bcT:\u00acX\u0080r$O\u0018\u0083m$\u001f{\u0010sQ/o\u00f3\u00df\\1t.<Z\u00e2r\u0086\u00b5\u0010\u00e2\u009d0D\u00e9\u00d9)\u00f9\u00df\u00fd\u00fe\u0083\u00a5\u008b\u00bb\u00e8\u0010\u0019\u00b7\u00a4\u0014K\u001bB\u00140\u007f\u001c\u00fc\u00f8\\\u00a5/h.yW\u00b4\u0092\u00d8G\u00e9\u00e5\u009dTHd\u00aa\u00e3\u001d\u0003!\u00ce\u00eb\u00cb\u0086\u00f1\u00f7\u00b0\u00c9+\u008d\u00808fkb\u008c7B_\u009eL\u00ae\u00d2\u00afHgP\u00a0\u00ddY\u00a6\u0093 A\u00f6\u008d\u00f9V\u00b1y\u00cf\u0092\u00f6\u00f2]\u00da\u00fa\u00ed\u00b0h\u0006\u00faD\u0092e?\u00cf\u0097\u00d6N'b4>r\u0004\u00a3FY\u00del:)T&\u0005dYo\f\u00a2[\u00a8\u00ff=!\u0010\u00ff\u00ac\u00feD\rc\u00e9\u00ef\u00a5kr`\u0017\u00b8\u00eb\u00a8\u0018\u00a6\u00a5\u00b36i\u009d.\u00db\u00d4\u00d3\u0019\u00a7K\u000f\u00c7\u00f3\u00ad\u00d4\b\u00e3\u00e8\u00e7G\u00b1 \u00b7E8^W\u00d37[\u0005\u00cf\u0005\u00b3!(\u00e8\u00d2\u00f9;Y\u00b1\u00c5\u009b\u00a0\u0089ti\u0098\u0003JV'\u00f1";
                        var19_6 = "\u00d2\u00df\u0007w\u00a6\u0016\u00dcK\u00fc\u009e\u00dc\u00e5u\u00a1\u00ea\u00eb\u0018\u00a0f\u0080O/B\u0095\u00d8Ez\u0014sIc\u0091\u00f3}\u00d7\u000blA\u0005u\u00f7\u0010\u00bb;\u00b6\u00d6>\u00d5H\u00de{\u00f8Q\u00df\u00f3\u00e0\u00f7\u00f6(v\u00c6g \u009c\u00fb\u00e9\u00b9W>;g\u00f2tU\u009c\u0017^I\u009f\u00b9A@S6T;\u00bb\u0003\u000b\u00fb\u00e7{@h`\u0080\u0016d\u0012\u0018\u00e5 \u001a\u0083\u001fK>,\u00f9\u00d1\u008d\u00a7\u00c7?\u00d5L\u009d\u0012w\u00f4V\u00e7u\u0097\u0010]\u0012\u00da8\u0083\u0010\u001c\u00ce79h\u000e*\u00b3\u0002W\u0018\u00ee\u0003\u00bd\u00f9/\u0010T\f\u00c5S\u00fb\u00f7\u00b7\u0002g\u00e1\u00ee0R1\u001bB\u00d3b\u0018\u00fc\u00a7\u00ef\u00f1\u00fb\u00d0\u00ac\u00bd\u00b5\u00bcT:\u00acX\u0080r$O\u0018\u0083m$\u001f{\u0010sQ/o\u00f3\u00df\\1t.<Z\u00e2r\u0086\u00b5\u0010\u00e2\u009d0D\u00e9\u00d9)\u00f9\u00df\u00fd\u00fe\u0083\u00a5\u008b\u00bb\u00e8\u0010\u0019\u00b7\u00a4\u0014K\u001bB\u00140\u007f\u001c\u00fc\u00f8\\\u00a5/h.yW\u00b4\u0092\u00d8G\u00e9\u00e5\u009dTHd\u00aa\u00e3\u001d\u0003!\u00ce\u00eb\u00cb\u0086\u00f1\u00f7\u00b0\u00c9+\u008d\u00808fkb\u008c7B_\u009eL\u00ae\u00d2\u00afHgP\u00a0\u00ddY\u00a6\u0093 A\u00f6\u008d\u00f9V\u00b1y\u00cf\u0092\u00f6\u00f2]\u00da\u00fa\u00ed\u00b0h\u0006\u00faD\u0092e?\u00cf\u0097\u00d6N'b4>r\u0004\u00a3FY\u00del:)T&\u0005dYo\f\u00a2[\u00a8\u00ff=!\u0010\u00ff\u00ac\u00feD\rc\u00e9\u00ef\u00a5kr`\u0017\u00b8\u00eb\u00a8\u0018\u00a6\u00a5\u00b36i\u009d.\u00db\u00d4\u00d3\u0019\u00a7K\u000f\u00c7\u00f3\u00ad\u00d4\b\u00e3\u00e8\u00e7G\u00b1 \u00b7E8^W\u00d37[\u0005\u00cf\u0005\u00b3!(\u00e8\u00d2\u00f9;Y\u00b1\u00c5\u009b\u00a0\u0089ti\u0098\u0003JV'\u00f1".length();
                        var16_7 = 16;
                        var15_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block18;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = Waypoints.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "\u00ba\u00c7\u00a5eK\u0082\u00fa\u00d6m\u00d8Jb\u000e\u00fb\u00bc\u00d5\u0010\u00eb\u0013\u00c6p\u00d9\u00105\u00b3\u00e7\u00ec\u0088W\u00f2-x\u00c4";
                            var19_6 = "\u00ba\u00c7\u00a5eK\u0082\u00fa\u00d6m\u00d8Jb\u000e\u00fb\u00bc\u00d5\u0010\u00eb\u0013\u00c6p\u00d9\u00105\u00b3\u00e7\u00ec\u0088W\u00f2-x\u00c4".length();
                            var16_7 = 16;
                            var15_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block18;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = Waypoints.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block19;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                Waypoints.D = var20_3;
                Waypoints.E = new String[17];
                Waypoints.I = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[19];
                var3_13 = 0;
                var4_14 = "\u009e\u0010u\u00faF\tCS\u00c0;*\u0094w\u0012t\u00be\u00e8xw\u007fF\u00f07\u00b6\u00f2\u0096\u00be\u007f\u00e0\u00e0\u00dfLE\u00dd\u00a9\u00a1\u00c0\u00fdx\u00ce\u00be\u00d0\u00a0\u0082\u00c7T\u001c\u0017\u00b3\u00eb\u00aeI|\u0087\u009cf\u00ba\u00b9\u00f0\u00df\u0089\u00ce\u009b&\u00cc~\u00a05\u00ef\u008eA\u001cD\u00bf<\u0019XmS\u00d9Y\u0014r\u00102'\u001fb\u00ff\u00b2\u00f8E\u0019\u0005\u0082n\u00b9\u00b1\u00cf\u00e7y\u0011\u00db\u00be*\u00dd\u009a\u00993\u008ft\u00f0\u00d9\u00d7Xc\u0002\u00bd/\u009c\u00d0\u00ef2C\u00a8\u00bcu\u0088\u00a8]g\u00ac\u00bc]/;";
                var5_15 = "\u009e\u0010u\u00faF\tCS\u00c0;*\u0094w\u0012t\u00be\u00e8xw\u007fF\u00f07\u00b6\u00f2\u0096\u00be\u007f\u00e0\u00e0\u00dfLE\u00dd\u00a9\u00a1\u00c0\u00fdx\u00ce\u00be\u00d0\u00a0\u0082\u00c7T\u001c\u0017\u00b3\u00eb\u00aeI|\u0087\u009cf\u00ba\u00b9\u00f0\u00df\u0089\u00ce\u009b&\u00cc~\u00a05\u00ef\u008eA\u001cD\u00bf<\u0019XmS\u00d9Y\u0014r\u00102'\u001fb\u00ff\u00b2\u00f8E\u0019\u0005\u0082n\u00b9\u00b1\u00cf\u00e7y\u0011\u00db\u00be*\u00dd\u009a\u00993\u008ft\u00f0\u00d9\u00d7Xc\u0002\u00bd/\u009c\u00d0\u00ef2C\u00a8\u00bcu\u0088\u00a8]g\u00ac\u00bc]/;".length();
                var2_16 = 0;
                while (true) {
                    var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                    v10 = var6_12;
                    v11 = var3_13++;
                    v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                    v13 = -1;
                    break block20;
                    break;
                }
lbl81:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    var4_14 = "\u0019\u00fcr;\u00ba\u00a6\u00ce\u00dbS\u000b>\u00ae\u0089>\u00b3\u00c0";
                    var5_15 = "\u0019\u00fcr;\u00ba\u00a6\u00ce\u00dbS\u000b>\u00ae\u0089>\u00b3\u00c0".length();
                    var2_16 = 0;
                    while (true) {
                        var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                        v10 = var6_12;
                        v11 = var3_13++;
                        v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                        v13 = 0;
                        break block20;
                        break;
                    }
                    break;
                }
lbl94:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    break block21;
                    break;
                }
            }
            var8_18 = v12;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            v14 = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
            switch (v13) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl107:
                // 1 sources

                ** continue;
            }
        }
        Waypoints.G = var6_12;
        Waypoints.H = new Integer[19];
        Waypoints.x = new GsonBuilder().setPrettyPrinting().create();
    }

    private static Throwable a(Throwable throwable) {
        return throwable;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static String b(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x38B7;
        if (E[n3] == null) {
            Object[] objectArray;
            try {
                Long l3 = Thread.currentThread().threadId();
                objectArray = (Object[])F.get(l3);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    F.put(l3, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/g/ao", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l2 >>> 56);
            for (int i2 = 1; i2 < 8; ++i2) {
                byArray[i2] = (byte)(l2 << i2 * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = D[n3].getBytes("ISO-8859-1");
            Waypoints.E[n3] = Waypoints.b(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return E[n3];
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        String string2 = Waypoints.b(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static CallSite b(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/ao" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x545A;
        if (H[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = G[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])I.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    I.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/g/ao", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Waypoints.H[n3] = n4;
        }
        return H[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = Waypoints.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/ao" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (K[n4] != null) {
            return n4;
        }
        Object object = J[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 23;
            case 1 -> 32;
            case 2 -> 21;
            case 3 -> 58;
            case 4 -> 30;
            case 5 -> 45;
            case 6 -> 10;
            case 7 -> 8;
            case 8 -> 40;
            case 9 -> 19;
            case 10 -> 55;
            case 11 -> 54;
            case 12 -> 13;
            case 13 -> 18;
            case 14 -> 48;
            case 15 -> 47;
            case 16 -> 51;
            case 17 -> 53;
            case 18 -> 33;
            case 19 -> 3;
            case 20 -> 17;
            case 21 -> 12;
            case 22 -> 49;
            case 23 -> 6;
            case 24 -> 60;
            case 25 -> 27;
            case 26 -> 9;
            case 27 -> 16;
            case 28 -> 38;
            case 29 -> 5;
            case 30 -> 39;
            case 31 -> 44;
            case 32 -> 46;
            case 33 -> 4;
            case 34 -> 37;
            case 35 -> 63;
            case 36 -> 0;
            case 37 -> 35;
            case 38 -> 62;
            case 39 -> 7;
            case 40 -> 20;
            case 41 -> 1;
            case 42 -> 22;
            case 43 -> 57;
            case 44 -> 2;
            case 45 -> 36;
            case 46 -> 24;
            case 47 -> 14;
            case 48 -> 11;
            case 49 -> 28;
            case 50 -> 25;
            case 51 -> 42;
            case 52 -> 31;
            case 53 -> 61;
            case 54 -> 29;
            case 55 -> 41;
            case 56 -> 52;
            case 57 -> 34;
            case 58 -> 59;
            case 59 -> 26;
            case 60 -> 43;
            case 61 -> 56;
            case 62 -> 15;
            default -> 50;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        Waypoints.K[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = J;
        J[0] = "\b\u001d{\fbF\u0003\u001d}\fb\u0007";
        objectArray[1] = "\b+z\u001780\u0001+y\u0017<";
        objectArray[2] = "d1_u^8y$\u0007W\u001f5a\"";
        objectArray[3] = "\u000f\t2LO\b\u0011\u0001(\u0003-\u0014\u0016\u001c";
        objectArray[4] = "\u0019_di6g\u0010_gi4";
        objectArray[5] = "Wt c]N\\t(";
        objectArray[6] = "LT4O\u001btET7O\u0010";
        objectArray[7] = "RWq]_\u0016'wzRNYFyqYJ\u00032";
        objectArray[8] = Void.TYPE;
        Waypoints.K[8] = "java/lang/Void";
        objectArray[9] = "\u0018g\u000e\u0013\u000e,\u0011g\r\u0013\u0002";
        objectArray[10] = "\u0002grl[O\u000bgql^";
        objectArray[11] = Integer.TYPE;
        Waypoints.K[11] = "java/lang/Integer";
        objectArray[12] = "n\u0015v\\:\u0017e\u0015}";
        objectArray[13] = "\u0019\u0013\u0013Q,zl3\u0018^=5\r=\u0013U9oy";
        objectArray[14] = "5liY`|>cx\u0016\u001ax-bhY,|:";
        objectArray[15] = " P<H1)Up7G f4~<L$<@";
        objectArray[16] = ";\u007f[WI.>0k_\u000b\"";
        objectArray[17] = "Wf\u0000(AB\\f\u0006(A(";
        objectArray[18] = "\bA";
        objectArray[19] = "2c+w5\u001b>k*<|\u0013\"c(w\u0015\u0007>b";
        objectArray[20] = "+\u0006bIFD \ts\u0006;\\3\u000ezO";
        objectArray[21] = "w\u001e\u0000\u0004\u0013\u001bw\u001e\u0017X\u001f\u0014mU\u0017F\u001f\u0001j$G\u001bN";
        objectArray[22] = "\u000e\u0002O!HA{\"D.Y\u000e\u001a,O%]Tn";
        objectArray[23] = "DD`zE\u00191dkuTVPj`~P\f$";
        objectArray[24] = Boolean.TYPE;
        Waypoints.K[24] = "java/lang/Boolean";
        objectArray[25] = "\"iU\u0000\u001d=WI^\u000f\fr6GU\u0004\b(B";
        objectArray[26] = "\u001e@ve]xk`}jL7\nnvaHm~";
        objectArray[27] = "\u0019\u0015X\\o#\u0019\u0015O\u0000c,\u0003^O\u001ec9\u0004/\u001eA1r";
        objectArray[28] = "uA\u0013+?\u0003|A\u0010+?";
        objectArray[29] = "%Jkx\u0002z.Ez7ct%N~m";
        objectArray[30] = "^\u0005e5\u0005KO\u0005ex";
        objectArray[31] = "+/h\u000bW-^\u000fc\u0004Fb?\u0001h\u000fB8K";
        objectArray[32] = "a#";
        objectArray[33] = "4]PDy]%]}";
        objectArray[34] = "w\u0003\u000f\u0005\u001df\u0002#\u0004\n\f)c-\u000f\u0001\bs\u0017";
        objectArray[35] = "&J$Y\u0003^/J\u0002";
        objectArray[36] = "W/\\i\u0007\r\"\u000fWf\u0016BC\u0001\\m\u0012\u00187";
        objectArray[37] = "r) \u0007<,{)\u0007";
        objectArray[38] = "f\u000e?Dt^\u0013.4Ke\u0011r ?@aK\u0006";
        objectArray[39] = "\u0004\u0005qMnN\f[y6z,\u0006Xb\u000byK\u0002\u0003$N";
        objectArray[40] = "Md5\u001ah{E:=ab\u0019H2%]z\u007f\t}!\u000f";
        objectArray[41] = "NG>\u0002&\tF\u00196y7kL\u001a-D1\fHAk\u0001";
        objectArray[42] = "Y\u001a\u0004igZ[\u0002\u0003(\u0018_2C\u0005q&\u0007J\u001c\u0005uq";
        objectArray[43] = "a>@\u000fl$i`HtgFccSI{!g8\u0015\f";
        objectArray[44] = ">=\f\u0017g\\6c\u0004l`>~?\u001f\u000fe\u0003k;\u0002Q\u000b\u0000<bXU1\u0005l>\u001fl";
        objectArray[45] = "ur4\f\u001eS},<w\u001b15p'\u0014\u001c\f t:Jr^>/8\u0005\rV%xew";
        objectArray[46] = "^?-%2\u0016\\'*dM\u00105f,=sKM9,9$";
        objectArray[47] = "\u0013L\u0017=ld\u001b\u0012\u001fF\u007f\u0006\u0015F\u001d,dlJS@ ";
        objectArray[48] = "a_b.\r\u0005i\u0001jU\u0011g4Db)\u001b\u00166Dq4";
        objectArray[49] = "\u0001\u0004#C\u001f(\u0003\u001c$\u0002`/j]\"[^u\u0012\u0002\"_\t";
        objectArray[50] = "\b\u000f\u0015C\u0004W\u0000Q\u001d8\u00125\nR\u0006\u0005\u0013R\u000e\t@@";
        objectArray[51] = "~uoJ\u0015Iv+g1\u0017+>w|R\u0017\u0016+sa\fy\u0015|*;\bC\u0010,v|1";
        objectArray[52] = "UMIO(\u0003\f\u0017\u001eJ\u0011\u0014VNX\u001a\u0011A\t\u0011\u001cN+DYM[w";
        objectArray[53] = "Dq\u0007\u0013\u0011dL/\u000fh4\u0006\u0012dV\u000f\u000fy\u001a\u007f\u0001R";
        objectArray[54] = "0&_pq\u001b1~\u0016s@\fR$\rg\u007f\u001d/\"\u000f\"&e";
        objectArray[55] = "LI&\u0001*9NQ!@U<'Yz\u00046;\u001aL~\u0019hUFP`\u000781\u0017Kf\u0002U";
        objectArray[56] = "\u001fWW/'Y^NPh]IgVY+>NZC]6` \u0000KVkd\\Y\u0011\u0001n]";
        objectArray[57] = "B\u0002Fy\u0007W@\u001aA8xV)[GaF\nQ\u0004Ge\u0011";
        objectArray[58] = "ay8d\u0004\u0012'xh\"h8\u0017G\u001eS2bay8d\u0004\u0012'xh\"";
        objectArray[59] = "7EF\u001c3`?\u001bNg!\u0002sRT_;iu\u0018U";
        objectArray[60] = ")y3p,m z=dU8Oa4f6?rt0{hQ jky'.(q<$U";
        objectArray[61] = "\u001aj|A:\u0007\u00124t:3eZhoY8XOlr\u0007V[\u00185(\u0003l^Hio:";
        objectArray[62] = "\u0013\u0015;W9\u001eB\r.A\tN#\u001b7\btA[\u00103Ar";
        objectArray[63] = "M\u001d^Wc3ECV,sQO@M\u0011t6K\u001b\u000bT";
        objectArray[64] = "3J`:5 ;\u0014hA<B6\u001cp}'$wSt/";
        objectArray[65] = "\r%\u001c\u000e5u\u0005{\u0014u0\u0017]yLIf+Q;\f\u0016Y~\u000fyKJerM9\u0014u";
        objectArray[66] = "\u0003\u007f)7^#\u000b!!LIA\u0004r25Cq_)}*";
        objectArray[67] = "\b5=]^$\u0000k5&CF\u000b+lYK|\u00001mY";
        objectArray[68] = "N&E\u0007)?HlD?$T\n.\u0006Ur8V0N\u0003M";
        objectArray[69] = "zH\u0015gD%r\u0016\u001d\u001cAG:J\u0006\u007fFz/N\u001b!(-\"D\u0018fA#:\u0014\u0013\u001c";
        objectArray[70] = "\"O/z\u001e_ W(;aYIMv?ZK)Fpl\u001b3";
        objectArray[71] = ",!5\u0015t+}9 \u0003D~\u001c-5K#`c%.\u001c~\u0012";
        objectArray[72] = "#\u0001S1\u0001P+_[J\u001f2u\u0014\u0002-\u001fM}\u000fUp";
        objectArray[73] = "\rU\u001fo\u001d,T\u000fHj$:jH\u0010/G>W]\u00142\u0019PT\nMh\u001djQZ\u0011/$";
        objectArray[74] = "I}HxK\u001cKeO94\u001c\"y@uOH\u001b~\bxF";
        objectArray[75] = "}\u0001H\u001br0u_@`TRt^F^/*+^B\t";
        objectArray[76] = "\u001a\u0003, &\u000fK\u001b96\u0016R*\u0019;<uX\u0017\f?!+6\u0014[f{/\f\u0011\u000b:<\u0016";
        objectArray[77] = "\u000bd>H{\u0007\rmbF\u001e\u000bor>@}\fRg:]#b\nw1S~\u001cP:%X\u001e";
        Object[] objectArray2 = objectArray;
        objectArray[78] = "9<u\u001f\rp1b}d\u0018\u0012>1n\u001d\u0010\"ej!\u0002";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = Waypoints.e(l2, l3);
            object = J[n2];
            try {
                if (!(object instanceof String)) break block2;
                Waypoints.J[n2] = clazz = Class.forName(K[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = Waypoints.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = Waypoints.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = Waypoints.e(l2, l3);
        Object object = J[n2];
        if (object instanceof String) {
            String string = K[n2];
            int n3 = string.indexOf(8);
            Class clazz = Waypoints.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = Waypoints.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = Waypoints.c(clazz3, string2, clazz2)) != null) {
                    Waypoints.J[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = Waypoints.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        Waypoints.J[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = Waypoints.f(2067106721083079L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = Waypoints.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = Waypoints.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = Waypoints.e(l2, l3);
        Object object = J[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = K[n2];
                int n4 = string2.indexOf(8);
                clazz3 = Waypoints.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = Waypoints.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = Waypoints.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        Waypoints.J[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = Waypoints.f(2067106721083079L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = Waypoints.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        Waypoints.J[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = Waypoints.f(2067106721083079L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == '$' || c2 == 'w' || c2 == 'q' || c2 == '\u00df') {
                field = Waypoints.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == '$' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == 'w' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == 'q' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = Waypoints.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == '\u00c9' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == 'g' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = Waypoints.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_2().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/ao" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Waypoints.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(Waypoints.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_2() {
        try {
            return MethodHandles.lookup().findStatic(Waypoints.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

