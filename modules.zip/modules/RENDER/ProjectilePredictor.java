// === Kuzi module: ProjectilePredictor ===
// Category   : RENDER
// Description: Shows the arc and landing block of the projectile you're holding (pearl, bow, potion...).
// Payload    : a.a.a.j.g.ah (verified: False)

package kuzi.modules.render;

import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.F;
import kuzi.obf.h.b.e;
import kuzi.obf.h.b.v;
import kuzi.obf.j.g.aD;
import kuzi.obf.m.r;
import kuzi.obf.p.Z;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.Vec3;
import net.minecraft.Minecraft;

public final class ProjectilePredictor
extends BaseModule {
    private final e m;
    private final BoolSetting landingBox;
    private final BoolSetting fillBox;
    private final SliderSetting fillOpacity;
    private final SliderSetting startGap;
    private final SliderSetting r;
    private static final long s;
    private static final String[] t;
    private static final String[] u;
    private static final Map v;
    private static final long[] w;
    private static final Integer[] x;
    private static final Map y;
    private static final Object[] z;
    private static final String[] A;

    public ProjectilePredictor() {
        long l2;
        long l3 = l2 = s ^ 0x34B979891E29L;
        long l4 = l3 ^ 0x9E7D63863D9L;
        long l5 = l3 ^ 0x4563E6FB7B91L;
        super("ProjectilePredictor", "Shows the arc and landing block of the projectile you're holding (pearl, bow, potion...).", Category.RENDER);
        this.m = new e("Color", new Color(90, 220, 160));
        this.landingBox = new BoolSetting("Landing Box", true);
        this.fillBox = new BoolSetting("Fill Box", true);
        this.fillOpacity = new SliderSetting("Fill Opacity", 45.0, 0.0, 255.0, 5.0);
        this.startGap = new SliderSetting("Start Gap", 2.0, 0.0, 6.0, 0.5);
        this.r = new SliderSetting("Max Length", 140.0, 20.0, 300.0, 10.0);
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.m, this.landingBox, this.fillBox, this.fillOpacity, this.startGap, this.r};
        objectArray[0] = l5;
        this.l(objectArray);
        WorldRenderEvents.END_MAIN.register(arg_0 -> this.a(l4, arg_0));
    }

    /*
     * Unable to fully structure code
     */
    private void a(long var1_1, WorldRenderContext var3_2) {
        block54: {
            block55: {
                block58: {
                    block59: {
                        block57: {
                            block56: {
                                v0 = var1_1 = ProjectilePredictor.s ^ var1_1;
                                var4_3 = v0 ^ 49104749771606L;
                                var6_4 = v0 ^ 10201087120747L;
                                var8_5 = v0 ^ 306218039600L;
                                var10_6 = v0 ^ 40747213950178L;
                                var12_7 = v0 ^ 57431652134074L;
                                var14_8 = aD.b();
                                if (!this.d()) {
                                    return;
                                }
                                v1 = var15_9 = Minecraft.getInstance();
                                if (var1_1 < 0L || var14_8 == null) break block56;
                                if (v1.level == null) break block57;
                                v1 = var15_9;
                            }
                            v2 = v1.player;
                            if (var14_8 == null) break block58;
                            if (v2 != null) break block59;
                        }
                        return;
                    }
                    v2 = var15_9.player;
                }
                v3 = new Object[3];
                v3[2] = Float.valueOf(var15_9.getDeltaTracker().getGameTimeDeltaPartialTick(true));
                v3[1] = var4_3;
                v3[0] = v2;
                var16_10 = Z.a(v3);
                if (var16_10 == null) {
                    return;
                }
                try {
                    v4 = new Object[5];
                    v4[4] = var10_6;
                    v4[3] = (int)Math.round((Double)this.r.a());
                    v4[2] = var16_10;
                    v4[1] = var15_9.player;
                    v4[0] = var15_9.level;
                    var17_11 = Z.a(v4);
                }
                catch (Throwable var18_12) {
                    return;
                }
                var18_13 = var17_11.a;
                if (var18_13.size() < 2) {
                    return;
                }
                var19_14 = var3_2.matrices();
                if (var19_14 == null) {
                    return;
                }
                v5 = var20_15 = var15_9.gameRenderer.getMainCamera();
                if (var14_8 != null) {
                    if (v5 == null) {
                        return;
                    }
                    v5 = var20_15;
                }
                var21_16 = v5.position();
                var22_17 = var21_16.x;
                var24_18 = var21_16.y;
                var26_19 = var21_16.z;
                var28_20 = this.m.a().getRGB() & ProjectilePredictor.c("l", (int)13510, (long)(4064418809873420976L ^ var1_1));
                var29_21 = ProjectilePredictor.c("l", (int)25114, (long)(6535957467542357099L ^ var1_1)) | var28_20;
                var30_22 = this.m.a();
                v6 = new Object[2];
                v6[1] = var12_7;
                v6[0] = (int)Math.round((Double)this.fillOpacity.a());
                var31_23 = ProjectilePredictor.a(v6);
                var32_24 = (Vec3)var18_13.get(0);
                var33_25 = (Double)this.startGap.a();
                var35_26 = var33_25 * var33_25;
                var37_27 = F.a(new Object[0]);
                try {
                    block49: {
                        block53: {
                            block52: {
                                block51: {
                                    block50: {
                                        block48: {
                                            block60: {
                                                block46: {
                                                    block22: for (var38_28 = 0; var38_28 < var18_13.size() - 1; ++var38_28) {
                                                        v7 = var18_13.get(var38_28);
                                                        do {
                                                            block47: {
                                                                var39_31 = (Vec3)v7;
                                                                var40_34 = (Vec3)var18_13.get(var38_28 + 1);
                                                                try {
                                                                    cfr_temp_0 = var39_31.distanceToSqr(var32_24) - var35_26;
                                                                    v8 = cfr_temp_0 == 0.0 ? 0 : (cfr_temp_0 < 0.0 ? -1 : 1);
                                                                    v9 = var14_8;
                                                                    if (var1_1 >= 0L) {
                                                                        if (v9 == null) break block46;
                                                                        if (v8 >= 0) break block47;
                                                                    }
                                                                    ** GOTO lbl107
                                                                }
                                                                catch (Throwable v10) {
                                                                    throw ProjectilePredictor.a(v10);
                                                                }
                                                                if (var1_1 > 0L) continue block22;
                                                            }
                                                            v11 = new Object[5];
                                                            v11[4] = new Vec3(var40_34.x - var22_17, var40_34.y - var24_18, var40_34.z - var26_19);
                                                            v11[3] = var6_4;
                                                            v11[2] = new Vec3(var39_31.x - var22_17, var39_31.y - var24_18, var39_31.z - var26_19);
                                                            v11[1] = var30_22;
                                                            v11[0] = var19_14;
                                                            var37_27.c(v11);
                                                            if (var14_8 != null) continue block22;
                                                            v7 = (Boolean)this.landingBox.a();
                                                        } while (var1_1 < 0L);
                                                    }
                                                    v8 = v7.booleanValue();
                                                }
                                                v9 = var14_8;
lbl107:
                                                // 2 sources

                                                if (v9 == null) break block48;
                                                if (v8 == 0) break block49;
                                                break block60;
                                                catch (Throwable v12) {
                                                    throw ProjectilePredictor.a(v12);
                                                }
                                            }
                                            try {
                                                block61: {
                                                    v13 = var17_11;
                                                    if (var1_1 < 0L || var14_8 == null) break block50;
                                                    break block61;
                                                    catch (Throwable v14) {
                                                        throw ProjectilePredictor.a(v14);
                                                    }
                                                }
                                                v8 = (int)v13.b;
                                            }
                                            catch (Throwable v15) {
                                                throw ProjectilePredictor.a(v15);
                                            }
                                        }
                                        if (v8 == 0) break block49;
                                        v13 = var17_11;
                                    }
                                    v16 = v13.c;
                                    if (var14_8 == null) break block51;
                                    try {
                                        block62: {
                                            if (v16 == null) break block49;
                                            break block62;
                                            catch (Throwable v17) {
                                                throw ProjectilePredictor.a(v17);
                                            }
                                        }
                                        v16 = var17_11.c;
                                    }
                                    catch (Throwable v18) {
                                        throw ProjectilePredictor.a(v18);
                                    }
                                }
                                var38_29 = v16;
                                var39_32 = (double)var38_29.getX() - var22_17;
                                var41_35 = (double)var38_29.getY() - var24_18;
                                var43_36 = (double)var38_29.getZ() - var26_19;
                                var45_37 = (double)(var38_29.getX() + 1) - var22_17;
                                var47_38 = (double)(var38_29.getY() + 1) - var24_18;
                                var49_39 = (double)(var38_29.getZ() + 1) - var26_19;
                                try {
                                    v19 = ((Boolean)this.fillBox.a()).booleanValue();
                                    if (var1_1 <= 0L || var14_8 == null) break block52;
                                    if (v19 == 0) break block53;
                                }
                                catch (Throwable v20) {
                                    throw ProjectilePredictor.a(v20);
                                }
                                v19 = var31_23;
                            }
                            try {
                                if (v19 > 0) {
                                    v21 = new Object[10];
                                    v21[9] = false;
                                    v21[8] = var31_23 << ProjectilePredictor.c("l", (int)12503, (long)(4701112687691290279L ^ var1_1)) | var28_20;
                                    v21[7] = var49_39;
                                    v21[6] = var47_38;
                                    v21[5] = var45_37;
                                    v21[4] = var43_36;
                                    v21[3] = var41_35;
                                    v21[2] = var39_32;
                                    v21[1] = var8_5;
                                    v21[0] = var19_14;
                                    var37_27.b(v21);
                                }
                            }
                            catch (Throwable v22) {
                                throw ProjectilePredictor.a(v22);
                            }
                        }
                        v23 = new Object[10];
                        v23[9] = true;
                        v23[8] = var29_21;
                        v23[7] = var49_39;
                        v23[6] = var47_38;
                        v23[5] = var45_37;
                        v23[4] = var43_36;
                        v23[3] = var41_35;
                        v23[2] = var39_32;
                        v23[1] = var8_5;
                        v23[0] = var19_14;
                        var37_27.b(v23);
                    }
                    if (var1_1 <= 0L) break block54;
                    v24 = var37_27;
                    if (var14_8 == null) break block55;
                }
                catch (Throwable var38_30) {
                    block63: {
                        if (var1_1 <= 0L) break block63;
                        v25 = var37_27;
                        if (var14_8 == null) ** GOTO lbl214
                        if (v25 == null) break block63;
                        try {
                            v25 = var37_27;
lbl214:
                            // 2 sources

                            v25.close();
                        }
                        catch (Throwable var39_33) {
                            var38_30.addSuppressed(var39_33);
                        }
                    }
                    throw var38_30;
                }
                if (v24 == null) break block54;
                v24 = var37_27;
            }
            v24.close();
        }
    }

    private static int a(Object[] objectArray) {
        int clampedOpacity;
        block6: {
            int candidate;
            long l2;
            block4: {
                int opacity;
                block5: {
                    opacity = (Integer)objectArray[0];
                    l2 = (Long)objectArray[1];
                    l2 = s ^ l2;
                    CallSite callSite = ProjectilePredictor.d("\u00a3", (long)-1157824415234355112L, (long)l2);
                    try {
                        try {
                            candidate = opacity;
                            if (callSite == null) break block4;
                            if (candidate >= 0) break block5;
                        }
                        catch (r r2) {
                            throw ProjectilePredictor.d("\u00a3", (Object)r2, (long)-1158234721726615136L, (long)l2);
                        }
                        clampedOpacity = 0;
                        break block6;
                    }
                    catch (r r3) {
                        throw ProjectilePredictor.d("\u00a3", (Object)r3, (long)-1158234721726615136L, (long)l2);
                    }
                }
                candidate = opacity;
            }
            clampedOpacity = Math.min(candidate, (int)ProjectilePredictor.c("l", (int)16203, (long)(0x656016459661CB2EL ^ l2)));
        }
        return clampedOpacity;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block21: {
            block20: {
                block19: {
                    block18: {
                        ProjectilePredictor.s = kuzi.obf.h.b.v.a(-6815052673480257638L, 641777191849215431L, MethodHandles.lookup().lookupClass()).a(210605981914759L);
                        ProjectilePredictor.z = new Object[52];
                        ProjectilePredictor.A = new String[52];
                        ProjectilePredictor.c();
                        ProjectilePredictor.v = new HashMap<K, V>(13);
                        var11 = ProjectilePredictor.s ^ 36369380200903L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[8];
                        var18_4 = 0;
                        var17_5 = "X,X)p\u00e0fH\u00ccE\u00f5\u00d2\u00f6K\u00c9\u00d5\u00e1\u00e6\u00ad\u00fd\u00f0\u00fa\u00ee\u00a6g\u00c0\u00da\u00b1\u008c\u0094\u0083\u0010h\u0001\u00cd\u00caL\u009etu\u0006?\u00dbU\u0005\u001011\u00f1\u0085\u00ee\u00e3\u00ddD\n\u0003\u0003\u00a7\u00b1\u00c28\u00ec\u008fV~%\u009cS\u0093e\u0014\u00f2a\u00a6\u00e9u\u00ffa\u000e\u00981\u00ach<O\u0000\u000e \u00da\u00c4F\u00cd4\\\u007fK\u00d5\u00bd\u00d2\u00c1\u0091\u008b\u00f7#\u00b9\u00a2\u000b\u008c\u0010\u0017\u00f2\u00c1\u00f6<\u0017\u00f1O@o\u00d5\u0099\u0093*\u001baVc\u009d\u00ba\u0005\u0011\u00d5\u00ad\u0092\u00b0]\u00cb\u0001\u0095\u00aa\u00e0~!\u00f6_\u0004G\u00e7p\u00fc\u00a4\u00f1\u0010_\u0018|\u0098\r^\u00a0\u00de\u008e\u00fe\u0012`\u0090v\u00fa\u0004(>\u00da\u0000\u00a2\u0005\u0095\u00a5Q\u0092O8A\u00edAh\u0092:\u00c3\u00da{ANw\u00e8\u00b6\u00f3$\u00a7\u00d0\f%\u00cb \u00f0\u00b4U\u00fe\u0087\u00aa\u00fb\u0018u\u00b1\u00b1&J\u00e7\u00dcm\u00b25{\u009a\u00eaF\u00e0\u00c5\u00ccc\u00f4*9\u0080J! n\u0000\u00cfZ\u00a6\u0085o\u00cf\u009bF\u00fd9r\u00c2\u0004\u0002\n\u0004]\u00b2%(q\u00a9\u00ec<\u00836\u0085\u00ee\u0092(\u0018\u0014\u0096\u00ef\u0080 \u0013\u00ddv\u00d1\u001b2\u00e9\u00db<\u00dcr\u0012tA\u00c7\u0004\u00bf\u00df\u00f5";
                        var19_6 = "X,X)p\u00e0fH\u00ccE\u00f5\u00d2\u00f6K\u00c9\u00d5\u00e1\u00e6\u00ad\u00fd\u00f0\u00fa\u00ee\u00a6g\u00c0\u00da\u00b1\u008c\u0094\u0083\u0010h\u0001\u00cd\u00caL\u009etu\u0006?\u00dbU\u0005\u001011\u00f1\u0085\u00ee\u00e3\u00ddD\n\u0003\u0003\u00a7\u00b1\u00c28\u00ec\u008fV~%\u009cS\u0093e\u0014\u00f2a\u00a6\u00e9u\u00ffa\u000e\u00981\u00ach<O\u0000\u000e \u00da\u00c4F\u00cd4\\\u007fK\u00d5\u00bd\u00d2\u00c1\u0091\u008b\u00f7#\u00b9\u00a2\u000b\u008c\u0010\u0017\u00f2\u00c1\u00f6<\u0017\u00f1O@o\u00d5\u0099\u0093*\u001baVc\u009d\u00ba\u0005\u0011\u00d5\u00ad\u0092\u00b0]\u00cb\u0001\u0095\u00aa\u00e0~!\u00f6_\u0004G\u00e7p\u00fc\u00a4\u00f1\u0010_\u0018|\u0098\r^\u00a0\u00de\u008e\u00fe\u0012`\u0090v\u00fa\u0004(>\u00da\u0000\u00a2\u0005\u0095\u00a5Q\u0092O8A\u00edAh\u0092:\u00c3\u00da{ANw\u00e8\u00b6\u00f3$\u00a7\u00d0\f%\u00cb \u00f0\u00b4U\u00fe\u0087\u00aa\u00fb\u0018u\u00b1\u00b1&J\u00e7\u00dcm\u00b25{\u009a\u00eaF\u00e0\u00c5\u00ccc\u00f4*9\u0080J! n\u0000\u00cfZ\u00a6\u0085o\u00cf\u009bF\u00fd9r\u00c2\u0004\u0002\n\u0004]\u00b2%(q\u00a9\u00ec<\u00836\u0085\u00ee\u0092(\u0018\u0014\u0096\u00ef\u0080 \u0013\u00ddv\u00d1\u001b2\u00e9\u00db<\u00dcr\u0012tA\u00c7\u0004\u00bf\u00df\u00f5".length();
                        var16_7 = 152;
                        var15_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block18;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = ProjectilePredictor.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "\u00eaEC\u00aa\u00b8\u00f5\u008epo\u00cb\u008c\u00adO/A/g\u007f\u00bf\u00e1\u00a8\u00e4\u0015e\u000f#n\u00dey\u00921\u0093\u0018\u0096x\u008c\t>\u00dd\u00da\u00a0\u0099oq\u00d8\u00af\u000e\u00bc\u00fcD\u00fa\u008d\u0000t\u00af!\u00a3";
                            var19_6 = "\u00eaEC\u00aa\u00b8\u00f5\u008epo\u00cb\u008c\u00adO/A/g\u007f\u00bf\u00e1\u00a8\u00e4\u0015e\u000f#n\u00dey\u00921\u0093\u0018\u0096x\u008c\t>\u00dd\u00da\u00a0\u0099oq\u00d8\u00af\u000e\u00bc\u00fcD\u00fa\u008d\u0000t\u00af!\u00a3".length();
                            var16_7 = 32;
                            var15_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block18;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = ProjectilePredictor.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block19;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                ProjectilePredictor.t = var20_3;
                ProjectilePredictor.u = new String[8];
                ProjectilePredictor.y = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[8];
                var3_13 = 0;
                var4_14 = "\u009e\u00c2nM/\t\u00a7\u00c6G\u009d&\u00bc\u0001\u0087\u00e6@\u00c8\u00a9\u0086\u00ebQ\u0005\u001e\u008a\u00ef\u00cc\u00b6$Q'\u00b1j\u00cap`\u00b5\u0093\u0094A\u00e5\t7\u00dc\u00b0\u0090FP\u009d";
                var5_15 = "\u009e\u00c2nM/\t\u00a7\u00c6G\u009d&\u00bc\u0001\u0087\u00e6@\u00c8\u00a9\u0086\u00ebQ\u0005\u001e\u008a\u00ef\u00cc\u00b6$Q'\u00b1j\u00cap`\u00b5\u0093\u0094A\u00e5\t7\u00dc\u00b0\u0090FP\u009d".length();
                var2_16 = 0;
                while (true) {
                    var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                    v10 = var6_12;
                    v11 = var3_13++;
                    v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                    v13 = -1;
                    break block20;
                    break;
                }
lbl81:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    var4_14 = "r\u0014\u008d\u0019TQd\u00d6g\tn\u001e\u00db\u001bx\u00fb";
                    var5_15 = "r\u0014\u008d\u0019TQd\u00d6g\tn\u001e\u00db\u001bx\u00fb".length();
                    var2_16 = 0;
                    while (true) {
                        var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                        v10 = var6_12;
                        v11 = var3_13++;
                        v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                        v13 = 0;
                        break block20;
                        break;
                    }
                    break;
                }
lbl94:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    break block21;
                    break;
                }
            }
            var8_18 = v12;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            v14 = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
            switch (v13) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl107:
                // 1 sources

                ** continue;
            }
        }
        ProjectilePredictor.w = var6_12;
        ProjectilePredictor.x = new Integer[8];
    }

    private static Throwable a(Throwable throwable) {
        return throwable;
    }

    private static String b(byte[] byArray) {
        int outIndex = 0;
        int inputLength = byArray.length;
        char[] cArray = new char[inputLength];
        for (int index = 0; index < inputLength; ++index) {
            char ch;
            int byteValue = 0xFF & byArray[index];
            if (byteValue < 192) {
                cArray[outIndex++] = (char)byteValue;
                continue;
            }
            if (byteValue < 224) {
                ch = (char)((char)(byteValue & 0x1F) << 6);
                byteValue = byArray[++index];
                ch = (char)(ch | (char)(byteValue & 0x3F));
                cArray[outIndex++] = ch;
                continue;
            }
            if (index >= inputLength - 2) continue;
            ch = (char)((char)(byteValue & 0xF) << 12);
            byteValue = byArray[++index];
            ch = (char)(ch | (char)(byteValue & 0x3F) << 6);
            byteValue = byArray[++index];
            ch = (char)(ch | (char)(byteValue & 0x3F));
            cArray[outIndex++] = ch;
        }
        return new String(cArray, 0, outIndex);
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x1B83;
        if (x[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = w[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])y.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    y.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/g/ah", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            ProjectilePredictor.x[n3] = n4;
        }
        return x[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = ProjectilePredictor.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/ah" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (A[n4] != null) {
            return n4;
        }
        Object object = z[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 31;
            case 1 -> 48;
            case 2 -> 41;
            case 3 -> 63;
            case 4 -> 54;
            case 5 -> 14;
            case 6 -> 26;
            case 7 -> 36;
            case 8 -> 23;
            case 9 -> 9;
            case 10 -> 44;
            case 11 -> 17;
            case 12 -> 32;
            case 13 -> 6;
            case 14 -> 3;
            case 15 -> 0;
            case 16 -> 10;
            case 17 -> 25;
            case 18 -> 1;
            case 19 -> 29;
            case 20 -> 2;
            case 21 -> 13;
            case 22 -> 55;
            case 23 -> 47;
            case 24 -> 16;
            case 25 -> 39;
            case 26 -> 49;
            case 27 -> 35;
            case 28 -> 56;
            case 29 -> 42;
            case 30 -> 21;
            case 31 -> 45;
            case 32 -> 18;
            case 33 -> 51;
            case 34 -> 34;
            case 35 -> 30;
            case 36 -> 57;
            case 37 -> 62;
            case 38 -> 60;
            case 39 -> 61;
            case 40 -> 27;
            case 41 -> 58;
            case 42 -> 12;
            case 43 -> 28;
            case 44 -> 40;
            case 45 -> 33;
            case 46 -> 22;
            case 47 -> 52;
            case 48 -> 7;
            case 49 -> 53;
            case 50 -> 50;
            case 51 -> 15;
            case 52 -> 19;
            case 53 -> 38;
            case 54 -> 5;
            case 55 -> 11;
            case 56 -> 59;
            case 57 -> 20;
            case 58 -> 37;
            case 59 -> 4;
            case 60 -> 8;
            case 61 -> 46;
            case 62 -> 24;
            default -> 43;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        ProjectilePredictor.A[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = z;
        z[0] = "|#\u001a%}mw#\u001c%}+";
        objectArray[1] = "U\u000e\u001e\u00129,\\\u000e\u001d\u00125";
        objectArray[2] = "u\u001a]i%\u0019~\u001aU";
        objectArray[3] = "^\u0003^W\u0016\u0003W\u0003]W\u0012";
        objectArray[4] = "|B\u0016j\u0011\u0000uB\u0015j\u0013";
        objectArray[5] = "Fc<\rL\"Mc7";
        objectArray[6] = "'\u001cSLU\u0012R<XCD]32SH@\u0007G";
        objectArray[7] = Void.TYPE;
        ProjectilePredictor.A[7] = "java/lang/Void";
        objectArray[8] = "M\u0016Chm%F\u0016EhmO";
        objectArray[9] = "Cj";
        objectArray[10] = "\u001d(k\u0004x:\u0016'zK\u0002>\u0005&j\u00044:\u0012";
        objectArray[11] = "\u0007i\u001c\u0012@z\u0016i'";
        objectArray[12] = "\u001f\u00130\u0003\u0007\u0004j3;\f\u0016K\u000b=0\u0007\u0012\u0011\u007f";
        objectArray[13] = "-\u00112C\u0014><\u00112\u000f";
        objectArray[14] = "K\u001d-\u0017ANB\u001d\u000b";
        objectArray[15] = "Qeyd/;$Erk>tEKy`:.1";
        objectArray[16] = " X!c1vUx*l 94v!g$c@";
        objectArray[17] = Integer.TYPE;
        ProjectilePredictor.A[17] = "java/lang/Integer";
        objectArray[18] = "z\u0005 b\u0012\u0001\u000f%+m\u0003Nn+ f\u0007\u0014\u001a";
        objectArray[19] = "D\u000f#X\u0018\u0011U\u000f#\u0017";
        objectArray[20] = "\u0007\u0011Ay^\u0002\u001a\u0004\u0019[\u001f\u000f\u0002\u0002";
        objectArray[21] = Boolean.TYPE;
        ProjectilePredictor.A[21] = "java/lang/Boolean";
        objectArray[22] = "\u0000\u001f{H{Ou?pGj\u0000\u00141{LnZ`";
        objectArray[23] = "0G1R|f9G2R|";
        objectArray[24] = "Jb\u0000wZ\u000eAm\u00118;\u0000Jf\u0015b";
        objectArray[25] = "]sucH\u001dC{o,*\u0001Df";
        objectArray[26] = "5m@\u0017H\u001b5mWKD\u0014/&WUD\u0001(W\u0006\n\u0016J";
        objectArray[27] = "g-\"SrOn-\u0005";
        objectArray[28] = "~\u0000r\u0007L?\u000b y\b]pj.r\u0003Y*\u001e";
        objectArray[29] = "m6o$W^d$\reo]}54}W\u000fsev";
        objectArray[30] = "\u0019Iy\"\u00030RV$.f\u0000mk\u000f\f<Z\u0019Iy\"\u00030RV$.";
        objectArray[31] = "\u0013gJD\u000e\tX3\u0017Fr\u0011#?\u0018N\u001e\u0013\u001d6\u0017AOx\u0012l\u0011E\u0002\u001fD\"\u0019@r";
        objectArray[32] = "3\u0010y\u000b\u001d\u0001*O|\u0016#\u0015ZNxJO\u0015dGwE\u001e~g\u0013t\tG\u0012$\\p\u000b#";
        objectArray[33] = "Y2=\u0015;\u0005P _W\u0003\u0006I1fL;TGa$";
        objectArray[34] = "J6Bl\u000enC$ 26n\u000e%\u00106T,Hh]";
        objectArray[35] = "tUl\u00034G}G\u000eQ\f\u001fc\u000bbS2\u0016l\u000438g\u0012r\u00070Ik\u0007r[\u000e";
        objectArray[36] = "@/,F>EI=N\u0005\u0006FP,w\u001f>\u0014^|5";
        objectArray[37] = "L\u001cFL8u\u0007H\u001bNDm|D\u0014F(oBM\u001bIy\u0004\u0010E\u001c\u000e)mLOC\u0019D";
        objectArray[38] = "\u0017$DWm*Ub\t\u001a\f!-uG\u001c`\"]sFVrH";
        objectArray[39] = "\u0014L-\"\u0013\u0002F\u0014{yxR*K&q\u0016BD\f.y\u00008";
        objectArray[40] = "Q5n-y\u001c\u0007{f(\t\u0011`j5ej\u001e\u0018|mql";
        objectArray[41] = "4S0\u001d\u0013\u001c=ARO+\u0019!\u00060\\Q\u00195\u00043&\u0014Jw^(\\\u0014^u]R";
        objectArray[42] = "\u0000(Xc\u001e\u000b\t::?&\n\u0014\u007f\u0002$G\u0001\u001b.B";
        objectArray[43] = "x\u0007S\u0019`L2\u0010\u0018^\u000eAC\u0018\u0014RmH;\u000eLFk-";
        objectArray[44] = "$\r\u0004.\u0016V=R\u00013(CMS\u0005oDBsZ\n`\u0015)p\u000e\t,LE3A\r.(";
        objectArray[45] = "\u0004q%+~D\u001d. 6@P\t*16@\u0006R/8?,E\u001d+:[";
        objectArray[46] = "S\b`uP;X\u0000:z,h=\u001a0u\u0014x\u0007\u001a1!]\u0001";
        objectArray[47] = "8\u0016M:\u007f#nXE?\u000f-\tGDm2|x\u001aC8>";
        objectArray[48] = "\t/\u0015%I=_a\u001d 918\u007fO!VcSb\t#\u0005";
        objectArray[49] = "D\u0004\u0001fE\r@\u0010\u001f= \u0019%\u0016\u0013fL\u001b\u001b\u001f\u001ci\u001dpLH\u0012'\u001e\u000fU\u0017\u0017: ";
        objectArray[50] = "$D\bi\u000b\u000bnSC.e\u000e\u001fW\u001da\t\u0001!^\u0012nXj\"\n\u0011\"\u0001\u0006aE\u0015 e";
        Object[] objectArray2 = objectArray;
        objectArray[51] = "%??yJ\u001d,-]$r\u001c1he>\u0013\u0017>9%";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = ProjectilePredictor.e(l2, l3);
            object = z[n2];
            try {
                if (!(object instanceof String)) break block2;
                ProjectilePredictor.z[n2] = clazz = Class.forName(A[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = ProjectilePredictor.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int index = 0; index < classArray.length; ++index) {
                field = ProjectilePredictor.d(classArray[index], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = ProjectilePredictor.e(l2, l3);
        Object object = z[n2];
        if (object instanceof String) {
            String string = A[n2];
            int n3 = string.indexOf(8);
            Class clazz = ProjectilePredictor.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = ProjectilePredictor.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = ProjectilePredictor.c(clazz3, string2, clazz2)) != null) {
                    ProjectilePredictor.z[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int index = 0; index < classArray.length; ++index) {
                        field = ProjectilePredictor.d(classArray[index], string2, clazz2);
                        if (field == null) continue;
                        ProjectilePredictor.z[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = ProjectilePredictor.f(1735454354345998L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int parameterCount, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != parameterCount) continue;
            for (int index = 0; index < parameterCount; ++index) {
                if (classArray2[index] != classArray[index]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int parameterCount, Class[] classArray) {
        Method method = ProjectilePredictor.c(clazz, string, clazz2, parameterCount, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int index = 0; index < classArray2.length; ++index) {
                method = ProjectilePredictor.d(classArray2[index], string, clazz2, parameterCount, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = ProjectilePredictor.e(l2, l3);
        Object object = z[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = A[n2];
                int n4 = string2.indexOf(8);
                clazz3 = ProjectilePredictor.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int paramIndex = 0; paramIndex < n6; ++paramIndex) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = ProjectilePredictor.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (paramIndex < n3) {
                        classArray2[paramIndex] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = ProjectilePredictor.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        ProjectilePredictor.z[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = ProjectilePredictor.f(1735454354345998L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = ProjectilePredictor.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        ProjectilePredictor.z[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = ProjectilePredictor.f(1735454354345998L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == '\u00d5' || c2 == '\u00cc' || c2 == 'E' || c2 == 'M') {
                field = ProjectilePredictor.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == '\u00d5' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == '\u00cc' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == 'E' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = ProjectilePredictor.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == '\u00c2' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == '\u00a3' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = ProjectilePredictor.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/ah" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(ProjectilePredictor.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(ProjectilePredictor.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

