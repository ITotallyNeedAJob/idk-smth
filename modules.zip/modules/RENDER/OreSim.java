// === Kuzi module: OreSim ===
// Category   : RENDER
// Description: Predicts ore locations from the server world seed and renders them.
// Payload    : a.a.a.j.g.af (verified: False)

package kuzi.modules.render;

import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicLong;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.core.Client;
import kuzi.mixin.MixinExposed;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.g.a.h;
import kuzi.obf.h.b.b;
import kuzi.obf.h.b.e;
import kuzi.obf.h.b.l;
import kuzi.obf.h.b.v;
import kuzi.obf.j.g.aD;
import kuzi.obf.j.g.z;
import kuzi.obf.p.Q;
import kuzi.obf.p.r_0;
import kuzi.obf.p.x_0;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import kuzi.settings.StringSetting;
import net.minecraft.ChunkPos;
import net.minecraft.Blocks;
import net.minecraft.Block;
import net.minecraft.BlockPos;
import net.minecraft.Packet;
import net.minecraft.ClientboundBlockUpdatePacket;
import net.minecraft.ClientboundSectionBlocksUpdatePacket;
import net.minecraft.BlockState;
import net.minecraft.Minecraft;
import net.minecraft.ResourceKey;
import net.minecraft.LevelRenderer;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class OreSim
extends BaseModule
implements kuzi.obf.g.a.v {
    private static volatile OreSim instance;
    private static final int n;
    private static final long o;
    private static final long p;
    private static final long q;
    private static final long r;
    private static final int s;
    private final StringSetting seed;
    private final b oreSelection;
    private final SliderSetting radius;
    private final l renderMode;
    private final e color;
    private final BoolSetting verify;
    private final Map oreBlocks;
    private final Set queuedChunks;
    private final Queue chunkQueue;
    private ExecutorService executor;
    private final AtomicLong chunksTotal;
    private final AtomicLong chunksDone;
    private final AtomicLong lastOreChangeMillis;
    private String lastSeedText;
    private Set lastOreSelection;
    private ResourceKey lastDimension;
    private long lastVerifyMillis;
    private long lastProgressMillis;
    private long lastCleanupMillis;
    private long lastXrayRefreshMillis;
    private boolean warnedNoSeed;
    private boolean warnedDimension;
    private boolean warnedWorldgen;
    private boolean loggedScanError;
    private boolean warnedNoOres;
    private volatile String lastScanError;
    private static final long T;
    private static final String[] U;
    private static final String[] V;
    private static final Map W;
    private static final long[] X;
    private static final Integer[] Y;
    private static final Map Z;
    private static final long[] ab;
    private static final Long[] bb;
    private static final Map db;
    private static final Object[] hb;
    private static final String[] ib;

    public OreSim() {
        long l2;
        long l3 = l2 = T ^ 0x1E6E9B9596D5L;
        long l4 = l3 ^ 0x7FA930A051E7L;
        long l5 = l3 ^ 0x34D401E1E7D1L;
        super("Ore Sim", "Predicts ore locations from the server world seed and renders them.", Category.RENDER);
        this.seed = new StringSetting("Seed", "");
        this.oreSelection = new b("Ores", OreSim.a(new Object[0]));
        this.radius = new SliderSetting("Radius", 6.0, 1.0, 16.0, 1.0);
        this.renderMode = new l("Render Mode", kuzi.obf.j.g.z.BOXES, z.class);
        this.color = new e("Color", new Color(0, 220, 190, 160));
        this.verify = new BoolSetting("Verify", true);
        this.oreBlocks = new ConcurrentHashMap();
        this.queuedChunks = ConcurrentHashMap.newKeySet();
        this.chunkQueue = new ConcurrentLinkedQueue();
        this.chunksTotal = new AtomicLong();
        this.chunksDone = new AtomicLong();
        this.lastOreChangeMillis = new AtomicLong();
        this.lastSeedText = "";
        this.lastOreSelection = new HashSet();
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.seed, this.oreSelection, this.radius, this.renderMode, this.color, this.verify};
        objectArray[0] = l5;
        this.l(objectArray);
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l4;
        kuzi.obf.j.f.l.a(objectArray2);
    }

    @Override
    public void d() {
        long l2;
        long l3 = l2 = T ^ 0x60D42D7F4DDCL;
        long l4 = l3 ^ 0x2CE3E5DDA0ECL;
        long l5 = l3 ^ 0x12A230C7721EL;
        long l6 = l3 ^ 0x216B1C2217FDL;
        long l7 = l3 ^ 0x5546C909E33L;
        long l8 = l3 ^ 0x5D3F98D387EDL;
        long l9 = l3 ^ 0x88F9CAEB410L;
        int[] nArray = aD.b();
        instance = this;
        Client.c.a(kuzi.obf.g.a.v.class, this);
        int[] nArray2 = nArray;
        Object[] objectArray = new Object[2];
        objectArray[1] = null;
        objectArray[0] = l9;
        kuzi.obf.p.Q.a(objectArray);
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l7;
        this.c(objectArray2);
        Object[] objectArray3 = new Object[1];
        objectArray3[0] = l4;
        this.a(objectArray3);
        OreSim oreSim = this;
        if (nArray2 != null) {
            Object[] objectArray4 = new Object[2];
            objectArray4[1] = l5;
            objectArray4[0] = (String)oreSim.t.a();
            if (kuzi.obf.p.Q.a(objectArray4) == null) {
                Object[] objectArray5 = new Object[2];
                objectArray5[1] = l6;
                objectArray5[0] = "No seed set - paste the server world seed into the Seed setting.";
                x_0.b(objectArray5);
                this.warnedNoSeed = true;
            }
            oreSim = this;
        }
        Object[] objectArray6 = new Object[1];
        objectArray6[0] = l8;
        oreSim.q(objectArray6);
    }

    @Override
    public void e() {
        long l2;
        long l3 = l2 = T ^ 0x75A8349E2DF2L;
        long l4 = l3 ^ 0x10287571FE1DL;
        long l5 = l3 ^ 0x48438132E7C3L;
        long l6 = l3 ^ 0x1B13B1E1B19L;
        int[] nArray = aD.b();
        OreSim oreSim = instance;
        if (nArray != null) {
            if (oreSim == this) {
                instance = null;
            }
            Client.c.b(kuzi.obf.g.a.v.class, this);
            Object[] objectArray = new Object[1];
            objectArray[0] = l6;
            this.b(objectArray);
            Object[] objectArray2 = new Object[1];
            objectArray2[0] = l4;
            this.c(objectArray2);
            oreSim = this;
        }
        Object[] objectArray = new Object[1];
        objectArray[0] = l5;
        oreSim.q(objectArray);
    }

    @Override
    public void g(Object[] objectArray) {
        OreSim oreSim;
        long l2;
        long l3;
        block4: {
            OreSim oreSim2;
            long l4;
            block5: {
                long l5;
                block6: {
                    l3 = (Long)objectArray[0];
                    long l6 = l3;
                    l2 = l6 ^ 0x61C41F4749DFL;
                    l5 = l6 ^ 0x4873960A7700L;
                    CallSite callSite = OreSim.f("\u00e4", (long)5684247315232207566L, (long)l3);
                    try {
                        try {
                            oreSim = this;
                            if (callSite == null) break block4;
                            l4 = 5684352027561271927L;
                            if (l3 <= 0L) break block5;
                            if (OreSim.f("f", (Object)oreSim, (long)l4, (long)l3) != false) break block6;
                        }
                        catch (UnsupportedOperationException unsupportedOperationException) {
                            throw OreSim.f("\u00e4", (Object)unsupportedOperationException, (long)5686494249525472111L, (long)l3);
                        }
                        return;
                    }
                    catch (UnsupportedOperationException unsupportedOperationException) {
                        throw OreSim.f("\u00e4", (Object)unsupportedOperationException, (long)5686494249525472111L, (long)l3);
                    }
                }
                oreSim2 = this;
                l4 = l5;
            }
            Object[] objectArray2 = new Object[1];
            objectArray2[0] = l4;
            OreSim.f("f", (Object)oreSim2, (Object)objectArray2, (long)5687727557462523631L, (long)l3);
            oreSim = this;
        }
        Object[] objectArray3 = new Object[1];
        objectArray3[0] = l2;
        OreSim.f("f", (Object)oreSim, (Object)objectArray3, (long)5685970775699617534L, (long)l3);
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    @Override
    public void i() {
        block48: {
            block47: {
                block45: {
                    block46: {
                        block42: {
                            block44: {
                                block43: {
                                    block39: {
                                        block40: {
                                            block41: {
                                                block36: {
                                                    block38: {
                                                        block37: {
                                                            block35: {
                                                                block32: {
                                                                    block33: {
                                                                        block34: {
                                                                            block30: {
                                                                                block31: {
                                                                                    block29: {
                                                                                        block28: {
                                                                                            v0 = var1_1 = OreSim.T ^ 132832499043056L;
                                                                                            var3_2 = v0 ^ 40312835338793L;
                                                                                            var5_3 = v0 ^ 89537780521183L;
                                                                                            var7_4 = v0 ^ 61628674038662L;
                                                                                            var9_5 = v0 ^ 11649223032038L;
                                                                                            var11_6 = v0 ^ 14242918282194L;
                                                                                            var13_7 = v0 ^ 59539465883963L;
                                                                                            var15_8 = v0 ^ 124018600988119L;
                                                                                            var17_9 = v0 ^ 122968843065104L;
                                                                                            var19_10 = v0 ^ 11791368434994L;
                                                                                            var21_11 = v0 ^ 63154419060945L;
                                                                                            var23_12 = v0 ^ 32226079430943L;
                                                                                            var25_13 = v0 ^ 14686733488524L;
                                                                                            var27_14 = v0 ^ 137403877962857L;
                                                                                            var29_15 = aD.b();
                                                                                            v1 = BaseModule.a;
                                                                                            if (var29_15 == null) break block28;
                                                                                            if (v1.level == null) break block29;
                                                                                            v1 = BaseModule.a;
                                                                                        }
                                                                                        v2 /* !! */  = v1.player;
                                                                                        if (var29_15 == null) break block30;
                                                                                        if (v2 /* !! */  != null) break block31;
                                                                                    }
                                                                                    return;
                                                                                }
                                                                                v2 /* !! */  = this.seed.a();
                                                                            }
                                                                            if (var29_15 == null) ** GOTO lbl35
                                                                            if (v2 /* !! */  == null) {
                                                                                v3 = "";
                                                                            } else {
                                                                                v2 /* !! */  = this.seed.a();
lbl35:
                                                                                // 2 sources

                                                                                v3 = ((String)v2 /* !! */ ).trim();
                                                                            }
                                                                            seedText = v3;
                                                                            v4 = new Object[1];
                                                                            v4[0] = var13_7;
                                                                            selectedOres = this.oreSelection.a(v4);
                                                                            dimension = BaseModule.a.level.dimension();
                                                                            if (var29_15 == null) break block32;
                                                                            if (!seedText.equals(this.lastSeedText)) break block33;
                                                                            v5 = selectedOres.equals(this.lastOreSelection);
                                                                            if (var29_15 == null) break block34;
                                                                            if (!v5) break block33;
                                                                            v5 = dimension.equals(this.lastDimension);
                                                                        }
                                                                        if (v5) break block35;
                                                                    }
                                                                    this.lastSeedText = seedText;
                                                                    this.lastOreSelection = new HashSet<E>(selectedOres);
                                                                    this.lastDimension = dimension;
                                                                    v6 = new Object[1];
                                                                    v6[0] = var23_12;
                                                                    this.c(v6);
                                                                    this.warnedNoSeed = false;
                                                                }
                                                                this.warnedDimension = false;
                                                            }
                                                            v7 = new Object[2];
                                                            v7[1] = var19_10;
                                                            v7[0] = seedText;
                                                            var33_19 = kuzi.obf.p.Q.a(v7);
                                                            if (var33_19 != null) break block36;
                                                            v8 = this;
                                                            if (var29_15 == null) break block37;
                                                            if (v8.warnedNoSeed) break block38;
                                                            v9 = new Object[2];
                                                            v9[1] = var21_11;
                                                            v9[0] = "No seed set - paste the server world seed into the Seed setting.";
                                                            x_0.b(v9);
                                                            v8 = this;
                                                        }
                                                        v8.warnedNoSeed = true;
                                                    }
                                                    return;
                                                }
                                                v10 = selectedOres.isEmpty();
                                                if (var29_15 != null) {
                                                    if (v10) {
                                                        return;
                                                    }
                                                    v11 = new Object[1];
                                                    v11[0] = var11_6;
                                                    v10 = kuzi.obf.p.Q.a(v11);
                                                }
                                                if (v10) break block39;
                                                v12 = new Object[1];
                                                v12[0] = var9_5;
                                                var34_20 = kuzi.obf.p.Q.a(v12);
                                                if (var34_20 == null) break block40;
                                                v13 = this;
                                                if (var29_15 == null) break block41;
                                                if (v13.warnedWorldgen) break block40;
                                                v13 = this;
                                            }
                                            v13.warnedWorldgen = true;
                                            v14 = new Object[2];
                                            v14[1] = var15_8;
                                            v14[0] = "Worldgen bootstrap failed: " + var34_20;
                                            x_0.c(v14);
                                        }
                                        return;
                                    }
                                    v15 = new Object[2];
                                    v15[1] = dimension;
                                    v15[0] = var7_4;
                                    var34_21 = kuzi.obf.p.Q.a(v15);
                                    if (var34_21 != null) break block42;
                                    v16 = this;
                                    if (var29_15 == null) break block43;
                                    if (v16.warnedDimension) break block44;
                                    v16 = this;
                                }
                                v16.warnedDimension = true;
                                v17 = new Object[2];
                                v17[1] = var21_11;
                                v17[0] = "Ore Sim only covers the overworld and the nether; this dimension is skipped.";
                                x_0.b(v17);
                            }
                            return;
                        }
                        v18 = this;
                        if (var29_15 == null) break block45;
                        if (v18.lastScanError == null) break block46;
                        v18 = this;
                        if (var29_15 == null) break block45;
                        if (!v18.loggedScanError) {
                            this.loggedScanError = true;
                            v19 = new Object[2];
                            v19[1] = var15_8;
                            v19[0] = this.lastScanError;
                            x_0.c(v19);
                        }
                    }
                    v20 = new Object[1];
                    v20[0] = var3_2;
                    this.f(v20);
                    v18 = this;
                }
                v21 = new Object[3];
                v21[2] = var25_13;
                v21[1] = (long)var33_19;
                v21[0] = var34_21;
                v18.d(v21);
                var35_22 = System.currentTimeMillis();
                cfr_temp_0 = var35_22 - this.lastCleanupMillis - OreSim.d("v", (int)22041, (long)(5698653237678739308L ^ var1_1));
                v22 = cfr_temp_0 == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1);
                if (var29_15 == null) break block47;
                if (v22 > 0) {
                    this.lastCleanupMillis = var35_22;
                    v23 = new Object[1];
                    v23[0] = var27_14;
                    this.m(v23);
                }
                v24 = this;
                if (var29_15 == null) break block48;
                v22 = (long)((Boolean)v24.y.a()).booleanValue();
            }
            if (v22 != false && var35_22 - this.lastVerifyMillis > OreSim.d("v", (int)32050, (long)(7848878010114974787L ^ var1_1))) {
                this.lastVerifyMillis = var35_22;
                v25 = new Object[1];
                v25[0] = var5_3;
                this.o(v25);
            }
            v24 = this;
        }
        v26 = new Object[2];
        v26[1] = var17_9;
        v26[0] = var35_22;
        v24.p(v26);
    }

    private void a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = l2 = T ^ l2;
        long l4 = l3 ^ 0x37318717A0E1L;
        int n2 = (int)(l4 >>> 48);
        int n3 = (int)(l4 << 16 >>> 32);
        int n4 = (int)(l4 << 48 >>> 48);
        long l5 = l3 ^ 0x3377562B31CAL;
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l5;
        this.b(objectArray2);
        this.executor = Executors.newFixedThreadPool(2, arg_0 -> OreSim.lambda$startPool$0((short)n2, n3, (char)n4, arg_0));
    }

    private void b(Object[] objectArray) {
        block3: {
            ExecutorService executorService;
            block2: {
                long l2 = (Long)objectArray[0];
                l2 = T ^ l2;
                int[] nArray = aD.b();
                executorService = this.executor;
                if (nArray == null) break block2;
                if (executorService == null) break block3;
                executorService = this.executor;
            }
            executorService.shutdownNow();
            this.executor = null;
        }
    }

    private void c(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = T ^ l2;
        this.oreBlocks.clear();
        this.queuedChunks.clear();
        this.chunkQueue.clear();
        this.chunksTotal.set(0L);
        this.chunksDone.set(0L);
        this.lastProgressMillis = 0L;
        this.warnedNoOres = false;
        this.lastVerifyMillis = System.currentTimeMillis();
        this.lastOreChangeMillis.set(System.currentTimeMillis());
    }

    /*
     * Exception decompiling
     */
    private void f(Object[] var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * java.lang.UnsupportedOperationException
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.considerAsDoLoopStart(LoopIdentifier.java:383)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.identifyLoops1(LoopIdentifier.java:65)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:681)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private void d(Object[] objectArray) {
        r_0 r_02 = (r_0)objectArray[0];
        long l2 = (Long)objectArray[1];
        long l3 = (Long)objectArray[2];
        long l4 = (l3 = T ^ l3) ^ 0x562480A081C2L;
        int[] nArray = aD.b();
        OreSim oreSim = this;
        if (nArray != null) {
            if (oreSim.executor == null) {
                return;
            }
            oreSim = this;
        }
        Set oreSet = oreSim.lastOreSelection;
        for (int i2 = 0; i2 < 4; ++i2) {
            ChunkPos chunkPos = (ChunkPos)this.chunkQueue.poll();
            if (nArray == null) continue;
            if (chunkPos == null) {
                return;
            }
            try {
                this.executor.submit(() -> this.lambda$drainQueue$1(r_02, l4, l2, oreSet, chunkPos));
                continue;
            }
            catch (Throwable throwable) {
                this.queuedChunks.remove(chunkPos);
                return;
            }
        }
    }

    private void m(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = l2 = T ^ l2;
        long l4 = l3 ^ 0x936EC6B59C4L;
        int n2 = (int)(l4 >>> 56);
        int n3 = (int)(l4 << 8 >>> 32);
        int n4 = (int)(l4 << 40 >>> 40);
        long l5 = l3 ^ 0x40C264C40307L;
        int n5 = (int)(l5 >>> 32);
        int n6 = (int)(l5 << 32 >>> 32);
        int maxChunkRadius = (int)((Double)this.radius.a()).doubleValue() + 2;
        ChunkPos playerChunk = BaseModule.a.player.chunkPosition();
        this.queuedChunks.removeIf(arg_0 -> OreSim.lambda$cleanup$5((byte)n2, n3, n4, playerChunk, maxChunkRadius, arg_0));
        this.oreBlocks.keySet().removeIf(arg_0 -> OreSim.lambda$cleanup$6(n5, n6, playerChunk, maxChunkRadius, arg_0));
    }

    private void o(Object[] objectArray) {
        block19: {
            String message;
            long l2;
            block18: {
                int n2;
                long l3;
                block17: {
                    long l4;
                    int[] nArray;
                    long l5;
                    long l6;
                    block16: {
                        long l7;
                        block10: {
                            block11: {
                                block13: {
                                    long l8;
                                    block14: {
                                        block15: {
                                            OreSim oreSim;
                                            boolean bl;
                                            block12: {
                                                l3 = (Long)objectArray[0];
                                                long l9 = l3 = T ^ l3;
                                                l8 = l9 ^ 0x6346FA25221FL;
                                                l6 = l9 ^ 0x5CDFC55BF830L;
                                                l2 = l9 ^ 0x2AFDE63BBF19L;
                                                l5 = this.chunksTotal.get();
                                                nArray = aD.b();
                                                long l10 = l5 - 0L;
                                                l7 = l10 == 0L ? 0 : (l10 < 0L ? -1 : 1);
                                                if (nArray == null) break block10;
                                                if (l7 != false) break block11;
                                                bl = this.warnedNoOres;
                                                if (nArray == null) break block12;
                                                if (bl) break block13;
                                                if (l3 < 0L) break block14;
                                                oreSim = this;
                                                if (nArray == null) break block15;
                                                bl = oreSim.queuedChunks.isEmpty();
                                            }
                                            if (bl) break block13;
                                            oreSim = this;
                                        }
                                        oreSim.warnedNoOres = true;
                                    }
                                    Object[] objectArray2 = new Object[2];
                                    objectArray2[1] = l8;
                                    objectArray2[0] = OreSim.b("f", (int)14040, (long)(0x7AED8C82589C12ABL ^ l3));
                                    x_0.b(objectArray2);
                                }
                                return;
                            }
                            l4 = l5;
                            if (nArray == null) break block16;
                            long l11 = l4 - this.lastProgressMillis;
                            l7 = l11 == 0L ? 0 : (l11 < 0L ? -1 : 1);
                        }
                        if (l7 == false) {
                            return;
                        }
                        this.lastProgressMillis = l5;
                        l4 = this.chunksDone.get();
                    }
                    long l12 = l4;
                    int percent = (int)Math.round(100.0 * (double)l12 / (double)l5);
                    long l13 = l5;
                    long l14 = l12;
                    int percentCopy = percent;
                    n2 = 19832;
                    if (l3 < 0L) break block17;
                    message = (String)((Object)OreSim.b("f", (int)n2, (long)(0x1CE052C3EE70E91FL ^ l3))) + percentCopy + (String)((Object)OreSim.b("f", (int)21137, (long)(0x26AE9EFC21B276E0L ^ l3))) + l14 + "/" + l13 + (String)((Object)OreSim.b("f", (int)23446, (long)(0x2B22EBE2AD84FFEEL ^ l3)));
                    if (nArray == null) break block18;
                    Object[] objectArray3 = new Object[2];
                    objectArray3[1] = message;
                    objectArray3[0] = l6;
                    x_0.a(objectArray3);
                    n2 = percent;
                }
                if (n2 >= OreSim.c("r", (int)20418, (long)(0x24F0F2C3098E425BL ^ l3))) break block19;
                message = OreSim.b("f", (int)18688, (long)(0x7E8DD896AD28ED76L ^ l3));
            }
            Object[] objectArray4 = new Object[2];
            objectArray4[1] = l2;
            objectArray4[0] = message;
            x_0.c(objectArray4);
        }
    }

    @Override
    public void a(h packetEvent) {
        block9: {
            Packet rawPacket;
            long l2;
            block10: {
                boolean bl;
                Packet rawPacket2;
                block7: {
                    int[] nArray;
                    block8: {
                        block6: {
                            block5: {
                                boolean bl2;
                                block4: {
                                    long l3 = T ^ 0x2607D5106805L;
                                    l2 = l3 ^ 0x6ABD571D4B49L;
                                    nArray = aD.b();
                                    bl2 = this.d();
                                    if (nArray == null) break block4;
                                    if (!bl2) break block5;
                                    bl2 = this.oreBlocks.isEmpty();
                                }
                                if (!bl2) break block6;
                            }
                            return;
                        }
                        rawPacket2 = packetEvent.c;
                        bl = rawPacket2 instanceof ClientboundBlockUpdatePacket;
                        if (nArray == null) break block7;
                        if (!bl) break block8;
                        ClientboundBlockUpdatePacket blockUpdate = (ClientboundBlockUpdatePacket)rawPacket2;
                        this.a(l2, blockUpdate.getPos(), blockUpdate.getBlockState());
                        if (nArray != null) break block9;
                    }
                    rawPacket = rawPacket2 = packetEvent.c;
                    if (nArray == null) break block10;
                    bl = rawPacket instanceof ClientboundSectionBlocksUpdatePacket;
                }
                if (!bl) break block9;
                rawPacket = rawPacket2;
            }
            ClientboundSectionBlocksUpdatePacket sectionUpdate = (ClientboundSectionBlocksUpdatePacket)rawPacket;
            sectionUpdate.runUpdates((arg_0, arg_1) -> this.a(l2, arg_0, arg_1));
        }
    }

    private void a(long l2, BlockPos pos, BlockState state) {
        block6: {
            block5: {
                l2 = T ^ l2;
                Block previousBlock = (Block)this.oreBlocks.get(pos);
                int[] nArray = aD.b();
                Object currentBlock = previousBlock;
                if (nArray != null) {
                    if (currentBlock == null) {
                        return;
                    }
                    currentBlock = state.getBlock();
                }
                if (nArray == null) break block5;
                if (currentBlock == previousBlock) break block6;
                currentBlock = this.oreBlocks.remove(pos);
            }
            this.lastOreChangeMillis.set(System.currentTimeMillis());
        }
    }

    private void p(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = (Long)objectArray[1];
        long l4 = l3 = T ^ l3;
        long l5 = l4 ^ 0x6F6FC01D094AL;
        long l6 = l4 ^ 0x21ABB77B3DC0L;
        int[] nArray = aD.b();
        OreSim oreSim = this;
        if (nArray != null) {
            Object[] objectArray2 = new Object[2];
            objectArray2[1] = l5;
            objectArray2[0] = kuzi.obf.j.g.z.XRAY;
            if (!oreSim.renderMode.b(objectArray2)) {
                return;
            }
            oreSim = this;
        }
        long l7 = oreSim.lastOreChangeMillis.get();
        long l8 = l7 - this.lastXrayRefreshMillis;
        long l9 = l8 == 0L ? 0 : (l8 < 0L ? -1 : 1);
        int[] nArray2 = nArray;
        if (l3 > 0L) {
            if (nArray2 != null) {
                if (l9 <= 0) {
                    return;
                }
                long l10 = l2 - l7 - OreSim.d("v", (int)9771, (long)(0xB51E456907B825AL ^ l3));
                l9 = l10 == 0L ? 0 : (l10 < 0L ? -1 : 1);
            }
            nArray2 = nArray;
        }
        if (nArray2 != null) {
            if (l9 < 0) {
                return;
            }
            long l11 = l2 - this.lastXrayRefreshMillis - OreSim.d("v", (int)12842, (long)(0x60E1A31423F39659L ^ l3));
            l9 = l11 == 0L ? 0 : (l11 < 0L ? -1 : 1);
        }
        if (l9 < 0) {
            return;
        }
        this.lastXrayRefreshMillis = l2;
        Object[] objectArray3 = new Object[1];
        objectArray3[0] = l6;
        this.q(objectArray3);
    }

    private void q(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = (l2 = T ^ l2) ^ 0x7BD6068CA2C8L;
        int n2 = (int)(l3 >>> 32);
        int n3 = (int)(l3 << 32 >>> 48);
        int n4 = (int)(l3 << 48 >>> 48);
        int[] nArray = aD.b();
        Minecraft mc = BaseModule.a;
        if (nArray != null) {
            if (mc.levelRenderer == null) {
                return;
            }
            mc = BaseModule.a;
        }
        mc.execute(() -> OreSim.lambda$reloadChunks$7(n2, (char)n3, (char)n4));
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @MixinExposed
    public static OreSim a() {
        OreSim oreSim;
        OreSim oreSim2 = instance;
        int[] nArray = aD.b();
        OreSim oreSim3 = oreSim2;
        if (nArray != null) {
            if (oreSim3 == null) return null;
            oreSim3 = oreSim2;
        }
        boolean bl = oreSim3.d();
        if (nArray != null) {
            if (!bl) return null;
            bl = ((z)((Object)oreSim2.renderMode.a())).name().equals("XRAY");
        }
        if (nArray != null) {
            if (!bl) return null;
            oreSim = oreSim2;
            if (nArray == null) return oreSim;
            bl = oreSim.oreBlocks.isEmpty();
        }
        if (bl) return null;
        oreSim = oreSim2;
        return oreSim;
    }

    @MixinExposed
    public Block a(BlockPos pos) {
        return (Block)this.oreBlocks.get(pos);
    }

    public Map a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = T ^ l2;
        return this.oreBlocks;
    }

    public boolean a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = T ^ l2;
        return ((z)((Object)this.renderMode.a())).name().equals(OreSim.b("f", (int)18219, (long)(0x1E47BE5D8F5886E9L ^ l2)));
    }

    public Color a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = T ^ l2;
        return this.color.a();
    }

    private static Set a(Object[] objectArray) {
        LinkedHashSet<Block> linkedHashSet = new LinkedHashSet<Block>();
        linkedHashSet.add(Blocks.DIAMOND_ORE);
        linkedHashSet.add(Blocks.DEEPSLATE_DIAMOND_ORE);
        linkedHashSet.add(Blocks.ANCIENT_DEBRIS);
        linkedHashSet.add(Blocks.EMERALD_ORE);
        linkedHashSet.add(Blocks.DEEPSLATE_EMERALD_ORE);
        linkedHashSet.add(Blocks.GOLD_ORE);
        linkedHashSet.add(Blocks.DEEPSLATE_GOLD_ORE);
        linkedHashSet.add(Blocks.NETHER_GOLD_ORE);
        linkedHashSet.add(Blocks.IRON_ORE);
        linkedHashSet.add(Blocks.DEEPSLATE_IRON_ORE);
        linkedHashSet.add(Blocks.REDSTONE_ORE);
        linkedHashSet.add(Blocks.DEEPSLATE_REDSTONE_ORE);
        linkedHashSet.add(Blocks.LAPIS_ORE);
        linkedHashSet.add(Blocks.DEEPSLATE_LAPIS_ORE);
        linkedHashSet.add(Blocks.COAL_ORE);
        linkedHashSet.add(Blocks.DEEPSLATE_COAL_ORE);
        linkedHashSet.add(Blocks.COPPER_ORE);
        linkedHashSet.add(Blocks.DEEPSLATE_COPPER_ORE);
        linkedHashSet.add(Blocks.NETHER_QUARTZ_ORE);
        return linkedHashSet;
    }

    private static void lambda$reloadChunks$7(int n2, char c2, char c3) {
        block5: {
            LevelRenderer levelRenderer;
            block4: {
                long l2 = ((long)n2 << 32 | (long)c2 << 48 >>> 32 | (long)c3 << 48 >>> 48) ^ T;
                CallSite callSite = OreSim.f("\u00e4", (long)-9010318434153005352L, (long)l2);
                try {
                    try {
                        levelRenderer = ((Minecraft)OreSim.f("\u00e8", (long)-9008407492256512637L, (long)l2)).levelRenderer;
                        if (callSite == null) break block4;
                        if (levelRenderer == null) break block5;
                    }
                    catch (UnsupportedOperationException unsupportedOperationException) {
                        throw OreSim.f("\u00e4", (Object)unsupportedOperationException, (long)-9008299135123478663L, (long)l2);
                    }
                    levelRenderer = ((Minecraft)OreSim.f("\u00e8", (long)-9008407492256512637L, (long)l2)).levelRenderer;
                }
                catch (UnsupportedOperationException unsupportedOperationException) {
                    throw OreSim.f("\u00e4", (Object)unsupportedOperationException, (long)-9008299135123478663L, (long)l2);
                }
            }
            levelRenderer.allChanged();
        }
    }

    private static boolean lambda$cleanup$6(int n2, int n3, ChunkPos playerChunk, int maxChunkRadius, BlockPos pos) {
        int outOfRange;
        block8: {
            block10: {
                long l2 = ((long)n2 << 32 | (long)n3 << 32 >>> 32) ^ T;
                CallSite callSite = OreSim.f("\u00e4", (long)6310644616940891071L, (long)l2);
                try {
                    block9: {
                        try {
                            try {
                                try {
                                    outOfRange = Math.abs((pos.getX() >> 4) - playerChunk.x);
                                    if (callSite == null) break block8;
                                    if (outOfRange > maxChunkRadius) break block9;
                                }
                                catch (UnsupportedOperationException unsupportedOperationException) {
                                    throw OreSim.f("\u00e4", (Object)unsupportedOperationException, (long)6312662862193521182L, (long)l2);
                                }
                                outOfRange = Math.abs((pos.getZ() >> 4) - playerChunk.z);
                                if (callSite == null) break block8;
                            }
                            catch (UnsupportedOperationException unsupportedOperationException) {
                                throw OreSim.f("\u00e4", (Object)unsupportedOperationException, (long)6312662862193521182L, (long)l2);
                            }
                            if (outOfRange <= maxChunkRadius) break block10;
                        }
                        catch (UnsupportedOperationException unsupportedOperationException) {
                            throw OreSim.f("\u00e4", (Object)unsupportedOperationException, (long)6312662862193521182L, (long)l2);
                        }
                    }
                    outOfRange = 1;
                    break block8;
                }
                catch (UnsupportedOperationException unsupportedOperationException) {
                    throw OreSim.f("\u00e4", (Object)unsupportedOperationException, (long)6312662862193521182L, (long)l2);
                }
            }
            outOfRange = 0;
        }
        return outOfRange != 0;
    }

    private static boolean lambda$cleanup$5(byte by, int n2, int n3, ChunkPos playerChunk, int maxChunkRadius, ChunkPos chunkPos) {
        int outOfRange;
        block8: {
            block10: {
                long l2 = ((long)by << 56 | (long)n2 << 32 >>> 8 | (long)n3 << 40 >>> 40) ^ T;
                CallSite callSite = OreSim.f("\u00e4", (long)959442833630130556L, (long)l2);
                try {
                    block9: {
                        try {
                            try {
                                try {
                                    outOfRange = Math.abs(chunkPos.x - playerChunk.x);
                                    if (callSite == null) break block8;
                                    if (outOfRange > maxChunkRadius) break block9;
                                }
                                catch (UnsupportedOperationException unsupportedOperationException) {
                                    throw OreSim.f("\u00e4", (Object)unsupportedOperationException, (long)961620336258263261L, (long)l2);
                                }
                                outOfRange = Math.abs(chunkPos.z - playerChunk.z);
                                if (callSite == null) break block8;
                            }
                            catch (UnsupportedOperationException unsupportedOperationException) {
                                throw OreSim.f("\u00e4", (Object)unsupportedOperationException, (long)961620336258263261L, (long)l2);
                            }
                            if (outOfRange <= maxChunkRadius) break block10;
                        }
                        catch (UnsupportedOperationException unsupportedOperationException) {
                            throw OreSim.f("\u00e4", (Object)unsupportedOperationException, (long)961620336258263261L, (long)l2);
                        }
                    }
                    outOfRange = 1;
                    break block8;
                }
                catch (UnsupportedOperationException unsupportedOperationException) {
                    throw OreSim.f("\u00e4", (Object)unsupportedOperationException, (long)961620336258263261L, (long)l2);
                }
            }
            outOfRange = 0;
        }
        return outOfRange != 0;
    }

    private void lambda$drainQueue$1(r_0 r_02, long l2, long l3, Set oreSet, ChunkPos chunkPos) {
        long l4 = (l2 = T ^ l2) ^ 0x54C0B2B10011L;
        Object[] objectArray = new Object[5];
        objectArray[4] = chunkPos;
        objectArray[3] = l4;
        objectArray[2] = oreSet;
        objectArray[1] = l3;
        objectArray[0] = r_02;
        OreSim.f("f", (Object)this, (Object)objectArray, (long)-5712134915261680420L, (long)l2);
    }

    private static Thread lambda$startPool$0(short s2, int n2, char c2, Runnable runnable) {
        long l2 = ((long)s2 << 48 | (long)n2 << 32 >>> 16 | (long)c2 << 48 >>> 48) ^ T;
        Thread thread = new Thread(runnable, (String)((Object)OreSim.b("f", (int)4831, (long)(0x2A217346DBB0034AL ^ l2))));
        thread.setDaemon(true);
        thread.setPriority(4);
        return thread;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block31: {
            block30: {
                block29: {
                    block28: {
                        block27: {
                            block26: {
                                OreSim.T = kuzi.obf.h.b.v.a(5179112667788025297L, -286822871278737642L, MethodHandles.lookup().lookupClass()).a(173432343366572L);
                                OreSim.hb = new Object[125];
                                OreSim.ib = new String[125];
                                OreSim.c();
                                OreSim.W = new HashMap<K, V>(13);
                                var22 = OreSim.T ^ 36700206199912L;
                                var24_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                                v0 = SecretKeyFactory.getInstance("DES");
                                v1 = new byte[8];
                                v2 = v1;
                                v1[0] = (byte)(var22 >>> 56);
                                for (var25_2 = 1; var25_2 < 8; ++var25_2) {
                                    v2 = v2;
                                    v2[var25_2] = (byte)(var22 << var25_2 * 8 >>> 56);
                                }
                                var24_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                                var31_3 = new String[22];
                                var29_4 = 0;
                                var28_5 = "\u00cd\u00fa8\u00dd\u00f1\u008c\u0090\u00c6\u008b\u0094\u00ca\u009d\u00e3\u000f \u009ap{\u00a78t\u00d6\u00c6\u00aa\u00bd.~F'A\u00195\u00be\u00cd\u00c4\u008e\u0084I\u009e\u00a7;>=\u00e4U\u00dak}\u00cbL1\u008c\u00be\u0081\u00f2V\u0013\u008e\u008aC\u00c7\u0082\f\u00d8\u00ca\u00aa\u00fd\u00c1[\u00few\u0098\u00eeb3\u00a9:,\u009bV@\u000eW\u008f\u00a1^\u00f0\u00c65\u00e4\u0081:\u001c\u00a8 nT|/\u0093\u0013\u008dF\u00a9\u0015\u00e4\u00d2'+1[8\u00e7/\u0082\u00b9\u00fc\u00bdp\u00f6&\u00ad\u008b\u00d2Q\u00de\u00d5)9\u0010\u00a63\u00a8M\u00aaf\u00d7\u00a4\u00fc\u00e5KE\u00fdE[E\u0010\u0096\u00f5zY\u00ed\u0014\u0085\u00a2\u0000\u00ac;F\u00a6\u001e\u0019\rx\f\u008b\u00d3A\u0088n\u00cd\u0080C%M\u00d8\u009c\u00fe7\u00f2\u00cel\u00a0=\u00b62\u009f\u00b0\u00e1a\u0019d\u001a\u00a9\u0088\u00f5}\u0098\u0080\u00b7\u00b7+\u00e9G\u0001P\u00f4{\bS\u009f\u00b8\u00fc!\u00ccc3\u00bb\u000e\u0091G\u009f<m6\u00c3\u00f6\u00e9\u00faZ\u0085,{x Q\u0014\u00fc\u00d4RTEW\u00e8\u00bf\u0095\u0000w\u0016\u00a0o\u00ea\u00bc\u00df\u00c2rU\u00fb>,\n\u001frC\u0098<0\u00e9H\u00d4\u00f3U\u0097\u00ea\u0099\u00a5\n2\u00be\u008aHTA\u009d(\u0089\u000f\u00e44\u00f8\u0080\u00ff\u00c6V\u0003\u00a0/p\u009c\u0093\u00e88\u00c8\u00b2v\u00eb\u008f\u0016c(\u00e2}\u0016\u00a5\u00ec\u00a4\u00b2\u00e6+\f\u00aeKr\u00ea\u00a2\u0010O\u0011\u00a8\u0015R\u00cb\u00af(\u00df6\u00c1\u0011\u00edy\u009ciPEn\r\u0017\f/\u00a6\u0017\u00e3\u00f2_\u0092Z\u00d0\u00e4\u008e\u0096\u00beA\u0017\u00faPx\u00c7\u00e6\u00e7\u0004UZ\u00aa&\u00d7A\u0000$\u00f9\u00d2\u00ed%\u00c8A\u0089C\u00e4g\u0098\u00c5\u0094\u00fe\u00d4\u00a2\u00db\u00cc\u008a\u00ce!\u00cb+\u00a1w\u00ef\u00bb\u00f3\u00a9\u00d8\u0096\u00c2\u00f0 /\u000e\u0002\u0082\u00bd\u0018\u001b\\j4?\u0010J\u00f6\u0099\u0098\u00c8|\u00dc\u00a4\u00bf\u000f\tVOm\u00b4\u00da\u0010$\u0002,p\u00d06\u0083\u00e1-\u0011\u00eej\u00d5\u0091\u00ddc\u0010\u00d2W\u00b0\u0094\u00a1=\u0099vg'\u00cf\u00e8\u00a1\u009f\u00af\u00d0\u0010k\u0093I{\u001c\u00dd#}WWV\u00ce\u00b2\u0091\u00cb[\u0088\u00b8\u0083v\u00b5\u00d38\u00e2r\u00f9\u00d6\f\u00f7A.\u00aa\u007f[1_\u00b5\u00b0\u00ee\u0098\u0006^X=6\u0015'e\b\u00ff@\u001435\u00f59\u00b7\u00c6\u0005\u0010\\\u0099\u009a\u0004\u00db\u0085\u009f\u00a5N\u00b3Y\u0080\u00c5\u0090\u0082\u00f3\u0099\u00ef\u00cf\u009e\u00ea@_\u00eeK{:\u00d3\u00aa3<Xf_pb\u009f\u000e\u00ba\r\u00cb2\u0017(nU\u00c0\u00f1\u00eabnT\u0007\u0006\u00d1$\u008e\u00162\u00bc\u0014~\u00b5L\u00a9\u00c3\u00fe\u009a\u00ac.\u00f3\u00ab\u0094\u00c0\u00a9Wh\u0002\u009dx\u0013\u0013Q\u00cf\u00ea7I\u008b\u00ec{\u00d1j\u00970d\u008f\u00b4\u00c1,@{%\u0095\u009cM\u0000>u\u00f6M\u00ad\u008b\u00ae,\u00d6m\u00bcT\u00b2\u00b2\u00f7-\u001cV;my\u00ed\u00a0\u00b4wM\u0092\u00cb\f\u0085Y\u00d01\u001b\u00b5\u00f0p\u00d7\u00933\u00dc{\u009a3\u007fN\u0003\u00deD\u00d7\u00c5\u00ae\u00a6'\u0098H\u00eb\b+$\u00c3x/\u008du\u0011\u00e0\t\u008c]\u00e7^\u0092\u0018\u0007%%\u00b4\u00a2a\u00c30\b~%\u0094\u0004\u0000\u001f\u00c0u\u00d8\u00e5+Y\u00b3\u00c9@\u0014\u0093Y\u0006\u0017K\u00da\u00978\u0010\u00fc\u00e9\u00fb\t\u00c9\u00c4\u00c3k0E\u00a0fQ\u0097(\u001b\u00bb#\u0080\u008c\u00bfY\u00c9\u00ae\u000b\u00feEo\u001dW&\u008ak\u00b6\u00ea\u00c9H\u00e6.\u008e{8\u0084\u00ael\u00bee\u0015S\u00e1J-w\u007f\u0092\u00cb+\u009b\u0091\u0000\u00b9\u00d0\"\u0087\u00c4A5\u0004\u00f0\u009d\u00faY\u00a6\u00ca\u00c5\u00aa\u00ad\u00c2\u00e6\u00b1\u0018\u00eb\u009b\u00aa\u00d0\u00f5\u00ad_\u00b5\u00ea\u00ebp\u00fa\u00ea7\u00e8\u001cn\u00188\u00f7q\u00c2SZ\u00a7\u00a4\u00e4\u00a3]\u00cf\u00c0\u00f3\u00ee%^\u0091\u00f6\n\u0090\u00da\u0000\u0093x\u00a2\u00e0\u00e4t\u008aMY\u00d3A\u0019EP;\u00ca\u00fa\u0000\u00faq\u00d6zzZ^\u00d1\u0091Vt*\u00fc\u00c3=\u00da\u00eb?\u0085DH\u00acJ\u009d\u00c9\u0001\u001c\u00a1\u0019\u00e9\u0089tB\u007f\u009e\u00b6\u0086\u00ad\u0019\u0000(\u0086;r\u00bb\b\u009d-1\u00ca\u0098J\u008am\u00c6\u00f2\u00e3\u00e2\b\u00d7\t\u0094U\u00bb\u00b5\u00baJ\u00e0\u0087w\u001d\u00d6\u009f\u00e4?\u00c5\u00c5\u00fd\u00b9\u00d6D\u00a2\u00b7!\u0095+C\u00b0\u009di\u00e0)\u0010\u001eC\u0089\u009aF\u008f^\u009a@\u00c2, kr<\u001f\u00b1\u00dd\u00c7LG\u0006\u00a1^\u00ef\u0080}\u0099m\u0094L\u00d9\u00d0l\u00be]\u00ff\u0018\u0098\u0005\u00f7\u00ec\u00a7\u0014p\u00e7\u00cc\u00cc\u001f\u0099\u00cc\u00bdA\u0011\u00d4\u00a1\r\u0013sU\u0016\u0084\u0001\u0096\u0087\u00f7\u00e0\u00f0\u00b9\u00c5,\u0014&\u00ae\u00f7\u00c6li2(^\u00d2\\\u00b7\u0080|\u00b6\u00eb8\u009c\u00e9\b\u00a9\u00d3ll\u00f5\u00b5\u00b4\u00fb\u00d5\u009f\u00d6\u00bb3\u00d6\u00e6\u008d\u00a1\u00d7\u009c\u00e6js\u009e)\u009cc\u0003l\u00ce\u0002\u009b\b\t\r\u0091\u0099\u00f7\u00b0\u00b3\u00e5\u008f\u00a8\fA\u0088Z\u00fc\u00fb\u0096\u00f3\u0007\u00e8\u00ab\u0090r!\u0006^\u00d3b\u0006p%~\u00ee";
                                var30_6 = "\u00cd\u00fa8\u00dd\u00f1\u008c\u0090\u00c6\u008b\u0094\u00ca\u009d\u00e3\u000f \u009ap{\u00a78t\u00d6\u00c6\u00aa\u00bd.~F'A\u00195\u00be\u00cd\u00c4\u008e\u0084I\u009e\u00a7;>=\u00e4U\u00dak}\u00cbL1\u008c\u00be\u0081\u00f2V\u0013\u008e\u008aC\u00c7\u0082\f\u00d8\u00ca\u00aa\u00fd\u00c1[\u00few\u0098\u00eeb3\u00a9:,\u009bV@\u000eW\u008f\u00a1^\u00f0\u00c65\u00e4\u0081:\u001c\u00a8 nT|/\u0093\u0013\u008dF\u00a9\u0015\u00e4\u00d2'+1[8\u00e7/\u0082\u00b9\u00fc\u00bdp\u00f6&\u00ad\u008b\u00d2Q\u00de\u00d5)9\u0010\u00a63\u00a8M\u00aaf\u00d7\u00a4\u00fc\u00e5KE\u00fdE[E\u0010\u0096\u00f5zY\u00ed\u0014\u0085\u00a2\u0000\u00ac;F\u00a6\u001e\u0019\rx\f\u008b\u00d3A\u0088n\u00cd\u0080C%M\u00d8\u009c\u00fe7\u00f2\u00cel\u00a0=\u00b62\u009f\u00b0\u00e1a\u0019d\u001a\u00a9\u0088\u00f5}\u0098\u0080\u00b7\u00b7+\u00e9G\u0001P\u00f4{\bS\u009f\u00b8\u00fc!\u00ccc3\u00bb\u000e\u0091G\u009f<m6\u00c3\u00f6\u00e9\u00faZ\u0085,{x Q\u0014\u00fc\u00d4RTEW\u00e8\u00bf\u0095\u0000w\u0016\u00a0o\u00ea\u00bc\u00df\u00c2rU\u00fb>,\n\u001frC\u0098<0\u00e9H\u00d4\u00f3U\u0097\u00ea\u0099\u00a5\n2\u00be\u008aHTA\u009d(\u0089\u000f\u00e44\u00f8\u0080\u00ff\u00c6V\u0003\u00a0/p\u009c\u0093\u00e88\u00c8\u00b2v\u00eb\u008f\u0016c(\u00e2}\u0016\u00a5\u00ec\u00a4\u00b2\u00e6+\f\u00aeKr\u00ea\u00a2\u0010O\u0011\u00a8\u0015R\u00cb\u00af(\u00df6\u00c1\u0011\u00edy\u009ciPEn\r\u0017\f/\u00a6\u0017\u00e3\u00f2_\u0092Z\u00d0\u00e4\u008e\u0096\u00beA\u0017\u00faPx\u00c7\u00e6\u00e7\u0004UZ\u00aa&\u00d7A\u0000$\u00f9\u00d2\u00ed%\u00c8A\u0089C\u00e4g\u0098\u00c5\u0094\u00fe\u00d4\u00a2\u00db\u00cc\u008a\u00ce!\u00cb+\u00a1w\u00ef\u00bb\u00f3\u00a9\u00d8\u0096\u00c2\u00f0 /\u000e\u0002\u0082\u00bd\u0018\u001b\\j4?\u0010J\u00f6\u0099\u0098\u00c8|\u00dc\u00a4\u00bf\u000f\tVOm\u00b4\u00da\u0010$\u0002,p\u00d06\u0083\u00e1-\u0011\u00eej\u00d5\u0091\u00ddc\u0010\u00d2W\u00b0\u0094\u00a1=\u0099vg'\u00cf\u00e8\u00a1\u009f\u00af\u00d0\u0010k\u0093I{\u001c\u00dd#}WWV\u00ce\u00b2\u0091\u00cb[\u0088\u00b8\u0083v\u00b5\u00d38\u00e2r\u00f9\u00d6\f\u00f7A.\u00aa\u007f[1_\u00b5\u00b0\u00ee\u0098\u0006^X=6\u0015'e\b\u00ff@\u001435\u00f59\u00b7\u00c6\u0005\u0010\\\u0099\u009a\u0004\u00db\u0085\u009f\u00a5N\u00b3Y\u0080\u00c5\u0090\u0082\u00f3\u0099\u00ef\u00cf\u009e\u00ea@_\u00eeK{:\u00d3\u00aa3<Xf_pb\u009f\u000e\u00ba\r\u00cb2\u0017(nU\u00c0\u00f1\u00eabnT\u0007\u0006\u00d1$\u008e\u00162\u00bc\u0014~\u00b5L\u00a9\u00c3\u00fe\u009a\u00ac.\u00f3\u00ab\u0094\u00c0\u00a9Wh\u0002\u009dx\u0013\u0013Q\u00cf\u00ea7I\u008b\u00ec{\u00d1j\u00970d\u008f\u00b4\u00c1,@{%\u0095\u009cM\u0000>u\u00f6M\u00ad\u008b\u00ae,\u00d6m\u00bcT\u00b2\u00b2\u00f7-\u001cV;my\u00ed\u00a0\u00b4wM\u0092\u00cb\f\u0085Y\u00d01\u001b\u00b5\u00f0p\u00d7\u00933\u00dc{\u009a3\u007fN\u0003\u00deD\u00d7\u00c5\u00ae\u00a6'\u0098H\u00eb\b+$\u00c3x/\u008du\u0011\u00e0\t\u008c]\u00e7^\u0092\u0018\u0007%%\u00b4\u00a2a\u00c30\b~%\u0094\u0004\u0000\u001f\u00c0u\u00d8\u00e5+Y\u00b3\u00c9@\u0014\u0093Y\u0006\u0017K\u00da\u00978\u0010\u00fc\u00e9\u00fb\t\u00c9\u00c4\u00c3k0E\u00a0fQ\u0097(\u001b\u00bb#\u0080\u008c\u00bfY\u00c9\u00ae\u000b\u00feEo\u001dW&\u008ak\u00b6\u00ea\u00c9H\u00e6.\u008e{8\u0084\u00ael\u00bee\u0015S\u00e1J-w\u007f\u0092\u00cb+\u009b\u0091\u0000\u00b9\u00d0\"\u0087\u00c4A5\u0004\u00f0\u009d\u00faY\u00a6\u00ca\u00c5\u00aa\u00ad\u00c2\u00e6\u00b1\u0018\u00eb\u009b\u00aa\u00d0\u00f5\u00ad_\u00b5\u00ea\u00ebp\u00fa\u00ea7\u00e8\u001cn\u00188\u00f7q\u00c2SZ\u00a7\u00a4\u00e4\u00a3]\u00cf\u00c0\u00f3\u00ee%^\u0091\u00f6\n\u0090\u00da\u0000\u0093x\u00a2\u00e0\u00e4t\u008aMY\u00d3A\u0019EP;\u00ca\u00fa\u0000\u00faq\u00d6zzZ^\u00d1\u0091Vt*\u00fc\u00c3=\u00da\u00eb?\u0085DH\u00acJ\u009d\u00c9\u0001\u001c\u00a1\u0019\u00e9\u0089tB\u007f\u009e\u00b6\u0086\u00ad\u0019\u0000(\u0086;r\u00bb\b\u009d-1\u00ca\u0098J\u008am\u00c6\u00f2\u00e3\u00e2\b\u00d7\t\u0094U\u00bb\u00b5\u00baJ\u00e0\u0087w\u001d\u00d6\u009f\u00e4?\u00c5\u00c5\u00fd\u00b9\u00d6D\u00a2\u00b7!\u0095+C\u00b0\u009di\u00e0)\u0010\u001eC\u0089\u009aF\u008f^\u009a@\u00c2, kr<\u001f\u00b1\u00dd\u00c7LG\u0006\u00a1^\u00ef\u0080}\u0099m\u0094L\u00d9\u00d0l\u00be]\u00ff\u0018\u0098\u0005\u00f7\u00ec\u00a7\u0014p\u00e7\u00cc\u00cc\u001f\u0099\u00cc\u00bdA\u0011\u00d4\u00a1\r\u0013sU\u0016\u0084\u0001\u0096\u0087\u00f7\u00e0\u00f0\u00b9\u00c5,\u0014&\u00ae\u00f7\u00c6li2(^\u00d2\\\u00b7\u0080|\u00b6\u00eb8\u009c\u00e9\b\u00a9\u00d3ll\u00f5\u00b5\u00b4\u00fb\u00d5\u009f\u00d6\u00bb3\u00d6\u00e6\u008d\u00a1\u00d7\u009c\u00e6js\u009e)\u009cc\u0003l\u00ce\u0002\u009b\b\t\r\u0091\u0099\u00f7\u00b0\u00b3\u00e5\u008f\u00a8\fA\u0088Z\u00fc\u00fb\u0096\u00f3\u0007\u00e8\u00ab\u0090r!\u0006^\u00d3b\u0006p%~\u00ee".length();
                                var27_7 = 16;
                                var26_8 = -1;
lbl23:
                                // 2 sources

                                while (true) {
                                    v3 = ++var26_8;
                                    v4 = var28_5.substring(v3, v3 + var27_7);
                                    v5 = -1;
                                    break block26;
                                    break;
                                }
lbl28:
                                // 1 sources

                                while (true) {
                                    var31_3[var29_4++] = OreSim.b(var32_9).intern();
                                    if ((var26_8 += var27_7) < var30_6) {
                                        var27_7 = var28_5.charAt(var26_8);
                                        ** continue;
                                    }
                                    var28_5 = "(-\u00a2e\u00dc\u00f3\u00b0\u0090\u00da\u00b6\u009e\u0012\u00cbi\u00a5I0\u0019\u00dc\u00d2\u00c4\u00b2\u00caD\u0085\u0094\u00a7Z?k'\u00b8\u00b7\u008d\u008f)DT\u0086\u0019\u00dbN\u0097\u00be%\u00e3\u0011+8\u00ca\u009d\u00fd$U'\u009b\u008a\u00c8\u00ef\u0094J\u0090a\u0002\u00e2";
                                    var30_6 = "(-\u00a2e\u00dc\u00f3\u00b0\u0090\u00da\u00b6\u009e\u0012\u00cbi\u00a5I0\u0019\u00dc\u00d2\u00c4\u00b2\u00caD\u0085\u0094\u00a7Z?k'\u00b8\u00b7\u008d\u008f)DT\u0086\u0019\u00dbN\u0097\u00be%\u00e3\u0011+8\u00ca\u009d\u00fd$U'\u009b\u008a\u00c8\u00ef\u0094J\u0090a\u0002\u00e2".length();
                                    var27_7 = 16;
                                    var26_8 = -1;
lbl37:
                                    // 2 sources

                                    while (true) {
                                        v6 = ++var26_8;
                                        v4 = var28_5.substring(v6, v6 + var27_7);
                                        v5 = 0;
                                        break block26;
                                        break;
                                    }
                                    break;
                                }
lbl42:
                                // 1 sources

                                while (true) {
                                    var31_3[var29_4++] = OreSim.b(var32_9).intern();
                                    if ((var26_8 += var27_7) < var30_6) {
                                        var27_7 = var28_5.charAt(var26_8);
                                        ** continue;
                                    }
                                    break block27;
                                    break;
                                }
                            }
                            var32_9 = var24_1.doFinal(v4.getBytes("ISO-8859-1"));
                            switch (v5) {
                                default: {
                                    ** continue;
                                }
                                ** case 0:
lbl54:
                                // 1 sources

                                ** continue;
                            }
                        }
                        OreSim.U = var31_3;
                        OreSim.V = new String[22];
                        OreSim.Z = new HashMap<K, V>(13);
                        var11_10 = Cipher.getInstance("DES/CBC/NoPadding");
                        v7 = SecretKeyFactory.getInstance("DES");
                        v8 = new byte[8];
                        v9 = v8;
                        v8[0] = (byte)(var22 >>> 56);
                        for (var12_11 = 1; var12_11 < 8; ++var12_11) {
                            v9 = v9;
                            v9[var12_11] = (byte)(var22 << var12_11 * 8 >>> 56);
                        }
                        var11_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                        var17_12 = new long[12];
                        var14_13 = 0;
                        var15_14 = "\u001b\u00cb\u0082\u00b1\u00cd\u0088\u0080\u00a0\u000f\u00f9[@\u00de\u00c1\u00f0q3\u00d4\u00cf[\u0012\u0080`-w\u00a5\u00d25\u00b5\u00a2c\u00e6pl.\u00c9B\u00a4O\u00ce\u008c\u0094T\u00bb\t\u00a3\u00e9p\u00b4\u00ca\u00c3\u0094>o\u008d#J\u0089\u00d2~%7\u0091\u00e3\u00c4\u00ecp\u0013\u00eb\u0012\u00be\u007f\u0005EwH\u00ff\u0095?\u00f1";
                        var16_15 = "\u001b\u00cb\u0082\u00b1\u00cd\u0088\u0080\u00a0\u000f\u00f9[@\u00de\u00c1\u00f0q3\u00d4\u00cf[\u0012\u0080`-w\u00a5\u00d25\u00b5\u00a2c\u00e6pl.\u00c9B\u00a4O\u00ce\u008c\u0094T\u00bb\t\u00a3\u00e9p\u00b4\u00ca\u00c3\u0094>o\u008d#J\u0089\u00d2~%7\u0091\u00e3\u00c4\u00ecp\u0013\u00eb\u0012\u00be\u007f\u0005EwH\u00ff\u0095?\u00f1".length();
                        var13_16 = 0;
                        while (true) {
                            var18_17 = var15_14.substring(var13_16, var13_16 += 8).getBytes("ISO-8859-1");
                            v10 = var17_12;
                            v11 = var14_13++;
                            v12 = ((long)var18_17[0] & 255L) << 56 | ((long)var18_17[1] & 255L) << 48 | ((long)var18_17[2] & 255L) << 40 | ((long)var18_17[3] & 255L) << 32 | ((long)var18_17[4] & 255L) << 24 | ((long)var18_17[5] & 255L) << 16 | ((long)var18_17[6] & 255L) << 8 | (long)var18_17[7] & 255L;
                            v13 = -1;
                            break block28;
                            break;
                        }
lbl81:
                        // 1 sources

                        while (true) {
                            v10[v11] = v14;
                            if (var13_16 < var16_15) ** continue;
                            var15_14 = "\u00dbe#\u0097+/~\u00db\u008e\u0092\u000bM\u00eb,|\u00c2";
                            var16_15 = "\u00dbe#\u0097+/~\u00db\u008e\u0092\u000bM\u00eb,|\u00c2".length();
                            var13_16 = 0;
                            while (true) {
                                var18_17 = var15_14.substring(var13_16, var13_16 += 8).getBytes("ISO-8859-1");
                                v10 = var17_12;
                                v11 = var14_13++;
                                v12 = ((long)var18_17[0] & 255L) << 56 | ((long)var18_17[1] & 255L) << 48 | ((long)var18_17[2] & 255L) << 40 | ((long)var18_17[3] & 255L) << 32 | ((long)var18_17[4] & 255L) << 24 | ((long)var18_17[5] & 255L) << 16 | ((long)var18_17[6] & 255L) << 8 | (long)var18_17[7] & 255L;
                                v13 = 0;
                                break block28;
                                break;
                            }
                            break;
                        }
lbl94:
                        // 1 sources

                        while (true) {
                            v10[v11] = v14;
                            if (var13_16 < var16_15) ** continue;
                            break block29;
                            break;
                        }
                    }
                    var19_18 = v12;
                    var21_19 = var11_10.doFinal(new byte[]{(byte)(var19_18 >>> 56), (byte)(var19_18 >>> 48), (byte)(var19_18 >>> 40), (byte)(var19_18 >>> 32), (byte)(var19_18 >>> 24), (byte)(var19_18 >>> 16), (byte)(var19_18 >>> 8), (byte)var19_18});
                    v14 = ((long)var21_19[0] & 255L) << 56 | ((long)var21_19[1] & 255L) << 48 | ((long)var21_19[2] & 255L) << 40 | ((long)var21_19[3] & 255L) << 32 | ((long)var21_19[4] & 255L) << 24 | ((long)var21_19[5] & 255L) << 16 | ((long)var21_19[6] & 255L) << 8 | (long)var21_19[7] & 255L;
                    switch (v13) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl107:
                        // 1 sources

                        ** continue;
                    }
                }
                OreSim.X = var17_12;
                OreSim.Y = new Integer[12];
                OreSim.n = 6;
                OreSim.s = 4;
                OreSim.db = new HashMap<K, V>(13);
                var0_20 = Cipher.getInstance("DES/CBC/NoPadding");
                v15 = SecretKeyFactory.getInstance("DES");
                v16 = new byte[8];
                v17 = v16;
                v16[0] = (byte)(var22 >>> 56);
                for (var1_21 = 1; var1_21 < 8; ++var1_21) {
                    v17 = v17;
                    v17[var1_21] = (byte)(var22 << var1_21 * 8 >>> 56);
                }
                var0_20.init(2, (Key)v15.generateSecret(new DESKeySpec(v17)), new IvParameterSpec(new byte[8]));
                var6_22 = new long[7];
                var3_23 = 0;
                var4_24 = "\u00d41\u00cb\u00f4\u001fE\u0083\u00fb\u0090\u008dQ\u00f2\u00e4\u0093(\u00a6ud\u008e5\u00c1P\u0080\u00d1?\u0015\u0010\u008d~\u0091\u00d3\u00bb\u00cb'\u00ae\u00d5\u00a9\u0080\t\u00f6";
                var5_25 = "\u00d41\u00cb\u00f4\u001fE\u0083\u00fb\u0090\u008dQ\u00f2\u00e4\u0093(\u00a6ud\u008e5\u00c1P\u0080\u00d1?\u0015\u0010\u008d~\u0091\u00d3\u00bb\u00cb'\u00ae\u00d5\u00a9\u0080\t\u00f6".length();
                var2_26 = 0;
                while (true) {
                    var7_27 = var4_24.substring(var2_26, var2_26 += 8).getBytes("ISO-8859-1");
                    v18 = var6_22;
                    v19 = var3_23++;
                    v20 = ((long)var7_27[0] & 255L) << 56 | ((long)var7_27[1] & 255L) << 48 | ((long)var7_27[2] & 255L) << 40 | ((long)var7_27[3] & 255L) << 32 | ((long)var7_27[4] & 255L) << 24 | ((long)var7_27[5] & 255L) << 16 | ((long)var7_27[6] & 255L) << 8 | (long)var7_27[7] & 255L;
                    v21 = -1;
                    break block30;
                    break;
                }
lbl136:
                // 1 sources

                while (true) {
                    v18[v19] = v22;
                    if (var2_26 < var5_25) ** continue;
                    var4_24 = "\u00de\u0017X~\u00ab\u00a5[ \u009cm\u000b/\u008cLu\u00e4";
                    var5_25 = "\u00de\u0017X~\u00ab\u00a5[ \u009cm\u000b/\u008cLu\u00e4".length();
                    var2_26 = 0;
                    while (true) {
                        var7_27 = var4_24.substring(var2_26, var2_26 += 8).getBytes("ISO-8859-1");
                        v18 = var6_22;
                        v19 = var3_23++;
                        v20 = ((long)var7_27[0] & 255L) << 56 | ((long)var7_27[1] & 255L) << 48 | ((long)var7_27[2] & 255L) << 40 | ((long)var7_27[3] & 255L) << 32 | ((long)var7_27[4] & 255L) << 24 | ((long)var7_27[5] & 255L) << 16 | ((long)var7_27[6] & 255L) << 8 | (long)var7_27[7] & 255L;
                        v21 = 0;
                        break block30;
                        break;
                    }
                    break;
                }
lbl149:
                // 1 sources

                while (true) {
                    v18[v19] = v22;
                    if (var2_26 < var5_25) ** continue;
                    break block31;
                    break;
                }
            }
            var8_28 = v20;
            var10_29 = var0_20.doFinal(new byte[]{(byte)(var8_28 >>> 56), (byte)(var8_28 >>> 48), (byte)(var8_28 >>> 40), (byte)(var8_28 >>> 32), (byte)(var8_28 >>> 24), (byte)(var8_28 >>> 16), (byte)(var8_28 >>> 8), (byte)var8_28});
            v22 = ((long)var10_29[0] & 255L) << 56 | ((long)var10_29[1] & 255L) << 48 | ((long)var10_29[2] & 255L) << 40 | ((long)var10_29[3] & 255L) << 32 | ((long)var10_29[4] & 255L) << 24 | ((long)var10_29[5] & 255L) << 16 | ((long)var10_29[6] & 255L) << 8 | (long)var10_29[7] & 255L;
            switch (v21) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl162:
                // 1 sources

                ** continue;
            }
        }
        OreSim.ab = var6_22;
        OreSim.bb = new Long[7];
        OreSim.o = 15000L;
        OreSim.p = 5000L;
        OreSim.r = 1200L;
        OreSim.q = 5000L;
    }

    private static Throwable a(Throwable throwable) {
        return throwable;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static String b(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x3658;
        if (V[n3] == null) {
            Object[] objectArray;
            try {
                Long l3 = Thread.currentThread().threadId();
                objectArray = (Object[])W.get(l3);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    W.put(l3, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/g/af", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l2 >>> 56);
            for (int i2 = 1; i2 < 8; ++i2) {
                byArray[i2] = (byte)(l2 << i2 * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = U[n3].getBytes("ISO-8859-1");
            OreSim.V[n3] = OreSim.b(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return V[n3];
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        String string2 = OreSim.b(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static CallSite b(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/af" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x1FB5;
        if (Y[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = X[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])Z.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    Z.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/g/af", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            OreSim.Y[n3] = n4;
        }
        return Y[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = OreSim.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/af" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static long d(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x3991;
        if (bb[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = ab[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])db.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    db.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/g/af", exception);
            }
            long l5 = ((long)byArray[0] & 0xFFL) << 56 | ((long)byArray[1] & 0xFFL) << 48 | ((long)byArray[2] & 0xFFL) << 40 | ((long)byArray[3] & 0xFFL) << 32 | ((long)byArray[4] & 0xFFL) << 24 | ((long)byArray[5] & 0xFFL) << 16 | ((long)byArray[6] & 0xFFL) << 8 | (long)byArray[7] & 0xFFL;
            OreSim.bb[n3] = l5;
        }
        return bb[n3];
    }

    private static long d(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        long l3 = OreSim.d(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Long.TYPE, l3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return l3;
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_2().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/af" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (ib[n4] != null) {
            return n4;
        }
        Object object = hb[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 44;
            case 1 -> 24;
            case 2 -> 39;
            case 3 -> 30;
            case 4 -> 2;
            case 5 -> 11;
            case 6 -> 26;
            case 7 -> 19;
            case 8 -> 49;
            case 9 -> 12;
            case 10 -> 48;
            case 11 -> 9;
            case 12 -> 28;
            case 13 -> 1;
            case 14 -> 46;
            case 15 -> 27;
            case 16 -> 43;
            case 17 -> 22;
            case 18 -> 35;
            case 19 -> 6;
            case 20 -> 29;
            case 21 -> 57;
            case 22 -> 13;
            case 23 -> 16;
            case 24 -> 61;
            case 25 -> 51;
            case 26 -> 5;
            case 27 -> 50;
            case 28 -> 36;
            case 29 -> 14;
            case 30 -> 60;
            case 31 -> 58;
            case 32 -> 33;
            case 33 -> 53;
            case 34 -> 40;
            case 35 -> 10;
            case 36 -> 56;
            case 37 -> 20;
            case 38 -> 25;
            case 39 -> 15;
            case 40 -> 59;
            case 41 -> 17;
            case 42 -> 32;
            case 43 -> 55;
            case 44 -> 41;
            case 45 -> 18;
            case 46 -> 45;
            case 47 -> 54;
            case 48 -> 8;
            case 49 -> 42;
            case 50 -> 62;
            case 51 -> 3;
            case 52 -> 21;
            case 53 -> 0;
            case 54 -> 38;
            case 55 -> 52;
            case 56 -> 37;
            case 57 -> 23;
            case 58 -> 31;
            case 59 -> 34;
            case 60 -> 63;
            case 61 -> 47;
            case 62 -> 7;
            default -> 4;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        OreSim.ib[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = hb;
        hb[0] = "/Ku~u\u0001$Ks~uI";
        objectArray[1] = Boolean.TYPE;
        OreSim.ib[1] = "java/lang/Boolean";
        objectArray[2] = Long.TYPE;
        OreSim.ib[2] = "java/lang/Long";
        objectArray[3] = "9!(A&5L\u0001#N7z-\u000f(E3 Y";
        objectArray[4] = Void.TYPE;
        OreSim.ib[4] = "java/lang/Void";
        objectArray[5] = "\nS\u0015BS,\u007fs\u001eMBc\u001e}\u0015FF9j";
        objectArray[6] = "\ru8Sn\u0012\u001cu\b";
        objectArray[7] = ";$\u00014\u0015UN\u0004\n;\u0004\u001a/\n\u00010\u0000@[";
        objectArray[8] = "\u0005f-4\u001e=\u000ei<{|>\u0001`";
        objectArray[9] = "40C\nW\f??RE*\u0014,8[\f";
        objectArray[10] = "P&\u001bGT\u0010%\u0006\u0010HE_D\b\u001bCA\u00050";
        objectArray[11] = "\u000ei\u0017`Yp\u000ei\u0000<U\u007f\u0014\"\u0000\"Uj\u0013SV}\u0006(";
        objectArray[12] = "h\u0002F|Y5a\u0002E|Y";
        objectArray[13] = "\u00169#\r{X\u001d62B\u001aV\u0016=6\u0018";
        objectArray[14] = "3C\u0003ODeFc\b@U*'m\u0003KQpS";
        objectArray[15] = "\u001e)G0Zc\u000f)t";
        objectArray[16] = "$*&(\u0000o-*%(\u0012";
        objectArray[17] = "rF@eOy\u0007fKj^6fh@aZl\u0012";
        objectArray[18] = "~Ai%\u000e7wAj%\r";
        objectArray[19] = "o*\u001d9>s\u001a\n\u00166/<{\u0004\u001d=+f\u000f";
        objectArray[20] = "dOC:]xzGYu hz";
        objectArray[21] = "o\\mH\u0017\ff\\nH\u0015";
        objectArray[22] = "QZ\u0004 s?ZZ\u000f";
        objectArray[23] = "<b3K\u0003U<b$\u0017\u000fZ&)$\t\u000fO!XtT^";
        objectArray[24] = "E?pH+ZN0a\u0007Q^]1qHgZJ";
        objectArray[25] = "V\bEQq^#(N^`\u0011B&EUdK6";
        objectArray[26] = "R\fQ\u0012?\u0004Y\fW\u0012?n";
        objectArray[27] = "q)";
        objectArray[28] = "\u0010\u000e\\MVc\u0001\u000eE";
        objectArray[29] = ">|[>\u0005uK\\P1\u0014:*R[:\u0010`^";
        objectArray[30] = "/)gsw0Z\tl|f\u007f;\u0007gwb%O";
        objectArray[31] = "g2oN*\u0001\u0012\u0012dA;Ns\u001coJ?\u0014\u0007";
        objectArray[32] = "&U\u001ecz`Su\u0015lk/2{\u001egouF";
        objectArray[33] = ")\fZ8@B\\,Q7Q\r=\"Z<UWI";
        objectArray[34] = "F)F0\u0007q3\tM?\u0016>R\u0007F4\u0012d&";
        objectArray[35] = "Oq\"oVg:Q)`G([_\"kCr/";
        objectArray[36] = "+[n %w5StoFc1";
        objectArray[37] = "ZmO9/MZmXe#B@&X{#WGW\t$q\u001c";
        objectArray[38] = "hq $z0hq7xv?r:7fv*uKf</i";
        objectArray[39] = "\f\u0018c\u0006:ky8h\t+$\u00186c\u0002/~l";
        objectArray[40] = "BS\u000e?\r@IS\b?\u0016";
        objectArray[41] = "\u000bf\bJ\nT\u0002f\u000bJ\u0007";
        objectArray[42] = "h\u0003hN:Cv\u000br\u0001wYl\u0001k]fSl\u00160N`Yo\u000b}\u0001UBm\u000fwLXYl\u0005";
        objectArray[43] = "\u0018\u0010h\b \fm0c\u00071C\f>h\f5\u0019x";
        objectArray[44] = "Ra\u0010\u001d\u0017|'A\u001b\u0012\u00063FO\u0010\u0019\u0002i2";
        objectArray[45] = "$?\u0010rq(Q\u001f\u001b}`g0\u0011\u0010vd=D";
        objectArray[46] = "QX?#$<$x4,5sEv?'1)1";
        objectArray[47] = Integer.TYPE;
        OreSim.ib[47] = "java/lang/Integer";
        objectArray[48] = "\nCw\u0012S,\u0014Km]\u001e6\u000eAt\u0001\u000f<\u000eV/6\u0005<\u0003Wu\u001c\u000f\n\u0005Pw\u001a\u001e<";
        objectArray[49] = "!#\u0012\"\u0016A?+\bmiA.7\u0001";
        objectArray[50] = "e\u0006X\t\u001a\u001fl\u0006[\t\u001e";
        objectArray[51] = "\u0018q\\hK\u001f\u0005d\u0004J\n\u0012\u001db";
        objectArray[52] = "b\u001b/Lj\u0010\u0017;$C{_v5/H\u007f\u0005\u0002";
        objectArray[53] = "!(t\u0015f\u0007*(|";
        objectArray[54] = "x%\u0016OeD\r\u0005\u001d@t\u000bl\u000b\u0016KpQ\u0018";
        objectArray[55] = "\u000bll9\u000fs\u0002lo9\u0003";
        objectArray[56] = "k\u00153=}(`\u00154=p";
        objectArray[57] = "\u00102\u001e\u001eb/e\u0012\u0015\u0011s`\u0004\u001c\u001e\u001aw:p";
        objectArray[58] = "t.G1\u007fl\u0001\u000eL>n#`\u0000G5jy\u0014";
        objectArray[59] = "\bD\\C8\u0013}dWL)\\\u001cj\\G-\u0006h";
        objectArray[60] = "$mk\u0001G\u0006/mm\u0001G_";
        objectArray[61] = "~,\t=\u0011*\u000b\f\u00022\u0000ej\u0002\t9\u0004?\u001e";
        objectArray[62] = "F\rkhuy\u001e\nt\u0019\\\u0017\u0018\u001b(%p(\u0010\nms";
        objectArray[63] = "sm\u0002Q\"M+j\u001d 1#-5\u0013Er\u001dpvLIq#/4\u0016\u0019/^$t\u0011@I";
        objectArray[64] = "^wdI\u00063\u0006p{8\u0003]\u0000/u]Vc]l*QU]\u0002.p\u0001\u000b \tnwXm";
        objectArray[65] = "[\b\u001dG^\"\u000e\u0007XC`ug[XA\u0005'Y\u0006\u001b\u001e\t$g_\u0003^\u001cs^R\u001c\u0014X\u001c";
        objectArray[66] = "cT\u0017\u0011Tw;S\b`|\u0019=BT\\Q&5S\u0011\n";
        objectArray[67] = "\u007f1DR:l'6[#:\u0002!iUFj<|*\nJi\u0002#hP\u001a7\u007f((WCQ";
        objectArray[68] = "\u0010$)bl\"H#6\u0013nLN2j/isF#/y\u00075O8/(iqN~n\u0013~3\u0019\u007f5ib%\u001c8W(8&N$*#x!\u0017B";
        objectArray[69] = "\u000f\u0006\u0011{YrM_\u0015ciC3h7EirJS\u001f.\u00120\u0013W\u0007";
        objectArray[70] = "\u00116\u001e+V'I1\u0001Z|II.\u001ceO2\u001a9Q ";
        objectArray[71] = "\u001dpA5YmLcIx0y-/C\u007fNo\u0015bG}B\u0010";
        objectArray[72] = "ij3(m23k7{o@9Puul%kn(63)hPwtiy6-|4n P";
        objectArray[73] = "\"\u0014EjO2w\u001b\u0000nqe\u001eG\u0000l\u00147 \u001aC3\u00184\u001e\u0017Oq\u0010p%NZm\u001e\f";
        objectArray[74] = ".ieex\u0016vnz\u0014ox#vqim\u0019-cjr";
        objectArray[75] = "\u0017c^\u0003u\\OdAro2\u001e;B\nnBKnQ\u0017";
        objectArray[76] = "bz/\u0014oV #+\f_}C\r\u0015q$\u0013r!t\nfJv9";
        objectArray[77] = "/]2(\u0012\u0012wZ-Y\t|:\n)`\u0004\u0005*_}0";
        objectArray[78] = ";fm\u001a6;0yiHU(Y9*\u001f0zgdi@<yY;+\u001al'$0k\u001d5A";
        objectArray[79] = "nw/^u\u000eq<(\u000e\u000f\u0005\u0000h-\u0001nQb9x^m";
        objectArray[80] = "ajp;\u0013U9moJ\u0011;?2a/C\u0005bq>#@;k45!\u0014_=1v,x";
        objectArray[81] = "#=^j]b{:A\u001b_\f$dA*G<\"7Ja6l{:\u0011j\u0006j(1Z\u001b";
        objectArray[82] = "{#\u00192\u0006\u001ekvMb{\u000e\t`\u001d;JYrp\fe\u001fg";
        objectArray[83] = "?J\u001bHu\u0012gM\u00049c|3O\u0014Ix\u00176@\u0019E";
        objectArray[84] = "\fG%\u000653\u0007X!TV#n\u0018b\u00033rPE!\\?qn\u001ac\u0006o/\u0013\u0011#\u00016I";
        objectArray[85] = ".-fd>.v*y\u00158@puwpn~-6(|m@rtr,3=y4uuU";
        objectArray[86] = "]\u000e\u00164\u001e[\u0005\t\tE\u00105\u0003V\u0007 N\u000b^\u0015X,M5\u0001W\u0002|\u0013H\n\u0017\u0005%u";
        objectArray[87] = "@\nHn<UK\u0015L<_D\"U\u000fk:\u0014\u001c\bL46\u0017\"W\u000enfI_\\Ni?/";
        objectArray[88] = "Pr8lCi\bu'\u001dl\u0007\u000ed{!F8\u0006u>w";
        objectArray[89] = "\u001a\u001c6B]jB\u001b)3|\u0004\fB:Q_x\u0012\u001e3Z";
        objectArray[90] = "H\t\n0X-\u0010\u000e\u0015AZC\u0016Q\u001b$\b}K\u0012D(\u000bC\u0014P\u001exU>\u001f\u0010\u0019!3";
        objectArray[91] = "?X'Y1>g_8(\u0002P$CdD*49\u0004%";
        objectArray[92] = ",A#|m(tF<\rJF7H h==p\u001a'i";
        objectArray[93] = "\u001f8 ;vuG??JX\u001bA.cvs$I?& ";
        objectArray[94] = "7\u007f'*\u0006\u001dox8[\u0012s+g<)S\r!r`!";
        objectArray[95] = "C\t3\u0015\u001cZ\u0016[p\u0012\u001bk\u001377R\b\u000eA\tj\u0011W\u0002B7r\u0011Z\u0007\nSoV\u001bk";
        objectArray[96] = "?DL\u000fv2gCS~F\\f]\fCp$6\u0012]\u0007";
        objectArray[97] = "^62%%u\u00061-T\u0000\u001bE?11u`\u0002m60";
        objectArray[98] = "F$%&\u0014j\u001e#:W\u0015\u0004\u0018|42D:E?k>G\u0004\u001a}1n\u0019y\u0011=67\u007f";
        objectArray[99] = "\u0018\tm\u0003\u0013C@\u000err\u001d-\u0018\tm\u0003\u0013C@\u000er";
        objectArray[100] = "$N\u0004,HN|I\u001b]j .\u0010A6ODx\u0015\u0002;";
        objectArray[101] = "\u001aO\u001cb[rBH\u0003\u0013i\u001c\u0001T_\u007f@x\u001c\u0013\u001e";
        objectArray[102] = "&Tv\u0005vps[3\u0001H'\u001a\u00073\u0003-u$Zp\\!v\u001aBpQ$>~_7\u0010H";
        objectArray[103] = "E\tC\u001bu @\u0006N\u0017\u0013\".S\f\u0004vp\u0010\u000eO[zs.\u0007\nPx'JQ\u000f\u0013uK";
        objectArray[104] = "\u00171\u000bmP*O6\u0014\u001caD\f*HpK \u0011m\t";
        objectArray[105] = ",-3\u001c\u001e\u0014t*,m:zu4sP\u0018\u0002%{\"\u0014";
        objectArray[106] = "bV-,-b:Q2]\u0001\fyMn16hd\n/";
        objectArray[107] = "B\n\u001b'jH\u001a^\u0017 <y!\u007f \u0000\u0016#{\u000b^10HJS\n=7\u001e";
        objectArray[108] = "{X2vQ[#_-\u0007z5q\u0006wlVQ'\u00034a";
        objectArray[109] = "i<%Y:B<3`]\u0004\u0015Uo`_aGk2#\u0000mDUmaZ=\u001a(f!]d|";
        objectArray[110] = "^o\u001cvd\u0017\u0006h\u0003\u0007qy\u00003\f9s\u0001Zv\\e2";
        objectArray[111] = "\u0019}\u0011\u0003RvAz\u000er\u007f\u0018\u0002fR\u001eI|\u001f!\u0013";
        objectArray[112] = "OL\u0000L7;\u0017K\u001f=.UOX\u0014\u0006>6RO\u0006T";
        objectArray[113] = "#\u00037\u007f8\u001a{\u0004(\u000e4t}[&khJ \u0018ygkt\u007fZ#75\tt\u001a$nS";
        objectArray[114] = "W\u001d@\u001e\u0001sXQ\u001eEo}6N@B\u0010uMV\u0007\u001f\u0003\u0017";
        objectArray[115] = "L?\u0010W]5St\u0017\u0007';\"3\u0000PK'F.G\u0011'";
        objectArray[116] = "\u0003z6\u0004H\u0011[})uE\u007f]\"'\u0010\u0018A\u0000ax\u001c\u001b\u007f_#\"LE\u0002Tc%\u0015#";
        objectArray[117] = "!Tu\u0019K9ySjhLW\u007f\fd\r\u001bi\"O;\u0001\u0018W}\raQF*vMf\b ";
        objectArray[118] = "C8Z\r:)\u001b?E|(G\u001d`K\u0019jy@#\u0014\u0015iG\u001faNE7:\u0014!I\u001cQ";
        objectArray[119] = "\r|L\u0018%nXs\t\u001c\u001b91/\t\u001e~k\u000frJArh1f\t\u0018w/I&\u0007\u001f`P";
        objectArray[120] = "\u0002y<\u007fgTZ~#\u000eG:\u0015p;0s]\\p~d";
        objectArray[121] = "\u000bQS]\u001a\u000fSVL,<a\u0010XPIJ\u001aW\nWH";
        objectArray[122] = "6z5%yKcup!G\u001c\n)p#\"N4t3|.M\n.1rz\u0018r~~#>u";
        objectArray[123] = "H3\u007fN{bWxx\u001e\u0001d&z,\u001bd;\u0018'oDh8&x-\u001e8f[sm\u0019a\u0000";
        Object[] objectArray2 = objectArray;
        objectArray[124] = "Q\u0002hA\u001by[\u00174I%m*E3\\@<\u0014\u0018p\u0003L?*\u0000p\u000eIwN\u001d7O%";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = OreSim.e(l2, l3);
            object = hb[n2];
            try {
                if (!(object instanceof String)) break block2;
                OreSim.hb[n2] = clazz = Class.forName(ib[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = OreSim.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = OreSim.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = OreSim.e(l2, l3);
        Object object = hb[n2];
        if (object instanceof String) {
            String string = ib[n2];
            int n3 = string.indexOf(8);
            Class clazz = OreSim.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = OreSim.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = OreSim.c(clazz3, string2, clazz2)) != null) {
                    OreSim.hb[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = OreSim.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        OreSim.hb[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = OreSim.f(924688188701783L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = OreSim.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = OreSim.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = OreSim.e(l2, l3);
        Object object = hb[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = ib[n2];
                int n4 = string2.indexOf(8);
                clazz3 = OreSim.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = OreSim.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = OreSim.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        OreSim.hb[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = OreSim.f(924688188701783L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = OreSim.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        OreSim.hb[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = OreSim.f(924688188701783L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == 's' || c2 == '\u00e7' || c2 == '\u00e8' || c2 == '\u00e5') {
                field = OreSim.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == 's' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == '\u00e7' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == '\u00e8' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = OreSim.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == 'f' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == '\u00e4' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = OreSim.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite f(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_3().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/af" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(OreSim.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(OreSim.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_2() {
        try {
            return MethodHandles.lookup().findStatic(OreSim.class, "d", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_3() {
        try {
            return MethodHandles.lookup().findStatic(OreSim.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

