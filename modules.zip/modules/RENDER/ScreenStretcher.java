// === Kuzi module: ScreenStretcher ===
// Category   : RENDER
// Description: Horizontally stretches your screen for a cool distorted look
// Payload    : a.a.a.j.f.b (verified: True)

package kuzi.modules.render;

import java.lang.invoke.MethodHandles;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.b.v;
import kuzi.obf.j.f.q;
import kuzi.obf.m.r;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;

public class ScreenStretcher
extends BaseModule {
    public final SliderSetting stretch;
    public static volatile boolean n;
    public static volatile float o;
    private static final long p;
    private static final String[] q;
    private static final String[] r;
    private static final Map s;
    private static final Object[] t;
    private static final String[] u;

    public ScreenStretcher() {
        block0: {
            long l2 = p ^ 0x57728340440BL;
            long l3 = l2 ^ 0x7A091CF297B1L;
            int n2 = kuzi.obf.j.f.q.c();
            super("ScreenStretcher", "Horizontally stretches your screen for a cool distorted look", Category.RENDER);
            this.stretch = new SliderSetting("Stretch", 1.5, 0.5, 3.0, 0.05);
            int n3 = n2;
            Object[] objectArray = new Object[2];
            objectArray[1] = new Setting[]{this.stretch};
            objectArray[0] = l3;
            this.l(objectArray);
            if (BaseModule.b() != null) break block0;
            kuzi.obf.j.f.q.b(++n3);
        }
    }

    @Override
    public void d() {
        o = ((Double)this.stretch.a()).floatValue();
        n = true;
        super.d();
    }

    @Override
    public void e() {
        n = false;
        super.e();
    }

    @Override
    public void i() {
        o = ((Double)this.stretch.a()).floatValue();
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        p = v.a(5457692193740341648L, 8872536174882260812L, MethodHandles.lookup().lookupClass()).a(217400884117871L);
        long l2 = p ^ 0x4BF77E400E57L;
        t = new Object[24];
        u = new String[24];
        ScreenStretcher.c();
        s = new HashMap(13);
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] keyBytes = new byte[8];
        byte[] keyBytesAlias = keyBytes;
        keyBytes[0] = (byte)(l2 >>> 56);
        for (int i2 = 1; i2 < 8; ++i2) {
            keyBytesAlias = keyBytesAlias;
            keyBytesAlias[i2] = (byte)(l2 << i2 * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(keyBytesAlias)), new IvParameterSpec(new byte[8]));
        String[] decodedStrings = new String[3];
        int chunkIndex = 0;
        String cipherText = "\u0011J\u00b3\u00a6\u00ec8\u00c1\u00dam\u00ed$\u0012\u00d3\u0013\u0096`p\u0097\u0083\u0001\u0005\u00c8x<\u00b6\u000bi4\u00f2\u00dc\u00cc\u00fch\u00e9\u000f\u00bdQ-\u008068Jm4\u00c6\u00e2\u00c9S\n\u0082\u001d\u00e0\u00dcZ\n?\u00f9\u00c9j\u0003\u00f1\u00f4\u00b4\ftn\u0097?\u00e6g\u00a7?\u00df\u00a6\u0002U\u001334\u00a4L\u0000\u001a\u00e6|\u0004\u00a7\u0018\u000b\u00c6m\u00df\u0004\u001fB\u00f8Y\u001e\u0087\u00b1S\u00ad;\u00d4E\u00b4\u00b6\u00e64$\u00cd\u00f3\u00c2\u0093\u00ee5\u00a1:@\u00c6\u009aM\u0086\u00ab\u00e0Q\u00e2t\u001a\u00a2N\u00a1\u00ed\u008d\u00d7\u00b5\u00f2\u0010\u00dej.\u00b2\u00c8P\u0083}\u007f\u00c7\u00d9\u00b4\u00d1{\u00b7>";
        int encodedLength = "\u0011J\u00b3\u00a6\u00ec8\u00c1\u00dam\u00ed$\u0012\u00d3\u0013\u0096`p\u0097\u0083\u0001\u0005\u00c8x<\u00b6\u000bi4\u00f2\u00dc\u00cc\u00fch\u00e9\u000f\u00bdQ-\u008068Jm4\u00c6\u00e2\u00c9S\n\u0082\u001d\u00e0\u00dcZ\n?\u00f9\u00c9j\u0003\u00f1\u00f4\u00b4\ftn\u0097?\u00e6g\u00a7?\u00df\u00a6\u0002U\u001334\u00a4L\u0000\u001a\u00e6|\u0004\u00a7\u0018\u000b\u00c6m\u00df\u0004\u001fB\u00f8Y\u001e\u0087\u00b1S\u00ad;\u00d4E\u00b4\u00b6\u00e64$\u00cd\u00f3\u00c2\u0093\u00ee5\u00a1:@\u00c6\u009aM\u0086\u00ab\u00e0Q\u00e2t\u001a\u00a2N\u00a1\u00ed\u008d\u00d7\u00b5\u00f2\u0010\u00dej.\u00b2\u00c8P\u0083}\u007f\u00c7\u00d9\u00b4\u00d1{\u00b7>".length();
        int chunkSize = 32;
        int offset = -1;
        while (true) {
            int chunkStart = ++offset;
            byte[] chunkBytes = cipher.doFinal(cipherText.substring(chunkStart, chunkStart + chunkSize).getBytes("ISO-8859-1"));
            decodedStrings[chunkIndex++] = ScreenStretcher.b(chunkBytes).intern();
            if ((offset += chunkSize) >= encodedLength) {
                q = decodedStrings;
                r = new String[3];
                n = false;
                o = 1.5f;
                return;
            }
            chunkSize = cipherText.charAt(offset);
        }
    }

    private static r a(r r2) {
        return r2;
    }

    private static String b(byte[] bytes) {
        int outputIndex = 0;
        int inputLength = bytes.length;
        char[] decoded = new char[inputLength];
        for (int i2 = 0; i2 < inputLength; ++i2) {
            char decodedChar;
            int codeUnit = 0xFF & bytes[i2];
            if (codeUnit < 192) {
                decoded[outputIndex++] = (char)codeUnit;
                continue;
            }
            if (codeUnit < 224) {
                decodedChar = (char)((char)(codeUnit & 0x1F) << 6);
                codeUnit = bytes[++i2];
                decodedChar = (char)(decodedChar | (char)(codeUnit & 0x3F));
                decoded[outputIndex++] = decodedChar;
                continue;
            }
            if (i2 >= inputLength - 2) continue;
            decodedChar = (char)((char)(codeUnit & 0xF) << 12);
            codeUnit = bytes[++i2];
            decodedChar = (char)(decodedChar | (char)(codeUnit & 0x3F) << 6);
            codeUnit = bytes[++i2];
            decodedChar = (char)(decodedChar | (char)(codeUnit & 0x3F));
            decoded[outputIndex++] = decodedChar;
        }
        return new String(decoded, 0, outputIndex);
    }

    private static void c() {
        Object[] objectArray = t;
        t[0] = "19\u0007r]Y:9\u0000r^";
        objectArray[1] = Float.TYPE;
        ScreenStretcher.u[1] = "java/lang/Float";
        objectArray[2] = "k\u0007ool\u0019b\u0007lo`";
        objectArray[3] = "5[p,]\u001f<[s,]";
        objectArray[4] = "2^sf\u0000Z9Qb)aT2Zfs";
        objectArray[5] = Boolean.TYPE;
        ScreenStretcher.u[5] = "java/lang/Boolean";
        objectArray[6] = "\u001a\\?\u000eCE\u0011\\7";
        objectArray[7] = "K\u0004\u001d\u001d)\u0010G\u0004\u000e";
        objectArray[8] = "*p\u0014\rm\u0006!p\u001f";
        objectArray[9] = "0\u0001";
        objectArray[10] = "\u0002^\u0005;,d\t^\u0002;<";
        objectArray[11] = Integer.TYPE;
        ScreenStretcher.u[11] = "java/lang/Integer";
        objectArray[12] = Void.TYPE;
        ScreenStretcher.u[12] = "java/lang/Void";
        objectArray[13] = "Nq6_-x;Q=P<7Z_6[8m.";
        objectArray[14] = "M\u000b@\b0\u0006\u000b\u001aL\u0015T3<&a(\u000eiM\u000b@\b0\u0006\u000b\u001aL\u0015";
        objectArray[15] = "?\u001fD1!if\u0015U1D>\u0000L\u0006=':f\u000eE4}T0\u0017\u0001(;j8\u0016\u00036D";
        objectArray[16] = "x\u0002%kDK%Bm\u0013\\0f\u0003nh\u0005Hr\tv";
        objectArray[17] = "@=\bZd\t\u001d}@\"rr\u001d7\u0000Ee\u0017\u0019=ZO\u001bNQvV\\~J[,\\\"";
        objectArray[18] = "\u000b7 \u0017PWVwhoI,Q1c\u000eH\u001dSv!\u0012";
        objectArray[19] = "\u001e\u0010$\u0006\u0005pG\u001a5\u0006`&!Cf\n\u0003#G\u0001%\u0003YM";
        objectArray[20] = "\u0007`W:\nB_s\u0005ht@=0VjE[\u0002s]{\n)";
        objectArray[21] = "^v{3tH\u001aru?\u000fAc5{?nW[7vwp+";
        objectArray[22] = " M\u00031fx}\rKI|\u0003xO\u00027$:;Y\u0005+";
        Object[] objectArray2 = objectArray;
        objectArray[23] = "6\u00175il}r\u0013;e\u0017z\u000b[=8zgz\u0007fnx\u001e;\u0001d(h 3\u0000f6\u0017";
    }

    private static Field findDeclaredField(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field findFieldInHierarchy(Class clazz, String string, Class clazz2) {
        Field field = ScreenStretcher.findDeclaredField(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = ScreenStretcher.findFieldInHierarchy(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method findDeclaredMethod(Class clazz, String string, Class clazz2, int parameterCount, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != parameterCount) continue;
            for (int i2 = 0; i2 < parameterCount; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method findMethodInHierarchy(Class clazz, String string, Class clazz2, int parameterCount, Class[] classArray) {
        Method method = ScreenStretcher.findDeclaredMethod(clazz, string, clazz2, parameterCount, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = ScreenStretcher.findMethodInHierarchy(classArray2[i2], string, clazz2, parameterCount, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }
}

