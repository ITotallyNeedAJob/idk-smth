// === Kuzi module: ModuleE ===
// Category   : RENDER
// Description: 
// Payload    : a.a.a.j.g.E (verified: False)

package kuzi.modules.render;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.g.a.h;
import kuzi.obf.h.b.v;
import kuzi.obf.j.g.aD;
import kuzi.obf.m.r;
import kuzi.obf.p.ag;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.ChunkPos;
import net.minecraft.Blocks;
import net.minecraft.Block;
import net.minecraft.BlockPos;
import net.minecraft.Position;
import net.minecraft.AABB;
import net.minecraft.Vec3i;
import net.minecraft.Vec3;
import net.minecraft.ShulkerBoxBlock;
import net.minecraft.Packet;
import net.minecraft.ClientboundBlockUpdatePacket;
import net.minecraft.ClientboundSectionBlocksUpdatePacket;
import net.minecraft.ClientboundExplodePacket;
import net.minecraft.ClientboundLevelEventPacket;
import net.minecraft.BlockState;
import net.minecraft.ClientboundSoundPacket;
import net.minecraft.Property;
import net.minecraft.SoundEvent;
import net.minecraft.Camera;
import net.minecraft.PoseStack;
import net.minecraft.MultiBufferSource;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class ModuleE
extends BaseModule
implements kuzi.obf.g.a.v,
WorldRenderEvents.AfterEntities {
    private final SliderSetting m;
    private final SliderSetting n;
    private final SliderSetting o;
    private final BoolSetting p;
    private final SliderSetting q;
    private final BoolSetting r;
    private final Set foundPositions;
    private final List renderBoxes;
    private final Set scannedChunks;
    private long lastScanMillis;
    private long w;
    private long x;
    private static final int y;
    private static final int z;
    private static final Set A;
    private static final long B;
    private static final String[] C;
    private static final String[] D;
    private static final Map E;
    private static final long[] F;
    private static final Integer[] G;
    private static final Map H;
    private static final long[] I;
    private static final Long[] J;
    private static final Map K;
    private static final Object[] L;
    private static final String[] M;

    public ModuleE() {
        long l2 = B ^ 0x500887D98EB4L;
        long l3 = l2 ^ 0x3481F382B528L;
        super((String)((Object)ModuleE.b("i", (int)8701, (long)(0x60065CC781CC4FC9L ^ l2))), (String)((Object)ModuleE.b("i", (int)8893, (long)(0x6D881D36F9F84C8BL ^ l2))), Category.WORLD);
        this.m = new SliderSetting((String)((Object)ModuleE.b("i", (int)21210, (long)(0x6C49E8713FA4BCE5L ^ l2))), 16.0, 1.0, 32.0, 1.0);
        this.n = new SliderSetting((String)((Object)ModuleE.b("i", (int)26583, (long)(0x89FA8094E1889F0L ^ l2))), 0.0, -64.0, 320.0, 1.0);
        this.o = new SliderSetting((String)((Object)ModuleE.b("i", (int)7067, (long)(0x24398079DCCD75A3L ^ l2))), 32.0, 4.0, 128.0, 1.0);
        this.p = new BoolSetting((String)((Object)ModuleE.b("i", (int)4691, (long)(0x76CAE32C225BFC6DL ^ l2))), true);
        this.q = new SliderSetting((String)((Object)ModuleE.b("i", (int)6202, (long)(0x13A5C1C668477610L ^ l2))), 40.0, 10.0, 200.0, 1.0);
        this.r = new BoolSetting((String)((Object)ModuleE.b("i", (int)29756, (long)(0x4ACCCEAA06671A1DL ^ l2))), false);
        this.foundPositions = ConcurrentHashMap.newKeySet();
        this.renderBoxes = Collections.synchronizedList(new ArrayList());
        this.scannedChunks = ConcurrentHashMap.newKeySet();
        this.lastScanMillis = 0L;
        this.w = 0L;
        this.x = 0L;
        Setting[] settingArray = new Setting[ModuleE.c("w", (int)3263, (long)(0x4E0E4DD61183649FL ^ l2))];
        settingArray[0] = this.m;
        settingArray[1] = this.n;
        settingArray[2] = this.o;
        settingArray[3] = this.p;
        settingArray[4] = this.r;
        settingArray[5] = this.q;
        Object[] objectArray = new Object[2];
        objectArray[1] = settingArray;
        objectArray[0] = l3;
        this.l(objectArray);
        WorldRenderEvents.END_MAIN.register(this::afterEntities);
    }

    @Override
    public void d() {
        this.foundPositions.clear();
        this.renderBoxes.clear();
        this.scannedChunks.clear();
        this.lastScanMillis = 0L;
        this.w = 0L;
        Client.a().a(kuzi.obf.g.a.v.class, this);
    }

    @Override
    public void e() {
        Client.a().b(kuzi.obf.g.a.v.class, this);
        this.foundPositions.clear();
        this.renderBoxes.clear();
        this.scannedChunks.clear();
    }

    @Override
    public void i() {
        block9: {
            block4: {
                block5: {
                    int[] nArray;
                    int n2;
                    int n3;
                    int n4;
                    long l2;
                    block7: {
                        long l3;
                        block8: {
                            ModuleE moduleE;
                            long l4;
                            long l5;
                            block6: {
                                long l6;
                                long l7 = l6 = B ^ 0x36FC97C4C068L;
                                l2 = l7 ^ 0x60C49F8337F8L;
                                long l8 = l7 ^ 0x4357A5BBA3F5L;
                                n4 = (int)(l8 >>> 48);
                                n3 = (int)(l8 << 16 >>> 48);
                                n2 = (int)(l8 << 32 >>> 32);
                                long l9 = l7 ^ 0x1C02F8B0A5F1L;
                                l5 = l7 ^ 0x5EDEBB047F09L;
                                nArray = aD.b();
                                if (nArray == null) break block4;
                                if (BaseModule.a.level == null || BaseModule.a.player == null) break block5;
                                l3 = System.currentTimeMillis();
                                Object[] objectArray = new Object[2];
                                objectArray[1] = 2;
                                objectArray[0] = l9;
                                this.a(objectArray);
                                long l10 = l3 - this.lastScanMillis - ModuleE.d("s", (int)20499, (long)(0xD422D78D7EBE027L ^ l6));
                                l4 = l10 == 0L ? 0 : (l10 < 0L ? -1 : 1);
                                if (nArray == null) break block6;
                                if (l4 <= 0) break block7;
                                moduleE = this;
                                if (nArray == null) break block8;
                                l4 = (long)moduleE.foundPositions.isEmpty();
                            }
                            if (l4 != false) break block7;
                            Object[] objectArray = new Object[1];
                            objectArray[0] = l5;
                            this.c(objectArray);
                            moduleE = this;
                        }
                        moduleE.lastScanMillis = l3;
                    }
                    BlockPos playerPos = BaseModule.a.player.blockPosition();
                    int n5 = ((Double)this.m.a()).intValue() + 2 << 4;
                    double d2 = (double)n5 * (double)n5;
                    this.foundPositions.removeIf(arg_0 -> ModuleE.lambda$onTick$0(playerPos, d2, l2, arg_0));
                    int playerChunkX = BaseModule.a.player.getBlockX() >> 4;
                    int playerChunkZ = BaseModule.a.player.getBlockZ() >> 4;
                    int maxChunkDistance = ((Double)this.m.a()).intValue() + 2;
                    this.scannedChunks.removeIf(arg_0 -> ModuleE.lambda$onTick$1((char)n4, playerChunkX, maxChunkDistance, (short)n3, n2, playerChunkZ, arg_0));
                    if (nArray != null) break block9;
                }
                this.foundPositions.clear();
            }
            this.renderBoxes.clear();
        }
    }

    /*
     * Exception decompiling
     */
    private void a(Object[] var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * java.lang.UnsupportedOperationException
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.considerAsDoLoopStart(LoopIdentifier.java:383)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.identifyLoops1(LoopIdentifier.java:65)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:681)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    private void b(Object[] var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * java.lang.UnsupportedOperationException
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.considerAsDoLoopStart(LoopIdentifier.java:383)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.identifyLoops1(LoopIdentifier.java:65)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:681)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    @Override
    public void a(h h2) {
        block22: {
            Packet mc25962;
            BlockPos mc23382;
            int n2;
            int[] nArray;
            block34: {
                boolean bl;
                Packet mc25963;
                block30: {
                    block31: {
                        block33: {
                            int n3;
                            ClientboundLevelEventPacket mc26732;
                            block32: {
                                long l2;
                                block25: {
                                    block26: {
                                        block29: {
                                            Object object;
                                            ClientboundSoundPacket mc27672;
                                            Object object2;
                                            long l3;
                                            block28: {
                                                ClientboundSoundPacket mc27673;
                                                block27: {
                                                    block23: {
                                                        block24: {
                                                            long l4;
                                                            block13: {
                                                                block14: {
                                                                    block16: {
                                                                        boolean bl2;
                                                                        block21: {
                                                                            ClientboundBlockUpdatePacket mc26262;
                                                                            long l5;
                                                                            block19: {
                                                                                boolean bl3;
                                                                                block20: {
                                                                                    long l6;
                                                                                    long l7;
                                                                                    block18: {
                                                                                        block17: {
                                                                                            int n4;
                                                                                            block15: {
                                                                                                long l8;
                                                                                                long l9 = l8 = B ^ 0x68343B3F229DL;
                                                                                                l2 = l9 ^ 0x1837F6372C16L;
                                                                                                l4 = l9 ^ 0xCCD8EB59117L;
                                                                                                l3 = l9 ^ 0x2140B2B019A8L;
                                                                                                l7 = l9 ^ 0x4F8082CC6445L;
                                                                                                l6 = l9 ^ 0x100E1A4D4F0DL;
                                                                                                l5 = l9 ^ 0x7ED593521262L;
                                                                                                nArray = aD.b();
                                                                                                if (!this.d() || BaseModule.a.level == null) {
                                                                                                    return;
                                                                                                }
                                                                                                mc25963 = h2.c;
                                                                                                n2 = ((Double)this.n.a()).intValue();
                                                                                                bl = mc25963 instanceof ClientboundBlockUpdatePacket;
                                                                                                if (nArray == null) break block13;
                                                                                                if (!bl) break block14;
                                                                                                mc26262 = (ClientboundBlockUpdatePacket)mc25963;
                                                                                                mc23382 = mc26262.getPos();
                                                                                                n4 = mc23382.getY();
                                                                                                if (nArray == null) break block15;
                                                                                                if (n4 > n2) break block16;
                                                                                                n4 = ((Boolean)this.r.a()).booleanValue() ? 1 : 0;
                                                                                            }
                                                                                            if (nArray == null) break block17;
                                                                                            if (n4 == 0) break block18;
                                                                                            n4 = this.foundPositions.add(mc23382.immutable()) ? 1 : 0;
                                                                                        }
                                                                                        if (nArray != null) break block16;
                                                                                    }
                                                                                    object2 = mc26262.getBlockState().getBlock();
                                                                                    Object[] objectArray = new Object[2];
                                                                                    objectArray[1] = object2;
                                                                                    objectArray[0] = l7;
                                                                                    bl3 = this.g(objectArray);
                                                                                    if (nArray == null) break block19;
                                                                                    if (bl3) break block20;
                                                                                    Object[] objectArray2 = new Object[2];
                                                                                    objectArray2[1] = object2;
                                                                                    objectArray2[0] = l6;
                                                                                    bl2 = this.a(objectArray2);
                                                                                    if (nArray == null) break block21;
                                                                                    if (!bl2) break block19;
                                                                                }
                                                                                bl3 = this.foundPositions.add(mc23382.immutable());
                                                                            }
                                                                            bl2 = mc26262.getBlockState().getProperties().stream().anyMatch(arg_0 -> ModuleE.lambda$onPacketReceive$2(l5, arg_0));
                                                                        }
                                                                        if (nArray != null && bl2) {
                                                                            bl2 = this.foundPositions.add(mc23382.immutable());
                                                                        }
                                                                    }
                                                                    if (nArray != null) break block22;
                                                                }
                                                                bl = mc25963 instanceof ClientboundSectionBlocksUpdatePacket;
                                                            }
                                                            if (nArray == null) break block23;
                                                            if (!bl) break block24;
                                                            ClientboundSectionBlocksUpdatePacket mc26372 = (ClientboundSectionBlocksUpdatePacket)mc25963;
                                                            mc26372.runUpdates((arg_0, arg_1) -> this.lambda$onPacketReceive$3(l4, n2, arg_0, arg_1));
                                                            if (nArray != null) break block22;
                                                        }
                                                        bl = mc25963 instanceof ClientboundSoundPacket;
                                                    }
                                                    if (nArray == null) break block25;
                                                    if (!bl) break block26;
                                                    mc27673 = mc27672 = (ClientboundSoundPacket)mc25963;
                                                    if (nArray == null) break block27;
                                                    if (!(mc27673.getY() <= (double)n2)) break block22;
                                                    mc27673 = mc27672;
                                                }
                                                object = mc23382 = mc27673.getSound();
                                                if (nArray == null) break block28;
                                                if (!object.isBound()) break block29;
                                                object = mc23382.comp_349();
                                            }
                                            object2 = ((SoundEvent)object).comp_3319().getPath();
                                            Object[] objectArray = new Object[2];
                                            objectArray[1] = l3;
                                            objectArray[0] = object2;
                                            boolean bl4 = this.d(objectArray);
                                            if (nArray != null && bl4) {
                                                bl4 = this.foundPositions.add(BlockPos.containing((double)mc27672.getX(), (double)mc27672.getY(), (double)mc27672.getZ()));
                                            }
                                        }
                                        if (nArray != null) break block22;
                                    }
                                    bl = mc25963 instanceof ClientboundLevelEventPacket;
                                }
                                if (nArray == null) break block30;
                                if (!bl) break block31;
                                mc26732 = (ClientboundLevelEventPacket)mc25963;
                                n3 = mc26732.getPos().getY();
                                if (nArray == null) break block32;
                                if (n3 > n2) break block22;
                                Object[] objectArray = new Object[2];
                                objectArray[1] = l2;
                                objectArray[0] = mc26732.getType();
                                n3 = this.f(objectArray) ? 1 : 0;
                            }
                            if (nArray == null) break block33;
                            if (n3 == 0) break block22;
                            n3 = this.foundPositions.add(mc26732.getPos().immutable()) ? 1 : 0;
                        }
                        if (nArray != null) break block22;
                    }
                    mc25962 = mc25963;
                    if (nArray == null) break block34;
                    bl = mc25962 instanceof ClientboundExplodePacket;
                }
                if (!bl) break block22;
                mc25962 = mc25963;
            }
            ClientboundExplodePacket mc26642 = (ClientboundExplodePacket)mc25962;
            mc23382 = mc26642.comp_2883();
            double d2 = mc23382.y - (double)n2;
            double d3 = d2 == 0.0 ? 0 : (d2 < 0.0 ? -1 : 1);
            if (nArray != null && d3 <= 0) {
                d3 = (double)this.foundPositions.add(BlockPos.containing((double)mc23382.x, (double)mc23382.y, (double)mc23382.z));
            }
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean a(Object[] objectArray) {
        Block mc22482;
        int[] nArray;
        Block mc22483;
        long l2;
        block18: {
            Block mc22484;
            block17: {
                l2 = (Long)objectArray[0];
                mc22483 = (Block)objectArray[1];
                l2 = B ^ l2;
                nArray = aD.b();
                mc22482 = mc22483;
                mc22484 = Blocks.DISPENSER;
                if (nArray != null) {
                    if (mc22482 == mc22484) return true;
                    mc22482 = mc22483;
                    mc22484 = Blocks.DROPPER;
                }
                int[] nArray2 = nArray;
                if (l2 > 0L) {
                    if (nArray2 != null) {
                        if (mc22482 == mc22484) return true;
                        mc22482 = mc22483;
                        mc22484 = Blocks.HOPPER;
                    }
                    nArray2 = nArray;
                }
                if (l2 >= 0L) {
                    if (nArray2 != null) {
                        if (mc22482 == mc22484) return true;
                        mc22482 = mc22483;
                        mc22484 = Blocks.CHEST;
                    }
                    nArray2 = nArray;
                }
                if (nArray2 == null) break block17;
                if (mc22482 == mc22484) return true;
                mc22482 = mc22483;
                if (l2 <= 0L || nArray == null) break block18;
                mc22484 = Blocks.TRAPPED_CHEST;
            }
            if (mc22482 == mc22484) return true;
            mc22482 = mc22483;
        }
        boolean bl = mc22482 instanceof ShulkerBoxBlock;
        if (nArray == null) return bl;
        if (bl) return true;
        Block mc22485 = mc22483;
        Block mc22486 = Blocks.BARREL;
        int[] nArray3 = nArray;
        if (l2 > 0L) {
            if (nArray3 != null) {
                if (mc22485 == mc22486) return true;
                mc22485 = mc22483;
                mc22486 = Blocks.FURNACE;
            }
            nArray3 = nArray;
        }
        if (l2 > 0L) {
            if (nArray3 != null) {
                if (mc22485 == mc22486) return true;
                mc22485 = mc22483;
                mc22486 = Blocks.BLAST_FURNACE;
            }
            nArray3 = nArray;
        }
        if (l2 > 0L) {
            if (nArray3 != null) {
                if (mc22485 == mc22486) return true;
                mc22485 = mc22483;
                mc22486 = Blocks.SMOKER;
            }
            nArray3 = nArray;
        }
        if (l2 > 0L) {
            if (nArray3 != null) {
                if (mc22485 == mc22486) return true;
                mc22485 = mc22483;
                mc22486 = Blocks.LECTERN;
            }
            nArray3 = nArray;
        }
        if (nArray3 != null) {
            if (mc22485 == mc22486) return true;
            mc22485 = mc22483;
            mc22486 = Blocks.ENDER_CHEST;
        }
        if (mc22485 != mc22486) return false;
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean d(Object[] objectArray) {
        String string = (String)objectArray[0];
        long l2 = (Long)objectArray[1];
        l2 = B ^ l2;
        int[] nArray = aD.b();
        boolean bl = string.contains((CharSequence)((Object)ModuleE.b("i", (int)11195, (long)(0x725E07638792509DL ^ l2))));
        if (nArray == null) return bl;
        if (bl) return true;
        bl = string.contains((CharSequence)((Object)ModuleE.b("i", (int)23851, (long)(0xCEBAA228283A607L ^ l2))));
        if (nArray == null) return bl;
        if (bl) return true;
        bl = string.contains((CharSequence)((Object)ModuleE.b("i", (int)3222, (long)(0x1257886B2E38F7A4L ^ l2))));
        if (nArray == null) return bl;
        if (bl) return true;
        bl = string.contains((CharSequence)((Object)ModuleE.b("i", (int)17927, (long)(0x46E2DDAB5759BD36L ^ l2))));
        if (nArray == null) return bl;
        if (bl) return true;
        bl = string.contains((CharSequence)((Object)ModuleE.b("i", (int)28962, (long)(0x1625B3CF37538A11L ^ l2))));
        if (nArray == null) return bl;
        if (bl) return true;
        bl = string.contains((CharSequence)((Object)ModuleE.b("i", (int)12831, (long)(0x76E00F4BF62CC92BL ^ l2))));
        if (nArray == null) return bl;
        if (bl) return true;
        bl = string.contains((CharSequence)((Object)ModuleE.b("i", (int)2220, (long)(0x7ED378161F30F38CL ^ l2))));
        if (nArray == null) return bl;
        if (bl) return true;
        bl = string.contains((CharSequence)((Object)ModuleE.b("i", (int)13701, (long)(0x4E4DD7A08CEECEBEL ^ l2))));
        if (nArray == null) return bl;
        if (bl) return true;
        bl = string.contains((CharSequence)((Object)ModuleE.b("i", (int)25476, (long)(0x3C5479BD34C998BCL ^ l2))));
        if (nArray == null) return bl;
        if (bl) return true;
        bl = string.contains((CharSequence)((Object)ModuleE.b("i", (int)9802, (long)(0x607AE03979AB5D62L ^ l2))));
        if (nArray == null) return bl;
        if (bl) return true;
        bl = string.contains((CharSequence)((Object)ModuleE.b("i", (int)8448, (long)(0x11745C446F0DDA27L ^ l2))));
        if (nArray == null) return bl;
        if (bl) return true;
        bl = string.contains((CharSequence)((Object)ModuleE.b("i", (int)3365, (long)(0x1368D70D64387600L ^ l2))));
        if (nArray == null) return bl;
        if (bl) return true;
        bl = string.contains((CharSequence)((Object)ModuleE.b("i", (int)26500, (long)(0x7C06DE059DA71CA0L ^ l2))));
        if (nArray == null) return bl;
        if (bl) return true;
        bl = string.contains((CharSequence)((Object)ModuleE.b("i", (int)24519, (long)(0x10851074E5FBA4FEL ^ l2))));
        if (nArray == null) return bl;
        if (bl) return true;
        bl = string.contains((CharSequence)((Object)ModuleE.b("i", (int)10123, (long)(0x5340C9EA9BC5DCA5L ^ l2))));
        if (nArray == null) return bl;
        if (bl) return true;
        bl = string.contains((CharSequence)((Object)ModuleE.b("i", (int)28190, (long)(0x677C6290C6E1535L ^ l2))));
        if (nArray == null) return bl;
        if (bl) return true;
        bl = string.contains((CharSequence)((Object)ModuleE.b("i", (int)26329, (long)(0x16D1183EC9FD1DE3L ^ l2))));
        if (nArray == null) return bl;
        if (bl) return true;
        bl = string.contains((CharSequence)((Object)ModuleE.b("i", (int)10979, (long)(0x1DE6C4F22F22D1C2L ^ l2))));
        if (nArray == null) return bl;
        if (bl) return true;
        bl = string.contains((CharSequence)((Object)ModuleE.b("i", (int)26221, (long)(0x414D0A6EB16F9D52L ^ l2))));
        if (nArray == null) return bl;
        if (bl) return true;
        bl = string.contains((CharSequence)((Object)ModuleE.b("i", (int)10129, (long)(0x28CA0DCC4876DCACL ^ l2))));
        if (nArray == null) return bl;
        if (!bl) return false;
        return true;
    }

    private boolean f(Object[] objectArray) {
        boolean bl;
        block20: {
            block22: {
                boolean bl2 = ((Integer)objectArray[0]).intValue();
                long l2 = (Long)objectArray[1];
                l2 = B ^ l2;
                CallSite callSite = ModuleE.f("\u00ea", (long)1046349842462233778L, (long)l2);
                try {
                    block21: {
                        try {
                            try {
                                try {
                                    try {
                                        try {
                                            try {
                                                try {
                                                    try {
                                                        try {
                                                            bl = bl2;
                                                            if (callSite == null) break block20;
                                                            if (bl == ModuleE.c("w", (int)27065, (long)(0x15A8BE8A3772161L ^ l2))) break block21;
                                                        }
                                                        catch (r r2) {
                                                            throw ModuleE.f("\u00ea", (Object)r2, (long)1045242168295250508L, (long)l2);
                                                        }
                                                        bl = bl2;
                                                        if (callSite == null) break block20;
                                                    }
                                                    catch (r r3) {
                                                        throw ModuleE.f("\u00ea", (Object)r3, (long)1045242168295250508L, (long)l2);
                                                    }
                                                    if (l2 <= 0L) break block20;
                                                    if (bl == ModuleE.c("w", (int)12217, (long)(0x76A9B2F43BDAE731L ^ l2))) break block21;
                                                }
                                                catch (r r4) {
                                                    throw ModuleE.f("\u00ea", (Object)r4, (long)1045242168295250508L, (long)l2);
                                                }
                                                bl = bl2;
                                                if (callSite == null) break block20;
                                            }
                                            catch (r r5) {
                                                throw ModuleE.f("\u00ea", (Object)r5, (long)1045242168295250508L, (long)l2);
                                            }
                                            if (l2 <= 0L) break block20;
                                            if (bl == ModuleE.c("w", (int)29228, (long)(0x4AC9964E3CA93ACBL ^ l2))) break block21;
                                        }
                                        catch (r r6) {
                                            throw ModuleE.f("\u00ea", (Object)r6, (long)1045242168295250508L, (long)l2);
                                        }
                                        bl = bl2;
                                        if (callSite == null) break block20;
                                    }
                                    catch (r r7) {
                                        throw ModuleE.f("\u00ea", (Object)r7, (long)1045242168295250508L, (long)l2);
                                    }
                                    if (l2 < 0L) break block20;
                                    if (bl == ModuleE.c("w", (int)9087, (long)(0x7C0C32C969516BE8L ^ l2))) break block21;
                                }
                                catch (r r8) {
                                    throw ModuleE.f("\u00ea", (Object)r8, (long)1045242168295250508L, (long)l2);
                                }
                                bl = bl2;
                                if (callSite == null) break block20;
                            }
                            catch (r r9) {
                                throw ModuleE.f("\u00ea", (Object)r9, (long)1045242168295250508L, (long)l2);
                            }
                            if (bl != ModuleE.c("w", (int)6662, (long)(0x3D67E5A7788052DAL ^ l2))) break block22;
                        }
                        catch (r r10) {
                            throw ModuleE.f("\u00ea", (Object)r10, (long)1045242168295250508L, (long)l2);
                        }
                    }
                    bl = true;
                    break block20;
                }
                catch (r r11) {
                    throw ModuleE.f("\u00ea", (Object)r11, (long)1045242168295250508L, (long)l2);
                }
            }
            bl = false;
        }
        return bl;
    }

    private boolean g(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        Block mc22482 = (Block)objectArray[1];
        l2 = B ^ l2;
        return A.contains(mc22482);
    }

    /*
     * Exception decompiling
     */
    private void c(Object[] var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [36[DOLOOP]], but top level block is 4[TRYBLOCK]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:435)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:484)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void afterEntities(WorldRenderContext worldRenderContext) {
        long l2 = B ^ 0x554D62B96EF4L;
        long l3 = l2 ^ 0x2A8764B68D94L;
        int[] nArray = aD.b();
        if (!this.d()) {
            return;
        }
        PoseStack mc45872 = worldRenderContext.matrices();
        MultiBufferSource mc45972 = worldRenderContext.consumers();
        Camera mc41842 = BaseModule.a.gameRenderer.getMainCamera();
        Vec3 cameraPos = mc41842.position();
        List boxList = this.renderBoxes;
        synchronized (boxList) {
            for (AABB cachedBox : this.renderBoxes) {
                AABB offsetBox = new AABB(cachedBox.minX - cameraPos.x, cachedBox.minY - cameraPos.y, cachedBox.minZ - cameraPos.z, cachedBox.maxX - cameraPos.x, cachedBox.maxY - cameraPos.y, cachedBox.maxZ - cameraPos.z);
                int n2 = ((Double)this.q.a()).intValue();
                int n3 = n2 << 24 | 0xCC0000;
                try {
                    Object[] objectArray = new Object[5];
                    objectArray[4] = l3;
                    objectArray[3] = n3;
                    objectArray[2] = offsetBox;
                    objectArray[1] = mc45972;
                    objectArray[0] = mc45872;
                    ag.r(objectArray);
                    if (nArray != null) {
                        if (nArray != null) continue;
                    }
                    break;
                }
                catch (r r2) {
                    throw ModuleE.a(r2);
                }
            }
            if (((Boolean)this.p.a()).booleanValue()) {
                double d2 = 16384.0;
                int n4 = 0;
                for (BlockPos foundPos : this.foundPositions) {
                    double d3 = foundPos.distToCenterSqr((Position)cameraPos) - d2;
                    double d4 = d3 == 0.0 ? 0 : (d3 > 0.0 ? 1 : -1);
                    if (nArray != null) {
                        if (d4 > 0) continue;
                        d4 = foundPos.getX();
                    }
                    double d5 = (double)d4 - cameraPos.x;
                    double d6 = (double)foundPos.getY() - cameraPos.y;
                    double d7 = (double)foundPos.getZ() - cameraPos.z;
                    AABB box = new AABB(d5, d6, d7, d5 + 1.0, d6 + 1.0, d7 + 1.0);
                    Object[] objectArray = new Object[5];
                    objectArray[4] = l3;
                    objectArray[3] = 1090497194;
                    objectArray[2] = box;
                    objectArray[1] = mc45972;
                    objectArray[0] = mc45872;
                    ag.r(objectArray);
                    if (++n4 < 256 && nArray != null) continue;
                }
            }
            return;
        }
    }

    private static List lambda$recalculateClusters$5(Integer n2) {
        return new ArrayList();
    }

    private static List lambda$recalculateClusters$4(Long l2) {
        return new ArrayList();
    }

    private void lambda$onPacketReceive$3(long l2, int n2, BlockPos mc23382, BlockState mc26802) {
        block3: {
            int n3;
            block4: {
                int[] nArray;
                long l3;
                block2: {
                    long l4 = l2 = B ^ l2;
                    long l5 = l4 ^ 0x627735F55DBL;
                    l3 = l4 ^ 0x59A9EBDE7E93L;
                    nArray = aD.b();
                    n3 = mc23382.getY();
                    if (nArray == null) break block2;
                    if (n3 > n2) break block3;
                    Object[] objectArray = new Object[2];
                    objectArray[1] = mc26802.getBlock();
                    objectArray[0] = l5;
                    n3 = this.g(objectArray) ? 1 : 0;
                }
                if (nArray == null) break block3;
                if (n3 != 0) break block4;
                Object[] objectArray = new Object[2];
                objectArray[1] = mc26802.getBlock();
                objectArray[0] = l3;
                n3 = this.a(objectArray) ? 1 : 0;
                if (nArray == null || n3 == 0) break block3;
            }
            n3 = this.foundPositions.add(mc23382.immutable()) ? 1 : 0;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static boolean lambda$onPacketReceive$2(long l2, Property mc27692) {
        l2 = B ^ l2;
        int[] nArray = aD.b();
        boolean bl = mc27692.getName().equals("powered");
        if (nArray == null) return bl;
        if (bl) return true;
        bl = mc27692.getName().equals("power");
        if (nArray == null) return bl;
        if (bl) return true;
        bl = mc27692.getName().equals("lit");
        if (nArray == null) return bl;
        if (!bl) return false;
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static boolean lambda$onTick$1(char c2, int n2, int n3, short s2, int n4, int n5, ChunkPos mc19232) {
        long l2 = ((long)c2 << 48 | (long)s2 << 48 >>> 16 | (long)n4 << 32 >>> 32) ^ B;
        int[] nArray = aD.b();
        int n6 = Math.abs(mc19232.x - n2);
        if (nArray == null) return n6 != 0;
        if (n6 > n3) return 1 != 0;
        n6 = Math.abs(mc19232.z - n5);
        if (nArray == null) return n6 != 0;
        if (n6 <= n3) return 0 != 0;
        return 1 != 0;
    }

    private static boolean lambda$onTick$0(BlockPos mc23382, double d2, long l2, BlockPos mc23383) {
        l2 = B ^ l2;
        int[] nArray = aD.b();
        double d3 = mc23383.distSqr((Vec3i)mc23382) - d2;
        double d4 = d3 == 0.0 ? 0 : (d3 > 0.0 ? 1 : -1);
        if (nArray != null) {
            d4 = d4 > 0 ? 1.0 : 0.0;
        }
        return (boolean)d4;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block26: {
            block25: {
                block24: {
                    block23: {
                        block22: {
                            block21: {
                                ModuleE.B = kuzi.obf.h.b.v.a(-5878151459531087396L, 6482066018954559411L, MethodHandles.lookup().lookupClass()).a(185879060563552L);
                                var31 = ModuleE.B ^ 95025188244462L;
                                ModuleE.L = new Object[63];
                                ModuleE.M = new String[63];
                                ModuleE.c();
                                ModuleE.E = new HashMap<K, V>(13);
                                var22_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                                v0 = SecretKeyFactory.getInstance("DES");
                                v1 = new byte[8];
                                v2 = v1;
                                v1[0] = (byte)(var31 >>> 56);
                                for (var23_2 = 1; var23_2 < 8; ++var23_2) {
                                    v2 = v2;
                                    v2[var23_2] = (byte)(var31 << var23_2 * 8 >>> 56);
                                }
                                var22_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                                var29_3 = new String[31];
                                var27_4 = 0;
                                var26_5 = "L\u0019\u00cd\u00e8>\br\u00f3j\u0090\u0093j\u00a8\u008a(\u000f\u0091\u00aeQ\u00c5\u00e9\u0018\u00f9\u00e6\u0010\u008f\u00e7;|<t$\u00fc\u00c0\u00ec\u00fa\u001c5\u00bcg\u00e5X(\u00e6_\u00cf\u00cd\u0098W\u00f1\u0080\u0019Z\u00b8\u00a5\u00f1\u00cd2~[\u000b\u009f\r^\u00a9g\u00ca\u0085/:\u00a9\u00a8\u00fb\u00f3\\\u00f19\u00f1\u000b\u00dfX\u0005;\u0018\u00f9O\u0015\u00bb\u00fe\u00aaE\u001ah\u00fe\u00ac\u00c2\u0084\u009c\u00f3\u00c3\u009e\u00a6\u00ed\u001cLh\u0007\u00a3a\"\u00f0\u0092+\u00f4%\u00ef\u0005\u00c4\u00e2\u000bb\u00a6\u000b)\u00b5\u008c\u00e8m\u00b5\u00ec\u0010%\u00f7\u00b0\u00a0\u00c177\u00b7\u00bbp\u00ae(\u00f6\u0002J\u00cd\u0010\u00ea?\u00ad\u0097Y\u00f2o~\u001f\u0000\u0084\u00d7\u00e6e[\u00ec\u0018f\u0081\u0004\u00ed3\u00ca\u00f61\u00baM\u0093\u00e2+\u001fT\u00e7\u00960\u00a3:\"\u00a8[\u00ea\u0010/\u00989\u00a37H\u0011\u00e4\u00a82.\u00f8\u00e0!\u00b5\u0004\u0018\u0001\t\u001d\u008c\u00d7Ku\u00a2_\nQ\u0095\u0086n\u0002\u00b1W\u00a4\u0090\u00fa*\u00d8\u00c1\u00af\u00181\u0089\u00e2\u0017B%\u00eag\u0080\u0017\u00a5Q\u00c5_!:\f\n\u00af@y\u00b3\u0080I\u0010\u0089\u008e=\u009b\u0099mdy\u00e1\u00d96\u00e0\u0011sX\u00ca TH\u0013\u00c2@\u0081\u00cf\u00a5\u0001eBs\u008a1\u00d7\u00bf\u00b4 v\u00d1\u0011:d\u00c9\u00b4\u0007\u009e\u0094Y\u0005\u00e8q\u0018\u0080i\"\u00c3\u00a9\u00dbluO\u009d\u0092p\u00a9\u00e6!\u00c3\u0087\u001aS\u00de\u0000\u007fB\u00d7\u0018\u0097'\u0080\u00f4?\n\u00e1\u00e3\u00cf\u0089bLL8\n\u00d2\u00c4\u00fb\u009f\u0086\t\u00f8a\u00da\u0010\u009bC\u0005.B\u00f9\u00d9U\u00b7\u00de\u00b2\u00be\u001ch\u0012\u00b3\u0010|\u00abu\u00a1vKL\u009c\u001a\u00a7G A\u00b5\u0006\r\u0010\u00f0C\u009e\u001d!Q\u008c\u008a\u00a8\u00e9\u00d9[\u00cf*\u009by \u001au)[iJ\u0003\u00f1bNIw\u00d2G\u0098\u00ad\u0000I\u00fb\u00dcF\f\u00f4)\u00e4\u008a\u00a7\u00d9z57\u0087\u00106\u008b\u001d\u00df\u001e\u00e6\u00f6\u00ce8\u001fT\u00ec\u00b8\u008f\u009b\u0095\u0018\u00d7\u00fd\u008f\u001e\u00aaX\u00e5I\\\u00ed\u00160\u009b>}&@\u00e7\u00abZ~\u00bf\u0017\u00d5\u0010\u0006\u00f2\u00b3n\u00dc\u001c'\u00f6(R\u0090\u008a\u00adk\u00e0\u00ca\u0018\u0003\u00fe\u0090\u00edeB\u0005\u00a8\u0080d\u001f\u008e\u009a\u008e\n\u00ac\u00ffN\u00d5$\u0096\u00926\u00c7(\u00f3\u0015\u00ae\u00cf\u007f2\u008eq\u00dckJ\u0003\u00a1\u00a0\u00bb\u00ff\u00e3(\n\u0092\u0099\u0086\u00eb\u0012^\u0085\u00ec\u00c3\u00f6%M\u00b7\u00e1\u00df\u0099\b7\u008d\u00d3[\u0010\u0010b8d\u00196(4\u007fXJ\u0003\u00ea\u00f8\u00d2\u00fc\u0010\u008cA\u00e6o2\u0012\u00f8\u0084\u00c0NV\u00af\u00bcK\u0097z\u0018\u0002\u0010;\u001c\u00df&\u00f8\u00c2\u00beA\u00d0\u001b]\u00dd\u00e2G\u00b3\u0093\u0012s<\u000e\u00ad\u0014 \u00acH9y\u00a1\u00bc]\r4\u008d\u001f'Qb\u0084#\u00cd\u0002\u00df\u00cf\u0082Tq[o\u00e5K\u00b6\u00ad\u00d7,\u0095\u0010C\u00c3\u0094\u009f\u0014)\u0092\u00f1\u00b7\u0090\u0006&\u0003\u0012\u00e0d\u0010~:m\u00e6'\u0088'\u00cc\u0096\u00ae\u00bf\u00cb\u000f\u00cc\u00e2\u0014 \u00c7{8G\u008a./\u00f3\u009b\u00c7\u00db\u0089)\u00fe\t\u00e8a\u00f8\u0015O\u0018\u0087F'\u00d4\u001c+\u00c1\u001a\u009d\u00ea!";
                                var28_6 = "L\u0019\u00cd\u00e8>\br\u00f3j\u0090\u0093j\u00a8\u008a(\u000f\u0091\u00aeQ\u00c5\u00e9\u0018\u00f9\u00e6\u0010\u008f\u00e7;|<t$\u00fc\u00c0\u00ec\u00fa\u001c5\u00bcg\u00e5X(\u00e6_\u00cf\u00cd\u0098W\u00f1\u0080\u0019Z\u00b8\u00a5\u00f1\u00cd2~[\u000b\u009f\r^\u00a9g\u00ca\u0085/:\u00a9\u00a8\u00fb\u00f3\\\u00f19\u00f1\u000b\u00dfX\u0005;\u0018\u00f9O\u0015\u00bb\u00fe\u00aaE\u001ah\u00fe\u00ac\u00c2\u0084\u009c\u00f3\u00c3\u009e\u00a6\u00ed\u001cLh\u0007\u00a3a\"\u00f0\u0092+\u00f4%\u00ef\u0005\u00c4\u00e2\u000bb\u00a6\u000b)\u00b5\u008c\u00e8m\u00b5\u00ec\u0010%\u00f7\u00b0\u00a0\u00c177\u00b7\u00bbp\u00ae(\u00f6\u0002J\u00cd\u0010\u00ea?\u00ad\u0097Y\u00f2o~\u001f\u0000\u0084\u00d7\u00e6e[\u00ec\u0018f\u0081\u0004\u00ed3\u00ca\u00f61\u00baM\u0093\u00e2+\u001fT\u00e7\u00960\u00a3:\"\u00a8[\u00ea\u0010/\u00989\u00a37H\u0011\u00e4\u00a82.\u00f8\u00e0!\u00b5\u0004\u0018\u0001\t\u001d\u008c\u00d7Ku\u00a2_\nQ\u0095\u0086n\u0002\u00b1W\u00a4\u0090\u00fa*\u00d8\u00c1\u00af\u00181\u0089\u00e2\u0017B%\u00eag\u0080\u0017\u00a5Q\u00c5_!:\f\n\u00af@y\u00b3\u0080I\u0010\u0089\u008e=\u009b\u0099mdy\u00e1\u00d96\u00e0\u0011sX\u00ca TH\u0013\u00c2@\u0081\u00cf\u00a5\u0001eBs\u008a1\u00d7\u00bf\u00b4 v\u00d1\u0011:d\u00c9\u00b4\u0007\u009e\u0094Y\u0005\u00e8q\u0018\u0080i\"\u00c3\u00a9\u00dbluO\u009d\u0092p\u00a9\u00e6!\u00c3\u0087\u001aS\u00de\u0000\u007fB\u00d7\u0018\u0097'\u0080\u00f4?\n\u00e1\u00e3\u00cf\u0089bLL8\n\u00d2\u00c4\u00fb\u009f\u0086\t\u00f8a\u00da\u0010\u009bC\u0005.B\u00f9\u00d9U\u00b7\u00de\u00b2\u00be\u001ch\u0012\u00b3\u0010|\u00abu\u00a1vKL\u009c\u001a\u00a7G A\u00b5\u0006\r\u0010\u00f0C\u009e\u001d!Q\u008c\u008a\u00a8\u00e9\u00d9[\u00cf*\u009by \u001au)[iJ\u0003\u00f1bNIw\u00d2G\u0098\u00ad\u0000I\u00fb\u00dcF\f\u00f4)\u00e4\u008a\u00a7\u00d9z57\u0087\u00106\u008b\u001d\u00df\u001e\u00e6\u00f6\u00ce8\u001fT\u00ec\u00b8\u008f\u009b\u0095\u0018\u00d7\u00fd\u008f\u001e\u00aaX\u00e5I\\\u00ed\u00160\u009b>}&@\u00e7\u00abZ~\u00bf\u0017\u00d5\u0010\u0006\u00f2\u00b3n\u00dc\u001c'\u00f6(R\u0090\u008a\u00adk\u00e0\u00ca\u0018\u0003\u00fe\u0090\u00edeB\u0005\u00a8\u0080d\u001f\u008e\u009a\u008e\n\u00ac\u00ffN\u00d5$\u0096\u00926\u00c7(\u00f3\u0015\u00ae\u00cf\u007f2\u008eq\u00dckJ\u0003\u00a1\u00a0\u00bb\u00ff\u00e3(\n\u0092\u0099\u0086\u00eb\u0012^\u0085\u00ec\u00c3\u00f6%M\u00b7\u00e1\u00df\u0099\b7\u008d\u00d3[\u0010\u0010b8d\u00196(4\u007fXJ\u0003\u00ea\u00f8\u00d2\u00fc\u0010\u008cA\u00e6o2\u0012\u00f8\u0084\u00c0NV\u00af\u00bcK\u0097z\u0018\u0002\u0010;\u001c\u00df&\u00f8\u00c2\u00beA\u00d0\u001b]\u00dd\u00e2G\u00b3\u0093\u0012s<\u000e\u00ad\u0014 \u00acH9y\u00a1\u00bc]\r4\u008d\u001f'Qb\u0084#\u00cd\u0002\u00df\u00cf\u0082Tq[o\u00e5K\u00b6\u00ad\u00d7,\u0095\u0010C\u00c3\u0094\u009f\u0014)\u0092\u00f1\u00b7\u0090\u0006&\u0003\u0012\u00e0d\u0010~:m\u00e6'\u0088'\u00cc\u0096\u00ae\u00bf\u00cb\u000f\u00cc\u00e2\u0014 \u00c7{8G\u008a./\u00f3\u009b\u00c7\u00db\u0089)\u00fe\t\u00e8a\u00f8\u0015O\u0018\u0087F'\u00d4\u001c+\u00c1\u001a\u009d\u00ea!".length();
                                var25_7 = 24;
                                var24_8 = -1;
lbl23:
                                // 2 sources

                                while (true) {
                                    v3 = ++var24_8;
                                    v4 = var26_5.substring(v3, v3 + var25_7);
                                    v5 = -1;
                                    break block21;
                                    break;
                                }
lbl28:
                                // 1 sources

                                while (true) {
                                    var29_3[var27_4++] = ModuleE.b(var30_9).intern();
                                    if ((var24_8 += var25_7) < var28_6) {
                                        var25_7 = var26_5.charAt(var24_8);
                                        ** continue;
                                    }
                                    var26_5 = "\u00c10\u0017#\u0098ma/iI\u00b6Y\u0014\u00c9\u00aaX \u009f$\u00ef\u009a\u00b2l\u00d9\u00ab2\u0098\u00c1\u008eQ\u0098 \u00e8\u00f9e\u00a0j\u00b8\"\u00cb\u001aI\u0006\u0016\u00ba\u00bd|UL";
                                    var28_6 = "\u00c10\u0017#\u0098ma/iI\u00b6Y\u0014\u00c9\u00aaX \u009f$\u00ef\u009a\u00b2l\u00d9\u00ab2\u0098\u00c1\u008eQ\u0098 \u00e8\u00f9e\u00a0j\u00b8\"\u00cb\u001aI\u0006\u0016\u00ba\u00bd|UL".length();
                                    var25_7 = 16;
                                    var24_8 = -1;
lbl37:
                                    // 2 sources

                                    while (true) {
                                        v6 = ++var24_8;
                                        v4 = var26_5.substring(v6, v6 + var25_7);
                                        v5 = 0;
                                        break block21;
                                        break;
                                    }
                                    break;
                                }
lbl42:
                                // 1 sources

                                while (true) {
                                    var29_3[var27_4++] = ModuleE.b(var30_9).intern();
                                    if ((var24_8 += var25_7) < var28_6) {
                                        var25_7 = var26_5.charAt(var24_8);
                                        ** continue;
                                    }
                                    break block22;
                                    break;
                                }
                            }
                            var30_9 = var22_1.doFinal(v4.getBytes("ISO-8859-1"));
                            switch (v5) {
                                default: {
                                    ** continue;
                                }
                                ** case 0:
lbl54:
                                // 1 sources

                                ** continue;
                            }
                        }
                        ModuleE.C = var29_3;
                        ModuleE.D = new String[31];
                        ModuleE.H = new HashMap<K, V>(13);
                        var11_10 = Cipher.getInstance("DES/CBC/NoPadding");
                        v7 = SecretKeyFactory.getInstance("DES");
                        v8 = new byte[8];
                        v9 = v8;
                        v8[0] = (byte)(var31 >>> 56);
                        for (var12_11 = 1; var12_11 < 8; ++var12_11) {
                            v9 = v9;
                            v9[var12_11] = (byte)(var31 << var12_11 * 8 >>> 56);
                        }
                        var11_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                        var17_12 = new long[89];
                        var14_13 = 0;
                        var15_14 = "P\u0002\u00f2\u00c1`\u00a4\u009e\u00fa\u008349H?\u00c4\u0094Q\u00f4`\n\u0088*@!^\u009f,K:CE\u0082\u00fc\u001e!\u00fbe9N.s\u009f\u00ef<Y\u00e6\u00e7K\u00c5\u00d8S\n\u00db\u0015-\u0013\u00de\u00fet\u00a3\u008bVV]+\u00c9t\u0096\u00e3\u00e5_\u00ca\u00c5\u00ae!\u00d7\u00d0\u0012\u00a8UZ\u009e\u00b1\u0015j\u00a9\u00a0\u00e0\u00a5\ti\u00aeO\u00cc\u00d5z\u00b4\u00c06\u00d5\u000ee\u00a6\u00f1\u00f1\u0005\u0000%\u00da\u00c9>K\u0089v\u0098\u0090\u0019:\u0081P'3\u00de\u00fbp+\u00bb^\u00c7\u00a9\u008b\u00f1\u0003uo3$\u0090\u000b\u001cM\u0097\u001atQ\u00d8\u00ac\u0090\u0099!=#\u00d2\u00f2dO\u0082T\u00b8\u00d1b=\r\u0093\u00e1$\u0099\u0015!\u00148\u0006%0t\u00a8\u000f\u00baK\u00a3'\u008a\u00c1\u0015\u00e1\u0014\u0013\u0006\u00b5\u0000x\u00d6\u00b7d2:\u001c\u000f\u001a\u00d2\u008e\u0002\u00f0FG\u009c_\u00a7>\u00df\t\u001a\u008bUBg\u00fd\u0085\u00f4\u00a5m\u0098Aez6\u00f9\u009d\u00c0a\u00dcg\u0083K`\"\u00e9\u0005\u00ae0\u00e0\u0097:\u00ea\u0012X6P\u00be%\u009e\u00e9\u00f6xgAu\u00a2\u0086!\u00eda\u00ab]\u009f\u00ea\u001a\u00db\u00dck>m\u009ad\u0005\u00e7\u00dd\u009b 0%&\u00dd\u009eU\u00f6,t\\\f=\"\u00c7[\u00a0\u0081$I\u00f7\u0087\u00d2\u00d8N\u001a0k\u00daF\u000f'\u0019|\u00efI\u00c4$E\u00fe\u00ec\u00b6\u00b76\u0011\u00c9\u00a4<a\u00d4Ad2\u00b0s\u009aE\u00ceR\u0095\u00ce\u00b6\u0011\u00f2EJ\u00a0\u00bb\u00b6%\u00a1\u008c\u00bcb\u001d\u00cb\u00e5\u00f3Z\u008d\u00ef\u00c7`v\u00ffE\u0094l\u00e2V\u00d8\u00a7\u008f\u0017\u00a5b\u0004\u00a7\u00c1\u00b4i\u008c\u00f7z\u0080\u00f1\u008a\u0017!b\u0081\u00ea\u0003o\u008b\u00c8\u00d9Z\u001c\u008cy\u0096\u009f\u00be,\u0011\u0006\u00eao\u00be\n\u00186\u00fa\u00d4j\u00d8\u00f0\u00e3\u00ef-ga\u0005\u00f3\u0097\u00f0\u0001\u00b9\u00f0=?a!\u00f5\u00b2\u001e\u0080\u00fd\u0095g:\u00a5\u00c9\u0003#\u008c\u00d1\u0083\u00d2{\u00ab(\u000f\"\u00ae\u00ce\u0092)N]<\u00dem\u000b.\u00df\u00f7\u00c3\\Z79\u00d5\u00e1\u00f5\u0091\u00f7\u008d&\u001aq\u00aaz\u00ceM\u00be\u00bb9h\u008e6i\u00bd\u00eb\u009f\u00adJ\u001a\u001b<\u00c8\u00e1\u00f16|V\u0002\u00f0\u008b\"\u00fe $l\f\u00fe\u00cd\u0084*\u0013\u00b7g\u00a6)\u0013\u00a3\u00a4\u00b2-\u0094]\"\u00ea)\u00b2\u0089)j\u00d9?\u00ae\u00cer\u008c\u00f4y#\u009d\u00ad\u00da\u00ccR\u0095\u001a\u00b3\u00cbSz\u00ee)\u0007\u00b5\u0014\u00ceY,\u00a1B\u0088\u0003\u00c6C\u00cb\u0089\u0095Q\\\u00c8\u0006\u00014\u0007\u00f4k\u0017\u00f4Fy\u00a1\u0087\u0019\u001ea\u00d9_\u00ed\u00a1\u00f1\u00e8;\u00ed\u00edH\u00e5\u00b6\u00c2V\u00eaI\u00ce\u009b\u00a5\u009c\u00bf\u00a1Z\u00c1`E\u00f5\u0097\u00e3?\u00cc\u00e6\u00ec\u0084\u001d5z9\u00ee\u00aa\u0017d\u00a8\u00fe\u0090\u00f1t\u00ff\u009c\u0012B4FWx\u009a~\u00daL\b\u00e2\u00f9\u00b5\u0086\u0080V\u00ef\u000er\u00f4B\u00cd\u009b@dM\u00c7[oDj\u0017\u00c5\u0094\u00f4\u00d8\u00b1\u00da\u001b\u00d3s\u00d4\u0003\u00f0\u00f2I?\u00d9J\u00ed\u0001\u00c4\u00dc\u00ef\u00b7";
                        var16_15 = "P\u0002\u00f2\u00c1`\u00a4\u009e\u00fa\u008349H?\u00c4\u0094Q\u00f4`\n\u0088*@!^\u009f,K:CE\u0082\u00fc\u001e!\u00fbe9N.s\u009f\u00ef<Y\u00e6\u00e7K\u00c5\u00d8S\n\u00db\u0015-\u0013\u00de\u00fet\u00a3\u008bVV]+\u00c9t\u0096\u00e3\u00e5_\u00ca\u00c5\u00ae!\u00d7\u00d0\u0012\u00a8UZ\u009e\u00b1\u0015j\u00a9\u00a0\u00e0\u00a5\ti\u00aeO\u00cc\u00d5z\u00b4\u00c06\u00d5\u000ee\u00a6\u00f1\u00f1\u0005\u0000%\u00da\u00c9>K\u0089v\u0098\u0090\u0019:\u0081P'3\u00de\u00fbp+\u00bb^\u00c7\u00a9\u008b\u00f1\u0003uo3$\u0090\u000b\u001cM\u0097\u001atQ\u00d8\u00ac\u0090\u0099!=#\u00d2\u00f2dO\u0082T\u00b8\u00d1b=\r\u0093\u00e1$\u0099\u0015!\u00148\u0006%0t\u00a8\u000f\u00baK\u00a3'\u008a\u00c1\u0015\u00e1\u0014\u0013\u0006\u00b5\u0000x\u00d6\u00b7d2:\u001c\u000f\u001a\u00d2\u008e\u0002\u00f0FG\u009c_\u00a7>\u00df\t\u001a\u008bUBg\u00fd\u0085\u00f4\u00a5m\u0098Aez6\u00f9\u009d\u00c0a\u00dcg\u0083K`\"\u00e9\u0005\u00ae0\u00e0\u0097:\u00ea\u0012X6P\u00be%\u009e\u00e9\u00f6xgAu\u00a2\u0086!\u00eda\u00ab]\u009f\u00ea\u001a\u00db\u00dck>m\u009ad\u0005\u00e7\u00dd\u009b 0%&\u00dd\u009eU\u00f6,t\\\f=\"\u00c7[\u00a0\u0081$I\u00f7\u0087\u00d2\u00d8N\u001a0k\u00daF\u000f'\u0019|\u00efI\u00c4$E\u00fe\u00ec\u00b6\u00b76\u0011\u00c9\u00a4<a\u00d4Ad2\u00b0s\u009aE\u00ceR\u0095\u00ce\u00b6\u0011\u00f2EJ\u00a0\u00bb\u00b6%\u00a1\u008c\u00bcb\u001d\u00cb\u00e5\u00f3Z\u008d\u00ef\u00c7`v\u00ffE\u0094l\u00e2V\u00d8\u00a7\u008f\u0017\u00a5b\u0004\u00a7\u00c1\u00b4i\u008c\u00f7z\u0080\u00f1\u008a\u0017!b\u0081\u00ea\u0003o\u008b\u00c8\u00d9Z\u001c\u008cy\u0096\u009f\u00be,\u0011\u0006\u00eao\u00be\n\u00186\u00fa\u00d4j\u00d8\u00f0\u00e3\u00ef-ga\u0005\u00f3\u0097\u00f0\u0001\u00b9\u00f0=?a!\u00f5\u00b2\u001e\u0080\u00fd\u0095g:\u00a5\u00c9\u0003#\u008c\u00d1\u0083\u00d2{\u00ab(\u000f\"\u00ae\u00ce\u0092)N]<\u00dem\u000b.\u00df\u00f7\u00c3\\Z79\u00d5\u00e1\u00f5\u0091\u00f7\u008d&\u001aq\u00aaz\u00ceM\u00be\u00bb9h\u008e6i\u00bd\u00eb\u009f\u00adJ\u001a\u001b<\u00c8\u00e1\u00f16|V\u0002\u00f0\u008b\"\u00fe $l\f\u00fe\u00cd\u0084*\u0013\u00b7g\u00a6)\u0013\u00a3\u00a4\u00b2-\u0094]\"\u00ea)\u00b2\u0089)j\u00d9?\u00ae\u00cer\u008c\u00f4y#\u009d\u00ad\u00da\u00ccR\u0095\u001a\u00b3\u00cbSz\u00ee)\u0007\u00b5\u0014\u00ceY,\u00a1B\u0088\u0003\u00c6C\u00cb\u0089\u0095Q\\\u00c8\u0006\u00014\u0007\u00f4k\u0017\u00f4Fy\u00a1\u0087\u0019\u001ea\u00d9_\u00ed\u00a1\u00f1\u00e8;\u00ed\u00edH\u00e5\u00b6\u00c2V\u00eaI\u00ce\u009b\u00a5\u009c\u00bf\u00a1Z\u00c1`E\u00f5\u0097\u00e3?\u00cc\u00e6\u00ec\u0084\u001d5z9\u00ee\u00aa\u0017d\u00a8\u00fe\u0090\u00f1t\u00ff\u009c\u0012B4FWx\u009a~\u00daL\b\u00e2\u00f9\u00b5\u0086\u0080V\u00ef\u000er\u00f4B\u00cd\u009b@dM\u00c7[oDj\u0017\u00c5\u0094\u00f4\u00d8\u00b1\u00da\u001b\u00d3s\u00d4\u0003\u00f0\u00f2I?\u00d9J\u00ed\u0001\u00c4\u00dc\u00ef\u00b7".length();
                        var13_16 = 0;
                        while (true) {
                            var18_17 = var15_14.substring(var13_16, var13_16 += 8).getBytes("ISO-8859-1");
                            v10 = var17_12;
                            v11 = var14_13++;
                            v12 = ((long)var18_17[0] & 255L) << 56 | ((long)var18_17[1] & 255L) << 48 | ((long)var18_17[2] & 255L) << 40 | ((long)var18_17[3] & 255L) << 32 | ((long)var18_17[4] & 255L) << 24 | ((long)var18_17[5] & 255L) << 16 | ((long)var18_17[6] & 255L) << 8 | (long)var18_17[7] & 255L;
                            v13 = -1;
                            break block23;
                            break;
                        }
lbl81:
                        // 1 sources

                        while (true) {
                            v10[v11] = v14;
                            if (var13_16 < var16_15) ** continue;
                            var15_14 = "\u0098y#\u00b0\u00a7\u00e2\u0018P4\u0013\u00c2mj\u00c6\u0095G";
                            var16_15 = "\u0098y#\u00b0\u00a7\u00e2\u0018P4\u0013\u00c2mj\u00c6\u0095G".length();
                            var13_16 = 0;
                            while (true) {
                                var18_17 = var15_14.substring(var13_16, var13_16 += 8).getBytes("ISO-8859-1");
                                v10 = var17_12;
                                v11 = var14_13++;
                                v12 = ((long)var18_17[0] & 255L) << 56 | ((long)var18_17[1] & 255L) << 48 | ((long)var18_17[2] & 255L) << 40 | ((long)var18_17[3] & 255L) << 32 | ((long)var18_17[4] & 255L) << 24 | ((long)var18_17[5] & 255L) << 16 | ((long)var18_17[6] & 255L) << 8 | (long)var18_17[7] & 255L;
                                v13 = 0;
                                break block23;
                                break;
                            }
                            break;
                        }
lbl94:
                        // 1 sources

                        while (true) {
                            v10[v11] = v14;
                            if (var13_16 < var16_15) ** continue;
                            break block24;
                            break;
                        }
                    }
                    var19_18 = v12;
                    var21_19 = var11_10.doFinal(new byte[]{(byte)(var19_18 >>> 56), (byte)(var19_18 >>> 48), (byte)(var19_18 >>> 40), (byte)(var19_18 >>> 32), (byte)(var19_18 >>> 24), (byte)(var19_18 >>> 16), (byte)(var19_18 >>> 8), (byte)var19_18});
                    v14 = ((long)var21_19[0] & 255L) << 56 | ((long)var21_19[1] & 255L) << 48 | ((long)var21_19[2] & 255L) << 40 | ((long)var21_19[3] & 255L) << 32 | ((long)var21_19[4] & 255L) << 24 | ((long)var21_19[5] & 255L) << 16 | ((long)var21_19[6] & 255L) << 8 | (long)var21_19[7] & 255L;
                    switch (v13) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl107:
                        // 1 sources

                        ** continue;
                    }
                }
                ModuleE.F = var17_12;
                ModuleE.G = new Integer[89];
                ModuleE.z = 256;
                ModuleE.y = 2;
                ModuleE.K = new HashMap<K, V>(13);
                var0_20 = Cipher.getInstance("DES/CBC/NoPadding");
                v15 = SecretKeyFactory.getInstance("DES");
                v16 = new byte[8];
                v17 = v16;
                v16[0] = (byte)(var31 >>> 56);
                for (var1_21 = 1; var1_21 < 8; ++var1_21) {
                    v17 = v17;
                    v17[var1_21] = (byte)(var31 << var1_21 * 8 >>> 56);
                }
                var0_20.init(2, (Key)v15.generateSecret(new DESKeySpec(v17)), new IvParameterSpec(new byte[8]));
                var6_22 = new long[2];
                var3_23 = 0;
                var4_24 = "\u0003\u0089\u009f\u0095\u00e2!\u00b9\u00f2\u0012\u00dc\u0095D\n\u00b4\u009fx";
                var5_25 = "\u0003\u0089\u009f\u0095\u00e2!\u00b9\u00f2\u0012\u00dc\u0095D\n\u00b4\u009fx".length();
                var2_26 = 0;
                while (true) {
                    break block25;
                    break;
                }
lbl133:
                // 1 sources

                while (true) {
                    var6_22[v18] = ((long)var10_29[0] & 255L) << 56 | ((long)var10_29[1] & 255L) << 48 | ((long)var10_29[2] & 255L) << 40 | ((long)var10_29[3] & 255L) << 32 | ((long)var10_29[4] & 255L) << 24 | ((long)var10_29[5] & 255L) << 16 | ((long)var10_29[6] & 255L) << 8 | (long)var10_29[7] & 255L;
                    if (var2_26 < var5_25) ** continue;
                    break block26;
                    break;
                }
            }
            var7_27 = var4_24.substring(var2_26, var2_26 += 8).getBytes("ISO-8859-1");
            v18 = var3_23++;
            var8_28 = ((long)var7_27[0] & 255L) << 56 | ((long)var7_27[1] & 255L) << 48 | ((long)var7_27[2] & 255L) << 40 | ((long)var7_27[3] & 255L) << 32 | ((long)var7_27[4] & 255L) << 24 | ((long)var7_27[5] & 255L) << 16 | ((long)var7_27[6] & 255L) << 8 | (long)var7_27[7] & 255L;
            var10_29 = var0_20.doFinal(new byte[]{(byte)(var8_28 >>> 56), (byte)(var8_28 >>> 48), (byte)(var8_28 >>> 40), (byte)(var8_28 >>> 32), (byte)(var8_28 >>> 24), (byte)(var8_28 >>> 16), (byte)(var8_28 >>> 8), (byte)var8_28});
            ** while (true)
        }
        ModuleE.I = var6_22;
        ModuleE.J = new Long[2];
        v19 = new Block[73];
        v19[0] = Blocks.REDSTONE_WIRE;
        v19[1] = Blocks.REDSTONE_TORCH;
        v19[2] = Blocks.REDSTONE_WALL_TORCH;
        v19[3] = Blocks.REDSTONE_BLOCK;
        v19[4] = Blocks.REPEATER;
        v19[5] = Blocks.COMPARATOR;
        v19[6] = Blocks.PISTON;
        v19[7] = Blocks.STICKY_PISTON;
        v19[8] = Blocks.OBSERVER;
        v19[9] = Blocks.HOPPER;
        v19[10] = Blocks.DISPENSER;
        v19[11] = Blocks.DROPPER;
        v19[12] = Blocks.LEVER;
        v19[13] = Blocks.STONE_BUTTON;
        v19[14] = Blocks.OAK_BUTTON;
        v19[15] = Blocks.SPRUCE_BUTTON;
        v19[16] = Blocks.BIRCH_BUTTON;
        v19[17] = Blocks.JUNGLE_BUTTON;
        v19[18] = Blocks.ACACIA_BUTTON;
        v19[19] = Blocks.DARK_OAK_BUTTON;
        v19[20] = Blocks.MANGROVE_BUTTON;
        v19[21] = Blocks.CHERRY_BUTTON;
        v19[22] = Blocks.BAMBOO_BUTTON;
        v19[23] = Blocks.CRIMSON_BUTTON;
        v19[24] = Blocks.WARPED_BUTTON;
        v19[25] = Blocks.POLISHED_BLACKSTONE_BUTTON;
        v19[26] = Blocks.LIGHT_WEIGHTED_PRESSURE_PLATE;
        v19[27] = Blocks.HEAVY_WEIGHTED_PRESSURE_PLATE;
        v19[28] = Blocks.STONE_PRESSURE_PLATE;
        v19[29] = Blocks.OAK_PRESSURE_PLATE;
        v19[30] = Blocks.SPRUCE_PRESSURE_PLATE;
        v19[31] = Blocks.BIRCH_PRESSURE_PLATE;
        v19[32] = Blocks.JUNGLE_PRESSURE_PLATE;
        v19[33] = Blocks.ACACIA_PRESSURE_PLATE;
        v19[34] = Blocks.DARK_OAK_PRESSURE_PLATE;
        v19[35] = Blocks.MANGROVE_PRESSURE_PLATE;
        v19[36] = Blocks.CHERRY_PRESSURE_PLATE;
        v19[37] = Blocks.BAMBOO_PRESSURE_PLATE;
        v19[38] = Blocks.CRIMSON_PRESSURE_PLATE;
        v19[39] = Blocks.WARPED_PRESSURE_PLATE;
        v19[40] = Blocks.POLISHED_BLACKSTONE_PRESSURE_PLATE;
        v19[41] = Blocks.TRIPWIRE_HOOK;
        v19[42] = Blocks.TRIPWIRE;
        v19[43] = Blocks.IRON_DOOR;
        v19[44] = Blocks.OAK_DOOR;
        v19[45] = Blocks.SPRUCE_DOOR;
        v19[46] = Blocks.BIRCH_DOOR;
        v19[47] = Blocks.JUNGLE_DOOR;
        v19[48] = Blocks.ACACIA_DOOR;
        v19[49] = Blocks.DARK_OAK_DOOR;
        v19[50] = Blocks.MANGROVE_DOOR;
        v19[51] = Blocks.CHERRY_DOOR;
        v19[52] = Blocks.BAMBOO_DOOR;
        v19[53] = Blocks.CRIMSON_DOOR;
        v19[54] = Blocks.WARPED_DOOR;
        v19[55] = Blocks.IRON_TRAPDOOR;
        v19[56] = Blocks.OAK_TRAPDOOR;
        v19[57] = Blocks.SPRUCE_TRAPDOOR;
        v19[58] = Blocks.BIRCH_TRAPDOOR;
        v19[59] = Blocks.JUNGLE_TRAPDOOR;
        v19[60] = Blocks.ACACIA_TRAPDOOR;
        v19[61] = Blocks.DARK_OAK_TRAPDOOR;
        v19[62] = Blocks.MANGROVE_TRAPDOOR;
        v19[63] = Blocks.CHERRY_TRAPDOOR;
        v19[64] = Blocks.BAMBOO_TRAPDOOR;
        v19[65] = Blocks.CRIMSON_TRAPDOOR;
        v19[66] = Blocks.WARPED_TRAPDOOR;
        v19[67] = Blocks.CHEST;
        v19[68] = Blocks.TRAPPED_CHEST;
        v19[69] = Blocks.NOTE_BLOCK;
        v19[70] = Blocks.CRAFTER;
        v19[71] = Blocks.SPAWNER;
        v19[72] = Blocks.ENDER_CHEST;
        ModuleE.A = Set.of(v19);
    }

    private static r a(r r2) {
        return r2;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static String b(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x4009;
        if (D[n3] == null) {
            Object[] objectArray;
            try {
                Long l3 = Thread.currentThread().threadId();
                objectArray = (Object[])E.get(l3);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    E.put(l3, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/g/E", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l2 >>> 56);
            for (int i2 = 1; i2 < 8; ++i2) {
                byArray[i2] = (byte)(l2 << i2 * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = C[n3].getBytes("ISO-8859-1");
            ModuleE.D[n3] = ModuleE.b(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return D[n3];
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        String string2 = ModuleE.b(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static CallSite b(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/E" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x464A;
        if (G[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = F[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])H.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    H.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/g/E", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            ModuleE.G[n3] = n4;
        }
        return G[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = ModuleE.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/E" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static long d(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x50D5;
        if (J[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = I[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])K.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    K.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/g/E", exception);
            }
            long l5 = ((long)byArray[0] & 0xFFL) << 56 | ((long)byArray[1] & 0xFFL) << 48 | ((long)byArray[2] & 0xFFL) << 40 | ((long)byArray[3] & 0xFFL) << 32 | ((long)byArray[4] & 0xFFL) << 24 | ((long)byArray[5] & 0xFFL) << 16 | ((long)byArray[6] & 0xFFL) << 8 | (long)byArray[7] & 0xFFL;
            ModuleE.J[n3] = l5;
        }
        return J[n3];
    }

    private static long d(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        long l3 = ModuleE.d(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Long.TYPE, l3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return l3;
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_2().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/E" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (M[n4] != null) {
            return n4;
        }
        Object object = L[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 55;
            case 1 -> 15;
            case 2 -> 4;
            case 3 -> 2;
            case 4 -> 24;
            case 5 -> 18;
            case 6 -> 44;
            case 7 -> 41;
            case 8 -> 28;
            case 9 -> 53;
            case 10 -> 56;
            case 11 -> 8;
            case 12 -> 14;
            case 13 -> 32;
            case 14 -> 61;
            case 15 -> 47;
            case 16 -> 22;
            case 17 -> 54;
            case 18 -> 57;
            case 19 -> 23;
            case 20 -> 17;
            case 21 -> 63;
            case 22 -> 60;
            case 23 -> 45;
            case 24 -> 16;
            case 25 -> 59;
            case 26 -> 30;
            case 27 -> 6;
            case 28 -> 27;
            case 29 -> 26;
            case 30 -> 38;
            case 31 -> 7;
            case 32 -> 50;
            case 33 -> 21;
            case 34 -> 9;
            case 35 -> 62;
            case 36 -> 39;
            case 37 -> 48;
            case 38 -> 37;
            case 39 -> 0;
            case 40 -> 40;
            case 41 -> 43;
            case 42 -> 51;
            case 43 -> 25;
            case 44 -> 3;
            case 45 -> 10;
            case 46 -> 49;
            case 47 -> 42;
            case 48 -> 52;
            case 49 -> 58;
            case 50 -> 29;
            case 51 -> 31;
            case 52 -> 46;
            case 53 -> 11;
            case 54 -> 34;
            case 55 -> 19;
            case 56 -> 5;
            case 57 -> 36;
            case 58 -> 12;
            case 59 -> 1;
            case 60 -> 13;
            case 61 -> 33;
            case 62 -> 20;
            default -> 35;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        ModuleE.M[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = L;
        L[0] = "\u001d0\u0017>YY\u00160\u0011>Y3";
        objectArray[1] = "|S";
        objectArray[2] = "\\@WR\u0003QW@QR'";
        objectArray[3] = "\u001bQq\u00175G\u0017Qb";
        objectArray[4] = "~\u0004Q\u00176=\u000b$Z\u0018'rj*Q\u0013#(\u001e";
        objectArray[5] = Boolean.TYPE;
        ModuleE.M[5] = "java/lang/Boolean";
        objectArray[6] = "\u001f~M\u0014w\bj^F\u001bfG\u000bPM\u0010b\u001d\u007f";
        objectArray[7] = "80PVc\b&8J\u0019\u001e\u0018&";
        objectArray[8] = Long.TYPE;
        ModuleE.M[8] = "java/lang/Long";
        objectArray[9] = "Df\u000f7\u000e7Mf\f7\f";
        objectArray[10] = "M'\u0001q\u0014`D'\u0002q\u0018";
        objectArray[11] = "Yi`\u0016\u001e\u0006Rih";
        objectArray[12] = "%A->\u0012$.A&";
        objectArray[13] = "vpr[&.\u0003PyT7ab^r_3;\u0016";
        objectArray[14] = Void.TYPE;
        ModuleE.M[14] = "java/lang/Void";
        objectArray[15] = "Xja<\u000f/Xjv`\u0003 B!v~\u00035EP&#R";
        objectArray[16] = "\u0003E\u001eGGb\u001dM\u0004\b%~\u001aP";
        objectArray[17] = "]d\n(<K(D\u0001'-\u0004IJ\n,)^=";
        objectArray[18] = "aK%+4~\u0014k.$%1ue%/!k\u0001";
        objectArray[19] = "E#etv\u0007L#ftv";
        objectArray[20] = "[\u0001\u001f\bfxP\u000e\u000eG\u0007v[\u0005\n\u001d";
        objectArray[21] = "E8%F\u0005\u00120\u0018.I\u0014]Q\u0016%B\u0010\u0007%";
        objectArray[22] = "\u0004\u001dU\u0012\r2q=^\u001d\u001c}\u00103U\u0016\u0018'd";
        objectArray[23] = ")[Bf-I\\{Ii<\u0006=uBb8\\I";
        objectArray[24] = "y%>)A0\f\u00055&P\u007fm\u000b>-T%\u0019";
        objectArray[25] = Integer.TYPE;
        ModuleE.M[25] = "java/lang/Integer";
        objectArray[26] = "\u0002+\u0018\u001d\u000b)w\u000b\u0013\u0012\u001af\u0016\u0005\u0018\u0019\u001e<b";
        objectArray[27] = "&P:Jc~Sp1Er12~:NvkF";
        objectArray[28] = "CsQSKs6SZ\\Z<W]QW^f#";
        objectArray[29] = "Ecsd TTcs-";
        objectArray[30] = "\u001fCViZYjc]fK\u0016\u000bmVmOL\u007f";
        objectArray[31] = "~\u0015,_2L+\u0002sF\u000bJGExC:W?A-Ys";
        objectArray[32] = "E\u001d4\t_8\u0010\nk\u0010f;|Nd\u0017\u0002,\u0016\u0013\u007f\u001a[";
        objectArray[33] = "I>M.hE\u001c)\u00127QRp4\u0017)*F\u0015i\u0001k+;\u00104\u001bf?\u0005\u0015:\u001a=Q";
        objectArray[34] = "p\u00063KW8%\u0011lRn/I\fiL\u0015;,Q\u007f\u000e\u0014FuS2\n\u000244PlTn";
        objectArray[35] = "/\u007fUHS[zh\nQjN\u0016u\u000fO\u0011Xs(\u0019\r\u0010%\u007f!\u0007CRCjw\u0005Hj";
        objectArray[36] = "k\u0012\u0007/h{>\u0005X6QoR\u0018](*x7EKj+\u0005o\u0007\u000bi=x7\u0010V3Q";
        objectArray[37] = "7KR\f\u0007\tb\\\r\u0015>\u0019\u000eA\b\u000bE\nk\u001c\u001eIDw2\u001eSMR\u0005s\u001d\r\u0013>";
        objectArray[38] = "z\b\u0000x\n#/\u001f_a3\u0014C[PfW7)\u0006Kk\u000e";
        objectArray[39] = "\\)h\u0000q*\t>7\u0019H;e#2\u00073)\u0000~$E2TY|iA$&\u0018\u007f7\u001fH";
        objectArray[40] = ">|\u0014WCfkkKNzq\u0007(B@\u0015`?#_\u0015\u0007\u0018=tJA\u0002 6i\u001fSz";
        objectArray[41] = "_\u00076yV1\n\u0010i`o)fVem\u00025\u0018\fmn\u001d";
        objectArray[42] = "c\\\u0012p\u0019;6KMi ?Z\fFl\u0011 \"\b\u0013vX";
        objectArray[43] = "B\u0015|C<f\u0017\u0002#Z\u0005a{D/Whb\u0005\u001e'Tw";
        objectArray[44] = "r(^\b2V'?\u0001\u0011\u000bSK{\u000e\u0016oB!&\u0015\u001b6";
        objectArray[45] = "\\o\"M\u0001H\u0001{?\u001dnB?d(\u0002\u0015EZ9>@\u00148V0 \u000eV^Cf\"\u0005n";
        objectArray[46] = " \u0010k\u0014J*s\u001dn\u001f >L\u0001%OR53\u0007h\u001a\u001fW";
        objectArray[47] = "Y\u0011qy\r1\f\u0006.`4&`\u001b+~O2\u0005F=<NO]\u0004}?X2\u0005\u0013 e4";
        objectArray[48] = "\u00006-z\t[U!rc0I9<w}KX\\aa?J%\u0005c,;\\WD`re0";
        objectArray[49] = "nr\u0013\u0006$O;eL\u001f\u001dAW!XC\"]*yO\u001ex";
        objectArray[50] = "x\u001f5Y\bs-\bj@1hANfM\\w?\u0014nNC";
        objectArray[51] = "k\u0006BY<\u001f>\u0011\u001d@\u0005\u001fRU\t\u001c:\r/\r\u001eA`";
        objectArray[52] = "LV#VG8\u0019A|O~,u\\yQ\u0005;\u0010\u0001o\u0013\u0004F\u001c\bq]F \t^sV~";
        objectArray[53] = "\u0014\u000b\u000e-@\u000bZ\u0017\u000e2z\u001c$\f\u00037@OC\u001a\u0003m\u0015";
        objectArray[54] = ")\u00116`z\\|\u0006iyC^\u0010\u0015mtr[t\u0015ay~";
        objectArray[55] = "wNU{4$\"Y\nb\r6ND\u000f|v'+\u0019\u0019>wZ'\u0010\u0007p5<2F\u0005{\r";
        objectArray[56] = "+\t}v.XfIiM~)-B6roBw\u0014h3\u0014";
        objectArray[57] = "^h\u001c}Qt\u000b\u007fCdhug;W8Wf\u001ac@e\r";
        objectArray[58] = "D\u00150\u0019\u0018\u0010\n\t0\u0006\"\u0002tGaV\u001a\u0002\u0006\u0006b\bDn";
        objectArray[59] = "yXN|T;,O\u0011em\"@\t\u001dh\u0000?>S\u0015k\u001f";
        objectArray[60] = "4\u0010YS|:hDWN\u001e[C#cd\u001e4m\u0007\\J h9\tA";
        objectArray[61] = "\u0018AD\u001f\u0002>MV\u001b\u0006;)!K\u001e\u0018@=D\u0016\bZA@H\u001f\u0016\u0014\u0003&]I\u0014\u001f;";
        Object[] objectArray2 = objectArray;
        objectArray[62] = ":nWKc\u0004trWTY\u001e\ndWK\"\u0007o9A\t#zc0_Ga\u001cvf]LY";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = ModuleE.e(l2, l3);
            object = L[n2];
            try {
                if (!(object instanceof String)) break block2;
                ModuleE.L[n2] = clazz = Class.forName(M[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = ModuleE.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = ModuleE.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = ModuleE.e(l2, l3);
        Object object = L[n2];
        if (object instanceof String) {
            String string = M[n2];
            int n3 = string.indexOf(8);
            Class clazz = ModuleE.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = ModuleE.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = ModuleE.c(clazz3, string2, clazz2)) != null) {
                    ModuleE.L[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = ModuleE.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        ModuleE.L[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = ModuleE.f(1414002003291043L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = ModuleE.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = ModuleE.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = ModuleE.e(l2, l3);
        Object object = L[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = M[n2];
                int n4 = string2.indexOf(8);
                clazz3 = ModuleE.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = ModuleE.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = ModuleE.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        ModuleE.L[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = ModuleE.f(1414002003291043L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = ModuleE.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        ModuleE.L[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = ModuleE.f(1414002003291043L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == '\u00ce' || c2 == 't' || c2 == '\u00c6' || c2 == '\u00dd') {
                field = ModuleE.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == '\u00ce' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == 't' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == '\u00c6' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = ModuleE.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == 'h' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == '\u00ea' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = ModuleE.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite f(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_3().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/E" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(ModuleE.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(ModuleE.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_2() {
        try {
            return MethodHandles.lookup().findStatic(ModuleE.class, "d", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_3() {
        try {
            return MethodHandles.lookup().findStatic(ModuleE.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

