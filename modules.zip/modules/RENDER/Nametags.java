// === Kuzi module: Nametags ===
// Category   : RENDER
// Description: Player nametags: name/health/distance/ping + items, enchants, effects
// Payload    : a.a.a.j.g.ac (verified: False)

package kuzi.modules.render;

import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.core.Client;
import kuzi.mixin.MixinExposed;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.modules.server.NameProtect;
import kuzi.obf.e.i;
import kuzi.obf.h.b.e;
import kuzi.obf.h.b.l;
import kuzi.obf.h.b.v;
import kuzi.obf.h.d_0;
import kuzi.obf.j.g.aD;
import kuzi.obf.j.g.aI;
import kuzi.obf.j.g.y;
import kuzi.obf.l.c.b;
import kuzi.obf.l.c.c;
import kuzi.obf.m.r;
import kuzi.obf.p.F;
import kuzi.obf.p.ac_0;
import kuzi.settings.BoolSetting;
import kuzi.settings.ButtonSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.MobEffectInstance;
import net.minecraft.Entity;
import net.minecraft.EquipmentSlot;
import net.minecraft.LivingEntity;
import net.minecraft.Player;
import net.minecraft.ItemStack;
import net.minecraft.Enchantment;
import net.minecraft.EnchantmentHelper;
import net.minecraft.Vec3;
import net.minecraft.Identifier;
import net.minecraft.Minecraft;
import net.minecraft.Gui;
import net.minecraft.Mth;
import net.minecraft.ClientPacketListener;
import net.minecraft.PlayerInfo;
import net.minecraft.Holder;
import net.minecraft.AbstractClientPlayer;
import net.minecraft.LocalPlayer;
import net.minecraft.ItemEnchantments;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class Nametags
extends BaseModule {
    private static final float m = 8.5f;
    private static final float n = 6.5f;
    private static final float o = 5.0f;
    private static final float p = 13.0f;
    private static final float q = 4.0f;
    private static final float r = 12.0f;
    private static final float s = 2.0f;
    private static final int t;
    private final BoolSetting self;
    private final BoolSetting showInvisibles;
    private final l w;
    private final SliderSetting scale;
    private final SliderSetting y;
    private final BoolSetting name2;
    private final BoolSetting health;
    private final BoolSetting absorption;
    private final BoolSetting distance;
    private final BoolSetting ping;
    private final BoolSetting E;
    private final BoolSetting handItems;
    private final BoolSetting enchants;
    private final BoolSetting effects;
    private final e I;
    private final e J;
    private final e K;
    private final e L;
    private final e M;
    private final e N;
    private final e O;
    private final ButtonSetting openEditor;
    private static volatile Nametags Q;
    private static final long R;
    private static final String[] S;
    private static final String[] T;
    private static final Map U;
    private static final long[] V;
    private static final Integer[] W;
    private static final Map X;
    private static final Object[] Y;
    private static final String[] Z;

    public Nametags() {
        long l2;
        long l3 = l2 = R ^ 0x46F7866A5DBL;
        long l4 = l3 ^ 0x2CD263DA4CFDL;
        long l5 = l3 ^ 0x194F01ACC59DL;
        super("Nametags", "Player nametags: name/health/distance/ping + items, enchants, effects", Category.RENDER);
        this.self = new BoolSetting("Self", false);
        this.showInvisibles = new BoolSetting("Show Invisibles", true);
        this.w = new l("Name Display", kuzi.obf.j.g.y.DISPLAY_NAME, y.class);
        this.scale = new SliderSetting("Scale", 1.0, 0.3, 2.0, 0.05);
        this.y = new SliderSetting("Range", 64.0, 8.0, 512.0, 1.0);
        this.name2 = new BoolSetting("Name", true);
        this.health = new BoolSetting("Health", true);
        this.absorption = new BoolSetting("Absorption", true);
        this.distance = new BoolSetting("Distance", true);
        this.ping = new BoolSetting("Ping", false);
        this.E = new BoolSetting("Armor", true);
        this.handItems = new BoolSetting("Hand Items", true);
        this.enchants = new BoolSetting("Enchants", false);
        this.effects = new BoolSetting("Effects", false);
        this.I = new e("Background Color", new Color(0, 0, 0, 170));
        this.J = new e("Name Color", new Color(237, 240, 244));
        this.K = new e("Friend Name Color", new Color(75, 191, 74));
        this.L = new e("Health Color", new Color(255, 255, 255));
        this.M = new e("Absorption Color", new Color(255, 196, 76));
        this.N = new e("Distance Color", new Color(150, 157, 153));
        this.O = new e("Ping Color", new Color(255, 255, 255));
        this.openEditor = new ButtonSetting("Open Editor", () -> Nametags.lambda$new$0(l4));
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.openEditor, this.self, this.showInvisibles, this.w, this.scale, this.y, this.name2, this.health, this.absorption, this.distance, this.ping, this.E, this.handItems, this.enchants, this.effects, this.I, this.J, this.K, this.L, this.M, this.N, this.O};
        objectArray[0] = l5;
        this.l(objectArray);
        Q = this;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @MixinExposed
    public static boolean a(LivingEntity mc13092) {
        LivingEntity mc13093;
        block5: {
            boolean bl;
            block4: {
                Nametags nametags = Q;
                int[] nArray = aD.b();
                Nametags nametags2 = nametags;
                if (nArray != null) {
                    if (nametags2 == null) return false;
                    nametags2 = nametags;
                }
                bl = nametags2.d();
                if (nArray == null) break block4;
                if (!bl) return false;
                mc13093 = mc13092;
                if (nArray == null) break block5;
                bl = mc13093 instanceof Player;
            }
            if (!bl) return false;
            mc13093 = mc13092;
        }
        if (mc13093 == Minecraft.getInstance().player) return false;
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @MixinExposed
    public static boolean a() {
        Nametags nametags = Q;
        int[] nArray = aD.b();
        Nametags nametags2 = nametags;
        if (nArray != null) {
            if (nametags2 == null) return false;
            nametags2 = nametags;
        }
        boolean bl = nametags2.d();
        if (nArray != null) {
            if (!bl) return false;
            bl = (Boolean)nametags.v.a();
        }
        if (nArray == null) return bl;
        if (!bl) return false;
        return true;
    }

    public List b(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = R ^ l2;
        return List.of(Nametags.d("G", (Object)this, (long)-1209291823662661409L, (long)l2), Nametags.d("G", (Object)this, (long)-1208644327590907452L, (long)l2), Nametags.d("G", (Object)this, (long)-1207123858632076842L, (long)l2), Nametags.d("G", (Object)this, (long)-1208327645957839056L, (long)l2), Nametags.d("G", (Object)this, (long)-1214850434594197004L, (long)l2), Nametags.d("G", (Object)this, (long)-1206990072490940242L, (long)l2), Nametags.d("G", (Object)this, (long)-1208222456236869772L, (long)l2), Nametags.d("G", (Object)this, (long)-1215037348324776202L, (long)l2), Nametags.d("G", (Object)this, (long)-1215383246085464780L, (long)l2));
    }

    public SliderSetting a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = R ^ l2;
        return Nametags.d("G", (Object)this, (long)-2077314315129037156L, (long)l2);
    }

    public void a(Object[] objectArray) {
        block4: {
            int n2;
            int n3;
            int n4;
            long l2;
            float f2;
            long l3;
            float f3;
            Minecraft minecraft;
            block5: {
                minecraft = (Minecraft)objectArray[0];
                f3 = ((Float)objectArray[1]).floatValue();
                l3 = (Long)objectArray[2];
                f2 = ((Float)objectArray[3]).floatValue();
                long l4 = l3 = R ^ l3;
                l2 = l4 ^ 0x7E1D3925AF5L;
                long l5 = l4 ^ 0x46FE06D942A0L;
                n4 = (int)(l5 >>> 48);
                n3 = (int)(l5 << 16 >>> 32);
                n2 = (int)(l5 << 48 >>> 48);
                CallSite callSite = Nametags.d("N", (long)-8886933768687445470L, (long)l3);
                try {
                    try {
                        if (callSite == null) break block4;
                        if (minecraft.player != null) break block5;
                    }
                    catch (r r2) {
                        throw Nametags.d("N", (Object)r2, (long)-8888711094339848476L, (long)l3);
                    }
                    return;
                }
                catch (r r3) {
                    throw Nametags.d("N", (Object)r3, (long)-8888711094339848476L, (long)l3);
                }
            }
            Nametags.d("N", (short)((short)n4), (int)1, (int)n3, (int)n2, (long)-8887216349369834568L, (long)l3);
            Object[] objectArray2 = new Object[5];
            objectArray2[4] = l2;
            objectArray2[3] = Float.valueOf(f2);
            objectArray2[2] = Float.valueOf(f3);
            objectArray2[1] = minecraft.player;
            objectArray2[0] = minecraft;
            Nametags.d("H", (Object)this, (Object)objectArray2, (long)-8884870209996777786L, (long)l3);
            Nametags.d("N", (short)((short)n4), (int)0, (int)n3, (int)n2, (long)-8887216349369834568L, (long)l3);
        }
    }

    public void b(Object[] objectArray) {
        block21: {
            Minecraft minecraft;
            int[] nArray;
            int n2;
            int n3;
            int n4;
            long l2;
            long l3;
            Minecraft MonsterRoomFeature;
            long l4;
            block25: {
                block26: {
                    block22: {
                        int[] nArray2;
                        block23: {
                            block24: {
                                l4 = (Long)objectArray[0];
                                MonsterRoomFeature = (Minecraft)objectArray[1];
                                long l5 = l4 = R ^ l4;
                                l3 = l5 ^ 0x6232EFC67C63L;
                                l2 = l5 ^ 0x4BF19D3942E1L;
                                long l6 = l5 ^ 0x232D3A8D6436L;
                                n4 = (int)(l6 >>> 48);
                                n3 = (int)(l6 << 16 >>> 32);
                                n2 = (int)(l6 << 48 >>> 48);
                                nArray = aD.b();
                                if (!this.d()) break block22;
                                minecraft = MonsterRoomFeature;
                                nArray2 = nArray;
                                if (l4 < 0L) break block23;
                                if (nArray2 == null) break block24;
                                if (minecraft.level == null) break block22;
                                minecraft = MonsterRoomFeature;
                            }
                            nArray2 = nArray;
                        }
                        if (nArray2 == null) break block25;
                        if (minecraft.player != null) break block26;
                    }
                    return;
                }
                minecraft = MonsterRoomFeature;
            }
            float f2 = minecraft.getDeltaTracker().getGameTimeDeltaPartialTick(true);
            double d2 = (Double)this.y.a() * (Double)this.y.a();
            int n5 = MonsterRoomFeature.getWindow().getGuiScaledWidth();
            int n6 = MonsterRoomFeature.getWindow().getGuiScaledHeight();
            boolean bl = MonsterRoomFeature.options.getCameraType().isFirstPerson();
            kuzi.obf.l.c.c.a((short)n4, 1, n3, n2);
            for (AbstractClientPlayer VecDeltaCodec : MonsterRoomFeature.level.players()) {
                float f3;
                float[] fArray;
                block32: {
                    double d3;
                    block31: {
                        int[] nArray3;
                        block29: {
                            block30: {
                                double d4;
                                LocalPlayer mc7462;
                                AbstractClientPlayer mc7423;
                                block27: {
                                    block28: {
                                        if (l4 <= 0L || nArray == null) break block21;
                                        mc7423 = VecDeltaCodec;
                                        mc7462 = MonsterRoomFeature.player;
                                        if (nArray == null) break block27;
                                        if (mc7423 != mc7462) break block28;
                                        d3 = (double)((Boolean)this.self.a()).booleanValue();
                                        nArray3 = nArray;
                                        if (l4 > 0L) {
                                            if (nArray3 != null) {
                                                if (d3 == false) continue;
                                                d3 = (double)bl;
                                            }
                                            nArray3 = nArray;
                                        }
                                        if (l4 <= 0L) break block29;
                                        if (nArray3 != null) {
                                            if (d3 != false && l4 > 0L) continue;
                                        }
                                        break block30;
                                    }
                                    mc7423 = VecDeltaCodec;
                                    mc7462 = MonsterRoomFeature.player;
                                }
                                d3 = (d4 = mc7423.distanceToSqr((Entity)mc7462) - d2) == 0.0 ? 0 : (d4 > 0.0 ? 1 : -1);
                            }
                            nArray3 = nArray;
                        }
                        if (l4 >= 0L) {
                            if (nArray3 != null) {
                                if (d3 > 0 && l4 >= 0L) continue;
                                d3 = (double)VecDeltaCodec.isInvisible();
                            }
                            nArray3 = nArray;
                        }
                        if (nArray3 == null) break block31;
                        if (d3 == false) break block32;
                        d3 = (double)((Boolean)this.showInvisibles.a()).booleanValue();
                    }
                    if (d3 == false) continue;
                }
                Vec3 VanillaChestLoot = new Vec3(Mth.lerp((double)f2, (double)VecDeltaCodec.xOld, (double)VecDeltaCodec.getX()), Mth.lerp((double)f2, (double)VecDeltaCodec.yOld, (double)VecDeltaCodec.getY()) + (double)VecDeltaCodec.getBbHeight() + 0.55, Mth.lerp((double)f2, (double)VecDeltaCodec.zOld, (double)VecDeltaCodec.getZ()));
                Object[] objectArray2 = new Object[2];
                objectArray2[1] = l2;
                objectArray2[0] = VanillaChestLoot;
                float[] fArray2 = fArray = ac_0.a(objectArray2);
                if (l4 >= 0L && nArray != null) {
                    if (fArray2 == null && l4 >= 0L) continue;
                    fArray2 = fArray;
                }
                float f4 = (f3 = fArray2[0] - -256.0f) == 0.0f ? 0 : (f3 < 0.0f ? -1 : 1);
                int[] nArray4 = nArray;
                if (l4 >= 0L) {
                    if (nArray4 != null) {
                        if (f4 < 0) continue;
                        float f5 = fArray[1] - -256.0f;
                        f4 = f5 == 0.0f ? 0 : (f5 < 0.0f ? -1 : 1);
                    }
                    nArray4 = nArray;
                }
                if (l4 > 0L) {
                    if (nArray4 != null) {
                        if (f4 < 0) continue;
                        float f6 = fArray[0] - ((float)n5 + 256.0f);
                        f4 = f6 == 0.0f ? 0 : (f6 > 0.0f ? 1 : -1);
                    }
                    nArray4 = nArray;
                }
                if (nArray4 != null) {
                    if (f4 > 0) continue;
                    float f7 = fArray[1] - ((float)n6 + 256.0f);
                    f4 = f7 == 0.0f ? 0 : (f7 > 0.0f ? 1 : -1);
                }
                if (f4 > 0) continue;
                Object[] objectArray3 = new Object[5];
                objectArray3[4] = l3;
                objectArray3[3] = Float.valueOf(fArray[1]);
                objectArray3[2] = Float.valueOf(fArray[0]);
                objectArray3[1] = VecDeltaCodec;
                objectArray3[0] = MonsterRoomFeature;
                this.c(objectArray3);
                if (l4 >= 0L) {
                    if (nArray != null) continue;
                }
                break block21;
            }
            kuzi.obf.l.c.c.a((short)n4, 0, n3, n2);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private void c(Object[] var1_1) {
        block81: {
            block72: {
                block86: {
                    block85: {
                        block84: {
                            block82: {
                                block83: {
                                    var2_2 = (Minecraft)var1_1[0];
                                    var4_3 = (AbstractClientPlayer)var1_1[1];
                                    var7_4 = ((Float)var1_1[2]).floatValue();
                                    var3_5 = ((Float)var1_1[3]).floatValue();
                                    var5_6 = (Long)var1_1[4];
                                    v0 = var5_6 = Nametags.R ^ var5_6;
                                    var8_7 = v0 ^ 1642217644566L;
                                    var10_8 = v0 ^ 72204567717860L;
                                    v1 = v0 ^ 35693069198859L;
                                    var12_9 = (int)(v1 >>> 48);
                                    var13_10 = (int)(v1 << 16 >>> 48);
                                    var14_11 = (int)(v1 << 32 >>> 32);
                                    var15_12 = v0 ^ 402026377236L;
                                    var17_13 = v0 ^ 135748672512363L;
                                    var19_14 = v0 ^ 94569150904381L;
                                    var21_15 = v0 ^ 94428649366208L;
                                    var23_16 = v0 ^ 125772728009641L;
                                    var25_17 = v0 ^ 70457963769393L;
                                    var27_18 = v0 ^ 45799065497711L;
                                    var29_19 = v0 ^ 128128121632800L;
                                    var31_20 = v0 ^ 70438721542802L;
                                    var33_21 = v0 ^ 7212272299524L;
                                    v2 = v0 ^ 18629778442638L;
                                    var35_22 = (int)(v2 >>> 32);
                                    var36_23 = (int)(v2 << 32 >>> 48);
                                    var37_24 = (int)(v2 << 48 >>> 48);
                                    var38_25 = v0 ^ 62581338933000L;
                                    var40_26 = v0 ^ 44102667854789L;
                                    var43_27 = ((Double)this.scale.a()).floatValue();
                                    var44_28 = kuzi.obf.p.F.a(var4_3.getGameProfile().name());
                                    var42_29 = aD.b();
                                    var45_30 = new ArrayList<aI>();
                                    v3 = ((Boolean)this.distance.a()).booleanValue();
                                    if (var42_29 != null) {
                                        if (v3 != 0) {
                                            var45_30.add(new aI(Math.round(var2_2.player.distanceTo((Entity)var4_3)) + "m", this.N.a().getRGB()));
                                        }
                                        v3 = ((Boolean)this.ping.a()).booleanValue();
                                    }
                                    v4 = var42_29;
                                    if (var5_6 >= 0L) {
                                        if (v4 != null) {
                                            if (v3 != 0) {
                                                v5 = new Object[3];
                                                v5[2] = var25_17;
                                                v5[1] = var4_3;
                                                v5[0] = var2_2;
                                                var45_30.add(new aI(Nametags.a(v5) + (String)Nametags.b("w", (int)24154, (long)(2766958820741711139L ^ var5_6)), this.O.a().getRGB()));
                                            }
                                            v3 = ((Boolean)this.name2.a()).booleanValue();
                                        }
                                        v4 = var42_29;
                                    }
                                    if (var5_6 > 0L) {
                                        if (v4 != null) {
                                            if (v3 != 0) {
                                                v6 = new Object[3];
                                                v6[2] = var44_28;
                                                v6[1] = var17_13;
                                                v6[0] = var4_3;
                                                var45_30.add(new aI(this.c(v6), (var44_28 != false ? this.K : this.J).a().getRGB()));
                                            }
                                            v3 = ((Boolean)this.health.a()).booleanValue();
                                        }
                                        v4 = var42_29;
                                    }
                                    if (var5_6 > 0L) {
                                        if (v4 != null) {
                                            if (v3 != 0) {
                                                var45_30.add(new aI(String.valueOf(Math.round(var4_3.getHealth())), this.L.a().getRGB()));
                                            }
                                            v3 = (int)((Boolean)this.absorption.a()).booleanValue();
                                        }
                                        v4 = var42_29;
                                    }
                                    if (var5_6 <= 0L) break block82;
                                    if (v4 == null) break block83;
                                    if (v3 == 0) break block84;
                                    cfr_temp_0 = var4_3.getAbsorptionAmount() - 0.0f;
                                    v3 = cfr_temp_0 == 0.0f ? 0 : (cfr_temp_0 > 0.0f ? 1 : -1);
                                }
                                v4 = var42_29;
                            }
                            if (v4 != null && v3 > 0) {
                                v3 = (int)var45_30.add(new aI(String.valueOf(Math.round(var4_3.getAbsorptionAmount())), this.M.a().getRGB()));
                            }
                        }
                        var46_31 = new ArrayList<E>();
                        v7 = (Boolean)this.handItems.a();
                        v8 = var42_29;
                        if (var5_6 >= 0L) {
                            if (v8 != null) {
                                if (v7) {
                                    v9 = new Object[3];
                                    v9[2] = var4_3.getItemBySlot(EquipmentSlot.MAINHAND);
                                    v9[1] = var46_31;
                                    v9[0] = var27_18;
                                    Nametags.f(v9);
                                }
                                v7 = (Boolean)this.E.a();
                            }
                            v8 = var42_29;
                        }
                        if (var5_6 > 0L) {
                            if (v8 != null) {
                                if (v7) {
                                    v10 = new Object[3];
                                    v10[2] = var4_3.getItemBySlot(EquipmentSlot.HEAD);
                                    v10[1] = var46_31;
                                    v10[0] = var27_18;
                                    Nametags.f(v10);
                                    v11 = new Object[3];
                                    v11[2] = var4_3.getItemBySlot(EquipmentSlot.CHEST);
                                    v11[1] = var46_31;
                                    v11[0] = var27_18;
                                    Nametags.f(v11);
                                    v12 = new Object[3];
                                    v12[2] = var4_3.getItemBySlot(EquipmentSlot.LEGS);
                                    v12[1] = var46_31;
                                    v12[0] = var27_18;
                                    Nametags.f(v12);
                                    v13 = new Object[3];
                                    v13[2] = var4_3.getItemBySlot(EquipmentSlot.FEET);
                                    v13[1] = var46_31;
                                    v13[0] = var27_18;
                                    Nametags.f(v13);
                                }
                                v7 = (Boolean)this.handItems.a();
                            }
                            v8 = var42_29;
                        }
                        if (var5_6 > 0L) {
                            if (v8 != null) {
                                if (v7) {
                                    v14 = new Object[3];
                                    v14[2] = var4_3.getItemBySlot(EquipmentSlot.OFFHAND);
                                    v14[1] = var46_31;
                                    v14[0] = var27_18;
                                    Nametags.f(v14);
                                }
                                v7 = var45_30.isEmpty();
                            }
                            v8 = var42_29;
                        }
                        if (v8 == null) break block85;
                        if (!v7) break block86;
                        v7 = var46_31.isEmpty();
                    }
                    if (v7) {
                        return;
                    }
                }
                var47_32 = 0.0f;
                var48_33 = new float[var45_30.size()];
                var49_34 = 0;
                block25: while (var49_34 < var45_30.size()) {
                    var48_33[var49_34] = kuzi.obf.l.c.c.a(((aI)var45_30.get((int)var49_34)).b2, 8.5f, var33_21);
                    v15 = var47_32 + var48_33[var49_34];
                    if (var5_6 >= 0L) {
                        var47_32 = v15;
                        ++var49_34;
                        while (var42_29 != null) {
                            if (var42_29 != null) continue block25;
                            if (var5_6 < 0L) continue;
                        }
                    }
                    break block72;
                }
                {
                    var47_32 += 4.0f * (float)Math.max(0, var45_30.size() - 1);
                    break;
                }
                v15 = var47_32 + 10.0f;
            }
            var49_35 = v15;
            var50_36 = (float)var46_31.size() * 12.0f + (float)Math.max(0, var46_31.size() - 1) * 2.0f;
            kuzi.obf.l.c.c.f(var29_19);
            try {
                block80: {
                    block74: {
                        block73: {
                            kuzi.obf.l.c.c.c(var7_4, var38_25, var3_5);
                            kuzi.obf.l.c.c.a(var43_27, var8_7);
                            v16 = var45_30.isEmpty();
                            v17 = var42_29;
                            if (var5_6 <= 0L) ** GOTO lbl195
                            if (v17 != null) {
                                if (v16 == 0) {
                                    var51_37 = -var49_35 / 2.0f;
                                    kuzi.obf.l.c.c.a(var51_37, 0.0f, var49_35, 13.0f, 4.0f, this.I.a().getRGB(), var10_8);
                                    kuzi.obf.l.c.c.a(var51_37, (short)var12_9, 0.0f, var49_35, (char)var13_10, var14_11, 13.0f, 4.0f, 1.0f, (int)Nametags.c("n", (int)27692, (long)(607870617278855201L ^ var5_6)));
                                    var52_38 = var51_37 + 5.0f;
                                    var53_39 = 0;
                                    block27: while (var53_39 < var45_30.size()) {
                                        kuzi.obf.l.c.c.b(((aI)var45_30.get((int)var53_39)).b2, var15_12, var52_38, 6.5f, 8.5f, ((aI)var45_30.get((int)var53_39)).b3 | Nametags.c("n", (int)20832, (long)(7093785321082488139L ^ var5_6)));
                                        var52_38 += var48_33[var53_39] + 4.0f;
                                        try {
                                            ++var53_39;
                                            while (var5_6 > 0L && var42_29 != null) {
                                                if (var42_29 != null) continue block27;
                                                if (var5_6 < 0L) continue;
                                                break block27;
                                            }
                                            break block73;
                                        }
                                        catch (r v18) {
                                            throw Nametags.a(v18);
                                        }
                                    }
                                }
                                v16 = var46_31.isEmpty();
                            }
                            try {
                                v17 = var42_29;
lbl195:
                                // 2 sources

                                if (v17 == null) break block74;
                                if (v16 != 0) break block73;
                            }
                            catch (r v19) {
                                throw Nametags.a(v19);
                            }
                            var51_37 = -var50_36 / 2.0f;
                            try {
                                v20 = var45_30.isEmpty() != false ? 0.0f : -15.0f;
                            }
                            catch (r v21) {
                                throw Nametags.a(v21);
                            }
                            var52_38 = v20;
                            for (ItemStack var54_41 : var46_31) {
                                block90: {
                                    block79: {
                                        block77: {
                                            block78: {
                                                block75: {
                                                    block76: {
                                                        block87: {
                                                            var55_42 = kuzi.obf.l.c.b.a(var40_26, var54_41);
                                                            v16 = var55_42;
                                                            v22 = var42_29;
                                                            if (var5_6 <= 0L) ** GOTO lbl215
                                                            if (v22 == null) break block74;
                                                            v22 = var42_29;
lbl215:
                                                            // 2 sources

                                                            if (var5_6 <= 0L) ** GOTO lbl236
                                                            if (v22 == null) break block75;
                                                            break block87;
                                                            catch (r v23) {
                                                                throw Nametags.a(v23);
                                                            }
                                                        }
                                                        try {
                                                            block88: {
                                                                if (v16 <= 0) break block76;
                                                                break block88;
                                                                catch (r v24) {
                                                                    throw Nametags.a(v24);
                                                                }
                                                            }
                                                            kuzi.obf.l.c.c.a(var31_20, var55_42, var51_37, var52_38, 12.0f, 12.0f, 0.0f, 1.0f);
                                                        }
                                                        catch (r v25) {
                                                            throw Nametags.a(v25);
                                                        }
                                                    }
                                                    v26 = var54_41.getCount();
                                                }
                                                v22 = var42_29;
lbl236:
                                                // 2 sources

                                                if (v22 == null) break block77;
                                                try {
                                                    block89: {
                                                        if (v26 <= true) break block78;
                                                        break block89;
                                                        catch (r v27) {
                                                            throw Nametags.a(v27);
                                                        }
                                                    }
                                                    kuzi.obf.l.c.c.c(String.valueOf(var54_41.getCount()), var51_37 + 12.0f, var52_38 + 12.0f - 2.0f, var21_15, 6.5f, -1);
                                                }
                                                catch (r v28) {
                                                    throw Nametags.a(v28);
                                                }
                                            }
                                            try {
                                                v29 = this;
                                                if (var5_6 >= 0L) {
                                                    if (var42_29 == null) break block79;
                                                    v29 = v29.G.a();
                                                }
                                                v26 = (int)((Boolean)v29).booleanValue();
                                            }
                                            catch (r v30) {
                                                throw Nametags.a(v30);
                                            }
                                        }
                                        if (v26 == false) break block90;
                                        v31 = this;
                                    }
                                    v32 = new Object[4];
                                    v32[3] = var19_14;
                                    v32[2] = Float.valueOf(var52_38 - 2.0f);
                                    v32[1] = Float.valueOf(var51_37 + 6.0f);
                                    v32[0] = var54_41;
                                    v31.d(v32);
                                }
                                var51_37 += 14.0f;
                                if (var42_29 != null) continue;
                            }
                        }
                        try {
                            v33 = this;
                            if (var5_6 < 0L || var42_29 == null) break block80;
                            v16 = ((Boolean)v33.H.a()).booleanValue();
                        }
                        catch (r v34) {
                            throw Nametags.a(v34);
                        }
                    }
                    if (v16 == 0) break block81;
                    v33 = this;
                }
                try {
                    v35 = var4_3;
                    v36 = var46_31.isEmpty() != false ? -15.0f : -32.0f;
                }
                catch (r v37) {
                    throw Nametags.a(v37);
                }
                v38 = new Object[3];
                v38[2] = var23_16;
                v38[1] = Float.valueOf(v36);
                v38[0] = v35;
                v33.e(v38);
            }
            finally {
                kuzi.obf.l.c.c.g(var35_22, (short)var36_23, (short)var37_24);
            }
        }
    }

    private void d(Object[] objectArray) {
        ItemStack itemStack = (ItemStack)objectArray[0];
        float x = ((Float)objectArray[1]).floatValue();
        float startY = ((Float)objectArray[2]).floatValue();
        long l2 = (Long)objectArray[3];
        long l3 = (l2 = R ^ l2) ^ 0x62AFBF17010AL;
        ItemEnchantments enchantments = EnchantmentHelper.getEnchantmentsForCrafting((ItemStack)itemStack);
        int[] nArray = aD.b();
        if (enchantments.isEmpty()) {
            return;
        }
        float y = startY;
        for (Holder enchantment : enchantments.keySet()) {
            String fullName;
            int level = enchantments.getLevel(enchantment);
            String shortName = fullName = Enchantment.getFullname((Holder)enchantment, (int)level).getString();
            if (nArray != null) {
                shortName = shortName.length() >= 2 ? fullName.substring(0, 2) : fullName;
            }
            String enchantLabel = shortName + level;
            kuzi.obf.l.c.c.d(enchantLabel, x, y, 6.5f, (int)Nametags.c("n", (int)1082, (long)(0x4A553E829B265355L ^ l2)), l3);
            y -= 7.5f;
            if (nArray != null) continue;
        }
    }

    private void e(Object[] objectArray) {
        Player player = (Player)objectArray[0];
        float y = ((Float)objectArray[1]).floatValue();
        long l2 = (Long)objectArray[2];
        long l3 = l2 = R ^ l2;
        long l4 = l3 ^ 0x431D652BDC30L;
        long l5 = l3 ^ 0x46CE9974FA9EL;
        long l6 = l3 ^ 0xEB08688A268L;
        long l7 = l3 ^ 0x3552B7AA1632L;
        Collection effects = player.getActiveEffects();
        int[] nArray = aD.b();
        int effectCount = effects.isEmpty();
        if (nArray != null) {
            if (effectCount != 0) {
                return;
            }
            effectCount = effects.size();
        }
        float totalWidth = (float)effectCount * 12.0f + (float)Math.max(0, effects.size() - 1) * 2.0f;
        float x = -totalWidth / 2.0f;
        for (MobEffectInstance effect : effects) {
            block11: {
                int spriteIndex;
                block10: {
                    int resolvedSprite;
                    Identifier spriteId;
                    Identifier resolvedId = spriteId = Gui.getMobEffectSprite((Holder)effect.getEffect());
                    if (nArray != null) {
                        if (resolvedId == null && l2 >= 0L) continue;
                        resolvedId = spriteId;
                    }
                    spriteIndex = resolvedSprite = kuzi.obf.l.c.b.a(l4, resolvedId.getNamespace(), (String)((Object)Nametags.b("w", (int)29600, (long)(0x164359223D835035L ^ l2))) + spriteId.getPath() + (String)((Object)Nametags.b("w", (int)23648, (long)(0x141DFA1E31F37FFEL ^ l2))), false);
                    if (nArray == null) break block10;
                    if (spriteIndex <= 0) break block11;
                    spriteIndex = resolvedSprite;
                }
                float alpha = 1.0f;
                float vOffset = 0.0f;
                float height = 12.0f;
                float width = 12.0f;
                float drawY = y;
                float drawX = x;
                int sprite = spriteIndex;
                kuzi.obf.l.c.c.a(l6, sprite, drawX, drawY, width, height, vOffset, alpha);
            }
            Object[] objectArray2 = new Object[2];
            objectArray2[1] = effect;
            objectArray2[0] = l7;
            String durationText = Nametags.a(objectArray2);
            int[] nArray2 = nArray;
            if (l2 > 0L) {
                if (nArray2 != null) {
                    if (!durationText.isEmpty()) {
                        kuzi.obf.l.c.c.d(durationText, x + 6.0f, y - 2.0f, 6.5f, (int)Nametags.c("n", (int)15557, (long)(0x345A9E5D40DB9033L ^ l2)), l5);
                    }
                    x += 14.0f;
                }
                nArray2 = nArray;
            }
            if (nArray2 != null) continue;
        }
    }

    private static String a(Object[] objectArray) {
        int totalSeconds;
        long l2;
        block4: {
            MobEffectInstance effect;
            block5: {
                l2 = (Long)objectArray[0];
                effect = (MobEffectInstance)objectArray[1];
                l2 = R ^ l2;
                CallSite callSite = Nametags.d("N", (long)-5722323874163511777L, (long)l2);
                try {
                    try {
                        totalSeconds = effect.isInfiniteDuration();
                        if (callSite == null) break block4;
                        if (totalSeconds == 0) break block5;
                    }
                    catch (r r2) {
                        throw Nametags.d("N", (Object)r2, (long)-5721392004239883559L, (long)l2);
                    }
                    return Nametags.b("w", (int)5610, (long)(0x1040F0D778F45B07L ^ l2));
                }
                catch (r r3) {
                    throw Nametags.d("N", (Object)r3, (long)-5721392004239883559L, (long)l2);
                }
            }
            totalSeconds = effect.getDuration() / Nametags.c("n", (int)25414, (long)(0x278BDFC42F90A2DDL ^ l2));
        }
        int seconds = totalSeconds;
        return seconds / Nametags.c("n", (int)1461, (long)(0x55AD33A1615E442CL ^ l2)) + ":" + String.format((String)((Object)Nametags.b("w", (int)28716, (long)(0xF5C17BAAD3EBEC0L ^ l2))), seconds % Nametags.c("n", (int)876, (long)(0x2A2EC0C788B742DAL ^ l2)));
    }

    private static void f(Object[] objectArray) {
        block5: {
            ItemStack checkedItem;
            int[] nArray;
            ItemStack itemStack;
            List items;
            block4: {
                long l2 = (Long)objectArray[0];
                items = (List)objectArray[1];
                itemStack = (ItemStack)objectArray[2];
                l2 = R ^ l2;
                nArray = aD.b();
                checkedItem = itemStack;
                if (nArray == null) break block4;
                if (checkedItem == null) break block5;
                checkedItem = itemStack;
            }
            boolean isEmpty = checkedItem.isEmpty();
            if (nArray != null && !isEmpty) {
                isEmpty = items.add(itemStack);
            }
        }
    }

    private String c(Object[] objectArray) {
        String displayName;
        block2: {
            NameProtect protector;
            AbstractClientPlayer player;
            block6: {
                boolean enabled;
                NameProtect nameProtectModule;
                block5: {
                    NameProtect nameProtectLookup;
                    int[] nArray;
                    block4: {
                        i client;
                        long l2;
                        block3: {
                            player = (AbstractClientPlayer)objectArray[0];
                            l2 = (Long)objectArray[1];
                            boolean applyProtection = (Boolean)objectArray[2];
                            l2 = R ^ l2;
                            nArray = aD.b();
                            String resolvedName = displayName = this.w.a() == kuzi.obf.j.g.y.NICKNAME_ONLY ? player.getGameProfile().name() : player.getDisplayName().getString();
                            if (!applyProtection) break block2;
                            client = Client.a();
                            if (nArray == null) break block3;
                            if (client == null) break block2;
                            client = Client.a();
                        }
                        nameProtectLookup = nameProtectModule = (NameProtect)client.a(NameProtect.class);
                        if (l2 < 0L || nArray == null) break block4;
                        if (nameProtectLookup == null) break block2;
                        nameProtectLookup = nameProtectModule;
                    }
                    enabled = nameProtectLookup.d();
                    if (nArray == null) break block5;
                    if (!enabled) break block2;
                    protector = nameProtectModule;
                    if (nArray == null) break block6;
                    enabled = protector.a();
                }
                if (!enabled) break block2;
                protector = nameProtectModule;
            }
            return protector.a(player.getGameProfile().name());
        }
        return displayName;
    }

    private static int a(Object[] objectArray) {
        PlayerInfo playerInfo;
        Minecraft minecraft = (Minecraft)objectArray[0];
        AbstractClientPlayer player = (AbstractClientPlayer)objectArray[1];
        long l2 = (Long)objectArray[2];
        l2 = R ^ l2;
        int[] nArray = aD.b();
        ClientPacketListener connection = minecraft.getConnection();
        if (nArray != null) {
            if (connection == null) {
                return 0;
            }
            connection = minecraft.getConnection();
        }
        return (playerInfo = connection.getPlayerInfo(player.getUUID())) == null ? 0 : Math.max(0, playerInfo.getLatency());
    }

    private static void lambda$new$0(long l2) {
        long l3 = (l2 = R ^ l2) ^ 0x56AA91D283FDL;
        Object[] objectArray = new Object[2];
        objectArray[1] = d_0.NAMETAG;
        objectArray[0] = l3;
        kuzi.obf.h.r.a(objectArray);
    }

    /*
     * Unable to fully structure code
     */
    static {
        block21: {
            block20: {
                block19: {
                    block18: {
                        Nametags.R = kuzi.obf.h.b.v.a(-5855039382504586932L, -6953033912546376318L, MethodHandles.lookup().lookupClass()).a(153787310646777L);
                        Nametags.Y = new Object[104];
                        Nametags.Z = new String[104];
                        Nametags.c();
                        Nametags.U = new HashMap<K, V>(13);
                        var11 = Nametags.R ^ 126407842335269L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[29];
                        var18_4 = 0;
                        var17_5 = "\u008dr\u00de\u00b4\u00d5%\u009aO{\u00e2#Z\u00f9k\u0013\u00f3\u00d3\u0016\u00a9@\u0016{\u00b5y\u0018^>a\u0097*,2\u009d=\f\u0000\u0080\u00cc\u00e4\u00adDU\u0085Q`\u00b5\u00bd\u0011\u0088\u0010\u00da\u00f8\u0083/c\u00da\u009a\u0082~\u008e\u008c\u0015\u00d7\u008b\u007fa\u0018\u00a6\"H\u008f@\u0000)\u00c6\u008f\u00d5\u00ce\u008f\u00c3\u0094\u00cb\u00b7&*\u00b8\u00e4\u00e1\u008f\u008b\u00a3\u0010b{\u00e2\u00f7\u0091\u000b\u00daF\u00d0Uu\u0097\u0095\u00ea\u00ce\u00fa \u0010\u00f7\u0091o\u00f0_p,\u001e\u00b2~>\u008f=i+\u00fe\u00b6\u00ee\u0005Z\u0004\u00940\u001f\u001b=M\u000bP\u009b\"\u0018P\u00af$\u00c9<'M\u00ee\u00bcp\u008e=\u00fd\u00ce\u0099\u00fd\u00da\u00d3\u009co8O\n\u001c\u0010gt\u00c7W\\\u0097@\u00ed\u009a\u00f8\u009d\u0097\u0086\u00c9\u00c1R\u0018\u00cb.\u0010;\u00eb\u00baD\u000b)A_\u0098[\u00b4S\u008c\u00a9\u00c4\\\u00b4\u00e0:\u0003\u00e0(2\u00a2i+\u00b4\u0017\u00fa-\u00b0Dd\u00cd*\u00e1|d\u00c7\u00e8\u0082\u00a4\u00c5c\u0012\u0086x\u00d5}\u00ea\u0011\u00d3\u009f\u0019\u00a7O_\u00a9\u00a3\u00f4\u00912\u0010\u0018i$\u00d4\u00dc\u009bx\u00d7\u00c4\u00df\u0017#\u00d0\u00e8\u008dZ\u0018>\u00a8\u0017\u00ee\u0016\u00c9\u00a0\u00b9Aa\u00b2\u00be\u00a2\u00baM\u00d9C\u00b4\u0092I\u00e6\u001a\u00e4\u00c4\u0010H>\u00b3b\u0004#\u0007\u00b6\u00b4\u0085O\u00ce\u00f3D\u00edp\u0018\u001d(Q8\u00d0\f\u0098\r_\u00e4\u00a1\u0089\u0097\u00ff\u00ee\u00c0\u0014j\u00ff\u00df\u000eb\u00d0\u00ce\u0018\u00074\u00aal\u0017\u00e45\u00e2\u00b2\u00b2XEr\u00cf\u008b\u00ae1\u00c4y\u0093\u00e9\u0012\u00f6\u00a5\u0010Wy\u007f\u0018\u0081\u0018}\u00b1U\u0084\u00f7_\u00b2\u00d9M\u00f7\u0010s\u008b\f:\u00bb\u00f3\u00d3k\u00ce5\u00bb\u00c9\u0083\u0087b\u009d(\u00da(\u00d4\u0096\u0093\u00ebq\u00cdBx\u0019(3\u001d\u00c1r^\u00ff\u0092\u00e9X\u00be\u0017l1<\n\u00b8,\u00fc\u00f1C\u00c2\u00f7|\u00e0\u00b0\u0098\u008f}\u0018\u009d`\u00b3\u009f_[X\u00e0ws\u008dD\u0012T4\u00a0\u0095\u0004C\u0081\u00a2s\u00d8\u00a7\u0010\f\u00d3\u00aeM\u00f7\u00a0^h\u00b2\u00da\u00d6\u0005k\u00d5\u000f\u0015\u00186\u0019U\u00df\u00ed\u0098\u0081C\u00ee\u0015\u00e1\u00a7\u000b\u00e6\u00e2\u00a0\u00e4\u0095\u00f1u{\u00e5\u0086x\u0018\u0015\u00f8<\u00f3e\u00c8\u008e\u0006\u007f%Z]\u00b7\u00cc\u00b7\u0099 \u00b0\u0089\u0007a\u00af.\u0015 \u00a7\u00c6\u0002I\u009f \u00f5\u00df\u00b37\u001dv\u00ba\u0080\u0087\u00d5m~\u00ea\u00af\u00d0\u009e\u00f8[\rMT\u00e5Z\u0012 \u00b8\u0010\u00f3C\n\u001cl\\\u00fd\u00a7\u001b\u009e\u00ec\u0090\u0089\u0002\u00a0F\u0010\u00cfS\u00a5y=Ib-\u00e2w\u0082R\u00aa\u0015\u0012\u00c9\u0010\u008f*M\u0002\u00c01i\u008f[\u00f8Nu$[\u0019\u00b7 v \u0080\u00b8\u00faZX\u00a2v\u0019z?\u00e6\u00ae\u0096\u00d8\u0002\u00a6w-c\u009d_\u00c9y\u00a7b\u00d3\u00d0\u0098nN";
                        var19_6 = "\u008dr\u00de\u00b4\u00d5%\u009aO{\u00e2#Z\u00f9k\u0013\u00f3\u00d3\u0016\u00a9@\u0016{\u00b5y\u0018^>a\u0097*,2\u009d=\f\u0000\u0080\u00cc\u00e4\u00adDU\u0085Q`\u00b5\u00bd\u0011\u0088\u0010\u00da\u00f8\u0083/c\u00da\u009a\u0082~\u008e\u008c\u0015\u00d7\u008b\u007fa\u0018\u00a6\"H\u008f@\u0000)\u00c6\u008f\u00d5\u00ce\u008f\u00c3\u0094\u00cb\u00b7&*\u00b8\u00e4\u00e1\u008f\u008b\u00a3\u0010b{\u00e2\u00f7\u0091\u000b\u00daF\u00d0Uu\u0097\u0095\u00ea\u00ce\u00fa \u0010\u00f7\u0091o\u00f0_p,\u001e\u00b2~>\u008f=i+\u00fe\u00b6\u00ee\u0005Z\u0004\u00940\u001f\u001b=M\u000bP\u009b\"\u0018P\u00af$\u00c9<'M\u00ee\u00bcp\u008e=\u00fd\u00ce\u0099\u00fd\u00da\u00d3\u009co8O\n\u001c\u0010gt\u00c7W\\\u0097@\u00ed\u009a\u00f8\u009d\u0097\u0086\u00c9\u00c1R\u0018\u00cb.\u0010;\u00eb\u00baD\u000b)A_\u0098[\u00b4S\u008c\u00a9\u00c4\\\u00b4\u00e0:\u0003\u00e0(2\u00a2i+\u00b4\u0017\u00fa-\u00b0Dd\u00cd*\u00e1|d\u00c7\u00e8\u0082\u00a4\u00c5c\u0012\u0086x\u00d5}\u00ea\u0011\u00d3\u009f\u0019\u00a7O_\u00a9\u00a3\u00f4\u00912\u0010\u0018i$\u00d4\u00dc\u009bx\u00d7\u00c4\u00df\u0017#\u00d0\u00e8\u008dZ\u0018>\u00a8\u0017\u00ee\u0016\u00c9\u00a0\u00b9Aa\u00b2\u00be\u00a2\u00baM\u00d9C\u00b4\u0092I\u00e6\u001a\u00e4\u00c4\u0010H>\u00b3b\u0004#\u0007\u00b6\u00b4\u0085O\u00ce\u00f3D\u00edp\u0018\u001d(Q8\u00d0\f\u0098\r_\u00e4\u00a1\u0089\u0097\u00ff\u00ee\u00c0\u0014j\u00ff\u00df\u000eb\u00d0\u00ce\u0018\u00074\u00aal\u0017\u00e45\u00e2\u00b2\u00b2XEr\u00cf\u008b\u00ae1\u00c4y\u0093\u00e9\u0012\u00f6\u00a5\u0010Wy\u007f\u0018\u0081\u0018}\u00b1U\u0084\u00f7_\u00b2\u00d9M\u00f7\u0010s\u008b\f:\u00bb\u00f3\u00d3k\u00ce5\u00bb\u00c9\u0083\u0087b\u009d(\u00da(\u00d4\u0096\u0093\u00ebq\u00cdBx\u0019(3\u001d\u00c1r^\u00ff\u0092\u00e9X\u00be\u0017l1<\n\u00b8,\u00fc\u00f1C\u00c2\u00f7|\u00e0\u00b0\u0098\u008f}\u0018\u009d`\u00b3\u009f_[X\u00e0ws\u008dD\u0012T4\u00a0\u0095\u0004C\u0081\u00a2s\u00d8\u00a7\u0010\f\u00d3\u00aeM\u00f7\u00a0^h\u00b2\u00da\u00d6\u0005k\u00d5\u000f\u0015\u00186\u0019U\u00df\u00ed\u0098\u0081C\u00ee\u0015\u00e1\u00a7\u000b\u00e6\u00e2\u00a0\u00e4\u0095\u00f1u{\u00e5\u0086x\u0018\u0015\u00f8<\u00f3e\u00c8\u008e\u0006\u007f%Z]\u00b7\u00cc\u00b7\u0099 \u00b0\u0089\u0007a\u00af.\u0015 \u00a7\u00c6\u0002I\u009f \u00f5\u00df\u00b37\u001dv\u00ba\u0080\u0087\u00d5m~\u00ea\u00af\u00d0\u009e\u00f8[\rMT\u00e5Z\u0012 \u00b8\u0010\u00f3C\n\u001cl\\\u00fd\u00a7\u001b\u009e\u00ec\u0090\u0089\u0002\u00a0F\u0010\u00cfS\u00a5y=Ib-\u00e2w\u0082R\u00aa\u0015\u0012\u00c9\u0010\u008f*M\u0002\u00c01i\u008f[\u00f8Nu$[\u0019\u00b7 v \u0080\u00b8\u00faZX\u00a2v\u0019z?\u00e6\u00ae\u0096\u00d8\u0002\u00a6w-c\u009d_\u00c9y\u00a7b\u00d3\u00d0\u0098nN".length();
                        var16_7 = 24;
                        var15_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block18;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = Nametags.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "\u00ec\u008b\u0017b\u000e\u00bb}\u00df<%e\u00eeX\u00f5\u00bc9h\u00d9\u00d6B9#.J^g\u00d2\u0086\u0000\u00e5\u0013*\rF\u0093j=B\u009d\u0011\u0015\u00f0-\u0089\u00f5r\u008e\u00bd\u0085&\u00b1\u00b8O\u0013?Z\u009aM\u00dc\f(\u00b4)et\u00f0\u0017\b\u00f6\u00c7\n\u000f\u0013\b\u00d5\n\u00f2\b\u00d0=\u0096\u00f3\u00c3\u00fb\u00d0!\f[K\u00c3\u00a2#Mp\u00cd\u00c7B\u00a8\u00a7\u00bf\u00e1\u00a1\u0082|\u00c9\u009b_@gW}6\u00a5\u00fd\u00acT0\u00e1\u00a5\u00e6\u008e";
                            var19_6 = "\u00ec\u008b\u0017b\u000e\u00bb}\u00df<%e\u00eeX\u00f5\u00bc9h\u00d9\u00d6B9#.J^g\u00d2\u0086\u0000\u00e5\u0013*\rF\u0093j=B\u009d\u0011\u0015\u00f0-\u0089\u00f5r\u008e\u00bd\u0085&\u00b1\u00b8O\u0013?Z\u009aM\u00dc\f(\u00b4)et\u00f0\u0017\b\u00f6\u00c7\n\u000f\u0013\b\u00d5\n\u00f2\b\u00d0=\u0096\u00f3\u00c3\u00fb\u00d0!\f[K\u00c3\u00a2#Mp\u00cd\u00c7B\u00a8\u00a7\u00bf\u00e1\u00a1\u0082|\u00c9\u009b_@gW}6\u00a5\u00fd\u00acT0\u00e1\u00a5\u00e6\u008e".length();
                            var16_7 = 16;
                            var15_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block18;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = Nametags.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block19;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                Nametags.S = var20_3;
                Nametags.T = new String[29];
                Nametags.X = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[39];
                var3_13 = 0;
                var4_14 = "7\u001ec\u0082\u0099!3\u00b9\u009f\u00d5\u00cf\t,]\u00ad\u008f\u009a\u00ba\u0082\u0001b\u00b2j\u0003,\u00d5\u00e33b\"\u00d2\u00ad\u00db;m\u00deV\u00dc\u00981\u00c3I\u00b13\u00fa4r{\u0093\u00c5[\u00cf\u00ce\u0087\u00a9G\u008aT\u0010\u00c5\u00ab\u00d5\u0090\u009fw\u0000n\u00b5\u0093\u00c3X\u00b9\u00de\u00b2\u00f8\u0010GG\u00d2\u00c6C\u0096\u00c5\u00ec@4\u000e\u00f0J-\u00aa\u0089\u00e0l?m\u00137R\u001a\u00ca'\u000b\u00a6\u0096\u00be\u0084q\u00a2\u00e6\u00a3\u00f1\u00d3h\u00ce^\u0002\u00efI\u000f.\u00d9\u000b\u00ccz\u00bb\u00bbae}\u00f3\u00a3\u0092j\u00a8\u009fy\u009bX\u0091 \u00a5\u00d1\u0092\u008a/e\u0085y\u00ca\u00e8\u00ac\u00abU\u0013\u00aa\u001a-G\u0001\u00e9\u0084l\u009a\u00e7-\u00d0\u001e\u00a5\u00cfIV\u00d3\u009f(vK,\u00b9j\u00f7\u00ff$\u001cK\u0098\u00ae\u00b5\u00a8\t8C\t\u00955\u00ba\u0090kS\u009f\u00f1U2\u00ab\u00e6[x\u001bu\u0007\u00df\u00880\u00c3\u00cf\u0006\u0003\u00de8h\u0006\u00fc\u0007\u0091Gn\u00ed(Sc\u00e6\u00cdO\u00bfAcH\u0000Pg\u00c4\u00b9A\u0086\u0012\u0081\u001exy\u009c\u0097P\u00ec\u0098\u00e8\u0091\u009d\u00f0\u00c6\u0006H\u00c6|\\\u0094\u0092\u00e7\u0091\u0002%\u00a8\u00c4\u00eb\u009bCo\u00aa\u008a\u009e\u008c3\u0018\u008dV@L152\u00d2\u001c9Q\u0094\u00e8\u0007";
                var5_15 = "7\u001ec\u0082\u0099!3\u00b9\u009f\u00d5\u00cf\t,]\u00ad\u008f\u009a\u00ba\u0082\u0001b\u00b2j\u0003,\u00d5\u00e33b\"\u00d2\u00ad\u00db;m\u00deV\u00dc\u00981\u00c3I\u00b13\u00fa4r{\u0093\u00c5[\u00cf\u00ce\u0087\u00a9G\u008aT\u0010\u00c5\u00ab\u00d5\u0090\u009fw\u0000n\u00b5\u0093\u00c3X\u00b9\u00de\u00b2\u00f8\u0010GG\u00d2\u00c6C\u0096\u00c5\u00ec@4\u000e\u00f0J-\u00aa\u0089\u00e0l?m\u00137R\u001a\u00ca'\u000b\u00a6\u0096\u00be\u0084q\u00a2\u00e6\u00a3\u00f1\u00d3h\u00ce^\u0002\u00efI\u000f.\u00d9\u000b\u00ccz\u00bb\u00bbae}\u00f3\u00a3\u0092j\u00a8\u009fy\u009bX\u0091 \u00a5\u00d1\u0092\u008a/e\u0085y\u00ca\u00e8\u00ac\u00abU\u0013\u00aa\u001a-G\u0001\u00e9\u0084l\u009a\u00e7-\u00d0\u001e\u00a5\u00cfIV\u00d3\u009f(vK,\u00b9j\u00f7\u00ff$\u001cK\u0098\u00ae\u00b5\u00a8\t8C\t\u00955\u00ba\u0090kS\u009f\u00f1U2\u00ab\u00e6[x\u001bu\u0007\u00df\u00880\u00c3\u00cf\u0006\u0003\u00de8h\u0006\u00fc\u0007\u0091Gn\u00ed(Sc\u00e6\u00cdO\u00bfAcH\u0000Pg\u00c4\u00b9A\u0086\u0012\u0081\u001exy\u009c\u0097P\u00ec\u0098\u00e8\u0091\u009d\u00f0\u00c6\u0006H\u00c6|\\\u0094\u0092\u00e7\u0091\u0002%\u00a8\u00c4\u00eb\u009bCo\u00aa\u008a\u009e\u008c3\u0018\u008dV@L152\u00d2\u001c9Q\u0094\u00e8\u0007".length();
                var2_16 = 0;
                while (true) {
                    var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                    v10 = var6_12;
                    v11 = var3_13++;
                    v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                    v13 = -1;
                    break block20;
                    break;
                }
lbl81:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    var4_14 = "\u0086x\u00b2\u00ca\bM..8\u00a6\u00fb\u0001O\u00a6v\u00a0";
                    var5_15 = "\u0086x\u00b2\u00ca\bM..8\u00a6\u00fb\u0001O\u00a6v\u00a0".length();
                    var2_16 = 0;
                    while (true) {
                        var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                        v10 = var6_12;
                        v11 = var3_13++;
                        v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                        v13 = 0;
                        break block20;
                        break;
                    }
                    break;
                }
lbl94:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    break block21;
                    break;
                }
            }
            var8_18 = v12;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            v14 = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
            switch (v13) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl107:
                // 1 sources

                ** continue;
            }
        }
        Nametags.V = var6_12;
        Nametags.W = new Integer[39];
        Nametags.t = 0x1AFFFFFF;
    }

    private static r a(r value) {
        return value;
    }

    private static String b(byte[] byArray) {
        int outIndex = 0;
        int inputLength = byArray.length;
        char[] cArray = new char[inputLength];
        for (int index = 0; index < inputLength; ++index) {
            char ch;
            int byteValue = 0xFF & byArray[index];
            if (byteValue < 192) {
                cArray[outIndex++] = (char)byteValue;
                continue;
            }
            if (byteValue < 224) {
                ch = (char)((char)(byteValue & 0x1F) << 6);
                byteValue = byArray[++index];
                ch = (char)(ch | (char)(byteValue & 0x3F));
                cArray[outIndex++] = ch;
                continue;
            }
            if (index >= inputLength - 2) continue;
            ch = (char)((char)(byteValue & 0xF) << 12);
            byteValue = byArray[++index];
            ch = (char)(ch | (char)(byteValue & 0x3F) << 6);
            byteValue = byArray[++index];
            ch = (char)(ch | (char)(byteValue & 0x3F));
            cArray[outIndex++] = ch;
        }
        return new String(cArray, 0, outIndex);
    }

    private static String b(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x7E74;
        if (T[n3] == null) {
            Object[] objectArray;
            try {
                Long l3 = Thread.currentThread().threadId();
                objectArray = (Object[])U.get(l3);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    U.put(l3, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/g/ac", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l2 >>> 56);
            for (int byteIndex = 1; byteIndex < 8; ++byteIndex) {
                byArray[byteIndex] = (byte)(l2 << byteIndex * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = S[n3].getBytes("ISO-8859-1");
            Nametags.T[n3] = Nametags.b(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return T[n3];
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        String string2 = Nametags.b(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static CallSite b(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/ac" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x7114;
        if (W[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = V[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])X.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    X.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/g/ac", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Nametags.W[n3] = n4;
        }
        return W[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = Nametags.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/ac" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (Z[n4] != null) {
            return n4;
        }
        Object object = Y[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 1;
            case 1 -> 7;
            case 2 -> 16;
            case 3 -> 61;
            case 4 -> 25;
            case 5 -> 56;
            case 6 -> 31;
            case 7 -> 41;
            case 8 -> 40;
            case 9 -> 0;
            case 10 -> 59;
            case 11 -> 62;
            case 12 -> 37;
            case 13 -> 48;
            case 14 -> 20;
            case 15 -> 21;
            case 16 -> 14;
            case 17 -> 43;
            case 18 -> 60;
            case 19 -> 3;
            case 20 -> 33;
            case 21 -> 29;
            case 22 -> 58;
            case 23 -> 32;
            case 24 -> 19;
            case 25 -> 4;
            case 26 -> 17;
            case 27 -> 38;
            case 28 -> 6;
            case 29 -> 24;
            case 30 -> 47;
            case 31 -> 50;
            case 32 -> 39;
            case 33 -> 15;
            case 34 -> 18;
            case 35 -> 35;
            case 36 -> 5;
            case 37 -> 28;
            case 38 -> 12;
            case 39 -> 52;
            case 40 -> 13;
            case 41 -> 34;
            case 42 -> 57;
            case 43 -> 46;
            case 44 -> 23;
            case 45 -> 49;
            case 46 -> 27;
            case 47 -> 22;
            case 48 -> 45;
            case 49 -> 2;
            case 50 -> 11;
            case 51 -> 36;
            case 52 -> 54;
            case 53 -> 10;
            case 54 -> 30;
            case 55 -> 9;
            case 56 -> 8;
            case 57 -> 42;
            case 58 -> 55;
            case 59 -> 63;
            case 60 -> 44;
            case 61 -> 26;
            case 62 -> 51;
            default -> 53;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        Nametags.Z[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = Y;
        Y[0] = "xw6\u0018\u0013=sw0\u0018\u0013p";
        objectArray[1] = "j[\u0004p^\u001ac[\u0007pR";
        objectArray[2] = "1kY\u0004!\u007f8kJ";
        objectArray[3] = "]\u000f\u001f\u001e%k(/\u0014\u00114$I!\u001f\u001a0~=";
        objectArray[4] = Void.TYPE;
        Nametags.Z[4] = "java/lang/Void";
        objectArray[5] = "?\u0004kW\u0018\u00136\u0004n";
        objectArray[6] = "\u001d'h\u0015P\t\u0014'k\u0015R";
        objectArray[7] = "|\u0013+\u001cU'u\u0013(\u001cQ";
        objectArray[8] = "\u001epGAL4\u0017pDAA";
        objectArray[9] = "s{U\u001c\u00112x{S\u001c\t";
        objectArray[10] = "A8,9x(H8/9}";
        objectArray[11] = "\bY8Uv\"\u0003Y0";
        objectArray[12] = "y\u0004fE&\fr\u0004m";
        objectArray[13] = "Qhl\n\n($Hg\u0005\u001bgEFl\u000e\u001f=1";
        objectArray[14] = "UL\u0016u_,XL\u0014u]";
        objectArray[15] = Long.TYPE;
        Nametags.Z[15] = "java/lang/Long";
        objectArray[16] = Integer.TYPE;
        Nametags.Z[16] = "java/lang/Integer";
        objectArray[17] = Float.TYPE;
        Nametags.Z[17] = "java/lang/Float";
        objectArray[18] = "L\f-\u001d&EG\u0003<R[]T\u00045\u001b";
        objectArray[19] = "S\fN/8sX\fH/8\u0019";
        objectArray[20] = "\u000e\u001f";
        objectArray[21] = ">\rgA\rcK-lN\u001c,*#gE\u0018v^";
        objectArray[22] = "1xz7@\u0012=xi";
        objectArray[23] = "e2`3V\u0017h2b3U";
        objectArray[24] = Boolean.TYPE;
        Nametags.Z[24] = "java/lang/Boolean";
        objectArray[25] = Short.TYPE;
        Nametags.Z[25] = "java/lang/Short";
        objectArray[26] = "\u0018k>91SmK56 \u001c\fE>=$Fx";
        objectArray[27] = "hTA\u00002\u0000\u001dtJ\u000f#O|zA\u0004'\u0015\b";
        objectArray[28] = "vW1($,\u0003w:'5cby1,19\u0016";
        objectArray[29] = "x^HZ$.\r~CU5alpH^1;\u0018";
        objectArray[30] = "\u0007_]b?\u0002r\u007fVm.M\u0013q]f*\u0017g";
        objectArray[31] = "\u001f\u000fpu\u0006^\u0014\u000fvu\u00069";
        objectArray[32] = "()=4Ey!)>4E";
        objectArray[33] = "@\nz\u0007`jK\u0005kH\u0001d@\u000eo\u0012";
        objectArray[34] = Character.TYPE;
        Nametags.Z[34] = "java/lang/Character";
        objectArray[35] = "D\u0014C\u0010\u001a\u001eY\u0001\u001b2[\u0013A\u0007";
        objectArray[36] = "?/\u001bU;X./<";
        objectArray[37] = "q+(s\u001bqq+?/\u0017~k`?1\u0017kl\u0011mjO!";
        objectArray[38] = ".71}'J%75}\u0010";
        objectArray[39] = "\u0004R\u0006{nrqr\rt\u007f=\u0010|\u0006\u007f{gd";
        objectArray[40] = "u ,Sc\u0000d ,\u001e";
        objectArray[41] = "2(f&\rpG\bm)\u001c?&\u0006f\"\u0018eR";
        objectArray[42] = "i\u0001";
        objectArray[43] = "l,3\u0000}\n4s+\u0011D\u001c\u0005z7KtKbj4Mtuou(I>M=(3\rD\u001el(6\u001f(\u0005yp*r/\u001c>t<\u001e4\tfhQ\u0019-Nb~=\u00028\u0016~\u0013:\u001b\u007f\u0012h\u007f!\u000e'\u000e\u0005x8I#\u0018ic-\u0011?unzj\u0015)\u0019uo2\tDOxhm\u0016>Ho\"=r";
        objectArray[44] = "1vL/;56pL\u0016\u0007\\i:\u0015j<19 Ry";
        objectArray[45] = "jOwv/$2\u0010og\u00164\u0003\u001as}-!;H.fi[c\u0015+z&\"b\u0015n{\u0016;fNk4o:f\u000bj\u0004,&xLq~+12\u001c\u0015";
        objectArray[46] = "\u001fX\u0000L1{\u0018^\u0000u\u000f\u0012G\u0014Y\t6\u007f\u0017\u000e\u001e\u001a";
        objectArray[47] = "o\u0005\u0002,\u0010\u0014h\u0003\u0002\u0015\u0005}pI\u001e\u007f\n\u0004;EY.hGvCXq\u0012@a\t\b\u0015";
        objectArray[48] = "i\bm\t6Wn\u000em0\">vDqZ,G=H6\u000bN\u0004pN7T4\u0003g\u0004g0";
        objectArray[49] = "+E\u0002-.u,C\u0002\u0014\u0016\u001cs\u0014\u001e/<nq\u0007]j";
        objectArray[50] = "S2|\tG%\u000bmd\u0018~0:f{\u0019\u0001$\u00065l\u0004\u0005ZSk'K@=Ch!K~1S6y\u0016\u0012*Fne{\u00153\u0001js\u0017\u000e&Yv\u001e\u0010\u0017a]`r\u000b\u00029A\rt\u001d\u0007a@5&@\u001c%:7c\u0000B>@0tJ\u0012Z";
        objectArray[51] = "\u001cRca\ri\u001bTcX4\u0000D\u001e:$\nm\u0014\u0004}7";
        objectArray[52] = "\u0002yv%\u0013I\u0005\u007fv\u001c$ Z(j'\u0001RX;)b";
        objectArray[53] = "[8\u0005S=w^:\u0011U\u0000&\u0004]\u0004PywEeV\rb3";
        objectArray[54] = "GbfpyG@dfIM.\u001f3zrk\\\u001d 97";
        objectArray[55] = "aY0k\u001c9d[$m!h?<0kC}{\u0000c|^y";
        objectArray[56] = "\u0013;\u0007#y\r\u0014=\u0007\u001aDdKw^f~\t\u001bm\u0019u";
        objectArray[57] = "\u000e-g&ig\u000f4xi\u00042k6tyg4\u00149/n?[";
        objectArray[58] = "p 9\u0006y>w&9?jWol%Uc.$`b\u0004\u0001mifc[{j~,3?";
        objectArray[59] = "{Le\u00028g|Je;0\u000ed\u0001b_?im\u0013`";
        objectArray[60] = "d\t\u000eZg\u0005|\u0001B]W\u0011\u001d\u001cN\u0010>\u0006!\u000fNO%x";
        objectArray[61] = "|c6\u001cV\ru}<T4\bEb'\u0014^\u0003<)+S\u000fa\u007fd-RP\u001bxsg\u00024";
        objectArray[62] = "\u0004Uw\u0011\r\"\u0003Sw(2K\\\u0019.T\n&\f\u0003iG";
        objectArray[63] = "x6Sx+\u000f\u007f0SA-f gOz9\u0014\"t\f?";
        objectArray[64] = "i\u001bs8\r,q\u0013??=8\u0010\n' B/,Y0=FQ{\u0004 =Cm(\u0013=9=";
        objectArray[65] = "?\fL\u001f@\u001egST\u000ey\rVXK\u000f\u0006\u001fj\u000b\\\u0012\u0002a=Z\u0015\n\u0014\r&OM\u0016y\n?\bI\u0000\u0015\u0011*PUm\u0012\bmTC\u0001\t\u001d5H.\u0007\u001f\u0018mI\u0016UB\u0003)3G\u000b@QhTW\bFQV\tS\u0016E\u0005,\u000eD\\\u0015a";
        objectArray[66] = "[F*i\u000b1\u000b\\mzt5gPj,\u0018:\u000eOz.J\\";
        objectArray[67] = "Q\u0014D\u000b\u000f:V\u0012D25S\tX\u001dN\b>YBZ]";
        objectArray[68] = "ZK\u0006N\u001d\t]M\u0006w/`\u0002\u001a\u001aL\u000f\u0012\u0000\tY\t";
        objectArray[69] = "f\u007f+i)Jmau<L]\u001cu:+&Ve>6lw4`m*!\"D{4$mL";
        objectArray[70] = "u&\u000f\u0001\u001c<r \u000f8)U-w\u0013\u0003\u000e'/dPF";
        objectArray[71] = "\u0016o|`5n\u0011i|Y\u000e\u0007N#%%2j\u001e9b6";
        objectArray[72] = "\u0004?p\u0017Uj\\`h\u0006l~mk{^\u000bx\u0001pn\u0006\u0017\u0015\u0004f+URr\u0014e-Ul~\u0004;u\b\u0000e\u0011cieVh\u0016<v\u001fQ\u007f\\l\u0012";
        objectArray[73] = "zv-df5}p-]u\\e:17|%.6vf\u001e7{)4#\"dl40]";
        objectArray[74] = "^\u001afsJsY\u001cfJM\u001a\u0007B};M*Q\u0017e+";
        objectArray[75] = "EKN:`\fBMN\u0003qeZ\u0007Riz\u001c\u0011\u000b\u00158\u0018\u000fG\u000f\u0013y ]\u001a\u0014W\u0003";
        objectArray[76] = "178^$E618g2,.{$\r>Uewc\\\\\u0016(qb\u0003&\u0011?;2g";
        objectArray[77] = "\u0007w:$('\u0000q:\u001d9N\u0018;&w27S7a&P%\u0006(#clv\u00115'\u001d";
        objectArray[78] = "|fi|^\u0016$9qmg\u0000\u00152b5\u0000\u0004y)wm\u001ci|?2>Y\u000el<4>gSh\"7j\u001dT\u007fhg\u000e";
        objectArray[79] = "HzW9@\\^v\f9/Y&b[:\u001f\u000eArX<\u001f0Mn_|Q\f\u001eyBx/[CiB}\u0013\bTtF\u0003@A\u0016bC?SAIy=iII\u001dq\u0005;\u0014RY\u000b";
        objectArray[80] = "\u001f\u0011$\u0016\u0002ZGN<\u0007;LvE/_\\H\u001a^:\u0007@%\u0016Kx\u001a\u000b\\\u0017K=\u001b;N\u001f\u0015!\tWU\nM=dPLMI+\bKY\u0015UF\u0002E_\u0004E<XX\u001f\u001c.,\u0002B\u001e\f\u0016~_YZvE/_\\H\u001a^:\u0007@%\u001dG}\u0003VI\u0006R%\u001f;N\u001f\u0015!\tWU\nM=dQC\u000f\u0015<\\\u0003\u001e\u0014QF^F^JJ<YQ\u0014\u001a.";
        objectArray[81] = "k\u0011[\u0014g%l\u0017[-VL3@G\u0016u>1S\u0004S";
        objectArray[82] = "\\I\"<JI[O\"\u0005k \\I\"<JI[O\"";
        objectArray[83] = "yba0O+y'{d!\u0005\u0006FA\u001ah\u0018\u0010[P\u001blIyba0O+y'{d";
        objectArray[84] = "2l`\u0013y95j`*YPi>zEb;$jhJ";
        objectArray[85] = "EC8}}zBE8DN\u0013\u001d\u0012$\u007foa\u001f\u0001g:";
        objectArray[86] = "F\u001c\u0012\u001a\u0002C\u0002\u001b\u0010\u0011=z4?88g F\u001c\u0012\u001a\u0002C\u0002\u001b\u0010\u0011";
        objectArray[87] = "\b1W@\u0001z\u000f7Wy7\u0013P`KB\u0013aRs\b\u0007";
        objectArray[88] = "1I\u000fHFKi\u0016\u0017Y\u007f]X\u001d\bX\u0000JdN\u001fE\u000443\u001fV]\u0012X(\n\u000eA\u007f]>O]\u0004\u0018M=I]:\u0014]c\u0011\u0000V\u000fH;\rm";
        objectArray[89] = "\n\u0018\u0014\u000e\n\u0006RG\f\u001f3\u0010cG\u0013BMI\u001aF\u0013\u0007Ly\tA\u000fGIA[\u001c\u0014\u00033\u0013\u0005^M\u0006\u000bAXE\t|Y\u001f\u001a\u001c\fD\u000bB\u0001XvFN\u0002_C\fAYH\u000f'";
        objectArray[90] = "\u0010k\fBuj\u0017m\f{p\u0003H:\u0010@gqJ)S\u0005";
        objectArray[91] = "\r\u0015/\u0014S\bUJ7\u0005j\u0019dC+_ZI\u0003S(YZw^W6Z\u000e\rY@|\nj";
        objectArray[92] = "4}O{\nXe`\u001cyw|FD<\u0018>u\u000f:\rzHGmk\u0010)J";
        objectArray[93] = "~@7.Prq\u0018t|1x\u0012\u0012e$H,,@|0\u000b\u0012";
        objectArray[94] = "\u0010\"!!\t6\u0004 4/j`hs6/\u0015wT !2\u0011\t\u0007ic$\u00145\u0014i<?j";
        objectArray[95] = "am\rwq\u0006)f\u0006~\u001eWQx\f\"wEmk\f}l;";
        objectArray[96] = ")U5K\u000fFq\n-Z6R@\u00012[IG|R%FM9+\u0003l^[U0\u00164B6R)Q0TZI<\t,9__yZi^O\\\u007fZWR_\u0002'\u0007;IJZ;j=_O\u0002:Ro\u0002TF@P*B\n]:W=\bZ9";
        objectArray[97] = "[e\u001cL_\u001aMiGL0\u001f5}\u0010O\u0000HRm\u0013I\u0000vL*L\u0006\tOG\u007f\u001c\u00170\u001cSmM\f\bN\u000ev\tv";
        objectArray[98] = "R[a\u0011r\u000fR\u001e{E\u001c+-oZ9U(!s^9X<l\u001af\u0007r\u0003\u000e\u001a#\u001d&";
        objectArray[99] = "iZ\u0011+*/n\\\u0011\u0012;Fc\u0000Ilb}5\u0003\b\u007fR(jY\t\"i~i\u0018\u001a\u0012";
        objectArray[100] = "_Wfc l\u0007\b~r\u0019z6\u0003m*~~Z\u0018xrb\u0013]\u0001?vt\u007fF\u0014gj\u0019x_Sc|ucJ\u000b\u007f\u0011rz\r\u000fi}ioU\u0013\u0004zp(Q\u0005haepMhnw`(LP<*{l6\u0001b()-Q\u0011a.)\u0013\f\u0015\u007f-}i\u000b\u00025}\u0019";
        objectArray[101] = "mxTd\u000f\rj~T]\u0006dr5S9\b\u0003{'Q";
        objectArray[102] = "\u0018\nOw]\u0007P\u0001D~2^(\u000bNhXXQ@B/\t:\u0012\rD.V@\u0015\u001a\u000e~2";
        Object[] objectArray2 = objectArray;
        objectArray[103] = ")'\ri&\t.!\rP,`qv\u0011k4\u0012seR.";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = Nametags.e(l2, l3);
            object = Y[n2];
            try {
                if (!(object instanceof String)) break block2;
                Nametags.Y[n2] = clazz = Class.forName(Z[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = Nametags.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int index = 0; index < classArray.length; ++index) {
                field = Nametags.d(classArray[index], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = Nametags.e(l2, l3);
        Object object = Y[n2];
        if (object instanceof String) {
            String string = Z[n2];
            int n3 = string.indexOf(8);
            Class clazz = Nametags.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = Nametags.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = Nametags.c(clazz3, string2, clazz2)) != null) {
                    Nametags.Y[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int index = 0; index < classArray.length; ++index) {
                        field = Nametags.d(classArray[index], string2, clazz2);
                        if (field == null) continue;
                        Nametags.Y[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = Nametags.f(2368209596313495L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int parameterCount, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != parameterCount) continue;
            for (int index = 0; index < parameterCount; ++index) {
                if (classArray2[index] != classArray[index]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int parameterCount, Class[] classArray) {
        Method method = Nametags.c(clazz, string, clazz2, parameterCount, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int index = 0; index < classArray2.length; ++index) {
                method = Nametags.d(classArray2[index], string, clazz2, parameterCount, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = Nametags.e(l2, l3);
        Object object = Y[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = Z[n2];
                int n4 = string2.indexOf(8);
                clazz3 = Nametags.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int paramIndex = 0; paramIndex < n6; ++paramIndex) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = Nametags.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (paramIndex < n3) {
                        classArray2[paramIndex] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = Nametags.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        Nametags.Y[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = Nametags.f(2368209596313495L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = Nametags.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        Nametags.Y[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = Nametags.f(2368209596313495L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == 'G' || c2 == '\u00e5' || c2 == '\u00d4' || c2 == '\u00e3') {
                field = Nametags.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == 'G' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == '\u00e5' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == '\u00d4' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = Nametags.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == 'H' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == 'N' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = Nametags.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_2().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/ac" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Nametags.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(Nametags.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_2() {
        try {
            return MethodHandles.lookup().findStatic(Nametags.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

