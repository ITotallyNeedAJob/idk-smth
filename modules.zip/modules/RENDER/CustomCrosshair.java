// === Kuzi module: CustomCrosshair ===
// Category   : RENDER
// Description: Renders a custom crosshair
// Payload    : a.a.a.j.g.M (verified: False)

package kuzi.modules.render;

import java.awt.Color;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import kuzi.mixin.MixinExposed;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.b.e;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;

public final class CustomCrosshair
extends BaseModule {
    private static CustomCrosshair instance;
    public final SliderSetting size;
    public final SliderSetting gap;
    public final SliderSetting thickness;
    public final e q;
    private static final long r;
    private static final Object[] v;
    private static final String[] w;

    public CustomCrosshair() {
        long l2 = r ^ 0x7FD840DF2AA1L;
        long l3 = l2 ^ 0x1E48088B90D2L;
        super("Custom Crosshair", "Renders a custom crosshair", Category.RENDER);
        this.size = new SliderSetting("Size", 5.0, 1.0, 20.0, 1.0);
        this.gap = new SliderSetting("Gap", 2.0, 0.0, 10.0, 1.0);
        this.thickness = new SliderSetting("Thickness", 1.0, 0.5, 5.0, 0.5);
        this.q = new e("Color", Color.WHITE);
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.size, this.gap, this.thickness, this.q};
        objectArray[0] = l3;
        this.l(objectArray);
        instance = this;
    }

    @MixinExposed
    public static CustomCrosshair a() {
        return instance;
    }

    static {
        r = 70863792185702L;
        v = new Object[]{"FQqK&\u001cMQy", "\u001bVFC\u0007U\u0010V@C+", "\u000b\u0007cq\u0018G\u0002\u0007`q\u0014", "obv\u0006v/fbu\u0006r", "\u0017\u0007\u0016\u0002\r3\u001c\u0007\u001d", "\u0006hnTFysHe[W6\u0012FnPSlf", Void.TYPE, "I\u000b|t3\u0001B\u0004m;R\u000fI\u000fia", "lmh\u007f]n?\u007fn\u00078RH\\[]b}snn8\u0013.ah", "\u0017\u0014hn\u0001]\u0001\u0004w^\u0007d_\u000fv9P\u001e\u000b\u000f{'", "\u0013Vf\r1/\u0005Fy=6\u0016[MxZ`l\u000fMuD", "\f(0\u001c\u001c#\u001a8/,\u0005\u001aD3.KM`\u00103#U", "*X\u000egRf<H\u0011WJ_aR\u0016jU85H\u0013%", "\u000b?9+\u001b\u0017Q l'\"N1x,|I\u001a\u0001?l/S*\r;i SVC&-'\"", "V\u0001\bQ\u0004i@\u0011\u0017a\u0000PV\u0001\bQ\u0004i@\u0011\u0017"};
        w = new String[]{null, null, null, null, null, null, "java/lang/Void", null, null, null, null, null, null, null, null};
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = CustomCrosshair.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = CustomCrosshair.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = CustomCrosshair.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = CustomCrosshair.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }
}

