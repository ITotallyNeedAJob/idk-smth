// === Kuzi module: HealthIndicators ===
// Category   : RENDER
// Description: Rows of hearts above players
// Payload    : a.a.a.j.g.S (verified: True)

package kuzi.modules.render;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.b.v;
import kuzi.obf.j.g.aD;
import kuzi.obf.m.r;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.Component;
import net.minecraft.Minecraft;
import net.minecraft.Font;
import net.minecraft.Mth;
import net.minecraft.Camera;
import net.minecraft.PoseStack;
import net.minecraft.MultiBufferSource;
import net.minecraft.AbstractClientPlayer;
import net.minecraft.Axis;
import org.joml.Matrix4f;
import org.joml.Quaternionfc;

public final class HealthIndicators
extends BaseModule {
    private final SliderSetting heartsPerRow;
    private final BoolSetting showSelf;
    private final BoolSetting invisible;
    private final BoolSetting visibleThroughWalls;
    private static final int q;
    private static final int r;
    private static final Component t;
    private static final long u;
    private static final String[] v;
    private static final String[] w;
    private static final Map x;
    private static final long[] y;
    private static final Integer[] z;
    private static final Map A;
    private static final Object[] B;
    private static final String[] C;

    public HealthIndicators() {
        long l2;
        long l3 = l2 = u ^ 0x54BDE5DFFE8EL;
        long l4 = l3 ^ 0x6CEFB672C1F5L;
        long l5 = l3 ^ 0x7BE71492D941L;
        super("HealthIndicators", "Rows of hearts above players", Category.RENDER);
        this.heartsPerRow = new SliderSetting("Hearts Per Row", 10.0, 1.0, 30.0, 1.0);
        this.showSelf = new BoolSetting("Show Self", false);
        this.invisible = new BoolSetting("Invisible", false);
        this.visibleThroughWalls = new BoolSetting("Visible Through Walls", false);
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.heartsPerRow, this.showSelf, this.invisible, this.visibleThroughWalls};
        objectArray[0] = l4;
        this.l(objectArray);
        WorldRenderEvents.END_MAIN.register(arg_0 -> this.a(l5, arg_0));
    }

    private void a(long l2, WorldRenderContext worldRenderContext) {
        Minecraft mc;
        int[] nArray;
        block22: {
            block21: {
                Minecraft mcRef;
                block20: {
                    l2 = u ^ l2;
                    nArray = aD.b();
                    if (!this.d()) {
                        return;
                    }
                    mcRef = mc = Minecraft.getInstance();
                    if (l2 <= 0L || nArray == null) break block20;
                    if (mcRef.level == null) break block21;
                    mcRef = mc;
                }
                if (mcRef.player != null) break block22;
            }
            return;
        }
        PoseStack poseStack = worldRenderContext.matrices();
        Camera camera = mc.gameRenderer.getMainCamera();
        MultiBufferSource buffers = worldRenderContext.consumers();
        if (poseStack == null || camera == null || buffers == null) {
            return;
        }
        Font font = mc.font;
        Font.mc6415 textLayer = (Boolean)this.visibleThroughWalls.a() != false ? Font.mc6415.SEE_THROUGH : Font.mc6415.NORMAL;
        double camX = camera.position().x;
        double camY = camera.position().y;
        double camZ = camera.position().z;
        float partialTick = mc.getDeltaTracker().getGameTimeDeltaPartialTick(false);
        int heartsPerRowCount = ((Double)this.heartsPerRow.a()).intValue();
        double maxRenderDistanceSq = 16384.0;
        MultiBufferSource.mc4598 playerIterator = mc.level.players().iterator();
        block0: while (true) {
            int n3 = playerIterator.hasNext();
            block1: while (n3 != 0) {
                AbstractClientPlayer player = (AbstractClientPlayer)playerIterator.next();
                int[] nArray2 = nArray;
                while (nArray2 != null) {
                    block19: {
                        int totalHearts;
                        int[] nArray3;
                        int flag;
                        block29: {
                            block27: {
                                double distanceSq;
                                block28: {
                                    int[] nArray4;
                                    block25: {
                                        block26: {
                                            AbstractClientPlayer targetPlayer;
                                            block23: {
                                                block24: {
                                                    targetPlayer = player;
                                                    if (nArray == null) break block23;
                                                    if (targetPlayer != mc.player) break block24;
                                                    flag = ((Boolean)this.showSelf.a()).booleanValue() ? 1 : 0;
                                                    nArray4 = nArray;
                                                    if (l2 <= 0L) break block25;
                                                    if (nArray4 != null) {
                                                        if (flag == 0 && l2 > 0L) continue block0;
                                                    }
                                                    break block26;
                                                }
                                                targetPlayer = player;
                                            }
                                            flag = targetPlayer.isInvisible();
                                        }
                                        nArray4 = nArray;
                                    }
                                    if (nArray4 == null) break block27;
                                    if (flag == 0) break block28;
                                    flag = ((Boolean)this.invisible.a()).booleanValue() ? 1 : 0;
                                    nArray3 = nArray;
                                    if (l2 < 0L) break block29;
                                    if (nArray3 != null) {
                                        if (flag == 0 && l2 > 0L) continue block0;
                                    }
                                    break block27;
                                }
                                flag = (distanceSq = player.distanceToSqr(camera.position()) - maxRenderDistanceSq) == 0.0 ? 0 : (distanceSq > 0.0 ? 1 : -1);
                            }
                            nArray3 = nArray;
                        }
                        if (nArray3 != null) {
                            if (flag > 0 && l2 >= 0L) continue block0;
                            flag = Math.max(0, Mth.ceil((float)(player.getHealth() / 2.0f)));
                        }
                        int healthHearts = flag;
                        int absorptionHearts = Math.max(0, Mth.ceil((float)(player.getAbsorptionAmount() / 2.0f)));
                        int computedRows = totalHearts = healthHearts + absorptionHearts;
                        if (nArray != null) {
                            if (computedRows <= 0 && l2 > 0L) continue block0;
                            computedRows = (totalHearts + heartsPerRowCount - 1) / heartsPerRowCount;
                        }
                        int rowCount = computedRows;
                        double offsetX = Mth.lerp((double)partialTick, (double)player.xOld, (double)player.getX()) - camX;
                        double offsetY = Mth.lerp((double)partialTick, (double)player.yOld, (double)player.getY()) - camY + (double)player.getBbHeight() + 0.7;
                        double offsetZ = Mth.lerp((double)partialTick, (double)player.zOld, (double)player.getZ()) - camZ;
                        poseStack.pushPose();
                        poseStack.translate(offsetX, offsetY, offsetZ);
                        poseStack.mulPose((Quaternionfc)Axis.YP.rotationDegrees(-camera.yRot()));
                        poseStack.mulPose((Quaternionfc)Axis.XP.rotationDegrees(camera.xRot()));
                        poseStack.scale(-0.025f, -0.025f, 0.025f);
                        Matrix4f matrix4f = poseStack.last().pose();
                        int heartWidth = font.width("\u2764") + 1;
                        int heartIndex = 0;
                        int rowIndex = 0;
                        block3: while (true) {
                            int rowCursor = rowIndex;
                            int rowLimit = rowCount;
                            block4: while (rowCursor < rowLimit) {
                                int heartsInRow = Math.min(heartsPerRowCount, totalHearts - rowIndex * heartsPerRowCount);
                                int rowWidth = heartsInRow * heartWidth;
                                float rowStartX = (float)(-rowWidth) / 2.0f;
                                int rowFromBottom = -(rowCount - rowIndex);
                                Objects.requireNonNull(font);
                                CallSite lineHeight = HealthIndicators.c("r", (int)25477, (long)(0x61FAC6E38CDAAF80L ^ l2));
                                block5: while (true) {
                                    int rowY = rowFromBottom * lineHeight;
                                    n3 = 0;
                                    if (nArray == null) continue block1;
                                    int column = n3;
                                    while (column < heartsInRow) {
                                        Object object = heartIndex;
                                        if (nArray != null) {
                                            rowLimit = healthHearts;
                                            if (nArray == null) continue block4;
                                            if (l2 < 0L) continue block5;
                                            object = object < rowLimit ? (Object)HealthIndicators.c("r", (int)137, (long)(0x1FE71C0899234C88L ^ l2)) : (Object)HealthIndicators.c("r", (int)27972, (long)(0x64B520BC5E62A144L ^ l2));
                                        }
                                        int heartColor = object;
                                        font.drawInBatch(t, rowStartX + (float)(column * heartWidth), (float)rowY, heartColor, false, matrix4f, buffers, textLayer, 0, (int)HealthIndicators.c("r", (int)16321, (long)(0x67545B2BDBF173C3L ^ l2)));
                                        ++column;
                                        ++heartIndex;
                                        if (nArray != null) continue;
                                    }
                                    break;
                                }
                                ++rowIndex;
                                nArray2 = nArray;
                                if (l2 < 0L) break block19;
                                if (nArray2 != null) continue block3;
                            }
                            break;
                        }
                        poseStack.popPose();
                        if (l2 <= 0L) break block0;
                        nArray2 = nArray;
                        if (l2 <= 0L) continue;
                    }
                    if (nArray2 == null) break block0;
                    continue block0;
                }
                continue block0;
            }
            break;
        }
        {
            MultiBufferSource batchSource = buffers;
            if (nArray != null) {
                if (!(batchSource instanceof MultiBufferSource.mc4598)) break;
                batchSource = buffers;
            }
            playerIterator = (MultiBufferSource.mc4598)batchSource;
            playerIterator.endBatch();
            break;
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block21: {
            block20: {
                block19: {
                    block18: {
                        HealthIndicators.u = kuzi.obf.h.b.v.a(-6362339340613851408L, -6102010773268420147L, MethodHandles.lookup().lookupClass()).a(191391186666678L);
                        HealthIndicators.B = new Object[25];
                        HealthIndicators.C = new String[25];
                        HealthIndicators.c();
                        HealthIndicators.x = new HashMap<K, V>(13);
                        var11 = HealthIndicators.u ^ 1068898628736L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[6];
                        var18_4 = 0;
                        var17_5 = "\u00ce\u0014-?\u00d3\u000b\u0081d\u00e6\u00b3\u00a4?\u00f7h\u00db\u0004_\u0001!#\u00e5D\u0090\u008f\u00c2\u0018\u00f9dk6Rf\u00b6\u00f9\u00e3\u00d0\u00c3k\u00ff\u00b4_?/y\u00aa\u00d5\u001d\u00f2(\u0092\u00d7j<\u00ba3\u00c7V\u008b\u00da\u0000Y\u00d3\u0098[\u000e\u00fb\u00b8\u0093\u0095\u001d\u00f0A\u0098\n\u00ac\u00a8D\u00b9~_[$\u00da Z\u00ba\u0093(\u00ea\u0018\u0017g\u000e [\u0004!\u0007r\u00ae\u00d4)$C3\u001d\u00127;\u00c3e%\u0095B /\u00a0O\u001dY1@ke\u008b0\u00cb\u00f2N\u00adc\u00f9OJ\u0018\u00ec\u00c6p\u0097\u008c\u0098\u0015x\u0005(v\u008e";
                        var19_6 = "\u00ce\u0014-?\u00d3\u000b\u0081d\u00e6\u00b3\u00a4?\u00f7h\u00db\u0004_\u0001!#\u00e5D\u0090\u008f\u00c2\u0018\u00f9dk6Rf\u00b6\u00f9\u00e3\u00d0\u00c3k\u00ff\u00b4_?/y\u00aa\u00d5\u001d\u00f2(\u0092\u00d7j<\u00ba3\u00c7V\u008b\u00da\u0000Y\u00d3\u0098[\u000e\u00fb\u00b8\u0093\u0095\u001d\u00f0A\u0098\n\u00ac\u00a8D\u00b9~_[$\u00da Z\u00ba\u0093(\u00ea\u0018\u0017g\u000e [\u0004!\u0007r\u00ae\u00d4)$C3\u001d\u00127;\u00c3e%\u0095B /\u00a0O\u001dY1@ke\u008b0\u00cb\u00f2N\u00adc\u00f9OJ\u0018\u00ec\u00c6p\u0097\u008c\u0098\u0015x\u0005(v\u008e".length();
                        var16_7 = 48;
                        var15_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block18;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = HealthIndicators.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "\u00ec'\r7X\u00e0V7\u00cb,M\u00e3\u0087'\u00e7\u00e6\u001a3L\u001d\u00cfe\u009b\u008evt\u0098\u008d\u0083\u00b81\u00f1\u0087\u00b7\u00b0T\u00fd\u0087\t;\u00eb\u0088\u00af\u0081\u0007 &n\u0018\u00bc&\u00c83\u00ae\u00b3\u00ffp{\u00cc\u00afJ\u00a5\u00fd\u00c2\u00a0b\u0098\u00ca'g\\\u00a9\u00f8";
                            var19_6 = "\u00ec'\r7X\u00e0V7\u00cb,M\u00e3\u0087'\u00e7\u00e6\u001a3L\u001d\u00cfe\u009b\u008evt\u0098\u008d\u0083\u00b81\u00f1\u0087\u00b7\u00b0T\u00fd\u0087\t;\u00eb\u0088\u00af\u0081\u0007 &n\u0018\u00bc&\u00c83\u00ae\u00b3\u00ffp{\u00cc\u00afJ\u00a5\u00fd\u00c2\u00a0b\u0098\u00ca'g\\\u00a9\u00f8".length();
                            var16_7 = 48;
                            var15_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block18;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = HealthIndicators.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block19;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                HealthIndicators.v = var20_3;
                HealthIndicators.w = new String[6];
                HealthIndicators.A = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[6];
                var3_13 = 0;
                var4_14 = "\u00de\u00ea\u009b\u00b9\u00cf\\\f\u00ac\\5\u008eM~e\u00f6\u00a9\u00c6>I\u0017\u00a1\u00df\u0099\u0096\u0082\u00ed0h\nI\u00b1H";
                var5_15 = "\u00de\u00ea\u009b\u00b9\u00cf\\\f\u00ac\\5\u008eM~e\u00f6\u00a9\u00c6>I\u0017\u00a1\u00df\u0099\u0096\u0082\u00ed0h\nI\u00b1H".length();
                var2_16 = 0;
                while (true) {
                    var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                    v10 = var6_12;
                    v11 = var3_13++;
                    v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                    v13 = -1;
                    break block20;
                    break;
                }
lbl81:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    var4_14 = "\u008d\u00af\u0014uT(\u00fa\u00e2\u00ae\u0001>\u00d7\u00ae\u00f2\u00c4\u00b3";
                    var5_15 = "\u008d\u00af\u0014uT(\u00fa\u00e2\u00ae\u0001>\u00d7\u00ae\u00f2\u00c4\u00b3".length();
                    var2_16 = 0;
                    while (true) {
                        var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                        v10 = var6_12;
                        v11 = var3_13++;
                        v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                        v13 = 0;
                        break block20;
                        break;
                    }
                    break;
                }
lbl94:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    break block21;
                    break;
                }
            }
            var8_18 = v12;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            v14 = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
            switch (v13) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl107:
                // 1 sources

                ** continue;
            }
        }
        HealthIndicators.y = var6_12;
        HealthIndicators.z = new Integer[6];
        HealthIndicators.q = -43691;
        HealthIndicators.r = -15284;
        HealthIndicators.t = Component.literal((String)"\u2764");
    }

    private static r a(r value) {
        return value;
    }

    private static String b(byte[] byArray) {
        int outIndex = 0;
        int inputLength = byArray.length;
        char[] cArray = new char[inputLength];
        for (int index = 0; index < inputLength; ++index) {
            char ch;
            int byteValue = 0xFF & byArray[index];
            if (byteValue < 192) {
                cArray[outIndex++] = (char)byteValue;
                continue;
            }
            if (byteValue < 224) {
                ch = (char)((char)(byteValue & 0x1F) << 6);
                byteValue = byArray[++index];
                ch = (char)(ch | (char)(byteValue & 0x3F));
                cArray[outIndex++] = ch;
                continue;
            }
            if (index >= inputLength - 2) continue;
            ch = (char)((char)(byteValue & 0xF) << 12);
            byteValue = byArray[++index];
            ch = (char)(ch | (char)(byteValue & 0x3F) << 6);
            byteValue = byArray[++index];
            ch = (char)(ch | (char)(byteValue & 0x3F));
            cArray[outIndex++] = ch;
        }
        return new String(cArray, 0, outIndex);
    }

    private static int c(int keyIndex, long l2) {
        int tableIndex = keyIndex ^ (int)(l2 & 0x7FFFL) ^ 0x6BCE;
        if (z[tableIndex] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = y[tableIndex];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])A.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    A.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/g/S", exception);
            }
            int decodedInt = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            HealthIndicators.z[tableIndex] = decodedInt;
        }
        return z[tableIndex];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int keyIndex = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int decodedInt = HealthIndicators.c(keyIndex, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, decodedInt);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return decodedInt;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/S" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static void c() {
        Object[] objectArray = B;
        B[0] = "\u000f\u000e\u0011|h}\u0004\u000e\u0019";
        objectArray[1] = "\r~\u0016\u0000Uf\u0006~\u0010\u0000g";
        objectArray[2] = "]R\u0007\f>XTR\u0004\f<";
        objectArray[3] = "h4\u0004aDva4\u0007aH";
        objectArray[4] = "%\n\u001e\u000e,\u001a.\n\u0015";
        objectArray[5] = "dY\u0000mAd\u0011y\u000bbP+pw\u0000iTq\u0004";
        objectArray[6] = Void.TYPE;
        HealthIndicators.C[6] = "java/lang/Void";
        objectArray[7] = "b\u0018+\u0002\r*i\u0018-\u0002\r@";
        objectArray[8] = "E<";
        objectArray[9] = Boolean.TYPE;
        HealthIndicators.C[9] = "java/lang/Boolean";
        objectArray[10] = "R\r((*q^\r;";
        objectArray[11] = "J%l\nd6J%{Vh9Pn{Hh,W\u001f*\u0011?n";
        objectArray[12] = "l\u0013Ra%]e\u0013Qa%";
        objectArray[13] = "B#t\u0015EWI,eZ$YB'a\u0000";
        objectArray[14] = "H\u0005/vE\u0011\u001bH=O&'g9\u0012\u0015|\u0003Q\u0005fv\u0007P\u001c\u0017";
        objectArray[15] = "\u0019-Vz25\u001c\u007fR}Po *[%>3CwP;1";
        objectArray[16] = "8Ort%\u001c=\u001dvsG\\\u0001Naq KgOf'{";
        objectArray[17] = "\u0014x>\u001c\b/\u0011*:\u001bjt-\u007f3C\u0004)N\"8]\u000b";
        objectArray[18] = "J8Mx@nOjI\u007f\"*s?@'Lh\u0010bK9C";
        objectArray[19] = "\u000fn75H+\n<32*r6j7;MuQ3bj\u001b";
        objectArray[20] = "?XSgbPpGK#\u001c\u0006\u000f\u0011P{z\u001e4@[bbo";
        objectArray[21] = "_\t1P\u001e0\\\u00109Jg>bU$K\b%\u0013W`M\u0017T";
        objectArray[22] = "lS\bk$~f\u000fN>\u0015#WV\u0016fp %\r\r.{Gk\u0006\u000blh\"f\u0015\u0018k\u0015";
        objectArray[23] = "L\u0016\u001d\u007f\u0012^FJ[*#\u000bw\u0016\u0000*H^\u001eO\u0019:\u001eg";
        Object[] objectArray2 = objectArray;
        objectArray[24] = "^H\"%nS[\u001a&\"\f\u0006gI(pb\u0011\u0016Mxa6oX\u0016#ur\u001e\\F2!\f";
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = HealthIndicators.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int index = 0; index < classArray.length; ++index) {
                field = HealthIndicators.d(classArray[index], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int parameterCount, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != parameterCount) continue;
            for (int index = 0; index < parameterCount; ++index) {
                if (classArray2[index] != classArray[index]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int parameterCount, Class[] classArray) {
        Method method = HealthIndicators.c(clazz, string, clazz2, parameterCount, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int index = 0; index < classArray2.length; ++index) {
                method = HealthIndicators.d(classArray2[index], string, clazz2, parameterCount, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(HealthIndicators.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

