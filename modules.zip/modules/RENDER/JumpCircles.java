// === Kuzi module: JumpCircles ===
// Category   : RENDER
// Description: (identified by constant match; old tree JumpCircles.java)
// Payload    : a.a.a.j.e.S (verified: constant-match)

package kuzi.modules.render;

import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.function.BooleanSupplier;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.core.Client;
import kuzi.mixin.MixinExposed;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.module.Module;
import kuzi.obf.e.i;
import kuzi.obf.h.b.e;
import kuzi.obf.h.b.l;
import kuzi.obf.h.b.v;
import kuzi.obf.j.e.aj;
import kuzi.obf.j.e.al;
import kuzi.obf.j.e.am;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.Identifier;
import net.minecraft.Minecraft;
import net.minecraft.PoseStack;

public final class JumpCircles
extends BaseModule
implements Module {
    private static final int m;
    private static final int n;
    private static final int o;
    private static final Identifier circleTexture;
    private static boolean renderHookRegistered;
    private final l r;
    private final SliderSetting lifetimeS;
    private final SliderSetting startRadius;
    private final SliderSetting endRadius;
    private final SliderSetting lineWidth;
    private final SliderSetting distortion;
    private final e x;
    private final BoolSetting gradient;
    private final e z;
    private final BoolSetting throughWalls;
    private final BoolSetting glowMode;
    private final BoolSetting glowFilled;
    private final BoolSetting watermarkMode;
    private final BoolSetting blockGlowMode;
    private final SliderSetting blockGlowLifetimeS;
    private final e G;
    private final List ringEffects;
    private final List blockGlowEffects;
    private boolean J;
    private static final long K;
    private static final String[] L;
    private static final String[] M;
    private static final Map N;
    private static final long[] O;
    private static final Integer[] P;
    private static final Map Q;
    private static final Object[] R;
    private static final String[] S;

    public JumpCircles() {
        block0: {
            long l2;
            long l3 = l2 = K ^ 0x32F628D98274L;
            long l4 = l3 ^ 0x5EFFA04EA43AL;
            long l5 = l4 >>> 32;
            int n2 = (int)(l4 << 32 >>> 32);
            long l6 = l3 ^ 0x1A1F235C5C15L;
            int n3 = (int)(l6 >>> 48);
            int n4 = (int)(l6 << 16 >>> 48);
            int n5 = (int)(l6 << 32 >>> 32);
            long l7 = l3 ^ 0x2EA3045384BEL;
            long l8 = l3 ^ 0x5A4E5C7FA09EL;
            long l9 = l3 ^ 0x1CFAF7309EE1L;
            int n6 = (int)(l9 >>> 32);
            int n7 = (int)(l9 << 32 >>> 48);
            int n8 = (int)(l9 << 48 >>> 48);
            long l10 = l3 ^ 0x7C2B4460977BL;
            long l11 = l3 ^ 0x25D392592146L;
            long l12 = l3 ^ 0x634E72ED69BL;
            super("JumpCircles", "Renders rings when you jump.", Category.RENDER);
            this.r = new l("Style", (Enum)a.a.a.j.e.l.CLASSIC, a.a.a.j.e.l.class);
            this.lifetimeS = new SliderSetting("Lifetime (s)", 1.0, 0.1, 5.0, 0.1);
            this.startRadius = new SliderSetting("Start Radius", 0.55, 0.1, 3.0, 0.05);
            this.endRadius = new SliderSetting("End Radius", 1.8, 0.2, 6.0, 0.05);
            this.lineWidth = new SliderSetting("Line Width", 2.0, 0.5, 6.0, 0.1);
            this.distortion = new SliderSetting("Distortion", 0.6, 0.0, 2.0, 0.05);
            this.x = new e("Color", new Color(120, 220, 255, 255));
            this.gradient = new BoolSetting("Gradient", false);
            this.z = new e("Second Color", new Color(200, 120, 255, 255));
            this.throughWalls = new BoolSetting("Through Walls", false);
            this.glowMode = new BoolSetting("Glow Mode", false);
            this.glowFilled = new BoolSetting("Glow Filled", false);
            this.watermarkMode = new BoolSetting("Watermark Mode", false);
            String string = am.b();
            this.blockGlowMode = new BoolSetting("Block Glow Mode", false);
            this.blockGlowLifetimeS = new SliderSetting("Block Glow Lifetime (s)", 1.0, 0.1, 5.0, 0.1);
            this.G = new e("Glow Color", new Color(255, 100, 200, 200));
            this.ringEffects = new ArrayList();
            this.blockGlowEffects = new ArrayList();
            BooleanSupplier booleanSupplier = () -> this.lambda$new$0(l5, n2);
            BooleanSupplier booleanSupplier2 = () -> this.lambda$new$1(l11);
            BooleanSupplier booleanSupplier3 = () -> this.lambda$new$2((char)n3, (char)n4, n5);
            Object[] objectArray = new Object[2];
            objectArray[1] = () -> JumpCircles.lambda$new$3(l10, booleanSupplier2);
            objectArray[0] = l7;
            this.startRadius.a(objectArray);
            Object[] objectArray2 = new Object[2];
            objectArray2[1] = booleanSupplier2;
            objectArray2[0] = l7;
            this.distortion.a(objectArray2);
            Object[] objectArray3 = new Object[2];
            objectArray3[1] = booleanSupplier;
            objectArray3[0] = l7;
            this.lineWidth.a(objectArray3);
            Object[] objectArray4 = new Object[2];
            objectArray4[1] = booleanSupplier;
            objectArray4[0] = l7;
            this.glowMode.a(objectArray4);
            Object[] objectArray5 = new Object[2];
            objectArray5[1] = booleanSupplier;
            objectArray5[0] = l7;
            this.glowFilled.a(objectArray5);
            Object[] objectArray6 = new Object[2];
            objectArray6[1] = booleanSupplier;
            objectArray6[0] = l7;
            this.watermarkMode.a(objectArray6);
            Object[] objectArray7 = new Object[2];
            objectArray7[1] = booleanSupplier3;
            objectArray7[0] = l7;
            this.gradient.a(objectArray7);
            Object[] objectArray8 = new Object[2];
            objectArray8[1] = () -> this.lambda$new$4(n6, booleanSupplier3, n7, (char)n8);
            objectArray8[0] = l7;
            this.z.a(objectArray8);
            Object[] objectArray9 = new Object[2];
            objectArray9[1] = booleanSupplier3;
            objectArray9[0] = l7;
            this.throughWalls.a(objectArray9);
            Object[] objectArray10 = new Object[2];
            objectArray10[1] = this.blockGlowMode::a;
            objectArray10[0] = l7;
            this.blockGlowLifetimeS.a(objectArray10);
            Object[] objectArray11 = new Object[2];
            objectArray11[1] = this.blockGlowMode::a;
            objectArray11[0] = l7;
            this.G.a(objectArray11);
            Object[] objectArray12 = new Object[2];
            objectArray12[1] = new Setting[]{this.r, this.lifetimeS, this.startRadius, this.endRadius, this.lineWidth, this.distortion, this.x, this.gradient, this.z, this.throughWalls, this.glowMode, this.glowFilled, this.watermarkMode, this.blockGlowMode, this.blockGlowLifetimeS, this.G};
            objectArray12[0] = l12;
            this.l(objectArray12);
            Object[] objectArray13 = new Object[1];
            objectArray13[0] = l8;
            JumpCircles.c(objectArray13);
            if (string != null) break block0;
            BaseModule.b(new int[1]);
        }
    }

    @Override
    public void d() {
        this.ringEffects.clear();
        this.blockGlowEffects.clear();
        Client.a().a(Module.class, this);
    }

    @Override
    public void e() {
        Client.a().b(Module.class, this);
        this.ringEffects.clear();
        this.blockGlowEffects.clear();
    }

    /*
     * Unable to fully structure code
     */
    @MixinExposed
    public static void a() {
        block8: {
            block9: {
                block6: {
                    block7: {
                        block5: {
                            var0 = JumpCircles.K ^ 69989348101678L;
                            var2_1 = var0 ^ 43246872506509L;
                            var4_2 = am.b();
                            v0 = Client.a();
                            if (var4_2 == null) ** GOTO lbl9
                            if (v0 != null) {
                                v0 = Client.a();
lbl9:
                                // 2 sources

                                v1 = (JumpCircles)v0.a(JumpCircles.class);
                            } else {
                                v1 = null;
                            }
                            v2 = var5_3 = v1;
                            if (var4_2 == null) break block5;
                            if (v2 == null) break block6;
                            v2 = var5_3;
                        }
                        if (var4_2 == null) break block7;
                        if (!v2.d()) break block6;
                        v2 = var5_3;
                    }
                    if (var4_2 == null) break block8;
                    if (BaseModule.a.player != null) break block9;
                }
                return;
            }
            v3 = new Object[4];
            v3[3] = BaseModule.a.player.getZ();
            v3[2] = BaseModule.a.player.getY();
            v3[1] = BaseModule.a.player.getX();
            v3[0] = var2_1;
            var5_3.a(v3);
        }
    }

    private void a(Object[] objectArray) {
        block3: {
            long l2;
            long l3;
            block2: {
                l3 = (Long)objectArray[0];
                double x = (Double)objectArray[1];
                double y = (Double)objectArray[2];
                double z = (Double)objectArray[3];
                l2 = (l3 = K ^ l3) ^ 0x2C5D112D55AEL;
                long l4 = System.currentTimeMillis();
                String string = am.b();
                this.ringEffects.add(new aj(x, y + 0.02, z, l4));
                Object[] objectArray2 = new Object[3];
                objectArray2[2] = (int)JumpCircles.c("v", (int)16333, (long)(0x735DEAC7217DC05DL ^ l3));
                objectArray2[1] = this.ringEffects;
                objectArray2[0] = l2;
                JumpCircles.trimToLimit(objectArray2);
                boolean bl = (Boolean)this.blockGlowMode.a();
                if (string == null) break block2;
                if (!bl) break block3;
                bl = this.blockGlowEffects.add(new al(Math.floor(x), Math.floor(y), Math.floor(z), l4));
            }
            Object[] objectArray3 = new Object[3];
            objectArray3[2] = (int)JumpCircles.c("v", (int)16333, (long)(0x735DEAC7217DC05DL ^ l3));
            objectArray3[1] = this.blockGlowEffects;
            objectArray3[0] = l2;
            JumpCircles.trimToLimit(objectArray3);
        }
    }

    @Override
    public void b() {
        long l2;
        long l3;
        String string;
        block9: {
            block12: {
                block11: {
                    Minecraft mc;
                    block10: {
                        string = am.b();
                        mc = BaseModule.a;
                        if (string == null) break block10;
                        if (mc.level == null) break block11;
                        mc = BaseModule.a;
                    }
                    if (mc.player != null) break block12;
                }
                return;
            }
            l3 = System.currentTimeMillis();
            long l4 = (long)((Double)this.lifetimeS.a() * 1000.0);
            Iterator iterator = this.ringEffects.iterator();
            block0: while (true) {
                int n2 = iterator.hasNext();
                while (n2 != 0) {
                    l2 = l3 - ((aj)iterator.next()).d;
                    if (string != null) {
                        long l5 = l2 - l4;
                        n2 = l5 == 0L ? 0 : (l5 < 0L ? -1 : 1);
                        if (string == null) continue;
                        if (n2 < 0) continue block0;
                        iterator.remove();
                        if (string == null) break block0;
                        continue block0;
                    }
                    break block9;
                }
                break;
            }
            l2 = (long)((Double)this.blockGlowLifetimeS.a() * 1000.0);
        }
        long l6 = l2;
        Iterator iterator = this.blockGlowEffects.iterator();
        block2: while (true) {
            int n3 = iterator.hasNext();
            while (n3 != 0) {
                long l7 = l3 - ((al)iterator.next()).d - l6;
                n3 = l7 == 0L ? 0 : (l7 < 0L ? -1 : 1);
                if (string == null) continue;
                if (n3 < 0) continue block2;
                iterator.remove();
                if (string == null) break block2;
                continue block2;
            }
            break;
        }
    }

    private static void c(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = (l2 = K ^ l2) ^ 0x72CF36047945L;
        String string = am.b();
        boolean bl = renderHookRegistered;
        if (string != null) {
            if (bl) {
                return;
            }
            bl = true;
        }
        renderHookRegistered = bl;
        WorldRenderEvents.END_MAIN.register(arg_0 -> JumpCircles.a(l3, arg_0));
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static void a(long l2, WorldRenderContext worldRenderContext) {
        PoseStack poseStack;
        JumpCircles jumpCircles;
        long l3;
        block14: {
            JumpCircles jumpCircles2;
            CallSite callSite;
            block13: {
                JumpCircles jumpCircles3;
                block15: {
                    block12: {
                        i i2;
                        block11: {
                            l3 = (l2 = K ^ l2) ^ 0x4F3D6852382FL;
                            callSite = JumpCircles.d("\u00f8", (long)-7762461334845688453L, (long)l2);
                            try {
                                i2 = Client.a();
                                if (callSite == null) break block11;
                                if (i2 == null) break block12;
                            }
                            catch (IllegalStateException illegalStateException) {
                                throw JumpCircles.d("\u00f8", (Object)illegalStateException, (long)-7761747276372239877L, (long)l2);
                            }
                            i2 = Client.a();
                        }
                        jumpCircles3 = (JumpCircles)i2.a(JumpCircles.class);
                        break block15;
                    }
                    jumpCircles3 = null;
                }
                jumpCircles = jumpCircles3;
                try {
                    jumpCircles2 = jumpCircles;
                    if (l2 < 0L || callSite == null) break block13;
                    if (jumpCircles2 == null) return;
                }
                catch (IllegalStateException illegalStateException) {
                    throw JumpCircles.d("\u00f8", (Object)illegalStateException, (long)-7761747276372239877L, (long)l2);
                }
                jumpCircles2 = jumpCircles;
            }
            try {
                if (JumpCircles.d("\u00d6", (Object)jumpCircles2, (long)-7761170391410028186L, (long)l2) == false) {
                    return;
                }
            }
            catch (IllegalStateException illegalStateException) {
                throw JumpCircles.d("\u00f8", (Object)illegalStateException, (long)-7761747276372239877L, (long)l2);
            }
            poseStack = worldRenderContext.matrices();
            try {
                try {
                    if (callSite == null) return;
                    if (poseStack != null) break block14;
                    return;
                }
                catch (IllegalStateException illegalStateException) {
                    throw JumpCircles.d("\u00f8", (Object)illegalStateException, (long)-7761747276372239877L, (long)l2);
                }
            }
            catch (IllegalStateException illegalStateException) {
                throw JumpCircles.d("\u00f8", (Object)illegalStateException, (long)-7761747276372239877L, (long)l2);
            }
        }
        Object[] objectArray = new Object[3];
        objectArray[2] = worldRenderContext;
        objectArray[1] = l3;
        objectArray[0] = poseStack;
        JumpCircles.d("\u00d6", (Object)jumpCircles, (Object)objectArray, (long)-7748687740988312781L, (long)l2);
    }

    /*
     * Unable to fully structure code
     */
    private static void trimToLimit(Object[] var0) {
        var1_1 = (Long)var0[0];
        var4_2 = (List)var0[1];
        var3_3 = (Integer)var0[2];
        var1_1 = JumpCircles.K ^ var1_1;
        var5_4 = JumpCircles.d("\u00f8", (long)-1953405191904819751L, (long)var1_1);
        while (var4_2.size() > var3_3) {
            var4_2.remove(0);
lbl10:
            // 2 sources

            ** while (var5_4 == null)
lbl11:
            // 1 sources

        }
lbl12:
        // 2 sources

        if (var1_1 <= 0L) ** GOTO lbl10
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean lambda$new$4(int n2, BooleanSupplier booleanSupplier, int n3, char c2) {
        long l2 = ((long)n2 << 32 | (long)n3 << 48 >>> 32 | (long)c2 << 48 >>> 48) ^ K;
        String string = am.b();
        boolean bl = booleanSupplier.getAsBoolean();
        if (string != null) {
            if (!bl) return false;
            bl = (Boolean)this.gradient.a();
        }
        if (string == null) return bl;
        if (!bl) return false;
        return true;
    }

    private static boolean lambda$new$3(long l2, BooleanSupplier booleanSupplier) {
        l2 = K ^ l2;
        String string = am.b();
        boolean bl = booleanSupplier.getAsBoolean();
        if (string != null) {
            bl = !bl;
        }
        return bl;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean lambda$new$2(char c2, char c3, int n2) {
        long l2 = ((long)c2 << 48 | (long)c3 << 48 >>> 16 | (long)n2 << 32 >>> 32) ^ K;
        long l3 = l2 ^ 0x509F5846CACBL;
        String string = am.b();
        Object[] objectArray = new Object[2];
        objectArray[1] = l3;
        objectArray[0] = a.a.a.j.e.l.CLASSIC;
        boolean bl = this.r.b(objectArray);
        if (string != null) {
            if (bl) return false;
            Object[] objectArray2 = new Object[2];
            objectArray2[1] = l3;
            objectArray2[0] = a.a.a.j.e.l.GLASS;
            bl = this.r.b(objectArray2);
        }
        if (string == null) return bl;
        if (bl) return false;
        return true;
    }

    private boolean lambda$new$1(long l2) {
        long l3 = (l2 = K ^ l2) ^ 0x6F53E943B798L;
        Object[] objectArray = new Object[2];
        objectArray[1] = l3;
        objectArray[0] = a.a.a.j.e.l.GLASS;
        return this.r.b(objectArray);
    }

    private boolean lambda$new$0(long l2, int n2) {
        long l3 = (l2 << 32 | (long)n2 << 32 >>> 32) ^ K;
        long l4 = l3 ^ 0x147FDB5432E4L;
        Object[] objectArray = new Object[2];
        objectArray[1] = l4;
        objectArray[0] = a.a.a.j.e.l.CLASSIC;
        return this.r.b(objectArray);
    }

    /*
     * Unable to fully structure code
     */
    static {
        block21: {
            block20: {
                block19: {
                    block18: {
                        JumpCircles.K = kuzi.obf.h.b.v.a(5594575715441568738L, 2275154713648409953L, MethodHandles.lookup().lookupClass()).a(233281993159154L);
                        var20 = JumpCircles.K ^ 11370155872144L;
                        JumpCircles.R = new Object[142];
                        JumpCircles.S = new String[142];
                        JumpCircles.c();
                        JumpCircles.N = new HashMap<K, V>(13);
                        var11_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var20 >>> 56);
                        for (var12_2 = 1; var12_2 < 8; ++var12_2) {
                            v2 = v2;
                            v2[var12_2] = (byte)(var20 << var12_2 * 8 >>> 56);
                        }
                        var11_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var18_3 = new String[28];
                        var16_4 = 0;
                        var15_5 = "\u00a2@\u00bah\\\u00fa\u00bc\u000f\u00b2*\u0017\u0005R\u001e\u00ea\\\u0081\u008e\u00ff\u00a8\u009cxr\u008b\u0096\u00d0\u00f7\u0086x\u00e7a\u00f8\u0018!+\u0015\u00f7%\u00a4vW\u00dd\u0098\u00df\fu\u0010\u00aaS\u00e3\u00a9\u00f02\u00e4\u00fbIMh\u00d3\u00e4\u00e8\u0002\u00bbu(\u001b\u00981C\u0098~h\u00d7\u00bb\u00c3!\u00a6\u00b4F\u00c6\u00db%.3b\u00b0\u001e!\u00ca\u00e6\u00b2fo\u00dcA$\u00b3\u001b\u00be\u00dez\u0093u\u00ae\u00d2\u001d\u001d\u00c1\u00d9\u000e\u00a9o\u001bGZ\u0003\u0098?\u00b2!D\u00ee\n\u00b5\u00e3U+`3\u00e1\u00a3\u001f\u00d0QO\u00adK\u009f6\u00e3\u0017\u0092\u00c5,\u00ed\u00a0\u00db\u0091\u0083\u008a\u00ee\u0005\u007f\u008a\u00ee\u001f\u0000\u00f4t\u008cb%\u0010C_\u00cc\u00e3X\u00a7\u000f\u000e\u00ebSf\u00c4A\u0019\u00ed\u00b7 \u00c9\u00d1\u00bd\u00a6qP\u00fc'\u0000\u0084\u008d\u009e\u00d1\u00cb\u0090\u0013C\u00cf\u00ef@\u009d\tH\u00afA-\u00a9\u001e\u00a9\u00b6\u00fc78\u00cb[b\u009a\u009aiH\u001a\u00de\u00b1\u0019\u00ed|x~%kC8\u00953\u008dC=\u000bA\u00a7\u0099\\\u00bf\u00c78\u00c1\u001bz\u00a1\u0094\u001d\u00dd\u00c7nj\u00c6NS\u00d0p\u00a6\u00e0\u009el \u008c/h\u00b2\u0018b\u0015\u00f0/\u0003\u00d6\u009b]\u0007]\u00ac}\u00f8-N;\u00f3\u00a9\u00b0whqq\u00c0\u0018\u0081\u00c9\u00d8\u0080z\u00de)\u009d\u00bdkp\u00fc\u00f7\u00fc\u0083\u00d9'OX\u00ae\u0099\u001f5C \u0099\u0081\u00ea\u00b1\u00ff\u009d\u000bU\u00a1M\u007fR&\u0017\u0006\u00b1\u0096\u00bb\n\u0088g\u00f6\u008f5%\u00a7\u00a1`^\u0088D\u00c4P\u00a5\u008d\u00e3o.\u00c0I\u00a9\u00ac~\u00fa6;yZ\u001dIc\u00c7\u0098\u00a2\u00de(\u00ee8\u00d9\u00e9!\u008a\u00c1v%0^P\u0080Tk\u00a9\u000bL\u001a\u001f\u008amd\u00a2\u001b-\u00ff\u0080\u00edp|\u0085Pi\u00a4\u008d7\u0095c}\u009am}\u00cc\u00d7K_\u00ad\u00a1\u00e0\u009a\u00fb\u0080J\u000e\n@\u0018\u00a2t{+qn\u00cdBY!\u0088\u0087\u00bd\u001b3\u0083\u0097\u00b9&\u0095\u00e4\u00d5K)\u0018@G`\u00ac2O\u00ec\u0084%X$\u00d5\u009f\u0005\u0003b\u001a{\u0082\u00d8\u00f3^4~ \u00f0K\u007f\u00b2\nb\u00e2\u009a\u008c\u00d9h\u00b5\u00aa\u001e\u00bb%\u00e8/\u0091\u0084\u00f1wDl\u0017DaBgf\u00ad\u009a w\u0005F\u000bJ\u00c6,6\u00c8\u0083\u00dc I\f\u00a0X\u00c8\u00c3\u0083{\u00b8\u0019w/\u00efP\u009d\u00a20\u0019&\u001f '\u00ee\u00aa\u00b5\u00bc\u00fa\u00e2\u00c9y;\u0086\u0010n\u00c6+\u00ac\u00d5\u00a5-\u00aak\u00c3\u00c98`rK\u00e0\u000b]=\u00b1\u0010\u00a9\u009d\u0093\u0001\u00b9{\u00acb\u00ef\u00f7z\u0012\u00f3=d\u00e3 \u0084\u0085?=\u008c\u00cc\u00d6\u00e3\u0002\u0006\u00c3\u00a9aF\u0096\u0013b\u0007\u000e~H\u00c8=\u0090\u00f4S\u00bd\u00b5)\u00b3\u00efC\u0010\u00d2\u00ac\u00c6,k\u00f9*\u0080\u001d\\\u00d23\u00ab#\u00df/ \u00d0`\u00b22\u0081\u00ba\u009c\u00adv\u00df'j\u0014\u001ew\u00adN\u00c4j\u00dc\u00bf\u008e6\u0016\u00f0\u00ed\u0006\u00c2\u00db\u00a2&3 \u00e5}\u0013\u00e38\u00ab\u00cf`\u00d3\u00f5\u00a1Q\u00ea#K\u00cf\u00fe'q*\u00a6\u00bc/77 \n\u00fb|h\u00b09\u0018C\u00f9\u00a2v\u00fd/\u0092\u009c\u00062\u00f4\u00b8X'@\u00b9\u0005_(\u00f1 $\u00d0\u00ff K\u0004R\b\u00c9\u00e3\u00dc\u00baB5\u00d6\r\u0083\u009et\u00f3\u0014\u00cb\u00a4\u00d5\\K\u00e3)z4\u00f7Uj3f\u00f7\u0010\u00ea\u00eb\u00fd2\u0012.\u00e5\"\u00adk\u008e\u0004A\u00c0Q\u00af(;,\u0084FYE%q\u00db\f\u00c36\u00ff\u00d3\u001f\u00fd\u0088\u0082:-{\u00de\u00ce\u00b8`\u001a\u00b7h7\u00edeD\u00edu\u00f9\u0098\u00e1GH'@k\u009c\u00d3\u0011\u00aa+\u0002\u00db\u00bb\u00fb\u0006@Z\u0081s\u009a\u00de\u00e0\u00d3@f\u009fSy\u00d9\u00a8@\u00be\u00e1p\u00b2t\beR\u00fbB\u00fd\u007f!\u009c\u0085\u00f8\u009ar\u00ef\u0098x\u00ae\u00e8FZ\u0003\u0006\u00bf3\u008bV?\u000f\u0087\u0099\u00cb\u00e6(\u00f66j*\u00a1g\u00a9i\u00a2\u00bc-\u00e2L\u00bc\u00e5{\u008c(\u000b\u00d3=go\u00cb\u0018a\u0017x\u0087k4\u009du\u0083\u001b\u0001+\u00e7H'";
                        var17_6 = "\u00a2@\u00bah\\\u00fa\u00bc\u000f\u00b2*\u0017\u0005R\u001e\u00ea\\\u0081\u008e\u00ff\u00a8\u009cxr\u008b\u0096\u00d0\u00f7\u0086x\u00e7a\u00f8\u0018!+\u0015\u00f7%\u00a4vW\u00dd\u0098\u00df\fu\u0010\u00aaS\u00e3\u00a9\u00f02\u00e4\u00fbIMh\u00d3\u00e4\u00e8\u0002\u00bbu(\u001b\u00981C\u0098~h\u00d7\u00bb\u00c3!\u00a6\u00b4F\u00c6\u00db%.3b\u00b0\u001e!\u00ca\u00e6\u00b2fo\u00dcA$\u00b3\u001b\u00be\u00dez\u0093u\u00ae\u00d2\u001d\u001d\u00c1\u00d9\u000e\u00a9o\u001bGZ\u0003\u0098?\u00b2!D\u00ee\n\u00b5\u00e3U+`3\u00e1\u00a3\u001f\u00d0QO\u00adK\u009f6\u00e3\u0017\u0092\u00c5,\u00ed\u00a0\u00db\u0091\u0083\u008a\u00ee\u0005\u007f\u008a\u00ee\u001f\u0000\u00f4t\u008cb%\u0010C_\u00cc\u00e3X\u00a7\u000f\u000e\u00ebSf\u00c4A\u0019\u00ed\u00b7 \u00c9\u00d1\u00bd\u00a6qP\u00fc'\u0000\u0084\u008d\u009e\u00d1\u00cb\u0090\u0013C\u00cf\u00ef@\u009d\tH\u00afA-\u00a9\u001e\u00a9\u00b6\u00fc78\u00cb[b\u009a\u009aiH\u001a\u00de\u00b1\u0019\u00ed|x~%kC8\u00953\u008dC=\u000bA\u00a7\u0099\\\u00bf\u00c78\u00c1\u001bz\u00a1\u0094\u001d\u00dd\u00c7nj\u00c6NS\u00d0p\u00a6\u00e0\u009el \u008c/h\u00b2\u0018b\u0015\u00f0/\u0003\u00d6\u009b]\u0007]\u00ac}\u00f8-N;\u00f3\u00a9\u00b0whqq\u00c0\u0018\u0081\u00c9\u00d8\u0080z\u00de)\u009d\u00bdkp\u00fc\u00f7\u00fc\u0083\u00d9'OX\u00ae\u0099\u001f5C \u0099\u0081\u00ea\u00b1\u00ff\u009d\u000bU\u00a1M\u007fR&\u0017\u0006\u00b1\u0096\u00bb\n\u0088g\u00f6\u008f5%\u00a7\u00a1`^\u0088D\u00c4P\u00a5\u008d\u00e3o.\u00c0I\u00a9\u00ac~\u00fa6;yZ\u001dIc\u00c7\u0098\u00a2\u00de(\u00ee8\u00d9\u00e9!\u008a\u00c1v%0^P\u0080Tk\u00a9\u000bL\u001a\u001f\u008amd\u00a2\u001b-\u00ff\u0080\u00edp|\u0085Pi\u00a4\u008d7\u0095c}\u009am}\u00cc\u00d7K_\u00ad\u00a1\u00e0\u009a\u00fb\u0080J\u000e\n@\u0018\u00a2t{+qn\u00cdBY!\u0088\u0087\u00bd\u001b3\u0083\u0097\u00b9&\u0095\u00e4\u00d5K)\u0018@G`\u00ac2O\u00ec\u0084%X$\u00d5\u009f\u0005\u0003b\u001a{\u0082\u00d8\u00f3^4~ \u00f0K\u007f\u00b2\nb\u00e2\u009a\u008c\u00d9h\u00b5\u00aa\u001e\u00bb%\u00e8/\u0091\u0084\u00f1wDl\u0017DaBgf\u00ad\u009a w\u0005F\u000bJ\u00c6,6\u00c8\u0083\u00dc I\f\u00a0X\u00c8\u00c3\u0083{\u00b8\u0019w/\u00efP\u009d\u00a20\u0019&\u001f '\u00ee\u00aa\u00b5\u00bc\u00fa\u00e2\u00c9y;\u0086\u0010n\u00c6+\u00ac\u00d5\u00a5-\u00aak\u00c3\u00c98`rK\u00e0\u000b]=\u00b1\u0010\u00a9\u009d\u0093\u0001\u00b9{\u00acb\u00ef\u00f7z\u0012\u00f3=d\u00e3 \u0084\u0085?=\u008c\u00cc\u00d6\u00e3\u0002\u0006\u00c3\u00a9aF\u0096\u0013b\u0007\u000e~H\u00c8=\u0090\u00f4S\u00bd\u00b5)\u00b3\u00efC\u0010\u00d2\u00ac\u00c6,k\u00f9*\u0080\u001d\\\u00d23\u00ab#\u00df/ \u00d0`\u00b22\u0081\u00ba\u009c\u00adv\u00df'j\u0014\u001ew\u00adN\u00c4j\u00dc\u00bf\u008e6\u0016\u00f0\u00ed\u0006\u00c2\u00db\u00a2&3 \u00e5}\u0013\u00e38\u00ab\u00cf`\u00d3\u00f5\u00a1Q\u00ea#K\u00cf\u00fe'q*\u00a6\u00bc/77 \n\u00fb|h\u00b09\u0018C\u00f9\u00a2v\u00fd/\u0092\u009c\u00062\u00f4\u00b8X'@\u00b9\u0005_(\u00f1 $\u00d0\u00ff K\u0004R\b\u00c9\u00e3\u00dc\u00baB5\u00d6\r\u0083\u009et\u00f3\u0014\u00cb\u00a4\u00d5\\K\u00e3)z4\u00f7Uj3f\u00f7\u0010\u00ea\u00eb\u00fd2\u0012.\u00e5\"\u00adk\u008e\u0004A\u00c0Q\u00af(;,\u0084FYE%q\u00db\f\u00c36\u00ff\u00d3\u001f\u00fd\u0088\u0082:-{\u00de\u00ce\u00b8`\u001a\u00b7h7\u00edeD\u00edu\u00f9\u0098\u00e1GH'@k\u009c\u00d3\u0011\u00aa+\u0002\u00db\u00bb\u00fb\u0006@Z\u0081s\u009a\u00de\u00e0\u00d3@f\u009fSy\u00d9\u00a8@\u00be\u00e1p\u00b2t\beR\u00fbB\u00fd\u007f!\u009c\u0085\u00f8\u009ar\u00ef\u0098x\u00ae\u00e8FZ\u0003\u0006\u00bf3\u008bV?\u000f\u0087\u0099\u00cb\u00e6(\u00f66j*\u00a1g\u00a9i\u00a2\u00bc-\u00e2L\u00bc\u00e5{\u008c(\u000b\u00d3=go\u00cb\u0018a\u0017x\u0087k4\u009du\u0083\u001b\u0001+\u00e7H'".length();
                        var14_7 = 32;
                        var13_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var13_8;
                            v4 = var15_5.substring(v3, v3 + var14_7);
                            v5 = -1;
                            break block18;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var18_3[var16_4++] = JumpCircles.b(var19_9).intern();
                            if ((var13_8 += var14_7) < var17_6) {
                                var14_7 = var15_5.charAt(var13_8);
                                ** continue;
                            }
                            var15_5 = "8\u00fb\u00f9@\u0092\u007f\u00d8\u008e\u007f\u00c8\u00a6\u00e3\u0092|\u00b51\u0087\u00b1\u00cc\u00aciH\u0099\u00a0\u00e0T\u0093\u00c6\u0092)\u00e4= \u00c9\u0096\u00e3<o\u00ce\u00dc\u00063\u00f6\u009a(\u00f2\u00b5LN\u00a1\u00f6>T\u0083\u0016\u0002\u0087\u00e9\u00ac\"\u00ef\u00d7\u00eey\u0011";
                            var17_6 = "8\u00fb\u00f9@\u0092\u007f\u00d8\u008e\u007f\u00c8\u00a6\u00e3\u0092|\u00b51\u0087\u00b1\u00cc\u00aciH\u0099\u00a0\u00e0T\u0093\u00c6\u0092)\u00e4= \u00c9\u0096\u00e3<o\u00ce\u00dc\u00063\u00f6\u009a(\u00f2\u00b5LN\u00a1\u00f6>T\u0083\u0016\u0002\u0087\u00e9\u00ac\"\u00ef\u00d7\u00eey\u0011".length();
                            var14_7 = 32;
                            var13_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var13_8;
                                v4 = var15_5.substring(v6, v6 + var14_7);
                                v5 = 0;
                                break block18;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var18_3[var16_4++] = JumpCircles.b(var19_9).intern();
                            if ((var13_8 += var14_7) < var17_6) {
                                var14_7 = var15_5.charAt(var13_8);
                                ** continue;
                            }
                            break block19;
                            break;
                        }
                    }
                    var19_9 = var11_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                JumpCircles.L = var18_3;
                JumpCircles.M = new String[28];
                JumpCircles.Q = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var20 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var20 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[29];
                var3_13 = 0;
                var4_14 = "S\u00a0c]\u0097\u007fX\u00a2\u00d3\u00e7\u00a1\u00c3\u0098\u00db18I\u00b6\u00ab\u00ee\u00a8~\u00c1\u0003\u00fe}{6\u00e0B\u0010=x\u00df\u00cam!\u00f4\u009b\u00ef\u00d1\u00b2\u0098U7H>\u00f3a\u0003\u00d7s\u0011\u00a8\u00cc\u0017\u008a\u000b\u00d2t~[\u00dc+\n\u00f9!\u0011\u0085\u001f6i\u009c\u0005\u00f7)qeejx\u0016\u00dd\u00dd%o\u0016\u00ce\u00b2\u0006$\u0083\u009c\u00e62\u00e9\u009e\u00d0\u000e\u00f8{\u00b9\u001d\u00e6\u008f\u00a3\u00ab\u000fe\u009d\u0099\u00c9A94\u0011\u0018X\u00a0\u00c9\u009c\u001bE\u0096\u00cb\u00e6\u00c2\u0080^[\u00d8\u00a2\u00eb):;\u007fy\u00b0-\u0091\u00c4\u00a6\u0003\u00e1\u0007-r)cZ\u00ebN}\u00d0^\u009a\u0005\u0011\u001e {\\?1\u0016\u00cc\u00cb\u00dc\u0095\r>\u0094\u00be\u00f2sO\u009dO?\u000f\u00e6\u008e|\u00bb\u00a2\u00df\u009d|\u00dd\u00dcr\u00e6D\u00b3k\u0011`[E?\u0099{iQn\u009as\u00fe\u008b\u00f1cyLL\u009c";
                var5_15 = "S\u00a0c]\u0097\u007fX\u00a2\u00d3\u00e7\u00a1\u00c3\u0098\u00db18I\u00b6\u00ab\u00ee\u00a8~\u00c1\u0003\u00fe}{6\u00e0B\u0010=x\u00df\u00cam!\u00f4\u009b\u00ef\u00d1\u00b2\u0098U7H>\u00f3a\u0003\u00d7s\u0011\u00a8\u00cc\u0017\u008a\u000b\u00d2t~[\u00dc+\n\u00f9!\u0011\u0085\u001f6i\u009c\u0005\u00f7)qeejx\u0016\u00dd\u00dd%o\u0016\u00ce\u00b2\u0006$\u0083\u009c\u00e62\u00e9\u009e\u00d0\u000e\u00f8{\u00b9\u001d\u00e6\u008f\u00a3\u00ab\u000fe\u009d\u0099\u00c9A94\u0011\u0018X\u00a0\u00c9\u009c\u001bE\u0096\u00cb\u00e6\u00c2\u0080^[\u00d8\u00a2\u00eb):;\u007fy\u00b0-\u0091\u00c4\u00a6\u0003\u00e1\u0007-r)cZ\u00ebN}\u00d0^\u009a\u0005\u0011\u001e {\\?1\u0016\u00cc\u00cb\u00dc\u0095\r>\u0094\u00be\u00f2sO\u009dO?\u000f\u00e6\u008e|\u00bb\u00a2\u00df\u009d|\u00dd\u00dcr\u00e6D\u00b3k\u0011`[E?\u0099{iQn\u009as\u00fe\u008b\u00f1cyLL\u009c".length();
                var2_16 = 0;
                while (true) {
                    var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                    v10 = var6_12;
                    v11 = var3_13++;
                    v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                    v13 = -1;
                    break block20;
                    break;
                }
lbl81:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    var4_14 = "9\u00b8\u00ee\u00e5\u009f%!\u0007m\u00a0\u007f\u00ad\u0089\t\u00e6\u00db";
                    var5_15 = "9\u00b8\u00ee\u00e5\u009f%!\u0007m\u00a0\u007f\u00ad\u0089\t\u00e6\u00db".length();
                    var2_16 = 0;
                    while (true) {
                        var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                        v10 = var6_12;
                        v11 = var3_13++;
                        v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                        v13 = 0;
                        break block20;
                        break;
                    }
                    break;
                }
lbl94:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    break block21;
                    break;
                }
            }
            var8_18 = v12;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            v14 = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
            switch (v13) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl107:
                // 1 sources

                ** continue;
            }
        }
        JumpCircles.O = var6_12;
        JumpCircles.P = new Integer[29];
        JumpCircles.n = 16;
        JumpCircles.m = 128;
        JumpCircles.o = 16;
        JumpCircles.circleTexture = Identifier.fromNamespaceAndPath((String)"kuzi", (String)"textures/jump_circles/kuziclient_circle.png");
    }

    private static Throwable a(Throwable throwable) {
        return throwable;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x129;
        if (P[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = O[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])Q.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    Q.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/e/S", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            JumpCircles.P[n3] = n4;
        }
        return P[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = JumpCircles.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/e/S" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (S[n4] != null) {
            return n4;
        }
        Object object = R[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 20;
            case 1 -> 21;
            case 2 -> 25;
            case 3 -> 49;
            case 4 -> 47;
            case 5 -> 3;
            case 6 -> 4;
            case 7 -> 22;
            case 8 -> 27;
            case 9 -> 39;
            case 10 -> 15;
            case 11 -> 1;
            case 12 -> 41;
            case 13 -> 10;
            case 14 -> 13;
            case 15 -> 7;
            case 16 -> 17;
            case 17 -> 9;
            case 18 -> 8;
            case 19 -> 36;
            case 20 -> 54;
            case 21 -> 56;
            case 22 -> 63;
            case 23 -> 0;
            case 24 -> 31;
            case 25 -> 61;
            case 26 -> 26;
            case 27 -> 43;
            case 28 -> 48;
            case 29 -> 24;
            case 30 -> 14;
            case 31 -> 28;
            case 32 -> 37;
            case 33 -> 50;
            case 34 -> 51;
            case 35 -> 11;
            case 36 -> 12;
            case 37 -> 40;
            case 38 -> 5;
            case 39 -> 23;
            case 40 -> 53;
            case 41 -> 18;
            case 42 -> 32;
            case 43 -> 30;
            case 44 -> 33;
            case 45 -> 60;
            case 46 -> 44;
            case 47 -> 2;
            case 48 -> 55;
            case 49 -> 6;
            case 50 -> 62;
            case 51 -> 29;
            case 52 -> 34;
            case 53 -> 35;
            case 54 -> 42;
            case 55 -> 57;
            case 56 -> 46;
            case 57 -> 38;
            case 58 -> 59;
            case 59 -> 45;
            case 60 -> 19;
            case 61 -> 58;
            case 62 -> 16;
            default -> 52;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        JumpCircles.S[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = R;
        R[0] = "O9.57\u000fD9*57M";
        objectArray[1] = Long.TYPE;
        JumpCircles.S[1] = "java/lang/Long";
        objectArray[2] = "SEmQH0XEiQHs";
        objectArray[3] = "UE\u0002n{.^J\u0013!\u00066MM\u001ah";
        objectArray[4] = "Bg\u0017%-LKg0";
        objectArray[5] = "\u0010y\"-ko\u0010y5qg`\n25ogu\rCb6?1";
        objectArray[6] = Void.TYPE;
        JumpCircles.S[6] = "java/lang/Void";
        objectArray[7] = Double.TYPE;
        JumpCircles.S[7] = "java/lang/Double";
        objectArray[8] = "FevR3IOeuR7";
        objectArray[9] = "`\u0015\u0019\u0000ok}\u0000A\".fe\u0006";
        objectArray[10] = ")\u0003w1\u007fK\"\u0003s1M";
        objectArray[11] = "mVIt\u001b\u0004dVJt\u0017";
        objectArray[12] = "qs9\"AXo{#m#Dhf";
        objectArray[13] = "b8e\u0004HAk8f\u0004H";
        objectArray[14] = "\tI\u001fr<f\u0002F\u000e=]h\tM\ng";
        objectArray[15] = "w\u001bew2!\u0002;nx#nc5es'4\u0017";
        objectArray[16] = "u'w#\u0016H~(fllLm)v#ZHz";
        objectArray[17] = "(-w oG#-|";
        objectArray[18] = "Kv\u0000/\u0010\bKv\u0017s\u001c\u0007Q=\u0017m\u001c\u0012VLG0M";
        objectArray[19] = Boolean.TYPE;
        JumpCircles.S[19] = "java/lang/Boolean";
        objectArray[20] = "pO*UL\u0017\u0005o!Z]Xda*QY\u0002\u0010";
        objectArray[21] = "1|KX\u0000A:|OX\u0000\u0005";
        objectArray[22] = "\u0006z$p\u0012\u0018sZ/\u007f\u0003W\u0012T$t\u0007\rf";
        objectArray[23] = "R\u001e\f\u001652R\u001e\u001bJ9=HU\u001bT9(O$J\u0001nk";
        objectArray[24] = Float.TYPE;
        JumpCircles.S[24] = "java/lang/Float";
        objectArray[25] = "\b;;eo:}\u001b0j~u\u001c\u0015;az/h";
        objectArray[26] = "A\u0006\u001b\u0006p{J\u0006\u001f\u0006}";
        objectArray[27] = "K-84l->\r3;}b_\u000380y8+";
        objectArray[28] = ">*8%\u0000>7*;%\u0002";
        objectArray[29] = "\u0002kV\u0010~\rwK]\u001foB\u0016EV\u0014k\u0018b";
        objectArray[30] = "\u007f6\u0012LAv\n\u0016\u0019CP9k\u0018\u0012HTc\u001f";
        objectArray[31] = "\f3T|\u0016\u0014\u00053W|\u001b";
        objectArray[32] = "!nf\u0007qeTNm\b`*5@f\u0003dpA";
        objectArray[33] = "d<\"T`\u000b\u0011\u001c)[qDp\u0012\"Pu\u001e\u0004";
        objectArray[34] = "#3\t[,9V\u0013\u0002T=v7\u001d\t_9,C";
        objectArray[35] = Integer.TYPE;
        JumpCircles.S[35] = "java/lang/Integer";
        objectArray[36] = "b\u000e\t,+,o\u000e\t,/";
        objectArray[37] = "WU\u0002X0wWU\u0015\u0004<xM\u001e\u0015\u001a<mJoBCe&";
        objectArray[38] = "d\u0003'nIFf\u001dn\rB]y\u00188tE";
        objectArray[39] = "\u000b\u0005<w2~\u000b\u0005++>q\u0011N+5>d\u0016?y`m&";
        objectArray[40] = "k|\tf\u0017\r\u001e\\\u0002i\u0006B\u007fR\tb\u0002\u0018\u000b";
        objectArray[41] = "c\u0001tS\u0018%\u0016!\u007f\\\tjw/tW\r0\u0003";
        objectArray[42] = ")G\u001a@%r\\g\u0011O4==i\u001aD0gI";
        objectArray[43] = "?\r\u007fG9qJ-tH(>+#\u007fC,d_";
        objectArray[44] = "\u0011\u0016c;:\u001cd6h4+S\u00058c?/\tq";
        objectArray[45] = "]AbJ\u00124(aiE\u0003{IobN\u0007!=";
        objectArray[46] = "*s~[\u001c:_SuT\ru>]~_\t/J";
        objectArray[47] = "L:\u0002x_\u00119\u001a\twN^X\u0014\u0002|J\u0004,";
        objectArray[48] = "q+";
        objectArray[49] = "\u0010\u000fn5\u000e\u0018\u001b\u000ff";
        objectArray[50] = "\u0003 ";
        objectArray[51] = "bsF[\n5\u0017SMT\u001bzv]F_\u001f \u0002";
        objectArray[52] = "gjTl<d\u0012J_c-+sDTh)q\u0007";
        objectArray[53] = "9-`\nu/2-d\nuj";
        objectArray[54] = "\u000bs@\u000b\u007fq\u0002}CB<|\u0004}W@!zFlDUwr\u0001rH\u000b@{\u0006xHWBw\u0018yAL|{";
        objectArray[55] = "\u001eh; \f,kH0/\u001dc\nF;$\u00199~";
        objectArray[56] = "f\u0016cy(.o\u0018`0k#i\u0018t2v%+\u001b{1#$w\n \u001054G\fh1 3";
        objectArray[57] = "p\u0012\u0000P`a}\u0012\u0000P`";
        objectArray[58] = "*\u0006`o\n\u0013)\b8L]\t%%chB\u00182";
        objectArray[59] = "pD$I&KyJ'\u0000eF\u007fJ3\u0002x@=_,\u001f?QaN:I\fTf\u007f,\u001f?QaN\u001f\u000e.S";
        objectArray[60] = "1V&O\u0011'<V&O\u0012";
        objectArray[61] = "b<qq:\fb<f-6\u0003xwf36\u0016\u007f\u00064mfV;";
        objectArray[62] = "5UC\u001dYi@uH\u0012H&!{C\u0019L|U";
        objectArray[63] = "Z;i\u0019+\u0007Z;~E'\b@p~['\u001dG\u0001/\u0000p";
        objectArray[64] = "K\u0011\fE4\u000fT\u001e\u0010Z\f\u0002&ROC3\u0004Y\u000eIN=";
        objectArray[65] = "\fjL!:.SzUvVu33\t%;hNjJ0;.36J+fsM7\t?n\u0013";
        objectArray[66] = "N\u0000kB#e\u0011\u0010r\u0015O3qY.F\"#\f\u0000mS\"eq\\mH\u007f8\u000f].\\wX";
        objectArray[67] = "\u00181\f.r_Ig\u000f?\u000e98\u001c\u007f@o\bE4L|>^F%";
        objectArray[68] = "x~t,&W'nm{J\u0013Grh-,\u0016{l6r&";
        objectArray[69] = "I~N\u0006M\u001c\u0016nWQ!\\v!SV\u001dGHdM\u0003^";
        objectArray[70] = "}=cV4\r\"|>Rf0-\u0006\u007fW1Z<at\f:0};9V T }n\n/0";
        objectArray[71] = "YD\u0018!\u001d\u000f\u0007\u0019V!l[h\u001eYt\u0001I\u0015G\u001aa\u0001\u000fh\u0016\u0005`SCUHX.S2";
        objectArray[72] = "4J[\u0002W>j\u0017\u0015\u0002&j\u0005\u0018W@\u001d3k\u0010\u0019P@\u0003";
        objectArray[73] = "d\u001f0<4\u0000;^m8f=4$o>0@gB)j,\u0001%$";
        objectArray[74] = "km1;E\u00134}(l)lTa-:ORh\u007fseE";
        objectArray[75] = "J[\u0013Wd\u0001CM\u001fP\u000f\u0012 VS\bf\u0016K\u0018UWfx\u001c[J^o\u0006\u001d\u0018^V\u000f";
        objectArray[76] = "\u0005(P\u0017I\u0017G<W\u00013E<`\u000f\bZ^\u0001`\u000bUH/";
        objectArray[77] = "[`V|\u0007\u000eRvZ{l\u001e1w\t!\u001e\u0019Pd\u001au\u000e";
        objectArray[78] = "G`\u0004#Q \u00166\u00072-WbBc\u0016lW&jSqC`\u001a;\u0005rR";
        objectArray[79] = "\fg/?a\u0019\u001f27%Z\u000ftal93\u0017Iahd!f\u000ef?3\"\u0001\u0005=4Y6\u0000\u001b=/e(^D7S5<\t\u0012'o+bV\u0018[)ff\b\b4h`+\u0016t";
        objectArray[80] = "M<n\t\u00164\u000b\u007fbHhbwyj\u001fV`\f9;\b\u0016\u000bK>oC\buJ}{Kh";
        objectArray[81] = "B`4RB\u007f\u001dp-\u0005.+}9qVC9\u0000`2CC\u007f}g/NV-\u0017l6E\u0014B";
        objectArray[82] = "%,<U\u0015+z<%\u0002yg\u001a.%G\u000bl$>{U\u001b";
        objectArray[83] = ";v~\u001bkGdfgL\u0007\u0016\u0004/;\u001fj\u0001yvx\njG\u0004*x\u00117\u001az+;\u0005?z";
        objectArray[84] = "\"\u0019R\r\u0013^}\tKZ\u007f/\u001d\u001bK\u001f\r\u0019#\u000b\u0015\r\u001d";
        objectArray[85] = "A]r\u0017p\u0002HK~\u0010\u001b\u0011+P2Hr\u0015@\u001e4\u0017r{";
        objectArray[86] = "\u001d\u00003_],]\u0017.M#. O5_Y#A\u001e1\b[G";
        objectArray[87] = "]4\u001a\t,W\u0002$\u0003^@ b6\u0003\u001b2\u0010\\&]\t\"";
        objectArray[88] = "\u0006?\bhvq\u00190\u0014wN}k|Knqz\u0014 Mc\u007f";
        objectArray[89] = "$\\0k\fG{L)<`\u0010\u001b\u0005uo\r\u0001f\\6z\rG\u001b\\wz]\u001cx\u0006!t^z";
        objectArray[90] = "MY\u001bp\u001bi\u0012I\u0002'w=r\u0000^t\u001a/\u000fY\u001da\u001airY\\aJ2\u0011\u0003\noIT";
        objectArray[91] = "D\u0006o&\u000e\u000e\u001b\u0016vqbI{_*\"\u000fH\u0006\u0006i7\u000f\u000e{Zi,RS\u0005[*8Z3";
        objectArray[92] = "&A5p:\u0019yQ,'Ve\u0019\u0011+$l\u001a}K)y&";
        objectArray[93] = "}\n\u0017\tG\u0015\"\u001a\u000e^+gBW\u001c\u0005DV)\u0017\u000b\u0018V";
        objectArray[94] = "8r}j\u0011W'}au)_Ul8p\u0014W66n~\u0017";
        objectArray[95] = ")PU\u0007\u0001\u0014v@LPmB\u0016\t\u0010\u0003\u0000RkPS\u0016\u0000\u0014\u0016P\u0012\u0016POu\nD\u0018S)";
        objectArray[96] = "-DMj)\u0005|\u0012N{Uv\bf*_UX'\u0013\u001fxi\tq\u0010\u000e";
        objectArray[97] = "mr\u001apPc+1\u00161.=W5@`C'*l\u0003uCaW0\u0003n\u001e<)1@z\u0016\\";
        objectArray[98] = "\u001fa\u00020 l@ _4rQOZ]3.+\u001b!_p (ZZ";
        objectArray[99] = "\bU\u007f\u000fk\u0007WEfX\u0007H7\bt\u0003hD\\Hc\u001ez";
        objectArray[100] = "h>\u0017\u0007W\u001f7.\u000eP;lWa\nW\u0007Di$\u0014\u0002D";
        objectArray[101] = "m~\u000f/gU2n\u0016x\u000b\u0005R'J+f\u0013/~\t>fUR\"\t%;\b,#J13h";
        objectArray[102] = "5\u0006rSk)sE~\u0012\u0015|\u000fDkM%vqE(Y-\u0016";
        objectArray[103] = "3'p\n0\u0017ge \u00170-c\u001epA?\u0013o/4\u00160D6";
        objectArray[104] = "Lme]~$\u0018/5@~\u001e\u001cTe\u0010ds\u000e)<SqsHTe\u00144t\u00157?\u001ect\rT";
        objectArray[105] = "UIXp{h\n\b\u0005t)U\u0005r\u0007pk0\u0007\u000bB%l;\rrDq~?\u0014\u0015O*uU\u000b\u0013L4}?\u0000\nGv\u0012lP\u000b['k)\u0005\fP-\u0012";
        objectArray[106] = "j.Yya\u001c>-N@m =lG\u007fj_ajJq";
        objectArray[107] = "y.m^=J&>t\tQ\bFqp\u000em\u0011x4n[.";
        objectArray[108] = "znJu\u001fW%~S\"s\rE7\u000fq\u001e\u00118nLd\u001eWE2L\u007fC\n;3\u000fkKj";
        objectArray[109] = "GPq'tcX_m8Li*T4.&}M_o%";
        objectArray[110] = ",{\u0018*\u0014ksk\u0001}x?\u0013\"].\u0015-n{\u001e;\u0015k\u0013b\\;\u0002**x\u0000;\u0005V";
        objectArray[111] = "ya\u0018\\XK&q\u0001\u000b4\u000fF8]XY\r;a\u001eMYKF=\u001eV\u0004\u00168<]B\fv";
        objectArray[112] = "Hi'5cc\u0017y>b\u000f&wf6+n Hb&=2";
        objectArray[113] = "a@}\u007f.gg\u0006 |=\u00021~=8 h \u00196c+\u0002aB>`'{$\u00179k-\u0002";
        objectArray[114] = "\u007fD}\u0010\u0017, TdG{x@\u001d8\u0014\u0016j=D{\u0001\u0016,@\u0018{\u001aKq>\u00198\u000eC\u0011";
        objectArray[115] = "F\u000bD%A5Y\u0004X:y>+\u0015\u0001?D5HOW1G";
        objectArray[116] = "{\u0012,Uk]d\u001d0JSR\u0016QoSlVi\ri^b";
        objectArray[117] = "8N\u00192\f,lM\u000e\u000b\u0001\u0010o\f\u00074\u0007o3\n\n:";
        objectArray[118] = "nP\u001ch;G1@\u0005?W\u0013QZ\u001ei*F.Z\u0001x3z;H\t{k\u0005;W\u0018bW";
        objectArray[119] = "5RD\u0000\u000eQjB]Wb\u0012\n\rYP^\n4HG\u0005\u001d";
        objectArray[120] = ":7\u001bM<U<qFN/0j\tFV,HlcMO'\n\u0003n@E&_ieYNd0dhSO1ZoqX\r^\t83KW=S2dKO^";
        objectArray[121] = "\rOgBd|YLp{n@\u001d\u000bv\u0011z'\u0016P}";
        objectArray[122] = "~\"'b5{!2>5Y\u000fA >p+<\u007f0`b;";
        objectArray[123] = "H(vibmTntl_[tWSO\u0005\u0001H(vibmTntl";
        objectArray[124] = "\u0002\bh\\IN]\u0018q\u000b%8=\nqNW\t\u0003\u001a/\\G";
        objectArray[125] = "d\u001bTFh\u0010;\u000bM\u0011\u0004`[\u0019MTvWe\t\u0013Ff";
        objectArray[126] = "\u000bX8/Wm_[/\u0016XQ\\\u001a&)\\.\u0000\u001c+'";
        objectArray[127] = "\u001ar+\u000eg\\\u0013d'\t\fIpbpXjYL|.\u0007`%";
        objectArray[128] = "$\u0004Rwe`{\u0014K \t%\u001b]\u0017sd&f\u0004Tfd`\u001bXT}9=eY\u0017i1]";
        objectArray[129] = "{.R\u001b:^$>KLV\rDw\u0017\u001f;\u00189.T\n;^DrT\u0011f\u0003:s\u0017\u0005nc";
        objectArray[130] = "K>\u00035\u007fBMx^6l'\u001b\u0000CrqM\ngH)z'N|]\u007f}YO?Iw\u001d";
        objectArray[131] = "~%&%}M!5?r\u00110Au8q+N%/:,a";
        objectArray[132] = ":PuS0\u000be@l\u0004\\M\u0005\u000fh\u0003`P;JvV#";
        objectArray[133] = "(2M\u0017|\u0013w\"T@\u0010^\u0017oF\u001b\u007fP|/Q\u0006m";
        objectArray[134] = ")%\u0016~8\u0019v5\u000f)T^\u0016!\u0011*j@j}\u0014v/";
        objectArray[135] = "5Yj\u0010P\u000bjIsG<J\n\u0006w@\u0000P4Ci\u0015C";
        objectArray[136] = "m[\u0017\u001d)P2K\u000eJE\u0007R\u0002R\u0019(\u0016/[\u0011\f(PR\u0007\u0011\u0017u\r,\u0006R\u0003}m";
        objectArray[137] = "w\u0017\b\u0018,\\#UX\u0005,f$.\bTf\u001c,K\u000e\u0012;\u001f?";
        objectArray[138] = "u\u0003c|/ufV{f\u0014`\rF!env4\\}ei\nt@ma~;1\u0001g#\u0014j0@\"|w0fN!\u001at7r\u0002yy.a|\u0001\u001fz)u0Y| \u007f{3?\u007f'k7k\\%qe4\r_\"e)ln\u0005tk*\nj^mb{`aGf \u00146q[/zj72O'\u001a";
        objectArray[139] = ":I6\u0003)7eY/TEo\u0005\u0010s\u0007(qxI0\u0012(7\u0005\u00150\tuj{\u0014s\u001d}\n";
        objectArray[140] = "\u000b<|@J\u0010\u0002*pG!\ray~\u0013L\u0012\u001c =\u0006LTa|=\u001d\u0011\t\u001f}~\t\u0019i";
        Object[] objectArray2 = objectArray;
        objectArray[141] = "*d_} jva\u00038D|N Z))m3y\u0019<)+Nu\u0003,\"jrk]s(\u0016";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = JumpCircles.e(l2, l3);
            object = R[n2];
            try {
                if (!(object instanceof String)) break block2;
                JumpCircles.R[n2] = clazz = Class.forName(S[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = JumpCircles.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = JumpCircles.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = JumpCircles.e(l2, l3);
        Object object = R[n2];
        if (object instanceof String) {
            String string = S[n2];
            int n3 = string.indexOf(8);
            Class clazz = JumpCircles.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = JumpCircles.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = JumpCircles.c(clazz3, string2, clazz2)) != null) {
                    JumpCircles.R[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = JumpCircles.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        JumpCircles.R[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = JumpCircles.f(1015136421022607L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = JumpCircles.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = JumpCircles.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = JumpCircles.e(l2, l3);
        Object object = R[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = S[n2];
                int n4 = string2.indexOf(8);
                clazz3 = JumpCircles.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = JumpCircles.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = JumpCircles.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        JumpCircles.R[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = JumpCircles.f(1015136421022607L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = JumpCircles.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        JumpCircles.R[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = JumpCircles.f(1015136421022607L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == '\u00ff' || c2 == '\u00e5' || c2 == '\u00ca' || c2 == '\u00e2') {
                field = JumpCircles.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == '\u00ff' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == '\u00e5' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == '\u00ca' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = JumpCircles.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == '\u00d6' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == '\u00f8' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = JumpCircles.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/e/S" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(JumpCircles.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(JumpCircles.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

