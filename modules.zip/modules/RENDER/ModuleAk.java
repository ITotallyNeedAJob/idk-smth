// === Kuzi module: ModuleAk ===
// Category   : RENDER
// Description: 
// Payload    : a.a.a.j.g.ak (verified: False)

package kuzi.modules.render;

import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.b.e;
import kuzi.obf.h.b.v;
import kuzi.obf.j.g.aA;
import kuzi.obf.j.g.aD;
import kuzi.obf.m.r;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.ChunkPos;
import net.minecraft.BlockPos;
import net.minecraft.AABB;
import net.minecraft.Vec3;
import net.minecraft.BlockEntity;
import net.minecraft.BrewingStandBlockEntity;
import net.minecraft.ChestBlockEntity;
import net.minecraft.DispenserBlockEntity;
import net.minecraft.AbstractFurnaceBlockEntity;
import net.minecraft.EnderChestBlockEntity;
import net.minecraft.HopperBlockEntity;
import net.minecraft.ShulkerBoxBlockEntity;
import net.minecraft.SpawnerBlockEntity;
import net.minecraft.TrappedChestBlockEntity;
import net.minecraft.LevelChunk;
import net.minecraft.BarrelBlockEntity;
import net.minecraft.ClientLevel;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class ModuleAk
extends BaseModule
implements WorldRenderEvents.AfterEntities {
    private static final int m;
    private static final int n;
    private final SliderSetting range;
    private final BoolSetting showTrappedChest;
    private final BoolSetting showEnderChest;
    private final BoolSetting showShulkerBox;
    private final BoolSetting showBarrel;
    private final BoolSetting showDispenser;
    private final BoolSetting showHopper;
    private final BoolSetting showSpawner;
    private final BoolSetting showFurnace;
    private final e chestColor;
    private final e trappedChestColor;
    private final e enderChestColor;
    private final e shulkerColor;
    private final e barrelColor;
    private final e otherColor;
    private final BoolSetting D;
    private final BoolSetting E;
    private final SliderSetting F;
    private final BoolSetting G;
    private final SliderSetting H;
    private final SliderSetting I;
    private static final long J;
    private final List boxes;
    private long L;
    private long M;
    private static final long N;
    private static final String[] O;
    private static final String[] P;
    private static final Map Q;
    private static final long[] R;
    private static final Integer[] S;
    private static final Map T;
    private static final long[] U;
    private static final Long[] V;
    private static final Map W;
    private static final Object[] X;
    private static final String[] Y;

    public ModuleAk() {
        long l2 = N ^ 0x1D6318298EF6L;
        long l3 = l2 ^ 0x39E70E2FFA53L;
        super((String)((Object)ModuleAk.b("k", (int)13046, (long)(0x36E7B7FD6DA967F2L ^ l2))), (String)((Object)ModuleAk.b("k", (int)2262, (long)(0x390D8E9A79E75DDCL ^ l2))), Category.WORLD);
        this.range = new SliderSetting((String)((Object)ModuleAk.b("k", (int)1537, (long)(0x678D08F47C5CD303L ^ l2))), 64.0, 8.0, 256.0, 1.0);
        this.showTrappedChest = new BoolSetting((String)((Object)ModuleAk.b("k", (int)20018, (long)(0x12B1C953072B1B37L ^ l2))), true);
        this.showEnderChest = new BoolSetting((String)((Object)ModuleAk.b("k", (int)17156, (long)(0x38E12EA934999602L ^ l2))), true);
        this.showShulkerBox = new BoolSetting((String)((Object)ModuleAk.b("k", (int)18611, (long)(0x7F72985FBDAF1DBFL ^ l2))), true);
        this.showBarrel = new BoolSetting((String)((Object)ModuleAk.b("k", (int)9230, (long)(0x5770621CD0787106L ^ l2))), true);
        this.showDispenser = new BoolSetting((String)((Object)ModuleAk.b("k", (int)22028, (long)(0x4B3BA94E08E98316L ^ l2))), false);
        this.showHopper = new BoolSetting((String)((Object)ModuleAk.b("k", (int)32037, (long)(0x7E9C878909072826L ^ l2))), false);
        this.showSpawner = new BoolSetting((String)((Object)ModuleAk.b("k", (int)1610, (long)(0x4CA71DAC1050D355L ^ l2))), true);
        this.showFurnace = new BoolSetting((String)((Object)ModuleAk.b("k", (int)15483, (long)(0xBE0F180F4BE6970L ^ l2))), true);
        this.chestColor = new e((String)((Object)ModuleAk.b("k", (int)9482, (long)(0x7B7256FABA32700AL ^ l2))), new Color((int)ModuleAk.c("d", (int)26983, (long)(0x7A1A3F2334142949L ^ l2)), (int)ModuleAk.c("d", (int)14962, (long)(0x1186341E4D72FA6EL ^ l2)), 0));
        this.trappedChestColor = new e((String)((Object)ModuleAk.b("k", (int)18348, (long)(0x189C55E2E5CD92B4L ^ l2))), new Color((int)ModuleAk.c("d", (int)26983, (long)(0x7A1A3F2334142949L ^ l2)), (int)ModuleAk.c("d", (int)29685, (long)(0x1CEA0E04190833E7L ^ l2)), (int)ModuleAk.c("d", (int)4672, (long)(0x420D345C4EADD24FL ^ l2))));
        this.enderChestColor = new e((String)((Object)ModuleAk.b("k", (int)8217, (long)(0x50D4208C2E477518L ^ l2))), new Color((int)ModuleAk.c("d", (int)6434, (long)(0x7C202E174AB45929L ^ l2)), 0, (int)ModuleAk.c("d", (int)26983, (long)(0x7A1A3F2334142949L ^ l2))));
        this.shulkerColor = new e((String)((Object)ModuleAk.b("k", (int)13267, (long)(0x223EFA28F01866CDL ^ l2))), new Color((int)ModuleAk.c("d", (int)29048, (long)(0x7CC683015D76317EL ^ l2)), (int)ModuleAk.c("d", (int)1122, (long)(0x3FFF70DE5681C462L ^ l2)), (int)ModuleAk.c("d", (int)26983, (long)(0x7A1A3F2334142949L ^ l2))));
        this.barrelColor = new e((String)((Object)ModuleAk.b("k", (int)17194, (long)(0x7540B790801B9623L ^ l2))), new Color((int)ModuleAk.c("d", (int)722, (long)(0x50E65750442E42C2L ^ l2)), (int)ModuleAk.c("d", (int)29414, (long)(0x70ABAD883FA932E5L ^ l2)), (int)ModuleAk.c("d", (int)12077, (long)(0x7BA3CE466EE3EF35L ^ l2))));
        this.otherColor = new e((String)((Object)ModuleAk.b("k", (int)3024, (long)(0x7046144F09455EDFL ^ l2))), new Color((int)ModuleAk.c("d", (int)12514, (long)(0xD149508E09EF0E6L ^ l2)), (int)ModuleAk.c("d", (int)12514, (long)(0xD149508E09EF0E6L ^ l2)), (int)ModuleAk.c("d", (int)12514, (long)(0xD149508E09EF0E6L ^ l2))));
        this.D = new BoolSetting((String)((Object)ModuleAk.b("k", (int)6479, (long)(0x2F3A97A0EF68CC56L ^ l2))), true);
        this.E = new BoolSetting((String)((Object)ModuleAk.b("k", (int)2837, (long)(0x2D9DBEA9FDCCDE1BL ^ l2))), true);
        this.F = new SliderSetting((String)((Object)ModuleAk.b("k", (int)26984, (long)(0x681E1154E6EC3C75L ^ l2))), 60.0, 0.0, 255.0, 5.0);
        this.G = new BoolSetting((String)((Object)ModuleAk.b("k", (int)7314, (long)(0x50561A223FE4995L ^ l2))), false);
        this.H = new SliderSetting((String)((Object)ModuleAk.b("k", (int)8516, (long)(0x750D7F5179127449L ^ l2))), 1.0, 0.25, 10.0, 0.25);
        this.I = new SliderSetting((String)((Object)ModuleAk.b("k", (int)24635, (long)(0x784B48C18BF83527L ^ l2))), 255.0, 0.0, 255.0, 5.0);
        this.boxes = new ArrayList();
        this.L = (long)ModuleAk.d("j", (int)2542, (long)(0x717D8CF5BA74952FL ^ l2));
        this.M = (long)ModuleAk.d("j", (int)17473, (long)(0x11FFA42843D4D881L ^ l2));
        Setting[] settingArray = new Setting[ModuleAk.c("d", (int)21256, (long)(0x606CA2884620131EL ^ l2))];
        settingArray[0] = this.range;
        settingArray[1] = this.showTrappedChest;
        settingArray[2] = this.showEnderChest;
        settingArray[3] = this.showShulkerBox;
        settingArray[4] = this.showBarrel;
        settingArray[5] = this.showDispenser;
        settingArray[ModuleAk.c("d", (int)11235, (long)(0x7030BD50D6C46BFCL ^ l2))] = this.showHopper;
        settingArray[ModuleAk.c("d", (int)1781, (long)(0x55673F4222E346EEL ^ l2))] = this.showSpawner;
        settingArray[ModuleAk.c("d", (int)6135, (long)(0x235CCA07E50057FDL ^ l2))] = this.showFurnace;
        settingArray[ModuleAk.c("d", (int)14294, (long)(0x333296F0448377CBL ^ l2))] = this.chestColor;
        settingArray[ModuleAk.c("d", (int)12769, (long)(0x733F8C5F1C5C71FFL ^ l2))] = this.trappedChestColor;
        settingArray[ModuleAk.c("d", (int)25536, (long)(0x7541EF4C65E923D4L ^ l2))] = this.enderChestColor;
        settingArray[ModuleAk.c("d", (int)252, (long)(0x6AB284AC2A67C0EDL ^ l2))] = this.shulkerColor;
        settingArray[ModuleAk.c("d", (int)649, (long)(0x513E2BDB2BAC287L ^ l2))] = this.barrelColor;
        settingArray[ModuleAk.c("d", (int)14061, (long)(0x47A96D704FE0F6C0L ^ l2))] = this.otherColor;
        settingArray[ModuleAk.c("d", (int)18287, (long)(0x48652C04E22F0743L ^ l2))] = this.D;
        settingArray[ModuleAk.c("d", (int)30554, (long)(0x617078F5ADF83771L ^ l2))] = this.E;
        settingArray[ModuleAk.c("d", (int)15231, (long)(0x7194F5ED7FEAFB65L ^ l2))] = this.F;
        settingArray[ModuleAk.c("d", (int)1886, (long)(0x536B8F5DE9C34759L ^ l2))] = this.G;
        settingArray[ModuleAk.c("d", (int)16251, (long)(0x1EE4FFE5C964FF54L ^ l2))] = this.H;
        settingArray[ModuleAk.c("d", (int)14386, (long)(0x5FD31449D9B2783EL ^ l2))] = this.I;
        Object[] objectArray = new Object[2];
        objectArray[1] = settingArray;
        objectArray[0] = l3;
        this.l(objectArray);
        WorldRenderEvents.END_MAIN.register(this::afterEntities);
    }

    @Override
    public void d() {
        long l2 = N ^ 0x6EEAA10D487DL;
        Client.a();
        this.boxes.clear();
        this.L = (long)ModuleAk.d("j", (int)17473, (long)(0x11FFD7A1FAF01E0AL ^ l2));
        this.M = (long)ModuleAk.d("j", (int)17473, (long)(0x11FFD7A1FAF01E0AL ^ l2));
    }

    /*
     * Exception decompiling
     */
    public void afterEntities(WorldRenderContext var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Statement already marked as first in another block
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.markFirstStatementInBlock(Op03SimpleStatement.java:461)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc.markWholeBlock(Misc.java:251)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.considerAsSimpleIf(ConditionalRewriter.java:673)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.identifyNonjumpingConditionals(ConditionalRewriter.java:56)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:722)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private void a(Object[] objectArray) {
        block18: {
            List list;
            block20: {
                ModuleAk moduleAk;
                int[] nArray;
                int n2;
                int n3;
                int n4;
                long l2;
                block19: {
                    int n5;
                    int n6;
                    int[][] nArray2;
                    double d2;
                    int n7;
                    int n8;
                    int n9;
                    long l3;
                    Vec3 playerPos;
                    ClientLevel level;
                    block15: {
                        level = (ClientLevel)objectArray[0];
                        playerPos = (Vec3)objectArray[1];
                        l2 = (Long)objectArray[2];
                        ChunkPos chunkPos = (ChunkPos)objectArray[3];
                        long l4 = l2 = N ^ l2;
                        l3 = l4 ^ 0x154AE3D4219CL;
                        long l5 = l4 ^ 0x66300730900CL;
                        n9 = (int)(l5 >>> 32);
                        n8 = (int)(l5 << 32 >>> 48);
                        n7 = (int)(l5 << 48 >>> 48);
                        long l6 = l4 ^ 0x1A7561E3A53BL;
                        n4 = (int)(l6 >>> 48);
                        n3 = (int)(l6 << 16 >>> 48);
                        n2 = (int)(l6 << 32 >>> 32);
                        this.boxes.clear();
                        double d3 = (Double)this.range.a();
                        d2 = d3 * d3;
                        int n10 = (int)Math.ceil(d3 / 16.0) + 1;
                        nArray = aD.b();
                        int n11 = 2 * n10 + 1;
                        nArray2 = new int[n11 * n11][3];
                        int n12 = 0;
                        int n13 = chunkPos.x - n10;
                        while (n13 <= chunkPos.x + n10) {
                            int[] nArray3;
                            block16: {
                                block17: {
                                    if (nArray == null) break block15;
                                    n6 = chunkPos.z - n10;
                                    block1: while (n6 <= chunkPos.z + n10) {
                                        n5 = n13 - chunkPos.x;
                                        int n14 = n6 - chunkPos.z;
                                        nArray2[n12][0] = n13;
                                        nArray2[n12][1] = n6++;
                                        nArray2[n12][2] = n5 * n5 + n14 * n14;
                                        ++n12;
                                        do {
                                            nArray3 = nArray;
                                            if (l2 <= 0L) break block16;
                                            if (nArray3 == null) break block17;
                                            if (nArray != null) continue block1;
                                        } while (l2 < 0L);
                                    }
                                    ++n13;
                                }
                                nArray3 = nArray;
                            }
                            if (nArray3 != null) continue;
                        }
                        Arrays.sort(nArray2, Comparator.comparingInt(ModuleAk::lambda$rebuildCache$0));
                        if (l2 > 0L) {
                            // empty if block
                        }
                    }
                    int[][] nArray4 = nArray2;
                    n6 = nArray4.length;
                    n5 = 0;
                    block3: while (true) {
                        int n15 = n5;
                        Object object = n6;
                        block4: while (n15 < object) {
                            int[] nArray5;
                            int[] nArray6 = nArray4[n5];
                            LevelChunk chunk = level.getChunkSource().getChunk(nArray6[0], nArray6[1], false);
                            if (nArray == null) break block18;
                            if (chunk != null) {
                                for (BlockEntity blockEntity : new ArrayList(chunk.getBlockEntities().values())) {
                                    moduleAk = this;
                                    if (l2 > 0L) {
                                        BlockPos blockPos;
                                        double d4;
                                        ModuleAk moduleAk2;
                                        if (nArray != null) {
                                            n15 = moduleAk.boxes.size();
                                            object = ModuleAk.c("d", (int)2242, (long)(0x739276A9CFB9928BL ^ l2));
                                            if (nArray == null || l2 < 0L) continue block4;
                                            if (n15 >= object) break block3;
                                            moduleAk2 = this;
                                        }
                                        Object[] objectArray2 = new Object[2];
                                        objectArray2[1] = blockEntity;
                                        objectArray2[0] = l3;
                                        Color color = moduleAk2.a(objectArray2);
                                        if (color == null || (d4 = playerPos.distanceToSqr((double)(blockPos = blockEntity.getBlockPos()).getX() + 0.5, (double)blockPos.getY() + 0.5, (double)blockPos.getZ() + 0.5)) > d2) continue;
                                        Object[] objectArray3 = new Object[6];
                                        objectArray3[5] = (int)((short)n7);
                                        objectArray3[4] = blockPos;
                                        objectArray3[3] = (int)((char)n8);
                                        objectArray3[2] = level;
                                        objectArray3[1] = n9;
                                        objectArray3[0] = blockEntity;
                                        AABB box = this.a(objectArray3);
                                        this.boxes.add(new aA(box.minX, box.minY, box.minZ, box.maxX, box.maxY, box.maxZ, color.getRGB() & ModuleAk.c("d", (int)8413, (long)(0x7AD5AC57D96A3A90L ^ l2)), d4));
                                        nArray5 = nArray;
                                        if (l2 <= 0L) continue block3;
                                        if (nArray5 != null) continue;
                                    }
                                    break block19;
                                }
                            }
                            ++n5;
                            nArray5 = nArray;
                            if (nArray5 != null) continue block3;
                        }
                        break;
                    }
                    if (l2 <= 0L) break block18;
                    moduleAk = this;
                }
                list = moduleAk.boxes;
                if (nArray == null) break block20;
                if (list.size() <= ModuleAk.c("d", (int)28580, (long)(0x3BD74D7BA90CF5F6L ^ l2))) break block18;
                this.boxes.sort(Comparator.comparingDouble(arg_0 -> ModuleAk.lambda$rebuildCache$1((char)n4, (char)n3, n2, arg_0)));
                list = this.boxes.subList((int)ModuleAk.c("d", (int)11917, (long)(0x208E874B3D5E34C2L ^ l2)), this.boxes.size());
            }
            list.clear();
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private Color a(Object[] objectArray) {
        ModuleAk moduleAk;
        block36: {
            boolean bl;
            block34: {
                int[] nArray;
                block35: {
                    long l2 = (Long)objectArray[0];
                    BlockEntity blockEntity = (BlockEntity)objectArray[1];
                    l2 = N ^ l2;
                    nArray = aD.b();
                    bl = blockEntity instanceof TrappedChestBlockEntity;
                    if (nArray != null) {
                        if (bl) {
                            ModuleAk moduleAk2 = this;
                            if (nArray != null) {
                                if ((Boolean)moduleAk2.showTrappedChest.a() == false) return null;
                                moduleAk2 = this;
                            }
                            Color color = moduleAk2.trappedChestColor.a();
                            return color;
                        }
                        bl = blockEntity instanceof ChestBlockEntity;
                    }
                    int[] nArray2 = nArray;
                    if (l2 > 0L) {
                        if (nArray2 != null) {
                            if (bl) {
                                ModuleAk moduleAk3 = this;
                                if (nArray != null) {
                                    if ((Boolean)moduleAk3.showTrappedChest.a() == false) return null;
                                    moduleAk3 = this;
                                }
                                Color color = moduleAk3.chestColor.a();
                                return color;
                            }
                            bl = blockEntity instanceof EnderChestBlockEntity;
                        }
                        nArray2 = nArray;
                    }
                    if (l2 >= 0L) {
                        if (nArray2 != null) {
                            if (bl) {
                                ModuleAk moduleAk4 = this;
                                if (nArray != null) {
                                    if ((Boolean)moduleAk4.showEnderChest.a() == false) return null;
                                    moduleAk4 = this;
                                }
                                Color color = moduleAk4.enderChestColor.a();
                                return color;
                            }
                            bl = blockEntity instanceof ShulkerBoxBlockEntity;
                        }
                        nArray2 = nArray;
                    }
                    if (l2 > 0L) {
                        if (nArray2 != null) {
                            if (bl) {
                                ModuleAk moduleAk5 = this;
                                if (nArray != null) {
                                    if ((Boolean)moduleAk5.showShulkerBox.a() == false) return null;
                                    moduleAk5 = this;
                                }
                                Color color = moduleAk5.shulkerColor.a();
                                return color;
                            }
                            bl = blockEntity instanceof BarrelBlockEntity;
                        }
                        nArray2 = nArray;
                    }
                    if (l2 > 0L) {
                        if (nArray2 != null) {
                            if (bl) {
                                ModuleAk moduleAk6 = this;
                                if (nArray != null) {
                                    if ((Boolean)moduleAk6.showBarrel.a() == false) return null;
                                    moduleAk6 = this;
                                }
                                Color color = moduleAk6.barrelColor.a();
                                return color;
                            }
                            bl = blockEntity instanceof DispenserBlockEntity;
                        }
                        nArray2 = nArray;
                    }
                    if (l2 > 0L) {
                        if (nArray2 != null) {
                            if (bl) {
                                ModuleAk moduleAk7 = this;
                                if (nArray != null) {
                                    if ((Boolean)moduleAk7.showDispenser.a() == false) return null;
                                    moduleAk7 = this;
                                }
                                Color color = moduleAk7.otherColor.a();
                                return color;
                            }
                            bl = blockEntity instanceof HopperBlockEntity;
                        }
                        nArray2 = nArray;
                    }
                    if (l2 > 0L) {
                        if (nArray2 != null) {
                            if (bl) {
                                ModuleAk moduleAk8 = this;
                                if (nArray != null) {
                                    if ((Boolean)moduleAk8.showHopper.a() == false) return null;
                                    moduleAk8 = this;
                                }
                                Color color = moduleAk8.otherColor.a();
                                return color;
                            }
                            bl = blockEntity instanceof SpawnerBlockEntity;
                        }
                        nArray2 = nArray;
                    }
                    if (l2 > 0L) {
                        if (nArray2 != null) {
                            if (bl) {
                                ModuleAk moduleAk9 = this;
                                if (nArray != null) {
                                    if ((Boolean)moduleAk9.showSpawner.a() == false) return null;
                                    moduleAk9 = this;
                                }
                                Color color = moduleAk9.otherColor.a();
                                return color;
                            }
                            bl = blockEntity instanceof AbstractFurnaceBlockEntity;
                        }
                        nArray2 = nArray;
                    }
                    if (nArray2 == null) break block34;
                    if (bl) break block35;
                    bl = blockEntity instanceof BrewingStandBlockEntity;
                    if (nArray == null) break block34;
                    if (!bl) return null;
                }
                moduleAk = this;
                if (nArray == null) break block36;
                bl = (Boolean)moduleAk.showFurnace.a();
            }
            if (!bl) return null;
            moduleAk = this;
        }
        Color color = moduleAk.otherColor.a();
        return color;
    }

    private static int a(Object[] objectArray) {
        Object object;
        block10: {
            int n2;
            block11: {
                CallSite callSite;
                long l2;
                block8: {
                    block9: {
                        n2 = (Integer)objectArray[0];
                        l2 = (Long)objectArray[1];
                        l2 = N ^ l2;
                        callSite = ModuleAk.f("\u00de", (long)-1136113767145059671L, (long)l2);
                        try {
                            try {
                                object = n2;
                                if (callSite == null) break block8;
                                if (object >= 0) break block9;
                            }
                            catch (r r2) {
                                throw ModuleAk.f("\u00de", (Object)r2, (long)-1143205444947065425L, (long)l2);
                            }
                            object = 0;
                            break block10;
                        }
                        catch (r r3) {
                            throw ModuleAk.f("\u00de", (Object)r3, (long)-1143205444947065425L, (long)l2);
                        }
                    }
                    object = n2;
                }
                try {
                    try {
                        if (callSite == null) break block10;
                        if (object <= ModuleAk.c("d", (int)14121, (long)(0x136D6551FFBE644L ^ l2))) break block11;
                    }
                    catch (r r4) {
                        throw ModuleAk.f("\u00de", (Object)r4, (long)-1143205444947065425L, (long)l2);
                    }
                    object = ModuleAk.c("d", (int)26983, (long)(0x7A1A0A218ABDB825L ^ l2));
                    break block10;
                }
                catch (r r5) {
                    throw ModuleAk.f("\u00de", (Object)r5, (long)-1143205444947065425L, (long)l2);
                }
            }
            object = n2;
        }
        return object;
    }

    /*
     * Exception decompiling
     */
    private AABB a(Object[] var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [40[FORLOOP]], but top level block is 41[WHILELOOP]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:435)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:484)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private static double lambda$rebuildCache$1(char c2, char c3, int n2, aA aA2) {
        long l2 = ((long)c2 << 48 | (long)c3 << 48 >>> 16 | (long)n2 << 32 >>> 32) ^ N;
        return (double)ModuleAk.f("L", (Object)aA2, (long)-1037286977505135664L, (long)l2);
    }

    private static int lambda$rebuildCache$0(int[] nArray) {
        return nArray[2];
    }

    /*
     * Unable to fully structure code
     */
    static {
        block31: {
            block30: {
                block29: {
                    block28: {
                        block27: {
                            block26: {
                                ModuleAk.N = kuzi.obf.h.b.v.a(-5712883059496777387L, 5430550892121902586L, MethodHandles.lookup().lookupClass()).a(244341333191170L);
                                ModuleAk.X = new Object[83];
                                ModuleAk.Y = new String[83];
                                ModuleAk.c();
                                ModuleAk.Q = new HashMap<K, V>(13);
                                var22 = ModuleAk.N ^ 135010302492145L;
                                var24_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                                v0 = SecretKeyFactory.getInstance("DES");
                                v1 = new byte[8];
                                v2 = v1;
                                v1[0] = (byte)(var22 >>> 56);
                                for (var25_2 = 1; var25_2 < 8; ++var25_2) {
                                    v2 = v2;
                                    v2[var25_2] = (byte)(var22 << var25_2 * 8 >>> 56);
                                }
                                var24_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                                var31_3 = new String[23];
                                var29_4 = 0;
                                var28_5 = "\u00fc\u00a4\u0006iJ\u0016\u00f6\u00c6I\u00cb\u0014\u00ad\u00c67\u001eO->K\u00d8\u00c1|\u0082\u00b0\u00b8\u00d6\u0018\u0086p=\u00e6\"\u0018\u0090N\u0016Al\u00e84?\u00b8Q\u00b4\u00e0f\u00ad\u00e4\u0099#pm\u0002\u009d\u00a4\u00b5\u00f5\u0010'\u00dc:\u00a6\u009dt\u00a15\u00f5V\u001a\u0094\u00ab\u0013\u00feF\u0018\u00d5\u00fd\u00fc\u00e2\u00cc\u00b0.W5o\u00b0n\\\u00ed\u00fd\u00bc2h\u0012\u00fe\u0018]o\u00a2\u0010y\u00d9\u00df\u0097d\u00eaZ?\u00acl\u00ff\u00b8XF3\u001f\u0018Bk\b\u00bdw\u00f3\u00a6`\u00cf\u0084\u00b6\u00c5\u00cd\u00d7\u00f0\u0087\u00fb\u00d0}\u00cd)\u00f2d\u000f8\u00d1\u00b5=\u008al\u0096\u00db\u00f9\u00e8?\u00fe\u00aa\u00a0(S\u00e4\b\u00f9\u00b6l\u00f8\u00d2\u0086\u00d2q1\u0018g\u008d\u00ba7\u00e4\u0014#\u00dc\u008f@a\u00c6h\u00b1\u00d4\u00b3[\u00cca\u00f9\u00cc\u00d8<\u00e0!\u00ca\u00a8\u00fbt \u00c9\u0090g\u008e0\u0012\u00c4X}\b!\u00b78\u0089\u0015\u00fd/\u00c1\u00e6\u00ccL\u00c1\u00be\u00fe\u0091\u00b9Q3\u0000V\u00c0!\u0018\u00f8\u00bb\u008a1~\u00cc\u00b5\u00d1\u0013\u00a7\u0015\u00d3\u0005\u0014\u00cf?\u0088\fM]s\u00aa\u00d7\u001c\u0010\u00dc%\u00d2t6\u000br\u009b~u\u00a091\u009f$m\u0018eL\u001d\u0088e\u00f3\u00f6-\u00cf)\bs\u001c\u0002\u00a17D\u00c2\u00f0\u0090\u00d8\t\u00d7A\u0010\u00a5\u008c,`\u00cd\u00e9\u0093$L\u00b4\u00d8z\u00da^:c\u0018Q\u00e4\u0099\u008c\u0015Z\u008a\u00bb\u00acYn\u00f7\u000f(\u00c1-\u001b?\u0019\u0092\u00a4\u008b\u00c8\u00a4(\u008b\u00f6\u00e3\u00fd~\u0007\u00f1\u0097\u00d4a\u00ea\u00b1s\u0005\u00c2\u001e~\u0004\u00ef\u0013\u00daYa\u009b#}\u009b\u001aN\u0000aOX\u0004\u00bd\u00c9-.0]\u0010\u00f3\u00eds\u00d9a\u00c3\u00f2\u00bd:\\\u00d2\u00ca&\u00d4\u001d\u00dc\u0010.\u00149z\u00fd\u00bd,\u007f~>PcU\u00dd0\u0095\u0018&\u00b5?\u00fe\u0081\u00b0\u00cd\u00da\u00cbY\u00d7|\u00f4ic\u00ee\u00c0;\u0088'J\u00c5\u0098\u00d4 \u00e5%Ae\u0014\u00d8\u00b8r<X\u00bf\u00b2c\u001f\u00a38\u00d2\u00ec\u00ff\u008c\u00e4\u00f2\u00adKaU5gm\u009b\u0097\u00a8\u0018JQ\u00c9\u0097Q\u00be\u00ca9\u00fb\u0092\u00e5t\u00aa3INh[(\u00f7#\u00847\u00de |im\u00d0i\u0018\u0090m\u009f]\u00f4\u0098\u000b\u0099I\u0093=\u0010\u00c5L\u00a7\u00ee-\u00ad\u008dK\u00ef\u00c9\u00de\f\u00b3\u001c(_\u00ad\u00aa\u0092\u00a2\u0093\u00a68\u00ca\u00e5i\u00ae\u0014\u0001\u00f7H\u00d5\u0013\u00ff\u00e0C\u00ca\u00aa\u00e5\u0006\u0007b\u00b8\u00a6\u009a\u00a51\u0013\u00ea\u001c\u00ea\u00a3F2>";
                                var30_6 = "\u00fc\u00a4\u0006iJ\u0016\u00f6\u00c6I\u00cb\u0014\u00ad\u00c67\u001eO->K\u00d8\u00c1|\u0082\u00b0\u00b8\u00d6\u0018\u0086p=\u00e6\"\u0018\u0090N\u0016Al\u00e84?\u00b8Q\u00b4\u00e0f\u00ad\u00e4\u0099#pm\u0002\u009d\u00a4\u00b5\u00f5\u0010'\u00dc:\u00a6\u009dt\u00a15\u00f5V\u001a\u0094\u00ab\u0013\u00feF\u0018\u00d5\u00fd\u00fc\u00e2\u00cc\u00b0.W5o\u00b0n\\\u00ed\u00fd\u00bc2h\u0012\u00fe\u0018]o\u00a2\u0010y\u00d9\u00df\u0097d\u00eaZ?\u00acl\u00ff\u00b8XF3\u001f\u0018Bk\b\u00bdw\u00f3\u00a6`\u00cf\u0084\u00b6\u00c5\u00cd\u00d7\u00f0\u0087\u00fb\u00d0}\u00cd)\u00f2d\u000f8\u00d1\u00b5=\u008al\u0096\u00db\u00f9\u00e8?\u00fe\u00aa\u00a0(S\u00e4\b\u00f9\u00b6l\u00f8\u00d2\u0086\u00d2q1\u0018g\u008d\u00ba7\u00e4\u0014#\u00dc\u008f@a\u00c6h\u00b1\u00d4\u00b3[\u00cca\u00f9\u00cc\u00d8<\u00e0!\u00ca\u00a8\u00fbt \u00c9\u0090g\u008e0\u0012\u00c4X}\b!\u00b78\u0089\u0015\u00fd/\u00c1\u00e6\u00ccL\u00c1\u00be\u00fe\u0091\u00b9Q3\u0000V\u00c0!\u0018\u00f8\u00bb\u008a1~\u00cc\u00b5\u00d1\u0013\u00a7\u0015\u00d3\u0005\u0014\u00cf?\u0088\fM]s\u00aa\u00d7\u001c\u0010\u00dc%\u00d2t6\u000br\u009b~u\u00a091\u009f$m\u0018eL\u001d\u0088e\u00f3\u00f6-\u00cf)\bs\u001c\u0002\u00a17D\u00c2\u00f0\u0090\u00d8\t\u00d7A\u0010\u00a5\u008c,`\u00cd\u00e9\u0093$L\u00b4\u00d8z\u00da^:c\u0018Q\u00e4\u0099\u008c\u0015Z\u008a\u00bb\u00acYn\u00f7\u000f(\u00c1-\u001b?\u0019\u0092\u00a4\u008b\u00c8\u00a4(\u008b\u00f6\u00e3\u00fd~\u0007\u00f1\u0097\u00d4a\u00ea\u00b1s\u0005\u00c2\u001e~\u0004\u00ef\u0013\u00daYa\u009b#}\u009b\u001aN\u0000aOX\u0004\u00bd\u00c9-.0]\u0010\u00f3\u00eds\u00d9a\u00c3\u00f2\u00bd:\\\u00d2\u00ca&\u00d4\u001d\u00dc\u0010.\u00149z\u00fd\u00bd,\u007f~>PcU\u00dd0\u0095\u0018&\u00b5?\u00fe\u0081\u00b0\u00cd\u00da\u00cbY\u00d7|\u00f4ic\u00ee\u00c0;\u0088'J\u00c5\u0098\u00d4 \u00e5%Ae\u0014\u00d8\u00b8r<X\u00bf\u00b2c\u001f\u00a38\u00d2\u00ec\u00ff\u008c\u00e4\u00f2\u00adKaU5gm\u009b\u0097\u00a8\u0018JQ\u00c9\u0097Q\u00be\u00ca9\u00fb\u0092\u00e5t\u00aa3INh[(\u00f7#\u00847\u00de |im\u00d0i\u0018\u0090m\u009f]\u00f4\u0098\u000b\u0099I\u0093=\u0010\u00c5L\u00a7\u00ee-\u00ad\u008dK\u00ef\u00c9\u00de\f\u00b3\u001c(_\u00ad\u00aa\u0092\u00a2\u0093\u00a68\u00ca\u00e5i\u00ae\u0014\u0001\u00f7H\u00d5\u0013\u00ff\u00e0C\u00ca\u00aa\u00e5\u0006\u0007b\u00b8\u00a6\u009a\u00a51\u0013\u00ea\u001c\u00ea\u00a3F2>".length();
                                var27_7 = 32;
                                var26_8 = -1;
lbl23:
                                // 2 sources

                                while (true) {
                                    v3 = ++var26_8;
                                    v4 = var28_5.substring(v3, v3 + var27_7);
                                    v5 = -1;
                                    break block26;
                                    break;
                                }
lbl28:
                                // 1 sources

                                while (true) {
                                    var31_3[var29_4++] = ModuleAk.b(var32_9).intern();
                                    if ((var26_8 += var27_7) < var30_6) {
                                        var27_7 = var28_5.charAt(var26_8);
                                        ** continue;
                                    }
                                    var28_5 = "hM\u00e8\u00f8\u0084\u00a7\\px{\u00b8\u00a5(_\u00f5\u00cd 3\u00b0\u00b0\u0082e\u00e06\u00fak\u00a0\u00dd\u0080RP%\u0011u\u00ab*\u00fd\u00f4\u00cd\u00ba\u001cy\u00e2\u00d3}6J\u00ed\u0001";
                                    var30_6 = "hM\u00e8\u00f8\u0084\u00a7\\px{\u00b8\u00a5(_\u00f5\u00cd 3\u00b0\u00b0\u0082e\u00e06\u00fak\u00a0\u00dd\u0080RP%\u0011u\u00ab*\u00fd\u00f4\u00cd\u00ba\u001cy\u00e2\u00d3}6J\u00ed\u0001".length();
                                    var27_7 = 16;
                                    var26_8 = -1;
lbl37:
                                    // 2 sources

                                    while (true) {
                                        v6 = ++var26_8;
                                        v4 = var28_5.substring(v6, v6 + var27_7);
                                        v5 = 0;
                                        break block26;
                                        break;
                                    }
                                    break;
                                }
lbl42:
                                // 1 sources

                                while (true) {
                                    var31_3[var29_4++] = ModuleAk.b(var32_9).intern();
                                    if ((var26_8 += var27_7) < var30_6) {
                                        var27_7 = var28_5.charAt(var26_8);
                                        ** continue;
                                    }
                                    break block27;
                                    break;
                                }
                            }
                            var32_9 = var24_1.doFinal(v4.getBytes("ISO-8859-1"));
                            switch (v5) {
                                default: {
                                    ** continue;
                                }
                                ** case 0:
lbl54:
                                // 1 sources

                                ** continue;
                            }
                        }
                        ModuleAk.O = var31_3;
                        ModuleAk.P = new String[23];
                        ModuleAk.T = new HashMap<K, V>(13);
                        var11_10 = Cipher.getInstance("DES/CBC/NoPadding");
                        v7 = SecretKeyFactory.getInstance("DES");
                        v8 = new byte[8];
                        v9 = v8;
                        v8[0] = (byte)(var22 >>> 56);
                        for (var12_11 = 1; var12_11 < 8; ++var12_11) {
                            v9 = v9;
                            v9[var12_11] = (byte)(var22 << var12_11 * 8 >>> 56);
                        }
                        var11_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                        var17_12 = new long[37];
                        var14_13 = 0;
                        var15_14 = "\u00bc\u008a\u00b3n\u00e2'8\u00adh\u00f8\u009c8\u00d5/\u00c0\u00a8MN:O\u00a8\u00b5M\u00d9\u009eW\u00db\u001c\u00e8\u00c4\u00b7\u0095\"\u00d5\u0080g\u00f4aU\u00d09\u0099\u008aS\u001f3\u00d2\u00fcO\u0085j\u009a\u000f\u00df\u00d2/\u00d8\u00d1\u00ac2%@h\\N\u007f\u007f\u00bf8\u00e1|\u00dcmx\f\u00e2\u00fb\u0093\u00fc\u009d\u0097\u0006c\u0017\t\u00eb<\u009b\u00ad\u0014\u00e1\u00c8\u008f\u009c\u0004\u00a4\u0082\u0017\u00eew\u00cb1h+=\u00e6\u00c0\u009cR\u00f3\u00d1\u00bc\u00af\u00b4PAh\u0002\u00b7\u008aM\u00b5\u00e6\rJ\u00a8\u00be\u007f\u001c\u00fa\u001f\u00de\u00eeF<M\u00aa\u00af*\u0087\u0007\u00ec7\u00b9\u00fa\"qVn\u001eI\u009d\bP\u001et\u00f7B\u00c4\r\u00ff$\u00c6\u0002\u00fb\u00da\u0013\u00d5\u008a\u00c2Y:\u00f8\u00fe\u00a5\u00c5y\u00d1\u00e7\u00f2\u0095\u00e3\u0000p\u00ebF\u00aa\u00c1@(6q\u00ed\u00b0\u00e0G\u0099\u00a0G5M\u008c\u0094\u00fa\u00848yDN\u00d5d\u00ddM1\u00f4\u00e8s\u0092\u00e4\u0095\u00e4\u00b0a)g\u0080'\u00f8\u000f\u00f6\u008f\u00c9D<\u00cb\u00d2\u00e2\u00d1\u009d\u00c1\u00a3s\u0095\u0087{\u00c6\u00b4\u0087P\u00d3$j\u00df&\u00bd\u0084\u00f5\u00d3l\u00be~.E\u00d9\u00ee\u00b1?\u00ee.\u00c4O\u0010\u00d3VO+\u00a5\u0085F\u0005";
                        var16_15 = "\u00bc\u008a\u00b3n\u00e2'8\u00adh\u00f8\u009c8\u00d5/\u00c0\u00a8MN:O\u00a8\u00b5M\u00d9\u009eW\u00db\u001c\u00e8\u00c4\u00b7\u0095\"\u00d5\u0080g\u00f4aU\u00d09\u0099\u008aS\u001f3\u00d2\u00fcO\u0085j\u009a\u000f\u00df\u00d2/\u00d8\u00d1\u00ac2%@h\\N\u007f\u007f\u00bf8\u00e1|\u00dcmx\f\u00e2\u00fb\u0093\u00fc\u009d\u0097\u0006c\u0017\t\u00eb<\u009b\u00ad\u0014\u00e1\u00c8\u008f\u009c\u0004\u00a4\u0082\u0017\u00eew\u00cb1h+=\u00e6\u00c0\u009cR\u00f3\u00d1\u00bc\u00af\u00b4PAh\u0002\u00b7\u008aM\u00b5\u00e6\rJ\u00a8\u00be\u007f\u001c\u00fa\u001f\u00de\u00eeF<M\u00aa\u00af*\u0087\u0007\u00ec7\u00b9\u00fa\"qVn\u001eI\u009d\bP\u001et\u00f7B\u00c4\r\u00ff$\u00c6\u0002\u00fb\u00da\u0013\u00d5\u008a\u00c2Y:\u00f8\u00fe\u00a5\u00c5y\u00d1\u00e7\u00f2\u0095\u00e3\u0000p\u00ebF\u00aa\u00c1@(6q\u00ed\u00b0\u00e0G\u0099\u00a0G5M\u008c\u0094\u00fa\u00848yDN\u00d5d\u00ddM1\u00f4\u00e8s\u0092\u00e4\u0095\u00e4\u00b0a)g\u0080'\u00f8\u000f\u00f6\u008f\u00c9D<\u00cb\u00d2\u00e2\u00d1\u009d\u00c1\u00a3s\u0095\u0087{\u00c6\u00b4\u0087P\u00d3$j\u00df&\u00bd\u0084\u00f5\u00d3l\u00be~.E\u00d9\u00ee\u00b1?\u00ee.\u00c4O\u0010\u00d3VO+\u00a5\u0085F\u0005".length();
                        var13_16 = 0;
                        while (true) {
                            var18_17 = var15_14.substring(var13_16, var13_16 += 8).getBytes("ISO-8859-1");
                            v10 = var17_12;
                            v11 = var14_13++;
                            v12 = ((long)var18_17[0] & 255L) << 56 | ((long)var18_17[1] & 255L) << 48 | ((long)var18_17[2] & 255L) << 40 | ((long)var18_17[3] & 255L) << 32 | ((long)var18_17[4] & 255L) << 24 | ((long)var18_17[5] & 255L) << 16 | ((long)var18_17[6] & 255L) << 8 | (long)var18_17[7] & 255L;
                            v13 = -1;
                            break block28;
                            break;
                        }
lbl81:
                        // 1 sources

                        while (true) {
                            v10[v11] = v14;
                            if (var13_16 < var16_15) ** continue;
                            var15_14 = "\u00c7\u0013\u0080\u009f\u00a5\u000f/\u00ad\u008bI\u0080^\u00ee\u00df/\u00ee";
                            var16_15 = "\u00c7\u0013\u0080\u009f\u00a5\u000f/\u00ad\u008bI\u0080^\u00ee\u00df/\u00ee".length();
                            var13_16 = 0;
                            while (true) {
                                var18_17 = var15_14.substring(var13_16, var13_16 += 8).getBytes("ISO-8859-1");
                                v10 = var17_12;
                                v11 = var14_13++;
                                v12 = ((long)var18_17[0] & 255L) << 56 | ((long)var18_17[1] & 255L) << 48 | ((long)var18_17[2] & 255L) << 40 | ((long)var18_17[3] & 255L) << 32 | ((long)var18_17[4] & 255L) << 24 | ((long)var18_17[5] & 255L) << 16 | ((long)var18_17[6] & 255L) << 8 | (long)var18_17[7] & 255L;
                                v13 = 0;
                                break block28;
                                break;
                            }
                            break;
                        }
lbl94:
                        // 1 sources

                        while (true) {
                            v10[v11] = v14;
                            if (var13_16 < var16_15) ** continue;
                            break block29;
                            break;
                        }
                    }
                    var19_18 = v12;
                    var21_19 = var11_10.doFinal(new byte[]{(byte)(var19_18 >>> 56), (byte)(var19_18 >>> 48), (byte)(var19_18 >>> 40), (byte)(var19_18 >>> 32), (byte)(var19_18 >>> 24), (byte)(var19_18 >>> 16), (byte)(var19_18 >>> 8), (byte)var19_18});
                    v14 = ((long)var21_19[0] & 255L) << 56 | ((long)var21_19[1] & 255L) << 48 | ((long)var21_19[2] & 255L) << 40 | ((long)var21_19[3] & 255L) << 32 | ((long)var21_19[4] & 255L) << 24 | ((long)var21_19[5] & 255L) << 16 | ((long)var21_19[6] & 255L) << 8 | (long)var21_19[7] & 255L;
                    switch (v13) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl107:
                        // 1 sources

                        ** continue;
                    }
                }
                ModuleAk.R = var17_12;
                ModuleAk.S = new Integer[37];
                ModuleAk.m = 1024;
                ModuleAk.n = 8192;
                ModuleAk.W = new HashMap<K, V>(13);
                var0_20 = Cipher.getInstance("DES/CBC/NoPadding");
                v15 = SecretKeyFactory.getInstance("DES");
                v16 = new byte[8];
                v17 = v16;
                v16[0] = (byte)(var22 >>> 56);
                for (var1_21 = 1; var1_21 < 8; ++var1_21) {
                    v17 = v17;
                    v17[var1_21] = (byte)(var22 << var1_21 * 8 >>> 56);
                }
                var0_20.init(2, (Key)v15.generateSecret(new DESKeySpec(v17)), new IvParameterSpec(new byte[8]));
                var6_22 = new long[4];
                var3_23 = 0;
                var4_24 = "\u00ad@EB\u00bd4\u00ba\u0010\u00b62\u00c5\u00f5\u00ba1\u009cK";
                var5_25 = "\u00ad@EB\u00bd4\u00ba\u0010\u00b62\u00c5\u00f5\u00ba1\u009cK".length();
                var2_26 = 0;
                while (true) {
                    var7_27 = var4_24.substring(var2_26, var2_26 += 8).getBytes("ISO-8859-1");
                    v18 = var6_22;
                    v19 = var3_23++;
                    v20 = ((long)var7_27[0] & 255L) << 56 | ((long)var7_27[1] & 255L) << 48 | ((long)var7_27[2] & 255L) << 40 | ((long)var7_27[3] & 255L) << 32 | ((long)var7_27[4] & 255L) << 24 | ((long)var7_27[5] & 255L) << 16 | ((long)var7_27[6] & 255L) << 8 | (long)var7_27[7] & 255L;
                    v21 = -1;
                    break block30;
                    break;
                }
lbl138:
                // 1 sources

                while (true) {
                    v18[v19] = v22;
                    if (var2_26 < var5_25) ** continue;
                    var4_24 = "[\u0099\u00e0\u00e2p\u0014\u00fe>\u00a7\n\u0099\u00e3\u00b1\u00d9\u0011\u00c3";
                    var5_25 = "[\u0099\u00e0\u00e2p\u0014\u00fe>\u00a7\n\u0099\u00e3\u00b1\u00d9\u0011\u00c3".length();
                    var2_26 = 0;
                    while (true) {
                        var7_27 = var4_24.substring(var2_26, var2_26 += 8).getBytes("ISO-8859-1");
                        v18 = var6_22;
                        v19 = var3_23++;
                        v20 = ((long)var7_27[0] & 255L) << 56 | ((long)var7_27[1] & 255L) << 48 | ((long)var7_27[2] & 255L) << 40 | ((long)var7_27[3] & 255L) << 32 | ((long)var7_27[4] & 255L) << 24 | ((long)var7_27[5] & 255L) << 16 | ((long)var7_27[6] & 255L) << 8 | (long)var7_27[7] & 255L;
                        v21 = 0;
                        break block30;
                        break;
                    }
                    break;
                }
lbl151:
                // 1 sources

                while (true) {
                    v18[v19] = v22;
                    if (var2_26 < var5_25) ** continue;
                    break block31;
                    break;
                }
            }
            var8_28 = v20;
            var10_29 = var0_20.doFinal(new byte[]{(byte)(var8_28 >>> 56), (byte)(var8_28 >>> 48), (byte)(var8_28 >>> 40), (byte)(var8_28 >>> 32), (byte)(var8_28 >>> 24), (byte)(var8_28 >>> 16), (byte)(var8_28 >>> 8), (byte)var8_28});
            v22 = ((long)var10_29[0] & 255L) << 56 | ((long)var10_29[1] & 255L) << 48 | ((long)var10_29[2] & 255L) << 40 | ((long)var10_29[3] & 255L) << 32 | ((long)var10_29[4] & 255L) << 24 | ((long)var10_29[5] & 255L) << 16 | ((long)var10_29[6] & 255L) << 8 | (long)var10_29[7] & 255L;
            switch (v21) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl164:
                // 1 sources

                ** continue;
            }
        }
        ModuleAk.U = var6_22;
        ModuleAk.V = new Long[4];
        ModuleAk.J = 200L;
    }

    private static Throwable a(Throwable throwable) {
        return throwable;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static String b(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x344A;
        if (P[n3] == null) {
            Object[] objectArray;
            try {
                Long l3 = Thread.currentThread().threadId();
                objectArray = (Object[])Q.get(l3);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    Q.put(l3, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/g/ak", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l2 >>> 56);
            for (int i2 = 1; i2 < 8; ++i2) {
                byArray[i2] = (byte)(l2 << i2 * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = O[n3].getBytes("ISO-8859-1");
            ModuleAk.P[n3] = ModuleAk.b(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return P[n3];
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        String string2 = ModuleAk.b(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static CallSite b(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/ak" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x2149;
        if (S[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = R[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])T.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    T.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/g/ak", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            ModuleAk.S[n3] = n4;
        }
        return S[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = ModuleAk.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/ak" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static long d(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x7D85;
        if (V[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = U[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])W.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    W.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/g/ak", exception);
            }
            long l5 = ((long)byArray[0] & 0xFFL) << 56 | ((long)byArray[1] & 0xFFL) << 48 | ((long)byArray[2] & 0xFFL) << 40 | ((long)byArray[3] & 0xFFL) << 32 | ((long)byArray[4] & 0xFFL) << 24 | ((long)byArray[5] & 0xFFL) << 16 | ((long)byArray[6] & 0xFFL) << 8 | (long)byArray[7] & 0xFFL;
            ModuleAk.V[n3] = l5;
        }
        return V[n3];
    }

    private static long d(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        long l3 = ModuleAk.d(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Long.TYPE, l3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return l3;
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_2().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/ak" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (Y[n4] != null) {
            return n4;
        }
        Object object = X[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 13;
            case 1 -> 44;
            case 2 -> 8;
            case 3 -> 45;
            case 4 -> 24;
            case 5 -> 5;
            case 6 -> 48;
            case 7 -> 2;
            case 8 -> 34;
            case 9 -> 9;
            case 10 -> 10;
            case 11 -> 29;
            case 12 -> 38;
            case 13 -> 39;
            case 14 -> 6;
            case 15 -> 22;
            case 16 -> 47;
            case 17 -> 63;
            case 18 -> 57;
            case 19 -> 50;
            case 20 -> 54;
            case 21 -> 23;
            case 22 -> 20;
            case 23 -> 62;
            case 24 -> 25;
            case 25 -> 36;
            case 26 -> 51;
            case 27 -> 19;
            case 28 -> 42;
            case 29 -> 41;
            case 30 -> 4;
            case 31 -> 59;
            case 32 -> 12;
            case 33 -> 49;
            case 34 -> 60;
            case 35 -> 58;
            case 36 -> 37;
            case 37 -> 30;
            case 38 -> 40;
            case 39 -> 17;
            case 40 -> 55;
            case 41 -> 33;
            case 42 -> 14;
            case 43 -> 1;
            case 44 -> 7;
            case 45 -> 53;
            case 46 -> 52;
            case 47 -> 26;
            case 48 -> 32;
            case 49 -> 18;
            case 50 -> 28;
            case 51 -> 16;
            case 52 -> 56;
            case 53 -> 11;
            case 54 -> 46;
            case 55 -> 15;
            case 56 -> 21;
            case 57 -> 43;
            case 58 -> 31;
            case 59 -> 3;
            case 60 -> 61;
            case 61 -> 35;
            case 62 -> 27;
            default -> 0;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        ModuleAk.Y[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = X;
        X[0] = "x-GV\u000b\u0018s-AV\u000b]";
        objectArray[1] = "O1\u001a\u0002d\u0007F1\u0019\u0002f";
        objectArray[2] = "! h\u0003\u0012V*/yLhR9.i\u0003^V.";
        objectArray[3] = "\u0018'\u0002W3m\u0011'\u0001W7";
        objectArray[4] = "%\u0017\u00104&\u000e8\u0002H\u0016g\u0003 \u0004";
        objectArray[5] = "\u000ept\u0013]0\u0005pr\u0013]Z";
        objectArray[6] = "P^";
        objectArray[7] = "g,=\f\u001c\u0016n,>\f\u001c";
        objectArray[8] = "3nr1X\u00008ac~9\u000e3jg$";
        objectArray[9] = "\u0014\u001dsF\u001bE\u001f\u001duF\u001b\u0011";
        objectArray[10] = "a~";
        objectArray[11] = "}8N\u00110=v8H\u00110R";
        objectArray[12] = Double.TYPE;
        ModuleAk.Y[12] = "java/lang/Double";
        objectArray[13] = "]\u0015XQ\u0001\u000bT\u0015[Q\r";
        objectArray[14] = Long.TYPE;
        ModuleAk.Y[14] = "java/lang/Long";
        objectArray[15] = "\u0000\f-C19\t\f\u000b";
        objectArray[16] = Void.TYPE;
        ModuleAk.Y[16] = "java/lang/Void";
        objectArray[17] = "_8NL[]V8i";
        objectArray[18] = "M\u0004P95g8$[6$(Y*P= r-";
        objectArray[19] = "\u0010|hn8de\\ca)+\u0004Rhj-qp";
        objectArray[20] = "\u00100FJ\u000b\u001e\u00100Q\u0016\u0007\u0011\n{Q\b\u0007\u0004\r\n\u0000PU";
        objectArray[21] = "|>-zw\u0017b675\u0015\u000be+";
        objectArray[22] = Integer.TYPE;
        ModuleAk.Y[22] = "java/lang/Integer";
        objectArray[23] = "\bDK\u001bI?\u0003D@";
        objectArray[24] = Boolean.TYPE;
        ModuleAk.Y[24] = "java/lang/Boolean";
        objectArray[25] = "JGCd@Z?gHkQ\u0015^iC`UO*";
        objectArray[26] = "\t\u0010\u001a\u0006\"\u0005|0\u0011\t3J\u001d>\u001a\u00027\u0010i";
        objectArray[27] = "XW1t\u001e\u0005-w:{\u000fJLy1p\u000b\u00108";
        objectArray[28] = "^aL\u0002Pc+AG\rA,JOL\u0006Ev>";
        objectArray[29] = "\u000bR\t?m\t\u0000R\u0001";
        objectArray[30] = "\u001f\u0018J~l?j8Aq}p\u000b6Jzy*\u007f";
        objectArray[31] = "e`2e7g\u0010@9j&(qN2a\"r\u0005";
        objectArray[32] = "Y\u0004R0n\r,$Y?\u007fBM*R4{\u00189";
        objectArray[33] = "h\u0019\u0019\u0002\u0010\u0016h\u0019\u000e^\u001c\u0019rR\u000e@\u001c\fu#_\u001fE";
        objectArray[34] = "D.X`9\u000fGk\u0015\\<\u007f\u0019g@99\u0005\u0018rCeUFPsA0/GEp\u001d\\";
        objectArray[35] = "\u001fL53\u0007]\u001c\tx\u000f\u0010-\u0002NqkWMB\u0011*";
        objectArray[36] = "vC/U\"\\u\u0006bi\u0001,kAk\rrL+\u001e0";
        objectArray[37] = "TK<selW\u000eqO@\u001c\nM%%g-R\u0014pt";
        objectArray[38] = "wH\u0014\u001dSz6S\u001c\u00180uK\u0007\u0010\u001eUs7\u0006O\u001d\u0000\u001c";
        objectArray[39] = "Q\u000b#\u001ar@RNn&a0L\tgB\"P\fV<";
        objectArray[40] = "\u0013\rH\u001fb\u0017\u0004NI\u0014\u001a\u0002xPU\u0011sV\u0013M\tL#k\u0011DV@cU\u001aGO\f\u001a";
        objectArray[41] = "\u001a\u0004/$=L\u0019Ab\u0018)<\u0007\u0006k|m\\GY0";
        objectArray[42] = " \u00102Azqu\u0006n\u0012\u0004v\u001f\\+KgkaT.\u0013j";
        objectArray[43] = "+~\u0004P%\u001e<=\u0005[]\b@#\u0019^4_+>E\u0003db,9\nC%\\=?B\t]";
        objectArray[44] = "nx.\f^}m=c0N\rszjT\u000em3%1";
        objectArray[45] = "\u0019\u001f\u0004\u0019\u000b~AFQHe&#\u001b\bC\u0003(_\u001c\u0010H]O";
        objectArray[46] = "H!\u0000\u001eQ_\u000e;\u0012_<Gva\u0003C\u0005\u0013I=\u000f_F";
        objectArray[47] = "\u000ex-G0h[nq\u0014Nj144M-rO<1\u0015 ";
        objectArray[48] = "i+q\u0012#q<=-A]uV9|H:x<,'S>";
        objectArray[49] = "e(\u00007\"/fmM\u000b\u0002_x*Dor?8u\u001f";
        objectArray[50] = "XY\u000b\u001f0$[\u001cF#.T\u0006_\u0012I2e^\u0006G\u0018";
        objectArray[51] = "!\u007fJTJy\":\u0007h\\\t<}\u000e\f\u001ai|\"U";
        objectArray[52] = "F*1U\u007fyEo|iz\tGp!\u0000.bZ,|P\u0013cEt*\u0014v8Nh*i";
        objectArray[53] = "$\u0018sJ2h']>v'\u00189\u001a7\u0012bxyEl";
        objectArray[54] = "+gU>\u0005U~q\tm{^\u0014+L4\u0018Oj#Il\u0015";
        objectArray[55] = "\u000fKq*\u0000h\f\u000e<\u0016-\u0018ZMrv\n%T\u0013jl";
        objectArray[56] = "k/3{Xzhj~Gp\nf-6}\bud()'";
        objectArray[57] = "\u001fnVLB\u001a\u001c+\u001bpIjJhU\u0010HWD6M\n";
        objectArray[58] = "&;?v@}%~rJ]\rx=& B< dsq";
        objectArray[59] = "bt0\u0010\u00194a1},\bD\u007fvtHI$?)/";
        objectArray[60] = "\u0001~Qb\u0018\u001d\u0002;\u001c^\nm\u001c|\u0015:H\r\\#N";
        objectArray[61] = "W\"\u0014J/r\\!\r\u0006V'Z4\u000f\u001aV&Y4\u0013\n3}R(\u0013w";
        objectArray[62] = "\f\u001f#=\u001e\u001cY\t\u007fn`\u001a3S:7\u0003\u0006M[?o\u000e";
        objectArray[63] = "Y,mi81\f:1:F0f`tc%+\u0018hq;(";
        objectArray[64] = "\u001f[6\u000e\u0017=\u001c\u001e{2>M\u0012Y3\bG2\u0010\\,R";
        objectArray[65] = "Y\u0003AHH0ZF\ftn@\u0007\u0005X\u001eJq_\\\rO";
        objectArray[66] = "AkvAEZ\u0014}*\u0012;_~'oKX@\u0000/j\u0013U";
        objectArray[67] = " \u0016'yMS#SjEj#~\u0010>/O\u0012&Ik~";
        objectArray[68] = "\u0012H\u0012HD^\u0011\r_tA.\u0013\u0012\u0002\u001d\u0015E\u000eN_M(\u0015\u001fA\b\u0013T\u0012\u0007JVt";
        objectArray[69] = "O\u0000v{\u0004#LE;G%SR\u00022#T3\u0012]i";
        objectArray[70] = "z|!X#1>`b]E9A1;W|n~m7K?S";
        objectArray[71] = "?M/R\u001e5j[s\u0001`5\u0000\u00016X\u0003/~\t3\u0000\u000e";
        objectArray[72] = "\u0004QjRV\u0017\u0007\u0014'nyg\u000eQvR\u0004_\u0005\u001ao\u0012";
        objectArray[73] = "5\u00014\u0005\u0005s\"\u0004-Ko%ZU1K\u0011y:\u0002z^\bI";
        objectArray[74] = "nKf}5wm\u000e+A0\u0007o\u0011v(dlrM+xYa1\u001bt:f|1\u0003gA";
        objectArray[75] = "s\u0010v2}$}\u001dn/\u0004\u0010W{@\u0003\u0004,!Sy6o\",Kd";
        objectArray[76] = "7pE\u001d)545\b!5Eiv\\K+t1/\t\u001a";
        objectArray[77] = "\u0016 \u0012G;`\u0015e_{\u0017\u0010C&\u0011\u001b1-Mx\t\u0001";
        objectArray[78] = "sa,fSBxb5**\u0010\u001au/7CAqhsj\u0013|pw+<W\u0019+|7<*";
        objectArray[79] = ">VV;)75UOwPcWBUj94<_\t7i\t=@Qa-lfKMaP";
        objectArray[80] = "H\u00169\u0006K\u001dKSt:im\u001d\u0010:ZAP\u0013N\"@";
        objectArray[81] = "Q(cYNXF-z\u0017$\u0006>v~\u000bM_Uk\"V\u001dbTtz\u0000Y\u0007\u000f\u007ff\u0000$";
        Object[] objectArray2 = objectArray;
        objectArray[82] = "\u0013\u001a\u00042]\u0003\u0010_I\u000eXs\u0012@\u0014g\f\u0018\u000f\u001cI71\u001d\u001cH\u001fl[\bGS\u001b\u000e";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = ModuleAk.e(l2, l3);
            object = X[n2];
            try {
                if (!(object instanceof String)) break block2;
                ModuleAk.X[n2] = clazz = Class.forName(Y[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = ModuleAk.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = ModuleAk.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = ModuleAk.e(l2, l3);
        Object object = X[n2];
        if (object instanceof String) {
            String string = Y[n2];
            int n3 = string.indexOf(8);
            Class clazz = ModuleAk.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = ModuleAk.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = ModuleAk.c(clazz3, string2, clazz2)) != null) {
                    ModuleAk.X[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = ModuleAk.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        ModuleAk.X[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = ModuleAk.f(575085141704564L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = ModuleAk.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = ModuleAk.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = ModuleAk.e(l2, l3);
        Object object = X[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = Y[n2];
                int n4 = string2.indexOf(8);
                clazz3 = ModuleAk.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = ModuleAk.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = ModuleAk.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        ModuleAk.X[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = ModuleAk.f(575085141704564L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = ModuleAk.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        ModuleAk.X[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = ModuleAk.f(575085141704564L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == 'L' || c2 == 'k' || c2 == '\u00e5' || c2 == 'I') {
                field = ModuleAk.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == 'L' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == 'k' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == '\u00e5' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = ModuleAk.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == 'P' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == '\u00de' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = ModuleAk.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite f(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_3().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/ak" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(ModuleAk.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(ModuleAk.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_2() {
        try {
            return MethodHandles.lookup().findStatic(ModuleAk.class, "d", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_3() {
        try {
            return MethodHandles.lookup().findStatic(ModuleAk.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

