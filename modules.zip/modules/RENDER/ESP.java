// === Kuzi module: ESP ===
// Category   : RENDER
// Description: (identified by constant match; old tree ESP.java)
// Payload    : a.a.a.j.g.N (verified: constant-match)

package kuzi.modules.render;

import a.a.a.j.g.m;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.core.Client;
import kuzi.mixin.MixinExposed;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.e.i;
import kuzi.obf.h.b.e;
import kuzi.obf.h.b.h;
import kuzi.obf.h.b.l;
import kuzi.obf.h.b.v;
import kuzi.obf.j.g.aD;
import kuzi.obf.j.g.l_0;
import kuzi.obf.m.r;
import kuzi.obf.p.F;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.Entity;
import net.minecraft.LivingEntity;
import net.minecraft.MobCategory;
import net.minecraft.ItemEntity;
import net.minecraft.Player;
import net.minecraft.Minecraft;
import net.minecraft.LocalPlayer;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class ESP
extends BaseModule {
    public final l m;
    public final BoolSetting players;
    public final BoolSetting hostileMobs;
    public final BoolSetting passiveMobs;
    public final BoolSetting items;
    public final h r;
    public final BoolSetting throughWalls;
    public final BoolSetting tracers;
    public final BoolSetting fill;
    public final SliderSetting fillOpacity;
    public final BoolSetting outline;
    public final BoolSetting healthBar;
    public final BoolSetting names;
    public final BoolSetting distance;
    public final l A;
    public final e B;
    public final SliderSetting range;
    public final BoolSetting showInvisibles;
    public final BoolSetting ignoreSelf;
    public final BoolSetting ignoreFriends;
    public final SliderSetting maxGlowTargets;
    private volatile Set H;
    private int I;
    private static final long J;
    private static final String[] K;
    private static final String[] L;
    private static final Map M;
    private static final long[] N;
    private static final Integer[] O;
    private static final Map P;
    private static final long Q;
    private static final Object[] R;
    private static final String[] S;

    public ESP() {
        long l2;
        long l3 = l2 = J ^ 0x4A6322A30404L;
        long l4 = l3 ^ 0x3D9221C3D0C0L;
        long l5 = l3 ^ 0x13BED9547200L;
        super("ESP", "Highlight entities \u2014 Shaders glow, 3D Box or 2D \u2014 with tracers, per-entity colors and filters", Category.RENDER);
        this.m = new l("Mode", (Enum)a.a.a.j.g.m.SHADERS, m.class);
        this.players = new BoolSetting("Players", true);
        this.hostileMobs = new BoolSetting("Hostile Mobs", false);
        this.passiveMobs = new BoolSetting("Passive Mobs", false);
        this.items = new BoolSetting("Items", false);
        this.r = new h("Specific Entities", new HashSet());
        this.throughWalls = new BoolSetting("Through Walls", true);
        this.tracers = new BoolSetting("Tracers", false);
        this.fill = new BoolSetting("Fill", true);
        this.fillOpacity = new SliderSetting("Fill Opacity", 40.0, 0.0, 255.0, 5.0);
        this.outline = new BoolSetting("Outline", true);
        this.healthBar = new BoolSetting("Health Bar", true);
        this.names = new BoolSetting("Names", false);
        this.distance = new BoolSetting("Distance", false);
        this.A = new l("Color Mode", l_0.STATIC, l_0.class);
        this.B = new e("Color", new Color(90, 170, 255));
        this.range = new SliderSetting("Range", 100.0, 10.0, 256.0, 1.0);
        this.showInvisibles = new BoolSetting("Show Invisibles", true);
        this.ignoreSelf = new BoolSetting("Ignore Self", true);
        this.ignoreFriends = new BoolSetting("Ignore Friends", false);
        this.maxGlowTargets = new SliderSetting("Max Glow Targets", 12.0, 1.0, 64.0, 1.0);
        this.H = Collections.emptySet();
        this.I = -1;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.m, this.players, this.hostileMobs, this.passiveMobs, this.items, this.r, this.throughWalls, this.tracers, this.fill, this.fillOpacity, this.outline, this.healthBar, this.names, this.distance, this.A, this.B, this.range, this.showInvisibles, this.ignoreSelf, this.ignoreFriends, this.maxGlowTargets};
        objectArray[0] = l5;
        this.l(objectArray);
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l4;
        kuzi.obf.j.f.h.a(objectArray2);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @MixinExposed
    public static boolean a() {
        ESP esp = ESP.a();
        int[] nArray = aD.b();
        ESP espRef = esp;
        if (nArray != null) {
            if (espRef == null) return false;
            espRef = esp;
        }
        boolean isEnabled = espRef.d();
        if (nArray != null) {
            if (!isEnabled) return false;
            isEnabled = (Boolean)esp.n.a();
        }
        if (nArray != null) {
            if (!isEnabled) return false;
            isEnabled = (Boolean)esp.D.a();
        }
        if (nArray == null) return isEnabled;
        if (!isEnabled) return false;
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @MixinExposed
    public static ESP a() {
        int[] nArray = aD.b();
        i client = Client.a;
        if (nArray != null) {
            if (client == null) return null;
            client = Client.a;
        }
        ESP eSP = (ESP)client.a(ESP.class);
        return eSP;
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    public boolean a(Object[] var1_1) {
        block36: {
            block34: {
                block35: {
                    block32: {
                        block33: {
                            block31: {
                                block30: {
                                    var2_2 = (Entity)var1_1[0];
                                    var3_3 = (Long)var1_1[1];
                                    var5_4 = (var3_3 = ESP.J ^ var3_3) ^ 25979179475505L;
                                    var7_5 = aD.b();
                                    if (var2_2 == null) {
                                        return false;
                                    }
                                    v0 = var8_6 = Minecraft.getInstance();
                                    if (var3_3 < 0L || var7_5 == null) break block30;
                                    if (v0.player == null) break block31;
                                    v0 = var8_6;
                                }
                                v1 /* !! */  = v0.level;
                                if (var3_3 <= 0L || var7_5 == null) break block32;
                                if (v1 /* !! */  != null) break block33;
                            }
                            return false;
                        }
                        v1 /* !! */  = this.ignoreSelf.a();
                    }
                    v2 = (Boolean)v1 /* !! */ ;
                    v3 = var7_5;
                    if (var3_3 >= 0L) {
                        if (v3 != null) {
                            if (v2) {
                                v4 = var2_2;
                                if (var7_5 != null) {
                                    if (v4 == var8_6.player) {
                                        return false;
                                    } else {
                                        ** GOTO lbl-1000
                                    }
                                }
                            } else lbl-1000:
                            // 3 sources

                            {
                                v4 = var2_2;
                            }
                            v2 = v4.isAlive();
                        }
                        v3 = var7_5;
                    }
                    if (var3_3 >= 0L) {
                        if (v3 != null) {
                            if (!v2) {
                                return false;
                            }
                            v5 = new Object[2];
                            v5[1] = var5_4;
                            v5[0] = var2_2;
                            v2 = this.d(v5);
                        }
                        v3 = var7_5;
                    }
                    if (var3_3 > 0L) {
                        if (v3 != null) {
                            if (!v2) {
                                return false;
                            }
                            cfr_temp_0 = (double)var8_6.player.distanceTo(var2_2) - (Double)this.range.a();
                            v2 = cfr_temp_0 == 0.0 ? 0 : (cfr_temp_0 > 0.0 ? 1 : -1);
                        }
                        v3 = var7_5;
                    }
                    if (var3_3 > 0L) {
                        if (v3 != null) {
                            if (v2 > false) {
                                return false;
                            }
                            v2 = (Boolean)this.ignoreFriends.a();
                        }
                        v3 = var7_5;
                    }
                    if (v3 == null) break block34;
                    if (!v2) break block35;
                    v2 = var2_2 instanceof Player;
                    if (var7_5 == null) break block34;
                    if (!v2) break block35;
                    var9_7 = (Player)var2_2;
                    v2 = kuzi.obf.p.F.a(var9_7.getGameProfile().name());
                    v6 = var7_5;
                    if (var3_3 > 0L) {
                        if (v6 != null) {
                            if (v2) {
                                return false;
                            } else {
                                ** GOTO lbl72
                            }
                        } else {
                            ** GOTO lbl71
                        }
                    }
                    break block36;
lbl71:
                    // 2 sources

                    break block34;
                }
                v2 = (Boolean)this.throughWalls.a();
            }
            v6 = var7_5;
        }
        if (v6 != null) {
            if (!v2) {
                v2 = var8_6.player.hasLineOfSight(var2_2);
                if (var7_5 != null) {
                    if (!v2) {
                        return false;
                    } else {
                        ** GOTO lbl-1000
                    }
                }
            } else lbl-1000:
            // 3 sources

            {
                v2 = true;
            }
        }
        return v2;
    }

    /*
     * Enabled aggressive block sorting
     */
    private boolean d(Object[] objectArray) {
        Boolean enabled;
        Entity entity = (Entity)objectArray[0];
        long l2 = (Long)objectArray[1];
        long l3 = (l2 = J ^ l2) ^ 0xA6F2C754D21L;
        int[] nArray = aD.b();
        Object[] objectArray2 = new Object[2];
        objectArray2[1] = entity.getType();
        objectArray2[0] = l3;
        boolean matches = this.r.b(objectArray2);
        if (nArray != null) {
            if (matches) {
                return true;
            }
            matches = entity instanceof Player;
        }
        int[] nArray2 = nArray;
        if (l2 > 0L) {
            if (nArray2 != null) {
                if (matches) {
                    return (Boolean)this.players.a();
                }
                matches = entity instanceof ItemEntity;
            }
            nArray2 = nArray;
        }
        if (l2 >= 0L) {
            if (nArray2 != null) {
                if (matches) {
                    return (Boolean)this.items.a();
                }
                matches = entity instanceof LivingEntity;
            }
            nArray2 = nArray;
        }
        if (nArray2 == null) return matches;
        if (!matches) {
            return false;
        }
        Object category = entity.getType().getCategory();
        if (nArray != null) {
            if (category == MobCategory.MONSTER) {
                enabled = (Boolean)this.hostileMobs.a();
                return enabled;
            }
            category = this.passiveMobs.a();
        }
        enabled = (Boolean)category;
        return enabled;
    }

    @MixinExposed
    public boolean e(Entity entity) {
        long l2;
        block4: {
            boolean isShaderMode;
            block2: {
                block3: {
                    long l3 = J ^ 0x96FD6BE5E5AL;
                    l2 = l3 ^ 0x6AA3FA08E02DL;
                    int[] nArray = aD.b();
                    isShaderMode = this.d();
                    if (nArray == null) break block2;
                    if (!isShaderMode) break block3;
                    isShaderMode = ((m)this.m.a()).name().equals("SHADERS");
                    if (nArray == null) break block2;
                    if (isShaderMode && entity != null) break block4;
                }
                isShaderMode = false;
            }
            return isShaderMode;
        }
        Object[] objectArray = new Object[1];
        objectArray[0] = l2;
        return this.a(objectArray).contains(entity.getId());
    }

    private Set a(Object[] objectArray) {
        HashSet visibleIdsResult;
        block15: {
            ArrayList<Entity> visibleCandidates;
            int maxTargets;
            int currentTick;
            int[] nArray;
            long l2;
            block14: {
                Minecraft mc;
                Minecraft currentMc;
                long l3;
                block18: {
                    block19: {
                        block17: {
                            block16: {
                                l2 = (Long)objectArray[0];
                                l3 = (l2 = J ^ l2) ^ 0x6A7DA12FE3FL;
                                mc = Minecraft.getInstance();
                                nArray = aD.b();
                                currentMc = mc;
                                if (nArray == null) break block16;
                                if (currentMc.player == null) break block17;
                                currentMc = mc;
                            }
                            if (nArray == null) break block18;
                            if (currentMc.level != null) break block19;
                        }
                        return Collections.emptySet();
                    }
                    currentMc = mc;
                }
                int tick = currentTick = currentMc.player.tickCount;
                if (l2 >= 0L) {
                    boolean hasLimit;
                    int limit = this.I;
                    if (nArray != null) {
                        if (tick == limit) {
                            return this.H;
                        }
                        hasLimit = true;
                        limit = ((Double)this.maxGlowTargets.a()).intValue();
                    }
                    tick = Math.max(hasLimit ? 1 : 0, limit);
                }
                maxTargets = tick;
                visibleCandidates = new ArrayList<Entity>();
                for (Entity entity : mc.level.entitiesForRendering()) {
                    if (nArray != null) {
                        Object[] objectArray2 = new Object[2];
                        objectArray2[1] = l3;
                        objectArray2[0] = entity;
                        boolean selected = this.a(objectArray2);
                        if (nArray != null && selected) {
                            selected = visibleCandidates.add(entity);
                        }
                        if (nArray != null) continue;
                        break;
                    }
                    break block14;
                }
                visibleCandidates.sort(Comparator.comparingDouble(arg_0 -> ((LocalPlayer)mc.player).distanceTo(arg_0)));
                if (l2 >= 0L) {
                    // empty if block
                }
            }
            HashSet visibleIds = new HashSet();
            int index = 0;
            block1: while (index < Math.min(maxTargets, visibleCandidates.size())) {
                visibleIdsResult = visibleIds;
                if (l2 > 0L) {
                    visibleIds.add(((Entity)visibleCandidates.get(index)).getId());
                    ++index;
                    while (nArray != null) {
                        if (nArray != null) continue block1;
                        if (l2 <= 0L) continue;
                    }
                }
                break block15;
            }
            {
                this.H = visibleIds;
                this.I = currentTick;
                break;
            }
            visibleIdsResult = visibleIds;
        }
        return visibleIdsResult;
    }

    @MixinExposed
    public int a(Entity entity) {
        long l2 = J ^ 0x7D349407957BL;
        long l3 = l2 ^ 0x713A3E8DC3B0L;
        Object[] objectArray = new Object[2];
        objectArray[1] = l3;
        objectArray[0] = entity;
        return this.c(objectArray) & 0xFFFFFF;
    }

    /*
     * Exception decompiling
     */
    public int c(Object[] var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 6[SWITCH]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:435)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:484)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    public static int a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        int fromRgb = (Integer)objectArray[1];
        int toRgb = (Integer)objectArray[2];
        float delta = ((Float)objectArray[3]).floatValue();
        l2 = J ^ l2;
        int fromR = fromRgb >> ESP.c("o", (int)6197, (long)(0x76289740DB6FB98CL ^ l2)) & ESP.c("o", (int)7230, (long)(0x373C0B5F4353D8FL ^ l2));
        int fromG = fromRgb >> ESP.c("o", (int)5644, (long)(0x2182B4319A1437ABL ^ l2)) & ESP.c("o", (int)7230, (long)(0x373C0B5F4353D8FL ^ l2));
        int fromB = fromRgb & ESP.c("o", (int)7230, (long)(0x373C0B5F4353D8FL ^ l2));
        int toR = toRgb >> ESP.c("o", (int)6197, (long)(0x76289740DB6FB98CL ^ l2)) & ESP.c("o", (int)7230, (long)(0x373C0B5F4353D8FL ^ l2));
        int toG = toRgb >> ESP.c("o", (int)5644, (long)(0x2182B4319A1437ABL ^ l2)) & ESP.c("o", (int)7230, (long)(0x373C0B5F4353D8FL ^ l2));
        int toB = toRgb & ESP.c("o", (int)7230, (long)(0x373C0B5F4353D8FL ^ l2));
        int mixedR = (int)((float)fromR + (float)(toR - fromR) * delta);
        int mixedG = (int)((float)fromG + (float)(toG - fromG) * delta);
        int mixedB = (int)((float)fromB + (float)(toB - fromB) * delta);
        return ESP.c("o", (int)1264, (long)(0x79DF3ABF7F95A544L ^ l2)) | mixedR << ESP.c("o", (int)6197, (long)(0x76289740DB6FB98CL ^ l2)) | mixedG << ESP.c("o", (int)5644, (long)(0x2182B4319A1437ABL ^ l2)) | mixedB;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block24: {
            block23: {
                block22: {
                    block21: {
                        block20: {
                            ESP.J = kuzi.obf.h.b.v.a(-5392713376290023033L, 2173110003422898660L, MethodHandles.lookup().lookupClass()).a(256477869064331L);
                            ESP.R = new Object[78];
                            ESP.S = new String[78];
                            ESP.c();
                            ESP.M = new HashMap<K, V>(13);
                            var16 = ESP.J ^ 126728836010018L;
                            var18_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                            v0 = SecretKeyFactory.getInstance("DES");
                            v1 = new byte[8];
                            v2 = v1;
                            v1[0] = (byte)(var16 >>> 56);
                            for (var19_2 = 1; var19_2 < 8; ++var19_2) {
                                v2 = v2;
                                v2[var19_2] = (byte)(var16 << var19_2 * 8 >>> 56);
                            }
                            var18_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                            var25_3 = new String[24];
                            var23_4 = 0;
                            var22_5 = "q\u00002h@^\u00144/\u0095I:.\u00f9uY\u0018\u0001sK2w\u00de\u00e7\u0094\u00d6\u00c8\u00e1\u001e\u001a \u00c0\u00e5V9&\u0010Ho\"3\u0018\u00b12\u00b6j`\u00e8\u00bc\f6\u00fe\u00fa\u00d9\u00aa\u00a6\u00ee\u001a\u00f8OA\u0017Zko\u00c5\u0018t\u00d5t2\u00cb\u001e\u00828\u0080\u00e8\u008fK\u00b4\u0005\"\u00d7\u00b9\u00f7\u00ee|y\r\u0094!\u0018\u00d8\u00ad#\u00d9\t\u00aa\u00ce\u00ea\u00aaS\u00a2ZXW[\u0012L\u0003\u00a1\u0018\u00f9\u00fa\u00bf\u00b2\u00a0\u001c\u00f9v[\u00ccv\u00da\u00f3P\u00cb%@\u0012\u00b7\u00d2\u00be\u00bd\u0010\u0000d|\u00e0\u008b\u00d4\u0087\u0014\u00bb{,\u007f'\u00f3\u009a\u0082\u00ac\u008f\u00a0\u00ce\u00c4\u00c1\u00f3,\u00c5\u00ccs\u00c59\u0085\u0003\u00dd\u0090&F\u00dad4EY\u00fe\u00a8\u00f5\u0005\u00c2\u00d8\u00bcv\u0090\u00bcJ\u00f3\u0018j\u00f6\u00148-\u00b5\u008cX\u00dd\u00e9.6\\ \u00c2G\u00a1I\u00d9\u00ae/TqD\u009a\u00d5\u00fe\u00f5\u00cb-g0T)Vb\u00ab\u00d5\u001f\u00ca8\u00d9T\u00a1\u00d7\u00ce\u0017\u00a0Um\u00d4\u0012i\u00e2w\u00e1\u001a\u0015[\u0013\u00c2\u0003Jh\u000e\u00fek|\u00a2\u0017\u0093W5B\u00121\u009d\u009e\u001a\u0011\u00a9r{U\u0000y\u00ae\u00b3\u00ee\u00188\u0002\u0002\u00e0F\u00b1{\u0097\u001e\u00e5\u00d4@K\u008b\u00d1\u0016\u009d\u00b6}\u00d5\u00d8\u00d8\u009e\u00c6\u0010vc+\u00e4\u00af*c\u0010\u008f\u0080m|\u00bd\u00fa>`\u0010a\u001a\u00f4u/\u00cf\u001e\u001e~\u00f3e\u000f`c2\u00d2\u0010\u00cezZ\u0003\u0089U\u00d1\u00ba\u00b9\u0014b\u00dbb\u00cc\u0089\u0015 \u0091\u0017\u00e5\u0093\u00b5\u0096'\b\u00c0)G\u0084\u0018\u009a\u00ec\u0013\u00bf\u00c5\u00f6\u001d\u00c0\u0080,\u0011z\u008f\u001c\u00056g\u00ae_(<\u009e\u00d1\u00c8\u0085\u00fc\u00b7s<`\u000b\u00d8\u00e3Ex\u00df\u00f9PGh\t\u00ecb\u0005G\u0094v\u0005\u00dd\u0006S\u00d4.\u008c\u00ad\u00a6\u00d5\u00eb\u00ac\u00c7\u0010\u0010\u0087 \u00b7\u00dd&\u00eb\u00ff\u00c67\"\u00ce\u00e8\u00cfo| \u0080\b\u00be\u00fe\u00d1]\u00e8\u00d7E\u0081\b\u00af\u0010\u00be\u00dbL\u00d1`\t\u00b3\u00b6\u00aa6\u00cf0\u00e3\u000b\u00d3\u00db\u00cb\u00d2\u0096\u0010 \u008fT\u00e7j\u00e5\u0098_\u0080\u00f0\u00a10\u00b3=\u0084\u001e\u0010gb\u00fc\u0017\u00f6\u00bd\u0014\u00a0\u0086\b\u00f9+\u00f0\u000f\u00bc\u009c\u0018\u0085^\u00c4ZR\u0099\u00a3\u00a7\u0011&\u009b\u00ac\t\u0099\u0016eP-V\u00f8\u0094?\u00e7\u00e2 a\u00c4\u0087\u00cba\u00e2!\u00c1]\u00a7K\u00b3P\u0096,\u00a1\u0088\u00ef\u00a2\u00e6\u00ed\r\u008b0\u0014wI4\u00b6\u00e7\u00d8\u0088 0f[\u0090\u00cb3\u0003W\u00d6}\u00f9\u008er\u00b9\u0081M\u001b\u00efN\u0082\u0099pS\u007f\u00a3\u00c1\u00fa\u009e\n)8^\u0010i\u00aa\u00e2\u001fcO$\u0019\u00c5T\u0010\u0011\b\u00cd\u00c3\u00c6\u0010^\u00d0\u009f\u0098a\u001e\r\u009a\u00d79 /\u00f4\u0014\u00e4\u00a1($\u001d\u0095\u009e\u0084\u0098}a~xT\u00e5~Pk'\u00b3\u009c\u009e\u00fc\u00a9\u0096<\u00c4\u00c2\u00d5\u00a0\u00bb\u001a&T\u00b0\u00f8\u00db\u00c7v1S<\\";
                            var24_6 = "q\u00002h@^\u00144/\u0095I:.\u00f9uY\u0018\u0001sK2w\u00de\u00e7\u0094\u00d6\u00c8\u00e1\u001e\u001a \u00c0\u00e5V9&\u0010Ho\"3\u0018\u00b12\u00b6j`\u00e8\u00bc\f6\u00fe\u00fa\u00d9\u00aa\u00a6\u00ee\u001a\u00f8OA\u0017Zko\u00c5\u0018t\u00d5t2\u00cb\u001e\u00828\u0080\u00e8\u008fK\u00b4\u0005\"\u00d7\u00b9\u00f7\u00ee|y\r\u0094!\u0018\u00d8\u00ad#\u00d9\t\u00aa\u00ce\u00ea\u00aaS\u00a2ZXW[\u0012L\u0003\u00a1\u0018\u00f9\u00fa\u00bf\u00b2\u00a0\u001c\u00f9v[\u00ccv\u00da\u00f3P\u00cb%@\u0012\u00b7\u00d2\u00be\u00bd\u0010\u0000d|\u00e0\u008b\u00d4\u0087\u0014\u00bb{,\u007f'\u00f3\u009a\u0082\u00ac\u008f\u00a0\u00ce\u00c4\u00c1\u00f3,\u00c5\u00ccs\u00c59\u0085\u0003\u00dd\u0090&F\u00dad4EY\u00fe\u00a8\u00f5\u0005\u00c2\u00d8\u00bcv\u0090\u00bcJ\u00f3\u0018j\u00f6\u00148-\u00b5\u008cX\u00dd\u00e9.6\\ \u00c2G\u00a1I\u00d9\u00ae/TqD\u009a\u00d5\u00fe\u00f5\u00cb-g0T)Vb\u00ab\u00d5\u001f\u00ca8\u00d9T\u00a1\u00d7\u00ce\u0017\u00a0Um\u00d4\u0012i\u00e2w\u00e1\u001a\u0015[\u0013\u00c2\u0003Jh\u000e\u00fek|\u00a2\u0017\u0093W5B\u00121\u009d\u009e\u001a\u0011\u00a9r{U\u0000y\u00ae\u00b3\u00ee\u00188\u0002\u0002\u00e0F\u00b1{\u0097\u001e\u00e5\u00d4@K\u008b\u00d1\u0016\u009d\u00b6}\u00d5\u00d8\u00d8\u009e\u00c6\u0010vc+\u00e4\u00af*c\u0010\u008f\u0080m|\u00bd\u00fa>`\u0010a\u001a\u00f4u/\u00cf\u001e\u001e~\u00f3e\u000f`c2\u00d2\u0010\u00cezZ\u0003\u0089U\u00d1\u00ba\u00b9\u0014b\u00dbb\u00cc\u0089\u0015 \u0091\u0017\u00e5\u0093\u00b5\u0096'\b\u00c0)G\u0084\u0018\u009a\u00ec\u0013\u00bf\u00c5\u00f6\u001d\u00c0\u0080,\u0011z\u008f\u001c\u00056g\u00ae_(<\u009e\u00d1\u00c8\u0085\u00fc\u00b7s<`\u000b\u00d8\u00e3Ex\u00df\u00f9PGh\t\u00ecb\u0005G\u0094v\u0005\u00dd\u0006S\u00d4.\u008c\u00ad\u00a6\u00d5\u00eb\u00ac\u00c7\u0010\u0010\u0087 \u00b7\u00dd&\u00eb\u00ff\u00c67\"\u00ce\u00e8\u00cfo| \u0080\b\u00be\u00fe\u00d1]\u00e8\u00d7E\u0081\b\u00af\u0010\u00be\u00dbL\u00d1`\t\u00b3\u00b6\u00aa6\u00cf0\u00e3\u000b\u00d3\u00db\u00cb\u00d2\u0096\u0010 \u008fT\u00e7j\u00e5\u0098_\u0080\u00f0\u00a10\u00b3=\u0084\u001e\u0010gb\u00fc\u0017\u00f6\u00bd\u0014\u00a0\u0086\b\u00f9+\u00f0\u000f\u00bc\u009c\u0018\u0085^\u00c4ZR\u0099\u00a3\u00a7\u0011&\u009b\u00ac\t\u0099\u0016eP-V\u00f8\u0094?\u00e7\u00e2 a\u00c4\u0087\u00cba\u00e2!\u00c1]\u00a7K\u00b3P\u0096,\u00a1\u0088\u00ef\u00a2\u00e6\u00ed\r\u008b0\u0014wI4\u00b6\u00e7\u00d8\u0088 0f[\u0090\u00cb3\u0003W\u00d6}\u00f9\u008er\u00b9\u0081M\u001b\u00efN\u0082\u0099pS\u007f\u00a3\u00c1\u00fa\u009e\n)8^\u0010i\u00aa\u00e2\u001fcO$\u0019\u00c5T\u0010\u0011\b\u00cd\u00c3\u00c6\u0010^\u00d0\u009f\u0098a\u001e\r\u009a\u00d79 /\u00f4\u0014\u00e4\u00a1($\u001d\u0095\u009e\u0084\u0098}a~xT\u00e5~Pk'\u00b3\u009c\u009e\u00fc\u00a9\u0096<\u00c4\u00c2\u00d5\u00a0\u00bb\u001a&T\u00b0\u00f8\u00db\u00c7v1S<\\".length();
                            var21_7 = 16;
                            var20_8 = -1;
lbl23:
                            // 2 sources

                            while (true) {
                                v3 = ++var20_8;
                                v4 = var22_5.substring(v3, v3 + var21_7);
                                v5 = -1;
                                break block20;
                                break;
                            }
lbl28:
                            // 1 sources

                            while (true) {
                                var25_3[var23_4++] = ESP.b(var26_9).intern();
                                if ((var20_8 += var21_7) < var24_6) {
                                    var21_7 = var22_5.charAt(var20_8);
                                    ** continue;
                                }
                                var22_5 = " `'\u00a4\u00a0\u0006])\\=\u00b4\u00e9\u00c2!Tt\u0010\u008bS\u00f1KO\u00a1Ro\u00c7\u00d6\u00cd'\u00b9&4\u00d3";
                                var24_6 = " `'\u00a4\u00a0\u0006])\\=\u00b4\u00e9\u00c2!Tt\u0010\u008bS\u00f1KO\u00a1Ro\u00c7\u00d6\u00cd'\u00b9&4\u00d3".length();
                                var21_7 = 16;
                                var20_8 = -1;
lbl37:
                                // 2 sources

                                while (true) {
                                    v6 = ++var20_8;
                                    v4 = var22_5.substring(v6, v6 + var21_7);
                                    v5 = 0;
                                    break block20;
                                    break;
                                }
                                break;
                            }
lbl42:
                            // 1 sources

                            while (true) {
                                var25_3[var23_4++] = ESP.b(var26_9).intern();
                                if ((var20_8 += var21_7) < var24_6) {
                                    var21_7 = var22_5.charAt(var20_8);
                                    ** continue;
                                }
                                break block21;
                                break;
                            }
                        }
                        var26_9 = var18_1.doFinal(v4.getBytes("ISO-8859-1"));
                        switch (v5) {
                            default: {
                                ** continue;
                            }
                            ** case 0:
lbl54:
                            // 1 sources

                            ** continue;
                        }
                    }
                    ESP.K = var25_3;
                    ESP.L = new String[24];
                    ESP.P = new HashMap<K, V>(13);
                    var5_10 = Cipher.getInstance("DES/CBC/NoPadding");
                    v7 = SecretKeyFactory.getInstance("DES");
                    v8 = new byte[8];
                    v9 = v8;
                    v8[0] = (byte)(var16 >>> 56);
                    for (var6_11 = 1; var6_11 < 8; ++var6_11) {
                        v9 = v9;
                        v9[var6_11] = (byte)(var16 << var6_11 * 8 >>> 56);
                    }
                    var5_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                    var11_12 = new long[30];
                    var8_13 = 0;
                    var9_14 = "\u0015[\u008e\n\u00fd&\u009ab\u000fF\u00c8\n2y\u00e5\u00e31s\u00abS\u00f0\u0088\u00feG\u00fc\u00d3\u00e7\u00c9\u00f1Vt\u00afiZ\u00a1\u009aC\u008f\f\rZ\u00aez\b\u009a)\u00e1\"ln\u00adx\bd\u00c5\u00ebk\u00cd\u0005\u009f&@Q\u0097\u00dcR4/\u0010qLg\u0099\u00bb\u00e5\u0096c\u00e7\u00ce\u00e6\u00fa\u009c\u0083%\u00f1\u0097P\u001f8\u00ee2\u00f7{\u00dd:fS\u00bd\u0001\u008b$.\u00beT\u00e2\u00b3\u000b\u0091\u0091b\u00e4\u009e\u0089\u00da\u00fc\u00f8>\u009f\u0002L4!\u001e*\u00bd\u00919M\u0013\u00d6\u0016\u00f02\u009b\u00d2=\u00fc\u00d8\u00f1b\u0010\u0015~*j\u00d8,70x\u00bc\u00f9\u0004\u00f8pe\u00ed\u008e\u0004\u00b4\u00d8\u00ba\u00da\u00df\u0001\u00d27\u0003\u00b4m\u0002L\u00da\u0005\u00ba\u0090\u00eb\u00c0(\u00b6h\u00e2\n\f\u00f3\u00e3\u00b5\u00c1Y\u00fa$\u0016\u0092L\u0083j\u009d\u00f5\u0010,\u0002%\u00e5D5\u0011a6;W\u00c3\u00bfY\u00ac_B\u009dE\u009c\u00d5 \u0085\u00dd\u0084";
                    var10_15 = "\u0015[\u008e\n\u00fd&\u009ab\u000fF\u00c8\n2y\u00e5\u00e31s\u00abS\u00f0\u0088\u00feG\u00fc\u00d3\u00e7\u00c9\u00f1Vt\u00afiZ\u00a1\u009aC\u008f\f\rZ\u00aez\b\u009a)\u00e1\"ln\u00adx\bd\u00c5\u00ebk\u00cd\u0005\u009f&@Q\u0097\u00dcR4/\u0010qLg\u0099\u00bb\u00e5\u0096c\u00e7\u00ce\u00e6\u00fa\u009c\u0083%\u00f1\u0097P\u001f8\u00ee2\u00f7{\u00dd:fS\u00bd\u0001\u008b$.\u00beT\u00e2\u00b3\u000b\u0091\u0091b\u00e4\u009e\u0089\u00da\u00fc\u00f8>\u009f\u0002L4!\u001e*\u00bd\u00919M\u0013\u00d6\u0016\u00f02\u009b\u00d2=\u00fc\u00d8\u00f1b\u0010\u0015~*j\u00d8,70x\u00bc\u00f9\u0004\u00f8pe\u00ed\u008e\u0004\u00b4\u00d8\u00ba\u00da\u00df\u0001\u00d27\u0003\u00b4m\u0002L\u00da\u0005\u00ba\u0090\u00eb\u00c0(\u00b6h\u00e2\n\f\u00f3\u00e3\u00b5\u00c1Y\u00fa$\u0016\u0092L\u0083j\u009d\u00f5\u0010,\u0002%\u00e5D5\u0011a6;W\u00c3\u00bfY\u00ac_B\u009dE\u009c\u00d5 \u0085\u00dd\u0084".length();
                    var7_16 = 0;
                    while (true) {
                        var12_17 = var9_14.substring(var7_16, var7_16 += 8).getBytes("ISO-8859-1");
                        v10 = var11_12;
                        v11 = var8_13++;
                        v12 = ((long)var12_17[0] & 255L) << 56 | ((long)var12_17[1] & 255L) << 48 | ((long)var12_17[2] & 255L) << 40 | ((long)var12_17[3] & 255L) << 32 | ((long)var12_17[4] & 255L) << 24 | ((long)var12_17[5] & 255L) << 16 | ((long)var12_17[6] & 255L) << 8 | (long)var12_17[7] & 255L;
                        v13 = -1;
                        break block22;
                        break;
                    }
lbl81:
                    // 1 sources

                    while (true) {
                        v10[v11] = v14;
                        if (var7_16 < var10_15) ** continue;
                        var9_14 = "ggd\f`\u00b4x\u0017/\u00e3\u00e9\u001e\u00d0\u00f2\u00fd\u00c0";
                        var10_15 = "ggd\f`\u00b4x\u0017/\u00e3\u00e9\u001e\u00d0\u00f2\u00fd\u00c0".length();
                        var7_16 = 0;
                        while (true) {
                            var12_17 = var9_14.substring(var7_16, var7_16 += 8).getBytes("ISO-8859-1");
                            v10 = var11_12;
                            v11 = var8_13++;
                            v12 = ((long)var12_17[0] & 255L) << 56 | ((long)var12_17[1] & 255L) << 48 | ((long)var12_17[2] & 255L) << 40 | ((long)var12_17[3] & 255L) << 32 | ((long)var12_17[4] & 255L) << 24 | ((long)var12_17[5] & 255L) << 16 | ((long)var12_17[6] & 255L) << 8 | (long)var12_17[7] & 255L;
                            v13 = 0;
                            break block22;
                            break;
                        }
                        break;
                    }
lbl94:
                    // 1 sources

                    while (true) {
                        v10[v11] = v14;
                        if (var7_16 < var10_15) ** continue;
                        break block23;
                        break;
                    }
                }
                var13_18 = v12;
                var15_19 = var5_10.doFinal(new byte[]{(byte)(var13_18 >>> 56), (byte)(var13_18 >>> 48), (byte)(var13_18 >>> 40), (byte)(var13_18 >>> 32), (byte)(var13_18 >>> 24), (byte)(var13_18 >>> 16), (byte)(var13_18 >>> 8), (byte)var13_18});
                v14 = ((long)var15_19[0] & 255L) << 56 | ((long)var15_19[1] & 255L) << 48 | ((long)var15_19[2] & 255L) << 40 | ((long)var15_19[3] & 255L) << 32 | ((long)var15_19[4] & 255L) << 24 | ((long)var15_19[5] & 255L) << 16 | ((long)var15_19[6] & 255L) << 8 | (long)var15_19[7] & 255L;
                switch (v13) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl107:
                    // 1 sources

                    ** continue;
                }
            }
            ESP.N = var11_12;
            ESP.O = new Integer[30];
            var0_20 = Cipher.getInstance("DES/CBC/NoPadding");
            v15 = SecretKeyFactory.getInstance("DES");
            v16 = new byte[8];
            v17 = v16;
            v16[0] = (byte)(var16 >>> 56);
            for (var1_21 = 1; var1_21 < 8; ++var1_21) {
                v17 = v17;
                v17[var1_21] = (byte)(var16 << var1_21 * 8 >>> 56);
            }
            break block24;
lbl121:
            // 1 sources

            while (true) {
                continue;
                break;
            }
        }
        var0_20.init(2, (Key)v15.generateSecret(new DESKeySpec(v17)), new IvParameterSpec(new byte[8]));
        var2_22 = -5395376220489943041L;
        var4_23 = var0_20.doFinal(new byte[]{(byte)(var2_22 >>> 56), (byte)(var2_22 >>> 48), (byte)(var2_22 >>> 40), (byte)(var2_22 >>> 32), (byte)(var2_22 >>> 24), (byte)(var2_22 >>> 16), (byte)(var2_22 >>> 8), (byte)var2_22});
        ** while (true)
        ESP.Q = ((long)var4_23[0] & 255L) << 56 | ((long)var4_23[1] & 255L) << 48 | ((long)var4_23[2] & 255L) << 40 | ((long)var4_23[3] & 255L) << 32 | ((long)var4_23[4] & 255L) << 24 | ((long)var4_23[5] & 255L) << 16 | ((long)var4_23[6] & 255L) << 8 | (long)var4_23[7] & 255L;
    }

    private static r a(r value) {
        return value;
    }

    private static String b(byte[] byArray) {
        int outIndex = 0;
        int inputLength = byArray.length;
        char[] cArray = new char[inputLength];
        for (int index = 0; index < inputLength; ++index) {
            char ch;
            int byteValue = 0xFF & byArray[index];
            if (byteValue < 192) {
                cArray[outIndex++] = (char)byteValue;
                continue;
            }
            if (byteValue < 224) {
                ch = (char)((char)(byteValue & 0x1F) << 6);
                byteValue = byArray[++index];
                ch = (char)(ch | (char)(byteValue & 0x3F));
                cArray[outIndex++] = ch;
                continue;
            }
            if (index >= inputLength - 2) continue;
            ch = (char)((char)(byteValue & 0xF) << 12);
            byteValue = byArray[++index];
            ch = (char)(ch | (char)(byteValue & 0x3F) << 6);
            byteValue = byArray[++index];
            ch = (char)(ch | (char)(byteValue & 0x3F));
            cArray[outIndex++] = ch;
        }
        return new String(cArray, 0, outIndex);
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x3001;
        if (O[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = N[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])P.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    P.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/g/N", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            ESP.O[n3] = n4;
        }
        return O[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = ESP.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/N" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (S[n4] != null) {
            return n4;
        }
        Object object = R[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 52;
            case 1 -> 16;
            case 2 -> 18;
            case 3 -> 6;
            case 4 -> 25;
            case 5 -> 30;
            case 6 -> 40;
            case 7 -> 50;
            case 8 -> 3;
            case 9 -> 45;
            case 10 -> 41;
            case 11 -> 4;
            case 12 -> 53;
            case 13 -> 19;
            case 14 -> 54;
            case 15 -> 24;
            case 16 -> 38;
            case 17 -> 29;
            case 18 -> 5;
            case 19 -> 1;
            case 20 -> 62;
            case 21 -> 7;
            case 22 -> 57;
            case 23 -> 60;
            case 24 -> 49;
            case 25 -> 20;
            case 26 -> 51;
            case 27 -> 33;
            case 28 -> 8;
            case 29 -> 55;
            case 30 -> 58;
            case 31 -> 39;
            case 32 -> 12;
            case 33 -> 15;
            case 34 -> 48;
            case 35 -> 56;
            case 36 -> 31;
            case 37 -> 22;
            case 38 -> 21;
            case 39 -> 2;
            case 40 -> 59;
            case 41 -> 23;
            case 42 -> 37;
            case 43 -> 42;
            case 44 -> 10;
            case 45 -> 34;
            case 46 -> 32;
            case 47 -> 28;
            case 48 -> 27;
            case 49 -> 14;
            case 50 -> 11;
            case 51 -> 43;
            case 52 -> 46;
            case 53 -> 35;
            case 54 -> 61;
            case 55 -> 63;
            case 56 -> 44;
            case 57 -> 13;
            case 58 -> 47;
            case 59 -> 0;
            case 60 -> 36;
            case 61 -> 26;
            case 62 -> 17;
            default -> 9;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        ESP.S[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = R;
        R[0] = "x9CZ\t[s9EZ&";
        objectArray[1] = "~:;|Jdr:(";
        objectArray[2] = "W\u0005\u0017\u0015\u0015]^\u0005\u0014\u0015\u0011";
        objectArray[3] = "Kw\u0016\u001e\feVbN<MhNd";
        objectArray[4] = "1\u0016C*E5:\u0016E*E_";
        objectArray[5] = "\u007f\u001f";
        objectArray[6] = "bM?pN<kM<pB";
        objectArray[7] = "EM\u001d6A/LM:";
        objectArray[8] = "oF]\u0000y\u0017\u001afV\u000fhX{h]\u0004l\u0002\u000f";
        objectArray[9] = Integer.TYPE;
        ESP.S[9] = "java/lang/Integer";
        objectArray[10] = "\u0013\u001eb%g/\u001a\u001ea%g";
        objectArray[11] = "9D\u000fhT\u00042K\u001e'5\n9@\u001a}";
        objectArray[12] = "?\u0013K10\u0000J3@>!O+=K5%\u0015_";
        objectArray[13] = Float.TYPE;
        ESP.S[13] = "java/lang/Float";
        objectArray[14] = "Db\u001d)K&Mb\u001e)F";
        objectArray[15] = "C\\\u000b1\u000bz6|\u0000>\u001a5Wr\u000b5\u001eo#";
        objectArray[16] = "jN\f\u001fn\u000ecN\u000f\u001fl";
        objectArray[17] = "QX\u001f!OTZX\u0014";
        objectArray[18] = Boolean.TYPE;
        ESP.S[18] = "java/lang/Boolean";
        objectArray[19] = "=$\u0014\u001e p#,\u000eQ]`#";
        objectArray[20] = "\u000e3C\u001eg+{\u0013H\u0011vd\u001a\u001dC\u001ar>n";
        objectArray[21] = "W#\u001cn\u000ex\\#\u001an\u0003";
        objectArray[22] = "xkT\u0014LAsk\\";
        objectArray[23] = "x=4\u000e\u000fOq=7\u000e\u0006";
        objectArray[24] = "\u0017!||\bF\u001c!z|\u0004";
        objectArray[25] = "@+C\u000briK+D\u000b{";
        objectArray[26] = "\u001c@m\nOzi`f\u0005^5\bnm\u000eZo|";
        objectArray[27] = Void.TYPE;
        ESP.S[27] = "java/lang/Void";
        objectArray[28] = "T8\u001b\tOk!\u0018\u0010\u0006^$@\u0016\u001b\rZ~4";
        objectArray[29] = "}\u0010]i\u0004q\b0Vf\u0015>i>]m\u0011d\u001d";
        objectArray[30] = "Qw\\L\u000f'$WWC\u001ehEY\\H\u001a21";
        objectArray[31] = ":l~B\u007f(+lY";
        objectArray[32] = "\u0003\u0012g\fA:\b\u001dvC<\"\u001b\u001a\u007f\n";
        objectArray[33] = "\r\r-\u0005%Vx-&\n4\u0019\u0019#-\u00010Cm";
        objectArray[34] = "\u000efKN\u0011,{F@A\u0000c\u001aHKJ\u00049n";
        objectArray[35] = "a6:\u0003*\u001eclzl%g+3a\u0000}\b=vnl<X0`;\u0003*\u001d?\f";
        objectArray[36] = "t\rO3\b8vW\u000f\\\u0007A)\n\u0003e\u001ep/WN&n-q]\u0005>\u0015$<[\u0004\\";
        objectArray[37] = "\u000bora6\u001f\t52\u000e\u001cf[k!qj\u0017\r;)o";
        objectArray[38] = "Z\u000b\u0006\\`EXQF3I<\\VT_aF\u0000\rS\u000f";
        objectArray[39] = "B\u0007\u000b0\u0002\u0012@]K_\u0019k\u0012\u0003X ^\u001aDSP>";
        objectArray[40] = "SA7a_\\Q\u001bw\u000eG%U\u001ceb^_\tGb2";
        objectArray[41] = "?Tm&<k=\u000e-I\u001a\u0012iQ738i`\u001c12";
        objectArray[42] = "~XhOr-|\u0002( ^T}\u0005e[%,)\u00197\u0010";
        objectArray[43] = "\u00056I>\u001f?\u0007l\tQ2F\u0003k\u001b=\u001e<_0\u001cm";
        objectArray[44] = "r\u000f(\fR(pUhcRQ\"\u000b{\u001c\u000e t[s\u0002";
        objectArray[45] = "[.yr[M\n0g58&j\u0004ULs}[.yr[M\n0g5";
        objectArray[46] = ";2*um$9v(r\u0012 \u0006lj`+:7j7-hJ8q5g|.>w)!\u0012";
        objectArray[47] = "Qp|\u00191MS,\"\\\u0000C>,~\u001c9Y\u000f*#Qz)RwzP|HB0&Q\u0000";
        objectArray[48] = "\u0013(?u0i\u0011r\u007f\u001a/\u0010C,lela\u0015|d{";
        objectArray[49] = "?C%\f,\u0003c_1\fB\u0015\u0000\u0011+\u001a8\u0007\u007fA<\u0018:|";
        objectArray[50] = "3\u001b\u0016\"t\u00061AVM{\u007fn\u001cZtbNhA\u00177\u0012N2\u001cH#k\u0001{\u001eBM";
        objectArray[51] = "\u0001}\u001d+u\u001d\u0003']DRd\u0005=O?}\u0000\u0003;Sy";
        objectArray[52] = "\u00190i!S\u000f\u001bj)N\\vD7%wEGBjh45HYh\" QN_tdN";
        objectArray[53] = ":0m+/<8j-D9Ej4>;s4<d6%";
        objectArray[54] = ",\u0015YZ2S.O\u00195=*,\u0015YZ2S.O\u00195";
        objectArray[55] = "+y\\3\u001bE)#\u001c\\\u001a<{}\u000f#GM--\u0007=";
        objectArray[56] = "WOm\u001fYFZAg\u0017'xthF1}\"WOm\u001fYFZAg\u0017";
        objectArray[57] = "\u0018'w>\f>\u001a}7Q\u0010GM&x([#Oz&m";
        objectArray[58] = "kw7TYwi-w;N\u000e;sdD\u0005\u007fm#lZ";
        objectArray[59] = "9\f\u0018[\u0019B;VX4\r;i\bKKEJ?XCU";
        objectArray[60] = " .\u0010p\u000f\\%mDj3<\u0000Vd^i<@\u007f\u0019+P[{zZ\u007fJ";
        objectArray[61] = "bw=cH+`-}\fBR?pq5^c9-<v.>dt=pO.#(<\f";
        objectArray[62] = "<+\u00128TB>qRWI;l/A(\bJ:\u007fI6";
        objectArray[63] = "\u0018oGr$\u0015\u001a5\u0007\u001d:lHk\u0014bx\u001d\u001e;\u001c|";
        objectArray[64] = "\b+pq2\u0018\\7\":\u0003\t1v$32\u0012T\"=;~`";
        objectArray[65] = "z\u0005\u0012\u0013\u0013 }EO\u0012r{@C\u0001\t\u0003.)\n\u0019\u0006N\u0011";
        objectArray[66] = "@@\u0010sHzB\u001aP\u001cc\u0003\u0010DCc\u0014rF\u0014K}";
        objectArray[67] = "'M:5\u001d:!\ry7gnL\u001fycW~-\u000f>?V\u0002";
        objectArray[68] = "CG\u001a\u001bx~A\u001dZtP\u0007\u0013CI\u000b$vE\u0013A\u0015";
        objectArray[69] = "GH\u0005Aw\u0016LI\u001d\u0016J\u001a#T\nD*\u001fZM_I8sO\rX\u001b6\u0012_J\u0004\u001aJ";
        objectArray[70] = "&/pq#\\$u0\u001e %u|+f/A#h)o";
        objectArray[71] = "T<,UNUVfl:A,\t;`\u0003X\u001d\u000ff-@(@R?,FIP\u0015c-:";
        objectArray[72] = "r\u0016nap\u001fpL.\u000eif\"\u0012=q,\u0017tB5o";
        objectArray[73] = "\u007fLX4.#}\u0016\u0018[#Z\"K\u0014b8k$\u0016Y!Hd?\u0014\u00135,b9\bU[";
        objectArray[74] = "\\\u0014\u007f,\u0005\f^N?C*u\u000fG$;\t\u0011YS&2";
        objectArray[75] = "/Z$Z.Q-\u0000d54(\u007f^wJrY)\u000e\u007fT";
        objectArray[76] = "S-J\n\u000f\u0016\b3H\u001cn@3+\u0005\u0010WY\u0002-X]\u0014)Q S\u0012\u000eIH5CUn";
        Object[] objectArray2 = objectArray;
        objectArray[77] = "\u0006d\n\u001a?v\u0000$I\u0018E*m=H\t|>\\;\u0015D?N\u000f6\u001e\u000b%.\u0016#\u000eLE";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = ESP.e(l2, l3);
            object = R[n2];
            try {
                if (!(object instanceof String)) break block2;
                ESP.R[n2] = clazz = Class.forName(S[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = ESP.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int index = 0; index < classArray.length; ++index) {
                field = ESP.d(classArray[index], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = ESP.e(l2, l3);
        Object object = R[n2];
        if (object instanceof String) {
            String string = S[n2];
            int n3 = string.indexOf(8);
            Class clazz = ESP.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = ESP.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = ESP.c(clazz3, string2, clazz2)) != null) {
                    ESP.R[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int index = 0; index < classArray.length; ++index) {
                        field = ESP.d(classArray[index], string2, clazz2);
                        if (field == null) continue;
                        ESP.R[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = ESP.f(801020641909669L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int parameterCount, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != parameterCount) continue;
            for (int index = 0; index < parameterCount; ++index) {
                if (classArray2[index] != classArray[index]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int parameterCount, Class[] classArray) {
        Method method = ESP.c(clazz, string, clazz2, parameterCount, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int index = 0; index < classArray2.length; ++index) {
                method = ESP.d(classArray2[index], string, clazz2, parameterCount, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = ESP.e(l2, l3);
        Object object = R[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = S[n2];
                int n4 = string2.indexOf(8);
                clazz3 = ESP.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int paramIndex = 0; paramIndex < n6; ++paramIndex) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = ESP.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (paramIndex < n3) {
                        classArray2[paramIndex] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = ESP.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        ESP.R[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = ESP.f(801020641909669L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = ESP.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        ESP.R[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = ESP.f(801020641909669L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == 'v' || c2 == '\u00f6' || c2 == '\u00d4' || c2 == '\u00f3') {
                field = ESP.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == 'v' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == '\u00f6' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == '\u00d4' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = ESP.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == '\u00dd' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == '\u00d3' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = ESP.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/N" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(ESP.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(ESP.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

