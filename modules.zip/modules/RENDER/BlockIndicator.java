// === Kuzi module: BlockIndicator ===
// Category   : RENDER
// Description: Outlines the block you're looking at and smoothly follows your aim
// Payload    : a.a.a.j.g.I (verified: False)

package kuzi.modules.render;

import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.b.e;
import kuzi.obf.h.b.v;
import kuzi.obf.m.r;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;

public final class BlockIndicator
extends BaseModule {
    private final BoolSetting outline;
    private final BoolSetting fill;
    private final SliderSetting fillOpacity;
    private final SliderSetting speed;
    private final BoolSetting realShape;
    private final e color;
    private boolean s;
    private double t;
    private double u;
    private double v;
    private double w;
    private double x;
    private double y;
    private static final long z;
    private static final String[] A;
    private static final String[] B;
    private static final Map C;
    private static final long[] D;
    private static final Integer[] E;
    private static final Map F;
    private static final Object[] G;
    private static final String[] H;

    public BlockIndicator() {
        long l2;
        long l3 = l2 = z ^ 0x63DC0FF87043L;
        long l4 = l3 ^ 0x7B7FF4259E35L;
        long l5 = l3 ^ 0x1E5C60F95FE0L;
        super("Block Indicator", "Outlines the block you're looking at and smoothly follows your aim", Category.RENDER);
        this.outline = new BoolSetting("Outline", true);
        this.fill = new BoolSetting("Fill", true);
        this.fillOpacity = new SliderSetting("Fill Opacity", 40.0, 0.0, 255.0, 5.0);
        this.speed = new SliderSetting("Speed", 0.35, 0.02, 1.0, 0.01);
        this.realShape = new BoolSetting("Real Shape", true);
        this.color = new e("Color", new Color(120, 190, 255));
        this.s = false;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.outline, this.fill, this.fillOpacity, this.speed, this.realShape, this.color};
        objectArray[0] = l5;
        this.l(objectArray);
        WorldRenderEvents.END_MAIN.register(arg_0 -> this.a(l4, arg_0));
    }

    @Override
    public void e() {
        this.s = false;
    }

    @Override
    public void h() {
        this.s = false;
    }

    /*
     * Exception decompiling
     */
    private void a(long var1_1, WorldRenderContext var3_2) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Statement already marked as first in another block
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.markFirstStatementInBlock(Op03SimpleStatement.java:461)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc.markWholeBlock(Misc.java:251)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.considerAsSimpleIf(ConditionalRewriter.java:673)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.identifyNonjumpingConditionals(ConditionalRewriter.java:56)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:722)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private static int a(Object[] objectArray) {
        int result;
        block6: {
            int clamped;
            long l2;
            block4: {
                int value;
                block5: {
                    value = (Integer)objectArray[0];
                    l2 = (Long)objectArray[1];
                    l2 = z ^ l2;
                    CallSite callSite = BlockIndicator.d("\u00f6", (long)2658480363046850057L, (long)l2);
                    try {
                        try {
                            clamped = value;
                            if (callSite == null) break block4;
                            if (clamped >= 0) break block5;
                        }
                        catch (r r2) {
                            throw BlockIndicator.d("\u00f6", (Object)r2, (long)2658450104061272147L, (long)l2);
                        }
                        result = 0;
                        break block6;
                    }
                    catch (r r3) {
                        throw BlockIndicator.d("\u00f6", (Object)r3, (long)2658450104061272147L, (long)l2);
                    }
                }
                clamped = value;
            }
            result = Math.min(clamped, (int)BlockIndicator.c("f", (int)9751, (long)(0x335DCC618602CF43L ^ l2)));
        }
        return result;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block21: {
            block20: {
                block19: {
                    block18: {
                        BlockIndicator.z = kuzi.obf.h.b.v.a(-5999889916796860272L, -5889866967974181429L, MethodHandles.lookup().lookupClass()).a(60008470749252L);
                        BlockIndicator.G = new Object[46];
                        BlockIndicator.H = new String[46];
                        BlockIndicator.c();
                        BlockIndicator.C = new HashMap<K, V>(13);
                        var11 = BlockIndicator.z ^ 45446147272784L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[8];
                        var18_4 = 0;
                        var17_5 = "\u0014\u00a9\u0093h\u00d8\u008d\u0085\u00b3\u00e1\u0017\u00ab`t\u00dc,E\u0010\u0010A\u00d0\u0011\u0018\u00d3B\u00b0s\u00d8_6w@\u00a9:\u0010\u00bb\u0019\u00913\u009c\u00dd\u000fJ\u0007RY!!|k\u009d VJ\u008a\u0013\u00f1}\u00a5v<}\u00e7\u00c7\u00d0\u00ed^\u00e4\u00d9\u00c0\u00cd\u009c\u00eb\u00c9h\u00f9&[\u00f9\u001f\u009d\u0012\u00d6\u0003 T\u00e1\u0088\u00e2\u0010.qaq\u00ae\u00caEl@\u00fa\u0089m\u00c9\u0088\u0097\u008d\n[V+>\u00c4$\u00d7i!/ \u001f\u00ea\u0011x\u00a2\u008dq\u00f6\rUS\u00d1\u00e4\u0018\u001f\u00ce\u0013:\u0094=\u00aeB\u00b5\u00capx\u00dal\u00e9\u0010\u00f5\u00e8";
                        var19_6 = "\u0014\u00a9\u0093h\u00d8\u008d\u0085\u00b3\u00e1\u0017\u00ab`t\u00dc,E\u0010\u0010A\u00d0\u0011\u0018\u00d3B\u00b0s\u00d8_6w@\u00a9:\u0010\u00bb\u0019\u00913\u009c\u00dd\u000fJ\u0007RY!!|k\u009d VJ\u008a\u0013\u00f1}\u00a5v<}\u00e7\u00c7\u00d0\u00ed^\u00e4\u00d9\u00c0\u00cd\u009c\u00eb\u00c9h\u00f9&[\u00f9\u001f\u009d\u0012\u00d6\u0003 T\u00e1\u0088\u00e2\u0010.qaq\u00ae\u00caEl@\u00fa\u0089m\u00c9\u0088\u0097\u008d\n[V+>\u00c4$\u00d7i!/ \u001f\u00ea\u0011x\u00a2\u008dq\u00f6\rUS\u00d1\u00e4\u0018\u001f\u00ce\u0013:\u0094=\u00aeB\u00b5\u00capx\u00dal\u00e9\u0010\u00f5\u00e8".length();
                        var16_7 = 16;
                        var15_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block18;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = BlockIndicator.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "\u00e2m\u00f0\u00ccY\u0085\u00cd\u00ca\u0013@\u00a0\u0010\u0083\u0091`G\u00b6\u00b7\u0018\u00f6C\u00ed\u009f\u0005X\u00f0\u001aD\u0017\u001dc\u00b0o\u00d4=[C@\u00f8\u00b6\u00c2\u00e8\b\u0083\u00c08\u0080\u001f\u00c8\u00fd\u00ae\t\u009b\u00b8Z\u00d4\u00ae\u00ee\u00b8\u0003\u00ec=|<= \u009f\u0005\u00f5\u000fjF\u00b4\u000eH%\u00e6\u00e7\u00d9B\u00e06\u009e \u00d4\u0017\u00b9\u0086\u00b69\u00da\u00fb\u00dc6\u001dTP\u00cc\u0098\u00fd\u00fc\u00a9:!g.\u00ff(j\u0095\u00e2\u0093\u0010\u0083a\u00ee\u00bb\u001d\u00af\u0015\u007fT\u0092\u0099\u008d\u0000\u0017il";
                            var19_6 = "\u00e2m\u00f0\u00ccY\u0085\u00cd\u00ca\u0013@\u00a0\u0010\u0083\u0091`G\u00b6\u00b7\u0018\u00f6C\u00ed\u009f\u0005X\u00f0\u001aD\u0017\u001dc\u00b0o\u00d4=[C@\u00f8\u00b6\u00c2\u00e8\b\u0083\u00c08\u0080\u001f\u00c8\u00fd\u00ae\t\u009b\u00b8Z\u00d4\u00ae\u00ee\u00b8\u0003\u00ec=|<= \u009f\u0005\u00f5\u000fjF\u00b4\u000eH%\u00e6\u00e7\u00d9B\u00e06\u009e \u00d4\u0017\u00b9\u0086\u00b69\u00da\u00fb\u00dc6\u001dTP\u00cc\u0098\u00fd\u00fc\u00a9:!g.\u00ff(j\u0095\u00e2\u0093\u0010\u0083a\u00ee\u00bb\u001d\u00af\u0015\u007fT\u0092\u0099\u008d\u0000\u0017il".length();
                            var16_7 = 112;
                            var15_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block18;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = BlockIndicator.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block19;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                BlockIndicator.A = var20_3;
                BlockIndicator.B = new String[8];
                BlockIndicator.F = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[8];
                var3_13 = 0;
                var4_14 = "\f\u00b6$\u00fc\u00f2G\u0012\u0000\u00f86\u0097\u00d3\u00dc\u00c8\u009e\t\u008a6>\u008d\u00a1\u0000\u00b3n\u0096\u00f0\f\u00d2i3\u00f7_\u00de8\u0004\u00a1\u00a2+f\u00abf\u00ddF\u00f2%\u00bc0\u00d7";
                var5_15 = "\f\u00b6$\u00fc\u00f2G\u0012\u0000\u00f86\u0097\u00d3\u00dc\u00c8\u009e\t\u008a6>\u008d\u00a1\u0000\u00b3n\u0096\u00f0\f\u00d2i3\u00f7_\u00de8\u0004\u00a1\u00a2+f\u00abf\u00ddF\u00f2%\u00bc0\u00d7".length();
                var2_16 = 0;
                while (true) {
                    var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                    v10 = var6_12;
                    v11 = var3_13++;
                    v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                    v13 = -1;
                    break block20;
                    break;
                }
lbl81:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    var4_14 = "\u00f2\u00a7!\u0011\u0089o\n&\r\u0092\u00952\u0003\u00ed\u00faM";
                    var5_15 = "\u00f2\u00a7!\u0011\u0089o\n&\r\u0092\u00952\u0003\u00ed\u00faM".length();
                    var2_16 = 0;
                    while (true) {
                        var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                        v10 = var6_12;
                        v11 = var3_13++;
                        v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                        v13 = 0;
                        break block20;
                        break;
                    }
                    break;
                }
lbl94:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    break block21;
                    break;
                }
            }
            var8_18 = v12;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            v14 = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
            switch (v13) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl107:
                // 1 sources

                ** continue;
            }
        }
        BlockIndicator.D = var6_12;
        BlockIndicator.E = new Integer[8];
    }

    private static Throwable a(Throwable throwable) {
        return throwable;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x4DB3;
        if (E[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = D[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])F.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    F.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/g/I", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            BlockIndicator.E[n3] = n4;
        }
        return E[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = BlockIndicator.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/I" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (H[n4] != null) {
            return n4;
        }
        Object object = G[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 38;
            case 1 -> 1;
            case 2 -> 25;
            case 3 -> 63;
            case 4 -> 48;
            case 5 -> 46;
            case 6 -> 13;
            case 7 -> 24;
            case 8 -> 52;
            case 9 -> 14;
            case 10 -> 22;
            case 11 -> 27;
            case 12 -> 19;
            case 13 -> 32;
            case 14 -> 42;
            case 15 -> 9;
            case 16 -> 23;
            case 17 -> 33;
            case 18 -> 60;
            case 19 -> 49;
            case 20 -> 15;
            case 21 -> 47;
            case 22 -> 40;
            case 23 -> 8;
            case 24 -> 54;
            case 25 -> 7;
            case 26 -> 56;
            case 27 -> 55;
            case 28 -> 37;
            case 29 -> 16;
            case 30 -> 45;
            case 31 -> 44;
            case 32 -> 12;
            case 33 -> 50;
            case 34 -> 26;
            case 35 -> 11;
            case 36 -> 2;
            case 37 -> 62;
            case 38 -> 34;
            case 39 -> 0;
            case 40 -> 29;
            case 41 -> 58;
            case 42 -> 3;
            case 43 -> 35;
            case 44 -> 6;
            case 45 -> 39;
            case 46 -> 5;
            case 47 -> 17;
            case 48 -> 30;
            case 49 -> 10;
            case 50 -> 28;
            case 51 -> 53;
            case 52 -> 31;
            case 53 -> 41;
            case 54 -> 20;
            case 55 -> 21;
            case 56 -> 59;
            case 57 -> 4;
            case 58 -> 43;
            case 59 -> 57;
            case 60 -> 36;
            case 61 -> 18;
            case 62 -> 51;
            default -> 61;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        BlockIndicator.H[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = G;
        G[0] = "q1b\u0014\u001bgz1d\u00143";
        objectArray[1] = "\u001fEyJ1U\u0016EzJ3";
        objectArray[2] = "jLlM\u0003\u001aaLd";
        objectArray[3] = Boolean.TYPE;
        BlockIndicator.H[3] = "java/lang/Boolean";
        objectArray[4] = "\u0002?\u0001|,v\u000b?\u0002| ";
        objectArray[5] = "^\tzz\rAW\tyz\t";
        objectArray[6] = "\nt.3b+\u0001t%";
        objectArray[7] = "7\t;7=kB)08,$#';3(~W";
        objectArray[8] = Void.TYPE;
        BlockIndicator.H[8] = "java/lang/Void";
        objectArray[9] = "#Al&B=Vag)Sr7ol\"W(C";
        objectArray[10] = Integer.TYPE;
        BlockIndicator.H[10] = "java/lang/Integer";
        objectArray[11] = Double.TYPE;
        BlockIndicator.H[11] = "java/lang/Double";
        objectArray[12] = "\u0001_'[F'\u001cJ\u007fy\u0007*\u0004L";
        objectArray[13] = "tE\u0002X#t\u007fE\u0004X#\u001e";
        objectArray[14] = "Qa";
        objectArray[15] = "|ZO\u000b\u007f\\wU^D\u0005XdTN\u000b3\\s";
        objectArray[16] = "/@\u0011`\u001bT&@7";
        objectArray[17] = "A'&\u0011GL4\u0007-\u001eV\u0003U\t&\u0015RY!";
        objectArray[18] = "<F9D\no5F:D\n";
        objectArray[19] = "I\u000e\u0012\u0013V*B\u0001\u0003\\7$I\n\u0007\u0006";
        objectArray[20] = "5$O\u000f'h<$h";
        objectArray[21] = "9RUp0bLr^\u007f!--|Ut%wY";
        objectArray[22] = "p\u000eaw\u0018SkWiM\u000ek/S)3\u0004\u000eqRk-";
        objectArray[23] = "\u0010\u0013\"\u000ff%DL|K\u001f\u0010d:P<EJ\u0010\u0013\"\u000ff%DL|K";
        objectArray[24] = "\u0017\u001d-RhX\fD%hq`\u001c\u00058Vd\u0010\t\u0011e\f\u0018_\u0015B:\u0001}\u0011\u0000\u00188h";
        objectArray[25] = "\u00054}JGQ\u001emupJi\\*t\u000f\b\u001b\u000673L";
        objectArray[26] = "[D)\u0010\\v@\u001d!*WN\u0007F:FP,EL(A";
        objectArray[27] = "$rv{su?+~A{Mxoxydq#lk(";
        objectArray[28] = "K\u0019\u0013\n\u0019\\P@\u001b0\u0019d\u0012\u0007\u001aOV\u0016H\u001a]\f";
        objectArray[29] = ",m;1l2u1- \u0013c\u0010e&=b2a,:%w\n";
        objectArray[30] = "\\ck~@q\u001f:u:;*mmo7[|\u0013`:>Y@";
        objectArray[31] = "TjI94CO3A\u0003-{[r\tr%EMc_{D\u0012M<Ibz\u0004\\j@\u0003";
        objectArray[32] = "\f\u0006 r\u001fuRD*s}\"0D?.\u00112R\u00065<\u0016N";
        objectArray[33] = "qVs\u0016\n\nj\u000f{,\u001d2-K}\u0014\u001d\u000evHnE";
        objectArray[34] = "UZ@9),N\u0003H\u0003#\u0014\u000f\u0005Wm&,VYA|";
        objectArray[35] = "E%\u0001\u0018\u0018.^|\t\"\u0011\u0016\u001axI\\\u0004sDy\u000bB";
        objectArray[36] = "\"4Omoj9mGWzR}i\u0007)s7#hE7";
        objectArray[37] = "YZF\u0013j6\\\u0005\u0016\u0001\u001123V\b\u001a/$CC\u001cGuX\u000eK\u000b\u000ezbJ\u0002\u0010\u001e\u0011";
        objectArray[38] = "P1K\u0012u]KhC({e\t/BW:\u0017S2\u0005\u0014";
        objectArray[39] = "F$TEh7C{\u0004W\u00132H\"\u001eE\u0013d\\9\u0015C) \u0015\"\u0005(";
        objectArray[40] = "r((]'niq g&V+6!\u0018h$q+f[";
        objectArray[41] = "x\u0001.&-PcX&\u001c!h!\u001f'cb\u001a{\u0002` ";
        objectArray[42] = "0\u0015\u0006`\"\u0012>\u0015\u0005uSG\\@\r|(JeR\u001dtn.";
        objectArray[43] = "F4Id\nB]mA^\u0005z\u001f*@!E\bE7\u0007b";
        objectArray[44] = "e60L#\u0010c&*LN\u000b\t)4Dp\u001ey< \u0019*bc%zM5\ffz*_N";
        Object[] objectArray2 = objectArray;
        objectArray[45] = "\u000fu(f]|Q7\"g?#3`-<\u0001;Cu9a[G\u000e}.(T}J458?";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = BlockIndicator.e(l2, l3);
            object = G[n2];
            try {
                if (!(object instanceof String)) break block2;
                BlockIndicator.G[n2] = clazz = Class.forName(H[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = BlockIndicator.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = BlockIndicator.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = BlockIndicator.e(l2, l3);
        Object object = G[n2];
        if (object instanceof String) {
            String string = H[n2];
            int n3 = string.indexOf(8);
            Class clazz = BlockIndicator.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = BlockIndicator.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = BlockIndicator.c(clazz3, string2, clazz2)) != null) {
                    BlockIndicator.G[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = BlockIndicator.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        BlockIndicator.G[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = BlockIndicator.f(1375431666915713L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = BlockIndicator.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = BlockIndicator.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = BlockIndicator.e(l2, l3);
        Object object = G[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = H[n2];
                int n4 = string2.indexOf(8);
                clazz3 = BlockIndicator.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = BlockIndicator.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = BlockIndicator.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        BlockIndicator.G[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = BlockIndicator.f(1375431666915713L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = BlockIndicator.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        BlockIndicator.G[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = BlockIndicator.f(1375431666915713L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == '\u00cb' || c2 == '\u00ca' || c2 == 'K' || c2 == 'm') {
                field = BlockIndicator.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == '\u00cb' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == '\u00ca' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == 'K' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = BlockIndicator.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == 'c' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == '\u00f6' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = BlockIndicator.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/I" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(BlockIndicator.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(BlockIndicator.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

