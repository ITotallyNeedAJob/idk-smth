// === Kuzi module: MobESP ===
// Category   : RENDER
// Description: Highlights all mobs and notifies you
// Payload    : a.a.a.j.g.aa (verified: False)

package kuzi.modules.render;

import java.awt.Color;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.b.e;
import kuzi.obf.j.f.k;
import kuzi.obf.j.g.aD;
import kuzi.obf.m.r;
import kuzi.obf.p.aw;
import kuzi.obf.p.x_0;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.LivingEntity;
import net.minecraft.Player;
import net.minecraft.Items;
import net.minecraft.ItemLike;
import net.minecraft.AABB;
import net.minecraft.Minecraft;
import net.minecraft.Toast;

public class MobESP
extends BaseModule {
    public final SliderSetting range;
    public final BoolSetting fill;
    public final BoolSetting outline;
    public final BoolSetting tracers;
    public final e q;
    public final e r;
    public final BoolSetting toastNotification;
    public final BoolSetting chatNotification;
    private final Set notifiedEntityIds;
    private long lastNotifyTime;
    private static final long w = 119543401803976L;
    private static final long notifyCooldownMs;
    private static final Object[] E;
    private static final String[] F;

    public MobESP() {
        long l2;
        long l3 = l2 = w ^ 0x3D5D032C3DFDL;
        long l4 = l3 ^ 0x24A256498C13L;
        long l5 = l3 ^ 0x700755AE5620L;
        super("MobESP", "Highlights all mobs and notifies you", Category.RENDER);
        this.range = new SliderSetting("Range", 50.0, 10.0, 200.0, 10.0);
        this.fill = new BoolSetting("Fill", true);
        this.outline = new BoolSetting("Outline", true);
        this.tracers = new BoolSetting("Tracers", false);
        this.q = new e("Fill Color", new Color(255, 0, 0, 102));
        this.r = new e("Outline Color", new Color(255, 0, 0, 255));
        this.toastNotification = new BoolSetting("Toast Notification", true);
        this.chatNotification = new BoolSetting("Chat Notification", true);
        this.notifiedEntityIds = new HashSet();
        this.lastNotifyTime = 0L;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.range, this.fill, this.outline, this.tracers, this.q, this.r, this.toastNotification, this.chatNotification};
        objectArray[0] = l5;
        this.l(objectArray);
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l4;
        k.a(objectArray2);
    }

    @Override
    public void i() {
        block11: {
            boolean setChanged;
            int[] nArray;
            long l2;
            long l3;
            long l4;
            block14: {
                block13: {
                    Minecraft client;
                    block12: {
                        long l5;
                        long l6 = l5 = w ^ 0x1F2FB51D9029L;
                        l4 = l6 ^ 0x6BA629DB54F8L;
                        l3 = l6 ^ 0x67E463D1069EL;
                        l2 = l6 ^ 0x6E977C80AFEL;
                        nArray = aD.b();
                        client = BaseModule.a;
                        if (nArray == null) break block12;
                        if (client.player == null) break block13;
                        client = BaseModule.a;
                    }
                    if (client.level != null) break block14;
                }
                return;
            }
            if (System.currentTimeMillis() - this.lastNotifyTime < notifyCooldownMs) {
                return;
            }
            this.lastNotifyTime = System.currentTimeMillis();
            AABB searchBox = new AABB(BaseModule.a.player.blockPosition()).inflate(((Double)this.range.a()).doubleValue());
            List nearbyMobs = BaseModule.a.level.getEntitiesOfClass(LivingEntity.class, searchBox, arg_0 -> MobESP.lambda$onTick$0(l3, arg_0));
            for (LivingEntity mob : nearbyMobs) {
                int entityId = mob.getId();
                setChanged = this.notifiedEntityIds.add(entityId);
                if (nArray != null) {
                    if (setChanged) {
                        String mobName = mob.getName().getString();
                        boolean notificationsOn = (Boolean)this.chatNotification.a();
                        if (nArray != null) {
                            if (notificationsOn) {
                                Object[] objectArray = new Object[2];
                                objectArray[1] = "Detected: " + mobName;
                                objectArray[0] = l2;
                                x_0.a(objectArray);
                            }
                            notificationsOn = (Boolean)this.toastNotification.a();
                        }
                        if (notificationsOn) {
                            BaseModule.a.getToastManager().addToast((Toast)new aw((ItemLike)Items.ZOMBIE_HEAD, "Mob ESP", "Found: " + mobName, false));
                        }
                    }
                    if (nArray != null) continue;
                }
                break block11;
            }
            setChanged = this.notifiedEntityIds.removeIf(arg_0 -> MobESP.lambda$onTick$1(l4, arg_0));
        }
    }

    @Override
    public void e() {
        this.notifiedEntityIds.clear();
    }

    public int a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = w ^ l2;
        return this.q.a().getRGB();
    }

    public int c(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = w ^ l2;
        return this.r.a().getRGB();
    }

    private static boolean lambda$onTick$1(long l2, Integer entityId) {
        l2 = w ^ l2;
        return BaseModule.a.level.getEntity(entityId.intValue()) == null;
    }

    private static boolean lambda$onTick$0(long l2, LivingEntity entity) {
        l2 = w ^ l2;
        int[] nArray = aD.b();
        boolean isMob = entity instanceof Player;
        if (nArray != null) {
            isMob = !isMob;
        }
        return isMob;
    }

    static {
        E = new Object[]{"w\u0012J\u001b_,|\u0012L\u001b_F", "j`", "}?+\bc\u0007v?-\bcH", "(d\b\t\u007fY$d\u001b", "21qulh,9k:\u0011x,", "rM(9[0yM ", Long.TYPE, "\u001aD0\u0016\u000f4\u0013D3\u0016\u000b", "\u0012}ch\u0013s\u001b}`h\u0011", "Z7ilf\u001aS7jlj", "\f(M\n~\u0004\u0007(J\nt", "\u0013XF\r\u000bYfxM\u0002\u001a\u0016\u0007vF\t\u001eLs", Void.TYPE, "\u001c_LNU\t\u0017_G", "U;x1Xb \u001bs>I-A\u0015x5Mw5", ";\u001aT/\"5&\u000f\f\rc8>\t", "\u0010=^N=\u0012\u0010=I\u00121\u001d\nvI\f1\b\r\u0007\u0019Q`", "\u001f9yI\u0019/\u000e9`", "\u0002} \u0019F;w]+\u0016Wt\u0016S \u001dS.b", "\u0012m!Y%\u0019\u001bm\"Y%", "|?1k;[w0 $ZU|;$~", "Z\u001d\u000f\u0018}\u001b\u001eL\u0010@A~+g.h\u001b$Z\u001d\u000f\u0018}\u001b\u001eL\u0010@", "\u0010r\u000e7J,\u0014(K<{%{$P)\u00111K$\f4\u0016LK*\b3\u00124\u0004uO {", "ek-xr$<e6(Ie\\2.;5|;t?=t", "}\u007fk/DS)oyl-DLut-VUqg+`@", "p6e8;8)8~h\u0000}Ioc7x{yjxif", "\u0019gV?iG@iMoR\u001e <\u0013em\u0005@|Pk.", "NLWl6@\u0017BL<\r\u0006w\u0015Qcu\u0003G\u0010J=k", "b\u0011+0tN;\u001f0`O\u0016[Jnjp\f;\n-d3", "\rNyneS\bU'p\u0019\n1Y6m{\bZ\u000f,lyc", "Z%\u000ek+CUy\u001e\u0019p!\u001eoDph[UpD\u0019", "6/mJH\u001eo!v\u001as]\u000ft(\u0010L\\o4k\u001e\u000f", "\u001f!>\u0006uGF/%VN\u001d&z V4I\u001f<v]/", "9S\u0001\u000b\u0004@`B\t\bxB\u0006W\n\u0011\u0012V6WV\f\u0015+6YR\u000b\u0011Sy\u0006\u0015\u0018x", ":\u0005\u001av\"ic\u000b\u0001&\u0019?\u0003Z\u0003pg$:\u001e\u00181cV9\u0001[7ko}\u001a\u001a3\u0019", "X\fV>\u001fD\u0001\u0002Mn$\u0006aR\u0014q\u0018E\u001f\u0002SsO", "\u0003lS\u0019<\\ZbHI\u0007\u001b:7\u0016C8\u001eZwUM{", "\u00058qg/4\u0010={aQ6i:0k.#Rf+t0_", "VN&VU\u0005\u000f@=\u0006nAo\u0015c\fQG\u000fU \u0002\u0012", ",x\u000e\u00172{xh\u001cT[a\u001ds\u0015\u00101x-sI\r6\u0005-}M\n2}b\"\n\u0019["};
        F = new String[]{null, null, null, null, null, null, "java/lang/Long", null, null, null, null, null, "java/lang/Void", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null};
        notifyCooldownMs = 2000L;
    }

    private static r a(r value) {
        return value;
    }

    private static Field findDeclaredField(Class ownerClass, String fieldName, Class fieldType) {
        for (Field field : ownerClass.getDeclaredFields()) {
            if (!field.getName().equals(fieldName) || field.getType() != fieldType) continue;
            return field;
        }
        return null;
    }

    private static Field findField(Class ownerClass, String fieldName, Class fieldType) {
        Field field = MobESP.findDeclaredField(ownerClass, fieldName, fieldType);
        if (field != null) {
            return field;
        }
        Class<?>[] interfaces = ownerClass.getInterfaces();
        if (interfaces != null) {
            for (int index = 0; index < interfaces.length; ++index) {
                field = MobESP.findField(interfaces[index], fieldName, fieldType);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method findDeclaredMethod(Class ownerClass, String methodName, Class returnType, int parameterCount, Class[] expectedParameterTypes) {
        block0: for (Method method : ownerClass.getDeclaredMethods()) {
            Class<?>[] parameterTypes;
            if (!method.getName().equals(methodName) || method.getReturnType() != returnType || (parameterTypes = method.getParameterTypes()).length != parameterCount) continue;
            for (int index = 0; index < parameterCount; ++index) {
                if (parameterTypes[index] != expectedParameterTypes[index]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method findMethod(Class ownerClass, String methodName, Class returnType, int parameterCount, Class[] expectedParameterTypes) {
        Method method = MobESP.findDeclaredMethod(ownerClass, methodName, returnType, parameterCount, expectedParameterTypes);
        if (method != null) {
            return method;
        }
        Class<?>[] interfaces = ownerClass.getInterfaces();
        if (interfaces != null) {
            for (int index = 0; index < interfaces.length; ++index) {
                method = MobESP.findMethod(interfaces[index], methodName, returnType, parameterCount, expectedParameterTypes);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }
}

