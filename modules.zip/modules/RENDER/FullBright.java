// === Kuzi module: FullBright ===
// Category   : RENDER
// Description: Makes everything bright
// Payload    : a.a.a.j.g.P (verified: False)

package kuzi.modules.render;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.j.g.aD;
import kuzi.obf.m.r;
import net.minecraft.MobEffectInstance;
import net.minecraft.MobEffects;
import net.minecraft.Holder;
import net.minecraft.LocalPlayer;

public class FullBright
extends BaseModule {
    private static final Object[] t = new Object[]{"\u0014^dhZ>\u001f^o", "|J\u0018Lx'|J\u000f\u0010t(f\u0001\u000f\u000et=ap_S%", "BO?\u001aAdIO9\u001aA\u000e", "%P", "\u0010\u0012\u000f\u000fe^\u001b\u0012\t\u000fT", "\r{ xE\u0013\u0001{3", "\u000b5m?<U\u00005e", "#[\u0014\u000eCr(T\u0005A\"|#_\u0001\u001b", "C3[y\u0017+\u0015oVxp\u00012\u0011s\t*[C3[y\u0017+\u0015oVx", "Gx\u0003PW\u0005G~\u0007Wh\u000b|z\u001e^P\u0013\u00113\u0018]\fbG8\u000e\u000f\u0019\u000f\u000e>\rSh", "\u001e\f\u001bVaf\u001b\u001dF:f\u0003AR\u0005\u0001el\u001bX\u0006\u000b", "}fi2\u0007>&~xyi2D-|y\u0014a(e\"0\u0005X"};

    public FullBright() {
        super("FullBright", "Makes everything bright", Category.RENDER);
    }

    @Override
    public void d() {
        super.d();
    }

    @Override
    public void e() {
        block3: {
            LocalPlayer player;
            block2: {
                int[] nArray = aD.b();
                super.e();
                int[] nArray2 = nArray;
                player = BaseModule.a.player;
                if (nArray2 == null) break block2;
                if (player == null) break block3;
                player = BaseModule.a.player;
            }
            player.removeEffect(MobEffects.NIGHT_VISION);
        }
    }

    @Override
    public void i() {
        block8: {
            MobEffectInstance effect;
            int[] nArray;
            block9: {
                MobEffectInstance effectInstance;
                Holder nightVision;
                LocalPlayer player;
                block6: {
                    block7: {
                        nArray = aD.b();
                        player = BaseModule.a.player;
                        if (nArray != null) {
                            if (player == null) {
                                return;
                            }
                            player = BaseModule.a.player;
                        }
                        nightVision = MobEffects.NIGHT_VISION;
                        if (nArray == null) break block6;
                        if (player.hasEffect(nightVision)) break block7;
                        BaseModule.a.player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 999999, 0, false, false, false));
                        if (nArray != null) break block8;
                    }
                    player = BaseModule.a.player;
                    nightVision = MobEffects.NIGHT_VISION;
                }
                effect = effectInstance = player.getEffect(nightVision);
                if (nArray == null) break block9;
                if (effect == null) break block8;
                effect = effectInstance;
            }
            int duration = effect.getDuration();
            if (nArray != null && duration < 200) {
                duration = BaseModule.a.player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 999999, 0, false, false, false)) ? 1 : 0;
            }
        }
    }

    private static r a(r r2) {
        return r2;
    }

    private static Field findDeclaredField(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field findFieldInHierarchy(Class clazz, String string, Class clazz2) {
        Field field = FullBright.findDeclaredField(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = FullBright.findFieldInHierarchy(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method findDeclaredMethod(Class clazz, String string, Class clazz2, int parameterCount, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != parameterCount) continue;
            for (int i2 = 0; i2 < parameterCount; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method findMethodInHierarchy(Class clazz, String string, Class clazz2, int parameterCount, Class[] classArray) {
        Method method = FullBright.findDeclaredMethod(clazz, string, clazz2, parameterCount, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = FullBright.findMethodInHierarchy(classArray2[i2], string, clazz2, parameterCount, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }
}

