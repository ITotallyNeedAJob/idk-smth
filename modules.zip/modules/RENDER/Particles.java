// === Kuzi module: Particles ===
// Category   : RENDER
// Description: Ambient particle field around you
// Payload    : a.a.a.j.g.ag (verified: True)

package kuzi.modules.render;

import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Random;
import java.util.concurrent.ConcurrentLinkedQueue;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.core.Client;
import kuzi.mixin.MixinExposed;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.module.Module;
import kuzi.obf.h.b.e;
import kuzi.obf.h.b.l;
import kuzi.obf.h.b.v;
import kuzi.obf.j.g.A;
import kuzi.obf.j.g.aD;
import kuzi.obf.j.g.ax;
import kuzi.obf.l.d.a;
import kuzi.obf.l.d.f;
import kuzi.obf.m.r;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.RenderTypes;
import net.minecraft.Entity;
import net.minecraft.Arrow;
import net.minecraft.ThrownEnderpearl;
import net.minecraft.ThrownTrident;
import net.minecraft.Vec3;
import net.minecraft.Minecraft;
import org.joml.Quaternionf;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class Particles
extends BaseModule
implements Module {
    private final e color;
    private final l physics;
    private final SliderSetting scale;
    private final SliderSetting amount;
    private final BoolSetting glow;
    private final BoolSetting cubes;
    private final BoolSetting crystals;
    private final BoolSetting pyramids;
    private final BoolSetting diamonds;
    private final BoolSetting rings;
    private final BoolSetting sparkles;
    private final BoolSetting idle;
    private final BoolSetting movement;
    private final BoolSetting pearlThrow;
    private final BoolSetting arrowShot;
    private final BoolSetting tridentThrow;
    private final BoolSetting totemPop;
    private static final double D = 0.04;
    private static final double E = 0.98;
    private static final double F = 0.004;
    private static final float G = 20.0f;
    private final List particleList;
    private final Queue spawnQueue;
    private final Random random;
    private static volatile Particles instance;
    private static final long L;
    private static final String[] M;
    private static final String[] N;
    private static final Map O;
    private static final long[] P;
    private static final Integer[] Q;
    private static final Map R;
    private static final Object[] S;
    private static final String[] T;

    public Particles() {
        long l2;
        long l3 = l2 = L ^ 0x2629B928E09L;
        long l4 = l3 ^ 0x39910E8AFCCFL;
        long l5 = l3 ^ 0x597B3779849AL;
        super("Particles", "Ambient particle field around you", Category.RENDER);
        this.color = new e("Color", new Color(120, 180, 255));
        this.physics = new l("Physics", kuzi.obf.j.g.A.FLY, A.class);
        this.scale = new SliderSetting("Scale", 0.3, 0.05, 1.5, 0.05);
        this.amount = new SliderSetting("Amount", 120.0, 20.0, 600.0, 10.0);
        this.glow = new BoolSetting("Glow", true);
        this.cubes = new BoolSetting("Cubes", true);
        this.crystals = new BoolSetting("Crystals", true);
        this.pyramids = new BoolSetting("Pyramids", false);
        this.diamonds = new BoolSetting("Diamonds", false);
        this.rings = new BoolSetting("Rings", false);
        this.sparkles = new BoolSetting("Sparkles", false);
        this.idle = new BoolSetting("Idle", true);
        this.movement = new BoolSetting("Movement", false);
        this.pearlThrow = new BoolSetting("Pearl Throw", false);
        this.arrowShot = new BoolSetting("Arrow Shot", false);
        this.tridentThrow = new BoolSetting("Trident Throw", false);
        this.totemPop = new BoolSetting("Totem Pop", false);
        this.particleList = new ArrayList();
        this.spawnQueue = new ConcurrentLinkedQueue();
        this.random = new Random();
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.color, this.physics, this.scale, this.amount, this.glow, this.cubes, this.crystals, this.pyramids, this.diamonds, this.rings, this.sparkles, this.idle, this.movement, this.pearlThrow, this.arrowShot, this.tridentThrow, this.totemPop};
        objectArray[0] = l5;
        this.l(objectArray);
        instance = this;
        WorldRenderEvents.END_MAIN.register(arg_0 -> this.renderParticles(l4, arg_0));
    }

    @MixinExposed
    public static void a(Entity entity) {
        block2: {
            boolean bl;
            Particles particles;
            block3: {
                Particles particles2;
                int[] nArray;
                block1: {
                    particles = instance;
                    nArray = aD.b();
                    particles2 = particles;
                    if (nArray == null) break block1;
                    if (particles2 == null) break block2;
                    particles2 = particles;
                }
                bl = particles2.d();
                if (nArray == null) break block3;
                if (!bl) break block2;
                bl = (Boolean)particles.C.a();
            }
            if (bl && entity != null) {
                particles.spawnQueue.add(entity.position().add(0.0, (double)entity.getBbHeight() / 2.0, 0.0));
            }
        }
    }

    @Override
    public void d() {
        super.d();
        Client.a().a(Module.class, this);
    }

    @Override
    public void e() {
        super.e();
        Client.a().b(Module.class, this);
        this.particleList.clear();
        this.spawnQueue.clear();
    }

    @Override
    public void b() {
        block8: {
            Object object;
            int[] nArray;
            Minecraft minecraft;
            long l2;
            long l3;
            block11: {
                block12: {
                    block10: {
                        Minecraft mc;
                        block9: {
                            long l4;
                            long l5 = l4 = L ^ 0x6294407B4942L;
                            l3 = l5 ^ 0x5065BA77EE27L;
                            l2 = l5 ^ 0x680FA2176E5EL;
                            minecraft = Minecraft.getInstance();
                            nArray = aD.b();
                            mc = minecraft;
                            if (nArray == null) break block9;
                            if (mc.level == null) break block10;
                            mc = minecraft;
                        }
                        object = mc.player;
                        if (nArray == null) break block11;
                        if (object != null) break block12;
                    }
                    return;
                }
                object = this.physics.a();
            }
            boolean dropsEnabled = object == kuzi.obf.j.g.A.DROP;
            this.particleList.removeIf(arg_0 -> Particles.lambda$onTick2$0(l3, arg_0));
            for (ax particle : this.particleList) {
                particle.d = particle.a;
                particle.e = particle.b;
                particle.f = particle.c;
                particle.m = particle.j;
                particle.n = particle.k;
                particle.o = particle.l;
                particle.a += particle.g;
                particle.b += particle.h;
                particle.c += particle.i;
                particle.j += particle.p;
                particle.k += particle.q;
                particle.l += particle.r;
                particle.g *= 0.98;
                particle.h *= 0.98;
                particle.i *= 0.98;
                particle.p *= 0.98f;
                particle.q *= 0.98f;
                particle.r *= 0.98f;
                if (nArray != null) {
                    if (nArray != null) {
                        if (dropsEnabled) {
                            particle.h -= 0.004;
                        }
                        ++particle.s;
                    }
                    if (nArray != null) continue;
                }
                break block8;
            }
            Object[] objectArray = new Object[3];
            objectArray[2] = l2;
            objectArray[1] = dropsEnabled;
            objectArray[0] = minecraft;
            this.a(objectArray);
        }
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private void a(Object[] var1_1) {
        block28: {
            block26: {
                block27: {
                    block24: {
                        block25: {
                            block21: {
                                block22: {
                                    block23: {
                                        block20: {
                                            block19: {
                                                var2_2 = (Minecraft)var1_1[0];
                                                var5_3 = (Boolean)var1_1[1];
                                                var3_4 = (Long)var1_1[2];
                                                v0 = var3_4 = Particles.L ^ var3_4;
                                                var6_5 = v0 ^ 138045704072437L;
                                                var8_6 = v0 ^ 64146064877941L;
                                                var10_7 = v0 ^ 63444192691744L;
                                                var12_8 = aD.b();
                                                v1 = ((Boolean)this.idle.a()).booleanValue();
                                                if (var12_8 != null) {
                                                    if (v1 != 0) {
                                                        var13_9 = ((Double)this.amount.a()).intValue();
                                                        var14_11 = Math.min((int)Particles.c("c", (int)6445, (long)(6293005427572195661L ^ var3_4)), Math.max(1, var13_9 / Particles.c("c", (int)26475, (long)(1027039402709630725L ^ var3_4))));
                                                        var15_13 = var2_2.player.position();
                                                        for (var16_15 = 0; var16_15 < var14_11; ++var16_15) {
                                                            v1 = this.particleList.size();
                                                            v2 = var12_8;
                                                            if (var3_4 >= 0L) {
                                                                if (v2 == null) break block19;
                                                                v2 = var12_8;
                                                            }
                                                            if (var3_4 < 0L) break block20;
                                                            if (v2 == null) break block19;
                                                            if (v1 >= var13_9) break;
                                                            v3 = new Object[3];
                                                            v3[2] = Float.valueOf(20.0f);
                                                            v3[1] = Float.valueOf(-20.0f);
                                                            v3[0] = var6_5;
                                                            v4 = new Object[3];
                                                            v4[2] = Float.valueOf(5.0f);
                                                            v4[1] = Float.valueOf(0.0f);
                                                            v4[0] = var6_5;
                                                            v5 = new Object[3];
                                                            v5[2] = Float.valueOf(20.0f);
                                                            v5[1] = Float.valueOf(-20.0f);
                                                            v5[0] = var6_5;
                                                            v6 = new Object[6];
                                                            v6[5] = 1.0;
                                                            v6[4] = var5_3;
                                                            v6[3] = var15_13.z + (double)this.randomFloat(v5);
                                                            v6[2] = var15_13.y + (double)this.randomFloat(v4);
                                                            v6[1] = var15_13.x + (double)this.randomFloat(v3);
                                                            v6[0] = var8_6;
                                                            this.spawnParticle(v6);
                                                            if (var12_8 != null) continue;
                                                            if (var3_4 <= 0L) break block21;
                                                        }
                                                    }
                                                    v1 = ((Boolean)this.movement.a()).booleanValue();
                                                }
                                            }
                                            v2 = var12_8;
                                        }
                                        if (v2 == null) break block22;
                                        if (v1 == 0) break block23;
                                        var13_10 = var2_2.player.getDeltaMovement();
                                        cfr_temp_0 = Math.sqrt(var13_10.x * var13_10.x + var13_10.z * var13_10.z) - 0.12;
                                        v1 = cfr_temp_0 == 0.0 ? 0 : (cfr_temp_0 > 0.0 ? 1 : -1);
                                        if (var12_8 == null) break block22;
                                        if (v1 > 0) {
                                            var14_12 = var2_2.player.position();
                                            v7 = new Object[3];
                                            v7[2] = var10_7;
                                            v7[1] = 0.3;
                                            v7[0] = -0.3;
                                            v8 = new Object[3];
                                            v8[2] = Float.valueOf(var2_2.player.getBbHeight());
                                            v8[1] = Float.valueOf(0.0f);
                                            v8[0] = var6_5;
                                            v9 = new Object[3];
                                            v9[2] = var10_7;
                                            v9[1] = 0.3;
                                            v9[0] = -0.3;
                                            v10 = new Object[6];
                                            v10[5] = 0.6;
                                            v10[4] = var5_3;
                                            v10[3] = var14_12.z + this.randomDouble(v9);
                                            v10[2] = var14_12.y + (double)this.randomFloat(v8);
                                            v10[1] = var14_12.x + this.randomDouble(v7);
                                            v10[0] = var8_6;
                                            this.spawnParticle(v10);
                                        }
                                    }
                                    v1 = (int)((Boolean)this.pearlThrow.a()).booleanValue();
                                }
                                var13_9 = v1;
                                var14_11 = ((Boolean)this.arrowShot.a()).booleanValue();
                            }
                            var15_14 = (Boolean)this.tridentThrow.a();
                            v11 = var13_9;
                            v12 = var12_8;
                            if (var3_4 < 0L) break block24;
                            if (v12 == null) break block25;
                            if (v11 != 0) break block26;
                            v11 = var14_11;
                        }
                        v12 = var12_8;
                    }
                    if (v12 == null) break block27;
                    if (v11 != 0) break block26;
                    v11 = (int)var15_14;
                }
                if (v11 == 0) break block28;
            }
            for (E v13 : var2_2.level.entitiesForRendering()) {
                block32: {
                    block37: {
                        block36: {
                            block35: {
                                block33: {
                                    block34: {
                                        block29: {
                                            block30: {
                                                block31: {
                                                    if (var12_8 == null) ** GOTO lbl193
                                                    var17_18 /* !! */  = v13 /* !! */ ;
                                                    v14 = var13_9;
                                                    v15 = var12_8;
                                                    if (var3_4 < 0L) break block29;
                                                    if (v15 == null) break block30;
                                                    if (v14 == 0) break block31;
                                                    v16 = var17_18 /* !! */  instanceof ThrownEnderpearl;
                                                    if (var12_8 == null) break block32;
                                                    if (v16) ** GOTO lbl-1000
                                                }
                                                v14 = (int)var15_14;
                                            }
                                            v15 = var12_8;
                                        }
                                        if (v15 == null) break block33;
                                        if (v14 == 0) break block34;
                                        v14 = var17_18 /* !! */  instanceof ThrownTrident;
                                        v17 = var12_8;
                                        if (var3_4 < 0L) break block35;
                                        if (v17 == null) break block33;
                                        if (v14 == 0) break block34;
                                        var20_22 = (ThrownTrident)var17_18 /* !! */ ;
                                        v16 = var20_22.onGround();
                                        if (var12_8 == null) break block32;
                                        if (!v16) ** GOTO lbl-1000
                                    }
                                    v14 = var14_11;
                                }
                                v17 = var12_8;
                            }
                            if (v17 == null) break block36;
                            if (v14 == 0) ** GOTO lbl-1000
                            v18 /* !! */  = var17_18 /* !! */ ;
                            if (var12_8 == null) break block37;
                            v14 = v18 /* !! */  instanceof Arrow;
                        }
                        if (v14 == 0) ** GOTO lbl-1000
                        v18 /* !! */  = var17_18 /* !! */ ;
                    }
                    var19_21 = (Arrow)v18 /* !! */ ;
                    v16 = var19_21.onGround();
                    if (var12_8 != null) {
                        ** if (v16) goto lbl-1000
                    }
                    break block32;
lbl-1000:
                    // 3 sources

                    {
                        v16 = true;
                        ** GOTO lbl173
                    }
lbl-1000:
                    // 3 sources

                    {
                        v16 = var18_20 = false;
                    }
                }
                if (var3_4 > 0L && var18_20) {
                    v19 = new Object[6];
                    v19[5] = 0.5;
                    v19[4] = var5_3;
                    v19[3] = var17_18 /* !! */ .getZ();
                    v19[2] = var17_18 /* !! */ .getY();
                    v19[1] = var17_18 /* !! */ .getX();
                    v19[0] = var8_6;
                    this.spawnParticle(v19);
                }
                if (var12_8 != null) continue;
            }
        }
        block2: while (true) {
            v13 /* !! */  = this.spawnQueue.poll();
lbl193:
            // 2 sources

            if ((var16_17 = (Vec3)v13 /* !! */ ) == null) ** GOTO lbl222
            do {
                var17_19 = 0;
                block4: while (var17_19 < Particles.c("c", (int)31784, (long)(2127528052911645771L ^ var3_4))) {
                    v20 = new Object[6];
                    v20[5] = 2.0;
                    v20[4] = var5_3;
                    v20[3] = var16_17.z;
                    v20[2] = var16_17.y;
                    v20[1] = var16_17.x;
                    v20[0] = var8_6;
                    this.spawnParticle(v20);
                    ++var17_19;
                    v21 = var12_8;
                    do {
                        if (v21 == null) continue block2;
                        v21 = var12_8;
                        if (var3_4 <= 0L) continue;
                        if (v21 != null) continue block4;
                        v21 = var12_8;
                    } while (var3_4 < 0L);
                }
                if (v21 == null) ** break;
                continue block2;
lbl222:
                // 2 sources

            } while (var3_4 <= 0L);
            break;
        }
    }

    private void spawnParticle(Object[] objectArray) {
        Object object;
        ax ax2;
        double d2;
        ax ax3;
        long l2;
        long l3;
        long l4;
        block6: {
            CallSite callSite;
            block4: {
                block5: {
                    l4 = (Long)objectArray[0];
                    double d3 = (Double)objectArray[1];
                    double d4 = (Double)objectArray[2];
                    double d5 = (Double)objectArray[3];
                    boolean bl = (Boolean)objectArray[4];
                    double d6 = (Double)objectArray[5];
                    long l5 = l4 = L ^ l4;
                    l3 = l5 ^ 0x8E49A09D7ECL;
                    l2 = l5 ^ 0x3D20C9D8D406L;
                    long l6 = l5 ^ 0x791E4C6E3ED3L;
                    CallSite callSite2 = Particles.d("h", (long)-6920392384062446049L, (long)l4);
                    ax3 = new ax();
                    double d7 = d3;
                    Particles.d("\u00db", (Object)ax3, (double)d7, (long)-6919586451237100713L, (long)l4);
                    Particles.d("\u00db", (Object)ax3, (double)d7, (long)-6920094635678421889L, (long)l4);
                    double d8 = d4;
                    Particles.d("\u00db", (Object)ax3, (double)d8, (long)-6919704996001815488L, (long)l4);
                    Particles.d("\u00db", (Object)ax3, (double)d8, (long)-6920196560189975699L, (long)l4);
                    CallSite callSite3 = callSite2;
                    double d9 = d5;
                    Particles.d("\u00db", (Object)ax3, (double)d9, (long)-6919340894196232498L, (long)l4);
                    Particles.d("\u00db", (Object)ax3, (double)d9, (long)-6926156568885422681L, (long)l4);
                    d2 = 0.04 * d6;
                    try {
                        try {
                            ax2 = ax3;
                            Object[] objectArray2 = new Object[3];
                            objectArray2[2] = Float.valueOf(1.0f);
                            objectArray2[1] = Float.valueOf(-1.0f);
                            objectArray2[0] = l2;
                            callSite = Particles.d("\u00cc", (Object)this, (Object)objectArray2, (long)-6919838355602178191L, (long)l4);
                            if (callSite3 == null) break block4;
                            Particles.d("\u00db", (Object)ax2, (double)((double)callSite * d2), (long)-6918035207709364755L, (long)l4);
                            ax2 = ax3;
                            if (!bl) break block5;
                        }
                        catch (r r2) {
                            throw Particles.d("h", (Object)r2, (long)-6918915478601516856L, (long)l4);
                        }
                        Object[] objectArray3 = new Object[3];
                        objectArray3[2] = l6;
                        objectArray3[1] = 0.4;
                        objectArray3[0] = -0.2;
                        object = Particles.d("\u00cc", (Object)this, (Object)objectArray3, (long)-6920561342770254750L, (long)l4);
                        break block6;
                    }
                    catch (r r3) {
                        throw Particles.d("h", (Object)r3, (long)-6918915478601516856L, (long)l4);
                    }
                }
                Object[] objectArray4 = new Object[3];
                objectArray4[2] = Float.valueOf(2.0f);
                objectArray4[1] = Float.valueOf(0.0f);
                objectArray4[0] = l2;
                callSite = Particles.d("\u00cc", (Object)this, (Object)objectArray4, (long)-6919838355602178191L, (long)l4);
            }
            object = (double)callSite;
        }
        Particles.d("\u00db", (Object)ax2, (double)(object * d2), (long)-6919557386050039040L, (long)l4);
        Object[] objectArray5 = new Object[3];
        objectArray5[2] = Float.valueOf(1.0f);
        objectArray5[1] = Float.valueOf(-1.0f);
        objectArray5[0] = l2;
        Particles.d("\u00db", (Object)ax3, (double)((double)Particles.d("\u00cc", (Object)this, (Object)objectArray5, (long)-6919838355602178191L, (long)l4) * d2), (long)-6919268861359779238L, (long)l4);
        Object[] objectArray6 = new Object[3];
        objectArray6[2] = Float.valueOf(6.283f);
        objectArray6[1] = Float.valueOf(0.0f);
        objectArray6[0] = l2;
        CallSite callSite = Particles.d("\u00cc", (Object)this, (Object)objectArray6, (long)-6919838355602178191L, (long)l4);
        Particles.d("\u00db", (Object)ax3, (float)callSite, (long)-6917889019425979186L, (long)l4);
        Particles.d("\u00db", (Object)ax3, (float)callSite, (long)-6925425789077987880L, (long)l4);
        Object[] objectArray7 = new Object[3];
        objectArray7[2] = Float.valueOf(6.283f);
        objectArray7[1] = Float.valueOf(0.0f);
        objectArray7[0] = l2;
        CallSite callSite4 = Particles.d("\u00cc", (Object)this, (Object)objectArray7, (long)-6919838355602178191L, (long)l4);
        Particles.d("\u00db", (Object)ax3, (float)callSite4, (long)-6919888330604594849L, (long)l4);
        Particles.d("\u00db", (Object)ax3, (float)callSite4, (long)-6925130646379987296L, (long)l4);
        Object[] objectArray8 = new Object[3];
        objectArray8[2] = Float.valueOf(6.283f);
        objectArray8[1] = Float.valueOf(0.0f);
        objectArray8[0] = l2;
        CallSite callSite5 = Particles.d("\u00cc", (Object)this, (Object)objectArray8, (long)-6919838355602178191L, (long)l4);
        Particles.d("\u00db", (Object)ax3, (float)callSite5, (long)-6917589260198112666L, (long)l4);
        Particles.d("\u00db", (Object)ax3, (float)callSite5, (long)-6925386970208260826L, (long)l4);
        Object[] objectArray9 = new Object[3];
        objectArray9[2] = Float.valueOf(1.0f);
        objectArray9[1] = Float.valueOf(-1.0f);
        objectArray9[0] = l2;
        Particles.d("\u00db", (Object)ax3, (float)(Particles.d("\u00cc", (Object)this, (Object)objectArray9, (long)-6919838355602178191L, (long)l4) * 0.04f), (long)-6918571934135014648L, (long)l4);
        Object[] objectArray10 = new Object[3];
        objectArray10[2] = Float.valueOf(1.0f);
        objectArray10[1] = Float.valueOf(-1.0f);
        objectArray10[0] = l2;
        Particles.d("\u00db", (Object)ax3, (float)(Particles.d("\u00cc", (Object)this, (Object)objectArray10, (long)-6919838355602178191L, (long)l4) * 0.04f), (long)-6920739068724124556L, (long)l4);
        Object[] objectArray11 = new Object[3];
        objectArray11[2] = Float.valueOf(1.0f);
        objectArray11[1] = Float.valueOf(-1.0f);
        objectArray11[0] = l2;
        Particles.d("\u00db", (Object)ax3, (float)(Particles.d("\u00cc", (Object)this, (Object)objectArray11, (long)-6919838355602178191L, (long)l4) * 0.04f), (long)-6919428524095856317L, (long)l4);
        Particles.d("\u00db", (Object)ax3, (int)(Particles.c("c", (int)10346, (long)(0x74607226CE5E48F0L ^ l4)) + ((Random)((Object)Particles.d("\u00a4", (Object)this, (long)-6917758924875485666L, (long)l4))).nextInt((int)Particles.c("c", (int)28009, (long)(0x5DED8976FD720DF7L ^ l4)))), (long)-6926278271579905601L, (long)l4);
        Object[] objectArray12 = new Object[3];
        objectArray12[2] = Float.valueOf(1.0f);
        objectArray12[1] = Float.valueOf(0.35f);
        objectArray12[0] = l2;
        Particles.d("\u00db", (Object)ax3, (float)((float)((Double)((Object)Particles.d("\u00cc", (Object)Particles.d("\u00a4", (Object)this, (long)-6919102920374832810L, (long)l4), (long)-6926458533471094876L, (long)l4))).doubleValue() * Particles.d("\u00cc", (Object)this, (Object)objectArray12, (long)-6919838355602178191L, (long)l4)), (long)-6919922632354812681L, (long)l4);
        Object[] objectArray13 = new Object[1];
        objectArray13[0] = l3;
        Particles.d("\u00db", (Object)ax3, (a)((Object)Particles.d("\u00cc", (Object)this, (Object)objectArray13, (long)-6925899000420385867L, (long)l4)), (long)-6918322366964920049L, (long)l4);
        Particles.d("\u00a4", (Object)this, (long)-6920900361138071187L, (long)l4).add(ax3);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Unable to fully structure code
     */
    private void renderParticles(long var1_1, WorldRenderContext context) {
        block30: {
            block37: {
                block36: {
                    block35: {
                        block34: {
                            block33: {
                                block32: {
                                    v0 = var1_1 = Particles.L ^ var1_1;
                                    v1 = v0 ^ 108033738461597L;
                                    var4_3 = (int)(v1 >>> 32);
                                    var5_4 = (int)(v1 << 32 >>> 48);
                                    var6_5 = (int)(v1 << 48 >>> 48);
                                    var7_6 = v0 ^ 105190832701619L;
                                    var9_7 = v0 ^ 77627884906794L;
                                    v2 = v0 ^ 26592684272522L;
                                    var11_8 = (int)(v2 >>> 48);
                                    var12_9 = (int)(v2 << 16 >>> 32);
                                    var13_10 = (int)(v2 << 48 >>> 48);
                                    var14_11 = aD.b();
                                    v3 = this.d();
                                    if (var14_11 == null) break block32;
                                    if (!v3) break block33;
                                    v3 = this.particleList.isEmpty();
                                }
                                if (!v3) break block34;
                            }
                            return;
                        }
                        v4 = minecraft = Minecraft.getInstance();
                        if (var1_1 <= 0L || var14_11 == null) break block35;
                        if (v4.level == null) break block36;
                        v4 = minecraft;
                    }
                    if (v4.player != null) break block37;
                }
                return;
            }
            matrices = context.matrices();
            camera = minecraft.gameRenderer.getMainCamera();
            if (matrices == null || camera == null || context.consumers() == null) {
                return;
            }
            partialTick = minecraft.getDeltaTracker().getGameTimeDeltaPartialTick(true);
            cameraPos = camera.position();
            packedColor = this.color.a().getRGB() & Particles.c("c", (int)861, (long)(2515565473179799272L ^ var1_1));
            matrices.pushPose();
            matrices.translate(-cameraPos.x, -cameraPos.y, -cameraPos.z);
            try {
                block26: {
                    block38: {
                        if (!((Boolean)this.glow.a()).booleanValue()) break block38;
                        vertexConsumer = kuzi.obf.l.d.f.a(context.consumers(), var7_6);
                        for (Object particle : this.particleList) {
                            block27: {
                                block28: {
                                    block29: {
                                        block39: {
                                            v5 = new Object[3];
                                            v5[2] = var9_7;
                                            v5[1] = Float.valueOf(partialTick);
                                            v5[0] = particle;
                                            particleAlpha = (int)(Particles.a(v5) * 100.0f);
                                            if (var1_1 < 0L) break block26;
                                            v6 = var14_11;
                                            if (var1_1 < 0L) ** GOTO lbl60
                                            if (v6 == null) break block26;
                                            v6 = var14_11;
lbl60:
                                            // 2 sources

                                            if (var1_1 <= 0L) break block27;
                                            if (v6 == null) break block28;
                                            break block39;
                                            catch (r v7) {
                                                throw Particles.a(v7);
                                            }
                                        }
                                        try {
                                            if (var1_1 <= 0L) break block28;
                                            if (particleAlpha <= 2) {
                                                continue;
                                            }
                                            break block29;
                                            catch (r v8) {
                                                throw Particles.a(v8);
                                            }
                                        }
                                        catch (r v9) {
                                            throw Particles.a(v9);
                                        }
                                    }
                                    v10 = new Object[3];
                                    v10[2] = Float.valueOf(partialTick);
                                    v10[1] = particle.a;
                                    v10[0] = particle.d;
                                    v11 = new Object[3];
                                    v11[2] = Float.valueOf(partialTick);
                                    v11[1] = particle.b;
                                    v11[0] = particle.e;
                                    v12 = new Object[3];
                                    v12[2] = Float.valueOf(partialTick);
                                    v12[1] = particle.c;
                                    v12[0] = particle.f;
                                    kuzi.obf.l.d.f.a(matrices, vertexConsumer, var4_3, camera, Particles.a(v10), Particles.a(v11), Particles.a(v12), particle.u * 4.0f, (char)var5_4, 0.0f, (short)var6_5, particleAlpha << Particles.c("c", (int)29359, (long)(7225214588009348866L ^ var1_1)) | packedColor);
                                }
                                v6 = var14_11;
                            }
                            if (v6 != null) continue;
                        }
                    }
                    vertexConsumer = context.consumers().getBuffer(RenderTypes.linesTranslucent());
                }
                matrix = matrices.last().pose();
                for (ax particle2 : this.particleList) {
                    block31: {
                        v13 = new Object[3];
                        v13[2] = var9_7;
                        v13[1] = Float.valueOf(partialTick);
                        v13[0] = particle2;
                        particleAlpha2 = Particles.a(v13);
                        if (var1_1 < 0L || var14_11 == null) break block30;
                        try {
                            if (particleAlpha2 <= 0.01f) {
                                continue;
                            }
                            break block31;
                            catch (r v14) {
                                throw Particles.a(v14);
                            }
                        }
                        catch (r v15) {
                            throw Particles.a(v15);
                        }
                    }
                    v16 = new Object[3];
                    v16[2] = Float.valueOf(partialTick);
                    v16[1] = Float.valueOf(particle2.j);
                    v16[0] = Float.valueOf(particle2.m);
                    v17 = new Object[3];
                    v17[2] = Float.valueOf(partialTick);
                    v17[1] = Float.valueOf(particle2.k);
                    v17[0] = Float.valueOf(particle2.n);
                    v18 = new Object[3];
                    v18[2] = Float.valueOf(partialTick);
                    v18[1] = Float.valueOf(particle2.l);
                    v18[0] = Float.valueOf(particle2.o);
                    rotation = new Quaternionf().rotationXYZ(Particles.c(v16), Particles.c(v17), Particles.c(v18));
                    v19 = new Object[3];
                    v19[2] = Float.valueOf(partialTick);
                    v19[1] = particle2.a;
                    v19[0] = particle2.d;
                    v20 = new Object[3];
                    v20[2] = Float.valueOf(partialTick);
                    v20[1] = particle2.b;
                    v20[0] = particle2.e;
                    v21 = new Object[3];
                    v21[2] = Float.valueOf(partialTick);
                    v21[1] = particle2.c;
                    v21[0] = particle2.f;
                    kuzi.obf.l.d.e.a(vertexConsumer, matrix, (short)var11_8, particle2.v, Particles.a(v19), Particles.a(v20), Particles.a(v21), rotation, var12_9, var13_10, particle2.u, packedColor, particleAlpha2, 1.5f);
                    if (var1_1 > 0L && var14_11 != null) continue;
                    break;
                }
            }
            finally {
                matrices.popPose();
            }
        }
    }

    private static float a(Object[] objectArray) {
        ax particle = (ax)objectArray[0];
        float f2 = ((Float)objectArray[1]).floatValue();
        long l2 = (Long)objectArray[2];
        l2 = L ^ l2;
        float age = (float)Particles.d("\u00a4", (Object)particle, (long)-3861929406442782219L, (long)l2) + f2;
        float fadeIn = Math.min(1.0f, age / 20.0f);
        float fadeOut = Math.min(1.0f, Math.max(0.0f, ((float)Particles.d("\u00a4", (Object)particle, (long)-3862497218046626758L, (long)l2) - age) / 20.0f));
        return (float)(Particles.d("h", (Object)new Object[]{Float.valueOf(fadeIn)}, (long)-3861839588668471566L, (long)l2) * Particles.d("h", (Object)new Object[]{Float.valueOf(fadeOut)}, (long)-3861839588668471566L, (long)l2));
    }

    private static double a(Object[] objectArray) {
        double d2 = (Double)objectArray[0];
        double d3 = (Double)objectArray[1];
        float f2 = ((Float)objectArray[2]).floatValue();
        return d2 + (d3 - d2) * (double)f2;
    }

    private static float c(Object[] objectArray) {
        float f2 = ((Float)objectArray[0]).floatValue();
        float f3 = ((Float)objectArray[1]).floatValue();
        float f4 = ((Float)objectArray[2]).floatValue();
        return f2 + (f3 - f2) * f4;
    }

    private double randomDouble(Object[] objectArray) {
        double d2 = (Double)objectArray[0];
        double d3 = (Double)objectArray[1];
        long l2 = (Long)objectArray[2];
        l2 = L ^ l2;
        return d2 + this.random.nextDouble() * (d3 - d2);
    }

    private float randomFloat(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        float f2 = ((Float)objectArray[1]).floatValue();
        float f3 = ((Float)objectArray[2]).floatValue();
        l2 = L ^ l2;
        return f2 + this.random.nextFloat() * (f3 - f2);
    }

    private static boolean lambda$onTick2$0(long l2, ax ax2) {
        l2 = L ^ l2;
        int[] nArray = aD.b();
        int n2 = ax2.s;
        if (nArray != null) {
            n2 = n2 >= ax2.t ? 1 : 0;
        }
        return n2 != 0;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block21: {
            block20: {
                block19: {
                    block18: {
                        Particles.L = kuzi.obf.h.b.v.a(5365079759899312429L, -5900206882139235978L, MethodHandles.lookup().lookupClass()).a(117880049360923L);
                        Particles.S = new Object[115];
                        Particles.T = new String[115];
                        Particles.c();
                        Particles.O = new HashMap<K, V>(13);
                        var11 = Particles.L ^ 118133194013530L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[19];
                        var18_4 = 0;
                        var17_5 = "\u00efW\u0013h\u00a7\u00a6\u009f\u00eb\n\u0005\u00a8\u00e42\f\u0017\u00e4A\u00fe\u00fa\u007f\u0099:j\u008e\u009f\u00ccy\u0085\u00c7\b\u00eb\u00a6\u0010\u00edZ\u00e6\u0085\u0091\u00fa\u00be\u0014\u0090G\u00a3\u0012\u0012/\u00c9\u00fe\u0010\u00a3\u0005\u007f$ \u00a2jU\u0099\u00c8\u0090\u000b\u00910\u00cc \u0010d\u0081@\u000f\u0087L\u00aa?\u00c7\u00f0F\u008b\u00f7Q\u00cfD \u00b7\u009b\u00d1{\u00d4\u0080\u0012b\u00e0\u00de\u0080\u0012\u001d\u00b4ZkF+\u00b3\u00a8\u00b2\u00a3(\u00c8\u00c1t)\u00f0\u0085\u00db\u00bf\u00f6 '\u0017\u00fe\u0016c\u0018\u00d1\u00a0Z\u00a6\u00da\u0005\u00e7\u00eb<o,\u0087U\u00f3\u00cd\u0098T\u00b4\u009d\u0018\u009b\u001cm2\u00dc\u00c1\u0018\u00b4*\u00dc\u001f\u00ed\u00a7\u00a9\u0019Wh\u0017\u00f8\u00a2\r5\u00b4I\u0001\u00ebU\u00165\u0089%@\u00bc\b|E\u00d8XlM\u00e7\u0006\u009cDE=\u0014\u009e\u00fa\u0002\u00e3\u000e\u009b\u00e2i\u00abB\u00bd\u001d$\u00c4)\u00e4:G\u00c0\u0092\u0084\u00a7z\u00c5y\u00d3\u008f\u00acA\u00ce\u00a1\u00db\u008e\u00cb\u0095J\u00ab\u00dfgovm\u0096I\"\u00e5\u00d1\u008ct\u0010\u0096{\u0080\u0081\"\u0012\u008c\u008e7\u007f\u00c6d\u00cdm\u0006\u00a1\u0010\u00a3\u00fb\u0098\u00ca8f\u00f6\u00a7\u00b46-\u00c2{\t]\u000e \u00f2\u001c\u001d\u0018\u00a7\u00e0?\u00f9$x2Yf\u009b\u00ed\u0013\u008a\u0090N\u001f\u00c9\u00cd\u007ft%\u0095\u00ee\u00f0\u00ea\u00dc\\\u00cf\u0018K\u0082\u00f5\u0006\u0097\u00ce\u0015\u0016\u00b1\u00a3txD)\u00c8\u00d7\u00812\u0092\u00c2\u00cc\u00d2hr \u00ffv\u00f9#\u0098\u00d7\u000b\u0083hu\u0087K\u001bg\u00e4\u00dc\u0083\u00dd|\u00cc#\u00c8\u008d\u00aa\u0004&k\u00fe\u009d\u00da\u00fc\u0085\u0010\u00e8\u00ca\\_sG\u009d\f{\u00b1\u00dbY\u00e3\u00a0Z\u00d2\u0018%\u00e7D\u0017\u0013\u00d6\u00f2Q\u00f9DF\u00b8?\u009e\u00b7\u00cbo\u0018D\u00ff\u0015\u00cc\u0015\u00a2 V\u0004\u0012\u0010_\u00ad\u00ed\u00de\u001f\u00a0\u0088\u00f0\u00b8G7R\u0088\f\u00ae6$J\u0092\u00c8\u00bc\u0094Z\u00bc\u00a7{\u00c3\u00e8\u0010\u00b4.\"u\u008c-\u008b\u00b4\u0001\u00a8VG\u0011\u00a2B\u00f5";
                        var19_6 = "\u00efW\u0013h\u00a7\u00a6\u009f\u00eb\n\u0005\u00a8\u00e42\f\u0017\u00e4A\u00fe\u00fa\u007f\u0099:j\u008e\u009f\u00ccy\u0085\u00c7\b\u00eb\u00a6\u0010\u00edZ\u00e6\u0085\u0091\u00fa\u00be\u0014\u0090G\u00a3\u0012\u0012/\u00c9\u00fe\u0010\u00a3\u0005\u007f$ \u00a2jU\u0099\u00c8\u0090\u000b\u00910\u00cc \u0010d\u0081@\u000f\u0087L\u00aa?\u00c7\u00f0F\u008b\u00f7Q\u00cfD \u00b7\u009b\u00d1{\u00d4\u0080\u0012b\u00e0\u00de\u0080\u0012\u001d\u00b4ZkF+\u00b3\u00a8\u00b2\u00a3(\u00c8\u00c1t)\u00f0\u0085\u00db\u00bf\u00f6 '\u0017\u00fe\u0016c\u0018\u00d1\u00a0Z\u00a6\u00da\u0005\u00e7\u00eb<o,\u0087U\u00f3\u00cd\u0098T\u00b4\u009d\u0018\u009b\u001cm2\u00dc\u00c1\u0018\u00b4*\u00dc\u001f\u00ed\u00a7\u00a9\u0019Wh\u0017\u00f8\u00a2\r5\u00b4I\u0001\u00ebU\u00165\u0089%@\u00bc\b|E\u00d8XlM\u00e7\u0006\u009cDE=\u0014\u009e\u00fa\u0002\u00e3\u000e\u009b\u00e2i\u00abB\u00bd\u001d$\u00c4)\u00e4:G\u00c0\u0092\u0084\u00a7z\u00c5y\u00d3\u008f\u00acA\u00ce\u00a1\u00db\u008e\u00cb\u0095J\u00ab\u00dfgovm\u0096I\"\u00e5\u00d1\u008ct\u0010\u0096{\u0080\u0081\"\u0012\u008c\u008e7\u007f\u00c6d\u00cdm\u0006\u00a1\u0010\u00a3\u00fb\u0098\u00ca8f\u00f6\u00a7\u00b46-\u00c2{\t]\u000e \u00f2\u001c\u001d\u0018\u00a7\u00e0?\u00f9$x2Yf\u009b\u00ed\u0013\u008a\u0090N\u001f\u00c9\u00cd\u007ft%\u0095\u00ee\u00f0\u00ea\u00dc\\\u00cf\u0018K\u0082\u00f5\u0006\u0097\u00ce\u0015\u0016\u00b1\u00a3txD)\u00c8\u00d7\u00812\u0092\u00c2\u00cc\u00d2hr \u00ffv\u00f9#\u0098\u00d7\u000b\u0083hu\u0087K\u001bg\u00e4\u00dc\u0083\u00dd|\u00cc#\u00c8\u008d\u00aa\u0004&k\u00fe\u009d\u00da\u00fc\u0085\u0010\u00e8\u00ca\\_sG\u009d\f{\u00b1\u00dbY\u00e3\u00a0Z\u00d2\u0018%\u00e7D\u0017\u0013\u00d6\u00f2Q\u00f9DF\u00b8?\u009e\u00b7\u00cbo\u0018D\u00ff\u0015\u00cc\u0015\u00a2 V\u0004\u0012\u0010_\u00ad\u00ed\u00de\u001f\u00a0\u0088\u00f0\u00b8G7R\u0088\f\u00ae6$J\u0092\u00c8\u00bc\u0094Z\u00bc\u00a7{\u00c3\u00e8\u0010\u00b4.\"u\u008c-\u008b\u00b4\u0001\u00a8VG\u0011\u00a2B\u00f5".length();
                        var16_7 = 32;
                        var15_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block18;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = Particles.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "\u00a5\u008aFt\u00a6%\u00d5\u0093\u0090\u008d^\u00ef\u0004@\u00e2\u00cc\t1\u0095\u008c4\u00e6\u00b8\u0080o\u008d\u00e0\u00b5i\u00eeVa\u0010gB\u00d1j\u00eeo.G\u00be\u00a8z\u00d22&\u008b\u00ba";
                            var19_6 = "\u00a5\u008aFt\u00a6%\u00d5\u0093\u0090\u008d^\u00ef\u0004@\u00e2\u00cc\t1\u0095\u008c4\u00e6\u00b8\u0080o\u008d\u00e0\u00b5i\u00eeVa\u0010gB\u00d1j\u00eeo.G\u00be\u00a8z\u00d22&\u008b\u00ba".length();
                            var16_7 = 32;
                            var15_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block18;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = Particles.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block19;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                Particles.M = var20_3;
                Particles.N = new String[19];
                Particles.R = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[22];
                var3_13 = 0;
                var4_14 = "S\u00c5r\u00b8d\u0013v\u0099\u008a.pI\u00e6q>M\"\u00ba2\u00da\u0000\u0089\u0083\u00b5\u00f7AYz\u00e7e\u00a6\u00f48\u00e1\u0083\u0011Q\u00bd\u00fd3C\u0085\u0015PPH/\u00df\u008c*\u0090\u00daP\u00f9\u00ca\u00ec\u00f2\u00c7C~n\u00cbs\n\u0088\u00ea\u00b6z\u0017\u00a7\u00ca\u00cb\u001b\u0084\u00d0AT\u00fc\u00a6O\u00bf\u00d5\u00c0.P\u0014\u00b9\u00c0\u008d?\u00c9y]y\u0086VB\u00a2\u00beq\u007f\u00f11\u00bb\u00eb\u0016g\u00fcf\u0091zC\b\u0092h\u00c5\u00d2\u00cb\u0011lks*\u00eaH\u001bQ\u008f\u008fAd\u008dA\fqr\u000f\u00c2J\u000e\u00ae_\t,{\u00d92!\u00f8\u001d\u00cefA\u00c7F;g\u00d1\u0097<";
                var5_15 = "S\u00c5r\u00b8d\u0013v\u0099\u008a.pI\u00e6q>M\"\u00ba2\u00da\u0000\u0089\u0083\u00b5\u00f7AYz\u00e7e\u00a6\u00f48\u00e1\u0083\u0011Q\u00bd\u00fd3C\u0085\u0015PPH/\u00df\u008c*\u0090\u00daP\u00f9\u00ca\u00ec\u00f2\u00c7C~n\u00cbs\n\u0088\u00ea\u00b6z\u0017\u00a7\u00ca\u00cb\u001b\u0084\u00d0AT\u00fc\u00a6O\u00bf\u00d5\u00c0.P\u0014\u00b9\u00c0\u008d?\u00c9y]y\u0086VB\u00a2\u00beq\u007f\u00f11\u00bb\u00eb\u0016g\u00fcf\u0091zC\b\u0092h\u00c5\u00d2\u00cb\u0011lks*\u00eaH\u001bQ\u008f\u008fAd\u008dA\fqr\u000f\u00c2J\u000e\u00ae_\t,{\u00d92!\u00f8\u001d\u00cefA\u00c7F;g\u00d1\u0097<".length();
                var2_16 = 0;
                while (true) {
                    var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                    v10 = var6_12;
                    v11 = var3_13++;
                    v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                    v13 = -1;
                    break block20;
                    break;
                }
lbl81:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    var4_14 = "k\u00fcf+\u0099\u00ed\u00fa\u0002\u00da\u00a70\u00fe!5\u0004}";
                    var5_15 = "k\u00fcf+\u0099\u00ed\u00fa\u0002\u00da\u00a70\u00fe!5\u0004}".length();
                    var2_16 = 0;
                    while (true) {
                        var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                        v10 = var6_12;
                        v11 = var3_13++;
                        v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                        v13 = 0;
                        break block20;
                        break;
                    }
                    break;
                }
lbl94:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    break block21;
                    break;
                }
            }
            var8_18 = v12;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            v14 = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
            switch (v13) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl107:
                // 1 sources

                ** continue;
            }
        }
        Particles.P = var6_12;
        Particles.Q = new Integer[22];
    }

    private static r a(r r2) {
        return r2;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x7F78;
        if (Q[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = P[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])R.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    R.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/g/ag", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Particles.Q[n3] = n4;
        }
        return Q[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = Particles.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/ag" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (T[n4] != null) {
            return n4;
        }
        Object object = S[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 31;
            case 1 -> 33;
            case 2 -> 11;
            case 3 -> 15;
            case 4 -> 5;
            case 5 -> 43;
            case 6 -> 26;
            case 7 -> 9;
            case 8 -> 23;
            case 9 -> 12;
            case 10 -> 25;
            case 11 -> 58;
            case 12 -> 40;
            case 13 -> 53;
            case 14 -> 7;
            case 15 -> 17;
            case 16 -> 13;
            case 17 -> 8;
            case 18 -> 3;
            case 19 -> 24;
            case 20 -> 30;
            case 21 -> 55;
            case 22 -> 56;
            case 23 -> 34;
            case 24 -> 46;
            case 25 -> 14;
            case 26 -> 28;
            case 27 -> 47;
            case 28 -> 21;
            case 29 -> 52;
            case 30 -> 54;
            case 31 -> 57;
            case 32 -> 19;
            case 33 -> 48;
            case 34 -> 4;
            case 35 -> 27;
            case 36 -> 61;
            case 37 -> 29;
            case 38 -> 50;
            case 39 -> 62;
            case 40 -> 2;
            case 41 -> 1;
            case 42 -> 63;
            case 43 -> 39;
            case 44 -> 59;
            case 45 -> 60;
            case 46 -> 36;
            case 47 -> 22;
            case 48 -> 38;
            case 49 -> 20;
            case 50 -> 51;
            case 51 -> 10;
            case 52 -> 6;
            case 53 -> 0;
            case 54 -> 35;
            case 55 -> 37;
            case 56 -> 45;
            case 57 -> 16;
            case 58 -> 41;
            case 59 -> 32;
            case 60 -> 18;
            case 61 -> 42;
            case 62 -> 49;
            default -> 44;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        Particles.T[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = S;
        S[0] = "Ayd $cJyb $*";
        objectArray[1] = "s/m\u0017Dtm'wX8`w*t\u001b";
        objectArray[2] = "$\u0000\u001cT~3/\u0000\u001aT~e";
        objectArray[3] = Float.TYPE;
        Particles.T[3] = "java/lang/Float";
        objectArray[4] = "Ea\u001eDq\u0002La\u001dDu";
        objectArray[5] = "\u0011a\u001an\u0004h\u001da\t";
        objectArray[6] = Double.TYPE;
        Particles.T[6] = "java/lang/Double";
        objectArray[7] = "\tH\u0014xt`\u0004H\u0011xs";
        objectArray[8] = "e\u0005D/)Le\u0005Ss%C\u007fNSm%Vx?\u00044}\u0012";
        objectArray[9] = Long.TYPE;
        Particles.T[9] = "java/lang/Long";
        objectArray[10] = "*Rp7,\r*Rgk \u00020\u0019gu \u00177h0,y\\";
        objectArray[11] = "%a\"F26,a!F2";
        objectArray[12] = " \u0006JI\u001fL+\t[\u0006~B \u0002_\\";
        objectArray[13] = "\u000eZ\u001abK\u0018{z\u0011mZW\u001at\u001af^\rn";
        objectArray[14] = "\t*\u0010q4\u0001|\n\u001b~%N\u001d\u0004\u0010u!\u0014i";
        objectArray[15] = "c7x\u001c{e\u0016\u0017s\u0013j*w\u0019x\u0018np\u0003";
        objectArray[16] = "\u000bQYON-\u0002QZOL";
        objectArray[17] = "<\u001d\rtN\r!\bUV\u000f\u00009\u000e";
        objectArray[18] = "2q\u00161\"a9q\u00101\"\u000b";
        objectArray[19] = "\tq";
        objectArray[20] = "I9BW*\u001dB9I";
        objectArray[21] = Boolean.TYPE;
        Particles.T[21] = "java/lang/Boolean";
        objectArray[22] = "R5,b\u0001e_5)b\u0001";
        objectArray[23] = "\fKz&\u0014Q\u0012C`ivM\u0015^";
        objectArray[24] = "F]w5PdK]r5T";
        objectArray[25] = "9V+d\u00199;Hb\u0007\u0012\"$M4~\u0015";
        objectArray[26] = Short.TYPE;
        Particles.T[26] = "java/lang/Short";
        objectArray[27] = "79\u0002rOI5'K\rPG,.\u00172LI6-";
        objectArray[28] = Integer.TYPE;
        Particles.T[28] = "java/lang/Integer";
        objectArray[29] = Void.TYPE;
        Particles.T[29] = "java/lang/Void";
        objectArray[30] = "&\"\u001a1\u001f\u0000&\"\rm\u0013\u000f<i\rs\u0013\u001a;\u0018Z*J^";
        objectArray[31] = "[\u0002:\u0000-\u0017[\u0002-\\!\u0018AI-B!\rF8z\u001fxJ";
        objectArray[32] = Character.TYPE;
        Particles.T[32] = "java/lang/Character";
        objectArray[33] = "ZOi\u0018\rMQOa";
        objectArray[34] = "P\u0015\u0016fCx[\u0015\u0010fc";
        objectArray[35] = "LdD\u0002\u0012>EdG\u0002\u001e";
        objectArray[36] = "PQ[3\u0003\u000fYQX3\u000e";
        objectArray[37] = "~W3_!2\u000bw8P0}jy3[4'\u001e";
        objectArray[38] = "\u0013\u0012ty\u0000\u0013\r\u001an6\u007f\u0013\u001c\u0006g";
        objectArray[39] = "\u001af\fl4\u0004oF\u0007c%K\u000eH\fh!\u0011z";
        objectArray[40] = "\u001b'6zb\u0002n\u0007=usM\u000f\t6~w\u0017{";
        objectArray[41] = "\u001c8\b}\u001dEi\u0018\u0003r\f\n\b\u0016\by\bP|";
        objectArray[42] = "\u001f4\u0003;\f\u001cj\u0014\b4\u001dS\u000b\u001a\u0003?\u0019\t\u007f";
        objectArray[43] = "\\.SE]m)\u000eXJL\"H\u0000SAHx<";
        objectArray[44] = "%\nN,1?P*E# p1$N($*E";
        objectArray[45] = "\u000e\r\u001b|,MR\u0015\\~KK7P\n#{JY\u0004\u0019&7";
        objectArray[46] = "`&g\u0007iy<> \u0005\u000exY{vX>~7/e]r";
        objectArray[47] = "*^\\x\u0012$\u007fH\u0013B\b\\*^\u0006{\u0013!|\u000b\\#";
        objectArray[48] = "MA\r:\u007f$\u0018WB\u0000o\\MAW9~!\u001b\u0014\ra";
        objectArray[49] = "\\\u0011s Cv\u000e\u001bqb;\u0003o?\u0004\u001aU,\bO1$\u0007&\n\r";
        objectArray[50] = "f\u001a0?\u000fy:\u0002w=hy_G!`X~1\u00132e\u0014";
        objectArray[51] = "Q\u001do:\b%\u0004\u000b \u0000\n]EK)0\u0004>GN#ic>UN0}\u001b,\u0003\u0018 \u0000";
        objectArray[52] = "NV\u0018?^?\u001b@W\u0005\\GZ\u0000^5R$X\u0005Tl5)@\u0002\u001c}\u000b{J\u0000^\u0005";
        objectArray[53] = "OEIc[u\u001dOK!#\u0013p{:\u001cb\u0007!O\u0017c\u00193\u001f\u001d\u001da[";
        objectArray[54] = "Q\u001dVQ\u001f\u0012\r\u0005\u0011Sx\u000bh\u0019\u0013W\u0011JYAQ\u000e\u0012";
        objectArray[55] = "J\bH<\u000b\u0017\u001f\u001e\u0007\u0006\no^^\u000e6\u0007\f\\[\u0004o`ULYFc\u000e\u0001_\\\n\u0006";
        objectArray[56] = "[N8O`)\u0007V\u007fM\u0007 b\u0015 J=-\u001eV#\u00178";
        objectArray[57] = "\u000by\n8\u0000_S(\u001ce0G6-\u0004`UDF/\u001d`[.\bn_8U\u0010F`\b60\u0011\u0006|\u001a<PNV\u007f\u0006Z";
        objectArray[58] = "\tzq\u0003\u007f`\\l>9]\u0018\tz+\u0000~e_/qX";
        objectArray[59] = "RZ\u007fjsP\u0007L0P[(RZ\u007fjsP\u0007L0";
        objectArray[60] = "3\u000fK\u007fvX<WJmI]\fY^`5\u00050U\u001d}14";
        objectArray[61] = "\u000b\u0014885L^\u0002w\u0002.4\u000b\u0014b;4I]A8c";
        objectArray[62] = "\"94@\u0015$~!sBr:\u001b=qF\u001b|*e3\u001f\u0018";
        objectArray[63] = "/\u0018%\u001cy\u0015z\u000ej&nm/\u0018\u007f\u001fx\u0010yM%G";
        objectArray[64] = "\u0010L\u0014.K\u0016EZ[\u0014Kn\u0004\u001aR$G\r\u0006\u001fX} T\u0016\u001d\u001aqN\u0000\u0005\u0018V\u0014";
        objectArray[65] = "o<X\n6\u0013:*\u00170\u001fk<oXLe\u0004lj\u0019L";
        objectArray[66] = "\u007f<\"mg\u001c#$eo\u0000\u0019Fa320\u001b(5 7|";
        objectArray[67] = "~\r_4\u0018\u001ea[_e +Cv;\u0005G[%\u0000[|X\r%Q";
        objectArray[68] = "\u0005\u0007\u001bd&EP\u0011T^4=\u0005\u0007Ag'@SR\u001b?";
        objectArray[69] = "M+i\tA&\u00113.\u000b&+tpq\f\u001c\"\b3rQ\u0019";
        objectArray[70] = "Vm4B-\u001e\tw(\u001eA\u000fmlf\u0017z[\u0014x=\u0013{f";
        objectArray[71] = "s\u0019\u0013<Ke/\u0001T>,bJD\u0002c\u001cb$\u0010\u0011fP";
        objectArray[72] = "c&\u0011pmL60^Jl4wpWzaWuu]#\u0006WguN7~E1#^J";
        objectArray[73] = "K\u001bT>`8\u0017\u0003\u0013<\u0007$r\u0012Md=\"L@Gf\u007f";
        objectArray[74] = "\u0000?. !OR5,bY*6\u0012NY\u001d<n5p c\tPgz\"!";
        objectArray[75] = "~\u0010P\u0005`@\u007f\u001d\u000bR\u001aC\u001e\u001fY\u0005gL~@\t\u0006{*~[\n\u0011|SbJ\u001b\f\u001aK}^\u000f\u000b{Aa\u001b\u0000itN$\u001a\u0011W&D&XiU\u007fO$F\u0015\u0016|\u0012! U\f\u007f\u0010x\\\u0016\u000f\"\u0015\u001e\u001c\f\f Lb_\u000fQ%*\u007fQ\u0002\u000eqHf\u001e\u001b\u0010\u001aI&F\u0000S+\u0011d\u001f\u0003iy\u0012xISX!P!JiSv\u0015.E\u0007\u0007e\u0010b \nQ|C$\u0011R\u0013%@\u001e\u001a\u0005V*OpN\u0016Sf*$LVY\u007fDp_S\u0015\u001aIp\u001d\b\u0014b[&K\u0018i";
        objectArray[76] = ";^aS%\"gF&QB8\u0002\u0003p\fr%lWc\t>";
        objectArray[77] = "4MCJvAa[\fp\\9'L\u0006K$\tgLM\u0000";
        objectArray[78] = "6SA-<~cE\u000e\u0017\u001c\u00066S\u001b.={`\u0006Av";
        objectArray[79] = "&Zs.-\u001a~\u000bes\u001d\u0002\u001bW!>rZ~\frsfk$\u0003r1{\u000b{Sq-\u001d\b#Uwv,Pa\ftLxSf\u000f|!y\ft\\\u001epx\u000e!Ub3{S$3\")xQ}Oa*%T\u001b\u000f{)'\rgLxt\"k!_!|x\u0005uL$0\u001d\u000e+J!}a\u0012p\n.L'\u0007$\u0003{\"s\u0014!O\u001e-~\u0015}Q\u007f'bPr3}t{\u0002!\u0002%6\"\u0001\u001bPpq|\u0016cB&'lk";
        objectArray[80] = "|yR\u007foi)o\u001dEa\u0011-}\u0002~hirg\u001e\"";
        objectArray[81] = "\f\u0003B u\u001fY\u0015\r\u001awg]\u001cM*q\u0006\u0007\u001dBv\u001e\\\u0017\\Lu\u007f\u0006\u0016S\u0010\u001a";
        objectArray[82] = "\u0012'=\u001bU\"@-?Y-F=\u0005H!CxFy\u007f\u001f\u0011rD;";
        objectArray[83] = ":X}\u0005\u001eNoN2?\n6:X'\u0006\u001fKl\r}^";
        objectArray[84] = "\"A<G%RwWs})*/Bn\u0007'\u0017wCy\u0004";
        objectArray[85] = "zG&9\u0015:/Qi\u00034BzG|:\u0014?,\u0012&b";
        objectArray[86] = "\u001eL_:Z,LF]x\"^1a Gd^pF\u0001:\u0018jN\u0014\u000b8Z";
        objectArray[87] = "6\n\u0012x.#c\u001c]B7[6\nH{/&`_\u0012#";
        objectArray[88] = "q$0\r\u001dK-<w\u000fzSHy!RJL&-2W\u0006";
        objectArray[89] = "\u000e3d\u0011.\t[%++8q\u000e3>\u0012/\fXfdJ";
        objectArray[90] = "qQ^\u001a\u0006i-I\u0019\u0018ajH\nF\u001f[m4IEB^";
        objectArray[91] = "\u0013y m\u0010\u0014Oagow\u0018*\"8hM\u0010Va;5H";
        objectArray[92] = "xf&\u0016\u0007J$~a\u0014`EA=>\u0013ZN=~=N_";
        objectArray[93] = "wC\u0016Q'\u001a\"UYk2bwCLR&\u001f!\u0016\u0016\n";
        objectArray[94] = "?<\u0010\ti6c$W\u000b\u000e4\u0006g\b\f42z$\u000bQ1";
        objectArray[95] = "\u001fS\u001bU'mCK\\W@c&\b\u0003PziZK\u0000\r\u007f";
        objectArray[96] = "@3|)^\t\u001c+;+9\u0016ynmv\t\u000e\u0017:~sE";
        objectArray[97] = "\\w_!;(\ta\u0010\u001b9PH!\u0019+73J$\u0013rPlS|[},/P!^\u001b";
        objectArray[98] = "BOL:M{\u0017Y\u0003\u0000J\u0003V\u0019\n0A`T\u001c\u0000i&9D\u001eBeHmW\u001b\u000e\u0000";
        objectArray[99] = "0\u0016Fb\"Zl\u000e\u0001`E^\tKW=u]g\u001fD89";
        objectArray[100] = "0E-n<5(E y\\\u0012\u001b>\u001eJ\u0006H0E-n<5(E y";
        objectArray[101] = "f1\rc*G3'BY(?rgKi&\\pbA0A\u0005``\u0003</QseOY";
        objectArray[102] = "d3bSG;8+%Q 0]hzV\u001a?!+y\u000b\u001f";
        objectArray[103] = "AMd@`\u0012\u001dU#B\u0007\u001ax\u0016|E=\u0016\u0004U\u007f\u00188";
        objectArray[104] = "\u001e\nK&xW\u0001\\Kw@`=gwp|\u0012H\u000e\u000eo*\u0012\u0019";
        objectArray[105] = "\u000f40\n1\bZ\"\u007f00p\u001bbv\u0000=\u0013\u0019g|YZL\u0000?4V&\u000f\u0003b10";
        objectArray[106] = "n\u007f,w7\fl`ttI\\\u0005r#60R|y*v'6";
        objectArray[107] = "d'5\\5^0s?MVJ\twbO;X1r3\\n&";
        objectArray[108] = "\\\u001f~/r9\t\t1\u0015cA\\\u001f$,s<\nJ~t";
        objectArray[109] = "\u0005Li,\u0016\u001aPZ&\u0016=b\u0000\u001bkk\u000f^\u0012X6h";
        objectArray[110] = "\u001b#'NAPN5htL(\tqgI\u0013B@< \u0005";
        objectArray[111] = "rN\u0007#\u001e\u007f.V@!ydK\u0013\u0016|Ix%G\u0005y\u0005";
        objectArray[112] = "\u001d[!vz^OQ#4\u0002+)n@\u0010K$sQ\u007fv8\u0018M\u0003utz";
        objectArray[113] = "n>-7W;:j'&4'\u0003~y1\u0004$`||;]C`n|(I;r8*84";
        Object[] objectArray2 = objectArray;
        objectArray[114] = "iXEr\"@<N\nH18d[\u00172 \u0005<Z\u00001";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = Particles.e(l2, l3);
            object = S[n2];
            try {
                if (!(object instanceof String)) break block2;
                Particles.S[n2] = clazz = Class.forName(T[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = Particles.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = Particles.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = Particles.e(l2, l3);
        Object object = S[n2];
        if (object instanceof String) {
            String string = T[n2];
            int n3 = string.indexOf(8);
            Class clazz = Particles.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = Particles.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = Particles.c(clazz3, string2, clazz2)) != null) {
                    Particles.S[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = Particles.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        Particles.S[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = Particles.f(913554738667825L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = Particles.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = Particles.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = Particles.e(l2, l3);
        Object object = S[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = T[n2];
                int n4 = string2.indexOf(8);
                clazz3 = Particles.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = Particles.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = Particles.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        Particles.S[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = Particles.f(913554738667825L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = Particles.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        Particles.S[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = Particles.f(913554738667825L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == '\u00a4' || c2 == '\u00db' || c2 == 'f' || c2 == '\u00fd') {
                field = Particles.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == '\u00a4' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == '\u00db' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == 'f' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = Particles.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == '\u00cc' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == 'h' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = Particles.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/ag" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Particles.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(Particles.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

