// === Kuzi module: NoRender ===
// Category   : RENDER
// Description: Disables various rendering elements to improve performance
// Payload    : a.a.a.j.g.ae (verified: True)

package kuzi.modules.render;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;
import kuzi.mixin.MixinExposed;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.j.g.aD;
import kuzi.obf.m.r;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.Entity;
import net.minecraft.ArmorStand;
import net.minecraft.ItemFrame;
import net.minecraft.Painting;
import net.minecraft.ItemEntity;
import net.minecraft.EnderMan;
import net.minecraft.Guardian;
import net.minecraft.Slime;
import net.minecraft.Blocks;
import net.minecraft.BlockPos;
import net.minecraft.Vec3i;
import net.minecraft.BlockState;
import net.minecraft.ClientLevel;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class NoRender
extends BaseModule {
    private final BoolSetting rain;
    private final BoolSetting snow;
    private final BoolSetting thunder;
    private final BoolSetting fog;
    private final BoolSetting fire;
    private final BoolSetting water;
    private final BoolSetting lava;
    private final BoolSetting armorStands;
    private final BoolSetting itemFrames;
    private final BoolSetting paintings;
    private final BoolSetting enderman;
    private final BoolSetting guardian;
    private final BoolSetting slime;
    private final BoolSetting droppedItems;
    private final BoolSetting vignette;
    private final BoolSetting hurtCamera;
    private final BoolSetting totemAnimation;
    private final BoolSetting noSwing;
    private final SliderSetting entityDistance;
    private final SliderSetting blockDistance;
    private static final long G = 18493141325635L;
    private static final String[] H;
    private static final String[] I;
    private static final Map J;
    private static final long[] K;
    private static final Integer[] L;
    private static final Map M;
    private static final Object[] N;
    private static final String[] O;

    public NoRender() {
        long l2 = G ^ 0x53CF74928C8DL;
        long l3 = l2 ^ 0x62FDBAF180DBL;
        super("NoRender", "Disables various rendering elements to improve performance", Category.RENDER);
        this.rain = new BoolSetting("Rain", true);
        this.snow = new BoolSetting("Snow", true);
        this.thunder = new BoolSetting("Thunder", true);
        this.fog = new BoolSetting("Fog", false);
        this.fire = new BoolSetting("Fire", false);
        this.water = new BoolSetting("Water", false);
        this.lava = new BoolSetting("Lava", false);
        this.armorStands = new BoolSetting("Armor Stands", false);
        this.itemFrames = new BoolSetting("Item Frames", false);
        this.paintings = new BoolSetting("Paintings", false);
        this.enderman = new BoolSetting("Enderman", false);
        this.guardian = new BoolSetting("Guardian", false);
        this.slime = new BoolSetting("Slime", false);
        this.droppedItems = new BoolSetting("Dropped Items", false);
        this.vignette = new BoolSetting("Vignette", false);
        this.hurtCamera = new BoolSetting("Hurt Camera", false);
        this.totemAnimation = new BoolSetting("Totem Animation", false);
        this.noSwing = new BoolSetting("No Swing", false);
        this.entityDistance = new SliderSetting("Entity Distance", 64.0, 0.0, 1000.0, 1.0);
        this.blockDistance = new SliderSetting("Block Distance", 128.0, 0.0, 1000.0, 1.0);
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.rain, this.snow, this.thunder, this.fog, this.fire, this.water, this.lava, this.armorStands, this.itemFrames, this.paintings, this.enderman, this.guardian, this.slime, this.droppedItems, this.vignette, this.hurtCamera, this.totemAnimation, this.noSwing, this.entityDistance, this.blockDistance};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void i() {
        block9: {
            boolean bl;
            block7: {
                block8: {
                    block6: {
                        int[] nArray;
                        block5: {
                            nArray = aD.b();
                            Object object = BaseModule.a.level;
                            if (nArray != null) {
                                if (object == null) {
                                    return;
                                }
                                object = this.rain.a();
                            }
                            bl = (Boolean)object;
                            if (nArray == null) break block5;
                            if (bl) break block6;
                            bl = (Boolean)this.snow.a();
                        }
                        if (nArray == null) break block7;
                        if (!bl) break block8;
                    }
                    BaseModule.a.level.setRainLevel(0.0f);
                }
                bl = (Boolean)this.thunder.a();
            }
            if (!bl) break block9;
            BaseModule.a.level.setThunderLevel(0.0f);
        }
    }

    @Override
    public void e() {
        block3: {
            ClientLevel level;
            block2: {
                int[] nArray = aD.b();
                level = BaseModule.a.level;
                if (nArray == null) break block2;
                if (level == null) break block3;
                BaseModule.a.level.setRainLevel(1.0f);
                level = BaseModule.a.level;
            }
            level.setThunderLevel(1.0f);
        }
    }

    public boolean a(Object[] objectArray) {
        boolean bl;
        block2: {
            block3: {
                long l2 = (Long)objectArray[0];
                l2 = G ^ l2;
                CallSite callSite = NoRender.d("\u00ef", (long)6058782852178310452L, (long)l2);
                try {
                    bl = (Boolean)((Object)NoRender.d("\u00c6", (Object)NoRender.d("D", (Object)this, (long)6059955414286485630L, (long)l2), (long)6059794063983636848L, (long)l2));
                    if (callSite == null) break block2;
                    if (bl) break block3;
                }
                catch (r r2) {
                    throw NoRender.d("\u00ef", (Object)r2, (long)6060153051358197467L, (long)l2);
                }
                bl = true;
                break block2;
            }
            bl = false;
        }
        return bl;
    }

    public boolean f(Object[] objectArray) {
        boolean bl;
        block2: {
            block3: {
                long l2 = (Long)objectArray[0];
                l2 = G ^ l2;
                CallSite callSite = NoRender.d("\u00ef", (long)7312222490174669915L, (long)l2);
                try {
                    bl = (Boolean)((Object)NoRender.d("\u00c6", (Object)NoRender.d("D", (Object)this, (long)7312464720261751211L, (long)l2), (long)7311475125472772127L, (long)l2));
                    if (callSite == null) break block2;
                    if (bl) break block3;
                }
                catch (r r2) {
                    throw NoRender.d("\u00ef", (Object)r2, (long)7311269004534826932L, (long)l2);
                }
                bl = true;
                break block2;
            }
            bl = false;
        }
        return bl;
    }

    public boolean g(Object[] objectArray) {
        boolean bl;
        block2: {
            block3: {
                long l2 = (Long)objectArray[0];
                l2 = G ^ l2;
                CallSite callSite = NoRender.d("\u00ef", (long)7455502280119666262L, (long)l2);
                try {
                    bl = (Boolean)((Object)NoRender.d("\u00c6", (Object)NoRender.d("D", (Object)this, (long)7456397331588502094L, (long)l2), (long)7456531264753287698L, (long)l2));
                    if (callSite == null) break block2;
                    if (bl) break block3;
                }
                catch (r r2) {
                    throw NoRender.d("\u00ef", (Object)r2, (long)7456729676086592953L, (long)l2);
                }
                bl = true;
                break block2;
            }
            bl = false;
        }
        return bl;
    }

    @MixinExposed
    public boolean h() {
        int[] nArray = aD.b();
        boolean bl = (Boolean)this.fog.a();
        if (nArray != null) {
            bl = !bl;
        }
        return bl;
    }

    @MixinExposed
    public boolean i() {
        int[] nArray = aD.b();
        boolean bl = (Boolean)this.hurtCamera.a();
        if (nArray != null) {
            bl = !bl;
        }
        return bl;
    }

    @MixinExposed
    public boolean j() {
        int[] nArray = aD.b();
        boolean bl = (Boolean)this.totemAnimation.a();
        if (nArray != null) {
            bl = !bl;
        }
        return bl;
    }

    @MixinExposed
    public boolean k() {
        int[] nArray = aD.b();
        boolean bl = (Boolean)this.noSwing.a();
        if (nArray != null) {
            bl = !bl;
        }
        return bl;
    }

    /*
     * Unable to fully structure code
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @MixinExposed
    public boolean a(Entity entity) {
        var4_2 = aD.b();
        if (entity == null) return true;
        v0 = BaseModule.a.player;
        if (var4_2 != null) {
            if (v0 == null) {
                return true;
            }
            v0 = entity;
        }
        if (v0 == BaseModule.a.player) {
            return true;
        }
        cfr_temp_0 = (double)BaseModule.a.player.distanceTo(entity) - (Double)this.entityDistance.a();
        v1 = cfr_temp_0 == 0.0 ? 0 : (cfr_temp_0 > 0.0 ? 1 : -1);
        if (var4_2 != null) {
            if (v1 > 0) {
                return false;
            }
            v1 = (double)((Boolean)this.droppedItems.a()).booleanValue();
        }
        if (var4_2 != null) {
            if (v1 != false) {
                v1 = (double)(entity instanceof ItemEntity);
                if (var4_2 != null) {
                    if (v1 != false) {
                        return false;
                    } else {
                        ** GOTO lbl-1000
                    }
                }
            } else lbl-1000:
            // 3 sources

            {
                v1 = (double)((Boolean)this.armorStands.a()).booleanValue();
            }
        }
        if (var4_2 != null) {
            if (v1 != false) {
                v1 = (double)(entity instanceof ArmorStand);
                if (var4_2 != null) {
                    if (v1 != false) {
                        return false;
                    } else {
                        ** GOTO lbl-1000
                    }
                }
            } else lbl-1000:
            // 3 sources

            {
                v1 = (double)((Boolean)this.itemFrames.a()).booleanValue();
            }
        }
        if (var4_2 != null) {
            if (v1 != false) {
                v1 = (double)(entity instanceof ItemFrame);
                if (var4_2 != null) {
                    if (v1 != false) {
                        return false;
                    } else {
                        ** GOTO lbl-1000
                    }
                }
            } else lbl-1000:
            // 3 sources

            {
                v1 = (double)((Boolean)this.paintings.a()).booleanValue();
            }
        }
        if (var4_2 != null) {
            if (v1 != false) {
                v1 = (double)(entity instanceof Painting);
                if (var4_2 != null) {
                    if (v1 != false) {
                        return false;
                    } else {
                        ** GOTO lbl-1000
                    }
                }
            } else lbl-1000:
            // 3 sources

            {
                v1 = (double)((Boolean)this.enderman.a()).booleanValue();
            }
        }
        if (var4_2 != null) {
            if (v1 != false) {
                v1 = (double)(entity instanceof EnderMan);
                if (var4_2 != null) {
                    if (v1 != false) {
                        return false;
                    } else {
                        ** GOTO lbl-1000
                    }
                }
            } else lbl-1000:
            // 3 sources

            {
                v1 = (double)((Boolean)this.guardian.a()).booleanValue();
            }
        }
        if (var4_2 != null) {
            if (v1 != false) {
                v1 = (double)(entity instanceof Guardian);
                if (var4_2 != null) {
                    if (v1 != false) {
                        return false;
                    } else {
                        ** GOTO lbl-1000
                    }
                }
            } else lbl-1000:
            // 3 sources

            {
                v1 = (double)((Boolean)this.slime.a()).booleanValue();
            }
        }
        if (var4_2 == null) return (boolean)v1;
        if (v1 == false) ** GOTO lbl-1000
        v1 = (double)(entity instanceof Slime);
        if (var4_2 == null) return (boolean)v1;
        if (v1 == false) lbl-1000:
        // 2 sources

        {
            v1 = (double)true;
            return (boolean)v1;
        } else {
            v1 = (double)false;
        }
        return (boolean)v1;
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    public boolean d(Object[] var1_1) {
        block46: {
            block48: {
                block43: {
                    block45: {
                        block44: {
                            block40: {
                                block42: {
                                    block41: {
                                        block38: {
                                            block39: {
                                                block36: {
                                                    block37: {
                                                        var2_2 = (BlockState)var1_1[0];
                                                        var3_3 = (BlockPos)var1_1[1];
                                                        var4_4 = (Long)var1_1[2];
                                                        var4_4 = NoRender.G ^ var4_4;
                                                        var6_5 = NoRender.d("\u00ef", (long)4492087411150266230L, (long)var4_4);
                                                        try {
                                                            block35: {
                                                                try {
                                                                    try {
                                                                        if (var2_2 == null) break block35;
                                                                        v0 = NoRender.d("X", (long)4492473557882888031L, (long)var4_4).player;
                                                                        if (var4_4 < 0L || var6_5 == null) break block36;
                                                                    }
                                                                    catch (r v1) {
                                                                        throw NoRender.d("\u00ef", (Object)v1, (long)4493460222735096985L, (long)var4_4);
                                                                    }
                                                                    if (v0 != null) break block37;
                                                                }
                                                                catch (r v2) {
                                                                    throw NoRender.d("\u00ef", (Object)v2, (long)4493460222735096985L, (long)var4_4);
                                                                }
                                                            }
                                                            return true;
                                                        }
                                                        catch (r v3) {
                                                            throw NoRender.d("\u00ef", (Object)v3, (long)4493460222735096985L, (long)var4_4);
                                                        }
                                                    }
                                                    v0 = NoRender.d("X", (long)4492473557882888031L, (long)var4_4).player;
                                                }
                                                try {
                                                    try {
                                                        cfr_temp_0 = v0.blockPosition().distSqr((Vec3i)var3_3) - (Double)NoRender.d("\u00c6", (Object)NoRender.d("D", (Object)this, (long)4493395982793684079L, (long)var4_4), (long)4493099068541541170L, (long)var4_4) * (Double)NoRender.d("\u00c6", (Object)NoRender.d("D", (Object)this, (long)4493395982793684079L, (long)var4_4), (long)4493099068541541170L, (long)var4_4);
                                                        v4 = cfr_temp_0 == 0.0 ? 0 : (cfr_temp_0 > 0.0 ? 1 : -1);
                                                        v5 = var6_5;
                                                        if (var4_4 >= 0L) {
                                                            if (v5 == null) break block38;
                                                            if (v4 <= 0) break block39;
                                                        }
                                                        ** GOTO lbl50
                                                    }
                                                    catch (r v6) {
                                                        throw NoRender.d("\u00ef", (Object)v6, (long)4493460222735096985L, (long)var4_4);
                                                    }
                                                    return false;
                                                }
                                                catch (r v7) {
                                                    throw NoRender.d("\u00ef", (Object)v7, (long)4493460222735096985L, (long)var4_4);
                                                }
                                            }
                                            v4 = (double)((Boolean)NoRender.d("\u00c6", (Object)NoRender.d("D", (Object)this, (long)4493525748064244247L, (long)var4_4), (long)4493099068541541170L, (long)var4_4)).booleanValue();
                                        }
                                        try {
                                            try {
                                                try {
                                                    try {
                                                        v5 = var6_5;
lbl50:
                                                        // 2 sources

                                                        if (var4_4 > 0L) {
                                                            if (v5 == null) break block40;
                                                            if (v4 == false) break block41;
                                                        }
                                                        ** GOTO lbl79
                                                    }
                                                    catch (r v8) {
                                                        throw NoRender.d("\u00ef", (Object)v8, (long)4493460222735096985L, (long)var4_4);
                                                    }
                                                    v9 /* !! */  = var2_2.getBlock();
                                                    if (var6_5 == null) break block42;
                                                }
                                                catch (r v10) {
                                                    throw NoRender.d("\u00ef", (Object)v10, (long)4493460222735096985L, (long)var4_4);
                                                }
                                                if (v9 /* !! */  != Blocks.WATER) break block41;
                                            }
                                            catch (r v11) {
                                                throw NoRender.d("\u00ef", (Object)v11, (long)4493460222735096985L, (long)var4_4);
                                            }
                                            return false;
                                        }
                                        catch (r v12) {
                                            throw NoRender.d("\u00ef", (Object)v12, (long)4493460222735096985L, (long)var4_4);
                                        }
                                    }
                                    v9 /* !! */  = NoRender.d("\u00c6", (Object)NoRender.d("D", (Object)this, (long)4491860366344191257L, (long)var4_4), (long)4493099068541541170L, (long)var4_4);
                                }
                                v4 = (double)((Boolean)v9 /* !! */ ).booleanValue();
                            }
                            try {
                                try {
                                    try {
                                        try {
                                            v5 = var6_5;
lbl79:
                                            // 2 sources

                                            if (var4_4 >= 0L) {
                                                if (v5 == null) break block43;
                                                if (v4 == false) break block44;
                                            }
                                            ** GOTO lbl107
                                        }
                                        catch (r v13) {
                                            throw NoRender.d("\u00ef", (Object)v13, (long)4493460222735096985L, (long)var4_4);
                                        }
                                        v14 /* !! */  = var2_2.getBlock();
                                        if (var6_5 == null) break block45;
                                    }
                                    catch (r v15) {
                                        throw NoRender.d("\u00ef", (Object)v15, (long)4493460222735096985L, (long)var4_4);
                                    }
                                    if (v14 /* !! */  != Blocks.LAVA) break block44;
                                }
                                catch (r v16) {
                                    throw NoRender.d("\u00ef", (Object)v16, (long)4493460222735096985L, (long)var4_4);
                                }
                                return false;
                            }
                            catch (r v17) {
                                throw NoRender.d("\u00ef", (Object)v17, (long)4493460222735096985L, (long)var4_4);
                            }
                        }
                        v14 /* !! */  = NoRender.d("\u00c6", (Object)NoRender.d("D", (Object)this, (long)4492159503340694265L, (long)var4_4), (long)4493099068541541170L, (long)var4_4);
                    }
                    v4 = (double)((Boolean)v14 /* !! */ ).booleanValue();
                }
                try {
                    block47: {
                        try {
                            try {
                                v5 = var6_5;
lbl107:
                                // 2 sources

                                if (v5 == null) break block46;
                                if (v4 == false) break block47;
                            }
                            catch (r v18) {
                                throw NoRender.d("\u00ef", (Object)v18, (long)4493460222735096985L, (long)var4_4);
                            }
                            if (var2_2.getBlock() == Blocks.FIRE) break block48;
                        }
                        catch (r v19) {
                            throw NoRender.d("\u00ef", (Object)v19, (long)4493460222735096985L, (long)var4_4);
                        }
                    }
                    v4 = (double)true;
                    break block46;
                }
                catch (r v20) {
                    throw NoRender.d("\u00ef", (Object)v20, (long)4493460222735096985L, (long)var4_4);
                }
            }
            v4 = (double)false;
        }
        return (boolean)v4;
    }

    static {
        N = new Object[]{"D=4YCuO=?", "\b)/Ev%\b)8\u0019z*\u0012b8\u0007z?\u0015\u0013hZ+", "\u00078\u00010Y|\f8\u00070Y\u0016", "bq", "CLnd-JHLhd-\u0001", "w\tT\u001b`\u0001~\tW\u001bb", ",\u007fongY \u007f|", "\u00121\u00122Vk\u001b1\u00112V", "\u001b9\u007fS\u001d1\u00106n\u001c|?\u001b=jF", "_\u0004r\u0012'\u001bV\u0004q\u0012+", "'\u001cpL ~,\u001cx", "fK;M2E\u0013k0B#\nre;I'P\u0006", Void.TYPE, "g[\u0004e5ue\u000f\u0000=^4\\\u000b\u0002$;taWB`9", "\u001f\u0011ek\u0013\b\u001dEa3x\u007f$Ac*\u001d\t\u0019\u001d#n\u001f", ">/t\r)W<{pUB\u0014\u0005\u007frL'V8#2\b%", "Gm>W\u001c\u0019E9:\u000fwG|=8\u0016\u0012\u0018AaxR\u0010", "&KPs\u0012j$\u001fT+y,\u001d\u001bV2\u001ck G\u0016v\u001e", "Zhz\u0004j9X<~\\\u0001ka?=A0l[rsX?\u0002]=~\ro8\u0010sg\u0002\u0001", "^\t/(\t5\\]+pb@e\\9,\u0010e\u0003\u0006?/\u000f", "f \u0018q%\u0011dt\u001c)Ng]u\u000eu<A;/\bv#", "o*R\bO@m~VP$\u001cTzTIAAi&\u0014\rC", "W!I+R8UuMs9}lqOj\\9Q-\u000f.^", "\u001a%wgT)\u001fc\u007f=-)' w}\u0015-Ua-n\u0011@", "YWkDEE[\u0003o\u001c.\u000fb\u0007m\u0005KD_[-AI", "?Rt\n\u0010\u0017=\u0006pR{\\\u0004\u0002rK\u001e\u00169^2\u000f\u001c", "\u000e\u0018buTg\fLf-? 5Hd4Zf\b\u0014$pX", "\u0011\u001e__Z\u0004EA\u0011F?5ch/`eo\u0011\u001e__Z\u0004EA\u0011F", "`\u0010\\\u0000LQ>K\u001d?GldMJ@\u0017]7\u001dJ\\", "hv*<]nj\".d6\u001eS&,}Sonzl9Q", "?y'N_j=-#\u00164\u0018\u0004)!\u000fQk9uaKS", "/\n,B\u0016 -^(\u001a}i\u0014Z*\u0003\u0018!)\u0006jG\u001a", "NJeMB-L\u001ea\u0015)ou\u001ac\fL,HF#HN", "zEo4[z<\u000eh(:{C\u000f/1\u0001 /Eq P\u0011", "huo>-Qj!kfF S%i\u007f#Pny);!", "<\u0014=o\u000e\u0018>@97e\\\u0007D;.\u0000\u0019:\u0018{j\u0002", "Wu(|<,U!,$Wll%.=2-Qyny0", "`Z*?ddb\u000e.g\u000f9[\n,~jefVl:h", "L&XX\f\u0011\u0012}\u0019g\n,AyM\fTL\u001cx\u001e\u0007n\u001c\u001e\"L\u0001^L\u001d Dg"};
        O = new String[]{null, null, null, null, null, null, null, null, null, null, null, null, "java/lang/Void", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null};
    }

    private static r a(r r2) {
        return r2;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (O[n4] != null) {
            return n4;
        }
        Object object = N[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 29;
            case 1 -> 24;
            case 2 -> 57;
            case 3 -> 39;
            case 4 -> 0;
            case 5 -> 43;
            case 6 -> 46;
            case 7 -> 8;
            case 8 -> 4;
            case 9 -> 54;
            case 10 -> 10;
            case 11 -> 23;
            case 12 -> 12;
            case 13 -> 21;
            case 14 -> 41;
            case 15 -> 28;
            case 16 -> 51;
            case 17 -> 47;
            case 18 -> 33;
            case 19 -> 17;
            case 20 -> 53;
            case 21 -> 6;
            case 22 -> 52;
            case 23 -> 16;
            case 24 -> 32;
            case 25 -> 14;
            case 26 -> 13;
            case 27 -> 62;
            case 28 -> 2;
            case 29 -> 22;
            case 30 -> 9;
            case 31 -> 20;
            case 32 -> 19;
            case 33 -> 35;
            case 34 -> 26;
            case 35 -> 18;
            case 36 -> 15;
            case 37 -> 61;
            case 38 -> 40;
            case 39 -> 50;
            case 40 -> 34;
            case 41 -> 38;
            case 42 -> 58;
            case 43 -> 1;
            case 44 -> 5;
            case 45 -> 36;
            case 46 -> 59;
            case 47 -> 60;
            case 48 -> 11;
            case 49 -> 25;
            case 50 -> 56;
            case 51 -> 7;
            case 52 -> 44;
            case 53 -> 63;
            case 54 -> 55;
            case 55 -> 30;
            case 56 -> 3;
            case 57 -> 27;
            case 58 -> 49;
            case 59 -> 31;
            case 60 -> 45;
            case 61 -> 37;
            case 62 -> 42;
            default -> 48;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        NoRender.O[n4] = new String(cArray);
        return n4;
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = NoRender.e(l2, l3);
            object = N[n2];
            try {
                if (!(object instanceof String)) break block2;
                NoRender.N[n2] = clazz = Class.forName(O[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = NoRender.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = NoRender.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = NoRender.e(l2, l3);
        Object object = N[n2];
        if (object instanceof String) {
            String string = O[n2];
            int n3 = string.indexOf(8);
            Class clazz = NoRender.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = NoRender.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = NoRender.c(clazz3, string2, clazz2)) != null) {
                    NoRender.N[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = NoRender.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        NoRender.N[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = NoRender.f(611633207600500L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = NoRender.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = NoRender.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = NoRender.e(l2, l3);
        Object object = N[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = O[n2];
                int n4 = string2.indexOf(8);
                clazz3 = NoRender.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = NoRender.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = NoRender.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        NoRender.N[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = NoRender.f(611633207600500L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = NoRender.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        NoRender.N[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = NoRender.f(611633207600500L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == 'D' || c2 == '\u00f1' || c2 == 'X' || c2 == 'J') {
                field = NoRender.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == 'D' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == '\u00f1' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == 'X' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = NoRender.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == '\u00c6' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == '\u00ef' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = NoRender.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/ae" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(NoRender.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

