// === Kuzi module: Xray ===
// Category   : RENDER
// Description: Renders only selected ores through walls.
// Payload    : a.a.a.j.g.ap (verified: True)

package kuzi.modules.render;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.mixin.MixinExposed;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.b.b;
import kuzi.obf.h.b.v;
import kuzi.obf.j.g.aD;
import kuzi.obf.m.r;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import net.minecraft.MobEffectInstance;
import net.minecraft.MobEffects;
import net.minecraft.Blocks;
import net.minecraft.Block;
import net.minecraft.BlockState;
import net.minecraft.Minecraft;
import net.minecraft.LocalPlayer;
import net.minecraft.LevelRenderer;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class Xray
extends BaseModule {
    private static volatile Xray instance;
    private final BoolSetting fullbright;
    private final BoolSetting throughLiquids;
    private final b blocks;
    private static final long q;
    private static final String[] r;
    private static final String[] s;
    private static final Map t;
    private static final long[] u;
    private static final Integer[] v;
    private static final Map w;
    private static final Object[] x;
    private static final String[] y;

    public Xray() {
        long l2 = q ^ 0x15F29BC707C4L;
        long l3 = l2 ^ 0x563218B6C3A7L;
        super("Xray", "Renders only selected ores through walls.", Category.RENDER);
        this.fullbright = new BoolSetting("Fullbright", true);
        this.throughLiquids = new BoolSetting("Through Liquids", true);
        this.blocks = new b("Blocks", Xray.a(new Object[0]));
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.fullbright, this.throughLiquids, this.blocks};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @MixinExposed
    public boolean a() {
        return (Boolean)this.throughLiquids.a();
    }

    @Override
    public void d() {
        long l2 = q ^ 0x9AE347AF8BBL;
        long l3 = l2 ^ 0x55A9F211966CL;
        instance = this;
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.a(objectArray);
    }

    @Override
    public void e() {
        block6: {
            LocalPlayer player;
            block5: {
                long l2 = q ^ 0x1CD22D9B9895L;
                long l3 = l2 ^ 0x40D5EBF0F642L;
                int[] nArray = aD.b();
                Xray self = instance;
                if (nArray != null) {
                    if (self == this) {
                        instance = null;
                    }
                    self = this;
                }
                Object[] objectArray = new Object[1];
                objectArray[0] = l3;
                self.a(objectArray);
                player = BaseModule.a.player;
                if (nArray == null) break block5;
                if (player == null) break block6;
                player = BaseModule.a.player;
            }
            player.removeEffect(MobEffects.NIGHT_VISION);
        }
    }

    @Override
    public void i() {
        block7: {
            long l2;
            block6: {
                MobEffectInstance nightVision;
                block5: {
                    MobEffectInstance mc12933;
                    LocalPlayer player;
                    int[] nArray;
                    block3: {
                        block4: {
                            block2: {
                                long l3 = q ^ 0x11B560EE3F97L;
                                l2 = l3 ^ 0x554E654242BBL;
                                nArray = aD.b();
                                if (!((Boolean)this.fullbright.a()).booleanValue()) break block2;
                                player = BaseModule.a.player;
                                if (nArray == null) break block3;
                                if (player != null) break block4;
                            }
                            return;
                        }
                        player = BaseModule.a.player;
                    }
                    nightVision = mc12933 = player.getEffect(MobEffects.NIGHT_VISION);
                    if (nArray == null) break block5;
                    if (nightVision == null) break block6;
                    nightVision = mc12933;
                }
                if (nightVision.getDuration() >= 220) break block7;
            }
            BaseModule.a.execute(() -> Xray.lambda$onTick$0(l2));
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @MixinExposed
    public boolean a(BlockState blockState) {
        long l2 = q ^ 0x428C8A70E0D5L;
        long l3 = l2 ^ 0x651F76280E79L;
        int[] nArray = aD.b();
        if (blockState == null) return false;
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        boolean bl = this.blocks.a(objectArray).contains(blockState.getBlock());
        if (nArray == null) return bl;
        if (!bl) return false;
        return true;
    }

    private void a(Object[] objectArray) {
        block3: {
            Minecraft client;
            long l2;
            block2: {
                long l3 = (Long)objectArray[0];
                l2 = (l3 = q ^ l3) ^ 0x6E61418E42ECL;
                int[] nArray = aD.b();
                client = BaseModule.a;
                if (nArray == null) break block2;
                if (client.levelRenderer == null) break block3;
                client = BaseModule.a;
            }
            client.execute(() -> Xray.lambda$reloadChunks$1(l2));
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @MixinExposed
    public static Xray a() {
        Xray cached = instance;
        int[] nArray = aD.b();
        Xray result = cached;
        if (nArray != null) {
            if (result == null) return null;
            result = cached;
        }
        if (nArray == null) return result;
        if (!result.d()) return null;
        result = cached;
        return result;
    }

    private static Set a(Object[] objectArray) {
        LinkedHashSet<Block> defaultBlocks = new LinkedHashSet<Block>();
        defaultBlocks.add(Blocks.DIAMOND_ORE);
        defaultBlocks.add(Blocks.DEEPSLATE_DIAMOND_ORE);
        defaultBlocks.add(Blocks.ANCIENT_DEBRIS);
        defaultBlocks.add(Blocks.EMERALD_ORE);
        defaultBlocks.add(Blocks.DEEPSLATE_EMERALD_ORE);
        defaultBlocks.add(Blocks.GOLD_ORE);
        defaultBlocks.add(Blocks.DEEPSLATE_GOLD_ORE);
        defaultBlocks.add(Blocks.NETHER_GOLD_ORE);
        defaultBlocks.add(Blocks.IRON_ORE);
        defaultBlocks.add(Blocks.DEEPSLATE_IRON_ORE);
        defaultBlocks.add(Blocks.REDSTONE_ORE);
        defaultBlocks.add(Blocks.DEEPSLATE_REDSTONE_ORE);
        defaultBlocks.add(Blocks.LAPIS_ORE);
        defaultBlocks.add(Blocks.DEEPSLATE_LAPIS_ORE);
        defaultBlocks.add(Blocks.COAL_ORE);
        defaultBlocks.add(Blocks.DEEPSLATE_COAL_ORE);
        defaultBlocks.add(Blocks.COPPER_ORE);
        defaultBlocks.add(Blocks.DEEPSLATE_COPPER_ORE);
        defaultBlocks.add(Blocks.NETHER_QUARTZ_ORE);
        defaultBlocks.add(Blocks.SPAWNER);
        defaultBlocks.add(Blocks.CHEST);
        defaultBlocks.add(Blocks.TRAPPED_CHEST);
        return defaultBlocks;
    }

    private static void lambda$reloadChunks$1(long l2) {
        block5: {
            LevelRenderer mc7612;
            block4: {
                l2 = q ^ l2;
                CallSite callSite = Xray.d("\u00e6", (long)8306929771820391546L, (long)l2);
                try {
                    try {
                        mc7612 = ((Minecraft)Xray.d("\u00cc", (long)8307359203091161367L, (long)l2)).levelRenderer;
                        if (callSite == null) break block4;
                        if (mc7612 == null) break block5;
                    }
                    catch (r r2) {
                        throw Xray.d("\u00e6", (Object)r2, (long)8308006272060216073L, (long)l2);
                    }
                    mc7612 = ((Minecraft)Xray.d("\u00cc", (long)8307359203091161367L, (long)l2)).levelRenderer;
                }
                catch (r r3) {
                    throw Xray.d("\u00e6", (Object)r3, (long)8308006272060216073L, (long)l2);
                }
            }
            mc7612.allChanged();
        }
    }

    private static void lambda$onTick$0(long l2) {
        block5: {
            LocalPlayer player;
            int[] nArray;
            block4: {
                l2 = q ^ l2;
                nArray = aD.b();
                player = BaseModule.a.player;
                if (nArray == null) break block4;
                if (player == null) break block5;
                player = BaseModule.a.player;
            }
            boolean hasNightVision = player.hasEffect(MobEffects.NIGHT_VISION);
            if (nArray != null && !hasNightVision) {
                hasNightVision = BaseModule.a.player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, (int)Xray.c("x", (int)5063, (long)(0x6225E2D616287048L ^ l2)), 0, false, false, false));
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block16: {
            block15: {
                block14: {
                    block13: {
                        Xray.q = kuzi.obf.h.b.v.a(1310224948064480130L, 1149742893495105749L, MethodHandles.lookup().lookupClass()).a(97781962232265L);
                        Xray.x = new Object[32];
                        Xray.y = new String[32];
                        Xray.c();
                        Xray.t = new HashMap<K, V>(13);
                        var11 = Xray.q ^ 83764794603782L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[5];
                        var18_4 = 0;
                        var17_5 = "\u008f\u0083\u00c5bg\u0014\u00bch\u00f7>[[@?\u0086\u0017d\u00e7!P\"s\u00c4<\u0010\u00dc+\u0094\u00dd\u0002\u000f`\u0095{\u00ef,\u001f\u00c5\u00f8\u00e0\u0090H3\u0014\u0093\u00f1C\u00d3\u000ei \u00a2\u0006\u00bfQ%i\u00d87\u0094\u00dd]VC\u0001\u001c\u00d9_\u0016s\u00ba\u00ef\u00c7\u0093\u000f\u001d\n\u0096\u0096\u00ec+\u00d6\u0087_\u00a5\u00f4TD\u00ce\u0085\f\u00ea\u00d9\u00db\u00d8\u00b46\u0086\u008c'\u00dd-\u00f8\u00f7\u00cc\u0018y\n\u00fa\u009e\u0003MX1";
                        var19_6 = "\u008f\u0083\u00c5bg\u0014\u00bch\u00f7>[[@?\u0086\u0017d\u00e7!P\"s\u00c4<\u0010\u00dc+\u0094\u00dd\u0002\u000f`\u0095{\u00ef,\u001f\u00c5\u00f8\u00e0\u0090H3\u0014\u0093\u00f1C\u00d3\u000ei \u00a2\u0006\u00bfQ%i\u00d87\u0094\u00dd]VC\u0001\u001c\u00d9_\u0016s\u00ba\u00ef\u00c7\u0093\u000f\u001d\n\u0096\u0096\u00ec+\u00d6\u0087_\u00a5\u00f4TD\u00ce\u0085\f\u00ea\u00d9\u00db\u00d8\u00b46\u0086\u008c'\u00dd-\u00f8\u00f7\u00cc\u0018y\n\u00fa\u009e\u0003MX1".length();
                        var16_7 = 24;
                        var15_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block13;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = Xray.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "9Oq\u008b\u00f5\u00e8\u008f\u008f\u0015\u009b\u0086)j/\u001e\u00b0 ^~'\u00d0\u00ff?\u00166\u0006\u00d1\u00f4\u0011\\k\t:\u00d5A5\u00f6d\u00cei\u00b9\u00ea\u00d4\u00d8\u00d5?w\u0016\u0014";
                            var19_6 = "9Oq\u008b\u00f5\u00e8\u008f\u008f\u0015\u009b\u0086)j/\u001e\u00b0 ^~'\u00d0\u00ff?\u00166\u0006\u00d1\u00f4\u0011\\k\t:\u00d5A5\u00f6d\u00cei\u00b9\u00ea\u00d4\u00d8\u00d5?w\u0016\u0014".length();
                            var16_7 = 16;
                            var15_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block13;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = Xray.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block14;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                Xray.r = var20_3;
                Xray.s = new String[5];
                Xray.w = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[2];
                var3_13 = 0;
                var4_14 = "\u00f2b\u00c5\u008d\u0091\u00e7\u00cf\u001a5\u00ef\u00c8\u0087\u00b7Iz\u00c7";
                var5_15 = "\u00f2b\u00c5\u008d\u0091\u00e7\u00cf\u001a5\u00ef\u00c8\u0087\u00b7Iz\u00c7".length();
                var2_16 = 0;
                while (true) {
                    break block15;
                    break;
                }
lbl76:
                // 1 sources

                while (true) {
                    var6_12[v10] = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
                    if (var2_16 < var5_15) ** continue;
                    break block16;
                    break;
                }
            }
            var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
            v10 = var3_13++;
            var8_18 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            ** while (true)
        }
        Xray.u = var6_12;
        Xray.v = new Integer[2];
    }

    private static r a(r r2) {
        return r2;
    }

    private static String b(byte[] bytes) {
        int outIndex = 0;
        int length = bytes.length;
        char[] chars = new char[length];
        for (int i2 = 0; i2 < length; ++i2) {
            char decodedChar;
            int byteValue = 0xFF & bytes[i2];
            if (byteValue < 192) {
                chars[outIndex++] = (char)byteValue;
                continue;
            }
            if (byteValue < 224) {
                decodedChar = (char)((char)(byteValue & 0x1F) << 6);
                byteValue = bytes[++i2];
                decodedChar = (char)(decodedChar | (char)(byteValue & 0x3F));
                chars[outIndex++] = decodedChar;
                continue;
            }
            if (i2 >= length - 2) continue;
            decodedChar = (char)((char)(byteValue & 0xF) << 12);
            byteValue = bytes[++i2];
            decodedChar = (char)(decodedChar | (char)(byteValue & 0x3F) << 6);
            byteValue = bytes[++i2];
            decodedChar = (char)(decodedChar | (char)(byteValue & 0x3F));
            chars[outIndex++] = decodedChar;
        }
        return new String(chars, 0, outIndex);
    }

    private static int c(int n2, long l2) {
        int cacheIndex = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x1EA3;
        if (v[cacheIndex] == null) {
            byte[] decryptedBytes;
            byte[] keyBytes = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long key = u[cacheIndex];
            byte[] encryptedBytes = new byte[]{(byte)(key >>> 56), (byte)(key >>> 48), (byte)(key >>> 40), (byte)(key >>> 32), (byte)(key >>> 24), (byte)(key >>> 16), (byte)(key >>> 8), (byte)key};
            Long threadId = Thread.currentThread().threadId();
            Object[] threadCaches = (Object[])w.get(threadId);
            try {
                if (threadCaches == null) {
                    threadCaches = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    w.put(threadId, threadCaches);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(keyBytes);
                SecretKey secretKey = ((SecretKeyFactory)threadCaches[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)threadCaches[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)threadCaches[2]);
                decryptedBytes = cipher.doFinal(encryptedBytes);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/g/ap", exception);
            }
            int decryptedValue = (decryptedBytes[4] & 0xFF) << 24 | (decryptedBytes[5] & 0xFF) << 16 | (decryptedBytes[6] & 0xFF) << 8 | decryptedBytes[7] & 0xFF;
            Xray.v[cacheIndex] = decryptedValue;
        }
        return v[cacheIndex];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = Xray.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/ap" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int decodeIndex(long l2, long l3) {
        int n2;
        int n3;
        int tableIndex = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (y[tableIndex] != null) {
            return tableIndex;
        }
        Object entry = x[tableIndex];
        if (!(entry instanceof String)) {
            return tableIndex;
        }
        int decodeOffset = 0;
        decodeOffset = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 46;
            case 1 -> 31;
            case 2 -> 14;
            case 3 -> 19;
            case 4 -> 29;
            case 5 -> 11;
            case 6 -> 8;
            case 7 -> 41;
            case 8 -> 22;
            case 9 -> 44;
            case 10 -> 60;
            case 11 -> 2;
            case 12 -> 63;
            case 13 -> 55;
            case 14 -> 57;
            case 15 -> 5;
            case 16 -> 47;
            case 17 -> 50;
            case 18 -> 43;
            case 19 -> 45;
            case 20 -> 25;
            case 21 -> 54;
            case 22 -> 36;
            case 23 -> 58;
            case 24 -> 1;
            case 25 -> 12;
            case 26 -> 62;
            case 27 -> 26;
            case 28 -> 18;
            case 29 -> 9;
            case 30 -> 32;
            case 31 -> 52;
            case 32 -> 23;
            case 33 -> 6;
            case 34 -> 38;
            case 35 -> 49;
            case 36 -> 17;
            case 37 -> 30;
            case 38 -> 48;
            case 39 -> 56;
            case 40 -> 35;
            case 41 -> 33;
            case 42 -> 0;
            case 43 -> 37;
            case 44 -> 59;
            case 45 -> 21;
            case 46 -> 28;
            case 47 -> 4;
            case 48 -> 24;
            case 49 -> 16;
            case 50 -> 39;
            case 51 -> 20;
            case 52 -> 10;
            case 53 -> 34;
            case 54 -> 51;
            case 55 -> 27;
            case 56 -> 42;
            case 57 -> 13;
            case 58 -> 7;
            case 59 -> 15;
            case 60 -> 40;
            case 61 -> 53;
            case 62 -> 61;
            default -> 3;
        };
        int[] keyBytes = new int[6];
        int keyIndex = 0;
        while (keyIndex < 6) {
            n3 = 7 * (5 - keyIndex);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= decodeOffset) < 0) {
                n2 += 128;
            }
            keyBytes[keyIndex] = n2;
            ++keyIndex;
        }
        char[] chars = ((String)entry).toCharArray();
        n3 = 0;
        while (n3 < chars.length) {
            n2 = keyBytes[n3 % keyBytes.length];
            if (n2 == 0) break;
            chars[n3] = (char)(chars[n3] ^ n2);
            ++n3;
        }
        Xray.y[tableIndex] = new String(chars);
        return tableIndex;
    }

    private static void c() {
        Object[] objectArray = x;
        x[0] = "\u001aW.<=D\u0011W(<=\u001a";
        objectArray[1] = "6R\u0010\u001bg\u001bCr\u001b\u0014vT\"|\u0010\u001fr\u000eV";
        objectArray[2] = Void.TYPE;
        Xray.y[2] = "java/lang/Void";
        objectArray[3] = "\u0000\u001bRc\rH\u000b\u001bTc\r\"";
        objectArray[4] = "~&";
        objectArray[5] = "x5MKjRt5^";
        objectArray[6] = "\u00005[t\u0000\u0012\t5Xt\u0003";
        objectArray[7] = "\u00103V\u0004\u001eQe\u0013]\u000b\u000f\u001e\u0004\u001dV\u0000\u000bDp";
        objectArray[8] = "F~\u001bc\ttXv\u0001,tdX";
        objectArray[9] = "S\u0004z(Q\u001cX\u0004q";
        objectArray[10] = "S8b\u0004[=S8uXW2IsuFW'N\u0002%\u001b\u0006";
        objectArray[11] = "&i#70`-i+";
        objectArray[12] = "8G)!N`Mg\"._/,i)%[uX";
        objectArray[13] = "%\u001d\u001bOuQ,\u001d\u0018Ow";
        objectArray[14] = "2\u0004/jtbG$$ee-&*/nawR";
        objectArray[15] = "AP\u0018VR\u001eHP\u001bVR";
        objectArray[16] = "Ep.?TaN\u007f?p5oEt;*";
        objectArray[17] = Boolean.TYPE;
        Xray.y[17] = "java/lang/Boolean";
        objectArray[18] = "aAQ)\\Z6\u0011\u0003m!|\u001c7#^{&aAQ)\\Z6\u0011\u0003m";
        objectArray[19] = "\u0006\u0016U\u0007\u0012qC\u001f\fEo|8O]@\ts\u0001N@\u0004^";
        objectArray[20] = "cS\u0018B-\u001co\u0010#BI\u0006>TFC2\n}";
        objectArray[21] = " IJD3T#\u001b\u0013N]L\u001aL\u001dQ?BcI\u0001\nm&";
        objectArray[22] = "\u0000a%Xwj\f\"\u001eT\u0013 \u001aaxY-a\\=z=))\f!qQ~)\u001e-\u001e";
        objectArray[23] = "\u0006\u0019, 0\f\nZ\u0017,TF\u001c\u0019q!j\u0007ZEsEjJ^\u001fs5$\u0016Y\u001d\u0017";
        objectArray[24] = "OgB+;c\nn\u001biFkqj\u001brxl\u00121J\u007f4\u0007";
        objectArray[25] = "\u0019$O\u0019$+\u0015gt\u001a@a\u0016qL\u0002,)\u0014z\u001a";
        objectArray[26] = "5?C\\sP9|xP\u0017\u0017mn\u0018]{U99\u00049+\u00129c\u001cUiFn\u007fx";
        objectArray[27] = "Gm$\u001boBK.\u001f\u0019\u000b\bH8'\u0000g@J3q";
        objectArray[28] = "\u001f3Hau6\u000b \u000ec\u000fgv)\r(m6\u000b;[we\u000e";
        objectArray[29] = "~Bd]<^r\u0001_@X\u0019e\u00125I L{\u0017'";
        objectArray[30] = "exjkx\u0001 q3)\u0005\u0001[/xhc\u0001en>4aea&n(j\t6&|$\u0005";
        Object[] objectArray2 = objectArray;
        objectArray[31] = "/`\b!T*z~\r3%;\u0013+\u001fwC6-jY+AR-']qA\"c{Zs%";
    }

    private static Class resolveClass(long l2, long l3) {
        Object entry;
        Class<?> clazz;
        block2: {
            clazz = null;
            int tableIndex = Xray.decodeIndex(l2, l3);
            entry = x[tableIndex];
            try {
                if (!(entry instanceof String)) break block2;
                Xray.x[tableIndex] = clazz = Class.forName(y[tableIndex]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)entry;
        return clazz;
    }

    private static Field findDeclaredField(Class ownerClass, String memberName, Class memberType) {
        for (Field field : ownerClass.getDeclaredFields()) {
            if (!field.getName().equals(memberName) || field.getType() != memberType) continue;
            return field;
        }
        return null;
    }

    private static Field findField(Class ownerClass, String memberName, Class memberType) {
        Field field = Xray.findDeclaredField(ownerClass, memberName, memberType);
        if (field != null) {
            return field;
        }
        Class<?>[] interfaces = ownerClass.getInterfaces();
        if (interfaces != null) {
            for (int index = 0; index < interfaces.length; ++index) {
                field = Xray.findField(interfaces[index], memberName, memberType);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field resolveField(long l2, long l3) {
        int tableIndex = Xray.decodeIndex(l2, l3);
        Object entry = x[tableIndex];
        if (entry instanceof String) {
            String descriptor = y[tableIndex];
            int separatorIndex = descriptor.indexOf(8);
            Class clazz = Xray.resolveClass(Long.parseLong(descriptor.substring(0, separatorIndex), 36), 0L);
            int nextSeparatorIndex = descriptor.indexOf(8, ++separatorIndex);
            String memberName = descriptor.substring(separatorIndex, nextSeparatorIndex);
            Class clazz2 = Xray.resolveClass(Long.parseLong(descriptor.substring(++nextSeparatorIndex), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = Xray.findDeclaredField(clazz3, memberName, clazz2)) != null) {
                    Xray.x[tableIndex] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = Xray.findField(classArray[i2], memberName, clazz2);
                        if (field == null) continue;
                        Xray.x[tableIndex] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = Xray.resolveClass(1129112286729275L, 0L);
            }
            StringBuffer errorMessage = new StringBuffer();
            errorMessage.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(memberName);
            throw new RuntimeException(errorMessage.toString());
        }
        return (Field)entry;
    }

    private static Method findDeclaredMethod(Class ownerClass, String memberName, Class returnType, int parameterCount, Class[] expectedParameterTypes) {
        block0: for (Method method : ownerClass.getDeclaredMethods()) {
            Class<?>[] parameterTypes;
            if (!method.getName().equals(memberName) || method.getReturnType() != returnType || (parameterTypes = method.getParameterTypes()).length != parameterCount) continue;
            for (int index = 0; index < parameterCount; ++index) {
                if (parameterTypes[index] != expectedParameterTypes[index]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method findMethod(Class ownerClass, String memberName, Class returnType, int parameterCount, Class[] expectedParameterTypes) {
        Method method = Xray.findDeclaredMethod(ownerClass, memberName, returnType, parameterCount, expectedParameterTypes);
        if (method != null) {
            return method;
        }
        Class<?>[] interfaces = ownerClass.getInterfaces();
        if (interfaces != null) {
            for (int index = 0; index < interfaces.length; ++index) {
                method = Xray.findMethod(interfaces[index], memberName, returnType, parameterCount, expectedParameterTypes);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method resolveMethod(long l2, long l3) {
        int tableIndex = Xray.decodeIndex(l2, l3);
        Object entry = x[tableIndex];
        if (entry instanceof String) {
            Class<?>[] interfaces;
            Class clazz;
            Class clazz2;
            Class[] parameterTypes;
            int parameterCount;
            String methodName;
            Class clazz3;
            block10: {
                String descriptor = y[tableIndex];
                int firstSeparatorIndex = descriptor.indexOf(8);
                clazz3 = Xray.resolveClass(Long.parseLong(descriptor.substring(0, firstSeparatorIndex), 36), 0L);
                int secondSeparatorIndex = descriptor.indexOf(8, ++firstSeparatorIndex);
                methodName = descriptor.substring(firstSeparatorIndex, secondSeparatorIndex);
                int separatorCount = -1;
                int scanIndex = secondSeparatorIndex;
                do {
                    ++separatorCount;
                    ++scanIndex;
                } while ((scanIndex = descriptor.indexOf(8, scanIndex)) > -1);
                parameterCount = separatorCount - 1;
                parameterTypes = new Class[parameterCount];
                clazz2 = null;
                scanIndex = secondSeparatorIndex + 1;
                for (int i2 = 0; i2 < separatorCount; ++i2) {
                    int nextSeparatorIndex = descriptor.indexOf(8, scanIndex);
                    clazz2 = Xray.resolveClass(Long.parseLong(descriptor.substring(scanIndex, nextSeparatorIndex), 36), 0L);
                    if (i2 < parameterCount) {
                        parameterTypes[i2] = clazz2;
                    }
                    scanIndex = nextSeparatorIndex + 1;
                }
                clazz = clazz3;
                do {
                    if ((interfaces = Xray.findDeclaredMethod(clazz, methodName, clazz2, parameterCount, parameterTypes)) != null) {
                        Xray.x[tableIndex] = interfaces;
                        return interfaces;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = Xray.resolveClass(1129112286729275L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((interfaces = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < interfaces.length; ++i3) {
                        Method method = Xray.findMethod(interfaces[i3], methodName, clazz2, parameterCount, parameterTypes);
                        if (method == null) continue;
                        Xray.x[tableIndex] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = Xray.resolveClass(1129112286729275L, 0L);
            }
            StringBuffer errorMessage = new StringBuffer();
            errorMessage.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(methodName).append('(');
            int parameterIndex = 0;
            while (parameterIndex < parameterCount) {
                errorMessage.append(parameterTypes[parameterIndex].getName());
                if (++parameterIndex >= parameterCount) continue;
                errorMessage.append(", ");
            }
            errorMessage.append(')');
            throw new RuntimeException(errorMessage.toString());
        }
        return (Method)entry;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == '\u00d8' || c2 == '\u00c4' || c2 == '\u00cc' || c2 == 'v') {
                field = Xray.resolveField(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == '\u00d8' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == '\u00c4' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == '\u00cc' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = Xray.resolveMethod(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == 'E' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == '\u00e6' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = Xray.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/g/ap" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Xray.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(Xray.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

