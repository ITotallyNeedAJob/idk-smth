// === Kuzi module: ChinaHat ===
// Category   : RENDER
// Description: Renders a configurable conical hat above players.
// Payload    : a.a.a.j.g.K (verified: False)

package kuzi.modules.render;

import java.awt.Color;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.b.e;
import kuzi.obf.j.f.f;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;

public class ChinaHat
extends BaseModule {
    public final BoolSetting self;
    public final BoolSetting others;
    public final BoolSetting outline;
    public final BoolSetting hideSwimming;
    public final BoolSetting hideGliding;
    public final e r;
    public final e s;
    public final SliderSetting radius;
    public final SliderSetting height;
    public final SliderSetting yOffset;
    public final SliderSetting sides;
    private static final long x = 94606837727109L;
    private static final Object[] E = new Object[]{"Qyt@0\nXyw@4", "\u0002\u001dm;:C\u001f\b5\u0019{N\u0007\u000e", "\u0002AlJp$\tAjJZ", "u\u001e\u001dMR%|\u001e\u001eMP", "T ;N\u0000v] 8N\f", "5\u0016QHh\u0006>\u0016Y", "S/d*luX/o", "\u007f-X\u001d\u0017F\n\rS\u0012\u0006\tk\u0003X\u0019\u0002S\u001f", Void.TYPE, "+F\u00173.l F\u00103)", "x\th\u0000ze\r)c\u000fk*l'h\u0004op\u0018", "<7>Qj^78/\u001e\u000bP<3+D", "S\u000e\u001c\u001b[\u0003\u000b\u0003\u001c\u0003 \u000bjY\u0012\u0011P\n\u0010\u0004S\u000fI", "@`r#\u0015\u0000\u0018mr;n\u0016yfy6Q\r@<y ", "Dv\u001aY|$\u001c{\u001aA\u00077} \u0014C>3\u0018%@[;", "R\n C,\u0006UP-\u001fC$#v\u00010\u0019~R\n C,\u0006UP-\u001f", "o/(\u0019\n=7\"(\u0001q-Vy&\u0003H*3|r\u001bM", "#\nQ\u0018#Xy\nG'*a6\\_D\"\u000b5\rD'", "\u0013,Z`_ K!Zx$2*zTz\u001d7O\u007f\u0000b\u0018", "?:3,\u0012ug734ia\u0006m=&\u0019||0|8\u0000", "nG%R\u001c96J%Jg.WA.GX4n\u001b.Q", "W/V,vi\u000f\"V4\rcnxX&}`\u0014%\u00198d", ">>\u0006\\Inf3\u0006D2{\u0007i\bVBg}4IH[", "Dqu\u0011kh\u001c|u\t\u0010y}'{\u000b)\u007f\u0018\"/\u0013,", "@s\u0003:\u0001x\u0018~\u0003\"zsy$\r0\nq\u0003yL.\u0013", "\u0012;V,3U\u0012aGy]^.a\u0007#!\u0007Qe\u0000r8:\u0013,C8!\u0001MaT3]", "W\u0013\u0010 F4\u0005\u001a\u0017{'3iOH}[g\u0016KO,BZT\u0002\ff[a\nO\u001bm'"};
    private static final String[] F = new String[]{null, null, null, null, null, null, null, null, "java/lang/Void", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null};

    public ChinaHat() {
        long l2;
        long l3 = l2 = x ^ 0x21D1CBD66FAFL;
        long l4 = l3 ^ 0x56399E5F4B3FL;
        long l5 = l3 ^ 0x2E8506D0DA2FL;
        super("China Hat", "Renders a configurable conical hat above players.", Category.RENDER);
        this.self = new BoolSetting("Self", true);
        this.others = new BoolSetting("Others", true);
        this.outline = new BoolSetting("Outline", true);
        this.hideSwimming = new BoolSetting("Hide Swimming", true);
        this.hideGliding = new BoolSetting("Hide Gliding", true);
        this.r = new e("Fill Color", new Color(255, 40, 80, 120));
        this.s = new e("Outline Color", new Color(255, 40, 80, 220));
        this.radius = new SliderSetting("Radius", 0.72, 0.35, 1.4, 0.01);
        this.height = new SliderSetting("Height", 0.32, 0.05, 1.0, 0.01);
        this.yOffset = new SliderSetting("Y Offset", 0.18, -0.5, 1.0, 0.01);
        this.sides = new SliderSetting("Sides", 56.0, 12.0, 96.0, 1.0);
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.self, this.others, this.outline, this.hideSwimming, this.hideGliding, this.r, this.s, this.radius, this.height, this.yOffset, this.sides};
        objectArray[0] = l4;
        this.l(objectArray);
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l5;
        kuzi.obf.j.f.f.a(objectArray2);
    }

    public Color a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = x ^ l2;
        return this.r.a();
    }

    public Color b(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = x ^ l2;
        return this.s.a();
    }

    private static Field declaredField(Class clazz, String name, Class fieldType) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(name) || field.getType() != fieldType) continue;
            return field;
        }
        return null;
    }

    private static Field fieldIncludingInterfaces(Class clazz, String name, Class fieldType) {
        Field field = ChinaHat.declaredField(clazz, name, fieldType);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = ChinaHat.fieldIncludingInterfaces(classArray[i2], name, fieldType);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method declaredMethod(Class clazz, String name, Class returnType, int parameterCount, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] parameterTypes;
            if (!method.getName().equals(name) || method.getReturnType() != returnType || (parameterTypes = method.getParameterTypes()).length != parameterCount) continue;
            for (int i2 = 0; i2 < parameterCount; ++i2) {
                if (parameterTypes[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method methodIncludingInterfaces(Class clazz, String name, Class returnType, int parameterCount, Class[] classArray) {
        Method method = ChinaHat.declaredMethod(clazz, name, returnType, parameterCount, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = ChinaHat.methodIncludingInterfaces(classArray2[i2], name, returnType, parameterCount, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }
}

