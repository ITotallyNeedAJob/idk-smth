// === Kuzi module: AutoReconnect ===
// Category   : SERVER
// Description: Automatically reconnects when disconnected from a server
// Payload    : a.a.a.j.e.C (verified: True)

package kuzi.modules.server;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import kuzi.mixin.MixinExposed;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.m.r;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.ServerAddress;
import net.minecraft.ServerData;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class AutoReconnect
extends BaseModule {
    private final SliderSetting delay;
    private final BoolSetting hideButtons;
    public ServerAddress o;
    public ServerData p;
    private static final long q = 39221161927249L;
    private static final Object[] u = new Object[]{"y?\u00196s\u000br?\u001d6Q", "oi\u0015j$Pfi\u0016j&", "\u0004-,%'\u0019\r-/%'", "\u001b\u0002\u0005\n%\u0005\u0010\r\u0014ED\u000b\u001b\u0006\u0010\u001f", "\u001f{?PLY\u0014{7", "4\u0013;z#J=\u00138z/", "f`\\:Ptm`W", "a\u0003 K\u001bn\u0014#+D\n!u- O\u000e{\u0001", Void.TYPE, "_A\r1Y\u0000_A\u001amU\u000fE\n\u001asU\u001aB{O,\r", "\f\f:\u001a%\u0012\u0000\f)", "{l\u0014u'\u001f{l\u0003)+\u0010a'\u00037+\u0005fVVox", "'\u001c\nE<K\"\u0011\u001a(*7tLJG<S&\u001e\u0007N", "qtYq!T0{MlKl\u0006PhF\u00117qtYq!T0{Ml", "/~d\u0001p *stlx\\zo(Ppf'+s\u0003", "|9\u001b(Wyy4\u000bEN\u0005)d\u0017+Hy}-\u0017;':&)\u0004*[no)\u0014E", "O,\"\u0013\u001c\u001a\u0006k<\u0017a\fvk#P_\t\u0004>kV\u0007e", "U=\u0004p\u007fvP0\u0014\u001dj\n\u00047D&piE!\u0010$", "\u0004\u0005n=\u0001\u007fJ\u0007(3jr8Cj\"\tqVEi'U\u0016\u0006Ni2\tdQ\u00011nj", ",{\b\u0002\u001d+)v\u0018o\nWxx\u001dS\u0004,8m\u0010\n"};
    private static final String[] v = new String[]{null, null, null, null, null, null, null, null, "java/lang/Void", null, null, null, null, null, null, null, null, null, null, null};

    public AutoReconnect() {
        long l2 = q ^ 0x6CAB2E17A39FL;
        long l3 = l2 ^ 0x6EE3C6069ADBL;
        super("AutoReconnect", "Automatically reconnects when disconnected from a server", Category.SERVER);
        this.delay = new SliderSetting("Delay", 3.5, 0.0, 60.0, 0.1);
        this.hideButtons = new BoolSetting("Hide Buttons", false);
        Setting[] settingArray = new Setting[]{this.delay, this.hideButtons};
        Object[] objectArray = new Object[2];
        objectArray[1] = settingArray;
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @MixinExposed
    public void a(ServerAddress serverAddress, ServerData serverData) {
        this.o = serverAddress;
        this.p = serverData;
    }

    @MixinExposed
    public double a() {
        return (Double)this.delay.a();
    }

    @MixinExposed
    public boolean a() {
        return (Boolean)this.hideButtons.a();
    }

    @MixinExposed
    public boolean f() {
        return this.o != null;
    }

    private static r a(r r2) {
        return r2;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = AutoReconnect.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = AutoReconnect.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = AutoReconnect.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = AutoReconnect.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }
}

