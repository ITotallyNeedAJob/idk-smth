// === Kuzi module: NameProtect ===
// Category   : SERVER
// Description: Replaces your name with given one.
// Payload    : a.a.a.j.e.V (verified: True)

package kuzi.modules.server;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;
import kuzi.core.Client;
import kuzi.mixin.MixinExposed;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.modules.client.Friends;
import kuzi.obf.j.e.am;
import kuzi.obf.m.r;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.StringSetting;

public class NameProtect
extends BaseModule {
    private final StringSetting fakeName;
    private final BoolSetting protectFriends;
    private static final long o = 31494065804472L;
    private static final Object[] s = new Object[]{"E)`T-yN)dT\u001a", "$B -D>-B#-V", "=VL+,v4VO+.", "y\n2M%\\r\n:", "?0j'~\u000e40a", "D~\f\u0018a\u00041^\u0007\u0017pKPP\f\u001ct\u0011$", Void.TYPE, "ZrzEW\u000fSryEW", "+h O\u001f\u0012 g1\u0000~\u001c+l5Z", "\u001dJ\u000039\u001d\u0016J\u000333", "Q\u0003\u007fF\u000f\u0005$#tI\u001eJE-\u007fB\u001a\u00101", "!\u000e\u0015-U[?\u0006\u000fb7G8\u001b", "4?1f&???5f&|", "|\fX_[@w\u0003I\u0010&Xd\u0004@Y", Boolean.TYPE, "`uD;\u0004\"luW", "\u0012J%'Q9gj.(@v\u0006d%#D,r", "=Y\u0010<$\u0019=@L}\u0014\u000e\u0003V\u001e?kRqZF/nbj\u0005\u000b(}\u000bm\fN/\u0014", "UJ/B>pUSs\u0003\u000eakE!Aq;\u0019IyQt\u000b[\u001e$\tk7\u0014C$N\u000e", "\u0014`c[B2Tc7X\"6$<2X\u0012=Fim\bE\\", "U&\u001bGV$Z'\\?W\u0014\u0005u_\u0000O$N\"\u001eC", "\u001a &v!\nE3*q\u0018!m\u0016HCBz\u001a &v!\nE3*q", "jI0a'VeHw\u0019*fj\u001f1|*\u000fm\u0016t{C", "\u0003\u0015_\u0006m\u0002\f\u0014\u0018~b2[\u001b\u001cNhP\u000eDL\u0019\t", "A&\u0006\u0017~\u0018E!\u001b\u0000\u000f\u001a|v\u001b\u0012j\u000b\u0019!\u0002\u00042s", "m\u0011,\u0016T*b\u0010knY\u001am\u00198VRzu\u0015)P0sc\u0017i\fPko\u0006on", "zoG\u0001u\u0018un\u0000yw(*oA\u0013`\u0016\u007fe\u000bG", "*/&o\u001f\u007fh=pg/'\u00105)vPsb9qfUC,n/`Q:nop?/"};
    private static final String[] t = new String[]{null, null, null, null, null, null, "java/lang/Void", null, null, null, null, null, null, null, "java/lang/Boolean", null, null, null, null, null, null, null, null, null, null, null, null, null};

    public NameProtect() {
        long l2 = o ^ 0x6AAB68359DD9L;
        long l3 = l2 ^ 0x57ECABD2D274L;
        super("NameProtect", "Replaces your name with given one.", Category.SERVER);
        this.fakeName = new StringSetting("Fake Name", "DrDonutt");
        this.protectFriends = new BoolSetting("Protect Friends", false);
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.fakeName, this.protectFriends};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        super.d();
    }

    @Override
    public void e() {
        super.e();
    }

    @MixinExposed
    public String c() {
        return (String)this.fakeName.a();
    }

    @MixinExposed
    public boolean a() {
        return (Boolean)this.protectFriends.a();
    }

    @MixinExposed
    public String a(String name) {
        block25: {
            int friendIndex;
            block27: {
                int foundIndex;
                String stringTable;
                block17: {
                    Friends friendsModule;
                    long l2;
                    block26: {
                        Friends friendsRef;
                        long l3;
                        block24: {
                            BaseModule module;
                            block23: {
                                boolean isProtected;
                                block22: {
                                    String candidate;
                                    block20: {
                                        block21: {
                                            String result;
                                            block18: {
                                                block19: {
                                                    long l4;
                                                    long l5 = l4 = o ^ 0x4CFEF5110A50L;
                                                    l3 = l5 ^ 0x2C65F7E6E769L;
                                                    l2 = l5 ^ 0x345C40BC761EL;
                                                    stringTable = am.b();
                                                    result = name;
                                                    if (stringTable == null) break block18;
                                                    if (result == null) break block19;
                                                    candidate = name.trim();
                                                    if (stringTable == null) break block20;
                                                    if (!candidate.isEmpty()) break block21;
                                                }
                                                result = name;
                                            }
                                            return result;
                                        }
                                        candidate = Client.e.getUser().getName();
                                    }
                                    String ownName = candidate;
                                    isProtected = name.equals(ownName);
                                    if (stringTable == null) break block22;
                                    if (isProtected) {
                                        return this.c();
                                    }
                                    module = this;
                                    if (stringTable == null) break block23;
                                    isProtected = ((NameProtect)module).a();
                                }
                                if (!isProtected) {
                                    return name;
                                }
                                module = Client.a.a(Friends.class);
                            }
                            friendsModule = friendsRef = (Friends)module;
                            if (stringTable == null) break block24;
                            if (friendsModule == null) break block25;
                            friendsModule = friendsRef;
                        }
                        if (stringTable == null) break block26;
                        Object[] objectArray = new Object[2];
                        objectArray[1] = name;
                        objectArray[0] = l3;
                        if (!friendsModule.d(objectArray)) break block25;
                        friendsModule = friendsRef;
                    }
                    Object[] objectArray = new Object[1];
                    objectArray[0] = l2;
                    List friendNames = friendsModule.b(objectArray);
                    if (friendNames == null) break block25;
                    foundIndex = -1;
                    for (int index = 0; index < friendNames.size(); ++index) {
                        friendIndex = ((String)friendNames.get(index)).trim().equalsIgnoreCase(name.trim()) ? 1 : 0;
                        if (stringTable != null) {
                            if (stringTable != null) {
                                if (friendIndex == 0) continue;
                                int n4 = foundIndex = index;
                            }
                            if (stringTable != null) break;
                            if (stringTable != null) continue;
                        }
                        break block17;
                    }
                    friendIndex = foundIndex;
                }
                if (stringTable == null) break block27;
                if (friendIndex < 0) break block25;
                friendIndex = foundIndex + 1;
            }
            return "Friend" + friendIndex;
        }
        return name;
    }

    private static r a(r value) {
        return value;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = NameProtect.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int index = 0; index < classArray.length; ++index) {
                field = NameProtect.d(classArray[index], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int parameterCount, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != parameterCount) continue;
            for (int index = 0; index < parameterCount; ++index) {
                if (classArray2[index] != classArray[index]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int parameterCount, Class[] classArray) {
        Method method = NameProtect.c(clazz, string, clazz2, parameterCount, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int index = 0; index < classArray2.length; ++index) {
                method = NameProtect.d(classArray2[index], string, clazz2, parameterCount, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }
}

