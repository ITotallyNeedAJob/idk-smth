// === Kuzi module: ChatUtils ===
// Category   : SERVER
// Description: Extends chat history and persists it across servers.
// Payload    : a.a.a.j.e.H (verified: False)

package kuzi.modules.server;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import kuzi.module.BaseModule;
import kuzi.module.Category;

public class ChatUtils
extends BaseModule {
    private static final Object[] q = new Object[]{"|,'4>~w,/", "TD8\u001e\\D_K)Q=JT@-\u000b", "jR\u000f!_q5F\u001dO=\f\u0000j=\u0015fq<K\u001evV.(Y"};

    public ChatUtils() {
        super("ChatUtils", "Extends chat history and persists it across servers.", Category.SERVER);
    }

    private static Field findDeclaredField(Class ownerClass, String fieldName, Class fieldType) {
        for (Field field : ownerClass.getDeclaredFields()) {
            if (!field.getName().equals(fieldName) || field.getType() != fieldType) continue;
            return field;
        }
        return null;
    }

    private static Field findField(Class ownerClass, String fieldName, Class fieldType) {
        Field field = ChatUtils.findDeclaredField(ownerClass, fieldName, fieldType);
        if (field != null) {
            return field;
        }
        Class<?>[] interfaces = ownerClass.getInterfaces();
        if (interfaces != null) {
            for (int index = 0; index < interfaces.length; ++index) {
                field = ChatUtils.findField(interfaces[index], fieldName, fieldType);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method findDeclaredMethod(Class ownerClass, String methodName, Class returnType, int parameterCount, Class[] expectedParameterTypes) {
        block0: for (Method method : ownerClass.getDeclaredMethods()) {
            Class<?>[] parameterTypes;
            if (!method.getName().equals(methodName) || method.getReturnType() != returnType || (parameterTypes = method.getParameterTypes()).length != parameterCount) continue;
            for (int index = 0; index < parameterCount; ++index) {
                if (parameterTypes[index] != expectedParameterTypes[index]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method findMethod(Class ownerClass, String methodName, Class returnType, int parameterCount, Class[] expectedParameterTypes) {
        Method method = ChatUtils.findDeclaredMethod(ownerClass, methodName, returnType, parameterCount, expectedParameterTypes);
        if (method != null) {
            return method;
        }
        Class<?>[] interfaces = ownerClass.getInterfaces();
        if (interfaces != null) {
            for (int index = 0; index < interfaces.length; ++index) {
                method = ChatUtils.findMethod(interfaces[index], methodName, returnType, parameterCount, expectedParameterTypes);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }
}

