// === Kuzi module: AutoTPA ===
// Category   : SERVER
// Description: Automatically sends TPA requests to a player
// Payload    : a.a.a.j.e.E (verified: True)

package kuzi.modules.server;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.b.l;
import kuzi.obf.j.e.am;
import kuzi.obf.j.e.g;
import kuzi.obf.m.r;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import kuzi.settings.StringSetting;
import net.minecraft.Minecraft;

public class AutoTPA
extends BaseModule {
    private final StringSetting playerName;
    private final l mode;
    private final SliderSetting minDelay;
    private final SliderSetting maxDelay;
    private int delayTicks;
    private static final long r = 22817271316278L;
    private static final Object[] v = new Object[]{"\u0012c\u001b)qQ\u0019c\u001f)U", Integer.TYPE, "RW\u007fnt\f[W|nf", "\bb\u0012KwC\u0003b\u0016Kw\u0000", "\u001f\n5,\u0019\u0006\u0014\u0005$cd\u001e\u0007\u0002-*", "<fnGw~7fe", ")N\u0005\u001fZ\n)N\u0012CV\u00053\u0005\u0012]V\u00104tB\u0000\u0007", ">a\t\u0001Y>7a\n\u0001T", "\u000f-m=1\\\u0004-i=7", "n*E\u0016j\u0012g*F\u0016f", "3Eb~\u0011T?Eq", "?Ce=x\u000f6Cf=x", "\u0006\u00039\u0010>\u0006\r\f(__\b\u0006\u0007,\u0005", "djQ6^b\u0011JZ9O-pDQ2Kw\u0004", Boolean.TYPE, "{ kY\u000fIp c", "6QBD-TCqIK<\u001b\"\u007fB@8AV", Void.TYPE, "&i;tCT'j>\n]%\u007fij;S[\u007fbnk", ":_F\"->aOC!F>\u0000\b\u001cn8=f\u000b@$:T", "/h\u001d{zMmuRf\u0006H\u00145@g?Yq6\u0017z;", ":?KV\u001a6;<N(\u0007Ggo_\u0011Y *8^\u0019", "t\u0016PhLN2\u0014Gr.*\u0011/ /^\u00063\u0004\u0018i\\\u0011)", "L4Y9?IM7\\G#8\u00126M6+_Bk\\6", "D3\"x^0E0'\u0006LA\u001bm/{Jx[g*w%~\u0014<3i\u001c>\u001e9?\u0006", "%MG8i\u0001.QA>\u00154\u0001k%JOo%MG8i\u0001.QA>", "lAx0W\bmB}NUy5\u0016-!V\u0004f\u0012+p", "N;aIExG|cIuk~62\u0004\tp\u0007e!\u0012\u0016\u0002", ",\u0013`u\u0003lj\u0011woa\bI*PB;\u0019\u0011^`\u007f\u001b6)\u0018bh\u0001", "#l7\u000e+uaqx\u0013W}\u0018ga\n,{r7l\u0011:\u0019sf`\u0006n$\"k\u007f\u001dW", "\u0016Sf-8G[\u0004g%\u0000J+\u0007xs{BAWuhm B\u0001!zc\u0019N\u0013z\u007f\u0000", "Bqet\u0018{Cr`\n\u001b\n\u001csq{\fmL.`{"};
    private static final String[] w = new String[]{null, "java/lang/Integer", null, null, null, null, null, null, null, null, null, null, null, null, "java/lang/Boolean", null, null, "java/lang/Void", null, null, null, null, null, null, null, null, null, null, null, null, null, null};

    public AutoTPA() {
        long l2 = r ^ 0x202D20AE449CL;
        long l3 = l2 ^ 0x150EA48A20BFL;
        super("AutoTPA", "Automatically sends TPA requests to a player", Category.SERVER);
        this.playerName = new StringSetting("Player", "DrDonutt");
        this.mode = new l("Mode", kuzi.obf.j.e.g.TPAHERE, g.class);
        this.minDelay = new SliderSetting("Min Delay", 10.0, 1.0, 100.0, 1.0);
        this.maxDelay = new SliderSetting("Max Delay", 30.0, 1.0, 100.0, 1.0);
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.playerName, this.mode, this.minDelay, this.maxDelay};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        super.d();
        this.delayTicks = 0;
    }

    @Override
    public void e() {
        super.e();
        this.delayTicks = 0;
    }

    @Override
    public void i() {
        block16: {
            int maxTicks;
            int minTicks;
            block15: {
                String string;
                block14: {
                    String command;
                    block13: {
                        Object object;
                        block11: {
                            block12: {
                                int n4;
                                block10: {
                                    long l2;
                                    block9: {
                                        block8: {
                                            Minecraft mc;
                                            block7: {
                                                long l3 = r ^ 0x675667BB9FD7L;
                                                l2 = l3 ^ 0xBE0BB21744BL;
                                                string = am.b();
                                                mc = BaseModule.a;
                                                if (string == null) break block7;
                                                if (mc.player == null) break block8;
                                                mc = BaseModule.a;
                                            }
                                            if (mc.getConnection() != null) break block9;
                                        }
                                        return;
                                    }
                                    n4 = this.delayTicks--;
                                    if (string == null) break block10;
                                    if (n4 > 0) {
                                        return;
                                    }
                                    object = this.mode;
                                    if (string == null) break block11;
                                    Object[] objectArray = new Object[2];
                                    objectArray[1] = l2;
                                    objectArray[0] = kuzi.obf.j.e.g.TPA;
                                    n4 = ((l)object).b(objectArray) ? 1 : 0;
                                }
                                if (n4 == 0) break block12;
                                command = "tpa " + (String)this.playerName.a();
                                if (string != null) break block13;
                            }
                            object = this.playerName.a();
                        }
                        command = "tpahere " + (String)object;
                    }
                    BaseModule.a.getConnection().sendCommand(command);
                    minTicks = ((Double)this.minDelay.a()).intValue();
                    maxTicks = ((Double)this.maxDelay.a()).intValue();
                    if (string == null) break block14;
                    if (minTicks <= maxTicks) break block15;
                    this.delayTicks = minTicks;
                }
                if (string != null) break block16;
            }
            this.delayTicks = minTicks + (int)(Math.random() * (double)(maxTicks - minTicks + 1));
        }
    }

    private static r a(r r2) {
        return r2;
    }

    private static Field declaredField(Class clazz, String name, Class fieldType) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(name) || field.getType() != fieldType) continue;
            return field;
        }
        return null;
    }

    private static Field fieldIncludingInterfaces(Class clazz, String name, Class fieldType) {
        Field field = AutoTPA.declaredField(clazz, name, fieldType);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = AutoTPA.fieldIncludingInterfaces(classArray[i2], name, fieldType);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method declaredMethod(Class clazz, String name, Class returnType, int parameterCount, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] parameterTypes;
            if (!method.getName().equals(name) || method.getReturnType() != returnType || (parameterTypes = method.getParameterTypes()).length != parameterCount) continue;
            for (int i2 = 0; i2 < parameterCount; ++i2) {
                if (parameterTypes[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method methodIncludingInterfaces(Class clazz, String name, Class returnType, int parameterCount, Class[] classArray) {
        Method method = AutoTPA.declaredMethod(clazz, name, returnType, parameterCount, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = AutoTPA.methodIncludingInterfaces(classArray2[i2], name, returnType, parameterCount, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }
}

