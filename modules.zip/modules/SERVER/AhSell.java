// === Kuzi module: AhSell ===
// Category   : SERVER
// Description: Automatically sells items from your hotbar.
// Payload    : a.a.a.j.d.i (verified: True)

package kuzi.modules.server;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.j.d.b;
import kuzi.obf.j.d.c;
import kuzi.obf.p.x_0;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import kuzi.settings.StringSetting;
import net.minecraft.Player;
import net.minecraft.ClickType;
import net.minecraft.ContainerScreen;

public class AhSell
extends BaseModule {
    private final StringSetting sellPrice;
    private final SliderSetting delayTicks;
    private int delayCounter;
    private c state;
    private int stateTimer;
    private static final long s = 12775816489442L;
    private static final Object[] z = new Object[]{"^bT>\u0017_ObM", "/M-\\z0Zm&Sk\u007f;c-Xo%O", Void.TYPE, ":'2\u0010\u001fM1'7\u0010\u001c", Integer.TYPE, "@i\u0012~%yKi\u0017~-", "Kq6cSy@q3cQ", "0\u0001\u0015\\\u001ea;\u0001\u001e", "cwsD\u001dGcwd\u0018\u0011Hy<d\u0006\u0011]~M4[@", "0\u000fgHQUE/lG@\u001a$!gLD@P", "\u000e-\u0001$_\u0002\u0007-\u0002$M", "e\u001d*+t/\u0010=!$e`q3*/a:\u0005", "]\u0011MJ\u001a.V\u001e\\\u0005z7Z\u0012^Yr-E\u001dZ_q:T\u0015K_]-Y", "F\u0013T\"A\u0001O\u0013W\"A", "u\u0013Kb]\u0015~\u001cZ-<\u001bu\u0017^w", "\\+D`?bU+G`3", "K\\\u001bw\fN@\\\u0013", "u?>r\u007fK\u0000\u001f5}n\u0004a\u0011>vj^\u0015", "{j\u0011dc\u001b#9\f\u0015e$tk\b.tHrc\no\f\u001dcaT,e\u001a'gW\u0015", "\u000fJE\u000fGWM\u0007\r\u0019#]5M\r\t\u001a\bQI\u0003W\u00197", "Qu{_s`Tj E\u0010 j,t^zb\u0003u#Lb", "\u001fI\u0014(\u0007\u0013M@\r8m\u001d\"\u0019\r'\u001f\u0014K\u0019\u00060\u0017", "\n&7\b=SX/.\u0018WV7r7\u001eo\r^us\u0018l4", "`tbT\u0015&ek9Nvv[znSMg7|fQ\f\u001fbmd\u000fOve)b\fv", "\u0019N,wD>\u001cQwm'a\"\u0014${\u0018hRU*~[", "U>k\u0016z\u0000\fiy\u000eA6 \u0011U=\u0007&>\u001eN&\u0016&4\u0011\t@/\u000b\u0003k`\u0019x\u0019\u001b", "5X\u001b\fY00G@\u0016:n\u000eT\u001e\u0003\u0005tn\rKU\u0005", "$DT\u0015}*|\u0017Idy\u0015+EM_jy-MO\u001e\u0012,<O\u0011]{+xI\u0012d", "6>V\u000b$.oiD\u0013\u001f\u0006F\u0014ya#)h:\u000f\bz~z\"", "\u0018\u001bgFM^M\r6\u0000)c?&\u0006us8\u0018\u001bgFM^M\r6\u0000", "uS\u0002_I\r,\u0004\u0010Gr/\r|+v3\"\u0006j+r4*\bg%5N\n+W[\\\u0017]9O", "K\r\u0015K0\u0016N\u0012NQSFpX\u0013P!\u001e\u001e\u0013\b\u0010l/@\u000f\fZbA\u000b\u0014L\u0017S", "\t7)\u000e%\u0003]`v\u001fD\f88h]5_W8e\r\u007fe", "'M\u0001$UY\"RZ>6\u0018\u001c\u0013P&\u000f_x\u0017^x\f", "-\u001e%6t-(\u0001~,\u0017n\u0016@t4.+rDzj-", "Gl\u0000\f\u0007A\u0015e\u0019\u001cmBzj\u0011\u0019V^\u0016l\u0019\u001b\u0017&C}\u001bETOD9\u001dFm"};
    private static final String[] A = new String[]{null, null, "java/lang/Void", null, "java/lang/Integer", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null};

    public AhSell() {
        long l2 = s ^ 0x6C86FDBA9852L;
        long l3 = l2 ^ 0x46FB6CC7EAA5L;
        super("AhSell", "Automatically sells items from your hotbar.", Category.SERVER);
        this.sellPrice = new StringSetting("Sell Price", "15000");
        this.delayTicks = new SliderSetting("Delay (ticks)", 20.0, 5.0, 100.0, 1.0);
        this.delayCounter = 0;
        this.state = kuzi.obf.j.d.c.IDLE;
        this.stateTimer = 0;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.sellPrice, this.delayTicks};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public void i() {
        block39: {
            block23: {
                block34: {
                    block35: {
                        block38: {
                            block37: {
                                block36: {
                                    block28: {
                                        block29: {
                                            block32: {
                                                block33: {
                                                    block30: {
                                                        block31: {
                                                            block27: {
                                                                block25: {
                                                                    block26: {
                                                                        block24: {
                                                                            v0 = var1_1 = AhSell.s ^ 131977682520323L;
                                                                            var3_2 = v0 ^ 138689762139966L;
                                                                            var5_3 = v0 ^ 7599806745342L;
                                                                            var7_4 = v0 ^ 124018600988119L;
                                                                            var9_5 = kuzi.obf.j.d.b.b();
                                                                            v1 = BaseModule.a;
                                                                            if (var9_5 == 0) break block24;
                                                                            if (v1.player == null) break block25;
                                                                            v1 = BaseModule.a;
                                                                        }
                                                                        if (var9_5 == 0) break block26;
                                                                        if (v1.level == null) break block25;
                                                                        v1 = BaseModule.a;
                                                                    }
                                                                    if (v1.gameMode != null) break block27;
                                                                }
                                                                return;
                                                            }
                                                            v2 = this;
                                                            if (var9_5 != 0) {
                                                                if (v2.delayCounter > 0) {
                                                                    --this.delayCounter;
                                                                    return;
                                                                }
                                                                v2 = this;
                                                            }
                                                            v3 = v2.state;
                                                            v4 = kuzi.obf.j.d.c.WAITING_FOR_GUI;
                                                            if (var9_5 == 0) break block28;
                                                            if (v3 != v4) break block29;
                                                            --this.stateTimer;
                                                            v5 = BaseModule.a.screen instanceof ContainerScreen;
                                                            if (var9_5 == 0) break block30;
                                                            if (v5 == 0) break block31;
                                                            this.state = kuzi.obf.j.d.c.CLICKING_CONFIRM;
                                                            this.stateTimer = 2;
                                                            if (var9_5 != 0) break block32;
                                                        }
                                                        v6 = this;
                                                        if (var9_5 == 0) break block33;
                                                        v5 = v6.stateTimer;
                                                    }
                                                    if (v5 > 0) break block32;
                                                    v6 = this;
                                                }
                                                v7 = new Object[1];
                                                v7[0] = var3_2;
                                                v6.a(v7);
                                            }
                                            return;
                                        }
                                        v3 = this.state;
                                        v4 = kuzi.obf.j.d.c.CLICKING_CONFIRM;
                                    }
                                    if (var9_5 == 0) break block34;
                                    if (v3 != v4) break block35;
                                    v8 = --this.stateTimer;
                                    if (var9_5 == 0) break block36;
                                    if (v8 > 0) {
                                        return;
                                    }
                                    v9 = BaseModule.a;
                                    if (var9_5 == 0) break block37;
                                    v8 = v9.screen instanceof ContainerScreen;
                                }
                                if (v8 == 0) break block38;
                                BaseModule.a.gameMode.handleInventoryMouseClick(BaseModule.a.player.containerMenu.containerId, 15, 0, ClickType.PICKUP, (Player)BaseModule.a.player);
                                v9 = BaseModule.a;
                            }
                            v9.player.closeContainer();
                        }
                        v10 = new Object[1];
                        v10[0] = var3_2;
                        this.a(v10);
                        return;
                    }
                    v3 = this.state;
                    v4 = kuzi.obf.j.d.c.IDLE;
                }
                if (v3 != v4) break block39;
                slotIndex = -1;
                hotbarSlot = 0;
                while (hotbarSlot < 9) {
                    stack = BaseModule.a.player.getInventory().getItem(hotbarSlot);
                    if (var9_5 != 0) {
                        v11 = (int)stack.isEmpty();
                        if (var9_5 == 0) break block23;
                        if (v11 == 0) {
                            slotIndex = hotbarSlot;
                            if (var9_5 != 0) break;
                        }
                        ++hotbarSlot;
                    }
                    if (var9_5 != 0) continue;
                }
                v11 = slotIndex;
            }
            if (var9_5 == 0) ** GOTO lbl100
            if (v11 != -1) {
                try {
                    BaseModule.a.player.getInventory().setSelectedSlot(slotIndex);
                    v11 = Integer.parseInt((String)this.sellPrice.a());
lbl100:
                    // 2 sources

                    BaseModule.a.player.connection.sendCommand("ah sell " + (String)this.sellPrice.a());
                    this.state = kuzi.obf.j.d.c.WAITING_FOR_GUI;
                    this.stateTimer = 10;
                }
                catch (NumberFormatException var11_8) {
                    v12 = new Object[2];
                    v12[1] = var7_4;
                    v12[0] = "Invalid sell price. Disabling.";
                    x_0.c(v12);
                    this.j();
                }
            } else {
                v13 = new Object[2];
                v13[1] = "Hotbar is empty. Disabling.";
                v13[0] = var5_3;
                x_0.a(v13);
                this.j();
            }
        }
    }

    private void a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = s ^ l2;
        this.state = kuzi.obf.j.d.c.IDLE;
        this.delayCounter = ((Double)this.delayTicks.a()).intValue();
    }

    @Override
    public void d() {
        long l2 = s ^ 0x601326764E2FL;
        long l3 = l2 ^ 0x66386E955812L;
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.a(objectArray);
    }

    @Override
    public void e() {
        long l2 = s ^ 0x756F3F972E01L;
        long l3 = l2 ^ 0x73447774383CL;
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.a(objectArray);
    }

    private static NumberFormatException a(NumberFormatException numberFormatException) {
        return numberFormatException;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = AhSell.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = AhSell.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = AhSell.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = AhSell.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }
}

