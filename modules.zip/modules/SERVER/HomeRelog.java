// === Kuzi module: HomeRelog ===
// Category   : SERVER
// Description: Runs /sethome -> /rtp -> /home; on a key or when you drop below a Y.
// Payload    : a.a.a.j.d.q (verified: True)

package kuzi.modules.server;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.module.Module;
import kuzi.obf.h.b.v;
import kuzi.obf.j.d.e;
import kuzi.obf.m.r;
import kuzi.settings.BoolSetting;
import kuzi.settings.KeyBinding;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;

public final class HomeRelog
extends BaseModule
implements Module {
    private final SliderSetting home;
    private final KeyBinding triggerKey;
    private final BoolSetting autoBelowY;
    private final SliderSetting triggerY;
    private final SliderSetting rTPWaitS;
    private e state;
    private int s;
    private boolean t;
    private int u;
    private static final long v;
    private static final String[] w;
    private static final String[] x;
    private static final Map y;
    private static final long[] z;
    private static final Integer[] A;
    private static final Map B;
    private static final Object[] C;
    private static final String[] D;

    public HomeRelog() {
        long l2 = v ^ 0x286E08BFE5E6L;
        long l3 = l2 ^ 0x295A1ADAD051L;
        super("HomeRelog", "Runs /sethome -> /rtp -> /home; on a key or when you drop below a Y.", Category.SERVER);
        this.home = new SliderSetting("Home", 1.0, 1.0, 10.0, 1.0);
        this.triggerKey = new KeyBinding("Trigger Key", -1);
        this.autoBelowY = new BoolSetting("Auto Below Y", false);
        this.triggerY = new SliderSetting("Trigger Y", -5.0, -64.0, 320.0, 1.0);
        this.rTPWaitS = new SliderSetting("RTP Wait (s)", 4.0, 0.5, 15.0, 0.5);
        this.state = kuzi.obf.j.d.e.IDLE;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.home, this.triggerKey, this.autoBelowY, this.triggerY, this.rTPWaitS};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        this.state = kuzi.obf.j.d.e.IDLE;
        this.s = 0;
        this.t = false;
        this.u = 0;
        Client.a().a(Module.class, this);
    }

    @Override
    public void e() {
        Client.a().b(Module.class, this);
        this.state = kuzi.obf.j.d.e.IDLE;
    }

    /*
     * Exception decompiling
     */
    @Override
    public void b() {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Statement already marked as first in another block
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.markFirstStatementInBlock(Op03SimpleStatement.java:461)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc.markWholeBlock(Misc.java:251)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.considerAsSimpleIf(ConditionalRewriter.java:673)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.identifyNonjumpingConditionals(ConditionalRewriter.java:56)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:722)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private void a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = (l2 = v ^ l2) ^ 0x670584114831L;
        Object[] objectArray2 = new Object[2];
        objectArray2[1] = l3;
        objectArray2[0] = (String)((Object)HomeRelog.b("g", (int)8343, (long)(0x4D9AA4CF00DDA83EL ^ l2))) + ((Double)((Object)HomeRelog.d("\u00e3", (Object)HomeRelog.d("P", (Object)this, (long)-1752401814643610242L, (long)l2), (long)-1752358281997505085L, (long)l2))).intValue();
        HomeRelog.d("\u00e3", (Object)this, (Object)objectArray2, (long)-1755597882670484082L, (long)l2);
        HomeRelog.d("Q", (Object)this, (e)((Object)HomeRelog.d("\u00ce", (long)-1755930207235524077L, (long)l2)), (long)-1751979895742098696L, (long)l2);
        HomeRelog.d("Q", (Object)this, (int)HomeRelog.c("p", (int)16501, (long)(0x3367122E3DEA0068L ^ l2)), (long)-1756200943609911213L, (long)l2);
        HomeRelog.d("Q", (Object)this, (int)HomeRelog.c("p", (int)13417, (long)(0x17045EF55AF6F475L ^ l2)), (long)-1755728462151675658L, (long)l2);
    }

    private void b(Object[] objectArray) {
        String command = (String)objectArray[0];
        long l2 = (Long)objectArray[1];
        l2 = v ^ l2;
        BaseModule.a.getConnection().sendCommand(command);
    }

    /*
     * Unable to fully structure code
     */
    static {
        block16: {
            block15: {
                block14: {
                    block13: {
                        HomeRelog.v = kuzi.obf.h.b.v.a(-1784823770106719631L, -4508884292778704054L, MethodHandles.lookup().lookupClass()).a(248143568103860L);
                        HomeRelog.C = new Object[41];
                        HomeRelog.D = new String[41];
                        HomeRelog.c();
                        HomeRelog.y = new HashMap<K, V>(13);
                        var11 = HomeRelog.v ^ 133140073250115L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[10];
                        var18_4 = 0;
                        var17_5 = "\u00ba\u00f3T\u00bc\u00d8D\u00df\u00f9\u00c5\u00a4\u00c9\u00a8\u00fd\u00cb6\u00ae\u00e8\u001ctO\u00c4\b\u001e\u00b6L\u00b4\u00cd\u00c1Cn\u00a0\u00c3\u00bf\u00b1 \u0086\u0096~\u0010\u00c0/>\u00b9\u00fe \u00f6Ti\u0094;\u00aaz\u0092\u00f9z\u00f4P\u0096\u00f88\u00dc\u001b\u000eq\u00ce\r\u00a5\u0007\u00abr\u00c2V\\\u00f1\"&\u00f4\u0001\u0002\u008en\u00b6\u00df\\\u009c\u00ad\u0017j`2[\u0013\u009b\"\r\u00a6w\u00fd\u00832\u00d4\u00f0\u00de\u00fa\u00be\u0080\u009e \u0098x\u00be\u009d \b\u00d5\u008fcC/r5\u000b*\u00ae\u0016\u009df2VW\u00f6\u0098\u00a4\u00e4\u000e}\u0091\u0092U\u00d3(7\u001f\u00e1N \u00145\u00d2o=#\u00862\u00e4H\u0090\u00f6\u00a8,C\u00a7b\u00c3\u0001S\u00a47L\u008c\u00c7=\r\u0017\u0006gr\u0019\u0010_\u000fY}F\u00fd=k\u0082g\u00e7c\u00c0d\u00e3\u00e7 \u009b`$\u00f1\u00a6\u00a3\u00d5+\u0096\u0088\u0012*\u00dc\u008e\u00fdh\u00db\u0099~*\\Jw\u00f6\u00edK\u00e9T\u00db}\u00f3\u00c4\u0018\u00a7K\u0092Oq\u00fc\u00d5 \u00a4>'\u00b31\u0080\u008b\u00c9\u00d9\u00d4@\u00e6\u000e\u00bc\u0005\u00b7\u0010\u0098\u001fe\u00dd\u0081\u0007Y\u0093\u0001$\u00d1\u00bf\u00ac4\u00c2\u00a0 \u00a4\u00f3\u0007\u0012T\u00b8d\u00cc_\u008b\u0094\u000eW$[\u000e\u00cd8\u007f\u0092<\u00a3LT\u0087\u00b1\u00b7\u0013\u0006\u0018\u00d2\u0092";
                        var19_6 = "\u00ba\u00f3T\u00bc\u00d8D\u00df\u00f9\u00c5\u00a4\u00c9\u00a8\u00fd\u00cb6\u00ae\u00e8\u001ctO\u00c4\b\u001e\u00b6L\u00b4\u00cd\u00c1Cn\u00a0\u00c3\u00bf\u00b1 \u0086\u0096~\u0010\u00c0/>\u00b9\u00fe \u00f6Ti\u0094;\u00aaz\u0092\u00f9z\u00f4P\u0096\u00f88\u00dc\u001b\u000eq\u00ce\r\u00a5\u0007\u00abr\u00c2V\\\u00f1\"&\u00f4\u0001\u0002\u008en\u00b6\u00df\\\u009c\u00ad\u0017j`2[\u0013\u009b\"\r\u00a6w\u00fd\u00832\u00d4\u00f0\u00de\u00fa\u00be\u0080\u009e \u0098x\u00be\u009d \b\u00d5\u008fcC/r5\u000b*\u00ae\u0016\u009df2VW\u00f6\u0098\u00a4\u00e4\u000e}\u0091\u0092U\u00d3(7\u001f\u00e1N \u00145\u00d2o=#\u00862\u00e4H\u0090\u00f6\u00a8,C\u00a7b\u00c3\u0001S\u00a47L\u008c\u00c7=\r\u0017\u0006gr\u0019\u0010_\u000fY}F\u00fd=k\u0082g\u00e7c\u00c0d\u00e3\u00e7 \u009b`$\u00f1\u00a6\u00a3\u00d5+\u0096\u0088\u0012*\u00dc\u008e\u00fdh\u00db\u0099~*\\Jw\u00f6\u00edK\u00e9T\u00db}\u00f3\u00c4\u0018\u00a7K\u0092Oq\u00fc\u00d5 \u00a4>'\u00b31\u0080\u008b\u00c9\u00d9\u00d4@\u00e6\u000e\u00bc\u0005\u00b7\u0010\u0098\u001fe\u00dd\u0081\u0007Y\u0093\u0001$\u00d1\u00bf\u00ac4\u00c2\u00a0 \u00a4\u00f3\u0007\u0012T\u00b8d\u00cc_\u008b\u0094\u000eW$[\u000e\u00cd8\u007f\u0092<\u00a3LT\u0087\u00b1\u00b7\u0013\u0006\u0018\u00d2\u0092".length();
                        var16_7 = 112;
                        var15_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block13;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = HomeRelog.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "\u0083\u0088\u00c2\u00beW\u00cd\u0015}`\u00d3\u00f0\u00b7lDmO:'\u008e\u00aa\u0004\u0002\u001c\u00fb\u0010\u008b\u00b7\u00f1;\u0087%\u00d4\u00de\u00e3\u0092^\u00fe\u00c1g\u00f4\u007f";
                            var19_6 = "\u0083\u0088\u00c2\u00beW\u00cd\u0015}`\u00d3\u00f0\u00b7lDmO:'\u008e\u00aa\u0004\u0002\u001c\u00fb\u0010\u008b\u00b7\u00f1;\u0087%\u00d4\u00de\u00e3\u0092^\u00fe\u00c1g\u00f4\u007f".length();
                            var16_7 = 24;
                            var15_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block13;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = HomeRelog.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block14;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                HomeRelog.w = var20_3;
                HomeRelog.x = new String[10];
                HomeRelog.B = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[3];
                var3_13 = 0;
                var4_14 = "l\u0088w}\u00b8W~\u00a1\u001e\u00c2\u00c3\u00c7\u008fu\u0005\u00dc>\u00ed\u000f\u00c8L\u00ac\u00ff@";
                var5_15 = "l\u0088w}\u00b8W~\u00a1\u001e\u00c2\u00c3\u00c7\u008fu\u0005\u00dc>\u00ed\u000f\u00c8L\u00ac\u00ff@".length();
                var2_16 = 0;
                while (true) {
                    break block15;
                    break;
                }
lbl76:
                // 1 sources

                while (true) {
                    var6_12[v10] = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
                    if (var2_16 < var5_15) ** continue;
                    break block16;
                    break;
                }
            }
            var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
            v10 = var3_13++;
            var8_18 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            ** while (true)
        }
        HomeRelog.z = var6_12;
        HomeRelog.A = new Integer[3];
    }

    private static r a(r r2) {
        return r2;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static String b(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x6F06;
        if (x[n3] == null) {
            Object[] objectArray;
            try {
                Long l3 = Thread.currentThread().threadId();
                objectArray = (Object[])y.get(l3);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    y.put(l3, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/d/q", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l2 >>> 56);
            for (int i2 = 1; i2 < 8; ++i2) {
                byArray[i2] = (byte)(l2 << i2 * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = w[n3].getBytes("ISO-8859-1");
            HomeRelog.x[n3] = HomeRelog.b(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return x[n3];
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        String string2 = HomeRelog.b(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static CallSite b(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/d/q" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x27BB;
        if (A[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = z[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])B.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    B.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/d/q", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            HomeRelog.A[n3] = n4;
        }
        return A[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = HomeRelog.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/d/q" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (D[n4] != null) {
            return n4;
        }
        Object object = C[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 25;
            case 1 -> 17;
            case 2 -> 31;
            case 3 -> 2;
            case 4 -> 4;
            case 5 -> 58;
            case 6 -> 1;
            case 7 -> 48;
            case 8 -> 15;
            case 9 -> 30;
            case 10 -> 39;
            case 11 -> 24;
            case 12 -> 0;
            case 13 -> 16;
            case 14 -> 51;
            case 15 -> 26;
            case 16 -> 23;
            case 17 -> 46;
            case 18 -> 13;
            case 19 -> 53;
            case 20 -> 27;
            case 21 -> 52;
            case 22 -> 63;
            case 23 -> 37;
            case 24 -> 28;
            case 25 -> 32;
            case 26 -> 9;
            case 27 -> 33;
            case 28 -> 14;
            case 29 -> 36;
            case 30 -> 6;
            case 31 -> 20;
            case 32 -> 18;
            case 33 -> 34;
            case 34 -> 50;
            case 35 -> 38;
            case 36 -> 40;
            case 37 -> 29;
            case 38 -> 12;
            case 39 -> 47;
            case 40 -> 54;
            case 41 -> 55;
            case 42 -> 44;
            case 43 -> 41;
            case 44 -> 8;
            case 45 -> 22;
            case 46 -> 45;
            case 47 -> 35;
            case 48 -> 59;
            case 49 -> 21;
            case 50 -> 57;
            case 51 -> 43;
            case 52 -> 7;
            case 53 -> 60;
            case 54 -> 19;
            case 55 -> 49;
            case 56 -> 61;
            case 57 -> 42;
            case 58 -> 11;
            case 59 -> 62;
            case 60 -> 3;
            case 61 -> 10;
            case 62 -> 56;
            default -> 5;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        HomeRelog.D[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = C;
        C[0] = "jPx^\bKaP}^\u0018";
        objectArray[1] = Integer.TYPE;
        HomeRelog.D[1] = "java/lang/Integer";
        objectArray[2] = "13r\u0003n\u0015D\u0013y\f\u007fZ%\u001dr\u0007{\u0000Q";
        objectArray[3] = Void.TYPE;
        HomeRelog.D[3] = "java/lang/Void";
        objectArray[4] = "\u0010-k\u001bE@\u001b-n\u001bA";
        objectArray[5] = "Dmg\u000b+\u0016Mmd\u000b'";
        objectArray[6] = "UX7\u0013\u0002I\\X4\u0013\u0002";
        objectArray[7] = "/7\tu:\u001e$8\u0018:[\u0010/3\u001c`";
        objectArray[8] = "\u000e>?S<\u001a\u0005>4";
        objectArray[9] = "\u0006\u0018\u0013\u0005Px\u0006\u0018\u0004Y\\w\u001cS\u0004G\\b\u001b\"T\u001a\r";
        objectArray[10] = "V\u0006\u001azHo_\u0006\u0019zJ";
        objectArray[11] = "Y5\u001f PTH52";
        objectArray[12] = "@\u001a[0\u0014F5:P?\u0005\tT4[4\u0001S ";
        objectArray[13] = Boolean.TYPE;
        HomeRelog.D[13] = "java/lang/Boolean";
        objectArray[14] = "P\u0000$,SL% /#B\u0003D.$(FY0";
        objectArray[15] = "86<c<a46/";
        objectArray[16] = "Nc:4e>Ec?4f";
        objectArray[17] = "0l;d-q9l8d&";
        objectArray[18] = "h\u0004WcRXc\u0004_";
        objectArray[19] = "8DT\u0018\u0011iMd_\u0017\u0000&,jT\u001c\u0004|X";
        objectArray[20] = "T@c\u001c\u007f\u0013\t\u001b\"a|+\u000e\u001cbZj[IFb^";
        objectArray[21] = "r+*h\u0004{/pk\u0015\u001dCf\u007fywZ~&0.";
        objectArray[22] = "4Ec'lyhEs.\u0001z\u000bOy1yxp\u0018dw8\u0013:F!,>hmD}*\u0001";
        objectArray[23] = "\u007fD%6\u0005^\"\u001fdK\u000bfvAd3\n\u001d!\\\"ra\\*[r1\u0000\u001b$\u001f|K";
        objectArray[24] = "h\u001dvlBg:H(er|UG42\nz,\u001fv,\u0010";
        objectArray[25] = "\u000eHkCN\u0019S\u0013*>C!\u0007M*FAZPPl\u0007*\u001b[W<DK\\U\u00132>";
        objectArray[26] = "\u001f\u001c`;\u0006E\u001eYp1;mk:R\rl\u007fh:_\u0010~i%\\e(W\u0019D] 8]";
        objectArray[27] = "n#-n3;3xl\u0013+\u0003:\".uhxm rs";
        objectArray[28] = "s\u0003-IO_.Xl4Bg\u007f\u001f(\u000e\u001bX+\u001cs_+\u000enX-\u0004\u0014Zm\u0003|4";
        objectArray[29] = "I#7EYo\u0014xv8DW\u0010{vJG+Q'}_";
        objectArray[30] = "(\u0017!\f\u0004\ruL`q\u001b5<Cr\u0013Z\b|\f%";
        objectArray[31] = "KhQ\u0006C(J-A\f~\b=VcjD3\u000e~\u0013\u000bEv\u001et";
        objectArray[32] = "X\u0002\u0016>j \b\\\u0017<\u001a(2\u0014\u001bmxy\u000fTT:\u001a";
        objectArray[33] = "\u0011Z{o&XL\u0001:\u0012:`H\u0002:`8\u001c\t^1u";
        objectArray[34] = "\u001e\u001fF\bR\u0003CD\u0007uL;A\u0001\u0003\u0019\u000bZ@D\u0013\u0013";
        objectArray[35] = "DrV0\u0019;\u0015p\f0%\u0004e\u0011m\u0002\u007f_DrV0\u0019;\u0015p\f0";
        objectArray[36] = "\u001dA}t\u0002\u0002@\u001a<\t\u0003:D\u0019<{\u001cF\u0005E7n";
        objectArray[37] = "]/9\n\u001b(\u001320[u,au8\u0001\f4Q$9\u000e\u001bE";
        objectArray[38] = "b1v.Hp?j7SJHlj#2\u0014&b22!";
        objectArray[39] = "4P<gQ\u00105\u0015,ml8@v\u000eQ;+RrC1\u0016\u000eb\u0017\"0S\u001eh";
        Object[] objectArray2 = objectArray;
        objectArray[40] = "bfJZ`\u001b03\u0014SP\r_n\u0017\u0019(\u0002$9\n_iie2\r\u000f*\b\"<I\u0001P";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = HomeRelog.e(l2, l3);
            object = C[n2];
            try {
                if (!(object instanceof String)) break block2;
                HomeRelog.C[n2] = clazz = Class.forName(D[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = HomeRelog.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = HomeRelog.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = HomeRelog.e(l2, l3);
        Object object = C[n2];
        if (object instanceof String) {
            String string = D[n2];
            int n3 = string.indexOf(8);
            Class clazz = HomeRelog.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = HomeRelog.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = HomeRelog.c(clazz3, string2, clazz2)) != null) {
                    HomeRelog.C[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = HomeRelog.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        HomeRelog.C[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = HomeRelog.f(500100397421703L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = HomeRelog.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = HomeRelog.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = HomeRelog.e(l2, l3);
        Object object = C[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = D[n2];
                int n4 = string2.indexOf(8);
                clazz3 = HomeRelog.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = HomeRelog.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = HomeRelog.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        HomeRelog.C[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = HomeRelog.f(500100397421703L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = HomeRelog.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        HomeRelog.C[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = HomeRelog.f(500100397421703L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == 'P' || c2 == 'Q' || c2 == '\u00ce' || c2 == '$') {
                field = HomeRelog.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == 'P' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == 'Q' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == '\u00ce' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = HomeRelog.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == '\u00e3' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == '\u00c7' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = HomeRelog.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_2().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/d/q" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(HomeRelog.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(HomeRelog.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_2() {
        try {
            return MethodHandles.lookup().findStatic(HomeRelog.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

