// === Kuzi module: FakeScoreboard ===
// Category   : SERVER
// Description: Shows a custom DonutSMP-style sidebar.
// Payload    : a.a.a.j.d.n (verified: False)

package kuzi.modules.server;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.j.d.b;
import kuzi.obf.m.r;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.StringSetting;
import net.minecraft.Objective;
import net.minecraft.PlayerTeam;
import net.minecraft.Scoreboard;
import net.minecraft.Minecraft;
import net.minecraft.DisplaySlot;

public final class FakeScoreboard
extends BaseModule {
    private static final String m;
    private final StringSetting title;
    private final BoolSetting money;
    private final StringSetting moneyAmount;
    private final BoolSetting shards;
    private final StringSetting shardsAmount;
    private final BoolSetting kills;
    private final StringSetting killsAmount;
    private final BoolSetting deaths;
    private final StringSetting deathsAmount;
    private final BoolSetting playtime;
    private final StringSetting playtimeAmount;
    private Objective previousObjective;
    private Objective nextObjective;
    private final List trackedPlayers;
    private long B;
    private static final long C;
    private static final String[] D;
    private static final String[] E;
    private static final Map F;
    private static final long[] G;
    private static final Integer[] H;
    private static final Map I;
    private static final long J;
    private static final Object[] K;
    private static final String[] L;

    public FakeScoreboard() {
        block0: {
            long l2 = C ^ 0x211BF3687CC5L;
            long l3 = l2 ^ 0x66A5CB51A4F3L;
            super("Fake Scoreboard", "Shows a custom DonutSMP-style sidebar.", Category.SERVER);
            this.title = new StringSetting("Title", "Drdonutt");
            this.money = new BoolSetting("Money", true);
            this.moneyAmount = new StringSetting("Money Amount", "67B");
            this.shards = new BoolSetting("Shards", true);
            this.shardsAmount = new StringSetting("Shards Amount", "67K");
            this.kills = new BoolSetting("Kills", true);
            int n2 = kuzi.obf.j.d.b.b();
            this.killsAmount = new StringSetting("Kills Amount", "67");
            this.deaths = new BoolSetting("Deaths", true);
            this.deathsAmount = new StringSetting("Deaths Amount", "67");
            this.playtime = new BoolSetting("Playtime", true);
            this.playtimeAmount = new StringSetting("Playtime Amount", "67h");
            this.trackedPlayers = new ArrayList();
            Object[] objectArray = new Object[2];
            objectArray[1] = new Setting[]{this.title, this.money, this.moneyAmount, this.shards, this.shardsAmount, this.kills, this.killsAmount, this.deaths, this.deathsAmount, this.playtime, this.playtimeAmount};
            objectArray[0] = l3;
            this.l(objectArray);
            if (BaseModule.b() != null) break block0;
            kuzi.obf.j.d.b.b(++n2);
        }
    }

    public String c(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = C ^ l2;
        return (String)((Object)FakeScoreboard.d("\u00a3", (Object)FakeScoreboard.d("\u00d4", (Object)this, (long)3521077083856487795L, (long)l2), (long)3520321109648374879L, (long)l2));
    }

    public void a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        String value = (String)objectArray[1];
        l2 = C ^ l2;
        FakeScoreboard.d("\u00a3", (Object)FakeScoreboard.d("\u00d4", (Object)this, (long)5488320425379608964L, (long)l2), (Object)value, (long)5491937008663023176L, (long)l2);
    }

    @Override
    public void d() {
        long l2 = C ^ 0xDD08F32E4EEL;
        long l3 = l2 ^ 0x3FE6B0545455L;
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.b(objectArray);
    }

    @Override
    public void e() {
        long l2 = C ^ 0x18AC96D384C0L;
        long l3 = l2 ^ 0x210FE8E6D9C9L;
        Minecraft.getInstance().execute(() -> this.f(l3));
    }

    @Override
    public void g(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = l2 ^ 0x72C14ACEBD66L;
        FakeScoreboard.d("\u00d3", (Object)this, null, (long)5688266169154494918L, (long)l2);
        FakeScoreboard.d("\u00d3", (Object)this, null, (long)5688148750063686291L, (long)l2);
        FakeScoreboard.d("\u00d4", (Object)this, (long)5688756007572275631L, (long)l2).clear();
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l3;
        FakeScoreboard.d("\u00a3", (Object)this, (Object)objectArray2, (long)5688234529373008025L, (long)l2);
    }

    @Override
    public void i() {
        block3: {
            long l2;
            block2: {
                long l3 = C ^ 0x15CBDBA623C2L;
                l2 = l3 ^ 0x27FDE4C09379L;
                long l4 = System.currentTimeMillis();
                int n2 = kuzi.obf.j.d.b.b();
                if (n2 == 0) break block2;
                if (l4 - this.B < J) break block3;
                this.B = l4;
            }
            Object[] objectArray = new Object[1];
            objectArray[0] = l2;
            this.b(objectArray);
        }
    }

    public void b(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = (l2 = C ^ l2) ^ 0x4FCC8C8ABF5BL;
        Minecraft.getInstance().execute(() -> this.lambda$requestUpdate$0(l3));
    }

    /*
     * Unable to fully structure code
     */
    private void f(long var1_1) {
        block14: {
            block17: {
                block16: {
                    block15: {
                        var3_2 = (var1_1 = FakeScoreboard.C ^ var1_1) ^ 87372911164508L;
                        var5_3 = kuzi.obf.j.d.b.b();
                        level = BaseModule.a.level;
                        if (var5_3 != 0) {
                            if (level == null) {
                                this.previousObjective = null;
                                this.trackedPlayers.clear();
                                return;
                            }
                            level = BaseModule.a.level;
                        }
                        scoreboard = level.getScoreboard();
                        self = this;
                        if (var1_1 <= 0L) break block15;
                        clearArgs = new Object[2];
                        clearArgs[1] = var3_2;
                        clearArgs[0] = scoreboard;
                        self.d(clearArgs);
                        if (var5_3 == 0) break block16;
                        self = this;
                    }
                    if (self.previousObjective == null) break block17;
                    try {
                        scoreboard.removeObjective(this.previousObjective);
                    }
                    catch (Exception var7_5) {
                        // empty catch block
                    }
                }
                this.previousObjective = null;
            }
            sidebarObjective = null;
            objective = this.nextObjective;
            v4 = var5_3;
            if (var1_1 <= 0L) ** GOTO lbl41
            if (v4 == 0) ** GOTO lbl40
            if (objective == null) break block14;
            try {
                block13: {
                    objective = scoreboard.getObjective(this.nextObjective.getName());
lbl40:
                    // 3 sources

                    v4 = var5_3;
lbl41:
                    // 2 sources

                    if (v4 == 0) break block13;
                    try {
                        block18: {
                            if (objective == null) break block14;
                            break block18;
                            catch (Exception v5) {
                                throw FakeScoreboard.a(v5);
                            }
                        }
                        objective = this.nextObjective;
                    }
                    catch (Exception v6) {
                        throw FakeScoreboard.a(v6);
                    }
                }
                sidebarObjective = objective;
            }
            catch (Exception var8_7) {
                // empty catch block
            }
        }
        try {
            scoreboard.setDisplayObjective(DisplaySlot.SIDEBAR, sidebarObjective);
        }
        catch (Exception var8_8) {
            // empty catch block
        }
        this.nextObjective = null;
    }

    /*
     * Loose catch block
     */
    private void d(Object[] objectArray) {
        block8: {
            Scoreboard scoreboard = (Scoreboard)objectArray[0];
            long l2 = (Long)objectArray[1];
            l2 = C ^ l2;
            Iterator iterator = FakeScoreboard.d("\u00d4", (Object)this, (long)2484495308310932775L, (long)l2).iterator();
            CallSite callSite = FakeScoreboard.d("W", (long)2485746931385911656L, (long)l2);
            while (iterator.hasNext()) {
                block9: {
                    String playerName = (String)iterator.next();
                    try {
                        PlayerTeam team = scoreboard.getPlayerTeam(playerName);
                        if (callSite != false) break block8;
                        try {
                            block10: {
                                if (team == null) break block9;
                                break block10;
                                catch (Exception exception) {
                                    throw FakeScoreboard.d("W", (Object)exception, (long)2484228017085216257L, (long)l2);
                                }
                            }
                            scoreboard.removePlayerTeam(team);
                        }
                        catch (Exception exception) {
                            throw FakeScoreboard.d("W", (Object)exception, (long)2484228017085216257L, (long)l2);
                        }
                    }
                    catch (Exception exception) {
                        // empty catch block
                    }
                }
                if (callSite == false) continue;
            }
            FakeScoreboard.d("\u00d4", (Object)this, (long)2484495308310932775L, (long)l2).clear();
            if (l2 >= 0L) {
                // empty if block
            }
        }
    }

    private void lambda$requestUpdate$0(long l2) {
        block5: {
            FakeScoreboard fakeScoreboard;
            long l3;
            block4: {
                l3 = (l2 = C ^ l2) ^ 0x500F6F8E15DFL;
                CallSite callSite = FakeScoreboard.d("W", (long)5531778723872857993L, (long)l2);
                try {
                    try {
                        fakeScoreboard = this;
                        if (callSite == false) break block4;
                        if (FakeScoreboard.d("\u00a3", (Object)fakeScoreboard, (long)5534117754156644702L, (long)l2) == false) break block5;
                    }
                    catch (r r2) {
                        throw FakeScoreboard.d("W", (Object)r2, (long)5534021341405223092L, (long)l2);
                    }
                    fakeScoreboard = this;
                }
                catch (r r3) {
                    throw FakeScoreboard.d("W", (Object)r3, (long)5534021341405223092L, (long)l2);
                }
            }
            Object[] objectArray = new Object[1];
            objectArray[0] = l3;
            FakeScoreboard.d("\u00a3", (Object)fakeScoreboard, (Object)objectArray, (long)5535965489380312146L, (long)l2);
        }
    }

    static {
        C = 112550478103331L;
        K = new Object[]{"\u0003H:o+(\bH?o$", "\u000b3I\u0019|&\u0015;SV\u001e:\u0012&", "qK\u0017\u0016rmzK\u0012\u0016q", Integer.TYPE, "bx\fDONiw\u001d\u000b$Zk|\nQ\bMf", "\u000e\u000bO\u0018-*{+D\u0017<e\u001a%O\u001c8?n", Void.TYPE, "A\u001f#o\u0011\u007fH\u001f o\u0013", "\u001ccEMhO\u0015cFMz", ":\u001clnw\u0002O<gafM.2ljb\u0017Z", "\u001cBWd\u000eE\u0017MF+s]\u0004JOb", "MdRR9dDdQR9", "C\u0016QP#\u0012H\u0019@\u001fB\u001cC\u0012DE", "*\u0016*\u0005\u001c\u0011_6!\n\r^>8*\u0001\t\u0004J", "\r#mu{`\r#z)wo\u0017hz7wz\u0010\u0019,i#9", "\u00006\u0010&L\u000bu\u0016\u001b)]D\u0014\u0018\u0010\"Y\u001e`", "7\n6\b4?<\n=", "\f\u007fN\u001e\u0017w\f\u007fYB\u001bx\u00164Y\\\u001bm\u0011E\t\u0001J", "\"v\t<uc\"v\u001e`yl8=\u001e~yy?LO$.", "C\u007f\u0010QXn6_\u001b^I!WQ\u0010UM{#", "F5H\u0015\bs3\u0015C\u001a\u0019<R\u001bH\u0011\u001df&", ">8}is^58xi\u007f", Boolean.TYPE, ":2E\u0007 \u0015+2j", "*\u001a\u0010N0\u0016!\u0015\u0001\u0001Z\u00155\u0019\nJ", Double.TYPE, Long.TYPE, "\u000bf~ukN~Fuzz\u0001\u001fH~q~[k", ";?", "\\i_\u0014@\u000fWiW", "g\t\u0018~\u001b\u0002\u0012)\u0013q\nMs'\u0018z\u000e\u0017\u0007", "&\u0000/\u0012\u00122%\u0002,H+%\u001f@uW@ry\b.GMO", "\u0015\u0002VQ.\u0017T\\\u001ci[}H\b@\u0014x\u001cU\u000fW\u0010", "vo\u000bK%|71Ase\u0016w8\u001dH n5i\u001eJ", "FS`+\rL\u0007\r*\u0013H&GWihYY\u0010\nao", ",p1V\u0016Zm.{nT0-''U\u0013Hov$W", "-p.2\u007fc.r-hFu\u00140tw-#rx/g \u001e", "\u0012[wFm\u0006S\u0005=~>lM@c\u00196\u0001\u0017E9\u0006RSCY9\u000en\bT\rt~", "/V^\to|n\b\u001416\u0016.RWJ;iy\u000f_M", ".Ckk}^o\u001d!S(4qX\u007f4&Y+]%+B\r{]d28[lEbS", "%yF \u0003\u0005d'\f\u0018Lo$}OcW\u0010s Gd", "I,uuMDAt7%r\u0013&,$pM\n\u001aw3$\u0000zF(3fL\u0005@,-wr", "\u0010p}!PHMjw?>D}jdb[D\u001cpr;\u0004-", "Bhpb\u0004UL7d3b\u0001riek\\\u0001N``f\u001eh", "\u0014\u000e\u0012x*LUPX@n&\u0015Y\u0004{/^W\b\u0007y", "1I\bM_-p\u0017Bu\fGnR\u001c\u0012\u0004*4WF\r`{bL\u0019\u001bQvpSCu", "qo7zO\u000501}B\u0019o.t#%\u0014\u0002tqy:p^3b~+HS\"h%B", "z&U1'yy$Vk\u001enCf\u000ftu9%.Tdx\u0004\u007f3\u000fjp5r!\u00100\u001e", "I\u001e\u001d!\u000e?\u0014\u0004\u0017?`3$\n\u0010c\u0005eGYH6\u0002Z", "a|CY\u0000 `.FR=5\u000b\u007fBDF2w/WUG", "`\f\u000ev@H!RDN6\"e\u0003\u00070\u001eX3\u0014\u001f6", "j;i\u001bI\u0012+e##\u0011xkl\u007f\u0018L\u0000)=|\u001a", "BR\u001enq\u001c\u0003\fTV6vCV\u0017-%\t\u0014\u000b\u001f*", "C>\u00152<*\u0002`_\n}@B:\u001cqh?\u0015g\u0014v", "&_=|N!'\r8ws7LT-u\u00190(R,uK]", "9G0LS_x\u0019zt\u001558\u0010&OVMzA%M", "e\u000e\u0015As\fd\\\u0010JN\u001c\u000f\t\u000f\t+OlZW\\,p", "g^9$--&\u0000s\u001c`G0]4yk*?Vs%", ")\u0012(\u001c^6hLb$\u000b\\v\t<C\u00051,\ff\\a`z\u00179JPmh\bc$", " rgUpCa,-m>)wqj\b6Dxz-T", "\u0004!\u0017\u007f9?\u001fx\u0010|\u0004\u000e*\u001f$^^U\u0004!\u0017\u007f9?\u001fx\u0010|", "\u001cB\u000f7&-\u0014\u001aMg\u0019zs\u001dCm|z\u0012\u0007U4#\u0013L\u0010Wii/\u0017\u0007\u0003$\u0019", "[U'\u0001\"1\u001a\u000bm9a[ZQ.Bv$\r\f&E", "%\u007f<\u001a\u0014\u0010d!v\"Bz\"p([\u0016\u0016 s4O+Ap|4\u001fGCs` \"", "B6Rk5sLiF:S'r7Gbm'N>Bo/NNh]k=\u007fCzB1S", "b&\u001c?;k#xV\u0007n\u0001==\b``lg8R\u007f\u00040 +Un<=1!\u000e\u0007", "<\u000bsQK\u001e}U9i\u001ftc\u0010g\u000e\u0010\u00199\u0015=\u0011tHo\u000eb\u0007EE}\u00118i", "aFxs[a`\u0014}xfy\u000bL{d\u0001yf\u0016~>\u001e\u001d7@ea\b,:Rz;f"};
        L = new String[]{null, null, null, "java/lang/Integer", null, null, "java/lang/Void", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, "java/lang/Boolean", null, null, "java/lang/Double", "java/lang/Long", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null};
        J = 1000L;
    }

    private static Exception a(Exception exception) {
        return exception;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (L[n4] != null) {
            return n4;
        }
        Object object = K[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 16;
            case 1 -> 17;
            case 2 -> 29;
            case 3 -> 45;
            case 4 -> 41;
            case 5 -> 24;
            case 6 -> 59;
            case 7 -> 25;
            case 8 -> 38;
            case 9 -> 35;
            case 10 -> 62;
            case 11 -> 32;
            case 12 -> 4;
            case 13 -> 8;
            case 14 -> 37;
            case 15 -> 31;
            case 16 -> 50;
            case 17 -> 0;
            case 18 -> 9;
            case 19 -> 33;
            case 20 -> 7;
            case 21 -> 63;
            case 22 -> 46;
            case 23 -> 43;
            case 24 -> 36;
            case 25 -> 34;
            case 26 -> 28;
            case 27 -> 11;
            case 28 -> 20;
            case 29 -> 26;
            case 30 -> 30;
            case 31 -> 54;
            case 32 -> 18;
            case 33 -> 2;
            case 34 -> 6;
            case 35 -> 19;
            case 36 -> 40;
            case 37 -> 1;
            case 38 -> 55;
            case 39 -> 60;
            case 40 -> 39;
            case 41 -> 27;
            case 42 -> 21;
            case 43 -> 10;
            case 44 -> 53;
            case 45 -> 14;
            case 46 -> 49;
            case 47 -> 57;
            case 48 -> 13;
            case 49 -> 48;
            case 50 -> 3;
            case 51 -> 61;
            case 52 -> 5;
            case 53 -> 58;
            case 54 -> 42;
            case 55 -> 44;
            case 56 -> 23;
            case 57 -> 52;
            case 58 -> 47;
            case 59 -> 56;
            case 60 -> 12;
            case 61 -> 15;
            case 62 -> 51;
            default -> 22;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        FakeScoreboard.L[n4] = new String(cArray);
        return n4;
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = FakeScoreboard.e(l2, l3);
            object = K[n2];
            try {
                if (!(object instanceof String)) break block2;
                FakeScoreboard.K[n2] = clazz = Class.forName(L[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = FakeScoreboard.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = FakeScoreboard.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = FakeScoreboard.e(l2, l3);
        Object object = K[n2];
        if (object instanceof String) {
            String string = L[n2];
            int n3 = string.indexOf(8);
            Class clazz = FakeScoreboard.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = FakeScoreboard.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = FakeScoreboard.c(clazz3, string2, clazz2)) != null) {
                    FakeScoreboard.K[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = FakeScoreboard.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        FakeScoreboard.K[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = FakeScoreboard.f(886625824741409L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = FakeScoreboard.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = FakeScoreboard.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = FakeScoreboard.e(l2, l3);
        Object object = K[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = L[n2];
                int n4 = string2.indexOf(8);
                clazz3 = FakeScoreboard.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = FakeScoreboard.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = FakeScoreboard.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        FakeScoreboard.K[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = FakeScoreboard.f(886625824741409L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = FakeScoreboard.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        FakeScoreboard.K[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = FakeScoreboard.f(886625824741409L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == '\u00d4' || c2 == '\u00d3' || c2 == '\u00a2' || c2 == 'b') {
                field = FakeScoreboard.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == '\u00d4' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == '\u00d3' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == '\u00a2' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = FakeScoreboard.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == '\u00a3' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == 'W' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = FakeScoreboard.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/d/n" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(FakeScoreboard.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

