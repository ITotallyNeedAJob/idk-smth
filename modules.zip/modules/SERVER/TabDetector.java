// === Kuzi module: TabDetector ===
// Category   : SERVER
// Description: Detects when specific players join or leave the server
// Payload    : a.a.a.j.e.ah (verified: True)

package kuzi.modules.server;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.b.l;
import kuzi.obf.h.b.r;
import kuzi.obf.h.b.v;
import kuzi.obf.j.e.am;
import kuzi.obf.p.au;
import kuzi.obf.p.n;
import kuzi.obf.p.x_0;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import net.minecraft.Minecraft;
import net.minecraft.ClientPacketListener;
import net.minecraft.PlayerInfo;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class TabDetector
extends BaseModule {
    private final r targetPlayers;
    private final l notificationMode;
    private final BoolSetting logOffline;
    private final Set currentTargets;
    private final Set previousTargets;
    private static final long r;
    private static final String[] s;
    private static final String[] t;
    private static final Map u;
    private static final Object[] v;
    private static final String[] w;

    public TabDetector() {
        long l2 = r ^ 0x31B157605416L;
        long l3 = l2 ^ 0x763196B20357L;
        super("TabDetector", "Detects when specific players join or leave the server", Category.SERVER);
        this.targetPlayers = new r("Target Players");
        this.notificationMode = new l("Notification Mode", (Enum)a.a.a.j.e.v.Both, a.a.a.j.e.v.class);
        this.logOffline = new BoolSetting("Log Offline", true);
        this.currentTargets = new HashSet();
        this.previousTargets = new HashSet();
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.targetPlayers, this.notificationMode, this.logOffline};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void i() {
        block22: {
            boolean bl;
            block23: {
                Object object;
                ClientPacketListener connection;
                String string;
                long l2;
                long l3;
                long l4;
                block18: {
                    block19: {
                        block16: {
                            Minecraft mc;
                            block17: {
                                block15: {
                                    long l5;
                                    long l6 = l5 = r ^ 0x15F5224DACB5L;
                                    l4 = l6 ^ 0x7FE53CC4D6A0L;
                                    l3 = l6 ^ 0x21C7C96B5EA3L;
                                    l2 = l6 ^ 0x5379E6CFB9CEL;
                                    string = am.b();
                                    mc = BaseModule.a;
                                    if (string == null) break block15;
                                    if (mc.player == null) break block16;
                                    mc = BaseModule.a;
                                }
                                if (string == null) break block17;
                                if (mc.level == null) break block16;
                                mc = BaseModule.a;
                            }
                            connection = mc.getConnection();
                            if (string == null) break block18;
                            if (connection != null) break block19;
                        }
                        return;
                    }
                    this.currentTargets.clear();
                    connection = BaseModule.a.getConnection();
                }
                Collection onlinePlayers = connection.getOnlinePlayers();
                Object object2 = onlinePlayers.iterator();
                block0: while (true) {
                    boolean bl2 = object2.hasNext();
                    block1: while (bl2) {
                        object = (PlayerInfo)object2.next();
                        String playerName = object.getProfile().name();
                        Object[] objectArray = new Object[1];
                        objectArray[0] = l2;
                        for (String targetEntry : this.targetPlayers.a(objectArray)) {
                            block21: {
                                block20: {
                                    bl2 = targetEntry.equalsIgnoreCase(playerName);
                                    if (string == null) continue block1;
                                    if (string == null) break block20;
                                    if (!bl2) break block21;
                                    this.currentTargets.add(playerName);
                                }
                                if (string != null) continue block0;
                            }
                            if (string != null) continue;
                        }
                        if (string != null) continue block0;
                    }
                    break;
                }
                object2 = new HashSet(this.currentTargets);
                object2.removeAll(this.previousTargets);
                bl = object2.isEmpty();
                if (string != null) {
                    if (!bl) {
                        Object[] objectArray = new Object[2];
                        objectArray[1] = object2;
                        objectArray[0] = l3;
                        this.notifyJoined(objectArray);
                    }
                    bl = (Boolean)this.logOffline.a();
                }
                if (string == null) break block22;
                if (!bl) break block23;
                object = new HashSet(this.previousTargets);
                object.removeAll(this.currentTargets);
                bl = object.isEmpty();
                if (string == null) break block22;
                if (!bl) {
                    Object[] objectArray = new Object[2];
                    objectArray[1] = l4;
                    objectArray[0] = object;
                    this.notifyLeft(objectArray);
                }
            }
            this.previousTargets.clear();
            bl = this.previousTargets.addAll(this.currentTargets);
        }
    }

    /*
     * Unable to fully structure code
     */
    private void notifyJoined(Object[] var1_1) {
        block13: {
            block12: {
                block11: {
                    block8: {
                        block9: {
                            block10: {
                                block7: {
                                    block5: {
                                        block6: {
                                            var3_2 = (Long)var1_1[0];
                                            playerNames = (Set)var1_1[1];
                                            v0 = var3_2 = TabDetector.r ^ var3_2;
                                            var5_4 = v0 ^ 71800915269641L;
                                            var7_5 = v0 ^ 93910420232649L;
                                            var9_6 = v0 ^ 75921989495782L;
                                            joinedNames = String.join((CharSequence)TabDetector.b("h", (int)25115, (long)(4032413730322023708L ^ var3_2)), playerNames);
                                            var11_8 = am.b();
                                            chatMessage = playerNames.size() == 1 ? (String)TabDetector.b("h", (int)15782, (long)(6623692836837055150L ^ var3_2)) + joinedNames : (String)TabDetector.b("h", (int)18254, (long)(4591525275608686664L ^ var3_2)) + joinedNames;
                                            v1 = var14_10 = (a.a.a.j.e.v)this.notificationMode.a();
                                            v2 = a.a.a.j.e.v.Chat;
                                            v3 = var11_8;
                                            if (var3_2 < 0L) break block5;
                                            if (v3 == null) break block6;
                                            if (v1 == v2) break block7;
                                            v1 = var14_10;
                                            v2 = a.a.a.j.e.v.Both;
                                        }
                                        v3 = var11_8;
                                    }
                                    if (var3_2 <= 0L) break block8;
                                    if (v3 == null) break block9;
                                    if (v1 != v2) break block10;
                                }
                                v4 = new Object[2];
                                v4[1] = chatMessage;
                                v4[0] = var5_4;
                                x_0.a(v4);
                            }
                            v1 = var14_10;
                            v2 = a.a.a.j.e.v.Toast;
                        }
                        if (var3_2 <= 0L) break block11;
                        v3 = var11_8;
                    }
                    if (v3 == null) break block11;
                    if (v1 == v2) break block12;
                    v1 = var14_10;
                    v2 = a.a.a.j.e.v.Both;
                }
                if (v1 != v2) break block13;
            }
            v5 = playerNames.size();
            if (var3_2 < 0L) ** GOTO lbl52
            if (v5 == 1) {
                v6 = TabDetector.b("h", (int)21622, (long)(7391374882822435704L ^ var3_2));
            } else {
                v5 = 10100;
lbl52:
                // 2 sources

                v6 = TabDetector.b("h", (int)v5, (long)(900221389745438833L ^ var3_2));
            }
            toastDetail = v6;
            v7 = new Object[1];
            v7[0] = var7_5;
            v8 = new Object[4];
            v8[3] = kuzi.obf.p.n.WARNING;
            v8[2] = toastDetail;
            v8[1] = TabDetector.b("h", (int)10073, (long)(7451348426789797973L ^ var3_2));
            v8[0] = var9_6;
            au.a(v7).b(v8);
        }
    }

    /*
     * Unable to fully structure code
     */
    private void notifyLeft(Object[] var1_1) {
        block13: {
            block12: {
                block11: {
                    block8: {
                        block9: {
                            block10: {
                                block7: {
                                    block5: {
                                        block6: {
                                            playerNames = (Set)var1_1[0];
                                            var2_3 = (Long)var1_1[1];
                                            v0 = var2_3 = TabDetector.r ^ var2_3;
                                            var5_4 = v0 ^ 34563776778250L;
                                            var7_5 = v0 ^ 12420182610378L;
                                            var9_6 = v0 ^ 29884426052581L;
                                            leftNames = String.join((CharSequence)TabDetector.b("h", (int)16495, (long)(5647847193523531622L ^ var2_3)), playerNames);
                                            var11_8 = am.b();
                                            chatMessage = playerNames.size() == 1 ? (String)TabDetector.b("h", (int)28748, (long)(25289222019325760L ^ var2_3)) + leftNames : (String)TabDetector.b("h", (int)9122, (long)(472578369464061089L ^ var2_3)) + leftNames;
                                            v1 = var14_10 = (a.a.a.j.e.v)this.notificationMode.a();
                                            v2 = a.a.a.j.e.v.Chat;
                                            v3 = var11_8;
                                            if (var2_3 < 0L) break block5;
                                            if (v3 == null) break block6;
                                            if (v1 == v2) break block7;
                                            v1 = var14_10;
                                            v2 = a.a.a.j.e.v.Both;
                                        }
                                        v3 = var11_8;
                                    }
                                    if (var2_3 < 0L) break block8;
                                    if (v3 == null) break block9;
                                    if (v1 != v2) break block10;
                                }
                                v4 = new Object[2];
                                v4[1] = chatMessage;
                                v4[0] = var5_4;
                                x_0.a(v4);
                            }
                            v1 = var14_10;
                            v2 = a.a.a.j.e.v.Toast;
                        }
                        if (var2_3 <= 0L) break block11;
                        v3 = var11_8;
                    }
                    if (v3 == null) break block11;
                    if (v1 == v2) break block12;
                    v1 = var14_10;
                    v2 = a.a.a.j.e.v.Both;
                }
                if (v1 != v2) break block13;
            }
            v5 = playerNames.size();
            if (var2_3 < 0L) ** GOTO lbl52
            if (v5 == 1) {
                v6 = TabDetector.b("h", (int)23856, (long)(5022530980231655994L ^ var2_3));
            } else {
                v5 = 28724;
lbl52:
                // 2 sources

                v6 = TabDetector.b("h", (int)v5, (long)(8656124536243167028L ^ var2_3));
            }
            toastDetail = v6;
            v7 = new Object[1];
            v7[0] = var7_5;
            v8 = new Object[4];
            v8[3] = kuzi.obf.p.n.INFO;
            v8[2] = toastDetail;
            v8[1] = TabDetector.b("h", (int)10073, (long)(7451451636688832598L ^ var2_3));
            v8[0] = var9_6;
            au.a(v7).b(v8);
        }
    }

    @Override
    public void d() {
        block6: {
            ClientPacketListener connection;
            String string;
            long l2;
            block5: {
                long l3 = r ^ 0xDEE76D96B99L;
                l2 = l3 ^ 0x4B62B25B7EE2L;
                String string2 = am.b();
                this.currentTargets.clear();
                string = string2;
                this.previousTargets.clear();
                connection = BaseModule.a.getConnection();
                if (string == null) break block5;
                if (connection == null) break block6;
                connection = BaseModule.a.getConnection();
            }
            Collection onlinePlayers = connection.getOnlinePlayers();
            Iterator playerIterator = onlinePlayers.iterator();
            block0: while (true) {
                boolean bl = playerIterator.hasNext();
                block1: while (bl) {
                    PlayerInfo playerInfo = (PlayerInfo)playerIterator.next();
                    String playerName = playerInfo.getProfile().name();
                    Object[] objectArray = new Object[1];
                    objectArray[0] = l2;
                    for (String targetEntry : this.targetPlayers.a(objectArray)) {
                        block8: {
                            block7: {
                                bl = targetEntry.equalsIgnoreCase(playerName);
                                if (string == null) continue block1;
                                if (string == null) break block7;
                                if (!bl) break block8;
                                this.previousTargets.add(playerName);
                            }
                            if (string != null) continue block0;
                        }
                        if (string != null) continue;
                    }
                    if (string != null) continue block0;
                }
                break;
            }
        }
    }

    @Override
    public void e() {
        this.currentTargets.clear();
        this.previousTargets.clear();
    }

    public List b(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = (l2 = r ^ l2) ^ 0x24005F73FFL;
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l3;
        return TabDetector.c("N", (Object)TabDetector.c("\u00ba", (Object)this, (long)-6135985000531761157L, (long)l2), (Object)objectArray2, (long)-6134852950313526309L, (long)l2);
    }

    public void c(Object[] objectArray) {
        block8: {
            String trimmedName;
            long l2;
            long l3;
            String rawName;
            block7: {
                rawName = (String)objectArray[0];
                l3 = (Long)objectArray[1];
                l2 = (l3 = r ^ l3) ^ 0x5D7FD7BA320DL;
                CallSite callSite = TabDetector.c("\u00dc", (long)-339176931038553557L, (long)l3);
                try {
                    try {
                        trimmedName = rawName;
                        if (callSite == null) break block7;
                        if (trimmedName == null) break block8;
                    }
                    catch (kuzi.obf.m.r r2) {
                        throw TabDetector.c("\u00dc", (Object)r2, (long)-340979530912787511L, (long)l3);
                    }
                    trimmedName = rawName.trim();
                }
                catch (kuzi.obf.m.r r3) {
                    throw TabDetector.c("\u00dc", (Object)r3, (long)-340979530912787511L, (long)l3);
                }
            }
            try {
                if (!trimmedName.isEmpty()) {
                    Object[] objectArray2 = new Object[2];
                    objectArray2[1] = l2;
                    objectArray2[0] = rawName.trim();
                    TabDetector.c("N", (Object)TabDetector.c("\u00ba", (Object)this, (long)-340893416729102745L, (long)l3), (Object)objectArray2, (long)-340431722808659846L, (long)l3);
                }
            }
            catch (kuzi.obf.m.r r4) {
                throw TabDetector.c("\u00dc", (Object)r4, (long)-340979530912787511L, (long)l3);
            }
        }
    }

    public void d(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        String playerName = (String)objectArray[1];
        long l3 = (l2 = r ^ l2) ^ 0x18726DE0C05BL;
        try {
            if (playerName != null) {
                Object[] objectArray2 = new Object[2];
                objectArray2[1] = playerName.trim();
                objectArray2[0] = l3;
                TabDetector.c("N", (Object)TabDetector.c("\u00ba", (Object)this, (long)-8373885637817284886L, (long)l2), (Object)objectArray2, (long)-8374221768106346125L, (long)l2);
            }
        }
        catch (kuzi.obf.m.r r2) {
            throw TabDetector.c("\u00dc", (Object)r2, (long)-8374016127416409276L, (long)l2);
        }
    }

    public int a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = r ^ l2;
        return TabDetector.c("\u00ba", (Object)this, (long)-7978845583315193229L, (long)l2).size();
    }

    /*
     * Unable to fully structure code
     */
    static {
        block11: {
            block10: {
                TabDetector.r = kuzi.obf.h.b.v.a(3009474403528813421L, -8450079744385411865L, MethodHandles.lookup().lookupClass()).a(249244148468912L);
                TabDetector.v = new Object[52];
                TabDetector.w = new String[52];
                TabDetector.c();
                TabDetector.u = new HashMap<K, V>(13);
                var0 = TabDetector.r ^ 131555109516106L;
                var2_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                v0 = SecretKeyFactory.getInstance("DES");
                v1 = new byte[8];
                v2 = v1;
                v1[0] = (byte)(var0 >>> 56);
                for (var3_2 = 1; var3_2 < 8; ++var3_2) {
                    v2 = v2;
                    v2[var3_2] = (byte)(var0 << var3_2 * 8 >>> 56);
                }
                var2_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                var9_3 = new String[16];
                var7_4 = 0;
                var6_5 = "\u009a\u00c1\u00ce\u008c\u00aal\u00db\u00df'\u00ca\u00e0/\u00f2\u00aeL\u000eb\u00f1SJ\u001c\u0004\u00ce\u00f0_\u00f8 u\u00a9{\u00d7\u0086}h\u000f\"\u00be\u00d7\u0087*\u00d8\u0019f\u009f~dL\u00ccfA\u00d4Mq#\u009f\u00b7\u00a8\u00d6:\u000b\t\u0019\u0098\u0084=\u00fb\u00c2\u0018\u00be,=\u0092\u0004N\u0016)\u00a5.r\u0092\u00c2:\u00dd\u000fB\u001d\u0094\u00fc\u00d5|J\u00d6O\u00a0\u0097v \u00cc\u00bcH\u0004\u008b%-]\u00a6t>\u00baU\u00b4\u008eh\u00c3\u00c1\u00acA\u00b3_\u00d5\u00f7\u00e2\u008f}\u00d2+\u00a3\u00cb\u009f(m\u008f\u009f\u00afNs\u00b1\u00f9\u009dx\u000b\u001b{\u000f]E\f\u00d5\u00e3n\u001b\u00f5\u00c5\u0086\u0001\u00fe\u00b5\u00f8p\u00a6!\u00c8\u00fb\u00f0\u00afls?\u0012\\(a\u00adN\u00e4Z{c0\u00e4\u0016\u0007?{]4\u0087_\u00e2\"!\u00e0\u00cf\\\u001c\u00bb\u00f6\u00f6v5\u008e\u0012\u00c8\u009e\u0088\u00e4\u00e9`\u00cd\u00b3\u00a2(\u0083\u00825\roP{\u0016\u0092\u00a2C\u00a5\u0087\u00c8[\u00c5\u0017\u0005%\u00f4\u00db\u00d2\u0080\u00110\u00962\u001b\u008d\u00f2\n\u00ee\u00ad\u00d5S:\u00e0!\u00ca\u00c7(_+0\u0017\u00962n\u00e2\u00ea\u0001*\u00d2\u0097X\"\u00fb\u00c0[\u00e2\u00e8\u0012\u008c\u00b05\u00bd\u0010\u00a0\u00b7\u00c5\u00eb\u008b\u008dAF\u008a\u0082\u0010\u00fe\u00c6\u00ba\u0018E\u008c\u00b2\u00bc\u00bfb\u00bc\u0089g\n\u00bds'\u008b2\"\u007f\u00f0\u001b7p2\u0006'\u0010M\u00b1\u00b5W\u00c7\u0080\u0004E\u0082\\\u00e1 \u00d7\u009fE\u00c0(\u0002\u007f0\u00d0\u0096L\u00afS<\u0080\u00f5\u00f7\u00baE\u00be\u0006\u008b\\S\u00cdy+\u0082|\u00e4\u00dd\u00ec'iO\u00dd\u00f5\u00c5\u008e^e\u00bc=_\u00c9(\u00ce\u00d2V_1\u00e8M\r\u0015\u009a\u00c1&\u00fdd\u0000\u0017\u00a3\u00fb\u008f\u00f7E,]\u00fe\u0019\u00c4\u008aP(\u0005\u00f9\u009b\u00ef\u00a4KS\u001b\u0094?\b\u0010\u0082w\u0089\u0088\u00f9\u0087\u00de\u00b5\u0085[\u00cd5a\u009b7\u008d(\u00d6\u00b8\u0010\u0091\u00de\u00a5M0\u00d0\u00cf\u00b3^L\u00e4\u00e1\u00f4ql4\u0094\u00acr}T\u008ea\u0001\u00ee\u001dB\u0097\u00af\u00e7\u00e6\u0011\u00e9\u0085\u00a5\u0084\u00f7 \u00dc\u007fe\u00f2\u00d1\u001f'\u0015\u0015\u0004--\u008aK\u000f\u00d3[\u0000w\u00c5\nk!\u00dc@-z\u00b7\u00eb\u00c5\u00cf\u00d0(\u00b6=j\u00aa\u00a3\u00a7\u0012\u00b6\u0092\u0098--\u00d0\u00d1\u0013\u00f9\u00b2\u0085\u008c\u00cd5zx\u00bf\u00b2s\u0004\n\u008a\u00df\u007f\u0091n\u00e0\u0081KI\u000eWq";
                var8_6 = "\u009a\u00c1\u00ce\u008c\u00aal\u00db\u00df'\u00ca\u00e0/\u00f2\u00aeL\u000eb\u00f1SJ\u001c\u0004\u00ce\u00f0_\u00f8 u\u00a9{\u00d7\u0086}h\u000f\"\u00be\u00d7\u0087*\u00d8\u0019f\u009f~dL\u00ccfA\u00d4Mq#\u009f\u00b7\u00a8\u00d6:\u000b\t\u0019\u0098\u0084=\u00fb\u00c2\u0018\u00be,=\u0092\u0004N\u0016)\u00a5.r\u0092\u00c2:\u00dd\u000fB\u001d\u0094\u00fc\u00d5|J\u00d6O\u00a0\u0097v \u00cc\u00bcH\u0004\u008b%-]\u00a6t>\u00baU\u00b4\u008eh\u00c3\u00c1\u00acA\u00b3_\u00d5\u00f7\u00e2\u008f}\u00d2+\u00a3\u00cb\u009f(m\u008f\u009f\u00afNs\u00b1\u00f9\u009dx\u000b\u001b{\u000f]E\f\u00d5\u00e3n\u001b\u00f5\u00c5\u0086\u0001\u00fe\u00b5\u00f8p\u00a6!\u00c8\u00fb\u00f0\u00afls?\u0012\\(a\u00adN\u00e4Z{c0\u00e4\u0016\u0007?{]4\u0087_\u00e2\"!\u00e0\u00cf\\\u001c\u00bb\u00f6\u00f6v5\u008e\u0012\u00c8\u009e\u0088\u00e4\u00e9`\u00cd\u00b3\u00a2(\u0083\u00825\roP{\u0016\u0092\u00a2C\u00a5\u0087\u00c8[\u00c5\u0017\u0005%\u00f4\u00db\u00d2\u0080\u00110\u00962\u001b\u008d\u00f2\n\u00ee\u00ad\u00d5S:\u00e0!\u00ca\u00c7(_+0\u0017\u00962n\u00e2\u00ea\u0001*\u00d2\u0097X\"\u00fb\u00c0[\u00e2\u00e8\u0012\u008c\u00b05\u00bd\u0010\u00a0\u00b7\u00c5\u00eb\u008b\u008dAF\u008a\u0082\u0010\u00fe\u00c6\u00ba\u0018E\u008c\u00b2\u00bc\u00bfb\u00bc\u0089g\n\u00bds'\u008b2\"\u007f\u00f0\u001b7p2\u0006'\u0010M\u00b1\u00b5W\u00c7\u0080\u0004E\u0082\\\u00e1 \u00d7\u009fE\u00c0(\u0002\u007f0\u00d0\u0096L\u00afS<\u0080\u00f5\u00f7\u00baE\u00be\u0006\u008b\\S\u00cdy+\u0082|\u00e4\u00dd\u00ec'iO\u00dd\u00f5\u00c5\u008e^e\u00bc=_\u00c9(\u00ce\u00d2V_1\u00e8M\r\u0015\u009a\u00c1&\u00fdd\u0000\u0017\u00a3\u00fb\u008f\u00f7E,]\u00fe\u0019\u00c4\u008aP(\u0005\u00f9\u009b\u00ef\u00a4KS\u001b\u0094?\b\u0010\u0082w\u0089\u0088\u00f9\u0087\u00de\u00b5\u0085[\u00cd5a\u009b7\u008d(\u00d6\u00b8\u0010\u0091\u00de\u00a5M0\u00d0\u00cf\u00b3^L\u00e4\u00e1\u00f4ql4\u0094\u00acr}T\u008ea\u0001\u00ee\u001dB\u0097\u00af\u00e7\u00e6\u0011\u00e9\u0085\u00a5\u0084\u00f7 \u00dc\u007fe\u00f2\u00d1\u001f'\u0015\u0015\u0004--\u008aK\u000f\u00d3[\u0000w\u00c5\nk!\u00dc@-z\u00b7\u00eb\u00c5\u00cf\u00d0(\u00b6=j\u00aa\u00a3\u00a7\u0012\u00b6\u0092\u0098--\u00d0\u00d1\u0013\u00f9\u00b2\u0085\u008c\u00cd5zx\u00bf\u00b2s\u0004\n\u008a\u00df\u007f\u0091n\u00e0\u0081KI\u000eWq".length();
                var5_7 = 96;
                var4_8 = -1;
lbl23:
                // 2 sources

                while (true) {
                    v3 = ++var4_8;
                    v4 = var6_5.substring(v3, v3 + var5_7);
                    v5 = -1;
                    break block10;
                    break;
                }
lbl28:
                // 1 sources

                while (true) {
                    var9_3[var7_4++] = TabDetector.b(var10_9).intern();
                    if ((var4_8 += var5_7) < var8_6) {
                        var5_7 = var6_5.charAt(var4_8);
                        ** continue;
                    }
                    var6_5 = "\u009e\u00e2\u00e0\t@?\u00c1\u0099\u00f9\u0001\u0094\u00df\u00acV)\u00e3(\u0093\u009a{\u00da\u00b2\u0087y\u00c2n\u0010Q\u00d1\u00dfF\u00e1Q\u00f7u\u00f9\u0007\u00f7%1 a\u00b6\u00b4\u00a1\u00c5S\u00d4'\u0006\u00f8\u00d7\u00d3p\u00d4\u0007\u00a4\u0012\u00f1B\u0002\u0004\u000e\u00f7&\u00ce\u00ad\u00b8\u00f2Y\u008cU\u0017";
                    var8_6 = "\u009e\u00e2\u00e0\t@?\u00c1\u0099\u00f9\u0001\u0094\u00df\u00acV)\u00e3(\u0093\u009a{\u00da\u00b2\u0087y\u00c2n\u0010Q\u00d1\u00dfF\u00e1Q\u00f7u\u00f9\u0007\u00f7%1 a\u00b6\u00b4\u00a1\u00c5S\u00d4'\u0006\u00f8\u00d7\u00d3p\u00d4\u0007\u00a4\u0012\u00f1B\u0002\u0004\u000e\u00f7&\u00ce\u00ad\u00b8\u00f2Y\u008cU\u0017".length();
                    var5_7 = 40;
                    var4_8 = -1;
lbl37:
                    // 2 sources

                    while (true) {
                        v6 = ++var4_8;
                        v4 = var6_5.substring(v6, v6 + var5_7);
                        v5 = 0;
                        break block10;
                        break;
                    }
                    break;
                }
lbl42:
                // 1 sources

                while (true) {
                    var9_3[var7_4++] = TabDetector.b(var10_9).intern();
                    if ((var4_8 += var5_7) < var8_6) {
                        var5_7 = var6_5.charAt(var4_8);
                        ** continue;
                    }
                    break block11;
                    break;
                }
            }
            var10_9 = var2_1.doFinal(v4.getBytes("ISO-8859-1"));
            switch (v5) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl54:
                // 1 sources

                ** continue;
            }
        }
        TabDetector.s = var9_3;
        TabDetector.t = new String[16];
    }

    private static kuzi.obf.m.r a(kuzi.obf.m.r r2) {
        return r2;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static String b(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x151B;
        if (t[n3] == null) {
            Object[] objectArray;
            try {
                Long l3 = Thread.currentThread().threadId();
                objectArray = (Object[])u.get(l3);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    u.put(l3, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/e/ah", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l2 >>> 56);
            for (int i2 = 1; i2 < 8; ++i2) {
                byArray[i2] = (byte)(l2 << i2 * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = s[n3].getBytes("ISO-8859-1");
            TabDetector.t[n3] = TabDetector.b(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return t[n3];
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        String string2 = TabDetector.b(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static CallSite b(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/e/ah" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (w[n4] != null) {
            return n4;
        }
        Object object = v[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 10;
            case 1 -> 9;
            case 2 -> 48;
            case 3 -> 13;
            case 4 -> 60;
            case 5 -> 15;
            case 6 -> 41;
            case 7 -> 54;
            case 8 -> 50;
            case 9 -> 7;
            case 10 -> 2;
            case 11 -> 17;
            case 12 -> 62;
            case 13 -> 8;
            case 14 -> 43;
            case 15 -> 36;
            case 16 -> 40;
            case 17 -> 51;
            case 18 -> 63;
            case 19 -> 30;
            case 20 -> 11;
            case 21 -> 23;
            case 22 -> 6;
            case 23 -> 42;
            case 24 -> 25;
            case 25 -> 52;
            case 26 -> 38;
            case 27 -> 21;
            case 28 -> 44;
            case 29 -> 58;
            case 30 -> 5;
            case 31 -> 29;
            case 32 -> 55;
            case 33 -> 39;
            case 34 -> 28;
            case 35 -> 27;
            case 36 -> 59;
            case 37 -> 37;
            case 38 -> 57;
            case 39 -> 24;
            case 40 -> 20;
            case 41 -> 12;
            case 42 -> 32;
            case 43 -> 16;
            case 44 -> 45;
            case 45 -> 1;
            case 46 -> 0;
            case 47 -> 22;
            case 48 -> 26;
            case 49 -> 53;
            case 50 -> 35;
            case 51 -> 46;
            case 52 -> 34;
            case 53 -> 47;
            case 54 -> 56;
            case 55 -> 19;
            case 56 -> 18;
            case 57 -> 49;
            case 58 -> 3;
            case 59 -> 4;
            case 60 -> 61;
            case 61 -> 33;
            case 62 -> 14;
            default -> 31;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        TabDetector.w[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = v;
        v[0] = "\u000f\fu:i\u0002\u0004\fq:iA";
        objectArray[1] = "!\u0003s}KM*\fb26U9\u000bk{";
        objectArray[2] = "\u0018\fV|\u001d\u001e\u0013\f]";
        objectArray[3] = "\u00179]mg\n\u00179J1k\u0005\rrJ/k\u0010\n\u0003\u001ar:";
        objectArray[4] = "\u001bp\u0017\u0007F:\u0010p\u0013\u0007F|";
        objectArray[5] = "pm\u001d9\b<ne\u0007vu,n";
        objectArray[6] = "vLzCk\u0004\u007fLyCi";
        objectArray[7] = "A]X\bk?H][\bx";
        objectArray[8] = "\r]U0!1\u0001]F";
        objectArray[9] = "FOvZ8S3o}U)\u001cRav^-F&";
        objectArray[10] = Void.TYPE;
        TabDetector.w[10] = "java/lang/Void";
        objectArray[11] = "\u0007\u000f\u0012\u0014rd\u000e\u000f\u0011\u0014r";
        objectArray[12] = "\u0018_\u001ao\u001eo\u0013P\u000b \u007fa\u0018[\u000fz";
        objectArray[13] = "MS0x&j8s;w7%Y}0|3\u007f-";
        objectArray[14] = "CDv\u0002u#6d}\rdlWjv\u0006`6#";
        objectArray[15] = "7Q\u000bwd4)Y\u00118\u0006(.D";
        objectArray[16] = "P\bCmJl%(Hb[#D&Ci_y0";
        objectArray[17] = "|bw0\u0015N\tB|?\u0004\u0001hLw4\u0000[\u001c";
        objectArray[18] = "[9-I\u007f\u0011J94";
        objectArray[19] = "71\\\u0001D?B\u0011W\u000eUp#\u001f\\\u0005Q*W";
        objectArray[20] = "jl\u000fFF\u0001al\u000bFQ";
        objectArray[21] = "TS\u0017ly\u0007ES\u00177";
        objectArray[22] = "\u000f\b\u0018\u001b{7z(\u0013\u0014jx\u001b&\u0018\u001fn\"o";
        objectArray[23] = "2r\n\u001a'\u0016;r\t\u001a*";
        objectArray[24] = "8~D8]\u0016)~K";
        objectArray[25] = "D\fK\ty\u001f1,@\u0006hPP\"K\rl\n$";
        objectArray[26] = "\u001by\\\u0018\u001a\u0019\u0010yT";
        objectArray[27] = "r\t\u0007iLR\u0007)\ff]\u001df'\u0007mYG\u0012";
        objectArray[28] = "?\u00035N6l%\u0003(\u0019\u000fnT\u0011k\u001eh}hIbIj\u0007k\u0018/I0;mM<Y\u000f";
        objectArray[29] = "?<l\u0003b\\xz2?z5vm`N|Lct8?";
        objectArray[30] = "lzcD$F:\"wD\u001eQU&/YyU9`dPn";
        objectArray[31] = "Au\u000e\"f\u0000W+@x\u001frK5\u0010Hr\u0004R#\tpdZ\u001cy";
        objectArray[32] = "\u001b[v]\u0004\u0015B\u001a!^=] [>LZYA\u0018%Y_";
        objectArray[33] = "^jr'&0\u0007+%$\u001fgem.ge\u007f\u0000k<?}";
        objectArray[34] = "nmK\u000b+\u00137,\u001c\b\u0012FUj\nJx^2(@\u000fk";
        objectArray[35] = "Az\u001e\u000e-h\u0018;I\r\u00141z|W\b*)A0L\u001csXG9WNec\u000b\"C\u0017\u0014";
        objectArray[36] = "0uN!\u001e95~Zzq/^,\u000f\u007f\u0016?bt\u0006(\u0014Ea%K(NygpX8q";
        objectArray[37] = "p(]A;\u001a)i\nB\u0002CKqU\u0003ePw)\\Tg*tx\u0011T=\u0016r-\u0002D\u0002";
        objectArray[38] = "\\!UY<y\u001ek\u0010JAr`3S\u000f&d\\kZX$\u001e_:\u0017X~\"Yo\u0004HA";
        objectArray[39] = "'F\f\rTI~\u0007[\u000em\u001f\u001c\u0012\u0007\u001eS\u0013%\u0003\u0000\u001c\b";
        objectArray[40] = ":r)-X\u001e`&n0(6\u001c\u0005\u0013VHN'0$?\u0012\u001a`-";
        objectArray[41] = "a\u001f*v+uxJ/aH\u0010M)JB\u0012Ka\u001f*v+uxJ/a";
        objectArray[42] = "4\\dt\u007f<n\b#i\u000f\n\u001d?_NI\u001aT\u0005 rt%=_t5i";
        objectArray[43] = "\u001b_#2\u0012hY\u0015f!od'M%d\bu\u001b\u0015,3\n\u000f\u0018Da3P3\u001e\u0011r#o";
        objectArray[44] = "F*xq>1Gnd>E&yakst6\u0007;;`|O";
        objectArray[45] = "\u0012Vx+~\u001a\u0017]lp\u0011\u000f|\u000f9uv\u001c@W0\"tf\u0012Vx+~\u001a\u0017]lp\u0011";
        objectArray[46] = "be#2:~t;mhC\ro0!X.zq3$`8$?i";
        objectArray[47] = "b,\nNr(;m]MKaY,B_,d8oYJ)";
        objectArray[48] = "$-\u00079?Y2sIcF=.x\u0002/F\fuo\u0013*~\u001a+!I";
        objectArray[49] = "/F(~\u0012)v\u0007\u007f}+s\u0014\u001f <Lc(G)kN\u0019+\u0016dk\u0014%-Cw{+";
        objectArray[50] = "l?$>9\u001a.ua-D\u0014P-\"h#\u0007lu+?!}:t!m;\u001a9~&/D";
        Object[] objectArray2 = objectArray;
        objectArray[51] = "FL%=pu\u0010\u00141=Jo\u007fHaq-qC\u0010h&/\u000b@A%&u7F\u001466J";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = TabDetector.e(l2, l3);
            object = v[n2];
            try {
                if (!(object instanceof String)) break block2;
                TabDetector.v[n2] = clazz = Class.forName(w[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = TabDetector.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = TabDetector.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = TabDetector.e(l2, l3);
        Object object = v[n2];
        if (object instanceof String) {
            String string = w[n2];
            int n3 = string.indexOf(8);
            Class clazz = TabDetector.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = TabDetector.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = TabDetector.c(clazz3, string2, clazz2)) != null) {
                    TabDetector.v[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = TabDetector.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        TabDetector.v[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = TabDetector.f(848705112907021L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = TabDetector.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = TabDetector.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = TabDetector.e(l2, l3);
        Object object = v[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = w[n2];
                int n4 = string2.indexOf(8);
                clazz3 = TabDetector.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = TabDetector.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = TabDetector.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        TabDetector.v[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = TabDetector.f(848705112907021L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = TabDetector.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        TabDetector.v[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = TabDetector.f(848705112907021L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == '\u00ba' || c2 == '\u00a2' || c2 == 'J' || c2 == '\u00f6') {
                field = TabDetector.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == '\u00ba' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == '\u00a2' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == 'J' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = TabDetector.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == 'N' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == '\u00dc' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = TabDetector.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/e/ah" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(TabDetector.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(TabDetector.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

