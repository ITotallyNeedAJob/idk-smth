// === Kuzi module: AdminHud ===
// Category   : SERVER
// Description: Panel of watched staff currently in tab.
// Payload    : a.a.a.j.d.g (verified: True)

package kuzi.modules.server;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.core.Client;
import kuzi.mixin.MixinExposed;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.modules.client.HUD;
import kuzi.obf.e.i;
import kuzi.obf.h.b.v;
import kuzi.obf.j.d.b;
import kuzi.obf.j.d.t;
import kuzi.obf.l.c.c;
import kuzi.obf.m.r;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.Minecraft;
import net.minecraft.SoundEvents;
import net.minecraft.ChatScreen;
import net.minecraft.PlayerInfo;
import net.minecraft.LocalPlayer;
import org.lwjgl.glfw.GLFW;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class AdminHud
extends BaseModule {
    private static final int m;
    private static final long n;
    private static final long o;
    private static final long p;
    private static final double q = -10.0;
    private static final double r = 15.0;
    private static final int s;
    private static final int t;
    private static final int u;
    private static final int v;
    private static final int w;
    private static final int x;
    private static final int y;
    private static final float z = 8.0f;
    private static final float A = 8.0f;
    private static final float B = 7.0f;
    private static final float C = 2.0f;
    private static final long D;
    private static final long E;
    private static final long F;
    private static final int G;
    private static final int H;
    private static final int I;
    private static final int J;
    private static final int K;
    private static final int L;
    private static final int M;
    private static final int N;
    public final BoolSetting alertSound;
    public final BoolSetting chatMessage;
    public final BoolSetting showPanel;
    public final SliderSetting positionX;
    public final SliderSetting positionY;
    public final SliderSetting size2;
    private final Map U;
    private final List V;
    private volatile List W;
    private long X;
    private long Y;
    private double Z;
    private boolean aa;
    private boolean ab;
    private int ac;
    private boolean ad;
    private double ae;
    private double af;
    private int[] panelBounds;
    private static final String ah;
    private static final long bb;
    private static final String[] db;
    private static final String[] hb;
    private static final Map ib;
    private static final long[] jb;
    private static final Integer[] kb;
    private static final Map lb;
    private static final long[] mb;
    private static final Long[] nb;
    private static final Map ob;
    private static final Object[] pb;
    private static final String[] sb;

    public AdminHud() {
        long l2 = bb ^ 0x79F03E0F4851L;
        long l3 = l2 ^ 0x35334501BF87L;
        super("AdminHud", "Panel of watched staff currently in tab.", Category.SERVER);
        this.alertSound = new BoolSetting("Alert Sound", true);
        this.chatMessage = new BoolSetting("Chat Message", false);
        this.showPanel = new BoolSetting("Show Panel", true);
        this.positionX = new SliderSetting("Position X", -1.0, -1.0, 4000.0, 1.0);
        this.positionY = new SliderSetting("Position Y", -1.0, -1.0, 4000.0, 1.0);
        this.size2 = new SliderSetting("Size", 1.0, 0.5, 2.0, 0.05);
        this.U = new HashMap();
        this.V = new ArrayList();
        this.W = List.of();
        this.Z = -999.0;
        this.panelBounds = new int[]{0, 0, 0, 0};
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.alertSound, this.chatMessage, this.showPanel, this.positionX, this.positionY, this.size2};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        long l2 = bb ^ 0x6ADCC05CB0EL;
        long l3 = l2 ^ 0x63ED9F9F096L;
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.a(objectArray);
    }

    @Override
    public void e() {
        long l2 = bb ^ 0x13D1D5E4AB20L;
        long l3 = l2 ^ 0x1342C01890B8L;
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.a(objectArray);
    }

    private void a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = bb ^ l2;
        this.U.clear();
        this.V.clear();
        this.W = List.of();
        this.X = System.currentTimeMillis() + AdminHud.d("x", (int)30729, (long)(0x28BACF59940A1BB6L ^ l2));
        this.Y = 0L;
        this.Z = -999.0;
        this.aa = false;
        this.ab = false;
        this.ad = false;
        this.ac = 0;
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public void i() {
        block25: {
            block24: {
                block33: {
                    block32: {
                        block31: {
                            block30: {
                                block29: {
                                    block27: {
                                        block28: {
                                            block26: {
                                                v0 = var1_1 = AdminHud.bb ^ 33769592523810L;
                                                var3_2 = v0 ^ 133644863177304L;
                                                var5_3 = v0 ^ 73930841516135L;
                                                var7_4 = v0 ^ 95177880271140L;
                                                var9_5 = v0 ^ 116796905673396L;
                                                v1 = v0 ^ 7174066655216L;
                                                var11_6 = (int)(v1 >>> 32);
                                                var12_7 = (int)(v1 << 32 >>> 48);
                                                var13_8 = (int)(v1 << 48 >>> 48);
                                                var14_9 = v0 ^ 133954630427857L;
                                                var16_10 = kuzi.obf.j.d.b.c();
                                                v2 = BaseModule.a;
                                                if (var16_10 != 0) break block26;
                                                if (v2.player == null) break block27;
                                                v2 = BaseModule.a;
                                            }
                                            if (var16_10 != 0) break block28;
                                            if (v2.level == null) break block27;
                                            v2 = BaseModule.a;
                                        }
                                        if (v2.getConnection() != null) break block29;
                                    }
                                    return;
                                }
                                ++this.ac;
                                var17_11 = this.V.size();
                                v3 = new Object[2];
                                v3[1] = var9_5;
                                v3[0] = System.currentTimeMillis();
                                this.d(v3);
                                v4 = this.V.size();
                                v5 = var17_11;
                                if (var16_10 != 0) break block30;
                                if (v4 != v5) {
                                    v6 = new Object[1];
                                    v6[0] = var3_2;
                                    this.m(v6);
                                }
                                v7 = this;
                                if (var16_10 != 0) break block31;
                                v4 = v7.ac;
                                v5 = 10;
                            }
                            if (v4 % v5 != 0) {
                                v7 = this;
                                if (var16_10 == 0) {
                                    v8 = new Object[1];
                                    v8[0] = var14_9;
                                    if (!v7.a(v8)) {
                                        return;
                                    } else {
                                        ** GOTO lbl-1000
                                    }
                                }
                            } else lbl-1000:
                            // 3 sources

                            {
                                v7 = this;
                            }
                        }
                        v9 = new Object[1];
                        v9[0] = var5_3;
                        var18_12 = v7.a(v9);
                        v10 = this;
                        if (var16_10 != 0) break block32;
                        if (v10.ab) break block33;
                        this.U.clear();
                        this.U.putAll(var18_12);
                        v11 = new Object[5];
                        v11[4] = true;
                        v11[3] = var7_4;
                        v11[2] = List.of();
                        v11[1] = List.of();
                        v11[0] = var18_12;
                        this.c(v11);
                        v10 = this;
                    }
                    v10.ab = true;
                    return;
                }
                var19_13 = new ArrayList<Iterator<E>>();
                for (Iterator<E> var21_15 : var18_12.keySet()) {
                    v12 = this.U.containsKey(var21_15);
                    if (var16_10 == 0 && !v12) {
                        v12 = var19_13.add(var21_15);
                    }
                    if (var16_10 == 0) continue;
                }
                var20_14 = new ArrayList<E>();
                var21_15 = this.U.keySet().iterator();
                while (var21_15.hasNext()) {
                    var22_16 = (String)var21_15.next();
                    v13 = var18_12.containsKey(var22_16);
                    if (var16_10 == 0) {
                        if (var16_10 == 0 && !v13) {
                            var20_14.add(var22_16);
                        }
                        if (var16_10 == 0) continue;
                    }
                    ** GOTO lbl109
                }
                v14 = new Object[5];
                v14[4] = false;
                v14[3] = var7_4;
                v14[2] = var20_14;
                v14[1] = var19_13;
                v14[0] = var18_12;
                this.c(v14);
                var21_15 = var19_13.iterator();
                do {
                    v13 = var21_15.hasNext();
lbl109:
                    // 2 sources

                    if (!v13) break;
                    var22_16 = (String)var21_15.next();
                    v15 = new Object[5];
                    v15[4] = (int)((char)var13_8);
                    v15[3] = true;
                    v15[2] = (String)var18_12.get(var22_16);
                    v15[1] = (int)((short)var12_7);
                    v15[0] = var11_6;
                    this.b(v15);
                    if (var16_10 != 0) break block24;
                } while (var16_10 == 0);
                var21_15 = var20_14.iterator();
            }
            while (var21_15.hasNext()) {
                var22_16 = (String)var21_15.next();
                v16 = new Object[5];
                v16[4] = (int)((char)var13_8);
                v16[3] = false;
                v16[2] = (String)this.U.get(var22_16);
                v16[1] = (int)((short)var12_7);
                v16[0] = var11_6;
                this.b(v16);
                if (var16_10 == 0) {
                    if (var16_10 == 0) continue;
                }
                break block25;
            }
            this.U.clear();
            this.U.putAll(var18_12);
        }
    }

    private void b(Object[] objectArray) {
        block14: {
            CallSite callSite;
            String string;
            long l2;
            long l3;
            block17: {
                int n2;
                block15: {
                    block16: {
                        boolean bl;
                        int n3;
                        String string2;
                        int n4;
                        block12: {
                            block13: {
                                Object object;
                                CallSite callSite2;
                                long l4;
                                int n5;
                                int n6;
                                block10: {
                                    block11: {
                                        int n7 = (Integer)objectArray[0];
                                        n4 = (Integer)objectArray[1];
                                        string2 = (String)objectArray[2];
                                        n3 = ((Boolean)objectArray[3]).booleanValue();
                                        n6 = (Integer)objectArray[4];
                                        long l5 = l3 = ((long)n7 << 32 | (long)n4 << 48 >>> 32 | (long)n6 << 48 >>> 48) ^ bb;
                                        l2 = l5 ^ 0x6D4F500AA9CDL;
                                        long l6 = l5 ^ 0x2158E400B7FBL;
                                        n5 = (int)(l6 >>> 32);
                                        l4 = l6 << 32 >>> 32;
                                        callSite2 = AdminHud.f("a", (long)-4333538008209029601L, (long)l3);
                                        try {
                                            object = string2;
                                            if (callSite2 == false) break block10;
                                            if (object != null) break block11;
                                        }
                                        catch (r r2) {
                                            throw AdminHud.f("a", (Object)r2, (long)-4339154853062918550L, (long)l3);
                                        }
                                        return;
                                    }
                                    object = AdminHud.f("R", (Object)AdminHud.f("\u00f0", (Object)this, (long)-4337361241709771739L, (long)l3), (long)-4340690771970008920L, (long)l3);
                                }
                                try {
                                    try {
                                        bl = (Boolean)object;
                                        if (n6 < 0 || callSite2 == false) break block12;
                                        if (!bl) break block13;
                                    }
                                    catch (r r3) {
                                        throw AdminHud.f("a", (Object)r3, (long)-4339154853062918550L, (long)l3);
                                    }
                                    AdminHud.f("\u00d1", (long)-4340977988799965817L, (long)l3).execute(() -> AdminHud.lambda$announce$0(n5, l4));
                                }
                                catch (r r4) {
                                    throw AdminHud.f("a", (Object)r4, (long)-4339154853062918550L, (long)l3);
                                }
                            }
                            bl = (Boolean)((Object)AdminHud.f("R", (Object)AdminHud.f("\u00f0", (Object)this, (long)-4337416148999361629L, (long)l3), (long)-4340690771970008920L, (long)l3));
                        }
                        try {
                            try {
                                if (!bl) break block14;
                                string = string2;
                                n2 = n3;
                                if (n4 > 0) break block15;
                                if (n2 == 0) break block16;
                            }
                            catch (r r5) {
                                throw AdminHud.f("a", (Object)r5, (long)-4339154853062918550L, (long)l3);
                            }
                            callSite = AdminHud.b("s", (int)12175, (long)(0x52E52131C58CBDAAL ^ l3));
                            break block17;
                        }
                        catch (r r6) {
                            throw AdminHud.f("a", (Object)r6, (long)-4339154853062918550L, (long)l3);
                        }
                    }
                    n2 = 7357;
                }
                callSite = AdminHud.b("s", (int)n2, (long)(0x17EEAA29FAFE0E91L ^ l3));
            }
            Object[] objectArray2 = new Object[2];
            objectArray2[1] = string + (String)((Object)callSite);
            objectArray2[0] = l2;
            AdminHud.f("a", (Object)objectArray2, (long)-4341159878150818683L, (long)l3);
        }
    }

    /*
     * Unable to fully structure code
     */
    private boolean a(Object[] var1_1) {
        block19: {
            block17: {
                block18: {
                    block16: {
                        block14: {
                            block15: {
                                var2_2 = (Long)var1_1[0];
                                var2_2 = AdminHud.bb ^ var2_2;
                                var5_3 = System.currentTimeMillis();
                                var4_4 = kuzi.obf.j.d.b.c();
                                var7_5 = BaseModule.a.player.getY();
                                cfr_temp_0 = var5_3 - this.X;
                                v0 = cfr_temp_0 == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1);
                                if (var4_4 == 0) {
                                    if (v0 >= 0) {
                                        this.X = var5_3 + AdminHud.d("x", (int)31607, (long)(8091078456057793453L ^ var2_2)) - AdminHud.d("x", (int)10756, (long)(6169224991181888223L ^ var2_2)) + (long)(Math.random() * 15000.0 * 2.0);
                                        return true;
                                    }
                                    cfr_temp_1 = var7_5 - -10.0;
                                    v0 = cfr_temp_1 == 0.0 ? 0 : (cfr_temp_1 < 0.0 ? -1 : 1);
                                }
                                if (var4_4 != 0) break block14;
                                if (v0 > 0) break block15;
                                cfr_temp_2 = var5_3 - this.Y - AdminHud.d("x", (int)9333, (long)(1197432023124432038L ^ var2_2));
                                v0 = cfr_temp_2 == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1);
                                v1 = var4_4;
                                if (var2_2 <= 0L) break block16;
                                if (v1 == 0) {
                                    if (v0 >= 0) {
                                        this.Y = var5_3;
                                        return true;
                                    } else {
                                        ** GOTO lbl26
                                    }
                                }
                                break block14;
                            }
                            v0 = (cfr_temp_3 = var7_5 - this.Z) == 0.0 ? 0 : (cfr_temp_3 > 0.0 ? 1 : -1);
                        }
                        v1 = var4_4;
                    }
                    if (var2_2 >= 0L) {
                        if (v1 == 0) {
                            if (v0 > 0) {
                                this.Z = var7_5;
                            }
                            v0 = (cfr_temp_4 = this.Z - var7_5 - 15.0) == 0.0 ? 0 : (cfr_temp_4 > 0.0 ? 1 : -1);
                        }
                        v1 = var4_4;
                    }
                    if (v1 != 0) break block17;
                    if (v0 < 0) break block18;
                    cfr_temp_5 = var5_3 - this.Y - AdminHud.d("x", (int)27806, (long)(3494618467824376911L ^ var2_2));
                    v0 = cfr_temp_5 == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1);
                    v2 = var4_4;
                    if (var2_2 <= 0L) break block19;
                    if (v2 == 0) {
                        if (v0 >= 0) {
                            this.Y = var5_3;
                            this.Z = var7_5;
                            return true;
                        } else {
                            ** GOTO lbl49
                        }
                    }
                    break block17;
                }
                v0 = (long)this.aa;
            }
            v2 = var4_4;
        }
        if (v2 == 0) {
            if (v0 == false) {
                v0 = BaseModule.a.player.tickCount;
                if (var4_4 == 0) {
                    if (v0 > AdminHud.c("d", (int)23355, (long)(490400789988427322L ^ var2_2))) {
                        this.aa = true;
                        return true;
                    } else {
                        ** GOTO lbl-1000
                    }
                }
            } else lbl-1000:
            // 3 sources

            {
                v0 = 0;
            }
        }
        return (boolean)v0;
    }

    /*
     * Unable to fully structure code
     */
    private Map a(Object[] var1_1) {
        block9: {
            var2_2 = (Long)var1_1[0];
            v0 = var2_2 = AdminHud.bb ^ var2_2;
            var4_3 = v0 ^ 12994672467349L;
            var6_4 = v0 ^ 113984050076035L;
            var9_5 = new HashMap<String, String>();
            var8_6 = kuzi.obf.j.d.b.c();
            v1 = var10_7 = BaseModule.a.getConnection();
            if (var8_6 == 0) {
                if (v1 == null) {
                    return var9_5;
                }
                v1 = var10_7;
            }
            for (PlayerInfo var12_9 : v1.getOnlinePlayers()) {
                v2 = var12_9.getTabListDisplayName();
                if (var2_2 > 0L && var8_6 == 0) {
                    if (v2 == null && var2_2 > 0L) continue;
                    v2 = var12_9.getTabListDisplayName();
                }
                v3 = v2.getString();
                if (var8_6 == 0) {
                    v4 = new Object[2];
                    v4[1] = var6_4;
                    v4[0] = v3;
                    if (!AdminHud.d(v4)) continue;
                    v3 = var12_9.getProfile().name();
                }
                v5 = var13_10 = v3;
                if (var8_6 != 0) ** GOTO lbl38
                if (v5 == null) ** GOTO lbl-1000
                v5 = var13_10;
                if (var8_6 == 0) {
                    ** if (v5.isEmpty()) goto lbl-1000
lbl-1000:
                    // 1 sources

                    {
                        v6 = var13_10;
                        ** GOTO lbl43
                    }
                }
                ** GOTO lbl38
lbl-1000:
                // 2 sources

                {
                    v5 = var12_9.getTabListDisplayName().getString();
lbl38:
                    // 3 sources

                    v7 = new Object[2];
                    v7[1] = v5;
                    v7[0] = var4_3;
                    v6 = AdminHud.a(v7);
                }
lbl43:
                // 2 sources

                var14_11 = v6;
                v8 = var9_5;
                if (var2_2 > 0L) {
                    v8.put(var14_11.toLowerCase(Locale.ROOT), var14_11);
                    if (var8_6 == 0) continue;
                }
                break block9;
            }
            v8 = var9_5;
        }
        return v8;
    }

    /*
     * Exception decompiling
     */
    private static boolean d(Object[] var0) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * java.lang.UnsupportedOperationException
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.considerAsDoLoopStart(LoopIdentifier.java:383)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.identifyLoops1(LoopIdentifier.java:65)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:681)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private static String a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        String text = (String)objectArray[1];
        l2 = bb ^ l2;
        return text.replaceAll((String)((Object)AdminHud.b("s", (int)28327, (long)(0x226DC02353EDAA44L ^ l2))), "").trim();
    }

    /*
     * Exception decompiling
     */
    private void c(Object[] var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [2[UNCONDITIONALDOLOOP]], but top level block is 4[DOLOOP]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:435)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:484)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private t a(Object[] objectArray) {
        String string = (String)objectArray[0];
        long l2 = (Long)objectArray[1];
        l2 = bb ^ l2;
        Iterator iterator = this.V.iterator();
        int n2 = kuzi.obf.j.d.b.c();
        while (iterator.hasNext()) {
            int n3;
            block4: {
                block5: {
                    t t2;
                    block3: {
                        t t3;
                        t2 = t3 = (t)iterator.next();
                        if (n2 != 0) break block3;
                        n3 = t2.a.equals(string);
                        if (l2 <= 0L) break block4;
                        if (n3 == 0) break block5;
                        t2 = t3;
                    }
                    return t2;
                }
                n3 = n2;
            }
            if (n3 == 0) continue;
        }
        return null;
    }

    private void f(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = (l2 = bb ^ l2) ^ 0x6B2A74D8E57CL;
        this.V.sort(Comparator.comparing(arg_0 -> AdminHud.lambda$sort$1(l3, arg_0)));
    }

    private void d(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = (Long)objectArray[1];
        long l4 = (l3 = bb ^ l3) ^ 0x38BB2F0D8CE8L;
        Iterator iterator = this.V.iterator();
        int n2 = kuzi.obf.j.d.b.b();
        while (iterator.hasNext()) {
            int n3;
            block7: {
                block6: {
                    block5: {
                        t t2 = (t)iterator.next();
                        n3 = t2.d;
                        if (l3 <= 0L || n2 == 0) break block5;
                        if (n3 == 0) break block6;
                        Object[] objectArray2 = new Object[3];
                        objectArray2[2] = l4;
                        objectArray2[1] = l2;
                        objectArray2[0] = t2;
                        float f2 = this.a(objectArray2) - 0.01f;
                        n3 = f2 == 0.0f ? 0 : (f2 < 0.0f ? -1 : 1);
                    }
                    if (l3 < 0L) break block7;
                    if (n3 <= 0) {
                        iterator.remove();
                    }
                }
                n3 = n2;
            }
            if (n3 != 0) continue;
        }
    }

    private void m(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = bb ^ l2;
        this.W = List.copyOf(this.V);
    }

    private float a(Object[] objectArray) {
        t t2 = (t)objectArray[0];
        long l2 = (Long)objectArray[1];
        long l3 = (Long)objectArray[2];
        l3 = bb ^ l3;
        long l4 = l2 - t2.e;
        int n2 = kuzi.obf.j.d.b.b();
        boolean bl = t2.d;
        if (n2 != 0) {
            if (bl) {
                return 1.0f - AdminHud.b(new Object[]{Float.valueOf(Math.min(1.0f, (float)l4 / 300.0f))});
            }
            bl = t2.c;
        }
        if (bl) {
            return AdminHud.b(new Object[]{Float.valueOf(Math.min(1.0f, (float)l4 / 350.0f))});
        }
        return 1.0f;
    }

    private static float b(Object[] objectArray) {
        float f2 = ((Float)objectArray[0]).floatValue();
        float f3 = 1.0f - f2;
        return 1.0f - f3 * f3 * f3;
    }

    private int a(Object[] objectArray) {
        int n2;
        block5: {
            long l2 = (Long)objectArray[0];
            long l3 = (l2 = bb ^ l2) ^ 0x4D8F4387CE28L;
            long l4 = System.currentTimeMillis();
            int n3 = kuzi.obf.j.d.b.b();
            int n4 = 0;
            for (t t2 : this.W) {
                block8: {
                    block7: {
                        float f2;
                        block6: {
                            n2 = t2.d ? 1 : 0;
                            int n5 = n3;
                            if (l2 > 0L) {
                                if (n5 == 0) break block5;
                                n5 = n3;
                            }
                            if (n5 == 0) break block6;
                            if (n2 == 0) break block7;
                            Object[] objectArray2 = new Object[3];
                            objectArray2[2] = l3;
                            objectArray2[1] = l4;
                            objectArray2[0] = t2;
                            float f3 = this.a(objectArray2) - 0.01f;
                            f2 = f3 == 0.0f ? 0 : (f3 > 0.0f ? 1 : -1);
                        }
                        if (f2 <= 0) break block8;
                    }
                    ++n4;
                }
                if (n3 != 0) continue;
            }
            n2 = n4;
        }
        return n2;
    }

    private int c(Object[] objectArray) {
        float f2;
        long l2;
        int n2;
        int n3;
        int n4;
        long l3;
        long l4;
        block4: {
            l4 = (Long)objectArray[0];
            long l5 = l4 = bb ^ l4;
            l3 = l5 ^ 0x180864FCF906L;
            long l6 = l5 ^ 0x635BFFEDB404L;
            n4 = (int)(l6 >>> 48);
            n3 = (int)(l6 << 16 >>> 32);
            n2 = (int)(l6 << 48 >>> 48);
            l2 = l5 ^ 0x691BACAB828DL;
            float f3 = 0.0f;
            int n5 = kuzi.obf.j.d.b.b();
            kuzi.obf.l.c.c.a((short)n4, 2, n3, n2);
            for (t t2 : this.W) {
                if (l4 >= 0L) {
                    f2 = Math.max(f3, kuzi.obf.l.c.c.a(t2.b, 8.0f, l3));
                    if (n5 == 0) break block4;
                    f3 = f2;
                }
                if (n5 != 0) continue;
            }
            f2 = 18.0f + f3;
            if (l4 >= 0L) {
                f2 = f2 + 6.0f;
            }
        }
        float f4 = f2;
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l2;
        float f5 = 10.0f + kuzi.obf.l.c.c.a((String)((Object)AdminHud.b("s", (int)31156, (long)(0x73EE3ACD041BDA47L ^ l4))), 8.0f, l3) + 10.0f + kuzi.obf.l.c.c.a((String)((Object)AdminHud.b("s", (int)26245, (long)(0xBC456CCEA504569L ^ l4))) + this.a(objectArray2), 7.0f, l3) + 6.0f;
        kuzi.obf.l.c.c.a((short)n4, 1, n3, n2);
        return Math.round(Math.max(92.0f, Math.max(f4, f5)));
    }

    private int d(Object[] objectArray) {
        CallSite callSite;
        block6: {
            reference v1;
            block4: {
                reference var7_4;
                long l2;
                block5: {
                    l2 = (Long)objectArray[0];
                    long l3 = (l2 = bb ^ l2) ^ 0x26726185EE6BL;
                    Object[] objectArray2 = new Object[1];
                    objectArray2[0] = l3;
                    var7_4 = AdminHud.f("R", (Object)this, (Object)objectArray2, (long)2228342483895929368L, (long)l2);
                    CallSite callSite2 = AdminHud.f("a", (long)2229713373788648818L, (long)l2);
                    try {
                        try {
                            v1 = var7_4;
                            if (callSite2 != false) break block4;
                            if (v1 != false) break block5;
                        }
                        catch (r r2) {
                            throw AdminHud.f("a", (Object)r2, (long)2226022310796223302L, (long)l2);
                        }
                        callSite = AdminHud.c("d", (int)18548, (long)(0x18CB9C677FBDE34DL ^ l2));
                        break block6;
                    }
                    catch (r r3) {
                        throw AdminHud.f("a", (Object)r3, (long)2226022310796223302L, (long)l2);
                    }
                }
                v1 = AdminHud.c("d", (int)18560, (long)(0x4326350103C06391L ^ l2)) + var7_4 * AdminHud.c("d", (int)4625, (long)(0x58AC207C7AD43907L ^ l2)) + AdminHud.c("d", (int)9067, (long)(0x5981595749430862L ^ l2));
            }
            callSite = v1 - 2;
        }
        return (int)callSite;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void e(Object[] objectArray) {
        float f2;
        Minecraft mc = (Minecraft)objectArray[0];
        long l2 = (Long)objectArray[1];
        long l3 = l2 = bb ^ l2;
        long l4 = l3 ^ 0x1EE0A48C5C31L;
        long l5 = l3 ^ 0x6D231B051408L;
        long l6 = l3 ^ 0x585399E6E533L;
        int n2 = (int)(l6 >>> 32);
        int n3 = (int)(l6 << 32 >>> 48);
        int n4 = (int)(l6 << 48 >>> 48);
        long l7 = l3 ^ 0x224AD62B78EEL;
        long l8 = l3 ^ 0x5093A585E139L;
        long l9 = l3 ^ 0x2565D965BB0FL;
        long l10 = l3 ^ 0x1DFC94976B37L;
        long l11 = l3 ^ 0x1EAD30FDB16FL;
        long l12 = l3 ^ 0x411C6B1ACAA1L;
        int n5 = (int)(l12 >>> 32);
        int n6 = (int)(l12 << 32 >>> 48);
        int n7 = (int)(l12 << 48 >>> 48);
        long l13 = l3 ^ 0x690724334427L;
        int n8 = kuzi.obf.j.d.b.b();
        if (!((Boolean)this.showPanel.a()).booleanValue() || mc.player == null) {
            return;
        }
        long l14 = System.currentTimeMillis();
        float f3 = f2 = (float)mc.getWindow().getGuiScale();
        if (l2 >= 0L) {
            float f4;
            float f5 = 0.0f;
            if (n8 != 0) {
                if (f3 <= f5) {
                    f2 = 1.0f;
                }
                f4 = ((Double)this.size2.a()).floatValue();
                f5 = 2.0f / f2;
            }
            f3 = f4 * f5;
        }
        float f6 = f3;
        int n9 = mc.getWindow().getGuiScaledWidth();
        int n10 = mc.getWindow().getGuiScaledHeight();
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l7;
        int n11 = this.c(objectArray2);
        int n12 = Math.round((float)n11 * f6);
        Object[] objectArray3 = new Object[1];
        objectArray3[0] = l5;
        int n13 = Math.round((float)this.d(objectArray3) * f6);
        Object[] objectArray4 = new Object[5];
        objectArray4[4] = n9 - n12 - AdminHud.c("d", (int)25455, (long)(0x63A7AA03D549B0A6L ^ l2));
        objectArray4[3] = n12;
        objectArray4[2] = l10;
        objectArray4[1] = n9;
        objectArray4[0] = ((Double)this.positionX.a()).intValue();
        int n14 = AdminHud.f(objectArray4);
        Object[] objectArray5 = new Object[5];
        objectArray5[4] = (int)AdminHud.c("d", (int)11353, (long)(0x64AA3D31DC5A7F95L ^ l2));
        objectArray5[3] = n13;
        objectArray5[2] = l10;
        objectArray5[1] = n10;
        objectArray5[0] = ((Double)this.positionY.a()).intValue();
        int n15 = AdminHud.f(objectArray5);
        this.panelBounds = new int[]{n14, n15, n12, n13};
        Object[] objectArray6 = new Object[8];
        objectArray6[7] = n13;
        objectArray6[6] = n12;
        objectArray6[5] = n10;
        objectArray6[4] = n9;
        objectArray6[3] = mc;
        objectArray6[2] = n4;
        objectArray6[1] = n3;
        objectArray6[0] = n2;
        this.q(objectArray6);
        kuzi.obf.l.c.c.f(l9);
        try {
            kuzi.obf.l.c.c.c(n14, l13, n15);
            kuzi.obf.l.c.c.a(f6, l8);
            Object[] objectArray7 = new Object[1];
            objectArray7[0] = l4;
            Object[] objectArray8 = new Object[4];
            objectArray8[3] = n11;
            objectArray8[2] = l11;
            objectArray8[1] = Float.valueOf(this.c(objectArray7));
            objectArray8[0] = l14;
            this.n(objectArray8);
        }
        finally {
            kuzi.obf.l.c.c.g(n5, (short)n6, (short)n7);
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private float c(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = bb ^ l2;
        int n2 = kuzi.obf.j.d.b.b();
        i i2 = Client.a;
        if (n2 != 0) {
            if (i2 == null) {
                return 1.0f;
            }
            i2 = Client.a;
        }
        HUD hUD = (HUD)i2.a(HUD.class);
        HUD hUD2 = hUD;
        if (hUD2 != null) return Math.max(0.16f, Math.min(1.0f, ((Double)hUD2.ak.a()).floatValue() / 255.0f));
        return 1.0f;
    }

    /*
     * WARNING - void declaration
     */
    private void n(Object[] objectArray) {
        block17: {
            Object object;
            long l2;
            long l3;
            long l4;
            float f2;
            block14: {
                void var40_30;
                long l5 = (Long)objectArray[0];
                f2 = ((Float)objectArray[1]).floatValue();
                l4 = (Long)objectArray[2];
                int n2 = (Integer)objectArray[3];
                long l6 = l4 = bb ^ l4;
                l3 = l6 ^ 0x223D24642E97L;
                long l7 = l6 ^ 0x75537989E9E7L;
                long l8 = l6 ^ 0x510F8FEA803AL;
                long l9 = l6 ^ 0x1EAE5B8BC9A4L;
                long l10 = l6 ^ 0x77815CDDBC43L;
                long l11 = l6 ^ 0x63CBD15BB967L;
                long l12 = l6 ^ 0x216CE727888L;
                int n3 = (int)(l12 >>> 48);
                int n4 = (int)(l12 << 16 >>> 48);
                int n5 = (int)(l12 << 32 >>> 32);
                long l13 = l6 ^ 0x8DB18AFE3EEL;
                int n6 = (int)(l13 >>> 32);
                int n7 = (int)(l13 << 32 >>> 40);
                int n8 = (int)(l13 << 56 >>> 56);
                long l14 = l6 ^ 0x5FBC193B7D85L;
                int n9 = (int)(l14 >>> 48);
                int n10 = (int)(l14 << 16 >>> 32);
                int n11 = (int)(l14 << 48 >>> 48);
                long l15 = l6 ^ 0x55FC4A7D4B0CL;
                l2 = l6 ^ 0x16F35E29053AL;
                long l16 = l6 ^ 0x1E73A3666F70L;
                Object[] objectArray2 = new Object[1];
                objectArray2[0] = l9;
                CallSite callSite = AdminHud.f("R", (Object)this, (Object)objectArray2, (long)-4935528794651902342L, (long)l4);
                Object[] objectArray3 = new Object[1];
                objectArray3[0] = l15;
                CallSite callSite2 = AdminHud.f("R", (Object)this, (Object)objectArray3, (long)-4932609132030070913L, (long)l4);
                Object[] objectArray4 = new Object[3];
                objectArray4[2] = Float.valueOf(f2);
                objectArray4[1] = l2;
                objectArray4[0] = (int)AdminHud.c("d", (int)14072, (long)(0x18201803DAF4B881L ^ l4));
                Object[] objectArray5 = new Object[3];
                objectArray5[2] = Float.valueOf(f2);
                objectArray5[1] = l2;
                objectArray5[0] = (int)AdminHud.c("d", (int)3249, (long)(0x566EDE3DACCE02D2L ^ l4));
                AdminHud.f("a", (int)n6, (float)0.0f, (int)n7, (byte)((byte)n8), (float)0.0f, (float)n2, (float)((float)callSite), (float)6.0f, (int)AdminHud.f("a", (Object)objectArray4, (long)-4931627082903744837L, (long)l4), (int)AdminHud.f("a", (Object)objectArray5, (long)-4931627082903744837L, (long)l4), (long)-4935597400819852938L, (long)l4);
                Object[] objectArray6 = new Object[3];
                objectArray6[2] = Float.valueOf(f2);
                objectArray6[1] = l2;
                objectArray6[0] = (int)AdminHud.c("d", (int)5247, (long)(0xA9E04A82CC49A19L ^ l4));
                AdminHud.f("a", (float)0.0f, (short)((short)n3), (float)0.0f, (float)n2, (char)((char)n4), (int)n5, (float)((float)callSite), (float)6.0f, (float)1.0f, (int)AdminHud.f("a", (Object)objectArray6, (long)-4931627082903744837L, (long)l4), (long)-4935761515493523787L, (long)l4);
                float f3 = 7.0f;
                CallSite callSite3 = AdminHud.f("a", (long)-4929475726108487659L, (long)l4);
                Object[] objectArray7 = new Object[3];
                objectArray7[2] = Float.valueOf(f2 * 0.85f);
                objectArray7[1] = l2;
                objectArray7[0] = (int)AdminHud.c("d", (int)23515, (long)(0x1EC5FC14AA9D55A3L ^ l4));
                AdminHud.f("a", (float)6.0f, (float)(f3 - 3.5f), (float)1.2f, (float)7.0f, (float)0.6f, (int)AdminHud.f("a", (Object)objectArray7, (long)-4931627082903744837L, (long)l4), (long)l11, (long)-4933788957335093017L, (long)l4);
                AdminHud.f("a", (short)((short)n9), (int)2, (int)n10, (int)n11, (long)-4935331115427730401L, (long)l4);
                CallSite callSite4 = callSite3;
                Object[] objectArray8 = new Object[3];
                objectArray8[2] = Float.valueOf(f2);
                objectArray8[1] = l2;
                objectArray8[0] = (int)AdminHud.c("d", (int)4954, (long)(0x651344019CEC9D2EL ^ l4));
                AdminHud.f("a", (Object)AdminHud.b("s", (int)18312, (long)(0x5564CC77E045ADE3L ^ l4)), (long)l3, (float)10.0f, (float)f3, (float)8.0f, (int)AdminHud.f("a", (Object)objectArray8, (long)-4931627082903744837L, (long)l4), (long)-4929554449887778469L, (long)l4);
                AdminHud.f("a", (short)((short)n9), (int)1, (int)n10, (int)n11, (long)-4935331115427730401L, (long)l4);
                Object[] objectArray9 = new Object[3];
                objectArray9[2] = Float.valueOf(f2);
                objectArray9[1] = l2;
                objectArray9[0] = (int)AdminHud.c("d", (int)17320, (long)(0x666E5C394ED24DCFL ^ l4));
                AdminHud.f("a", (String)((Object)AdminHud.b("s", (int)23323, (long)(0x187F3E216001B16AL ^ l4))) + (int)callSite2, (float)(n2 - AdminHud.c("d", (int)6380, (long)(0x59A0973E4B199691L ^ l4))), (float)f3, (long)l10, (float)7.0f, (int)AdminHud.f("a", (Object)objectArray9, (long)-4931627082903744837L, (long)l4), (long)-4934299756310938762L, (long)l4);
                float f4 = 14.0f;
                boolean n12 = false;
                Iterator iterator = AdminHud.f("\u00f0", (Object)this, (long)-4931522027902009554L, (long)l4).iterator();
                block10: while (true) {
                    Object object2 = iterator.hasNext();
                    while (object2) {
                        float f5;
                        float f6;
                        boolean bl;
                        reference var43_33;
                        t t2;
                        block15: {
                            block16: {
                                t2 = (t)iterator.next();
                                Object[] objectArray10 = new Object[3];
                                objectArray10[2] = l7;
                                objectArray10[1] = l5;
                                objectArray10[0] = t2;
                                var43_33 = AdminHud.f("R", (Object)this, (Object)objectArray10, (long)-4932140776233806513L, (long)l4);
                                try {
                                    try {
                                        reference cfr_temp_0 = var43_33 - 0.01f;
                                        object = cfr_temp_0 == 0 ? 0 : (cfr_temp_0 < 0 ? -1 : 1);
                                        if (l4 <= 0L || l4 <= 0L || callSite4 != false) break block14;
                                        if (callSite4 != false) break block15;
                                    }
                                    catch (r r2) {
                                        throw AdminHud.f("a", (Object)r2, (long)-4935073342179588575L, (long)l4);
                                    }
                                    if (object > 0) break block16;
                                }
                                catch (r r3) {
                                    throw AdminHud.f("a", (Object)r3, (long)-4935073342179588575L, (long)l4);
                                }
                                if (l4 >= 0L) continue block10;
                            }
                            bl = true;
                        }
                        var40_30 = bl;
                        float f7 = Math.max(0.0f, Math.min(1.0f, (float)var43_33)) * f2;
                        try {
                            f6 = AdminHud.f("\u00f0", (Object)t2, (long)-4932793854253256671L, (long)l4) != false ? 0.0f : (1.0f - AdminHud.f("a", (Object)new Object[]{Float.valueOf((float)var43_33)}, (long)-4934776204825378976L, (long)l4)) * 8.0f;
                        }
                        catch (r r4) {
                            throw AdminHud.f("a", (Object)r4, (long)-4935073342179588575L, (long)l4);
                        }
                        float f8 = f6;
                        try {
                            f5 = AdminHud.f("\u00f0", (Object)t2, (long)-4932793854253256671L, (long)l4) != false ? (1.0f - var43_33) * -6.0f : 0.0f;
                        }
                        catch (r r5) {
                            throw AdminHud.f("a", (Object)r5, (long)-4935073342179588575L, (long)l4);
                        }
                        float f9 = f5;
                        float f10 = 6.0f + f8;
                        float f11 = f4 + f9;
                        Object[] objectArray11 = new Object[3];
                        objectArray11[2] = Float.valueOf(f7);
                        objectArray11[1] = l2;
                        objectArray11[0] = (int)AdminHud.c("d", (int)27584, (long)(0x5E86F6AD1FC0E5B7L ^ l4));
                        Object[] objectArray12 = new Object[5];
                        objectArray12[4] = (int)AdminHud.f("a", (Object)objectArray11, (long)-4931627082903744837L, (long)l4);
                        objectArray12[3] = Float.valueOf(3.5f);
                        objectArray12[2] = l16;
                        objectArray12[1] = Float.valueOf(f11 + 3.5f);
                        objectArray12[0] = Float.valueOf(f10 + 3.5f);
                        AdminHud.f("a", (Object)objectArray12, (long)-4932512392812549913L, (long)l4);
                        AdminHud.f("a", (short)((short)n9), (int)2, (int)n10, (int)n11, (long)-4935331115427730401L, (long)l4);
                        Object[] objectArray13 = new Object[3];
                        objectArray13[2] = Float.valueOf(f7);
                        objectArray13[1] = l2;
                        objectArray13[0] = (int)AdminHud.c("d", (int)4954, (long)(0x651344019CEC9D2EL ^ l4));
                        AdminHud.f("a", (Object)AdminHud.f("\u00f0", (Object)t2, (long)-4932185693499656903L, (long)l4), (long)l3, (float)(f10 + 7.0f + 5.0f), (float)(f11 + 3.5f), (float)8.0f, (int)AdminHud.f("a", (Object)objectArray13, (long)-4931627082903744837L, (long)l4), (long)-4929554449887778469L, (long)l4);
                        AdminHud.f("a", (short)((short)n9), (int)1, (int)n10, (int)n11, (long)-4935331115427730401L, (long)l4);
                        Object[] objectArray14 = new Object[6];
                        objectArray14[5] = n2;
                        objectArray14[4] = Float.valueOf(f7);
                        objectArray14[3] = l8;
                        objectArray14[2] = Float.valueOf(f11 + 3.5f);
                        objectArray14[1] = l5;
                        objectArray14[0] = t2;
                        AdminHud.f("R", (Object)this, (Object)objectArray14, (long)-4933505761243808975L, (long)l4);
                        f4 += 12.0f * var43_33;
                        object2 = callSite4;
                        if (l4 < 0L) continue;
                        if (object2) break block10;
                        continue block10;
                    }
                    break;
                }
                object = var40_30;
            }
            try {
                if (l4 >= 0L) {
                    if (object != false) break block17;
                    object = 17760;
                }
                Object[] objectArray15 = new Object[3];
                objectArray15[2] = Float.valueOf(f2);
                objectArray15[1] = l2;
                objectArray15[0] = (int)AdminHud.c("d", (int)20833, (long)(0x15917394B835F3EL ^ l4));
                AdminHud.f("a", (Object)AdminHud.b("s", (int)object, (long)(0x3D08B9E3A86CAF03L ^ l4)), (long)l3, (float)6.0f, (float)20.0f, (float)7.0f, (int)AdminHud.f("a", (Object)objectArray15, (long)-4931627082903744837L, (long)l4), (long)-4929554449887778469L, (long)l4);
            }
            catch (r r6) {
                throw AdminHud.f("a", (Object)r6, (long)-4935073342179588575L, (long)l4);
            }
        }
    }

    private static int f(Object[] objectArray) {
        int n2;
        block10: {
            int n3;
            int n4;
            block11: {
                int n5;
                int n6;
                int n7;
                block12: {
                    int n8;
                    block13: {
                        int n9;
                        block8: {
                            n8 = (Integer)objectArray[0];
                            n7 = (Integer)objectArray[1];
                            long l2 = (Long)objectArray[2];
                            n6 = (Integer)objectArray[3];
                            int n10 = (Integer)objectArray[4];
                            l2 = bb ^ l2;
                            CallSite callSite = AdminHud.f("a", (long)7047843834906954317L, (long)l2);
                            try {
                                block9: {
                                    try {
                                        try {
                                            try {
                                                n9 = n8;
                                                if (callSite != false) break block8;
                                                if (n9 < 0) break block9;
                                            }
                                            catch (r r2) {
                                                throw AdminHud.f("a", (Object)r2, (long)7051260019455040633L, (long)l2);
                                            }
                                            n2 = n8;
                                            if (l2 < 0L) break block10;
                                            n4 = n7 - AdminHud.c("d", (int)12721, (long)(0x280821D9A23B6583L ^ l2));
                                            if (callSite != false) break block11;
                                        }
                                        catch (r r3) {
                                            throw AdminHud.f("a", (Object)r3, (long)7051260019455040633L, (long)l2);
                                        }
                                        if (l2 < 0L) break block12;
                                        if (n2 <= n4) break block13;
                                    }
                                    catch (r r4) {
                                        throw AdminHud.f("a", (Object)r4, (long)7051260019455040633L, (long)l2);
                                    }
                                }
                                n9 = Math.max(0, n10);
                            }
                            catch (r r5) {
                                throw AdminHud.f("a", (Object)r5, (long)7051260019455040633L, (long)l2);
                            }
                        }
                        return n9;
                    }
                    n3 = n8;
                    n5 = 0;
                }
                n4 = Math.max(n5, n7 - n6);
            }
            n2 = Math.min(n3, n4);
        }
        return n2;
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private void q(Object[] var1_1) {
        block73: {
            block74: {
                block75: {
                    block81: {
                        block82: {
                            block80: {
                                block77: {
                                    block79: {
                                        block78: {
                                            block76: {
                                                block68: {
                                                    block69: {
                                                        block70: {
                                                            block71: {
                                                                block72: {
                                                                    block66: {
                                                                        block67: {
                                                                            block65: {
                                                                                block63: {
                                                                                    block64: {
                                                                                        block59: {
                                                                                            block60: {
                                                                                                block61: {
                                                                                                    block62: {
                                                                                                        block57: {
                                                                                                            var6_2 = (Integer)var1_1[0];
                                                                                                            var8_3 = (Integer)var1_1[1];
                                                                                                            var2_4 = (Integer)var1_1[2];
                                                                                                            var3_5 = (Minecraft)var1_1[3];
                                                                                                            var5_6 = (Integer)var1_1[4];
                                                                                                            var4_7 = (Integer)var1_1[5];
                                                                                                            var7_8 = (Integer)var1_1[6];
                                                                                                            var9_9 = (Integer)var1_1[7];
                                                                                                            var10_10 = ((long)var6_2 << 32 | (long)var8_3 << 48 >>> 32 | (long)var2_4 << 48 >>> 48) ^ AdminHud.bb;
                                                                                                            var12_11 = var10_10 ^ 11385689820594L;
                                                                                                            var14_12 = AdminHud.f("a", (long)-1167758808195257848L, (long)var10_10);
                                                                                                            try {
                                                                                                                try {
                                                                                                                    block58: {
                                                                                                                        try {
                                                                                                                            try {
                                                                                                                                try {
                                                                                                                                    v0 /* !! */  = var3_5.screen instanceof ChatScreen;
                                                                                                                                    if (var14_12 == false) break block57;
                                                                                                                                    if (!v0 /* !! */ ) break block58;
                                                                                                                                }
                                                                                                                                catch (r v1) {
                                                                                                                                    throw AdminHud.f("a", (Object)v1, (long)-1162106756361776515L, (long)var10_10);
                                                                                                                                }
                                                                                                                                v2 = var3_5.getWindow();
                                                                                                                                if (var2_4 <= 0 || var14_12 == false) break block59;
                                                                                                                            }
                                                                                                                            catch (r v3) {
                                                                                                                                throw AdminHud.f("a", (Object)v3, (long)-1162106756361776515L, (long)var10_10);
                                                                                                                            }
                                                                                                                            if (v2 != null) break block60;
                                                                                                                        }
                                                                                                                        catch (r v4) {
                                                                                                                            throw AdminHud.f("a", (Object)v4, (long)-1162106756361776515L, (long)var10_10);
                                                                                                                        }
                                                                                                                    }
                                                                                                                    v5 = this;
                                                                                                                    v6 /* !! */  = var14_12;
                                                                                                                    if (var8_3 <= 0) break block61;
                                                                                                                    if (v6 /* !! */  == false) break block62;
                                                                                                                }
                                                                                                                catch (r v7) {
                                                                                                                    throw AdminHud.f("a", (Object)v7, (long)-1162106756361776515L, (long)var10_10);
                                                                                                                }
                                                                                                                v0 /* !! */  = AdminHud.f("\u00f0", (Object)v5, (long)-1164768546936689693L, (long)var10_10);
                                                                                                            }
                                                                                                            catch (r v8) {
                                                                                                                throw AdminHud.f("a", (Object)v8, (long)-1162106756361776515L, (long)var10_10);
                                                                                                            }
                                                                                                        }
                                                                                                        try {
                                                                                                            if (v0 /* !! */ ) {
                                                                                                                v9 = new Object[1];
                                                                                                                v9[0] = var12_11;
                                                                                                                AdminHud.f("R", (Object)this, (Object)v9, (long)-1163969387152779882L, (long)var10_10);
                                                                                                            }
                                                                                                        }
                                                                                                        catch (r v10) {
                                                                                                            throw AdminHud.f("a", (Object)v10, (long)-1162106756361776515L, (long)var10_10);
                                                                                                        }
                                                                                                        v5 = this;
                                                                                                    }
                                                                                                    v6 /* !! */  = (CallSite)false;
                                                                                                }
                                                                                                AdminHud.f("w", (Object)v5, (boolean)v6 /* !! */ , (long)-1164768546936689693L, (long)var10_10);
                                                                                                return;
                                                                                            }
                                                                                            v2 = var3_5.getWindow();
                                                                                        }
                                                                                        try {
                                                                                            try {
                                                                                                v11 = v2.getScreenWidth();
                                                                                                if (var14_12 == false) break block63;
                                                                                                if (v11 != 0) break block64;
                                                                                            }
                                                                                            catch (r v12) {
                                                                                                throw AdminHud.f("a", (Object)v12, (long)-1162106756361776515L, (long)var10_10);
                                                                                            }
                                                                                            v13 = 1.0;
                                                                                            break block65;
                                                                                        }
                                                                                        catch (r v14) {
                                                                                            throw AdminHud.f("a", (Object)v14, (long)-1162106756361776515L, (long)var10_10);
                                                                                        }
                                                                                    }
                                                                                    v11 = var3_5.getWindow().getGuiScaledWidth();
                                                                                }
                                                                                v13 = (double)v11 / (double)var3_5.getWindow().getScreenWidth();
                                                                            }
                                                                            var15_13 = v13;
                                                                            var17_14 = var3_5.mouseHandler.xpos() * var15_13;
                                                                            var19_15 = var3_5.mouseHandler.ypos() * var15_13;
                                                                            try {
                                                                                try {
                                                                                    v15 = GLFW.glfwGetMouseButton((long)var3_5.getWindow().handle(), (int)0);
                                                                                    v16 /* !! */  = var14_12;
                                                                                    if (var8_3 >= 0) {
                                                                                        if (v16 /* !! */  == false) break block66;
                                                                                        v16 /* !! */  = (CallSite)true;
                                                                                    }
                                                                                    if (v15 != v16 /* !! */ ) break block67;
                                                                                }
                                                                                catch (r v17) {
                                                                                    throw AdminHud.f("a", (Object)v17, (long)-1162106756361776515L, (long)var10_10);
                                                                                }
                                                                                v15 = 1;
                                                                                break block66;
                                                                            }
                                                                            catch (r v18) {
                                                                                throw AdminHud.f("a", (Object)v18, (long)-1162106756361776515L, (long)var10_10);
                                                                            }
                                                                        }
                                                                        v15 = 0;
                                                                    }
                                                                    var21_16 = v15;
                                                                    try {
                                                                        try {
                                                                            try {
                                                                                try {
                                                                                    v19 /* !! */  = var21_16;
                                                                                    if (var8_3 < 0 || var14_12 == false) break block68;
                                                                                    if (v19 /* !! */  != 0) break block69;
                                                                                }
                                                                                catch (r v20) {
                                                                                    throw AdminHud.f("a", (Object)v20, (long)-1162106756361776515L, (long)var10_10);
                                                                                }
                                                                                v21 = this;
                                                                                v22 /* !! */  = var14_12;
                                                                                if (var2_4 <= 0) break block70;
                                                                                if (v22 /* !! */  == false) break block71;
                                                                            }
                                                                            catch (r v23) {
                                                                                throw AdminHud.f("a", (Object)v23, (long)-1162106756361776515L, (long)var10_10);
                                                                            }
                                                                            if (AdminHud.f("\u00f0", (Object)v21, (long)-1164768546936689693L, (long)var10_10) == false) break block72;
                                                                        }
                                                                        catch (r v24) {
                                                                            throw AdminHud.f("a", (Object)v24, (long)-1162106756361776515L, (long)var10_10);
                                                                        }
                                                                        v25 = new Object[1];
                                                                        v25[0] = var12_11;
                                                                        AdminHud.f("R", (Object)this, (Object)v25, (long)-1163969387152779882L, (long)var10_10);
                                                                    }
                                                                    catch (r v26) {
                                                                        throw AdminHud.f("a", (Object)v26, (long)-1162106756361776515L, (long)var10_10);
                                                                    }
                                                                }
                                                                v21 = this;
                                                            }
                                                            v22 /* !! */  = (CallSite)false;
                                                        }
                                                        AdminHud.f("w", (Object)v21, (boolean)v22 /* !! */ , (long)-1164768546936689693L, (long)var10_10);
                                                        return;
                                                    }
                                                    try {
                                                        if (var2_4 < 0) break block73;
                                                        v27 = this;
                                                        if (var14_12 == false) break block74;
                                                        v19 /* !! */  = (int)AdminHud.f("\u00f0", (Object)v27, (long)-1164768546936689693L, (long)var10_10);
                                                    }
                                                    catch (r v28) {
                                                        throw AdminHud.f("a", (Object)v28, (long)-1162106756361776515L, (long)var10_10);
                                                    }
                                                }
                                                try {
                                                    try {
                                                        try {
                                                            if (var8_3 >= 0) {
                                                                if (v19 /* !! */  != 0) break block75;
                                                                cfr_temp_0 = var17_14 - (double)AdminHud.f("\u00f0", (Object)this, (long)-1163311715803435957L, (long)var10_10)[0];
                                                                v19 /* !! */  = cfr_temp_0 == 0.0 ? 0 : (cfr_temp_0 > 0.0 ? 1 : -1);
                                                            }
                                                            v29 = var14_12;
                                                            if (var8_3 >= 0) {
                                                                if (v29 == false) break block76;
                                                            }
                                                            ** GOTO lbl176
                                                        }
                                                        catch (r v30) {
                                                            throw AdminHud.f("a", (Object)v30, (long)-1162106756361776515L, (long)var10_10);
                                                        }
                                                        if (v19 /* !! */  < 0) break block77;
                                                    }
                                                    catch (r v31) {
                                                        throw AdminHud.f("a", (Object)v31, (long)-1162106756361776515L, (long)var10_10);
                                                    }
                                                    cfr_temp_1 = var17_14 - (double)(AdminHud.f("\u00f0", (Object)this, (long)-1163311715803435957L, (long)var10_10)[0] + var7_8);
                                                    v19 /* !! */  = cfr_temp_1 == 0.0 ? 0 : (cfr_temp_1 < 0.0 ? -1 : 1);
                                                }
                                                catch (r v32) {
                                                    throw AdminHud.f("a", (Object)v32, (long)-1162106756361776515L, (long)var10_10);
                                                }
                                            }
                                            try {
                                                try {
                                                    v29 = var14_12;
lbl176:
                                                    // 2 sources

                                                    if (var6_2 >= 0) {
                                                        if (v29 == false) break block78;
                                                        if (v19 /* !! */  >= 0) break block77;
                                                    }
                                                    ** GOTO lbl192
                                                }
                                                catch (r v33) {
                                                    throw AdminHud.f("a", (Object)v33, (long)-1162106756361776515L, (long)var10_10);
                                                }
                                                cfr_temp_2 = var19_15 - (double)AdminHud.f("\u00f0", (Object)this, (long)-1163311715803435957L, (long)var10_10)[1];
                                                v19 /* !! */  = cfr_temp_2 == 0.0 ? 0 : (cfr_temp_2 > 0.0 ? 1 : -1);
                                            }
                                            catch (r v34) {
                                                throw AdminHud.f("a", (Object)v34, (long)-1162106756361776515L, (long)var10_10);
                                            }
                                        }
                                        try {
                                            try {
                                                v29 = var14_12;
lbl192:
                                                // 2 sources

                                                if (var8_3 > 0) {
                                                    if (v29 == false) break block79;
                                                    if (v19 /* !! */  < 0) break block77;
                                                }
                                                ** GOTO lbl207
                                            }
                                            catch (r v35) {
                                                throw AdminHud.f("a", (Object)v35, (long)-1162106756361776515L, (long)var10_10);
                                            }
                                            cfr_temp_3 = var19_15 - (double)(AdminHud.f("\u00f0", (Object)this, (long)-1163311715803435957L, (long)var10_10)[1] + var9_9);
                                            v19 /* !! */  = cfr_temp_3 == 0.0 ? 0 : (cfr_temp_3 < 0.0 ? -1 : 1);
                                        }
                                        catch (r v36) {
                                            throw AdminHud.f("a", (Object)v36, (long)-1162106756361776515L, (long)var10_10);
                                        }
                                    }
                                    try {
                                        v29 = var14_12;
lbl207:
                                        // 2 sources

                                        if (v29 == false) break block80;
                                        if (v19 /* !! */  >= 0) break block77;
                                    }
                                    catch (r v37) {
                                        throw AdminHud.f("a", (Object)v37, (long)-1162106756361776515L, (long)var10_10);
                                    }
                                    v19 /* !! */  = 1;
                                    break block80;
                                }
                                v19 /* !! */  = 0;
                            }
                            var22_17 /* !! */  = v19 /* !! */ ;
                            try {
                                try {
                                    v38 /* !! */  = var14_12;
                                    if (var8_3 >= 0) {
                                        if (v38 /* !! */  == false) break block81;
                                        v38 /* !! */  = (CallSite)var22_17 /* !! */ ;
                                    }
                                    if (v38 /* !! */  != false) break block82;
                                }
                                catch (r v39) {
                                    throw AdminHud.f("a", (Object)v39, (long)-1162106756361776515L, (long)var10_10);
                                }
                                return;
                            }
                            catch (r v40) {
                                throw AdminHud.f("a", (Object)v40, (long)-1162106756361776515L, (long)var10_10);
                            }
                        }
                        AdminHud.f("w", (Object)this, (boolean)true, (long)-1164768546936689693L, (long)var10_10);
                        AdminHud.f("w", (Object)this, (double)(var17_14 - (double)AdminHud.f("\u00f0", (Object)this, (long)-1163311715803435957L, (long)var10_10)[0]), (long)-1165248697945926826L, (long)var10_10);
                    }
                    AdminHud.f("w", (Object)this, (double)(var19_15 - (double)AdminHud.f("\u00f0", (Object)this, (long)-1163311715803435957L, (long)var10_10)[1]), (long)-1164691552881010155L, (long)var10_10);
                }
                AdminHud.f("R", (Object)AdminHud.f("\u00f0", (Object)this, (long)-1167587248457685510L, (long)var10_10), (Object)((double)Math.round(Math.max(0.0, Math.min(var17_14 - AdminHud.f("\u00f0", (Object)this, (long)-1165248697945926826L, (long)var10_10), (double)(var5_6 - var7_8))))), (long)-1165155423660563448L, (long)var10_10);
                v27 = this;
            }
            AdminHud.f("R", (Object)AdminHud.f("\u00f0", (Object)v27, (long)-1164985723586473464L, (long)var10_10), (Object)((double)Math.round(Math.max(0.0, Math.min(var19_15 - AdminHud.f("\u00f0", (Object)this, (long)-1164691552881010155L, (long)var10_10), (double)(var4_7 - var9_9))))), (long)-1165155423660563448L, (long)var10_10);
        }
    }

    public int[] a(Object[] objectArray) {
        CallSite callSite;
        block10: {
            block9: {
                Object object;
                long l2;
                block8: {
                    l2 = (Long)objectArray[0];
                    l2 = bb ^ l2;
                    CallSite callSite2 = AdminHud.f("a", (long)569199481148391973L, (long)l2);
                    try {
                        try {
                            try {
                                object = ((Boolean)((Object)AdminHud.f("R", (Object)AdminHud.f("\u00f0", (Object)this, (long)575751045328165136L, (long)l2), (long)574448029575847058L, (long)l2))).booleanValue();
                                if (callSite2 == false) break block8;
                                if (object == 0) break block9;
                            }
                            catch (r r2) {
                                throw AdminHud.f("a", (Object)r2, (long)572560146587613776L, (long)l2);
                            }
                            callSite = AdminHud.f("\u00f0", (Object)this, (long)573765080209130598L, (long)l2);
                            if (callSite2 == false) break block10;
                        }
                        catch (r r3) {
                            throw AdminHud.f("a", (Object)r3, (long)572560146587613776L, (long)l2);
                        }
                        object = callSite[2];
                    }
                    catch (r r4) {
                        throw AdminHud.f("a", (Object)r4, (long)572560146587613776L, (long)l2);
                    }
                }
                try {
                    if (object <= 0) break block9;
                    callSite = AdminHud.f("\u00f0", (Object)this, (long)573765080209130598L, (long)l2);
                    break block10;
                }
                catch (r r5) {
                    throw AdminHud.f("a", (Object)r5, (long)572560146587613776L, (long)l2);
                }
            }
            callSite = null;
        }
        return callSite;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @MixinExposed
    public boolean a(double d2, double d3) {
        int n2 = kuzi.obf.j.d.b.c();
        int n3 = ((Boolean)this.showPanel.a()).booleanValue();
        if (n2 == 0) {
            if (n3 == 0) return 0 != 0;
            n3 = this.panelBounds[2];
        }
        if (n2 == 0) {
            if (n3 <= 0) return 0 != 0;
            double d4 = d2 - (double)this.panelBounds[0];
            n3 = d4 == 0.0 ? 0 : (d4 > 0.0 ? 1 : -1);
        }
        if (n2 == 0) {
            if (n3 < 0) return 0 != 0;
            double d5 = d3 - (double)this.panelBounds[1];
            n3 = d5 == 0.0 ? 0 : (d5 > 0.0 ? 1 : -1);
        }
        if (n2 == 0) {
            if (n3 < 0) return 0 != 0;
            double d6 = d2 - (double)(this.panelBounds[0] + this.panelBounds[2]);
            n3 = d6 == 0.0 ? 0 : (d6 < 0.0 ? -1 : 1);
        }
        if (n2 == 0) {
            if (n3 >= 0) return 0 != 0;
            double d7 = d3 - (double)(this.panelBounds[1] + this.panelBounds[3]);
            n3 = d7 == 0.0 ? 0 : (d7 < 0.0 ? -1 : 1);
        }
        if (n2 != 0) return n3 != 0;
        if (n3 >= 0) return 0 != 0;
        return 1 != 0;
    }

    @MixinExposed
    public void a(double d2) {
        this.size2.a(Math.max(0.5, Math.min(2.0, (double)Math.round(((Double)this.size2.a() + d2) * 100.0) / 100.0)));
    }

    private static String lambda$sort$1(long l2, t t2) {
        l2 = bb ^ l2;
        return ((String)((Object)AdminHud.f("\u00f0", (Object)t2, (long)-6196273531888704330L, (long)l2))).toLowerCase(Locale.ROOT);
    }

    private static void lambda$announce$0(int n2, long l2) {
        block5: {
            LocalPlayer localPlayer;
            block4: {
                long l3 = ((long)n2 << 32 | l2 << 32 >>> 32) ^ bb;
                CallSite callSite = AdminHud.f("a", (long)1794005909541761894L, (long)l3);
                try {
                    try {
                        localPlayer = ((Minecraft)AdminHud.f("\u00d1", (long)1799737791173234367L, (long)l3)).player;
                        if (callSite != false) break block4;
                        if (localPlayer == null) break block5;
                    }
                    catch (r r2) {
                        throw AdminHud.f("a", (Object)r2, (long)1797065848498054482L, (long)l3);
                    }
                    localPlayer = ((Minecraft)AdminHud.f("\u00d1", (long)1799737791173234367L, (long)l3)).player;
                }
                catch (r r3) {
                    throw AdminHud.f("a", (Object)r3, (long)1797065848498054482L, (long)l3);
                }
            }
            localPlayer.playSound(SoundEvents.ARROW_HIT_PLAYER, 1.0f, 1.0f);
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block31: {
            block30: {
                block29: {
                    block28: {
                        block27: {
                            block26: {
                                AdminHud.bb = kuzi.obf.h.b.v.a(-6796020884281033160L, -5857810815126416127L, MethodHandles.lookup().lookupClass()).a(68047721599093L);
                                AdminHud.pb = new Object[126];
                                AdminHud.sb = new String[126];
                                AdminHud.c();
                                AdminHud.ib = new HashMap<K, V>(13);
                                var22 = AdminHud.bb ^ 50247267758779L;
                                var24_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                                v0 = SecretKeyFactory.getInstance("DES");
                                v1 = new byte[8];
                                v2 = v1;
                                v1[0] = (byte)(var22 >>> 56);
                                for (var25_2 = 1; var25_2 < 8; ++var25_2) {
                                    v2 = v2;
                                    v2[var25_2] = (byte)(var22 << var25_2 * 8 >>> 56);
                                }
                                var24_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                                var31_3 = new String[19];
                                var29_4 = 0;
                                var28_5 = "\u00d4\u00f2\r&\u0096y\u00a6\u00f9\u007f\u00a5\u0085x\u0006r|\u00c0ob\u00e9L\u00a7Z\u00a0\u00d48\u0019=B\u00fa\u00ce)\u0018\u00c50C\u00e2\u001f\u0016\u0013\u0000\u00d0\u009b\u00f0R\u00b4kD\u00d0\u0097G*\u0016\u00f52\u0004\u00bc0\u00f4\u0088\u00a4\u0095\u00e0\u0081\u00ba\u0010\u0083\u0001\u0016kN\u00e0\u00fcZ\u00d9\u00db\u00bdF\u0090\u0003\u0017H\u0010#\u00a0;\u0004\u00ee\u00d1j\u00ef\u0085+r\u00bbjT\u00aa\u009c \u0002\u000b\u008f\u00b5\u00a5\u00dc\u00f2\u0013w-6'{>\n\u00a6\u00e6\u009e7\u0005\u00d4\u00d8M\u001e,m\u00e0\u00c70\u0004]\u00aa \u00cb\u008cKHw\u0091\u009f\be\u0013n\u0010\u008a\u00fds\u00fe\u0014x\u008e\u00ac\u00b76\u0001\u00be\u00de\u00d4`\u008e\u00f4\u001f\u00db\u00fd\u00183}\u00c9\u0081\u00e8N+'\u00fa\u00c8:RG\f\u00bdO\u00d3\u00cc5F3\u00d9@L \u007f\u008cO\u00d4\u009e\u001dXq\u0092\u00b65\u000b\u0097\u00c6u\u00b5L\u00c8\u008f\u00e1\u0094\u00c7\u0098\u0091D\u0089\u001f\f\u0015\u0083\u0018&\u0018\u0081bW>\u00da\u00db\u00d3\u00af}Q|\u00ea\u00cbnH+\u00b0\u00b8Q\u00e8\u0018\u0005\u00b8\u00adP\u00d02\u00d1\t<s|\u00e3\u00fe\u0014\u00cc\u0094\u00ba'\u00df\nd\u00bf\u00a1\u00bbh\u00aa\u00f8\u00e2\u00e2\u00c6s\r\u0097\u008e\u001f\u00bd%\u00ea\u00e6\t\u00c4A\u009b!<\u00bft\u00c5\u00bbo\u00db\u00ba\u00bc1_,\u00f5\u009c7?\u001e\u00e9=\u0096\u00fd\u0017\u00d9o\u0089\u00ce\u00af\u00bf\u0012v2\u00cc\u0006\u00d3`\u00904w0\u00aa(\u009d31\u00f4I\u00f5\u0016\u00bb\u0099\u00f4\u008eQ+\u009a\u00c2\u00ef\u0003\u001c\u0084\u00d0\u00bd\u00fc\u00bf\u00f7R\u00d5GN2:1\u00fa\u0085\u00f5O\u0006:B\u0017\u00ed8WM\u0091\u00b0\u00e5\u00f5p\u00e8t\u00ad\u0016\u00ba\u00e63\u00c7n\u00b3\u00fa\u00d6\u009a\u00a4\u00dbt\u00f54P4\u0083\u00e2\u00b3\u00b2\u00e1E\u00a5..\u001d\b\u00aa\u00b4\u00ee\u00e6Z\u00d7\u00c6\u00e7\u00b5\u00f6\u00c3!\u00ef\u00c29uGF\u0010]\u007f\u0000\u0002\u008b\u00e0\r\u0006\u0007\u009dg\u0087\u00e2\u00eb8V\u0010\u009f\u00ff\u00a4s\u00aa\u001c\u00fc\u00fdR\u0086r\u0096\u00d7\u001b\u00d1\u00f3\u0010\u0011Q1\u00b3\u0016<\u00f0\u0003d\u00f7\u001f\u00ad\u00ad5\u00cd\u0092 |\u00ef\u0089\u00c8R\u009e/\u0007\u00a1\u0000\u00b8\u00e72^hh`M\u00a6<P\u00ca\t\u00df\u0001\u000b\u0014q4\u0007\u00b2\u00b9\u0018\t\u0085\u0082ju\u00ca\u00a5\u00c3\u008aX\u0000U\u00d8\u000fW\u0013\u00028\u0000\u00b7\u00c1!\u0089\u00d3\u0018uQt\u00d0\u00bb\nS\u0093\u00e2\u00beI\u0082\u00ac\u00c3\u00bb\u00e2\u00a1\u00de\u00f3N3\u00b7\u00a0\u009a";
                                var30_6 = "\u00d4\u00f2\r&\u0096y\u00a6\u00f9\u007f\u00a5\u0085x\u0006r|\u00c0ob\u00e9L\u00a7Z\u00a0\u00d48\u0019=B\u00fa\u00ce)\u0018\u00c50C\u00e2\u001f\u0016\u0013\u0000\u00d0\u009b\u00f0R\u00b4kD\u00d0\u0097G*\u0016\u00f52\u0004\u00bc0\u00f4\u0088\u00a4\u0095\u00e0\u0081\u00ba\u0010\u0083\u0001\u0016kN\u00e0\u00fcZ\u00d9\u00db\u00bdF\u0090\u0003\u0017H\u0010#\u00a0;\u0004\u00ee\u00d1j\u00ef\u0085+r\u00bbjT\u00aa\u009c \u0002\u000b\u008f\u00b5\u00a5\u00dc\u00f2\u0013w-6'{>\n\u00a6\u00e6\u009e7\u0005\u00d4\u00d8M\u001e,m\u00e0\u00c70\u0004]\u00aa \u00cb\u008cKHw\u0091\u009f\be\u0013n\u0010\u008a\u00fds\u00fe\u0014x\u008e\u00ac\u00b76\u0001\u00be\u00de\u00d4`\u008e\u00f4\u001f\u00db\u00fd\u00183}\u00c9\u0081\u00e8N+'\u00fa\u00c8:RG\f\u00bdO\u00d3\u00cc5F3\u00d9@L \u007f\u008cO\u00d4\u009e\u001dXq\u0092\u00b65\u000b\u0097\u00c6u\u00b5L\u00c8\u008f\u00e1\u0094\u00c7\u0098\u0091D\u0089\u001f\f\u0015\u0083\u0018&\u0018\u0081bW>\u00da\u00db\u00d3\u00af}Q|\u00ea\u00cbnH+\u00b0\u00b8Q\u00e8\u0018\u0005\u00b8\u00adP\u00d02\u00d1\t<s|\u00e3\u00fe\u0014\u00cc\u0094\u00ba'\u00df\nd\u00bf\u00a1\u00bbh\u00aa\u00f8\u00e2\u00e2\u00c6s\r\u0097\u008e\u001f\u00bd%\u00ea\u00e6\t\u00c4A\u009b!<\u00bft\u00c5\u00bbo\u00db\u00ba\u00bc1_,\u00f5\u009c7?\u001e\u00e9=\u0096\u00fd\u0017\u00d9o\u0089\u00ce\u00af\u00bf\u0012v2\u00cc\u0006\u00d3`\u00904w0\u00aa(\u009d31\u00f4I\u00f5\u0016\u00bb\u0099\u00f4\u008eQ+\u009a\u00c2\u00ef\u0003\u001c\u0084\u00d0\u00bd\u00fc\u00bf\u00f7R\u00d5GN2:1\u00fa\u0085\u00f5O\u0006:B\u0017\u00ed8WM\u0091\u00b0\u00e5\u00f5p\u00e8t\u00ad\u0016\u00ba\u00e63\u00c7n\u00b3\u00fa\u00d6\u009a\u00a4\u00dbt\u00f54P4\u0083\u00e2\u00b3\u00b2\u00e1E\u00a5..\u001d\b\u00aa\u00b4\u00ee\u00e6Z\u00d7\u00c6\u00e7\u00b5\u00f6\u00c3!\u00ef\u00c29uGF\u0010]\u007f\u0000\u0002\u008b\u00e0\r\u0006\u0007\u009dg\u0087\u00e2\u00eb8V\u0010\u009f\u00ff\u00a4s\u00aa\u001c\u00fc\u00fdR\u0086r\u0096\u00d7\u001b\u00d1\u00f3\u0010\u0011Q1\u00b3\u0016<\u00f0\u0003d\u00f7\u001f\u00ad\u00ad5\u00cd\u0092 |\u00ef\u0089\u00c8R\u009e/\u0007\u00a1\u0000\u00b8\u00e72^hh`M\u00a6<P\u00ca\t\u00df\u0001\u000b\u0014q4\u0007\u00b2\u00b9\u0018\t\u0085\u0082ju\u00ca\u00a5\u00c3\u008aX\u0000U\u00d8\u000fW\u0013\u00028\u0000\u00b7\u00c1!\u0089\u00d3\u0018uQt\u00d0\u00bb\nS\u0093\u00e2\u00beI\u0082\u00ac\u00c3\u00bb\u00e2\u00a1\u00de\u00f3N3\u00b7\u00a0\u009a".length();
                                var27_7 = 24;
                                var26_8 = -1;
lbl23:
                                // 2 sources

                                while (true) {
                                    v3 = ++var26_8;
                                    v4 = var28_5.substring(v3, v3 + var27_7);
                                    v5 = -1;
                                    break block26;
                                    break;
                                }
lbl28:
                                // 1 sources

                                while (true) {
                                    var31_3[var29_4++] = AdminHud.b(var32_9).intern();
                                    if ((var26_8 += var27_7) < var30_6) {
                                        var27_7 = var28_5.charAt(var26_8);
                                        ** continue;
                                    }
                                    var28_5 = "\\>\u008eNTQ/\u00edm\u00a9\u0098\u0089\t\u0003\u00e1\u000b\u0010\u009dr3\u000f\u00a1\u00cd\u00d5\u00ba\u0000C\u0088\u00d1\u008bm~V";
                                    var30_6 = "\\>\u008eNTQ/\u00edm\u00a9\u0098\u0089\t\u0003\u00e1\u000b\u0010\u009dr3\u000f\u00a1\u00cd\u00d5\u00ba\u0000C\u0088\u00d1\u008bm~V".length();
                                    var27_7 = 16;
                                    var26_8 = -1;
lbl37:
                                    // 2 sources

                                    while (true) {
                                        v6 = ++var26_8;
                                        v4 = var28_5.substring(v6, v6 + var27_7);
                                        v5 = 0;
                                        break block26;
                                        break;
                                    }
                                    break;
                                }
lbl42:
                                // 1 sources

                                while (true) {
                                    var31_3[var29_4++] = AdminHud.b(var32_9).intern();
                                    if ((var26_8 += var27_7) < var30_6) {
                                        var27_7 = var28_5.charAt(var26_8);
                                        ** continue;
                                    }
                                    break block27;
                                    break;
                                }
                            }
                            var32_9 = var24_1.doFinal(v4.getBytes("ISO-8859-1"));
                            switch (v5) {
                                default: {
                                    ** continue;
                                }
                                ** case 0:
lbl54:
                                // 1 sources

                                ** continue;
                            }
                        }
                        AdminHud.db = var31_3;
                        AdminHud.hb = new String[19];
                        AdminHud.ah = "\u2605\u2606\u2b50\u2726\u2727\u272f\u2739\u269d";
                        AdminHud.lb = new HashMap<K, V>(13);
                        var11_10 = Cipher.getInstance("DES/CBC/NoPadding");
                        v7 = SecretKeyFactory.getInstance("DES");
                        v8 = new byte[8];
                        v9 = v8;
                        v8[0] = (byte)(var22 >>> 56);
                        for (var12_11 = 1; var12_11 < 8; ++var12_11) {
                            v9 = v9;
                            v9[var12_11] = (byte)(var22 << var12_11 * 8 >>> 56);
                        }
                        var11_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                        var17_12 = new long[37];
                        var14_13 = 0;
                        var15_14 = "Y7\u00a94\u00f8\u00eb\u00d0\u008a\u00ad\u00c3\u009f\u00d4<S\u00a2H\u00a7\u00ad\"1\u008b&h\u000eF9\u00aa\u00bf\u00cf\u0000r<hHE\u00fdu:\u00e3\u00b8\u0099\"\u00030\u0093\u0012\u00f8;\u00a7\u009d\u00f3!\u0092\u00d1z#i1\u00ff\u00a4\u00c8\u00fd\u00f4\u00a0\u00fe\u0090*\u00ca\u00de\u0006\u009b\u00ac\u00f2\u00edF\u00fa\u0090\u000eq\\|\u009d\u00dc\u0017\u008f\u001b\u009f\u008deU\u00c2\u0018\u008f\u0094\u00a2gn^\u008b\u009b\u00db\u00a4\u00c7V\u00a9Z\u00afH\u00e9G\u00ac\u007f\u00fa\u00ae\u00beWG!\u00c9\u000f\u0093&\u00da\u001a\u00cf\u00b6\u00e5a\u00ff\u00cb\u0083h\u0084@K2\u00a3\u00d0\u00d0n\u00d7\u00e3\u00d4\u001c/\u0093a\u00b6C\u00f3\u0010v\u00cf\u00deD\u00ae<\u00ec\u00c9\f7\u00a9\u00ae\u00ebh\u00fd\u0095\u00ee\u0084\u000f\u00d6,\u00f5\u0000P\u008cO\u0014\u0090juS?7\u001a+\u00c1<-\u00a1\u00d2\u00d4\u0000\u0005\u009f?t\u0081\u00f3#\u00d0P\u001eC\u008d\u0014uk7\u001aW\u00a5\u00ac\u00f7\u0015\r\u00feW\u0012Sb;\u00a7\u00d3(U\u00ad\u009ad\u00d5\u00fb\u001a\u00fap\u00f9=\u001fl\u0091$\u00ff\u0083#\u00e6\u00fcx#\u0003\u0088\u009f\u00b9y\u000e;\u00cd\u0000\u000e\u00ee\u00b0\u00bc\u00e1\u00c4\u0090\u00a7\u0004\u00dc\u0098\u0000\u00e7?\"\u00f8\u00c9r\u00c9\u00b8s\u00b9\u00de_";
                        var16_15 = "Y7\u00a94\u00f8\u00eb\u00d0\u008a\u00ad\u00c3\u009f\u00d4<S\u00a2H\u00a7\u00ad\"1\u008b&h\u000eF9\u00aa\u00bf\u00cf\u0000r<hHE\u00fdu:\u00e3\u00b8\u0099\"\u00030\u0093\u0012\u00f8;\u00a7\u009d\u00f3!\u0092\u00d1z#i1\u00ff\u00a4\u00c8\u00fd\u00f4\u00a0\u00fe\u0090*\u00ca\u00de\u0006\u009b\u00ac\u00f2\u00edF\u00fa\u0090\u000eq\\|\u009d\u00dc\u0017\u008f\u001b\u009f\u008deU\u00c2\u0018\u008f\u0094\u00a2gn^\u008b\u009b\u00db\u00a4\u00c7V\u00a9Z\u00afH\u00e9G\u00ac\u007f\u00fa\u00ae\u00beWG!\u00c9\u000f\u0093&\u00da\u001a\u00cf\u00b6\u00e5a\u00ff\u00cb\u0083h\u0084@K2\u00a3\u00d0\u00d0n\u00d7\u00e3\u00d4\u001c/\u0093a\u00b6C\u00f3\u0010v\u00cf\u00deD\u00ae<\u00ec\u00c9\f7\u00a9\u00ae\u00ebh\u00fd\u0095\u00ee\u0084\u000f\u00d6,\u00f5\u0000P\u008cO\u0014\u0090juS?7\u001a+\u00c1<-\u00a1\u00d2\u00d4\u0000\u0005\u009f?t\u0081\u00f3#\u00d0P\u001eC\u008d\u0014uk7\u001aW\u00a5\u00ac\u00f7\u0015\r\u00feW\u0012Sb;\u00a7\u00d3(U\u00ad\u009ad\u00d5\u00fb\u001a\u00fap\u00f9=\u001fl\u0091$\u00ff\u0083#\u00e6\u00fcx#\u0003\u0088\u009f\u00b9y\u000e;\u00cd\u0000\u000e\u00ee\u00b0\u00bc\u00e1\u00c4\u0090\u00a7\u0004\u00dc\u0098\u0000\u00e7?\"\u00f8\u00c9r\u00c9\u00b8s\u00b9\u00de_".length();
                        var13_16 = 0;
                        while (true) {
                            var18_17 = var15_14.substring(var13_16, var13_16 += 8).getBytes("ISO-8859-1");
                            v10 = var17_12;
                            v11 = var14_13++;
                            v12 = ((long)var18_17[0] & 255L) << 56 | ((long)var18_17[1] & 255L) << 48 | ((long)var18_17[2] & 255L) << 40 | ((long)var18_17[3] & 255L) << 32 | ((long)var18_17[4] & 255L) << 24 | ((long)var18_17[5] & 255L) << 16 | ((long)var18_17[6] & 255L) << 8 | (long)var18_17[7] & 255L;
                            v13 = -1;
                            break block28;
                            break;
                        }
lbl82:
                        // 1 sources

                        while (true) {
                            v10[v11] = v14;
                            if (var13_16 < var16_15) ** continue;
                            var15_14 = "\u00b7s\u001c\u0011\u00ce\u0001~\u001be8\u00f9\u0097>\u00b0d\u00e5";
                            var16_15 = "\u00b7s\u001c\u0011\u00ce\u0001~\u001be8\u00f9\u0097>\u00b0d\u00e5".length();
                            var13_16 = 0;
                            while (true) {
                                var18_17 = var15_14.substring(var13_16, var13_16 += 8).getBytes("ISO-8859-1");
                                v10 = var17_12;
                                v11 = var14_13++;
                                v12 = ((long)var18_17[0] & 255L) << 56 | ((long)var18_17[1] & 255L) << 48 | ((long)var18_17[2] & 255L) << 40 | ((long)var18_17[3] & 255L) << 32 | ((long)var18_17[4] & 255L) << 24 | ((long)var18_17[5] & 255L) << 16 | ((long)var18_17[6] & 255L) << 8 | (long)var18_17[7] & 255L;
                                v13 = 0;
                                break block28;
                                break;
                            }
                            break;
                        }
lbl95:
                        // 1 sources

                        while (true) {
                            v10[v11] = v14;
                            if (var13_16 < var16_15) ** continue;
                            break block29;
                            break;
                        }
                    }
                    var19_18 = v12;
                    var21_19 = var11_10.doFinal(new byte[]{(byte)(var19_18 >>> 56), (byte)(var19_18 >>> 48), (byte)(var19_18 >>> 40), (byte)(var19_18 >>> 32), (byte)(var19_18 >>> 24), (byte)(var19_18 >>> 16), (byte)(var19_18 >>> 8), (byte)var19_18});
                    v14 = ((long)var21_19[0] & 255L) << 56 | ((long)var21_19[1] & 255L) << 48 | ((long)var21_19[2] & 255L) << 40 | ((long)var21_19[3] & 255L) << 32 | ((long)var21_19[4] & 255L) << 24 | ((long)var21_19[5] & 255L) << 16 | ((long)var21_19[6] & 255L) << 8 | (long)var21_19[7] & 255L;
                    switch (v13) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl108:
                        // 1 sources

                        ** continue;
                    }
                }
                AdminHud.jb = var17_12;
                AdminHud.kb = new Integer[37];
                AdminHud.K = -11141291;
                AdminHud.t = 92;
                AdminHud.J = 0x14FFFFFF;
                AdminHud.x = 7;
                AdminHud.y = 6;
                AdminHud.m = 10;
                AdminHud.s = 60;
                AdminHud.v = 12;
                AdminHud.G = -1726605025;
                AdminHud.I = 0x1AFFFFFF;
                AdminHud.w = 6;
                AdminHud.L = -1183500;
                AdminHud.N = -7629401;
                AdminHud.H = -1945432814;
                AdminHud.M = -8484709;
                AdminHud.u = 14;
                AdminHud.ob = new HashMap<K, V>(13);
                var0_20 = Cipher.getInstance("DES/CBC/NoPadding");
                v15 = SecretKeyFactory.getInstance("DES");
                v16 = new byte[8];
                v17 = v16;
                v16[0] = (byte)(var22 >>> 56);
                for (var1_21 = 1; var1_21 < 8; ++var1_21) {
                    v17 = v17;
                    v17[var1_21] = (byte)(var22 << var1_21 * 8 >>> 56);
                }
                var0_20.init(2, (Key)v15.generateSecret(new DESKeySpec(v17)), new IvParameterSpec(new byte[8]));
                var6_22 = new long[14];
                var3_23 = 0;
                var4_24 = "j\u00e1\u0080X\u0097\u00f4\u0081\u007f6h\u00e2)U$\u00f1\u0098\u00f6\"\u00ea\u00c7\u00a1)\u00c1K\u00a6X\u001ba\u00dd\u009f\u00ed\u00c1\u00a2g \u001f9P\u00e7\u0096\u00f6\f\u00c0b\u00df\u0005)4;\u00d6X\u00abZ\u0088\u0015\u00eb4\u00cam\u008e\u0000\u00b8\u00b6\f\u00c7?\u0000\u000e\u000e(\u009dq\u0010U[\u00ceXr\u00b3n\u00d3j\u0080\u00f1\u009b\u001d(o\u00ab\u00a6\u00e8\u00c7\u00ccX\u0017-";
                var5_25 = "j\u00e1\u0080X\u0097\u00f4\u0081\u007f6h\u00e2)U$\u00f1\u0098\u00f6\"\u00ea\u00c7\u00a1)\u00c1K\u00a6X\u001ba\u00dd\u009f\u00ed\u00c1\u00a2g \u001f9P\u00e7\u0096\u00f6\f\u00c0b\u00df\u0005)4;\u00d6X\u00abZ\u0088\u0015\u00eb4\u00cam\u008e\u0000\u00b8\u00b6\f\u00c7?\u0000\u000e\u000e(\u009dq\u0010U[\u00ceXr\u00b3n\u00d3j\u0080\u00f1\u009b\u001d(o\u00ab\u00a6\u00e8\u00c7\u00ccX\u0017-".length();
                var2_26 = 0;
                while (true) {
                    var7_27 = var4_24.substring(var2_26, var2_26 += 8).getBytes("ISO-8859-1");
                    v18 = var6_22;
                    v19 = var3_23++;
                    v20 = ((long)var7_27[0] & 255L) << 56 | ((long)var7_27[1] & 255L) << 48 | ((long)var7_27[2] & 255L) << 40 | ((long)var7_27[3] & 255L) << 32 | ((long)var7_27[4] & 255L) << 24 | ((long)var7_27[5] & 255L) << 16 | ((long)var7_27[6] & 255L) << 8 | (long)var7_27[7] & 255L;
                    v21 = -1;
                    break block30;
                    break;
                }
lbl151:
                // 1 sources

                while (true) {
                    v18[v19] = v22;
                    if (var2_26 < var5_25) ** continue;
                    var4_24 = "\u008a\u00e5\u00ab\u00dd%\u00d3m\u0003\u008d{i`\u00cfR;\u00dc";
                    var5_25 = "\u008a\u00e5\u00ab\u00dd%\u00d3m\u0003\u008d{i`\u00cfR;\u00dc".length();
                    var2_26 = 0;
                    while (true) {
                        var7_27 = var4_24.substring(var2_26, var2_26 += 8).getBytes("ISO-8859-1");
                        v18 = var6_22;
                        v19 = var3_23++;
                        v20 = ((long)var7_27[0] & 255L) << 56 | ((long)var7_27[1] & 255L) << 48 | ((long)var7_27[2] & 255L) << 40 | ((long)var7_27[3] & 255L) << 32 | ((long)var7_27[4] & 255L) << 24 | ((long)var7_27[5] & 255L) << 16 | ((long)var7_27[6] & 255L) << 8 | (long)var7_27[7] & 255L;
                        v21 = 0;
                        break block30;
                        break;
                    }
                    break;
                }
lbl164:
                // 1 sources

                while (true) {
                    v18[v19] = v22;
                    if (var2_26 < var5_25) ** continue;
                    break block31;
                    break;
                }
            }
            var8_28 = v20;
            var10_29 = var0_20.doFinal(new byte[]{(byte)(var8_28 >>> 56), (byte)(var8_28 >>> 48), (byte)(var8_28 >>> 40), (byte)(var8_28 >>> 32), (byte)(var8_28 >>> 24), (byte)(var8_28 >>> 16), (byte)(var8_28 >>> 8), (byte)var8_28});
            v22 = ((long)var10_29[0] & 255L) << 56 | ((long)var10_29[1] & 255L) << 48 | ((long)var10_29[2] & 255L) << 40 | ((long)var10_29[3] & 255L) << 32 | ((long)var10_29[4] & 255L) << 24 | ((long)var10_29[5] & 255L) << 16 | ((long)var10_29[6] & 255L) << 8 | (long)var10_29[7] & 255L;
            switch (v21) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl177:
                // 1 sources

                ** continue;
            }
        }
        AdminHud.mb = var6_22;
        AdminHud.nb = new Long[14];
        AdminHud.o = 15000L;
        AdminHud.p = 30000L;
        AdminHud.n = 90000L;
        AdminHud.D = 350L;
        AdminHud.F = 5000L;
        AdminHud.E = 300L;
    }

    private static r a(r r2) {
        return r2;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static String b(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x51F9;
        if (hb[n3] == null) {
            Object[] objectArray;
            try {
                Long l3 = Thread.currentThread().threadId();
                objectArray = (Object[])ib.get(l3);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    ib.put(l3, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/d/g", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l2 >>> 56);
            for (int i2 = 1; i2 < 8; ++i2) {
                byArray[i2] = (byte)(l2 << i2 * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = db[n3].getBytes("ISO-8859-1");
            AdminHud.hb[n3] = AdminHud.b(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return hb[n3];
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        String string2 = AdminHud.b(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static CallSite b(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/d/g" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x35E7;
        if (kb[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = jb[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])lb.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    lb.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/d/g", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            AdminHud.kb[n3] = n4;
        }
        return kb[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = AdminHud.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/d/g" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static long d(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x5825;
        if (nb[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = mb[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])ob.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    ob.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/d/g", exception);
            }
            long l5 = ((long)byArray[0] & 0xFFL) << 56 | ((long)byArray[1] & 0xFFL) << 48 | ((long)byArray[2] & 0xFFL) << 40 | ((long)byArray[3] & 0xFFL) << 32 | ((long)byArray[4] & 0xFFL) << 24 | ((long)byArray[5] & 0xFFL) << 16 | ((long)byArray[6] & 0xFFL) << 8 | (long)byArray[7] & 0xFFL;
            AdminHud.nb[n3] = l5;
        }
        return nb[n3];
    }

    private static long d(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        long l3 = AdminHud.d(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Long.TYPE, l3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return l3;
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_2().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/d/g" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (sb[n4] != null) {
            return n4;
        }
        Object object = pb[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 14;
            case 1 -> 22;
            case 2 -> 37;
            case 3 -> 59;
            case 4 -> 8;
            case 5 -> 60;
            case 6 -> 17;
            case 7 -> 61;
            case 8 -> 2;
            case 9 -> 56;
            case 10 -> 49;
            case 11 -> 45;
            case 12 -> 21;
            case 13 -> 9;
            case 14 -> 20;
            case 15 -> 24;
            case 16 -> 28;
            case 17 -> 27;
            case 18 -> 44;
            case 19 -> 47;
            case 20 -> 41;
            case 21 -> 34;
            case 22 -> 19;
            case 23 -> 5;
            case 24 -> 54;
            case 25 -> 51;
            case 26 -> 36;
            case 27 -> 40;
            case 28 -> 26;
            case 29 -> 12;
            case 30 -> 30;
            case 31 -> 31;
            case 32 -> 6;
            case 33 -> 43;
            case 34 -> 4;
            case 35 -> 52;
            case 36 -> 50;
            case 37 -> 1;
            case 38 -> 16;
            case 39 -> 53;
            case 40 -> 10;
            case 41 -> 32;
            case 42 -> 57;
            case 43 -> 38;
            case 44 -> 0;
            case 45 -> 23;
            case 46 -> 3;
            case 47 -> 35;
            case 48 -> 11;
            case 49 -> 29;
            case 50 -> 15;
            case 51 -> 46;
            case 52 -> 58;
            case 53 -> 39;
            case 54 -> 7;
            case 55 -> 55;
            case 56 -> 63;
            case 57 -> 42;
            case 58 -> 25;
            case 59 -> 33;
            case 60 -> 48;
            case 61 -> 62;
            case 62 -> 13;
            default -> 18;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        AdminHud.sb[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = pb;
        pb[0] = ")!\u000eyQd !\ry]";
        objectArray[1] = "3)\u001e\u001d;_8&\u000fRQ\\,*\u0004\u0019";
        objectArray[2] = Void.TYPE;
        AdminHud.sb[2] = "java/lang/Void";
        objectArray[3] = "@\u0019Kk?`I\u0019Hk?";
        objectArray[4] = "2_\u001c5\u0006\u00129P\rzg\u001c2[\t ";
        objectArray[5] = "f%.\\<]m%+\\:";
        objectArray[6] = "k\u0016H\u0004l@g\u0016[";
        objectArray[7] = "{('\u0003'\u0018p(,";
        objectArray[8] = ":H2E;*:H%\u00197% \u0003%\u000770'ruZf";
        objectArray[9] = ")v\r\u000e>\u0010\"v\b\u000e=";
        objectArray[10] = Integer.TYPE;
        AdminHud.sb[10] = "java/lang/Integer";
        objectArray[11] = ")\u001b%\u0004lb\\;.\u000b}-=5%\u0000ywI";
        objectArray[12] = Boolean.TYPE;
        AdminHud.sb[12] = "java/lang/Boolean";
        objectArray[13] = "{at)''\u000eA\u007f&6hoOt-22\u001b";
        objectArray[14] = "4XZ\fIS?WKC4K,PB\n";
        objectArray[15] = "W~ :;\f\\~%:.";
        objectArray[16] = "\rZG[&ExzLT7\n\u0019tG_3Pm";
        objectArray[17] = "~z5t[/sz7tY";
        objectArray[18] = Float.TYPE;
        AdminHud.sb[18] = "java/lang/Float";
        objectArray[19] = Long.TYPE;
        AdminHud.sb[19] = "java/lang/Long";
        objectArray[20] = "u\faDutk\u0004{\u000b\u0017hl\u0019";
        objectArray[21] = "+q/c\u0017h^Q$l\u0006'?_/g\u0002}K";
        objectArray[22] = "l\\[i@s\u0019|PfQ<xr[mUf\f";
        objectArray[23] = "*9\u0011jb@_\u0019\u001aes\u000f>\u0017\u0011nwUJ";
        objectArray[24] = "vR9\f*?\u0003r2\u0003;pb|9\b?*\u0016";
        objectArray[25] = "HugK8'=UlD)h\\[gO-2(";
        objectArray[26] = Double.TYPE;
        AdminHud.sb[26] = "java/lang/Double";
        objectArray[27] = "\u001e\"Gl7i\u0000*]#T}\u0004";
        objectArray[28] = "\u0002N:E01wn1J!~\u0016`:A%$b";
        objectArray[29] = "\f\u0018P0Yuy8[?H:\u00186P4L`l";
        objectArray[30] = "1\u001bMU\u0007\u0010D;FZ\u0016_%5MQ\u0012\u0005Q";
        objectArray[31] = "\f;3/.\u000fy\u001b8 ?@\u0018\u00153+;\u001al";
        objectArray[32] = " 1";
        objectArray[33] = "_\u0016c8\u0019\u001aV\u0016`8\u001b";
        objectArray[34] = Short.TYPE;
        AdminHud.sb[34] = "java/lang/Short";
        objectArray[35] = "\u000e\u00074|>I\u0005\u0007<";
        objectArray[36] = "D6sB|<1\u0016xMmsP\u0018sFi)$";
        objectArray[37] = "QjXape@jA";
        objectArray[38] = "0xp\u001f!tEX{\u00100;$Vp\u001b4aP";
        objectArray[39] = "IS]A<1BS^A1";
        objectArray[40] = "\u001c\u0017";
        objectArray[41] = "Vn";
        objectArray[42] = Character.TYPE;
        AdminHud.sb[42] = "java/lang/Character";
        objectArray[43] = Byte.TYPE;
        AdminHud.sb[43] = "java/lang/Byte";
        objectArray[44] = "1\u0011b](nD1iR9!%?bY={Q";
        objectArray[45] = "\u001d$\u000f:|Eh\u0004\u00045m\n\t\n\u000f>iP}";
        objectArray[46] = "\\m\u0010\u0012hS)M\u001b\u001dy\u001cHC\u0010\u0016}F<";
        objectArray[47] = ":jgZV3OJlUG|.Dg^C&Z";
        objectArray[48] = "r\u0013>8\bj\u0007357\u0019%f=><\u001d\u007f\u0012";
        objectArray[49] = "+;rz\u000b2^\u001byu\u001a}?\u0015r~\u001e'K";
        objectArray[50] = "\r2\u001d\u00064yx\u0012\u0016\t%6\u0019\u001c\u001d\u0002!lm";
        objectArray[51] = "I ?c7/<\u00004l&`]\u000e?g\":)";
        objectArray[52] = "\r-Y'o\nx\rR(~E\u0019\u0003Y#z\u001fm";
        objectArray[53] = "\u001d4U<ADh\u0014^3P\u000b\t\u001aU8TQ}";
        objectArray[54] = "`m-3u\u0004\u0015M&<dKtC-7`\u0011\u0000";
        objectArray[55] = "Kh<\u0005!T>H7\n0\u001b_F<\u00014A+";
        objectArray[56] = "\u000fXCY7vV]E\u0019\n&1\b@@p)\b\r\u0014RiL";
        objectArray[57] = "\b4xA:*\u00060?D]=axrE!?\u00018<W;";
        objectArray[58] = "\u0002Sqmu\u001fISp3\f}9T6:i]W\r((";
        objectArray[59] = ";x\tP^SiuK[9MP(\u000fBCGi-[PZ\"6mF\u001dW\u001fikS\u001b9D*f\nN\u0004\u001b,s\f \u0000R3+V[GK-'7";
        objectArray[60] = "Ui\u000f\u0012w!\u001ei\u000eL\u000epn5\u000f\u0016cwUaWE3!n5EJ2x\u0015r\\T>\u0019";
        objectArray[61] = "\fi1k\n<Gi05so751o\u001ej\fai<N<7332\ta\u000e6g \u0010\u0004";
        objectArray[62] = "\u0010!!J\u001ewB,cAyl{\u007fmE\u0005m\u001b?#W\u001f\u0006\u0017~!\u0006Dg\u0011qqYym\u00034{\u0001\u0015k\u0006>q:\u0012~\u0001*$V\u0014{\u000b \u001fQ\u0001|\u001fusW\u0004v\u0015N \u0002\u001b|\u001ew%V\te{woYEg\u00000vGI\u0006";
        objectArray[63] = "q\u0003\u000bry3(\u0006\r2DbOS\bk>lvV\\y'\t";
        objectArray[64] = "q5\u0012,1 :5\u0013rHsJi\u0012(%vq=J{u J;Pm,#&=Ug&\u0018";
        objectArray[65] = "2xN%\u0007xyxO{~\u001b\t\u007f\tr\u001b:g&\u0017`";
        objectArray[66] = "fR+jv\u0015-R*4\u000fD17!5~\u0016\"\u000bv4rC";
        objectArray[67] = "ho?^\u0017'4~o\u0001w\"R-}Y\u000f.1+w\u0019\u000eK";
        objectArray[68] = "\u0015l-hZ$^l,6#@.kj?Ff@2t-";
        objectArray[69] = "c\u001bY=<W(\u001bXcE\u00065~\u0002l;\fg\u0019\u000eax\u000e";
        objectArray[70] = "u3\u0019\u007f>F>3\u0018!G\u0019No\u0019{*\u0010u;A(zFNoS'{\u001f5(J9w~";
        objectArray[71] = "q#*\u0002+i(=8g8\u0007ma?X)}h$)ghwpb'\u001c/nnnF";
        objectArray[72] = "+\u0012#\u0006\u001de%\u0016d\u0003zwB_?\fAd~\b>\u0000\u0014";
        objectArray[73] = "B\u000f%;(1\t\u000f$eQ[y\u000bu~26\u001e\u0007x=0";
        objectArray[74] = "vr3/|9=r2q\u0005h&\u00176,g{(.3xub";
        objectArray[75] = "\u001aP\u001e\u0011\u001b\u0017QP\u001fObF!\f\u001e\u0015\u000fA\u001aXFF_\u0017!\n\u001cH\u0018J\u0018\u000fHZ\u0001/";
        objectArray[76] = "GXlg\b3O\bl7h(>Z43\u0005/\u0005\u000el`Uy>Z~oT E\u001dgqXA";
        objectArray[77] = "_]N}3\u0017\u0014]O#JF\n8\u0015,4L[_\u0019!wN";
        objectArray[78] = "c\u0010\u0012|<\fcMMk\u0004T^\u0015Un~W3DDeb";
        objectArray[79] = "\u007fH\u0012(vU4H\u0013v\u000f\u0007D\u0014\u0012,b\u0003\u007f@J\u007f2UD\u0014Xp3\f?SAn?m";
        objectArray[80] = "M\u0005\u000eq7]O^\u0000)MQT5\\m!]M[\u0005s3";
        objectArray[81] = "t\u0014\u001fZ\b\u001cz\u0010X_o\b\u001dX\u0015^\u0013\t}\u0018[L\t";
        objectArray[82] = "??]{K\u0003t?\\%2R\u0004c]\u007f_U?7\u0005,\u000f\u0003\u00041\u001f:V\u0000h7\u001a0\\;";
        objectArray[83] = "4\u0001P|\u001f\u0001f\f\u0012wx\u0019_\u0015\nhI\u001cg\u000b\u000eu\u0002p$\n\n=\u0014H:\u000e\u0017vx\f0\u001fWi\u001eK?\u001f\u0007\f\u0014@aRSm\u0012O1\rng\u0000\n;U\u0002a\u0005\u00001nQ4\u001a\n:WT`\b\u0013_W\u001eoD\u0011$\u0010\u0007qHp";
        objectArray[84] = "yt.\u0002pi2t/\\\t)B(.\u0006d?y|vU4iB(dZ509o}D9Q";
        objectArray[85] = "cz\u0015}oi(z\u0014#\u0016\bXy\u0013z,lc!T\"g";
        objectArray[86] = "}\u0000Qg<R6\u0000P9E\u0003F\\Qc(\u0004}\b\t0xRFU\u000f-~\u0015z\u0002\u000e!+j";
        objectArray[87] = "\u0006K\u0005@{tMK\u0004\u001e\u0002 =\u0017\u0005Do\"\u0006C]\u0017?t=\u001e[\n93\u0001IZ\u0006lL";
        objectArray[88] = "!s6gK9js792h\u001a/6c_o!{n0\u000f9\u001a'~#Njzg01T\u0001";
        objectArray[89] = ".g|\u001b3Jeg}EJ\u001f\u0015;|\u001f'\u001c.o$LwJ\u0015=~B0\u0017,8*P)r";
        objectArray[90] = "pSAR$3;S@\f]TK[\u0016V%f*[D\f0";
        objectArray[91] = " \u001fH&'Sr\u0012\n-@IK\u001b\u000e,$\u0019'\u001d\u000b&.\"'@Hj}C!O\u00185@I3\n\u0012m,O6\u0000\u0018VyR(L\u0017->K6@v";
        objectArray[92] = "v\u0011:`>$=\u0011;>GBM\u0019md?q,\u0019?>*";
        objectArray[93] = ";r\u0001%5<pr\u0000{Lb\u0000.\u0001!!j;zYrq<\u0000.K}pe{iRc|\u0004";
        objectArray[94] = "\u000fVfm]\"DVg3$J4_lh\u0018'UYc8G";
        objectArray[95] = "la\\X!Y'a]\u0006X\bW=\\\\5\u000fli\u0004\u000feYWe\u0019\n2]0\u007fX\u001d!a";
        objectArray[96] = "s\u0006Nf@ !\u000b\fm'8\u0018VHt]4!S\u001cfDQs\u0011\nr\u001c=u\u0014\u0000x'n \u000b\ns\u001ekt\u0019\u0013\u0016[.{W\u0017vYm!Vp}_+|R\u001c{Z!vi\u001bn]5#\u0005\u001dkW?\u0018\u0002\blCjt\u0004\rfIQs\u0011\nr\u001c=u\u0014\u0000x'n \u000b\ns\u001ekt\u0019\u0013\u0016\u0018iz\u0013\u0015/\u001d=h\np/W2$\b\u000bhN,(i";
        objectArray[97] = "m|V7\u001ew&|Wig#V V3\n!mt\u000e`ZwV&Tn\u001d*o#\u0000|\u0004O";
        objectArray[98] = "\u0016\u0019U\fIw]\u0019TR06-EU\b]!\u0016\u0011\r[\rw-E\u001fT\f.V\u0002\u0006J\u0000O";
        objectArray[99] = "\u001b\u0007\u0007|h1\u0015\u0003@y\u000f\"r\u0016O93r\u0013\u0010@il";
        objectArray[100] = "\u0010P\b\u0019\u0013\f[P\tGj]+\f\b\u001d\u0007Z\u0010XPNW\f+\\OZ\u0011SURK\u001d\u00144";
        objectArray[101] = "*Fak%\u0013xK#`B\u000bAB'a&Y-D\"k,b-\u0019a'\u007f\u0003+\u00161xB[1Jcz9\u001c(To\u001b";
        objectArray[102] = "{\bDh:\u000e)\u0005\u0006c]\u0016\u0010\f\u0002b9D|\n\u0007h3\u007fv\u001d\u000b%3B)\u001b\u001e#]\u0014h\u001d\u001e#1\u0012m\u0017\u0014\u00186\u0007j\u0003At0\u0002`\tzd2\u000e)\u0002\u001c#=\u000eygE ?\u0005u^@t-\u001c\u0010\f\u0002b9D|\n\u0007h3\u007f{\u001f\u0000|f\u0013}\u001a\nv]\u0014h\u001d\u001e#1\u0012m\u0017\u0014\u0018bGr\u001d\u001f!g\u0013`\u0004z!-\u001c,\u0006\u0001f4\u0002 g";
        objectArray[103] = "S\u00127@\u001ft\u0018\u00126\u001ef\"hN7D\u000b\"S\u001ao\u0017[thH5\u0019\u001c)QMa\u000b\u0005L";
        objectArray[104] = "\u0003\tg \b\u0006H\tf~qW8P:{\u000fGZV3|\f>\u0004\u000b=e\b\\\u0002\u0002:fq";
        objectArray[105] = "\u0002:\u001a\u0011\u0003BI:\u001bOz\u00149f\u001a\u0015\u0017\u0014\u00022BFGB9fPIF\u001bB!IWJz";
        objectArray[106] = ")\u001d\u0004vF\u0015b\u001d\u0005(?A\u0012A\u0004rRC)\u0015\\!\u0002\u0015\u0012AN.\u0003Li\u0006W0\u000f-";
        objectArray[107] = "J#(i7u\u0018.jbPm!}df,oA=*t6\u0004J4l}khL1fwPh\u0011r*$1n\u001e\"u\u0019;|[(-u=yQ\"\u0016";
        objectArray[108] = "D*5_\u001c3\u0016'wT{+/#q^F,\u0012|wK@B\u0010}iU\u001e{\u0015){L{}\u0017'qJBxC5h/DzM?n\u0016A._&\u000b\u0016\u000b!\u0013$pQ\u0012?\u001fE";
        objectArray[109] = "qA\t\u0000/h:A\b^V5J\u001d\t\u0004;>qIQWkhJ\u001dCXj11ZZFfP";
        objectArray[110] = "Y=\u001c-\u001b\u0019\u000b0^&|\u00062>\u0012c@US8\u001d3\u001fh\u000b\"Aa\u001d\u0013L;_m|";
        objectArray[111] = "*G6n\u000b(aG70r{\u0011\u001b6j\u001f~*On9O(\u0011\u001b|6Nqj\\e(B\u0010";
        objectArray[112] = "\u0019T\u0012I7$RT\u0013\u0017NM\"]\u0018Lr!C[\u0017\u001c-";
        objectArray[113] = "\t=:u@bB=;+9\u00022><r\u0003g\tf{*H";
        objectArray[114] = "&\u000e\u007fdxAm\u000e~:\u0001>\u001d\ryc;D&U>;p";
        objectArray[115] = "\u001eh9\u000f-ILe{\u0004JSu6u\u00006S\u0015v;\u0012,8\u001e\u007f}\u001bqT\u0018zw\u0011JS\r}cD&U\bwi\u007f&\bK;:\u001e \u0007\u001bd\u0007\u00142B\u0011<k\u00127H\u001b\u00078G(B\u0010>=\u0013:[u>w\u001cvY\u000eyn\u0002z8";
        objectArray[116] = "?=?>=\ft=>`D^\u0004a?:)Z?5giy\f\u00043}\u007f \u000fh5xu*4";
        objectArray[117] = "jZ\fH9F!Z\r\u0016@#Q^I\u001a*B6D\b\r9";
        objectArray[118] = "cvML \u0000(vL\u0012YBX*MH4Vc~\u0015\u001bd\u0000X*\u0007\u0014eY#m\u001e\ni8";
        objectArray[119] = "\u001dq]Z\u0007u\u000b.\u000e\fn_7Mo|4\u0004\u001dq]Z\u0007u\u000b.\u000e\f";
        objectArray[120] = "-+\u000e$&\u001d#/I!A\bDf\u0012.z\u001cx1\u0013\"/";
        objectArray[121] = "!\u0016Um\u0012Zj\u0016T3k\u000bus\n/\n\f~K_=\u000f\\";
        objectArray[122] = "?\u0015n\u0004+5m\u0018,\u000fL-T\u0011(\u000e(\u007f8\u0017-\u0004\"D?\u0002*\u0010w(9\u0007 \u001aL/,\u00004O ))\n>t'<.\u001ek\u0018!9$\u0014P\u001f4>0A<\u001914:zoL.>1Cj\u0018<'T\u0016`Jpy5\u0010o\u001a/Dm\n3H-?*\u0013-DL";
        objectArray[123] = "{\u0017u|c?0\u0017t\"\u001an)r\u007f#k<?N(\"gi";
        objectArray[124] = "x\u000eY\u00051|xS\u0006\u0012\t)E\u000f^Jd#~[\u0006\u00194uE\u000f\u0014\u00165,>H\r\b9M";
        Object[] objectArray2 = objectArray;
        objectArray[125] = "Vi,\u000e\"\u000e\u001di-P[_\u0007\f&Q*\r\u00120qP&X";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = AdminHud.e(l2, l3);
            object = pb[n2];
            try {
                if (!(object instanceof String)) break block2;
                AdminHud.pb[n2] = clazz = Class.forName(sb[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = AdminHud.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = AdminHud.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = AdminHud.e(l2, l3);
        Object object = pb[n2];
        if (object instanceof String) {
            String string = sb[n2];
            int n3 = string.indexOf(8);
            Class clazz = AdminHud.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = AdminHud.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = AdminHud.c(clazz3, string2, clazz2)) != null) {
                    AdminHud.pb[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = AdminHud.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        AdminHud.pb[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = AdminHud.f(302384728709126L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = AdminHud.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = AdminHud.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = AdminHud.e(l2, l3);
        Object object = pb[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = sb[n2];
                int n4 = string2.indexOf(8);
                clazz3 = AdminHud.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = AdminHud.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = AdminHud.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        AdminHud.pb[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = AdminHud.f(302384728709126L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = AdminHud.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        AdminHud.pb[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = AdminHud.f(302384728709126L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == '\u00f0' || c2 == 'w' || c2 == '\u00d1' || c2 == 't') {
                field = AdminHud.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == '\u00f0' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == 'w' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == '\u00d1' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = AdminHud.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == 'R' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == 'a' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = AdminHud.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite f(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_3().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/d/g" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(AdminHud.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(AdminHud.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_2() {
        try {
            return MethodHandles.lookup().findStatic(AdminHud.class, "d", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_3() {
        try {
            return MethodHandles.lookup().findStatic(AdminHud.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

