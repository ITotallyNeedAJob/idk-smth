// === Kuzi module: FakePlayer ===
// Category   : SERVER
// Description: Spawns fake players for testing ESP and other visual modules
// Payload    : a.a.a.j.e.N (verified: True)

package kuzi.modules.server;

import com.mojang.authlib.GameProfile;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.b.v;
import kuzi.obf.j.e.am;
import kuzi.obf.m.r;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import kuzi.settings.StringSetting;
import net.minecraft.Entity;
import net.minecraft.Minecraft;
import net.minecraft.RemotePlayer;

public class FakePlayer
extends BaseModule {
    public final SliderSetting maxPlayers;
    public final SliderSetting spawnDistance;
    public final StringSetting playerName;
    public final BoolSetting copyRotation;
    public final BoolSetting copyPose;
    private final List spawnedPlayers;
    private final Minecraft minecraft;
    private final String[] directions;
    private int directionIndex;
    private static final long v;
    private static final String[] w;
    private static final String[] x;
    private static final Map y;
    private static final Object[] z;
    private static final String[] A;

    public FakePlayer() {
        long l2 = v ^ 0x6CC0C5B964B9L;
        long l3 = l2 ^ 0x55CBE85407D0L;
        super("FakePlayer", "Spawns fake players for testing ESP and other visual modules", Category.SERVER);
        this.maxPlayers = new SliderSetting("Max Players", 5.0, 1.0, 20.0, 1.0);
        this.spawnDistance = new SliderSetting("Spawn Distance", 3.0, 1.0, 10.0, 0.5);
        this.playerName = new StringSetting("Player Name", "Steve");
        this.copyRotation = new BoolSetting("Copy Rotation", true);
        this.copyPose = new BoolSetting("Copy Pose", true);
        this.spawnedPlayers = new ArrayList();
        this.minecraft = Minecraft.getInstance();
        this.directions = new String[]{"Front", "Behind", "Left", "Right", "Above"};
        this.directionIndex = 0;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.maxPlayers, this.spawnDistance, this.playerName, this.copyRotation, this.copyPose};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        FakePlayer fakePlayer;
        long l2;
        block4: {
            block5: {
                FakePlayer fakePlayer2;
                block2: {
                    block3: {
                        long l3 = v ^ 0x73659AE65FB1L;
                        l2 = l3 ^ 0x3E0EA8458E47L;
                        String string = am.b();
                        fakePlayer2 = this;
                        if (string == null) break block2;
                        if (fakePlayer2.minecraft.player == null) break block3;
                        fakePlayer = this;
                        if (string == null) break block4;
                        if (fakePlayer.minecraft.level != null) break block5;
                    }
                    fakePlayer2 = this;
                }
                fakePlayer2.j();
                return;
            }
            fakePlayer = this;
        }
        Object[] objectArray = new Object[1];
        objectArray[0] = l2;
        fakePlayer.b(objectArray);
    }

    @Override
    public void e() {
        long l2 = v ^ 0x661983073F9FL;
        long l3 = l2 ^ 0x71F59A4D76F4L;
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.c(objectArray);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public void a(Object[] objectArray) {
        FakePlayer fakePlayer;
        long l2;
        long l3;
        block10: {
            CallSite callSite;
            block9: {
                l3 = (Long)objectArray[0];
                l2 = (l3 = v ^ l3) ^ 0x1D06A0E20E7BL;
                CallSite callSite2 = FakePlayer.c("\u00df", (long)3360046511307252869L, (long)l3);
                try {
                    try {
                        try {
                            callSite = FakePlayer.c("u", (Object)this, (long)3360772578527265562L, (long)l3);
                            if (callSite2 == null) break block9;
                            if (((Minecraft)callSite).player == null) return;
                        }
                        catch (r r2) {
                            throw FakePlayer.c("\u00df", (Object)r2, (long)3360642795865293357L, (long)l3);
                        }
                        if (l3 < 0L) return;
                        fakePlayer = this;
                        if (callSite2 == null) break block10;
                    }
                    catch (r r3) {
                        throw FakePlayer.c("\u00df", (Object)r3, (long)3360642795865293357L, (long)l3);
                    }
                    callSite = FakePlayer.c("u", (Object)fakePlayer, (long)3360772578527265562L, (long)l3);
                }
                catch (r r4) {
                    throw FakePlayer.c("\u00df", (Object)r4, (long)3360642795865293357L, (long)l3);
                }
            }
            try {
                if (((Minecraft)callSite).level == null) {
                    return;
                }
            }
            catch (r r5) {
                throw FakePlayer.c("\u00df", (Object)r5, (long)3360642795865293357L, (long)l3);
            }
            fakePlayer = this;
        }
        FakePlayer.c("u", (Object)fakePlayer, (long)3363304428089841596L, (long)l3).removeIf(arg_0 -> this.lambda$onUpdate$0(l2, arg_0));
    }

    public void b(Object[] objectArray) {
        String string;
        double d2;
        double d3;
        double d4;
        String string2;
        long l2;
        block37: {
            Object object;
            block35: {
                block36: {
                    String string3;
                    block34: {
                        Object object2;
                        block24: {
                            block25: {
                                boolean bl;
                                double d5;
                                block32: {
                                    String string4;
                                    block33: {
                                        String string5;
                                        double d6;
                                        double d7;
                                        block29: {
                                            block30: {
                                                block31: {
                                                    block26: {
                                                        block27: {
                                                            block28: {
                                                                block21: {
                                                                    block22: {
                                                                        block23: {
                                                                            FakePlayer fakePlayer;
                                                                            block19: {
                                                                                block20: {
                                                                                    block18: {
                                                                                        Minecraft mc;
                                                                                        block17: {
                                                                                            l2 = (Long)objectArray[0];
                                                                                            l2 = v ^ l2;
                                                                                            string2 = am.b();
                                                                                            mc = this.minecraft;
                                                                                            if (string2 == null) break block17;
                                                                                            if (mc.player == null) break block18;
                                                                                            fakePlayer = this;
                                                                                            if (l2 < 0L || string2 == null) break block19;
                                                                                            mc = fakePlayer.minecraft;
                                                                                        }
                                                                                        if (mc.level != null) break block20;
                                                                                    }
                                                                                    return;
                                                                                }
                                                                                fakePlayer = this;
                                                                            }
                                                                            Object object3 = fakePlayer.spawnedPlayers;
                                                                            if (string2 != null) {
                                                                                if (object3.size() >= ((Double)this.maxPlayers.a()).intValue()) {
                                                                                    return;
                                                                                }
                                                                                object3 = this.spawnDistance.a();
                                                                            }
                                                                            d5 = (Double)object3;
                                                                            d4 = this.minecraft.player.getX();
                                                                            d3 = this.minecraft.player.getY();
                                                                            d2 = this.minecraft.player.getZ();
                                                                            float f2 = this.minecraft.player.getYRot();
                                                                            double d8 = Math.toRadians(f2);
                                                                            d7 = Math.sin(d8);
                                                                            d6 = Math.cos(d8);
                                                                            string4 = this.directions[this.directionIndex];
                                                                            this.directionIndex = (this.directionIndex + 1) % this.directions.length;
                                                                            bl = string4.equals(FakePlayer.b("d", (int)31370, (long)(0x48294C0397D7F9B0L ^ l2)));
                                                                            string5 = string2;
                                                                            if (l2 < 0L) break block21;
                                                                            if (string5 == null) break block22;
                                                                            if (!bl) break block23;
                                                                            d4 += -d7 * d5;
                                                                            d2 += d6 * d5;
                                                                            object2 = string2;
                                                                            if (l2 <= 0L) break block24;
                                                                            if (object2 != null) break block25;
                                                                        }
                                                                        bl = string4.equals(FakePlayer.b("d", (int)14647, (long)(0x4ED1A7BAFC9EBA07L ^ l2)));
                                                                    }
                                                                    string5 = string2;
                                                                }
                                                                if (l2 <= 0L) break block26;
                                                                if (string5 == null) break block27;
                                                                if (!bl) break block28;
                                                                d4 += d7 * d5;
                                                                d2 += -d6 * d5;
                                                                object2 = string2;
                                                                if (l2 < 0L) break block24;
                                                                if (object2 != null) break block25;
                                                            }
                                                            bl = string4.equals(FakePlayer.b("d", (int)25646, (long)(0x396276D197B2E710L ^ l2)));
                                                        }
                                                        string5 = string2;
                                                    }
                                                    if (l2 < 0L) break block29;
                                                    if (string5 == null) break block30;
                                                    if (!bl) break block31;
                                                    d4 += d6 * d5;
                                                    d2 += d7 * d5;
                                                    object2 = string2;
                                                    if (l2 < 0L) break block24;
                                                    if (object2 != null) break block25;
                                                }
                                                bl = string4.equals(FakePlayer.b("d", (int)19344, (long)(0x40281CA69046C8A1L ^ l2)));
                                            }
                                            string5 = string2;
                                        }
                                        if (string5 == null) break block32;
                                        if (!bl) break block33;
                                        d4 += -d6 * d5;
                                        d2 += -d7 * d5;
                                        object2 = string2;
                                        if (l2 < 0L) break block24;
                                        if (object2 != null) break block25;
                                    }
                                    string3 = string4;
                                    if (string2 == null) break block34;
                                    bl = string3.equals(FakePlayer.b("d", (int)16950, (long)(0x39D12F3CCB17C102L ^ l2)));
                                }
                                if (bl) {
                                    d3 += d5;
                                }
                            }
                            object2 = this.playerName.a();
                        }
                        string3 = (String)object2;
                    }
                    string = string3;
                    object = string;
                    if (string2 == null) break block35;
                    if (object == null) break block36;
                    object = string.trim();
                    if (string2 == null) break block35;
                    if (!((String)object).isEmpty()) break block37;
                }
                object = FakePlayer.b("d", (int)30949, (long)(0x6E1A998A6EF4FBD0L ^ l2));
            }
            string = object;
        }
        GameProfile gameProfile = new GameProfile(UUID.randomUUID(), string);
        RemotePlayer fakePlayerEntity = new RemotePlayer(this.minecraft.level, gameProfile);
        fakePlayerEntity.snapTo(d4, d3, d2, 0.0f, 0.0f);
        fakePlayerEntity.setDeltaMovement(0.0, 0.0, 0.0);
        boolean bl = (Boolean)this.copyRotation.a();
        String string6 = string2;
        if (l2 > 0L) {
            if (string6 != null) {
                if (bl) {
                    float f3 = this.minecraft.player.getYRot();
                    float f4 = this.minecraft.player.getXRot();
                    fakePlayerEntity.setYRot(f3);
                    fakePlayerEntity.setXRot(f4);
                    fakePlayerEntity.yHeadRot = this.minecraft.player.yHeadRot;
                    fakePlayerEntity.yBodyRot = this.minecraft.player.yBodyRot;
                }
                bl = (Boolean)this.copyPose.a();
            }
            string6 = string2;
        }
        if (string6 != null) {
            if (bl) {
                fakePlayerEntity.setPose(this.minecraft.player.getPose());
            }
            fakePlayerEntity.setHealth(20.0f);
            fakePlayerEntity.getInventory().replaceWith(this.minecraft.player.getInventory());
            fakePlayerEntity.setInvisible(false);
            fakePlayerEntity.noPhysics = false;
            this.minecraft.level.addEntity((Entity)fakePlayerEntity);
            bl = this.spawnedPlayers.add(fakePlayerEntity);
        }
    }

    public void c(Object[] objectArray) {
        block4: {
            long l2 = (Long)objectArray[0];
            l2 = v ^ l2;
            String string = am.b();
            if (this.minecraft.level == null) {
                return;
            }
            block0: for (RemotePlayer fakePlayerEntity : new ArrayList(this.spawnedPlayers)) {
                this.minecraft.level.removeEntity(fakePlayerEntity.getId(), Entity.mc5529.DISCARDED);
                do {
                    String string2 = string;
                    if (l2 > 0L) {
                        if (string2 == null) break block4;
                        string2 = string;
                    }
                    if (string2 != null) continue block0;
                } while (l2 <= 0L);
            }
            this.spawnedPlayers.clear();
        }
    }

    private boolean lambda$onUpdate$0(long l2, RemotePlayer fakePlayerEntity) {
        boolean bl;
        l2 = v ^ l2;
        try {
            bl = ((Minecraft)FakePlayer.c("u", (Object)this, (long)-2835903047311346403L, (long)l2)).level.getEntity(fakePlayerEntity.getId()) == null;
        }
        catch (r r2) {
            throw FakePlayer.c("\u00df", (Object)r2, (long)-2836032739764587478L, (long)l2);
        }
        return bl;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block11: {
            block10: {
                FakePlayer.v = kuzi.obf.h.b.v.a(-5773604387595675130L, 8521427797909841233L, MethodHandles.lookup().lookupClass()).a(34894908706244L);
                FakePlayer.z = new Object[36];
                FakePlayer.A = new String[36];
                FakePlayer.c();
                FakePlayer.y = new HashMap<K, V>(13);
                var0 = FakePlayer.v ^ 51269104066765L;
                var2_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                v0 = SecretKeyFactory.getInstance("DES");
                v1 = new byte[8];
                v2 = v1;
                v1[0] = (byte)(var0 >>> 56);
                for (var3_2 = 1; var3_2 < 8; ++var3_2) {
                    v2 = v2;
                    v2[var3_2] = (byte)(var0 << var3_2 * 8 >>> 56);
                }
                var2_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                var9_3 = new String[19];
                var7_4 = 0;
                var6_5 = "f\u00e0s\u001f\t\u0013c%=\u000b\u00bb\u00d0\u00a31F\u00db\u0014\u0018\u00d2\u00ec\u0088\u0084\u00db\u00ff=\u00d1\u00f8\u00f3rh\u00a6<\u00e6\u0085)\u0084-WL\u0094t+\u00f8/\u00f9uO\u00bb\u00a9A\n\u00df\u00e8U9\u00e5@\u001eF\u00cd\u00af\u00e6\u00c8F\u00ffb\u00de\u0013}k\u0011\u0015\u009d\u00ec\u00c8\u00de\u00deg\u00c4\u009b\u0090\tX\u001c\u00cel\u0012\u00de\u00be\u00fb\u00fegG/\u001a\u00c2\u001d\u00e45N\u00fe\u0084\u00bb5 \u00be\u0097\tF\u0018\u00b3\u00c1\u00cd\u00c0\u0005\u00ae\u001c()P\u00e6\u00e4\u00af\u0000@I!\u008a\u00abma\u00b9\u00ca\u00c0\u00be\u009eb\u0010\t\u00c3\u008f`b\u00e7\u00ed@\u0002\u00d0\u0099\u00c7\u00dc\u0097\u00ff\u00b2\u0010\u0080\u0083\u0083\u0000\u00c9\u001f\u00ac\u00c8=\u00e08\u008f?\u00f9\u0088'\u0010<3\u00ba\u00fb\u0012!B\"\u00f5\u00d6\u00d7L\u00a7\u009e\u00bd\" E\u0082v!\u009a\u0012\u00f1u%\u00ddyJO\u00f8N\"\u0094\u00e4\u0019\u00f7\u00b4`\u00d5\u00a4\u00b4\u0017\u00d9\u00ecd\u00ddG~\u0010T\u0016\u0098\u00a9\u0089\u00b46!\u00f2\u00af\u00a0\u008c\u00b9\u008f\u00e6d\u0010\f|Y\u000f5:h\u00cd\u007f\u00af\u0010\u0012\u00b1\u00e0\u00e2w\u0010\u00b7\u00ba?\u00de\u00d0x\u00b8\u000f\u00d7\u00de\u00b6\u00c9\u0014\u00a6\u00fcY\u0010\u00f0\u007fq\u00a1\u0082?\u0001\u00d9)\u00d0Px\u00b2\u00f3\u00e33\u0018\u001b\"8\u00d7\u00f0\u00c2O\u00d9\u00c1\u00c0\u009f\u0085\u00f6\u00dc\u0095\u00fbo\u0004\u00a7\u00de\u000fF\u0090/\u0010\u00c1\u00e5\u0007\u00c8\u00e6DL\u009dT\u00d3h\u00007\u0083\u00ef\u00f0\u0010\u0011\u0015Z\u00c2KXL\u00a7\u00ed\u0007\u0088WB\u0087\u0096:\u0010#\u00ab\u00e0\u00b7\u00c4\u0097\u00b1\u00ca@\u0085\u00bf}T\u00ad\u00c7\u001f\u0010U\u00bc0\u00b7\u00da\\hx\u0004\u001c\u00c0\u00c0,\u00fcW\u00da \\\u00ed\u00b6}X\u00d3\u00d6l:\u00b2\u00a8\u00fa\u0089x\u00acmNc\u009a|\u00c9R\u00b3\u00af\u00fb\u00d6:\u00efG\u008b\u00d2\u001c \u00a5y\u001dn\u00b8\u000b\u001f\b\u00de\u00ce\u0016\u00f3Li\u0085\u001e\u00c9\u0001\u001c\u009dxdps\u001aH\u000b\u009d\u0010R\u00d8\u00c0";
                var8_6 = "f\u00e0s\u001f\t\u0013c%=\u000b\u00bb\u00d0\u00a31F\u00db\u0014\u0018\u00d2\u00ec\u0088\u0084\u00db\u00ff=\u00d1\u00f8\u00f3rh\u00a6<\u00e6\u0085)\u0084-WL\u0094t+\u00f8/\u00f9uO\u00bb\u00a9A\n\u00df\u00e8U9\u00e5@\u001eF\u00cd\u00af\u00e6\u00c8F\u00ffb\u00de\u0013}k\u0011\u0015\u009d\u00ec\u00c8\u00de\u00deg\u00c4\u009b\u0090\tX\u001c\u00cel\u0012\u00de\u00be\u00fb\u00fegG/\u001a\u00c2\u001d\u00e45N\u00fe\u0084\u00bb5 \u00be\u0097\tF\u0018\u00b3\u00c1\u00cd\u00c0\u0005\u00ae\u001c()P\u00e6\u00e4\u00af\u0000@I!\u008a\u00abma\u00b9\u00ca\u00c0\u00be\u009eb\u0010\t\u00c3\u008f`b\u00e7\u00ed@\u0002\u00d0\u0099\u00c7\u00dc\u0097\u00ff\u00b2\u0010\u0080\u0083\u0083\u0000\u00c9\u001f\u00ac\u00c8=\u00e08\u008f?\u00f9\u0088'\u0010<3\u00ba\u00fb\u0012!B\"\u00f5\u00d6\u00d7L\u00a7\u009e\u00bd\" E\u0082v!\u009a\u0012\u00f1u%\u00ddyJO\u00f8N\"\u0094\u00e4\u0019\u00f7\u00b4`\u00d5\u00a4\u00b4\u0017\u00d9\u00ecd\u00ddG~\u0010T\u0016\u0098\u00a9\u0089\u00b46!\u00f2\u00af\u00a0\u008c\u00b9\u008f\u00e6d\u0010\f|Y\u000f5:h\u00cd\u007f\u00af\u0010\u0012\u00b1\u00e0\u00e2w\u0010\u00b7\u00ba?\u00de\u00d0x\u00b8\u000f\u00d7\u00de\u00b6\u00c9\u0014\u00a6\u00fcY\u0010\u00f0\u007fq\u00a1\u0082?\u0001\u00d9)\u00d0Px\u00b2\u00f3\u00e33\u0018\u001b\"8\u00d7\u00f0\u00c2O\u00d9\u00c1\u00c0\u009f\u0085\u00f6\u00dc\u0095\u00fbo\u0004\u00a7\u00de\u000fF\u0090/\u0010\u00c1\u00e5\u0007\u00c8\u00e6DL\u009dT\u00d3h\u00007\u0083\u00ef\u00f0\u0010\u0011\u0015Z\u00c2KXL\u00a7\u00ed\u0007\u0088WB\u0087\u0096:\u0010#\u00ab\u00e0\u00b7\u00c4\u0097\u00b1\u00ca@\u0085\u00bf}T\u00ad\u00c7\u001f\u0010U\u00bc0\u00b7\u00da\\hx\u0004\u001c\u00c0\u00c0,\u00fcW\u00da \\\u00ed\u00b6}X\u00d3\u00d6l:\u00b2\u00a8\u00fa\u0089x\u00acmNc\u009a|\u00c9R\u00b3\u00af\u00fb\u00d6:\u00efG\u008b\u00d2\u001c \u00a5y\u001dn\u00b8\u000b\u001f\b\u00de\u00ce\u0016\u00f3Li\u0085\u001e\u00c9\u0001\u001c\u009dxdps\u001aH\u000b\u009d\u0010R\u00d8\u00c0".length();
                var5_7 = 104;
                var4_8 = -1;
lbl23:
                // 2 sources

                while (true) {
                    v3 = ++var4_8;
                    v4 = var6_5.substring(v3, v3 + var5_7);
                    v5 = -1;
                    break block10;
                    break;
                }
lbl28:
                // 1 sources

                while (true) {
                    var9_3[var7_4++] = FakePlayer.b(var10_9).intern();
                    if ((var4_8 += var5_7) < var8_6) {
                        var5_7 = var6_5.charAt(var4_8);
                        ** continue;
                    }
                    var6_5 = "\u00b7f\f\u00a4\u00d6\u00d03A6>\u00f5\u00f8\u00a4P\u00ea$\u0018\u0081\u00c7~!\u00bc\u00e6\u00a0@e\u0096\u00f3\u00fb\u00b6n\u00b6\u00ac+WdD3\u008f\u0080'";
                    var8_6 = "\u00b7f\f\u00a4\u00d6\u00d03A6>\u00f5\u00f8\u00a4P\u00ea$\u0018\u0081\u00c7~!\u00bc\u00e6\u00a0@e\u0096\u00f3\u00fb\u00b6n\u00b6\u00ac+WdD3\u008f\u0080'".length();
                    var5_7 = 16;
                    var4_8 = -1;
lbl37:
                    // 2 sources

                    while (true) {
                        v6 = ++var4_8;
                        v4 = var6_5.substring(v6, v6 + var5_7);
                        v5 = 0;
                        break block10;
                        break;
                    }
                    break;
                }
lbl42:
                // 1 sources

                while (true) {
                    var9_3[var7_4++] = FakePlayer.b(var10_9).intern();
                    if ((var4_8 += var5_7) < var8_6) {
                        var5_7 = var6_5.charAt(var4_8);
                        ** continue;
                    }
                    break block11;
                    break;
                }
            }
            var10_9 = var2_1.doFinal(v4.getBytes("ISO-8859-1"));
            switch (v5) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl54:
                // 1 sources

                ** continue;
            }
        }
        FakePlayer.w = var9_3;
        FakePlayer.x = new String[19];
    }

    private static r a(r r2) {
        return r2;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static String b(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x52CB;
        if (x[n3] == null) {
            Object[] objectArray;
            try {
                Long l3 = Thread.currentThread().threadId();
                objectArray = (Object[])y.get(l3);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    y.put(l3, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/e/N", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l2 >>> 56);
            for (int i2 = 1; i2 < 8; ++i2) {
                byArray[i2] = (byte)(l2 << i2 * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = w[n3].getBytes("ISO-8859-1");
            FakePlayer.x[n3] = FakePlayer.b(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return x[n3];
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        String string2 = FakePlayer.b(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static CallSite b(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/e/N" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (A[n4] != null) {
            return n4;
        }
        Object object = z[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 22;
            case 1 -> 61;
            case 2 -> 18;
            case 3 -> 29;
            case 4 -> 9;
            case 5 -> 16;
            case 6 -> 46;
            case 7 -> 32;
            case 8 -> 38;
            case 9 -> 30;
            case 10 -> 54;
            case 11 -> 44;
            case 12 -> 39;
            case 13 -> 0;
            case 14 -> 24;
            case 15 -> 36;
            case 16 -> 55;
            case 17 -> 51;
            case 18 -> 27;
            case 19 -> 28;
            case 20 -> 37;
            case 21 -> 53;
            case 22 -> 15;
            case 23 -> 40;
            case 24 -> 45;
            case 25 -> 19;
            case 26 -> 47;
            case 27 -> 60;
            case 28 -> 50;
            case 29 -> 62;
            case 30 -> 52;
            case 31 -> 43;
            case 32 -> 25;
            case 33 -> 26;
            case 34 -> 20;
            case 35 -> 42;
            case 36 -> 13;
            case 37 -> 5;
            case 38 -> 34;
            case 39 -> 1;
            case 40 -> 31;
            case 41 -> 56;
            case 42 -> 7;
            case 43 -> 59;
            case 44 -> 23;
            case 45 -> 6;
            case 46 -> 17;
            case 47 -> 10;
            case 48 -> 48;
            case 49 -> 33;
            case 50 -> 8;
            case 51 -> 2;
            case 52 -> 58;
            case 53 -> 14;
            case 54 -> 21;
            case 55 -> 12;
            case 56 -> 35;
            case 57 -> 63;
            case 58 -> 3;
            case 59 -> 49;
            case 60 -> 11;
            case 61 -> 4;
            case 62 -> 57;
            default -> 41;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        FakePlayer.A[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = z;
        z[0] = "\u001f\u0013\u0017HZ\u001b\u0014\u0013\u0013HZX";
        objectArray[1] = "k\u0004\u001bzYx`\u000b\n5$`s\f\u0003|";
        objectArray[2] = "s3^Si)x3ZSF";
        objectArray[3] = "QA>|DG$a5sU\bEo>xQR1";
        objectArray[4] = Void.TYPE;
        FakePlayer.A[4] = "java/lang/Void";
        objectArray[5] = "\u0019Fk\\4)\u0012F`";
        objectArray[6] = "<eSI\nm0e@";
        objectArray[7] = "\u001d~d\u0017@~\u001d~sKLq\u00075sULd\u0000D#\b\u001d";
        objectArray[8] = "lbSq@u\u0019BX~Q:xLSuU`\f";
        objectArray[9] = "t$\u0010Q\u0000'j,\n\u001eb;m1";
        objectArray[10] = "|(>\u0019O\u0003u(=\u0019C";
        objectArray[11] = "t\u001dZ,uI}\u001dY,w";
        objectArray[12] = "Jxj)Q<Cxi)C";
        objectArray[13] = "7zM\u0000@\b<zE";
        objectArray[14] = Integer.TYPE;
        FakePlayer.A[14] = "java/lang/Integer";
        objectArray[15] = "ky4eP\f\u001eY?jAC\u007fW4aE\u0019\u000b";
        objectArray[16] = "uz\u0011]o^\u0000Z\u001aR~\u0011}B\tUwX\u0015";
        objectArray[17] = "\"x@J&O+xCJ&";
        objectArray[18] = "\u0010V\u0014DZq\u001bY\u0005\u000b;\u007f\u0010R\u0001Q";
        objectArray[19] = "mhb!y6067/D?T5e9:4h3:`?";
        objectArray[20] = "L\n9\u0011c-\u0011Tl\u001f^=u\u00025\u0012:&\t\u0019;\u00017";
        objectArray[21] = "b-1\u0013\u0000Oh)2.\u000b~?:u\u0013\u0013\u0003y5y\u0015a";
        objectArray[22] = "8Q?+eje\u000fj%Xl\u0001Yl0\"7\u007fJ371\u0006:\f;,b:cC)nX";
        objectArray[23] = "%18#\b s84~j.\u001ejn-\u0013v\"3!?QL";
        objectArray[24] = "\u001f(hAxVBv=OEC&u|[;\n\u001d&\u007f\u00065";
        objectArray[25] = "#S~\u0000+L~\r+\u000e\u0016F\u001a\u000ey\u0018hN&\b&Am";
        objectArray[26] = "Oo\u0017>,o\u00121B0\u0011{v2\u0003$o3Ma\u0000ya";
        objectArray[27] = "hWK[R\r5\t\u001eUo\u0006Q\u0005Y\u001e\u0000\u000e1YZE\f";
        objectArray[28] = "\r3:9\u0005{Pmo78|4;i\"B&J(6%Q\u0017\u000fn>>\u0002+V!,|8";
        objectArray[29] = "v#Jh\u0001\u0000+}\u001ff<\u0005O}Co\u0001\u001dp#Rh\fls!Z+MS-0]&<";
        objectArray[30] = "}.n\u001cDl|ojZ<\\\u0001HJ*f\u0007}.n\u001cDl|ojZ";
        objectArray[31] = "\u001b'9Zm_FylTPH\"y/I/\u0002K$=Hl";
        objectArray[32] = "@~z\u000bo[I!-\u001dW\b++*A>\u000eHy+\b)a";
        objectArray[33] = "F1f\u0019\u0006y\u001bo3\u0017;h\u007fb\u007f\u0015^,\u000e<c\u001bW";
        objectArray[34] = "\u0004\\\b6\u0006\u0013RU\u0004kd\u001b?V[0\u001eNAE\u00047\r\u007f\u0004\u0003\f,^C]L\u001end";
        Object[] objectArray2 = objectArray;
        objectArray[35] = "'\u000f85t\u0003zQm;I\u0015\u001eS1!t\u001ey\u001di-#";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = FakePlayer.e(l2, l3);
            object = z[n2];
            try {
                if (!(object instanceof String)) break block2;
                FakePlayer.z[n2] = clazz = Class.forName(A[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = FakePlayer.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = FakePlayer.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = FakePlayer.e(l2, l3);
        Object object = z[n2];
        if (object instanceof String) {
            String string = A[n2];
            int n3 = string.indexOf(8);
            Class clazz = FakePlayer.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = FakePlayer.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = FakePlayer.c(clazz3, string2, clazz2)) != null) {
                    FakePlayer.z[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = FakePlayer.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        FakePlayer.z[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = FakePlayer.f(1323828593229091L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = FakePlayer.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = FakePlayer.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = FakePlayer.e(l2, l3);
        Object object = z[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = A[n2];
                int n4 = string2.indexOf(8);
                clazz3 = FakePlayer.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = FakePlayer.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = FakePlayer.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        FakePlayer.z[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = FakePlayer.f(1323828593229091L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = FakePlayer.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        FakePlayer.z[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = FakePlayer.f(1323828593229091L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == 'u' || c2 == '\u00a4' || c2 == 'R' || c2 == 'O') {
                field = FakePlayer.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == 'u' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == '\u00a4' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == 'R' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = FakePlayer.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == '\u00fa' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == '\u00df' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = FakePlayer.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/e/N" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(FakePlayer.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(FakePlayer.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

