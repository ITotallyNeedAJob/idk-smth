// === Kuzi module: AutoLogout ===
// Category   : SERVER
// Description: Automatically disconnects when certain requirements are met
// Payload    : a.a.a.j.c.z (verified: True)

package kuzi.modules.server;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.core.Client;
import kuzi.mixin.MixinExposed;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.modules.server.AutoReconnect;
import kuzi.obf.h.b.v;
import kuzi.obf.m.r;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.Entity;
import net.minecraft.Level;
import net.minecraft.Component;
import net.minecraft.ClientboundDisconnectPacket;
import net.minecraft.ClientboundEntityEventPacket;
import net.minecraft.MutableComponent;

public class AutoLogout
extends BaseModule {
    private final SliderSetting health;
    private final BoolSetting totemPop;
    private final BoolSetting toggleOff;
    private final BoolSetting toggleAutoReconnect;
    private int q;
    private static final long r;
    private static final String[] s;
    private static final String[] t;
    private static final Map u;
    private static final long[] v;
    private static final Integer[] w;
    private static final Map x;
    private static final Object[] y;
    private static final String[] z;

    public AutoLogout() {
        long l2 = r ^ 0x2BDC01B063C5L;
        long l3 = l2 ^ 0x3E0E3F1AFEL;
        super("AutoLogout", "Automatically disconnects when certain requirements are met", Category.SERVER);
        this.health = new SliderSetting("Health", 6.0, 0.0, 19.0, 1.0);
        this.totemPop = new BoolSetting("Totem Pop", true);
        this.toggleOff = new BoolSetting("Toggle Off", true);
        this.toggleAutoReconnect = new BoolSetting("Toggle Auto Reconnect", true);
        Setting[] settingArray = new Setting[]{this.health, this.totemPop, this.toggleOff, this.toggleAutoReconnect};
        Object[] objectArray = new Object[2];
        objectArray[1] = settingArray;
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        super.d();
        this.q = 0;
    }

    @Override
    public void i() {
        long l2 = r ^ 0x7997EC1082CFL;
        long l3 = l2 ^ 0x397851E38550L;
        boolean bl = false;
        if (BaseModule.a.player == null || BaseModule.a.level == null) {
            return;
        }
        float currentHealth = BaseModule.a.player.getHealth();
        if (currentHealth <= 0.0f) {
            this.j();
            return;
        }
        if ((Double)this.health.a() > 0.0 && (double)currentHealth <= (Double)this.health.a()) {
            Object[] objectArray = new Object[2];
            objectArray[1] = l3;
            objectArray[0] = "Health was lower than " + ((Double)this.health.a()).intValue() + ".";
            this.a(objectArray);
            if (((Boolean)this.toggleOff.a()).booleanValue()) {
                this.j();
            }
        }
    }

    @MixinExposed
    public void a(ClientboundEntityEventPacket packet) {
        long l2 = r ^ 0x4DC2537E1749L;
        long l3 = l2 ^ 0xD2DEE8D10D6L;
        boolean bl = false;
        if (packet.getEventId() != 35) {
            return;
        }
        if (BaseModule.a.player == null || BaseModule.a.level == null) {
            return;
        }
        Entity entity = packet.getEntity((Level)BaseModule.a.level);
        if (entity == null || !entity.equals((Object)BaseModule.a.player)) {
            return;
        }
        if (((Boolean)this.totemPop.a()).booleanValue()) {
            Object[] objectArray = new Object[2];
            objectArray[1] = l3;
            objectArray[0] = "Popped totem.";
            this.a(objectArray);
            if (((Boolean)this.toggleOff.a()).booleanValue()) {
                this.j();
            }
        }
    }

    private void a(Object[] objectArray) {
        String string = (String)objectArray[0];
        long l2 = (Long)objectArray[1];
        long l3 = (l2 = r ^ l2) ^ 0x2A65EAE84CAAL;
        Object[] objectArray2 = new Object[2];
        objectArray2[1] = Component.literal((String)string);
        objectArray2[0] = l3;
        this.b(objectArray2);
    }

    private void b(Object[] objectArray) {
        block4: {
            MutableComponent message;
            block5: {
                boolean bl;
                AutoReconnect autoReconnect;
                long l2;
                block6: {
                    l2 = (Long)objectArray[0];
                    Component content = (Component)objectArray[1];
                    l2 = r ^ l2;
                    message = Component.literal((String)((Object)AutoLogout.b("g", (int)17180, (long)(0x6B4C9D3C14F2CC7EL ^ l2))));
                    message.append(content);
                    autoReconnect = (AutoReconnect)Client.a().a(AutoReconnect.class);
                    boolean bl2 = false;
                    if (bl2) break block4;
                    if (autoReconnect == null) break block5;
                    bl = autoReconnect.d();
                    if (l2 < 0L || bl2) break block6;
                    if (!bl) break block5;
                    bl = (Boolean)this.toggleAutoReconnect.a();
                }
                if (bl) {
                    message.append((Component)Component.literal((String)((Object)AutoLogout.b("g", (int)26248, (long)(0xCE4A3077511E9E3L ^ l2)))).withColor((int)AutoLogout.c("k", (int)8734, (long)(0x21C8E63DB8D0EA43L ^ l2))));
                    autoReconnect.j();
                }
            }
            BaseModule.a.player.connection.handleDisconnect(new ClientboundDisconnectPacket((Component)message));
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block16: {
            block15: {
                block14: {
                    block13: {
                        AutoLogout.r = kuzi.obf.h.b.v.a(6405229626485877733L, -4599870980138026622L, MethodHandles.lookup().lookupClass()).a(208762409910126L);
                        AutoLogout.y = new Object[31];
                        AutoLogout.z = new String[31];
                        AutoLogout.c();
                        AutoLogout.u = new HashMap<K, V>(13);
                        var11 = AutoLogout.r ^ 20613486294733L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[10];
                        var18_4 = 0;
                        var17_5 = "|8\u0015\u00de\u00cc\u00ea_L\u0005[(\u0019\u00b5\u00bd\u00b4Q\u008f\u0003>\u00e1\u00a6)Q\u00ee\u00bb\u009e)\u0010\u00c49hI\u00e4\u0082U\u00fdF\u0015\u00ed['\u0097\u0094:\u00bbd\u00cbkg\u00bfsR\u009c\b\u00bdk\\\u007f\u00f2p\u00ed\u001d\u00ee\u0090 \u0096\u00f1k%\u0001\u00139\u0018m3):\u00e6\u00a58\u00fc\u00ad\u00e8\u00eb\u00c6s\u00d5\u00f5\u001f~\u000b$\u00ff,\u0082\u00b2[ 5}\u00cd\u009c\u00d3\u00d5[q\u000e\u00d0_\u00fcS+\u00e5\u0018X\u00ed4\u00ad\u00e7.\u00e7\u00ff\u009b\u0005\u00c2c92Q< \"\u008e\u0098>G\u00bf\u00cd\u00ec\u00a8l\u00c1\u00d8\u00c0Q\u00908t\u00e9\u0093\u00caX\u00a5\u00e6\u0091\u00bc\u00a4I\u0013[g\u000e\u0091(\rd\u00a9\u0084]\u00fc}\u00ddR\u0087\u0098\u00e0w2q'F\u0094|i\u0011\u00a7\u00cc9${\u0016v[CB\u00e7\u001cs,w\u00c5\f\"\u00b1h[\u0007\u008d1g\u0097\u00d2\u001a\u00a5\u00f1o\u0095>\u00ac6\u0092\u0088\u0095\u00f2*\u00c8\u00dcV\u00f8\b\u00f54\u00e0\u009eR\u0082\u0081m\u00caP\u00c6Bv\u00eb\u00bb\u00d5+\u00faq\u00dc\u001c\u0006\u00e3\u0091*\u00cb\u00d0\u00e9\u0097\u00c7H\u00a9\u00bd\u00fe\u00de\u00ee\u00fa\u0004\u0094\u00c2x6)\u00bf\u0013\u00f2\u0019\u00c0j\u00d9\u00b3\u0017\u00cc\u00b2K\u009bz\u00f3T\u00b0\u00ed\u0011\u00b8[gq\b\u0084\u00f1\u00ab\u0011eA\u00eeL\u00fbzR\u00a9 \u0096\u00e8>ss$eA\u00f2\u0091\u00f9,v\u00ec&\u0096\u0096\u001b\u00e5\u00e6k\u0091\u00b0G\u00aa\u0083\u000eIC\u00d4\u008e\u00970}\u00ab\u00fdfO^\u00e41Q\u00e9\u00ca\u00cb\\\u0014<\u0095\u00b0\u00eb\u00d93D\u00efk\u001d+\u00f7\u00bd\u00b9\u00a5eI\u00a6i\rW\t\u001bm}L@IlE\u00e2Bt^";
                        var19_6 = "|8\u0015\u00de\u00cc\u00ea_L\u0005[(\u0019\u00b5\u00bd\u00b4Q\u008f\u0003>\u00e1\u00a6)Q\u00ee\u00bb\u009e)\u0010\u00c49hI\u00e4\u0082U\u00fdF\u0015\u00ed['\u0097\u0094:\u00bbd\u00cbkg\u00bfsR\u009c\b\u00bdk\\\u007f\u00f2p\u00ed\u001d\u00ee\u0090 \u0096\u00f1k%\u0001\u00139\u0018m3):\u00e6\u00a58\u00fc\u00ad\u00e8\u00eb\u00c6s\u00d5\u00f5\u001f~\u000b$\u00ff,\u0082\u00b2[ 5}\u00cd\u009c\u00d3\u00d5[q\u000e\u00d0_\u00fcS+\u00e5\u0018X\u00ed4\u00ad\u00e7.\u00e7\u00ff\u009b\u0005\u00c2c92Q< \"\u008e\u0098>G\u00bf\u00cd\u00ec\u00a8l\u00c1\u00d8\u00c0Q\u00908t\u00e9\u0093\u00caX\u00a5\u00e6\u0091\u00bc\u00a4I\u0013[g\u000e\u0091(\rd\u00a9\u0084]\u00fc}\u00ddR\u0087\u0098\u00e0w2q'F\u0094|i\u0011\u00a7\u00cc9${\u0016v[CB\u00e7\u001cs,w\u00c5\f\"\u00b1h[\u0007\u008d1g\u0097\u00d2\u001a\u00a5\u00f1o\u0095>\u00ac6\u0092\u0088\u0095\u00f2*\u00c8\u00dcV\u00f8\b\u00f54\u00e0\u009eR\u0082\u0081m\u00caP\u00c6Bv\u00eb\u00bb\u00d5+\u00faq\u00dc\u001c\u0006\u00e3\u0091*\u00cb\u00d0\u00e9\u0097\u00c7H\u00a9\u00bd\u00fe\u00de\u00ee\u00fa\u0004\u0094\u00c2x6)\u00bf\u0013\u00f2\u0019\u00c0j\u00d9\u00b3\u0017\u00cc\u00b2K\u009bz\u00f3T\u00b0\u00ed\u0011\u00b8[gq\b\u0084\u00f1\u00ab\u0011eA\u00eeL\u00fbzR\u00a9 \u0096\u00e8>ss$eA\u00f2\u0091\u00f9,v\u00ec&\u0096\u0096\u001b\u00e5\u00e6k\u0091\u00b0G\u00aa\u0083\u000eIC\u00d4\u008e\u00970}\u00ab\u00fdfO^\u00e41Q\u00e9\u00ca\u00cb\\\u0014<\u0095\u00b0\u00eb\u00d93D\u00efk\u001d+\u00f7\u00bd\u00b9\u00a5eI\u00a6i\rW\t\u001bm}L@IlE\u00e2Bt^".length();
                        var16_7 = 64;
                        var15_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block13;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = AutoLogout.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "y\u00e6\u00dd4\u0097\u00df.'\u0098\u00b5\u00ecZ\u009eE\u00e0\u00e3 \u00ddR\u0088\u00fe_\u00d2\u00f0!\u00b3Q?\u009b\u0011C\u00db\u0001\u00d7\u00acU\u0012\u00d6\u00b8N\u00f7\u00f9\u00da\u00c2*g\u0007\u008a\u0087";
                            var19_6 = "y\u00e6\u00dd4\u0097\u00df.'\u0098\u00b5\u00ecZ\u009eE\u00e0\u00e3 \u00ddR\u0088\u00fe_\u00d2\u00f0!\u00b3Q?\u009b\u0011C\u00db\u0001\u00d7\u00acU\u0012\u00d6\u00b8N\u00f7\u00f9\u00da\u00c2*g\u0007\u008a\u0087".length();
                            var16_7 = 16;
                            var15_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block13;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = AutoLogout.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block14;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                AutoLogout.s = var20_3;
                AutoLogout.t = new String[10];
                AutoLogout.x = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[2];
                var3_13 = 0;
                var4_14 = "\u00e3\u0095\u00d8U\u0091\u0013\u008e\u0080\u0090\u00de\u00cf\u0007\u0082\u00dbP\u00e1";
                var5_15 = "\u00e3\u0095\u00d8U\u0091\u0013\u008e\u0080\u0090\u00de\u00cf\u0007\u0082\u00dbP\u00e1".length();
                var2_16 = 0;
                while (true) {
                    break block15;
                    break;
                }
lbl76:
                // 1 sources

                while (true) {
                    var6_12[v10] = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
                    if (var2_16 < var5_15) ** continue;
                    break block16;
                    break;
                }
            }
            var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
            v10 = var3_13++;
            var8_18 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            ** while (true)
        }
        AutoLogout.v = var6_12;
        AutoLogout.w = new Integer[2];
    }

    private static r a(r r2) {
        return r2;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static String b(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x2670;
        if (t[n3] == null) {
            Object[] objectArray;
            try {
                Long l3 = Thread.currentThread().threadId();
                objectArray = (Object[])u.get(l3);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    u.put(l3, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/c/z", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l2 >>> 56);
            for (int i2 = 1; i2 < 8; ++i2) {
                byArray[i2] = (byte)(l2 << i2 * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = s[n3].getBytes("ISO-8859-1");
            AutoLogout.t[n3] = AutoLogout.b(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return t[n3];
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        String string2 = AutoLogout.b(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static CallSite b(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/c/z" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x6147;
        if (w[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = v[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])x.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    x.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/c/z", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            AutoLogout.w[n3] = n4;
        }
        return w[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = AutoLogout.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/c/z" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static void c() {
        Object[] objectArray = y;
        y[0] = "dZG\u007f\u001dRoZL";
        objectArray[1] = ";bM\u0018\u000b@;bZD\u0007O!)ZZ\u0007Z&X\n\u0007V";
        objectArray[2] = Void.TYPE;
        AutoLogout.z[2] = "java/lang/Void";
        objectArray[3] = "`19\u001aJak1;\u001aE";
        objectArray[4] = Integer.TYPE;
        AutoLogout.z[4] = "java/lang/Integer";
        objectArray[5] = Boolean.TYPE;
        AutoLogout.z[5] = "java/lang/Boolean";
        objectArray[6] = "N3+N<8G3(N<";
        objectArray[7] = "3\u0014\\\u0002\u001eN8\u001bMM\u007f@3\u0010I\u0017";
        objectArray[8] = "qH\u000eGJ\u0007zH\fGQ";
        objectArray[9] = "\u001b\\\u0003\u0017f\u0015\u0012\\\u0000\u0017d";
        objectArray[10] = "7\fQ[0#;\fB";
        objectArray[11] = "~,\u00029\u0014D\u000b\f\t6\u0005\u000bj\u0002\u0002=\u0001Q\u001e";
        objectArray[12] = "=UTf[hHu_iJ'){TbN}]";
        objectArray[13] = "8a\u001c<t\u001e1a\u001f<x";
        objectArray[14] = "H*\\2ByC*T";
        objectArray[15] = "e\tJ_Fp\u0010)APW?q'J[Se\u0005";
        objectArray[16] = "\u0001q?|\u0019M^-8\u000e\u0017)\u001aq+3\u000e\u0013\u000fv)";
        objectArray[17] = "as\u001a\u000f\u000bwl{\u001a\u0005e0\\9F\u0014\u001dw=zAQ\u0002";
        objectArray[18] = "3)#,x9lu$^}]mqu4&gi%qc\u001f";
        objectArray[19] = "\u000bW\r\nd5XD\u0000]U\"1\u0005\u001cH-vPF\u001b\r2H";
        objectArray[20] = "\u0001\u001bn_\u0011w^Gi-\u001a\u0013]\\;N\u0010i\u001aYcSv";
        objectArray[21] = "#2wGUt.:wM;-\u001e}*DE.s17\u001d_";
        objectArray[22] = "\u001by&\b><H($\u0002\u0001\u0002?\u0013\u0000u[Y\u001by&\b><H($\u0002";
        objectArray[23] = "w\u0003E9o\u0012z\u000bE3\u0001IJCI<aO:\u001f\u001cbg";
        objectArray[24] = "vd\u001d\r_Q{l\u001d\u00071\u0006K|SS\n\u0015!s]WTorq\u0012\u0003\bUv%\u0016T1";
        objectArray[25] = "^\u001c;ipOS\f3tAIbY7g,\u0018\u0006]r-( ";
        objectArray[26] = "\f.(\u0007'\u0000\u0001&(\rIF1au\u00047Z\\-h]-";
        objectArray[27] = "``Z1d\u0005mhZ;\nQ]x\u0014o1A7w\u001ako;duU?3\u0001`!Qh\n";
        objectArray[28] = "_e\u001bb'mRm\u001bhI:b*Zxy=\u0013l\u001a<*S\\eU6'\"\u001a%\u0011eI";
        objectArray[29] = "3j:\u0004*e>b:\u000eD=\u000e%g\u0007:?ciz^ ";
        Object[] objectArray2 = objectArray;
        objectArray[30] = "P^\r\u007f\u0000\u000f\u000f\u0002\n\r\u0003k^\u001c^6\u001d\u0001Q\u0012ZhgRS]\u000e4]V\u0007YY\r";
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = AutoLogout.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = AutoLogout.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = AutoLogout.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = AutoLogout.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(AutoLogout.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(AutoLogout.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

