// === Kuzi module: FakePay ===
// Category   : SERVER
// Description: Overrides /pay with a fake confirmation message.
// Payload    : a.a.a.j.d.m (verified: False)

package kuzi.modules.server;

import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Locale;
import java.util.Map;
import java.util.function.UnaryOperator;
import kuzi.core.Client;
import kuzi.mixin.MixinExposed;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.modules.server.FakeScoreboard;
import kuzi.obf.e.i;
import kuzi.obf.j.d.b;
import kuzi.obf.m.r;
import kuzi.obf.p.n_0;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import net.minecraft.Component;
import net.minecraft.Style;
import net.minecraft.SoundEvents;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class FakePay
extends BaseModule {
    private static final int m;
    private static final int n;
    private final BoolSetting sound;
    private final BoolSetting actionBar;
    private final BoolSetting removeFromScoreboard;
    private volatile double totalPaid;
    private static final long s;
    private static final String[] t;
    private static final String[] u;
    private static final Map v;
    private static final long[] w;
    private static final Integer[] x;
    private static final Map y;
    private static final Object[] z;
    private static final String[] A;

    public FakePay() {
        long l2 = s ^ 0x26207B4B96ABL;
        long l3 = l2 ^ 0x207D92D3C888L;
        super("Fake Pay", "Overrides /pay with a fake confirmation message.", Category.SERVER);
        this.sound = new BoolSetting("Sound", true);
        this.actionBar = new BoolSetting("Action Bar", true);
        this.removeFromScoreboard = new BoolSetting("Remove From Scoreboard", false);
        this.totalPaid = 0.0;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.sound, this.actionBar, this.removeFromScoreboard};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void e() {
        this.totalPaid = 0.0;
        super.e();
    }

    @Override
    public void g(Object[] objectArray) {
        block10: {
            FakeScoreboard fakeScoreboard;
            long l2;
            long l3;
            block9: {
                FakeScoreboard fakeScoreboard2;
                CallSite callSite;
                block8: {
                    i i2;
                    block6: {
                        block7: {
                            l3 = (Long)objectArray[0];
                            l2 = l3 ^ 0x72C14ACEBD66L;
                            CallSite callSite2 = FakePay.d("k", (long)5691022291832010105L, (long)l3);
                            FakePay.d("\u00e0", (Object)this, (double)0.0, (long)5690477258456910213L, (long)l3);
                            callSite = callSite2;
                            try {
                                try {
                                    i2 = Client.a;
                                    if (callSite == false) break block6;
                                    if (i2 != null) break block7;
                                }
                                catch (r r2) {
                                    throw FakePay.d("k", (Object)r2, (long)5690570409607913362L, (long)l3);
                                }
                                fakeScoreboard2 = null;
                                break block8;
                            }
                            catch (r r3) {
                                throw FakePay.d("k", (Object)r3, (long)5690570409607913362L, (long)l3);
                            }
                        }
                        i2 = Client.a;
                    }
                    fakeScoreboard2 = (FakeScoreboard)i2.a(FakeScoreboard.class);
                }
                FakeScoreboard fakeScoreboard3 = fakeScoreboard2;
                try {
                    fakeScoreboard = fakeScoreboard3;
                    if (callSite == false) break block9;
                    if (fakeScoreboard == null) break block10;
                }
                catch (r r4) {
                    throw FakePay.d("k", (Object)r4, (long)5690570409607913362L, (long)l3);
                }
                fakeScoreboard = fakeScoreboard3;
            }
            Object[] objectArray2 = new Object[1];
            objectArray2[0] = l2;
            FakePay.d("\u00c0", (Object)fakeScoreboard, (Object)objectArray2, (long)5691250864520442641L, (long)l3);
        }
    }

    @MixinExposed
    public boolean a() {
        return (Boolean)this.removeFromScoreboard.a();
    }

    @MixinExposed
    public double a() {
        return this.totalPaid;
    }

    /*
     * Unable to fully structure code
     */
    @MixinExposed
    public boolean a(String var1_1) {
        block24: {
            block25: {
                block26: {
                    block22: {
                        block23: {
                            block21: {
                                block20: {
                                    block18: {
                                        block19: {
                                            block16: {
                                                block17: {
                                                    v0 = var2_2 = FakePay.s ^ 37269592269326L;
                                                    var4_3 = v0 ^ 99801274910502L;
                                                    var6_4 = v0 ^ 85799080122331L;
                                                    v1 = v0 ^ 79791000753207L;
                                                    var8_5 = (int)(v1 >>> 32);
                                                    var9_6 = (int)(v1 << 32 >>> 40);
                                                    var10_7 = (int)(v1 << 56 >>> 56);
                                                    var11_8 = v0 ^ 90367958045856L;
                                                    var13_9 = kuzi.obf.j.d.b.b();
                                                    if (var1_1 == null || BaseModule.a.player == null) {
                                                        return false;
                                                    }
                                                    parts = var1_1.trim().split("\\s+");
                                                    v2 = parts.length;
                                                    if (var13_9 == 0) break block16;
                                                    if (v2 < 3) break block17;
                                                    v3 = "pay";
                                                    if (var13_9 == 0) break block18;
                                                    if (v3.equals(parts[0].toLowerCase(Locale.ROOT))) break block19;
                                                }
                                                v2 = 0;
                                            }
                                            return (boolean)v2;
                                        }
                                        v3 = parts[1];
                                    }
                                    targetName = v3;
                                    v4 = amount = n_0.a(parts[2]);
                                    if (var13_9 == 0) break block20;
                                    if (v4 == null) break block21;
                                    v4 = amount;
                                }
                                v5 = v4;
                                if (var13_9 == 0) break block22;
                                if (!(v5 <= 0.0)) break block23;
                            }
                            return false;
                        }
                        v5 = amount;
                    }
                    amountText = n_0.a(v5);
                    message = Component.literal((String)("You paid " + targetName + " ")).withStyle((UnaryOperator)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Ljava/lang/Object;, lambda$handlePay$0(long net.minecraft.Style ), (Lnet/minecraft/Style;)Lnet/minecraft/Style;)((long)var6_4)).append((Component)Component.literal((String)"$").withStyle((UnaryOperator)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Ljava/lang/Object;, lambda$handlePay$1(int int byte net.minecraft.Style ), (Lnet/minecraft/Style;)Lnet/minecraft/Style;)((int)var8_5, (int)var9_6, (byte)((byte)var10_7)))).append((Component)Component.literal((String)(" " + amountText)).withStyle((UnaryOperator)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Ljava/lang/Object;, lambda$handlePay$2(long net.minecraft.Style ), (Lnet/minecraft/Style;)Lnet/minecraft/Style;)((long)var4_3)));
                    BaseModule.a.player.displayClientMessage((Component)message, false);
                    v6 = (Boolean)this.actionBar.a();
                    if (var13_9 != 0) {
                        if (v6) {
                            BaseModule.a.player.displayClientMessage((Component)message, true);
                        }
                        v6 = (Boolean)this.sound.a();
                    }
                    if (var13_9 != 0) {
                        if (v6) {
                            BaseModule.a.player.playSound(SoundEvents.ARROW_HIT_PLAYER, 1.0f, 1.0f);
                        }
                        v6 = (Boolean)this.removeFromScoreboard.a();
                    }
                    if (var13_9 == 0) break block24;
                    if (!v6) break block25;
                    this.totalPaid += amount.doubleValue();
                    v7 = Client.a;
                    if (var13_9 == 0) ** GOTO lbl63
                    if (v7 == null) {
                        v8 = null;
                    } else {
                        v7 = Client.a;
lbl63:
                        // 2 sources

                        v8 = (FakeScoreboard)v7.a(FakeScoreboard.class);
                    }
                    v9 = var19_15 = v8;
                    if (var13_9 == 0) break block26;
                    if (v9 == null) break block25;
                    v9 = var19_15;
                }
                v10 = new Object[1];
                v10[0] = var11_8;
                v9.b(v10);
            }
            v6 = true;
        }
        return v6;
    }

    private static Style lambda$handlePay$2(long l2, Style style) {
        l2 = s ^ l2;
        return style.withColor(0xFFFFFF);
    }

    private static Style lambda$handlePay$1(int n2, int n3, byte by, Style style) {
        long l2 = ((long)n2 << 32 | (long)n3 << 40 >>> 32 | (long)by << 56 >>> 56) ^ s;
        return style.withColor(0x55FF55);
    }

    private static Style lambda$handlePay$0(long l2, Style style) {
        l2 = s ^ l2;
        return style.withColor(0xFFFFFF);
    }

    static {
        s = 43700803978550L;
        z = new Object[]{"\u0001c$!\u0017\u001c\nc!!\u0014", Integer.TYPE, "`\u001bzJ%Yk\u001bq", "Y5vy5)Y5a%9&C~a;93D\u000f1fh", "<z\u0010\u0012347z\u0015\u0012?", "6>G\bZR?>D\bX", "+6=\bA\u001f 68\bN", "z\u0010,m\u0015p\u000f0'b\u0004?n>,i\u0000e\u001a", Void.TYPE, "\u0007)\u0017Z\b#\u0016)8", "]\u0006nsDyV\t\u007f<9aE\u000evu", "gsCm\u000bul|R\"avxpYi", Double.TYPE, "YqDB\u0019\u000fUqW", "R0\u0017!@`[0\u0014!@", "MYUehuFVD*\t{M]@p", "z\u00183C\u000f\u0010q\u0018;", "1GH0\u000bxDgC?\u001a7%iH4\u001emQ", "i\u001exO\"m7B\u001aNE*/E!\u0015+<dI\u001a", "\f`gi/2\u0005 v:N45&:h\u007f2[-d\"3", "14[yB`39^9\":\u000bu\u001d S-{8J2\u001f", "_F:qU-\b\u00147yi7cBcd\u0019,\u0003\u0014br\u000e]^P%#\u0000,\u0006T ti", "K\t-1\u0001xI\u0004(qa<qHkh\u00105\u0001\u0005<z\\", "HQ\u000fMb~LJU\f\u000e\u0014oa4zTOHQ\u000fMb~LJU\f", "+|8D\u0006\u000b~;0Xj\u0003\u0015<hW\u0015\u0005j|7S\bj%9nJZRn>7Tj", "w\u000fFP\u000bH\"HNLg@I@\u0010\r\u0015W(\u0016\n\u0004\u001c)v\u0011\tB\bV6N\r_g", "7p\u001c\u0001cM5}\u0019A\u0003\n\r=\u0001\u0001q\u000elk\u001b\bx", "(e\u0012\u001dsP*h\u0017]\u0013\u0004\u0012)\nKa\u0007p!\u0014Vcm#z\u000e_y\u000f+d\u0013]\u0013", "\u0019t\u001dKGv\u001by\u0018\u000b'3#5[\u0012V;Sx\f\u0000\u001a", "\u001dc@hp\u0001\u001ft\u0016u\u001a\u0004tfVfp\u0006\u001f}Ykvm", "*\b\u000br`1#H\u001a!\u0001:\u0013\u001fS9q/sIR/f^.\r\u0015~h/v\t\u0010)\u0001"};
        A = new String[]{null, "java/lang/Integer", null, null, null, null, null, null, "java/lang/Void", null, null, null, "java/lang/Double", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null};
    }

    private static r a(r r2) {
        return r2;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (A[n4] != null) {
            return n4;
        }
        Object object = z[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 43;
            case 1 -> 23;
            case 2 -> 48;
            case 3 -> 63;
            case 4 -> 24;
            case 5 -> 33;
            case 6 -> 32;
            case 7 -> 22;
            case 8 -> 12;
            case 9 -> 17;
            case 10 -> 13;
            case 11 -> 54;
            case 12 -> 15;
            case 13 -> 27;
            case 14 -> 56;
            case 15 -> 38;
            case 16 -> 16;
            case 17 -> 26;
            case 18 -> 5;
            case 19 -> 9;
            case 20 -> 41;
            case 21 -> 21;
            case 22 -> 55;
            case 23 -> 11;
            case 24 -> 30;
            case 25 -> 28;
            case 26 -> 39;
            case 27 -> 31;
            case 28 -> 0;
            case 29 -> 4;
            case 30 -> 18;
            case 31 -> 57;
            case 32 -> 58;
            case 33 -> 3;
            case 34 -> 50;
            case 35 -> 10;
            case 36 -> 34;
            case 37 -> 2;
            case 38 -> 46;
            case 39 -> 25;
            case 40 -> 29;
            case 41 -> 59;
            case 42 -> 1;
            case 43 -> 61;
            case 44 -> 60;
            case 45 -> 42;
            case 46 -> 8;
            case 47 -> 36;
            case 48 -> 62;
            case 49 -> 20;
            case 50 -> 44;
            case 51 -> 53;
            case 52 -> 7;
            case 53 -> 37;
            case 54 -> 49;
            case 55 -> 14;
            case 56 -> 47;
            case 57 -> 35;
            case 58 -> 45;
            case 59 -> 51;
            case 60 -> 52;
            case 61 -> 6;
            case 62 -> 19;
            default -> 40;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        FakePay.A[n4] = new String(cArray);
        return n4;
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = FakePay.e(l2, l3);
            object = z[n2];
            try {
                if (!(object instanceof String)) break block2;
                FakePay.z[n2] = clazz = Class.forName(A[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = FakePay.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = FakePay.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = FakePay.e(l2, l3);
        Object object = z[n2];
        if (object instanceof String) {
            String string = A[n2];
            int n3 = string.indexOf(8);
            Class clazz = FakePay.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = FakePay.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = FakePay.c(clazz3, string2, clazz2)) != null) {
                    FakePay.z[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = FakePay.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        FakePay.z[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = FakePay.f(1111463631404365L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = FakePay.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = FakePay.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = FakePay.e(l2, l3);
        Object object = z[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = A[n2];
                int n4 = string2.indexOf(8);
                clazz3 = FakePay.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = FakePay.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = FakePay.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        FakePay.z[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = FakePay.f(1111463631404365L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = FakePay.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        FakePay.z[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = FakePay.f(1111463631404365L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == '\u00c6' || c2 == '\u00e0' || c2 == '\u00ca' || c2 == '\u00da') {
                field = FakePay.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == '\u00c6' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == '\u00e0' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == '\u00ca' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = FakePay.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == '\u00c0' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == 'k' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = FakePay.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/d/m" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(FakePay.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

