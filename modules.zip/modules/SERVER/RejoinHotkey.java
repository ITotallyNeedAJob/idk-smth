// === Kuzi module: RejoinHotkey ===
// Category   : SERVER
// Description: Leaves the current server and reconnects when pressed.
// Payload    : a.a.a.j.e.ab (verified: False)

package kuzi.modules.server;

import java.lang.invoke.LambdaMetafactory;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.modules.server.AutoReconnect;
import kuzi.obf.j.e.am;
import kuzi.obf.m.r;
import kuzi.obf.p.x_0;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.Component;
import net.minecraft.Minecraft;
import net.minecraft.ConnectScreen;
import net.minecraft.Screen;
import net.minecraft.TitleScreen;
import net.minecraft.ServerAddress;
import net.minecraft.ServerData;

public class RejoinHotkey
extends BaseModule {
    private final SliderSetting delaySeconds;
    private boolean rejoining;
    private int remainingTicks;
    private ServerAddress serverAddress;
    private ServerData serverData;
    private static final long r = 127605976575074L;
    private static final long v;
    private static final Object[] w;
    private static final String[] x;

    public RejoinHotkey() {
        long l2 = r ^ 0xBF9E43E17F8L;
        long l3 = l2 ^ 0x5E147BA4208FL;
        super("Rejoin Hotkey", "Leaves the current server and reconnects when pressed.", Category.SERVER);
        this.delaySeconds = new SliderSetting("Delay Seconds", 0.5, 0.5, 15.0, 0.5);
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.delaySeconds};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public void d() {
        block23: {
            block22: {
                block21: {
                    block18: {
                        block20: {
                            block19: {
                                block16: {
                                    block17: {
                                        block13: {
                                            block14: {
                                                block15: {
                                                    v0 = var1_1 = RejoinHotkey.r ^ 34648181771183L;
                                                    var3_2 = v0 ^ 65436850679566L;
                                                    var5_3 = v0 ^ 34025324203474L;
                                                    var7_4 = am.b();
                                                    if (var7_4 == null) break block13;
                                                    if (BaseModule.a.player == null) break block14;
                                                    mc = BaseModule.a;
                                                    if (var7_4 == null) break block15;
                                                    if (mc.level == null) break block14;
                                                    mc = BaseModule.a;
                                                }
                                                if (var7_4 == null) break block16;
                                                if (mc.getConnection() != null) break block17;
                                            }
                                            v2 = new Object[2];
                                            v2[1] = "Rejoin failed: not connected to a server.";
                                            v2[0] = var5_3;
                                            x_0.a(v2);
                                            this.i(false);
                                        }
                                        return;
                                    }
                                    mc = BaseModule.a;
                                }
                                currentServer = mc.getCurrentServer();
                                if (var7_4 == null) break block18;
                                if (currentServer == null) break block19;
                                v3 = currentServer.ip;
                                if (var7_4 == null) break block20;
                                if (v3 == null) break block19;
                                v3 = currentServer.ip;
                                if (var7_4 == null) break block20;
                                if (!v3.isBlank()) break block21;
                            }
                            v3 = "Rejoin failed: no saved multiplayer server.";
                        }
                        v4 = new Object[2];
                        v4[1] = v3;
                        v4[0] = var5_3;
                        x_0.a(v4);
                        this.i(false);
                    }
                    return;
                }
                this.serverAddress = ServerAddress.parseString((String)currentServer.ip);
                this.serverData = currentServer;
                client = Client.a();
                if (var7_4 == null) ** GOTO lbl55
                if (client != null) {
                    client = Client.a();
lbl55:
                    // 2 sources

                    v6 = (AutoReconnect)client.a(AutoReconnect.class);
                } else {
                    v6 = null;
                }
                v7 = var9_6 = v6;
                if (var7_4 == null) break block22;
                if (v7 == null) break block23;
                v7 = var9_6;
            }
            v7.a(this.serverAddress, this.serverData);
        }
        connection = BaseModule.a.getConnection();
        if (var7_4 != null) {
            if (connection != null) {
                connection.getConnection().disconnect((Component)Component.literal((String)"Reconnecting..."));
            }
            BaseModule.a.execute((Runnable)LambdaMetafactory.metafactory(null, null, null, ()V, lambda$onEnable$0(long ), ()V)((long)var3_2));
            this.rejoining = true;
            this.remainingTicks = Math.max((int)RejoinHotkey.v, (int)Math.round((Double)this.delaySeconds.a() * 20.0));
        }
    }

    @Override
    public void e() {
        this.rejoining = false;
        this.remainingTicks = 0;
        this.serverAddress = null;
        this.serverData = null;
    }

    @Override
    public void i() {
        RejoinHotkey rejoinHotkey;
        long l2;
        block14: {
            block15: {
                RejoinHotkey rejoinHotkey2;
                block12: {
                    block13: {
                        String string;
                        block11: {
                            block10: {
                                Minecraft mc;
                                block9: {
                                    long l3 = r ^ 0x7987C05CC83L;
                                    l2 = l3 ^ 0x79F4FE8F000AL;
                                    string = am.b();
                                    if (!this.rejoining) {
                                        return;
                                    }
                                    mc = BaseModule.a;
                                    if (string == null) break block9;
                                    if (mc.getConnection() != null) break block10;
                                    mc = BaseModule.a;
                                }
                                if (mc.level == null) break block11;
                            }
                            return;
                        }
                        rejoinHotkey2 = this;
                        if (string != null) {
                            if (--rejoinHotkey2.remainingTicks > 0) {
                                return;
                            }
                            rejoinHotkey2 = this;
                        }
                        if (string == null) break block12;
                        if (rejoinHotkey2.serverAddress == null) break block13;
                        rejoinHotkey = this;
                        if (string == null) break block14;
                        if (rejoinHotkey.serverData != null) break block15;
                    }
                    rejoinHotkey2 = this;
                }
                rejoinHotkey2.i(false);
                return;
            }
            this.rejoining = false;
            rejoinHotkey = this;
        }
        ServerAddress targetAddress = rejoinHotkey.serverAddress;
        ServerData targetData = this.serverData;
        this.serverAddress = null;
        this.serverData = null;
        BaseModule.a.execute(() -> RejoinHotkey.lambda$onTick$1(targetAddress, l2, targetData));
        this.i(false);
    }

    private static void lambda$onTick$1(ServerAddress targetAddress, long l2, ServerData targetData) {
        l2 = r ^ l2;
        ConnectScreen.startConnecting((Screen)new TitleScreen(), (Minecraft)BaseModule.a, (ServerAddress)targetAddress, (ServerData)targetData, (boolean)false, null);
    }

    private static void lambda$onEnable$0(long l2) {
        l2 = r ^ l2;
        BaseModule.a.disconnect((Screen)new TitleScreen(), false);
    }

    static {
        w = new Object[]{"k6,\n\u0004\u0016z65", "x>\u0013c\u0004C\r\u001e\u0018l\u0015\fl\u0010\u0013g\u0011V\u0018", Void.TYPE, ":p('\u001a31p,'\u001ap", "{\u001c\u00128V\u0000p\u0013\u0003w+\u0018c\u0014\n>", "n&@/\u00158e&K", "D5S\r\u000e]D5DQ\u0002R^~DO\u0002GY\u000f\u0014\u0012S", "\u0006*e\u0003\u001f\t\r*a\u0003\u001fE", " ;\u00017n8);\u00027b", Boolean.TYPE, Integer.TYPE, "Pk!L\u0002\u0013\\k2", "\u0014\u0010s\u0019\u00067\u001d\u0010p\u0019\u0006", "y;%%[/r44j:!y?00", "\u0003YPx4P\bYTx\u0016", "dmRQ\\\u000bdmE\rP\u0004~&E\u0013P\u0011yW\u0010L\b", "C)\b{z\u000eC)\u001f'v\u0001Yb\u001f9v\u0014^\u0013Ja%", "Fr\u0013!`yMr\u001b", "V>mB`0#\u001efMq\u007fB\u0010mFu%6", "%F9>B\u0011pV(TBxwD44V\u0019,T6.+AxAm9M\u0016%\u0002-T", ",\u001bC4l\u0002z\u001bRh\f\u0004\u0016H_cf\u0004y\u0019S~vn", "DRqix\u000f\u001fY{?\u0017^\u007f\u001e(&u\\\u0012_q4z", "\u0003^\u001b}IIAZX$ \u0012?\u001e\u001cdE\r\u0005\u0011Q!F", "a6A\u0011d`:=KG\u000b9Zx\u000fUobb~\u001dA6Xc\"\n\u0015f>4\u007fIU\u000b", "Pxkp<\u0001\u0012|()UXl9h/?V\u0017vbo8", "Y}9\u007f?5\u001byz&Vme=\u007fd21];mpk", "K\u0000cBn\u000e\u001b\u0004eP^>l'Pm\u0004eK\u0000cBn\u000e\u001b\u0004eP", "\u001fL\u001dWn+]H^\u000e\u0007|#\u0002LPnoAJJZz\u0015\u0013[B^}w[]HJ\u0007", "lj\u001b!3Pe\u007f_u\u0002D\\?\u0010;9B,nHps-", "AP(A`\u0014KS8\u001e\u000fD(U:^5TT\u0007>[n-BU9\u0012eNFS(L\u000f\u0014LGbOiC\u0011\u0004\"\"", "FkFt`c\u0004o\u0005-\t%z|\u001dh3$\u0006.\u0019mh", "\b#l\u000f]BJ'/V4\u000547=\u000f\u0004\u0016W3;\u001eZ", "D8\u0000Fh9\u001f3\n\u0010\u0007e\u007f#N\u001bg|\u001ex^\u0019}\u0001F,KBjg\u0011q\b\u0002\u0007"};
        x = new String[]{null, null, "java/lang/Void", null, null, null, null, null, null, "java/lang/Boolean", "java/lang/Integer", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null};
        v = -3750197204703248374L;
    }

    private static r a(r r2) {
        return r2;
    }

    private static Field declaredField(Class clazz, String name, Class fieldType) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(name) || field.getType() != fieldType) continue;
            return field;
        }
        return null;
    }

    private static Field fieldIncludingInterfaces(Class clazz, String name, Class fieldType) {
        Field field = RejoinHotkey.declaredField(clazz, name, fieldType);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = RejoinHotkey.fieldIncludingInterfaces(classArray[i2], name, fieldType);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method declaredMethod(Class clazz, String name, Class returnType, int parameterCount, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] parameterTypes;
            if (!method.getName().equals(name) || method.getReturnType() != returnType || (parameterTypes = method.getParameterTypes()).length != parameterCount) continue;
            for (int i2 = 0; i2 < parameterCount; ++i2) {
                if (parameterTypes[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method methodIncludingInterfaces(Class clazz, String name, Class returnType, int parameterCount, Class[] classArray) {
        Method method = RejoinHotkey.declaredMethod(clazz, name, returnType, parameterCount, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = RejoinHotkey.methodIncludingInterfaces(classArray2[i2], name, returnType, parameterCount, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }
}

