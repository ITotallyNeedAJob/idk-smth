// === Kuzi module: AntiAFK ===
// Category   : SERVER
// Description: Prevents you from being kicked for being AFK by rotating your view
// Payload    : a.a.a.j.d.j (verified: True)

package kuzi.modules.server;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.j.d.b;
import kuzi.obf.m.r;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.Minecraft;
import net.minecraft.Mth;

public class AntiAFK
extends BaseModule {
    private final SliderSetting interval;
    private int tickCounter;
    private static final long o = 63747006953323L;
    private static final Object[] s = new Object[]{"\u007f<f&Aqt<c&J", Integer.TYPE, "\b\u0005\u0017\u0003Ts\u0003\u0005\u0012\u0003W", "W)_\tO\f\\)T", "\u0000\u0015<*6[\u0000\u0015+v:T\u001a^+h:A\u001d/{5k", "\u0006mt+'{\nmg", "^\u0005sA\u0006eW\u0005pA\n", "}1A,P\nt1B,P", "B\u0019#\t\u000f\u0018I\u00162Fn\u0016B\u001d6\u001c", "^\u00183z~\\U\u0018;", "q\u0006\u000f]E`\u0004&\u0004RT/e(\u000fYPu\u0011", Void.TYPE, "8@Q\u00199p3\u0019\b'd\u0014)\u001f\u0017Hak*\\\u0004", "\u0000_cwa9BL}r\u0005#9^/1j*F]l\"\u0005", "{}H'JVp$\u0011\u0019\u00142-y\bv\u0013TcpOe", "e\u000b;--\\9\u0002=g\u0013E_^;1i\u0013fTy2+", "UL`B@%\tR|Oq\u0012&vY>+IUL`B@%\tR|O", "\"13uhI%&scV\\\u001fg4r-\u0005z'p\"(5", "Ncgf\u0001wE:>XS\u0013\u001f`;'Yc\u0014}1$:(Fg!;J#[m\"X", "OS3*+u\u0013Z5`\u0015au\u0003{ x\u007f\u001e\u00014`u\u0005J[b4wb\u0004Fg,\u0015"};
    private static final String[] t = new String[]{null, "java/lang/Integer", null, null, null, null, null, null, null, null, null, "java/lang/Void", null, null, null, null, null, null, null, null};

    public AntiAFK() {
        long l2 = o ^ 0x3B7B8D470387L;
        long l3 = l2 ^ 0x2362C78EEFF9L;
        super("AntiAFK", "Prevents you from being kicked for being AFK by rotating your view", Category.SERVER);
        this.interval = new SliderSetting("Interval", 100.0, 20.0, 600.0, 10.0);
        this.tickCounter = 0;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.interval};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        this.tickCounter = 0;
    }

    @Override
    public void i() {
        block9: {
            block8: {
                Object object;
                int n2;
                block6: {
                    block7: {
                        block5: {
                            Minecraft minecraft;
                            block4: {
                                n2 = kuzi.obf.j.d.b.b();
                                minecraft = BaseModule.a;
                                if (n2 == 0) break block4;
                                if (minecraft.player == null) break block5;
                                minecraft = BaseModule.a;
                            }
                            object = minecraft.level;
                            if (n2 == 0) break block6;
                            if (object != null) break block7;
                        }
                        return;
                    }
                    ++this.tickCounter;
                    object = this.interval.a();
                }
                int intervalTicks = (int)((Double)object).doubleValue();
                AntiAFK antiAFK = this;
                if (n2 == 0) break block8;
                if (antiAFK.tickCounter < intervalTicks) break block9;
                antiAFK = this;
            }
            antiAFK.tickCounter = 0;
            float yaw = BaseModule.a.player.getYRot();
            float pitch = BaseModule.a.player.getXRot();
            float yawDelta = (float)(Math.random() * 10.0 - 5.0);
            float pitchDelta = (float)(Math.random() * 10.0 - 5.0);
            float newYaw = yaw + yawDelta;
            float newPitch = Mth.clamp((float)(pitch + pitchDelta), (float)-90.0f, (float)90.0f);
            BaseModule.a.player.setYRot(newYaw);
            BaseModule.a.player.setXRot(newPitch);
        }
    }

    @Override
    public void e() {
        this.tickCounter = 0;
    }

    private static r a(r r2) {
        return r2;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = AntiAFK.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = AntiAFK.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = AntiAFK.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = AntiAFK.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }
}

