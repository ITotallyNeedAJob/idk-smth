// === Kuzi module: StaffRoles ===
// Category   : SERVER
// Description: Displays a fake staff role in chat
// Payload    : a.a.a.j.d.r (verified: True)

package kuzi.modules.server;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.mixin.MixinExposed;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.b.l;
import kuzi.obf.h.b.v;
import kuzi.obf.j.d.b;
import kuzi.obf.j.d.f;
import kuzi.obf.m.r;
import kuzi.settings.Setting;
import net.minecraft.Component;
import net.minecraft.Minecraft;
import net.minecraft.User;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class StaffRoles
extends BaseModule {
    public static StaffRoles m;
    public final l n;
    private static final long o;
    private static final String[] p;
    private static final String[] q;
    private static final Map r;
    private static final long[] s;
    private static final Integer[] t;
    private static final Map u;
    private static final Object[] v;
    private static final String[] w;

    public StaffRoles() {
        long l2 = o ^ 0x53BB5B588CD4L;
        long l3 = l2 ^ 0x59BFCFBD46B3L;
        super("StaffRoles", "Displays a fake staff role in chat", Category.SERVER);
        this.n = new l("Role", kuzi.obf.j.d.f.NONE, f.class);
        m = this;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.n};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static boolean a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = o ^ l2;
        int n2 = kuzi.obf.j.d.b.b();
        StaffRoles staffRoles = m;
        if (n2 != 0) {
            if (staffRoles == null) return false;
            staffRoles = m;
        }
        boolean bl = staffRoles.d();
        int n3 = n2;
        if (l2 > 0L) {
            if (n3 != 0) {
                if (!bl) return false;
                bl = ((f)((Object)StaffRoles.m.n.a())).name().equals(StaffRoles.b("r", (int)28666, (long)(0x67C1CD77CD6650FDL ^ l2)));
            }
            n3 = n2;
        }
        if (n3 == 0) return bl;
        if (bl) return false;
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static String c(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = o ^ l2;
        Minecraft mc = Minecraft.getInstance();
        int n2 = kuzi.obf.j.d.b.b();
        Minecraft mcAlias = mc;
        if (n2 != 0) {
            if (mcAlias == null) return null;
            mcAlias = mc;
        }
        User user = mcAlias.getUser();
        if (n2 != 0) {
            if (user == null) return null;
            user = mc.getUser();
        }
        String userName = user.getName();
        return userName;
    }

    /*
     * Exception decompiling
     */
    @MixinExposed
    public Component a(Component var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Statement already marked as first in another block
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.markFirstStatementInBlock(Op03SimpleStatement.java:461)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc.markWholeBlock(Misc.java:251)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.considerAsSimpleIf(ConditionalRewriter.java:673)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.identifyNonjumpingConditionals(ConditionalRewriter.java:56)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:722)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    private Component a(Object[] var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 10[SWITCH]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:435)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:484)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Unable to fully structure code
     */
    static {
        block21: {
            block20: {
                block19: {
                    block18: {
                        StaffRoles.o = kuzi.obf.h.b.v.a(7385914799048731124L, 7160205936454606712L, MethodHandles.lookup().lookupClass()).a(121125996198466L);
                        StaffRoles.v = new Object[38];
                        StaffRoles.w = new String[38];
                        StaffRoles.c();
                        StaffRoles.r = new HashMap<K, V>(13);
                        var11 = StaffRoles.o ^ 128873781552048L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[13];
                        var18_4 = 0;
                        var17_5 = "N$(\u00ce\u00d7v\u0011a\u0089\u00d7\u001b\u0098\u00e40V\u0017@\u00f8\u00e0\u0014\n\u0083\u0091\u00ae\u0081v\r\u00bd.'\u0089\u0080\u0083\u00e1\u00d2\u00df\u0006\u000edPSn}\u00a0~\u00b4L\\\u00b9r[\u00f7\u009b\u00ec\u00ce\u00ae\u008bBx9v@\u007f\u0004\u0084\u00beM\u009dG\u001c\u00d2+T\u001e\u00a42\u00e0\u00e2\u00aeQ\t\u0018\u00fe\u0081\u00eb\u00fd\u00f3a\u0088\u00b8)46\u00b9\u00e0\u00f0\u00ac_\u00dbb-\u00aa\u0093\u00a1&\u00c5\u0010jb\u00df\u008b|\u00b0\f\u00c0\u00172Xf\u00aeF\u0099\u00c5\u0010UqU\u00f2\u00b8L0\u00ae#\u00ed\u00b2\u000b\u00c8O\u00c2\u00f6\u0010\u008a^/\u0099\u00c4\u008b\u00a5}\u00be1\u00dc\\6)\u00b9\u00db\u0010\u0088\u0019\u0010\u00a4\u00d6K\u000b\u009c\n\u0086\u00ad\u00bf\u0014\u007f\u001c\u00f7 \u001d\u00f8X\u00e5$\u001d1?\u00bd@\u0012\u00b7\u008e\u00bc\u008a\u00ad\n\u00cf\u00fc\u00a9|\u0001b_6\u00d1\u00bcz~\u000f\u0007w\u00109\u00cc\u00a4\u00d0:a\u009f\u00e8\u00ca\u00f8\u00bb\u00a6yU\u0003\u001b q\u009ch\n\u00f3\u00c5=\u00a6\u00eb?\u0088n\u00ffg\u0010\r,^o\u00d5|:D\u001eQ\u0095$\u00f6S\u000fI\b\u0010p\u00a6\u00e9H`\u007f\u00b6\u0090\u008f4p&\u00cb,0:";
                        var19_6 = "N$(\u00ce\u00d7v\u0011a\u0089\u00d7\u001b\u0098\u00e40V\u0017@\u00f8\u00e0\u0014\n\u0083\u0091\u00ae\u0081v\r\u00bd.'\u0089\u0080\u0083\u00e1\u00d2\u00df\u0006\u000edPSn}\u00a0~\u00b4L\\\u00b9r[\u00f7\u009b\u00ec\u00ce\u00ae\u008bBx9v@\u007f\u0004\u0084\u00beM\u009dG\u001c\u00d2+T\u001e\u00a42\u00e0\u00e2\u00aeQ\t\u0018\u00fe\u0081\u00eb\u00fd\u00f3a\u0088\u00b8)46\u00b9\u00e0\u00f0\u00ac_\u00dbb-\u00aa\u0093\u00a1&\u00c5\u0010jb\u00df\u008b|\u00b0\f\u00c0\u00172Xf\u00aeF\u0099\u00c5\u0010UqU\u00f2\u00b8L0\u00ae#\u00ed\u00b2\u000b\u00c8O\u00c2\u00f6\u0010\u008a^/\u0099\u00c4\u008b\u00a5}\u00be1\u00dc\\6)\u00b9\u00db\u0010\u0088\u0019\u0010\u00a4\u00d6K\u000b\u009c\n\u0086\u00ad\u00bf\u0014\u007f\u001c\u00f7 \u001d\u00f8X\u00e5$\u001d1?\u00bd@\u0012\u00b7\u008e\u00bc\u008a\u00ad\n\u00cf\u00fc\u00a9|\u0001b_6\u00d1\u00bcz~\u000f\u0007w\u00109\u00cc\u00a4\u00d0:a\u009f\u00e8\u00ca\u00f8\u00bb\u00a6yU\u0003\u001b q\u009ch\n\u00f3\u00c5=\u00a6\u00eb?\u0088n\u00ffg\u0010\r,^o\u00d5|:D\u001eQ\u0095$\u00f6S\u000fI\b\u0010p\u00a6\u00e9H`\u007f\u00b6\u0090\u008f4p&\u00cb,0:".length();
                        var16_7 = 16;
                        var15_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block18;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = StaffRoles.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "/\u00f7n\u0094\u0082\u00e1\u001c\u00b1N\u0006\u0084%xA\u0018\u00d6\u0010\u00c8\u00e0sHr5\u000e\u00d5\t\rnDnY|v";
                            var19_6 = "/\u00f7n\u0094\u0082\u00e1\u001c\u00b1N\u0006\u0084%xA\u0018\u00d6\u0010\u00c8\u00e0sHr5\u000e\u00d5\t\rnDnY|v".length();
                            var16_7 = 16;
                            var15_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block18;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = StaffRoles.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block19;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                StaffRoles.p = var20_3;
                StaffRoles.q = new String[13];
                StaffRoles.u = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[10];
                var3_13 = 0;
                var4_14 = "3]s\u0093\u00ae\u0084&2\u00c8\u00ff\u008b\u009f!\u00d6ZG\u00c6\u00c8r\u00fau\u0086m\u00cf\u0013\u009b\u0017\u0003L\u0081\u00fa\u00fb\u00d9 \u009fV\u000fO'\u00b0^\u00ac\u0001\u0084i\u00e6\u00c0\u0085\u001f\u00ab\u00004\u0083\u0094 W\u0080j\u00e3!C\u00df\u00f0u";
                var5_15 = "3]s\u0093\u00ae\u0084&2\u00c8\u00ff\u008b\u009f!\u00d6ZG\u00c6\u00c8r\u00fau\u0086m\u00cf\u0013\u009b\u0017\u0003L\u0081\u00fa\u00fb\u00d9 \u009fV\u000fO'\u00b0^\u00ac\u0001\u0084i\u00e6\u00c0\u0085\u001f\u00ab\u00004\u0083\u0094 W\u0080j\u00e3!C\u00df\u00f0u".length();
                var2_16 = 0;
                while (true) {
                    var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                    v10 = var6_12;
                    v11 = var3_13++;
                    v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                    v13 = -1;
                    break block20;
                    break;
                }
lbl81:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    var4_14 = "\u00ec+!\u00e7y1\u008b\u00dc)\u00ed\u00fc\u0017v:\u0087I";
                    var5_15 = "\u00ec+!\u00e7y1\u008b\u00dc)\u00ed\u00fc\u0017v:\u0087I".length();
                    var2_16 = 0;
                    while (true) {
                        var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                        v10 = var6_12;
                        v11 = var3_13++;
                        v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                        v13 = 0;
                        break block20;
                        break;
                    }
                    break;
                }
lbl94:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    break block21;
                    break;
                }
            }
            var8_18 = v12;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            v14 = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
            switch (v13) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl107:
                // 1 sources

                ** continue;
            }
        }
        StaffRoles.s = var6_12;
        StaffRoles.t = new Integer[10];
    }

    private static r a(r r2) {
        return r2;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static String b(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x3653;
        if (q[n3] == null) {
            Object[] objectArray;
            try {
                Long l3 = Thread.currentThread().threadId();
                objectArray = (Object[])r.get(l3);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    r.put(l3, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/d/r", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l2 >>> 56);
            for (int i2 = 1; i2 < 8; ++i2) {
                byArray[i2] = (byte)(l2 << i2 * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = p[n3].getBytes("ISO-8859-1");
            StaffRoles.q[n3] = StaffRoles.b(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return q[n3];
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        String string2 = StaffRoles.b(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static CallSite b(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/d/r" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x4B26;
        if (t[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = s[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])u.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    u.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/d/r", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            StaffRoles.t[n3] = n4;
        }
        return t[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = StaffRoles.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/d/r" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (w[n4] != null) {
            return n4;
        }
        Object object = v[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 56;
            case 1 -> 52;
            case 2 -> 63;
            case 3 -> 33;
            case 4 -> 51;
            case 5 -> 36;
            case 6 -> 59;
            case 7 -> 14;
            case 8 -> 41;
            case 9 -> 40;
            case 10 -> 17;
            case 11 -> 10;
            case 12 -> 50;
            case 13 -> 58;
            case 14 -> 19;
            case 15 -> 2;
            case 16 -> 60;
            case 17 -> 37;
            case 18 -> 48;
            case 19 -> 23;
            case 20 -> 7;
            case 21 -> 4;
            case 22 -> 30;
            case 23 -> 28;
            case 24 -> 3;
            case 25 -> 62;
            case 26 -> 29;
            case 27 -> 22;
            case 28 -> 46;
            case 29 -> 35;
            case 30 -> 31;
            case 31 -> 16;
            case 32 -> 55;
            case 33 -> 21;
            case 34 -> 11;
            case 35 -> 25;
            case 36 -> 13;
            case 37 -> 26;
            case 38 -> 53;
            case 39 -> 1;
            case 40 -> 6;
            case 41 -> 12;
            case 42 -> 20;
            case 43 -> 9;
            case 44 -> 8;
            case 45 -> 38;
            case 46 -> 44;
            case 47 -> 32;
            case 48 -> 49;
            case 49 -> 18;
            case 50 -> 42;
            case 51 -> 47;
            case 52 -> 61;
            case 53 -> 45;
            case 54 -> 54;
            case 55 -> 24;
            case 56 -> 0;
            case 57 -> 39;
            case 58 -> 27;
            case 59 -> 43;
            case 60 -> 5;
            case 61 -> 34;
            case 62 -> 15;
            default -> 57;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        StaffRoles.w[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = v;
        v[0] = "\u001c`Z|uM\u0017`_|v";
        objectArray[1] = Integer.TYPE;
        StaffRoles.w[1] = "java/lang/Integer";
        objectArray[2] = "k\n.};'`\n+}(";
        objectArray[3] = "\u00045WPkg\b5D";
        objectArray[4] = "\n/.)\n\u0011\u0003/-)\u0007";
        objectArray[5] = "\\k~!(`)Ku.9/HE~%=u<";
        objectArray[6] = Void.TYPE;
        StaffRoles.w[6] = "java/lang/Void";
        objectArray[7] = "L Yb]FE Zb]";
        objectArray[8] = "\u001f\u0016\u0011~N\u0013\u0014\u0019\u00001/\u001d\u001f\u0012\u0004k";
        objectArray[9] = "\u0014\u001c*c\f(a<!l\u001dg\u00002*g\u0019=t";
        objectArray[10] = "6^(6L16^?j@>,\u0015?t@++dn-\u0019k";
        objectArray[11] = "o2hH9^\u001a\u0012cG(\u0011{\u001chL,K\u000f";
        objectArray[12] = "ZV\np\u0007hQY\u001b?zpB^\u0012v";
        objectArray[13] = "\u0014p_wxGaPTxi\b\u0000^_smRt";
        objectArray[14] = ",@\u001c(\f\u001b,@\u000bt\u0000\u00146\u000b\u000bj\u0000\u00011zZ3WC";
        objectArray[15] = "Inr{)\u0005Bny";
        objectArray[16] = Boolean.TYPE;
        StaffRoles.w[16] = "java/lang/Boolean";
        objectArray[17] = "T\u0006)\u0004-'_\u0006-\u0004\u001a";
        objectArray[18] = "Q5\u0010#\u0017p$\u0015\u001b,\u0006?E\u001b\u0010'\u0002e1";
        objectArray[19] = "_C$\u000fg\u0013TC,";
        objectArray[20] = "q\"?n\\Kz\":n[";
        objectArray[21] = "VWh\u001b)}#wc\u001482Byh\u001f<h6";
        objectArray[22] = "0\u0014\u0016{_aw\u000bC\"#p\t\u001a\tl\u0013re\u000bCg\u0012\u001b9\u000bEzYb1\u001b\u0010q#";
        objectArray[23] = "B#7C\u0010\f\u0010et&\u00164\u0005d'\u001fLK\u0005g+&";
        objectArray[24] = "'\n!q\u0010[`\u0015t(lH\u001e\u0004>f\\Hr\u0015tm]!wQ<g\u0016GaP}hl";
        objectArray[25] = "wiGa1@0v\u00128M\\N0V~6\u0006qr\u0010g'";
        objectArray[26] = "\t?@j\u0013\u001eN \u00153o\r01_}_\r\\ \u0015v^d\f:RcU\u0016B>\u001duo";
        objectArray[27] = "i% G\u0017G;cc\"\u0010\u007f.b0\u001bK\u0000.a<\"";
        objectArray[28] = "<+\u00000x\u0002dt\t!\u0015\u001eU.\u0001al\u001476_1vr";
        objectArray[29] = " 7\nhp\u0018g(_1\f\u000b\u0019nY3~Ybd\u0016rvb#j[}7\u0019)%\u001au\f";
        objectArray[30] = "In%'/tH$.#W%\"d4g14[l$2:N";
        objectArray[31] = "U|\u0004Yf\u0012Yh\u0007G\u000b'tC>mQ|U|\u0004Yf\u0012Yh\u0007G";
        objectArray[32] = "k\u0019\u001f\u001f*=y\u0006]\u0000I\u0002A?n{$$:\u001d@\u00026;x\u0002";
        objectArray[33] = "\u0017KsQ'~PT&\b[a.\u0011}[<xTVb\u000ee";
        objectArray[34] = "\u0012B5akTU]`8\u0017G+L*v'GG]`}&.ANd\u007fqLY\u00104e\u0017";
        objectArray[35] = "\u0002\fpB\u0001qS\u00107_}w>@wN\u0004%A\r4\u0016\u0014\u001e";
        objectArray[36] = "}2\u00018?[%m\b)RO\u00140\u001d%bBx!W.c+(;\u0010;hYf?_-R";
        Object[] objectArray2 = objectArray;
        objectArray[37] = "\u0012s\f\u0001\u0010=UlYXl.+}\u0013\u0016\\.GlY\u001d]G\u0014{\u0006\u0019\u0017|Sv\u0004\u001dl";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = StaffRoles.e(l2, l3);
            object = v[n2];
            try {
                if (!(object instanceof String)) break block2;
                StaffRoles.v[n2] = clazz = Class.forName(w[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = StaffRoles.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = StaffRoles.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = StaffRoles.e(l2, l3);
        Object object = v[n2];
        if (object instanceof String) {
            String string = w[n2];
            int n3 = string.indexOf(8);
            Class clazz = StaffRoles.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = StaffRoles.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = StaffRoles.c(clazz3, string2, clazz2)) != null) {
                    StaffRoles.v[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = StaffRoles.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        StaffRoles.v[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = StaffRoles.f(591000994483642L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = StaffRoles.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = StaffRoles.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = StaffRoles.e(l2, l3);
        Object object = v[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = w[n2];
                int n4 = string2.indexOf(8);
                clazz3 = StaffRoles.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = StaffRoles.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = StaffRoles.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        StaffRoles.v[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = StaffRoles.f(591000994483642L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = StaffRoles.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        StaffRoles.v[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = StaffRoles.f(591000994483642L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == '\u00f1' || c2 == '\u00dd' || c2 == 'g' || c2 == '\u00a4') {
                field = StaffRoles.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == '\u00f1' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == '\u00dd' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == 'g' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = StaffRoles.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == '\u00c0' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == 't' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = StaffRoles.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_2().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/d/r" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(StaffRoles.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(StaffRoles.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_2() {
        try {
            return MethodHandles.lookup().findStatic(StaffRoles.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

