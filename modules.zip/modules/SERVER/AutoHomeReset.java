// === Kuzi module: AutoHomeReset ===
// Category   : SERVER
// Description: Resets a home: /delhome <n> then /sethome <n>.
// Payload    : a.a.a.j.d.k (verified: True)

package kuzi.modules.server;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.j.d.b;
import kuzi.obf.m.r;
import kuzi.obf.p.L;
import kuzi.settings.KeyBinding;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.Minecraft;

public class AutoHomeReset
extends BaseModule {
    private final SliderSetting home;
    private final KeyBinding triggerKey;
    private boolean triggerLatch;
    private int sethomeCountdown;
    private static final long q = 97404412983519L;
    private static final Object[] x = new Object[]{"\u0010V\fNXN\u0001V!", "dh4Cj\u0002\u0011H?L{MpF4G\u007f\u0017\u0004", Boolean.TYPE, "\u0002T{yK\u0000\tTp", "X4\u001d78\u000fX4\nk4\u0000B\u007f\nu4\u0015E\u000eZ(e", "Y\b`1I}R\be1C", "`^\u001f&\u0014Ll^\f", "\u0010?KC\u001am\u0019?HC\u0011", "Pzds\u0016\u0000[zas\u0015", Integer.TYPE, "J<\u001a\u001f\u0012\u0015C<\u0019\u001f\u0012", "z}\u001d\u001fL:qr\fP-4zy\b\n", ",1p\u0000bo%1s\u0000n", "\u001f!l\tG\u0017\u0014!d", "z+\u00030UM\u000f\u000b\b?D\u0002n\u0005\u00034@X\u001a", Void.TYPE, "\u001fj#\u0007DJ\u0018s'u\u0014%\u001dg:\u0011\u0010\u001a\u0006p5J}\u001c\u0006j6I\u0019W\bihu", "\u0005 Do\u00158R;\b).>?bKiJ<\\bDjN", "X\u0010+TWH\u0018\u001f!\u0012i+$.O`3pX\u0010+TWH\u0018\u001f!\u0012", "|\u001eY5R\u001c\u007f_X`)IG_\u00065\u0012Q~\u0002T%S {RZcX\u0019&\u0000J\")", "z[\u0016OhHy\u001a\u0017\u001a\u0013\u0013A\u001f\nC|H%T\u0004@\"", "p8uI`Y(~pC\u001a\\O9`\u0018#\t*xe\u0013k5", "A\u0017\u0000\u000euTBV\u0001[\u000e\rzZ\u0011\u001cr\n\u0018U\rRu", "4^\u0019]e<7\u001f\u0018\b\u001ef\u000f\u001e\u001eR$cj\u0018GZn", "\u0002\u0015\u0010Oj\u0011U\u000e\\\tQ\u001a8\u0004\u000e\u00145\u0013\u0007\u001f\u0019\u001bn~Q\u001c\u001fG2\u0015J\u001fZOQ", "vPV\u001b~w4\\J\u001a\u0006mK\u001fN\u001bh`q]U\u0018i\u0006", "o'Bb\u0005\u0016lfC7~RTdV`\u0010Ln&Mc\u0011"};
    private static final String[] y = new String[]{null, null, "java/lang/Boolean", null, null, null, null, null, null, "java/lang/Integer", null, null, null, null, null, "java/lang/Void", null, null, null, null, null, null, null, null, null, null, null};

    public AutoHomeReset() {
        long l2 = q ^ 0x266A34D46569L;
        long l3 = l2 ^ 0x5F1F84C686A3L;
        super("AutoHomeReset", "Resets a home: /delhome <n> then /sethome <n>.", Category.SERVER);
        this.home = new SliderSetting("Home", 1.0, 1.0, 10.0, 1.0);
        this.triggerKey = new KeyBinding("Trigger Key", 71);
        this.triggerLatch = false;
        this.sethomeCountdown = -1;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.home, this.triggerKey};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void e() {
        super.e();
        this.triggerLatch = false;
        this.sethomeCountdown = -1;
    }

    @Override
    public void i() {
        block21: {
            boolean triggerDown;
            block23: {
                AutoHomeReset self;
                block22: {
                    int triggerKeyCode;
                    int n3;
                    long l2;
                    block20: {
                        block19: {
                            block17: {
                                int n4;
                                block18: {
                                    block16: {
                                        block15: {
                                            Minecraft client;
                                            block14: {
                                                long l3 = q ^ 0x2B00538D183EL;
                                                l2 = l3 ^ 0x1B247D189E3BL;
                                                n3 = kuzi.obf.j.d.b.c();
                                                client = BaseModule.a;
                                                if (n3 != 0) break block14;
                                                if (client.player == null) break block15;
                                                client = BaseModule.a;
                                            }
                                            if (client.getConnection() != null) break block16;
                                        }
                                        return;
                                    }
                                    n4 = this.sethomeCountdown--;
                                    if (n3 != 0) break block17;
                                    if (n4 <= 0) break block18;
                                    n4 = this.sethomeCountdown;
                                    if (n3 != 0) break block17;
                                    if (n4 == 0) {
                                        BaseModule.a.getConnection().sendCommand("sethome " + ((Double)this.home.a()).intValue());
                                        this.sethomeCountdown = -1;
                                    }
                                }
                                n4 = triggerKeyCode = ((Integer)this.triggerKey.a()).intValue();
                            }
                            if (n3 != 0) break block19;
                            if (triggerKeyCode != -1 && BaseModule.a.screen == null) break block20;
                            this.triggerLatch = false;
                        }
                        return;
                    }
                    Object[] objectArray = new Object[2];
                    objectArray[1] = l2;
                    objectArray[0] = triggerKeyCode;
                    triggerDown = L.a(objectArray);
                    if (n3 != 0) break block21;
                    if (!triggerDown) break block22;
                    self = this;
                    if (n3 != 0) break block23;
                    if (self.triggerLatch) break block22;
                    self = this;
                    if (n3 != 0) break block23;
                    if (self.sethomeCountdown < 0) {
                        BaseModule.a.getConnection().sendCommand("delhome " + ((Double)this.home.a()).intValue());
                        this.sethomeCountdown = 5;
                    }
                }
                self = this;
            }
            self.triggerLatch = triggerDown;
        }
    }

    private static r a(r value) {
        return value;
    }

    private static Field findDeclaredField(Class ownerClass, String fieldName, Class fieldType) {
        for (Field field : ownerClass.getDeclaredFields()) {
            if (!field.getName().equals(fieldName) || field.getType() != fieldType) continue;
            return field;
        }
        return null;
    }

    private static Field findField(Class ownerClass, String fieldName, Class fieldType) {
        Field field = AutoHomeReset.findDeclaredField(ownerClass, fieldName, fieldType);
        if (field != null) {
            return field;
        }
        Class<?>[] interfaces = ownerClass.getInterfaces();
        if (interfaces != null) {
            for (int index = 0; index < interfaces.length; ++index) {
                field = AutoHomeReset.findField(interfaces[index], fieldName, fieldType);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method findDeclaredMethod(Class ownerClass, String methodName, Class returnType, int parameterCount, Class[] expectedParameterTypes) {
        block0: for (Method method : ownerClass.getDeclaredMethods()) {
            Class<?>[] parameterTypes;
            if (!method.getName().equals(methodName) || method.getReturnType() != returnType || (parameterTypes = method.getParameterTypes()).length != parameterCount) continue;
            for (int index = 0; index < parameterCount; ++index) {
                if (parameterTypes[index] != expectedParameterTypes[index]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method findMethod(Class ownerClass, String methodName, Class returnType, int parameterCount, Class[] expectedParameterTypes) {
        Method method = AutoHomeReset.findDeclaredMethod(ownerClass, methodName, returnType, parameterCount, expectedParameterTypes);
        if (method != null) {
            return method;
        }
        Class<?>[] interfaces = ownerClass.getInterfaces();
        if (interfaces != null) {
            for (int index = 0; index < interfaces.length; ++index) {
                method = AutoHomeReset.findMethod(interfaces[index], methodName, returnType, parameterCount, expectedParameterTypes);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }
}

