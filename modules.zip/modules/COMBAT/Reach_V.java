// === Kuzi module: Reach_V ===
// Category   : COMBAT
// Description: Attack past vanilla range. A vanilla server accepts up to 6 blocks; anticheat flags long before that.
// Payload    : a.a.a.j.c.V (verified: False)

package kuzi.modules.combat;

import a.a.a.p.q;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.Optional;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.m.r;
import kuzi.obf.p.F;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.Entity;
import net.minecraft.LivingEntity;
import net.minecraft.AttributeInstance;
import net.minecraft.Player;
import net.minecraft.AABB;
import net.minecraft.HitResult;
import net.minecraft.Vec3;
import net.minecraft.ClipContext;
import net.minecraft.BlockHitResult;
import net.minecraft.EntityHitResult;
import net.minecraft.Attributes;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class Reach_V
extends BaseModule
implements kuzi.obf.g.a.q {
    private final SliderSetting range;
    private final BoolSetting blockReach;
    private final SliderSetting blockRange;
    private final BoolSetting respectValidator;
    private static final long r = 86151678977756L;
    private static final Object[] v = new Object[]{"s7\u0018AB7x7\u0013", "yLX_CxyLO\u0003Owc\u0007O\u001dObdv\u001f@\u001e", "\u007f)\b9\u0007ft)\n90", "+\u0017KZ[a\"\u0017HZW", "yvpA>z\fV{N/5mXpE+o\u0019", "\u0010?oN}\u000f\u0010?x\u0012q\u0000\ntx\fq\u0015\r\u0005*S _", "4h\u0007v!J=h\u0004v#", "4\u0011e<\u0016\u0013?\u0011g<\u0019", Integer.TYPE, "\u0002:\"u0mw\u001a)z!\"\u0016\u0014\"q%xb", Void.TYPE, "!b\u0004C\u0011;-b\u0017", ")\u000e^3\r9 \u000e]3\r", "Jl=0_1Ac,\u007f>?Jh(%", "wB;\u001f9HfB+", "V\u0018\t[K##8\u0002TZlB6\t_^66", Boolean.TYPE, "\u0019>|/\u0019\u0018\b>[", "Q*+Gn\u001cZ%:\b\u0013\u0004I\"3A", "I)\u0012N\u0014#B)\u001a", ":<8&\u0011dO\u001c3)\u0000+.\u00128\"\u0004qZ", "8tqwXr62m\t\u0001\u0013cu9e\u0014)8-{k", "5ca+c#5ky%\u000f`\f!i.}g5{y%3", "'qa$0@'yy*\\\u0012\u001ed:p!\u000b|il)a{%mrtgB\"7a(\\", "{\u0000ZUuD{\bB[\u0019\u0018BDVCv\u001c&\u0012]W~", "\tIG\u0017D\u0005_\u0011\u0004\f%U4L\u0002B\u001aB\n\u0010C\u0016\u001a?", "O\u0004|\\=eO\fdRQ8vFtY#!O\u001cdRm", "@E\\\r\u0003[V\u001a\u001aZe!k>mu9j@E\\\r\u0003[V\u001a\u001aZ", "`\u0004{\u000e(\u00194U`QN\f\u000bPx\u000f+\fj\ng\u0001uga\u0007mUs\u001cs\u0001mAN", "i\u00173\u0017\n1i\u001f+\u0019fcP\u0002hC\u001bz2\u000f>\u001a[\no\u000e+\u0003\u000b20\u0002gCf", "0S\u0010S\u0010\u00040[\b]|V\t\u0014\u0005ADAw\u0012\u001fW\u001d?6T\u0001\u0002\u0002A0N\u0017[|", "jmE/C^je]!/\u001cS)I9@\u00067\u007fB-H", ":&Ns>?x Ow\u0002(\nn\t\"?\u007fw2K{nA", "\u0015Z.Z`yC\u0002mA\u0001((_k\u000f>>\u0016\u0003*[>C", "l+\u007f;jWbmcE>6c&38*TnpjxZ\toes(bVc)3E", "#hL.\u0003~+e^ e)\u0012t\u0000x\u00183pyV!XCx%].X8j#]:e"};
    private static final String[] w = new String[]{null, null, null, null, null, null, null, null, "java/lang/Integer", null, "java/lang/Void", null, null, null, null, null, "java/lang/Boolean", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null};

    public Reach_V() {
        long l2 = r ^ 0x1F053C0F5710L;
        long l3 = l2 ^ 0x70BCF74A2AD9L;
        super("Reach", "Attack past vanilla range. A vanilla server accepts up to 6 blocks; anticheat flags long before that.", Category.COMBAT);
        this.range = new SliderSetting("Range", 3.5, 3.0, 6.0, 0.1);
        this.blockReach = new BoolSetting("Block Reach", false);
        this.blockRange = new SliderSetting("Block Range", 5.0, 4.5, 5.5, 0.1);
        this.respectValidator = new BoolSetting("Respect Validator", false);
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.range, this.blockReach, this.blockRange, this.respectValidator};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public boolean b(Object[] objectArray) {
        return true;
    }

    @Override
    public void d() {
        Client.a().a(kuzi.obf.g.a.q.class, this);
    }

    @Override
    public void e() {
        long l2 = r ^ 0x30AB65AF213FL;
        long l3 = l2 ^ 0x30EE88AFBCE0L;
        Client.a().b(kuzi.obf.g.a.q.class, this);
        BaseModule.a.execute(() -> this.lambda$onDisable$0(l3));
    }

    @Override
    public void h() {
        long l2 = r ^ 0x6F4665DA9A21L;
        long l3 = l2 ^ 0x104D947D77ACL;
        BaseModule.a.execute(() -> this.lambda$onWorldLeave$1(l3));
    }

    @Override
    public void a() {
        long l2;
        long l3 = l2 = r ^ 0x619FF918B0AL;
        long l4 = l3 ^ 0x2924C9A2AE9DL;
        long l5 = l3 ^ 0x271F0812B76FL;
        long l6 = l3 ^ 0x177BC98851CEL;
        if (BaseModule.a.player == null || BaseModule.a.level == null) {
            return;
        }
        Object[] objectArray = new Object[2];
        objectArray[1] = (Boolean)this.blockReach.a() != false ? (Double)this.blockRange.a() : 4.5;
        objectArray[0] = l4;
        this.applyBlockRange(objectArray);
        if (BaseModule.a.screen != null || !BaseModule.a.options.keyAttack.isDown()) {
            return;
        }
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l5;
        LivingEntity target = this.findTarget(objectArray2);
        if (target == null) {
            return;
        }
        if (((Boolean)this.respectValidator.a()).booleanValue()) {
            Object[] objectArray3 = new Object[3];
            objectArray3[2] = target;
            objectArray3[1] = BaseModule.a;
            objectArray3[0] = l6;
            if (!a.a.a.p.q.b((Object[])objectArray3)) {
                return;
            }
        }
        BaseModule.a.hitResult = new EntityHitResult((Entity)target);
        BaseModule.a.crosshairPickEntity = target;
    }

    private void applyBlockRange(Object[] objectArray) {
        block6: {
            AttributeInstance attribute;
            double newRange;
            block7: {
                int n2;
                AttributeInstance attributeCopy;
                block4: {
                    int n3;
                    block5: {
                        long l2 = (Long)objectArray[0];
                        newRange = (Double)objectArray[1];
                        l2 = r ^ l2;
                        n3 = 66;
                        if (BaseModule.a.player == null) {
                            return;
                        }
                        attribute = attributeCopy = BaseModule.a.player.getAttribute(Attributes.BLOCK_INTERACTION_RANGE);
                        n2 = n3;
                        if (l2 <= 0L) break block4;
                        if (n2 == 0) break block5;
                        if (attribute == null) break block6;
                        attribute = attributeCopy;
                    }
                    n2 = n3;
                }
                if (n2 == 0) break block7;
                if (attribute.getBaseValue() == newRange) break block6;
                attribute = attributeCopy;
            }
            attribute.setBaseValue(newRange);
        }
    }

    private LivingEntity findTarget(Object[] objectArray) {
        LivingEntity result;
        block15: {
            long l2 = (Long)objectArray[0];
            l2 = r ^ l2;
            float partialTick = BaseModule.a.getDeltaTracker().getGameTimeDeltaPartialTick(false);
            Vec3 eyePos = BaseModule.a.player.getEyePosition(partialTick);
            Vec3 lookVec = BaseModule.a.player.getViewVector(partialTick);
            double rangeValue = (Double)this.range.a();
            Vec3 endPos = eyePos.add(lookVec.scale(rangeValue));
            double maxDistSq = rangeValue * rangeValue;
            boolean bl = false;
            BlockHitResult blockHit = BaseModule.a.level.clip(new ClipContext(eyePos, endPos, ClipContext.mc3960.OUTLINE, ClipContext.mc242.NONE, (Entity)BaseModule.a.player));
            if (blockHit.getType() != HitResult.mc240.MISS) {
                maxDistSq = Math.min(maxDistSq, eyePos.distanceToSqr(blockHit.getLocation()));
            }
            LivingEntity bestTarget = null;
            double bestDistSq = Double.MAX_VALUE;
            AABB searchBox = BaseModule.a.player.getBoundingBox().expandTowards(lookVec.scale(rangeValue)).inflate(1.0, 1.0, 1.0);
            Iterator iterator = BaseModule.a.level.getEntities((Entity)BaseModule.a.player, searchBox, Reach_V::lambda$findTarget$2).iterator();
            block0: while (true) {
                boolean bl2 = iterator.hasNext();
                while (bl2) {
                    block19: {
                        double d5;
                        block20: {
                            double d6;
                            double d7;
                            LivingEntity candidate;
                            block18: {
                                Object object;
                                LivingEntity targetEntity;
                                block17: {
                                    int n2;
                                    block16: {
                                        Entity entity = (Entity)iterator.next();
                                        result = candidate = (LivingEntity)entity;
                                        if (l2 < 0L || bl) break block15;
                                        n2 = result.isAlive();
                                        boolean bl3 = bl;
                                        if (l2 > 0L) {
                                            if (!bl3) {
                                                if (n2 == 0) continue block0;
                                                float healthDelta = candidate.getHealth() - 0.0f;
                                                n2 = healthDelta == 0.0f ? 0 : (healthDelta < 0.0f ? -1 : 1);
                                            }
                                            bl3 = bl;
                                        }
                                        if (bl3) break block16;
                                        if (n2 <= 0 && l2 >= 0L) continue block0;
                                        targetEntity = candidate;
                                        if (bl) break block17;
                                        n2 = targetEntity instanceof Player;
                                    }
                                    if (n2 != 0) {
                                        object = (Player)candidate;
                                        targetEntity = object;
                                        if (!bl) {
                                            if (F.c(targetEntity.getName().getString())) continue block0;
                                        }
                                    } else {
                                        targetEntity = candidate;
                                    }
                                }
                                if (((Optional)(object = targetEntity.getBoundingBox().inflate((double)candidate.getPickRadius()).clip(eyePos, endPos))).isEmpty()) continue block0;
                                d7 = eyePos.distanceToSqr((Vec3)((Optional)object).get());
                                d6 = d7 == maxDistSq ? 0 : (d7 > maxDistSq ? 1 : -1);
                                if (bl) break block18;
                                if (d6 > 0) continue block0;
                                if (l2 < 0L) break block19;
                                d5 = d7;
                                if (bl) break block20;
                                double d8 = d5 - bestDistSq;
                                d6 = d8 == 0.0 ? 0 : (d8 > 0.0 ? 1 : -1);
                            }
                            if (d6 >= 0) continue block0;
                            bestTarget = candidate;
                            d5 = d7;
                        }
                        bestDistSq = d5;
                    }
                    bl2 = bl;
                    if (l2 <= 0L) continue;
                    if (bl2) break block0;
                    continue block0;
                }
                break;
            }
            result = bestTarget;
        }
        return result;
    }

    private static boolean lambda$findTarget$2(Entity mc12972) {
        return mc12972 instanceof LivingEntity;
    }

    private void lambda$onWorldLeave$1(long l2) {
        long l3 = (l2 = r ^ l2) ^ 0x1E6C07AC2EC6L;
        Object[] objectArray = new Object[2];
        objectArray[1] = 4.5;
        objectArray[0] = l3;
        this.applyBlockRange(objectArray);
    }

    private void lambda$onDisable$0(long l2) {
        long l3 = (l2 = r ^ l2) ^ 0x61221B0B5E94L;
        Object[] objectArray = new Object[2];
        objectArray[1] = 4.5;
        objectArray[0] = l3;
        this.applyBlockRange(objectArray);
    }

    private static r a(r r2) {
        return r2;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = Reach_V.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = Reach_V.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = Reach_V.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = Reach_V.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }
}

