// === Kuzi module: FakeLag ===
// Category   : COMBAT
// Description: Delays your outbound packets so you appear to lag ù like LiquidBounce (uniform, Grim-safe).
// Payload    : a.a.a.j.c.L (verified: True)

package kuzi.modules.combat;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Iterator;
import java.util.concurrent.ThreadLocalRandom;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.module.Module;
import kuzi.obf.g.a.h;
import kuzi.obf.g.a.i;
import kuzi.obf.g.a.v;
import kuzi.obf.g.a.w;
import kuzi.obf.h.b.l;
import kuzi.obf.j.c.ac;
import kuzi.obf.j.c.k;
import kuzi.obf.m.r;
import kuzi.obf.p.F;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.Player;
import net.minecraft.Vec3;
import net.minecraft.Packet;
import net.minecraft.ClientboundExplodePacket;
import net.minecraft.ClientboundPlayerPositionPacket;
import net.minecraft.ClientboundSetEntityMotionPacket;
import net.minecraft.ClientboundSetHealthPacket;
import net.minecraft.ServerboundChatPacket;
import net.minecraft.ServerboundContainerClickPacket;
import net.minecraft.ServerboundInteractPacket;
import net.minecraft.ServerboundMovePlayerPacket;
import net.minecraft.ServerboundPlayerActionPacket;
import net.minecraft.ServerboundSwingPacket;
import net.minecraft.ServerboundUseItemOnPacket;
import net.minecraft.Minecraft;
import net.minecraft.ServerboundChatCommandPacket;
import net.minecraft.ServerboundChatCommandSignedPacket;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class FakeLag
extends BaseModule
implements w,
v,
Module {
    private final l modeSetting;
    private final SliderSetting range;
    private final SliderSetting minDelayMs;
    private final SliderSetting maxDelayMs;
    private final SliderSetting recoilMs;
    private final Deque delayedPackets;
    private volatile boolean sendingDirectly;
    private volatile boolean flushRequested;
    private volatile boolean delayActive;
    private volatile long lastInteractMs;
    private volatile long currentDelayMs;
    private static final long x = 7106824261981L;
    private static final long B;
    private static final Object[] C;
    private static final String[] D;

    public FakeLag() {
        long l2 = x ^ 0x44AA773E54C6L;
        long l3 = l2 ^ 0x633FD3FF9E8EL;
        super("FakeLag", "Delays your outbound packets so you appear to lag \u2014 like LiquidBounce (uniform, Grim-safe).", Category.COMBAT);
        this.modeSetting = new l("Mode", k.DYNAMIC, k.class);
        this.range = new SliderSetting("Range", 4.0, 1.0, 10.0, 0.5);
        this.minDelayMs = new SliderSetting("Min Delay (ms)", 300.0, 0.0, 1000.0, 10.0);
        this.maxDelayMs = new SliderSetting("Max Delay (ms)", 600.0, 0.0, 1000.0, 10.0);
        this.recoilMs = new SliderSetting("Recoil (ms)", 250.0, 0.0, 1000.0, 10.0);
        this.delayedPackets = new ArrayDeque();
        this.sendingDirectly = false;
        this.flushRequested = false;
        this.delayActive = false;
        this.lastInteractMs = 0L;
        this.currentDelayMs = B;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.modeSetting, this.range, this.minDelayMs, this.maxDelayMs, this.recoilMs};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void d() {
        long l2 = x ^ 0x6DFB13CAF690L;
        long l3 = l2 ^ 0x20D9CE6B40BFL;
        Client.a().a(w.class, this);
        Client.a().a(v.class, this);
        Client.a().a(Module.class, this);
        Deque deque = this.delayedPackets;
        synchronized (deque) {
            this.delayedPackets.clear();
        }
        this.sendingDirectly = false;
        this.flushRequested = false;
        this.delayActive = false;
        this.lastInteractMs = 0L;
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.currentDelayMs = this.a(objectArray);
        super.d();
    }

    @Override
    public void e() {
        long l2 = x ^ 0x78870A2B96BEL;
        long l3 = l2 ^ 0x3044E9D75A52L;
        Client.a().b(w.class, this);
        Client.a().b(v.class, this);
        Client.a().b(Module.class, this);
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.a(objectArray);
        super.e();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void a(i event) {
        boolean bl;
        long l2;
        long l3 = l2 = x ^ 0x79D6F617FE4EL;
        long l4 = l3 ^ 0x7BFCFCB40835L;
        long l5 = l3 ^ 0x311515EB32A2L;
        boolean bl2 = false;
        if (this.sendingDirectly) {
            return;
        }
        Packet packet = event.c;
        if (packet instanceof ServerboundChatPacket || packet instanceof ServerboundChatCommandSignedPacket || packet instanceof ServerboundChatCommandPacket) {
            return;
        }
        if (packet instanceof ServerboundInteractPacket || packet instanceof ServerboundSwingPacket || packet instanceof ServerboundUseItemOnPacket || packet instanceof ServerboundPlayerActionPacket || packet instanceof ServerboundContainerClickPacket) {
            Object[] objectArray = new Object[1];
            objectArray[0] = l5;
            this.a(objectArray);
            this.lastInteractMs = System.currentTimeMillis();
            return;
        }
        Object[] objectArray = new Object[1];
        objectArray[0] = l4;
        if (!this.f(objectArray)) {
            Object[] objectArray2 = new Object[1];
            objectArray2[0] = l5;
            this.a(objectArray2);
            return;
        }
        if (System.currentTimeMillis() - this.lastInteractMs < ((Double)this.recoilMs.a()).longValue()) {
            return;
        }
        boolean bl3 = bl = this.modeSetting.a() == k.CONSTANT || this.delayActive;
        if (!bl) {
            Object[] objectArray3 = new Object[1];
            objectArray3[0] = l5;
            this.a(objectArray3);
            return;
        }
        event.a();
        Deque deque = this.delayedPackets;
        synchronized (deque) {
            this.delayedPackets.addLast(new ac(packet, System.currentTimeMillis()));
        }
    }

    @Override
    public void a(h event) {
        block8: {
            block3: {
                Packet candidatePacket;
                block7: {
                    boolean bl;
                    Packet packet;
                    block5: {
                        boolean bl2;
                        block6: {
                            block4: {
                                block2: {
                                    packet = event.c;
                                    bl2 = false;
                                    bl = packet instanceof ClientboundPlayerPositionPacket;
                                    if (bl2) break block2;
                                    if (bl) break block3;
                                    bl = packet instanceof ClientboundSetHealthPacket;
                                }
                                if (bl2) break block4;
                                if (bl) break block3;
                                bl = packet instanceof ClientboundExplodePacket;
                            }
                            if (bl2) break block5;
                            if (!bl) break block6;
                            ClientboundExplodePacket explodePacket = (ClientboundExplodePacket)packet;
                            bl = explodePacket.comp_2884().isPresent();
                            if (bl2) break block5;
                            if (bl) break block3;
                        }
                        candidatePacket = packet;
                        if (bl2) break block7;
                        bl = candidatePacket instanceof ClientboundSetEntityMotionPacket;
                    }
                    if (!bl) break block8;
                    candidatePacket = packet;
                }
                ClientboundSetEntityMotionPacket motionPacket = (ClientboundSetEntityMotionPacket)candidatePacket;
                if (BaseModule.a.player == null || motionPacket.getId() != BaseModule.a.player.getId()) break block8;
            }
            this.flushRequested = true;
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Unable to fully structure code
     */
    @Override
    public void b() {
        v0 = var1_1 = FakeLag.x ^ 33089641351577L;
        var3_2 = v0 ^ 91787784790244L;
        var5_3 = v0 ^ 91511088758710L;
        var7_4 = v0 ^ 95501478086005L;
        var9_5 = 66;
        if (BaseModule.a.player == null || BaseModule.a.level == null || BaseModule.a.getConnection() == null) {
            v1 = new Object[1];
            v1[0] = var7_4;
            this.a(v1);
            this.delayActive = false;
            this.flushRequested = false;
            return;
        }
        if (this.flushRequested) {
            this.flushRequested = false;
            v2 = new Object[1];
            v2[0] = var7_4;
            this.a(v2);
            this.lastInteractMs = System.currentTimeMillis();
        }
        if (this.modeSetting.a() == k.CONSTANT) ** GOTO lbl-1000
        v3 = new Object[1];
        v3[0] = var3_2;
        if (this.a(v3)) lbl-1000:
        // 2 sources

        {
            v4 = true;
        } else {
            v4 = false;
        }
        this.delayActive = v4;
        var10_6 = System.currentTimeMillis();
        var13_7 = this.delayedPackets;
        synchronized (var13_7) {
            var12_8 = (ac)this.delayedPackets.peekFirst();
        }
        if (var12_8 != null && var10_6 - var12_8.bB() >= this.currentDelayMs) {
            v5 = new Object[1];
            v5[0] = var7_4;
            this.a(v5);
            v6 = new Object[1];
            v6[0] = var5_3;
            this.currentDelayMs = this.a(v6);
        }
        if (this.modeSetting.a() == k.DYNAMIC && !this.delayActive) {
            v7 = new Object[1];
            v7[0] = var7_4;
            this.a(v7);
        }
    }

    /*
     * Unable to fully structure code
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean a(Object[] var1_1) {
        block23: {
            block24: {
                block20: {
                    block19: {
                        var2_2 = (Long)var1_1[0];
                        v0 = var2_2 = FakeLag.x ^ var2_2;
                        var4_3 = v0 ^ 83016624038941L;
                        var6_4 = v0 ^ 46376365491502L;
                        var8_5 = 66;
                        if (BaseModule.a.player == null) return false;
                        if (BaseModule.a.level == null) {
                            return false;
                        }
                        var9_6 = (Double)this.range.a();
                        var11_7 = BaseModule.a.player.position();
                        v1 = new Object[3];
                        v1[2] = var9_6;
                        v1[1] = var4_3;
                        v1[0] = var11_7;
                        if (this.a(v1) == null) {
                            return false;
                        }
                        v2 = new Object[1];
                        v2[0] = var6_4;
                        var12_8 = this.a(v2);
                        if (var12_8 == null) {
                            return true;
                        }
                        var13_9 = BaseModule.a.player.getBoundingBox().move(var12_8.x - var11_7.x, var12_8.y - var11_7.y, var12_8.z - var11_7.z);
                        var14_10 = 1.7976931348623157E308;
                        var16_11 = 1.7976931348623157E308;
                        var18_12 = 0;
                        var19_13 = 0;
                        for (Player var21_15 : BaseModule.a.level.players()) {
                            block22: {
                                block21: {
                                    v3 = var8_5;
                                    if (var2_2 <= 0L) break block19;
                                    if (v3 == 0) break block20;
                                    v4 = var21_15;
                                    if (var2_2 >= 0L) {
                                        if (v4 == BaseModule.a.player) continue;
                                        v4 = var21_15;
                                    }
                                    if (!v4.isAlive() && var2_2 >= 0L || F.c(var21_15.getName().getString()) || (var23_17 = (var22_16 = var21_15.position()).distanceTo(var12_8)) > var9_6 && var2_2 > 0L) continue;
                                    v5 = 1;
                                    if (var2_2 > 0L) {
                                        var18_12 = v5;
                                        v5 = var23_17 == var14_10 ? 0 : (var23_17 < var14_10 ? -1 : 1);
                                    }
                                    if (v5 < 0) {
                                        var14_10 = var23_17;
                                    }
                                    var25_18 = var22_16.distanceTo(var11_7);
                                    v6 = var25_18 == var16_11 ? 0 : (var25_18 < var16_11 ? -1 : 1);
                                    v7 = var8_5;
                                    if (var2_2 > 0L) {
                                        if (v7 != 0) {
                                            if (v6 < 0) {
                                                var16_11 = var25_18;
                                            }
                                            v6 = (double)var21_15.getBoundingBox().intersects(var13_9);
                                        }
                                        v7 = var8_5;
                                    }
                                    if (v7 == 0) break block21;
                                    if (v6 == false) break block22;
                                    v6 = (double)true;
                                }
                                var19_13 = (int)v6;
                            }
                            v3 = var8_5;
                            if (var2_2 >= 0L) {
                                if (v3 != 0) continue;
                            }
                            break block19;
                        }
                        v3 = var18_12;
                    }
                    v8 = var8_5;
                    if (var2_2 <= 0L) break block23;
                    if (v8 != 0) {
                        if (v3 == 0) {
                            return false;
                        } else {
                            ** GOTO lbl74
                        }
                    }
                    break block24;
                }
                v3 = var14_10 == var16_11 ? 0 : (var14_10 < var16_11 ? -1 : 1);
            }
            v8 = var8_5;
        }
        if (var2_2 > 0L) {
            if (v8 != 0) {
                if (v3 < 0) return (boolean)0;
                v3 = var19_13;
            }
            v8 = var8_5;
        }
        if (v8 == 0) return (boolean)v3;
        if (v3 != 0) return (boolean)0;
        return (boolean)1;
    }

    private Player a(Object[] objectArray) {
        Player mc16572;
        block12: {
            Vec3 origin = (Vec3)objectArray[0];
            long l2 = (Long)objectArray[1];
            double d2 = (Double)objectArray[2];
            l2 = x ^ l2;
            double d3 = d2 * d2;
            Player mc16573 = null;
            boolean bl = false;
            double d4 = Double.MAX_VALUE;
            Iterator iterator = BaseModule.a.level.players().iterator();
            block0: while (true) {
                boolean bl2 = iterator.hasNext();
                while (bl2) {
                    block16: {
                        Player mc16574;
                        block17: {
                            double d5;
                            block18: {
                                double d6;
                                double d7;
                                block15: {
                                    Player mc16575;
                                    block14: {
                                        boolean bl3;
                                        block13: {
                                            Player mc16576;
                                            mc16572 = mc16574 = (Player)iterator.next();
                                            if (l2 < 0L) break block12;
                                            boolean bl4 = bl;
                                            if (l2 > 0L) {
                                                if (bl4) break block12;
                                                bl4 = bl;
                                            }
                                            if (!bl4) {
                                                if (mc16572 == BaseModule.a.player) continue block0;
                                                mc16576 = mc16574;
                                            }
                                            bl3 = mc16576.isAlive();
                                            if (bl) break block13;
                                            if (!bl3 && l2 > 0L) continue block0;
                                            mc16575 = mc16574;
                                            if (bl) break block14;
                                            bl3 = F.c(mc16575.getName().getString());
                                        }
                                        if (bl3) continue block0;
                                        mc16575 = mc16574;
                                    }
                                    d7 = mc16575.position().distanceToSqr(origin);
                                    d6 = d7 == d3 ? 0 : (d7 < d3 ? -1 : 1);
                                    if (bl) break block15;
                                    if (d6 > 0) break block16;
                                    if (l2 < 0L) break block17;
                                    d5 = d7;
                                    if (bl) break block18;
                                    double d8 = d5 - d4;
                                    d6 = d8 == 0.0 ? 0 : (d8 < 0.0 ? -1 : 1);
                                }
                                if (d6 >= 0) break block16;
                                d5 = d7;
                            }
                            d4 = d5;
                        }
                        mc16573 = mc16574;
                    }
                    bl2 = bl;
                    if (l2 < 0L) continue;
                    if (bl2) break block0;
                    continue block0;
                }
                break;
            }
            mc16572 = mc16573;
        }
        return mc16572;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Unable to fully structure code
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private Vec3 a(Object[] var1_1) {
        var2_2 = (Long)var1_1[0];
        var2_2 = FakeLag.x ^ var2_2;
        var5_3 = this.delayedPackets;
        synchronized (var5_3) {
            var4_4 = 66;
            for (ac entry : this.delayedPackets) {
                block13: {
                    block14: {
                        block12: {
                            block15: {
                                packet = entry.bA();
                                if (var4_4 == 0) return null;
                                v0 = packet;
                                if (var4_4 == 0) break block12;
                                break block15;
                                catch (r v1) {
                                    throw FakeLag.a(v1);
                                }
                            }
                            try {
                                block16: {
                                    v2 = v0 instanceof ServerboundMovePlayerPacket;
                                    if (var2_2 < 0L) break block13;
                                    if (v2 == 0) break block14;
                                    break block16;
                                    catch (r v3) {
                                        throw FakeLag.a(v3);
                                    }
                                }
                                v0 = packet;
                            }
                            catch (r v4) {
                                throw FakeLag.a(v4);
                            }
                        }
                        movePacket = (ServerboundMovePlayerPacket)v0;
                        v2 = movePacket.hasPosition();
                        if (var2_2 > 0L) {
                            if (v2 != 0) {
                                return new Vec3(movePacket.getX(0.0), movePacket.getY(0.0), movePacket.getZ(0.0));
                            } else {
                                ** GOTO lbl38
                            }
                        }
                        break block13;
                    }
                    v2 = var4_4;
                }
                if (v2 != 0) continue;
            }
            // MONITOREXIT @DISABLED, blocks:[0, 4] lbl40 : MonitorExitStatement: MONITOREXIT : var5_3
            if (var2_2 < 0L) return null;
        }
        return null;
    }

    private boolean f(Object[] objectArray) {
        boolean bl;
        boolean bl2;
        block20: {
            boolean bl3;
            block21: {
                block22: {
                    block19: {
                        Minecraft mc3102;
                        long l2;
                        block18: {
                            boolean bl4;
                            block14: {
                                block15: {
                                    block17: {
                                        boolean bl5;
                                        block16: {
                                            l2 = (Long)objectArray[0];
                                            l2 = x ^ l2;
                                            bl3 = false;
                                            if (BaseModule.a.player == null) {
                                                return false;
                                            }
                                            mc3102 = BaseModule.a;
                                            bl4 = bl3;
                                            if (l2 <= 0L) break block14;
                                            if (bl4) break block15;
                                            bl5 = mc3102.player.isAlive();
                                            if (l2 <= 0L) break block16;
                                            if (bl5) break block17;
                                            bl5 = false;
                                        }
                                        return bl5;
                                    }
                                    mc3102 = BaseModule.a;
                                }
                                if (l2 < 0L) break block18;
                                bl4 = bl3;
                            }
                            if (!bl4) {
                                if (mc3102.screen != null) {
                                    return false;
                                }
                                mc3102 = BaseModule.a;
                            }
                        }
                        if (mc3102.player.isInWater()) break block19;
                        bl2 = BaseModule.a.player.isUnderWater();
                        bl = bl3;
                        if (l2 <= 0L) break block20;
                        if (bl) break block21;
                        if (!bl2) break block22;
                    }
                    return false;
                }
                bl2 = BaseModule.a.player.isUsingItem();
            }
            bl = bl3;
        }
        if (!bl) {
            if (bl2) {
                return false;
            }
            bl2 = true;
        }
        return bl2;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = (l2 = x ^ l2) ^ 0x6791A6D0DBF9L;
        boolean bl = false;
        block3: while (true) {
            Packet packet;
            Deque deque = this.delayedPackets;
            synchronized (deque) {
                ac ac2 = (ac)this.delayedPackets.pollFirst();
                packet = ac2 == null ? null : ac2.bA();
            }
            do {
                if (l2 <= 0L) continue block3;
                if (packet == null) continue;
                Object[] objectArray2 = new Object[2];
                objectArray2[1] = packet;
                objectArray2[0] = l3;
                this.b(objectArray2);
                continue block3;
            } while (l2 < 0L);
            break;
        }
    }

    private void b(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        Packet packet = (Packet)objectArray[1];
        l2 = x ^ l2;
        int n2 = 66;
        if (BaseModule.a.getConnection() == null) {
            return;
        }
        this.sendingDirectly = true;
        try {
            BaseModule.a.getConnection().send(packet);
        }
        finally {
            this.sendingDirectly = false;
        }
    }

    private long a(Object[] objectArray) {
        long l2;
        long l3 = (Long)objectArray[0];
        l3 = x ^ l3;
        long minDelay = ((Double)this.minDelayMs.a()).longValue();
        int n2 = 66;
        long l5 = l2 = ((Double)this.maxDelayMs.a()).longValue();
        long jitter = minDelay;
        if (n2 != 0) {
            if (l5 <= jitter) {
                return minDelay;
            }
            l5 = minDelay;
            jitter = ThreadLocalRandom.current().nextLong(l2 - minDelay + 1L);
        }
        return l5 + jitter;
    }

    static {
        C = new Object[]{"\u001862\\\t\u000b\u001369", "X\u0019\rH\u001c}X\u0019\u001a\u0014\u0010rBR\u001a\n\u0010gE#JWA", "\u0007,V\u001e\u0000\u000e\f,T\u001e\u000f", Integer.TYPE, "e\u0010\u001fK )n\u0010\u001dK\r", "%0,\u001e82)0?", Boolean.TYPE, "i\u0014\t\u0017prx\u0014.", "`dt\fi\\kkeC\u0014Dxll\n", "]]PCZ\u0006(}[LKIIsPGO\u0013=", "q%=W\u0000-q%*\u000b\f\"kn*\u0015\f7l\u001f{M^", "z-\u00041{\u0006\u000f\r\u000f>jIn\u0003\u00045n\u0013\u001a", "iM!LKniM6\u0010Gas\u00066\u000eGttwdT\u00130", "6G\nnwB?G\tn{", "hXR^\u0013@aXQ^\u0013", "o.Sm\u000e\u007fd!B\"oqo*Fx", Long.TYPE, "!<n&0o(<m&=", "h(\t-Y\rc(\u000b-S", "K\u0015r\u007ft=@\u0015z", "zR)Mu2\u000fr\"Bd}n|)I`'\u001a", Void.TYPE, "\u0013y'\\\fI\rq=\u0013fY\bm4", "ic0v[,bc2v[a", "&C\twq\u0001&C\u001e+}\u000e<\b\u001e5}\u001b;yOl%^", "MI}8n\n8iv7\u007fEYg}<{\u001f-", "]`\u001ctf\u001f(@\u0017{wPIN\u001cps\n=", "$N_\u001c1zQnT\u0013 50`_\u0018$oD", "\u001d:G@\u0004\u0003h\u001aLO\u0015L\t\u0014GD\u0011\u0016}", "{\u0002Y#xY\u000e\"R,i\u0016o,Y'mL\u001b", "ZHAY'3\u000e\u001a]SU8aOWVe(\u0007DD\u000b4", "\u000b\u007fgC\u0001\\_-{IsD0ueFNSU-g\u0016\u000f-\u000fw=UO@\u000f(=Ms", ", \\v,\u0001xr@|^\t\u0017x\u0006n.\niuK$4", "sl(\u00076W'>4\rDXHop\u00018\\#xvWu", "Q\u0016\\\bo\u007f\u0005D@\u0002\u001dhjN\u0006\u0010mt\u0014CKZw", "[]8\u001b WN]?\rL|p\"\u000e;\u0005qkd9^!K[\u0004,^&]", "\u0000C+B\u000f;T\u00117H}#;I)G@4^\u0011+\u0017\u0001J\u0007K!EC{WI6@}", "\u0019Jwo\u001e\t\u0006_r5y\r<$v5\u0016\u001b\fOa3@Vv", "ja_\u0018\"UluW\u0013\\[S5ZN%A/mQ@.1", "Z8\b(\u001f+\u000ej\u0014\"m'am\u000f-\u0003dP=\r:\u0006", "\t\r8\u0007ss]_$\r\u0001y2X?\u0002o<\u0003\b=\u0015j", "\u0019G`\u000eS\u0002M\u0015|\u0004!\u001a\"Mb\u000b\u001c\rG\u0015`[]sOJ=\u0005\u001cJ\u001f^c\u001b!", "g;y`)\u00063iej[\u0019\\1{ef\t9iy5'w`3sgeF01db[", "\u0002B\u0005\u001bG\u0011V\u0010\u0019\u00115\n9H\u0007\u001e\b\u001e\\\u0010\u0005NI`TOX\u0010\bY\u0004[\u0006\u000e5", "JzEFpW\u001e(YL\u0002Zq/BCl\u0018@\u007f@Ti", "o\u0014\u0017[\u001f`&X\u000bOnb^\r\b\u0007\u0016;0\u0007\r\u0002\u0000\u000b", "]o/\u0005s4\t=3\u000f\u0001,fe-\u0000<;\u0003=/P}E\f8&\u0010{.\u001b>p]\u0001", "ec\u0002O2j(a\r*<Qaa\fAe3!,L\u001b", "\u0012\u0000Wt\u0012qFRK~`\u007f)\u0003\u000fr\u001czB\u0014\t$Q", ";\u0011pQ9noCl[Kx\u0000I*I;e~Dg\u0003!", "75QEDncgMO6v\f?S@\u000baigQ\u0010J\u001f<&VJV~b3PL6", "{98QB6/k$[0\"@;2C^z}1n_I", "\u001dIZ\u007f s\bI]iL_ 6~F\rXq\u001c\u000en0\u007f\u0011\t\u000ei&", "VzU8l\u0005\u0002(I2\u001e\fm\"\u000f n\u000e\u0013/Bjt", "@f^~D\u001dKn\u0001j&*k\u0013*[za@f^~D\u001dKn\u0001j", "qOzIS)q\bwL?-M\rvJ\\*#[jZ]FqQx[\u0001w!So^?", "m_Y\\\u0003M9\rEVqUV\rC\f\f_.IC\nI<mJ\u0006H\u0012D)J\u0000\rq", "_\u0019![\u00019Y\r)P\u007f6fM$\r\u0006-\u001a\u0015/\u0003\r]", "\u0012M\u001fQ\u0017*_O\u00104\u0014\u0011L\u0014B\t\u000et\u0014\u0016\u0012Hp|KKL\tI,_\u0015R4", "]:\u0003{\"\u001cB/\u0006!E\u0018{T\b')\u0015K$Vn&\u00142"};
        D = new String[]{null, null, null, "java/lang/Integer", null, null, "java/lang/Boolean", null, null, null, null, null, null, null, null, null, "java/lang/Long", null, null, null, null, "java/lang/Void", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null};
        B = 400L;
    }

    private static r a(r r2) {
        return r2;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = FakeLag.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = FakeLag.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = FakeLag.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = FakeLag.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }
}

