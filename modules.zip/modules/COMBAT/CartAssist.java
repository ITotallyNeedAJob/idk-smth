// === Kuzi module: CartAssist ===
// Category   : COMBAT
// Description: When you fire a bow, places a rail + TNT minecart where the arrow will land.
// Payload    : a.a.a.j.c.H (verified: True)

package kuzi.modules.combat;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.module.Module;
import kuzi.obf.h.b.v;
import kuzi.obf.j.c.i;
import kuzi.obf.p.Z;
import kuzi.obf.p.aA;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.Entity;
import net.minecraft.AbstractArrow;
import net.minecraft.ItemStack;
import net.minecraft.Items;
import net.minecraft.BlockPos;
import net.minecraft.Direction;
import net.minecraft.Vec3i;
import net.minecraft.Vec3;
import net.minecraft.BlockTags;
import net.minecraft.BlockHitResult;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class CartAssist
extends BaseModule
implements Module {
    private final SliderSetting reach;
    private final SliderSetting placeDelay;
    private final BoolSetting switchBack;
    private i state;
    private int placeDelayTicks;
    private int cooldownTicks;
    private int previousSlot;
    private BlockPos railPos;
    private BlockPos cartPos;
    private Vec3 hitVec;
    private final Set handledArrowIds;
    private static final long x;
    private static final String[] y;
    private static final String[] z;
    private static final Map A;
    private static final long[] B;
    private static final Integer[] C;
    private static final Map D;
    private static final Object[] E;
    private static final String[] F;

    public CartAssist() {
        long l2 = x ^ 0x5BC817110535L;
        long l3 = l2 ^ 0x10E4670CED4EL;
        super("CartAssist", "When you fire a bow, places a rail + TNT minecart where the arrow will land.", Category.COMBAT);
        this.reach = new SliderSetting("Reach", 4.5, 3.0, 6.0, 0.25);
        this.placeDelay = new SliderSetting("Place Delay", 1.0, 0.0, 6.0, 1.0);
        this.switchBack = new BoolSetting("Switch Back", true);
        this.state = i.IDLE;
        this.placeDelayTicks = 0;
        this.cooldownTicks = 0;
        this.previousSlot = -1;
        this.handledArrowIds = new HashSet();
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.reach, this.placeDelay, this.switchBack};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        long l2 = x ^ 0x142C716D4A3L;
        long l3 = l2 ^ 0x75E45A220A71L;
        Client.a().a(Module.class, this);
        super.d();
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.resetState(objectArray);
    }

    @Override
    public void e() {
        long l2;
        long l3 = l2 = x ^ 0x143EDEF7B48DL;
        long l4 = l3 ^ 0x609843C36A5FL;
        long l5 = l3 ^ 0xD07A7F8312FL;
        Client.a().b(Module.class, this);
        super.e();
        Object[] objectArray = new Object[1];
        objectArray[0] = l5;
        this.restoreSelectedSlot(objectArray);
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l4;
        this.resetState(objectArray2);
    }

    @Override
    public void h() {
        long l2 = x ^ 0x4BD3DE820F93L;
        long l3 = l2 ^ 0x3F7543B6D141L;
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.resetState(objectArray);
    }

    private void resetState(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = x ^ l2;
        this.state = i.IDLE;
        this.placeDelayTicks = 0;
        this.cooldownTicks = 0;
        this.previousSlot = -1;
        this.railPos = null;
        this.cartPos = null;
        this.hitVec = null;
        this.handledArrowIds.clear();
    }

    @Override
    public void b() {
        long l2;
        long l3 = l2 = x ^ 0x72A19C8DABAAL;
        long l4 = l3 ^ 0x741F8B0A2685L;
        long l5 = l3 ^ 0x7EBB3B14110AL;
        long l6 = l3 ^ 0x60701B97578L;
        int n2 = 66;
        if (BaseModule.a.player == null || BaseModule.a.level == null || BaseModule.a.gameMode == null) {
            Object[] objectArray = new Object[1];
            objectArray[0] = l6;
            this.resetState(objectArray);
            return;
        }
        if (BaseModule.a.screen != null) {
            return;
        }
        if (this.state != i.IDLE) {
            Object[] objectArray = new Object[1];
            objectArray[0] = l5;
            this.findRailSlot(objectArray);
            return;
        }
        if (this.cooldownTicks > 0) {
            --this.cooldownTicks;
            return;
        }
        if (this.handledArrowIds.size() > 64) {
            this.handledArrowIds.clear();
        }
        Object[] objectArray = new Object[1];
        objectArray[0] = l4;
        this.scanArrow(objectArray);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void scanArrow(Object[] var1_1) {
        block21: {
            block22: {
                var2_2 = (Long)var1_1[0];
                v0 = var2_2 = CartAssist.x ^ var2_2;
                var4_3 = v0 ^ 65908639554586L;
                var6_4 = v0 ^ 107733712546449L;
                var8_5 = v0 ^ 68879839730644L;
                var11_6 = BaseModule.a.level.entitiesForRendering().iterator();
                var10_7 = 0;
                block2: while (true) {
                    block24: {
                        block19: {
                            block20: {
                                v1 = var11_6.hasNext();
                                do lbl-1000:
                                // 3 sources

                                {
                                    block23: {
                                        if (!v1) {
                                            return;
                                        }
                                        v2 = var12_8 = (Entity)var11_6.next();
                                        if (var10_7 != 0) break block23;
                                        v1 = v2 instanceof AbstractArrow;
                                        if (var2_2 < 0L) ** GOTO lbl-1000
                                        if (!v1) continue block2;
                                        v2 = var12_8;
                                    }
                                    v3 = var13_9 = (AbstractArrow)v2;
                                    if (var2_2 > 0L && var10_7 == 0) {
                                        if (v3.getOwner() != BaseModule.a.player) continue block2;
                                        v3 = var13_9;
                                    }
                                    v4 = v3.onGround();
                                    v5 = var10_7;
                                    if (var2_2 > 0L) {
                                        if (v5 == 0) {
                                            if (v4 && var2_2 >= 0L) continue block2;
                                            v4 = this.handledArrowIds.contains(var13_9.getId());
                                        }
                                        v5 = var10_7;
                                    }
                                    if (v5 == 0) {
                                        if (v4 && var2_2 >= 0L) continue block2;
                                        v4 = this.handledArrowIds.add(var13_9.getId());
                                    }
                                    v6 = var14_10 = var13_9.getDeltaMovement();
                                    if (var10_7 != 0) ** GOTO lbl41
                                    if (v6.lengthSqr() < 1.0E-4) continue block2;
                                    try {
                                        v6 = new Vec3(var13_9.getX(), var13_9.getY(), var13_9.getZ());
lbl41:
                                        // 2 sources

                                        var16_12 = v6;
                                        v7 = new Object[8];
                                        v7[7] = (int)CartAssist.c("c", (int)32478, (long)(218927632095968704L ^ var2_2));
                                        v7[6] = 0.99;
                                        v7[5] = 0.05;
                                        v7[4] = var8_5;
                                        v7[3] = var14_10;
                                        v7[2] = var16_12;
                                        v7[1] = var13_9;
                                        v7[0] = BaseModule.a.level;
                                        var15_11 = Z.b(v7);
                                    }
                                    catch (Throwable var16_13) {
                                        continue block2;
                                    }
                                    v8 = var15_11;
                                    v9 = var10_7;
                                    if (var2_2 < 0L) break block19;
                                    if (v9 != 0) break block20;
                                    v1 = v8.b;
                                } while (var2_2 < 0L);
                                if (!v1) continue;
                                v8 = var15_11;
                            }
                            if (var2_2 < 0L) break block24;
                            v9 = var10_7;
                        }
                        if (v9 == 0) {
                            if (v8.d != Direction.UP) continue;
                            v8 = var15_11;
                        }
                    }
                    v10 = v8.c;
                    if (var10_7 == 0) {
                        if (v10 == null && var2_2 >= 0L) continue;
                        v10 = var15_11.c;
                    }
                    var16_12 = v10;
                    var17_14 = var16_12.above();
                    v11 = BaseModule.a;
                    if (var10_7 == 0) {
                        if (!v11.level.getBlockState(var17_14).canBeReplaced()) continue;
                        v11 = BaseModule.a;
                    }
                    var18_15 = v11.player.getEyePosition().distanceTo(Vec3.atCenterOf((Vec3i)var17_14));
                    cfr_temp_0 = var18_15 - (Double)this.reach.a();
                    v12 = cfr_temp_0 == 0.0 ? 0 : (cfr_temp_0 > 0.0 ? 1 : -1);
                    v13 = var10_7;
                    if (var2_2 > 0L) {
                        if (v13 == 0) {
                            if (v12 > 0 && var2_2 > 0L) continue;
                            v14 = new Object[1];
                            v14[0] = var4_3;
                            v12 = this.findRailSlot(v14);
                        }
                        v13 = -1;
                    }
                    if (var10_7 == 0) {
                        if (v12 == v13) continue;
                        v15 = this;
                        v16 = var10_7;
                        if (var2_2 < 0L) break block21;
                        if (v16 != 0) break block22;
                        v17 = new Object[1];
                        v17[0] = var6_4;
                        v12 = v15.findMinecartSlot(v17);
                        v13 = -1;
                    }
                    if (v12 != v13) break;
                }
                this.railPos = var16_12;
                this.cartPos = var17_14;
                this.hitVec = var15_11.e;
                this.previousSlot = BaseModule.a.player.getInventory().getSelectedSlot();
                this.state = i.RAIL;
                v15 = this;
            }
            v16 = 0;
        }
        v15.placeDelayTicks = v16;
    }

    /*
     * Unable to fully structure code
     */
    private void f(Object[] var1_1) {
        block22: {
            var2_2 = (Long)var1_1[0];
            v0 = var2_2 = CartAssist.x ^ var2_2;
            var4_3 = v0 ^ 54242166598549L;
            var6_4 = v0 ^ 118055861787934L;
            var8_5 = v0 ^ 113328789781867L;
            var10_6 = 66;
            v1 = this.state.ordinal();
            if (var2_2 <= 0L) ** GOTO lbl17
            switch (v1) {
                case 1: {
                    v2 = new Object[1];
                    v2[0] = var4_3;
                    v1 = this.findRailSlot(v2);
lbl17:
                    // 2 sources

                    var11_7 = v1;
                    v3 = var10_6;
                    if (var2_2 < 0L) ** GOTO lbl22
                    if (v3 == 0) ** GOTO lbl31
                    v3 = var11_7;
lbl22:
                    // 2 sources

                    if (v3 == -1) ** GOTO lbl27
                    v4 = this;
                    if (var2_2 <= 0L) ** GOTO lbl37
                    if (var2_2 < 0L) ** GOTO lbl35
                    if (v4.railPos != null) ** GOTO lbl32
lbl27:
                    // 2 sources

                    v5 = new Object[1];
                    v5[0] = var8_5;
                    this.m(v5);
lbl31:
                    // 2 sources

                    return;
lbl32:
                    // 1 sources

                    BaseModule.a.player.getInventory().setSelectedSlot(var11_7);
                    aA.a(new BlockHitResult(this.hitVec, Direction.UP, this.railPos, false), true);
                    v6 = this;
lbl35:
                    // 2 sources

                    v6.placeDelayTicks = Math.max(0, ((Double)this.placeDelay.a()).intValue());
                    v4 = this;
lbl37:
                    // 2 sources

                    v4.state = i.CART;
                    if (var2_2 >= 0L) break block22;
                }
                case 2: {
                    v7 = this;
                    v8 = var10_6;
                    if (var2_2 > 0L) {
                        if (v8 != 0) {
                            if (v7.placeDelayTicks-- > 0) {
                                return;
                            }
                            v7 = this;
                        }
                        v8 = var10_6;
                    }
                    if (v8 == 0) ** GOTO lbl51
                    if (v7.cartPos != null && BaseModule.a.level.getBlockState(this.cartPos).is(BlockTags.RAILS)) ** GOTO lbl56
                    v7 = this;
lbl51:
                    // 2 sources

                    v9 = new Object[1];
                    v9[0] = var8_5;
                    v7.m(v9);
                    return;
lbl56:
                    // 1 sources

                    v10 = new Object[1];
                    v10[0] = var6_4;
                    var11_7 = this.findMinecartSlot(v10);
                    v11 = var10_6;
                    if (var2_2 <= 0L) ** GOTO lbl75
                    if (v11 != 0) {
                        if (var11_7 == -1) {
                            v12 = new Object[1];
                            v12[0] = var8_5;
                            this.m(v12);
                            return;
                        }
                        BaseModule.a.player.getInventory().setSelectedSlot(var11_7);
                        aA.a(new BlockHitResult(Vec3.atCenterOf((Vec3i)this.cartPos), Direction.UP, this.cartPos, false), true);
                        this.placeDelayTicks = Math.max(0, ((Double)this.placeDelay.a()).intValue());
                        this.state = i.RESTORE;
                    }
                    if (var2_2 <= 0L) ** GOTO lbl76
                    v11 = var10_6;
lbl75:
                    // 2 sources

                    if (v11 != 0) break block22;
                }
lbl76:
                // 3 sources

                case 3: {
                    v13 = this;
                    if (var2_2 > 0L) {
                        if (v13.placeDelayTicks-- > 0) {
                            return;
                        }
                        v13 = this;
                    }
                    if (var2_2 < 0L) break;
                    v14 = new Object[1];
                    v14[0] = var8_5;
                    v13.m(v14);
                }
                {
                    break block22;
                }
                default: {
                    v13 = this;
                    break;
                }
            }
            v15 = new Object[1];
            v15[0] = var8_5;
            v13.m(v15);
        }
    }

    private void m(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = (l2 = x ^ l2) ^ 0x7231B4D7C269L;
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l3;
        this.restoreSelectedSlot(objectArray2);
        this.railPos = null;
        this.cartPos = null;
        this.hitVec = null;
        this.state = i.IDLE;
        this.cooldownTicks = Math.max(2, ((Double)this.placeDelay.a()).intValue() + 2);
    }

    private void restoreSelectedSlot(Object[] objectArray) {
        int n2;
        block5: {
            block6: {
                CartAssist cartAssist;
                block4: {
                    long l2 = (Long)objectArray[0];
                    l2 = x ^ l2;
                    int n3 = 66;
                    if (!((Boolean)this.switchBack.a()).booleanValue()) break block4;
                    cartAssist = this;
                    n2 = n3;
                    if (l2 < 0L) break block5;
                    if (n2 == 0) break block6;
                    if (cartAssist.previousSlot != -1 && BaseModule.a.player != null) {
                        BaseModule.a.player.getInventory().setSelectedSlot(this.previousSlot);
                    }
                }
                cartAssist = this;
            }
            n2 = -1;
        }
        cartAssist.previousSlot = n2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private int findRailSlot(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = x ^ l2;
        int n2 = 0;
        int n3 = 66;
        do {
            block6: {
                int n4;
                block5: {
                    if (n2 >= CartAssist.c("c", (int)13147, (long)(0x17F9C2D7A6FC1F30L ^ l2))) return -1;
                    ItemStack mc17992 = BaseModule.a.player.getInventory().getItem(n2);
                    int n5 = mc17992.is(Items.RAIL) ? 1 : 0;
                    int n6 = n3;
                    if (l2 > 0L) {
                        if (n6 == 0) return n5;
                        n6 = n3;
                    }
                    if (n6 == 0) return n4;
                    if (n5 != 0) break block5;
                    n4 = mc17992.is(Items.POWERED_RAIL) ? 1 : 0;
                    if (n3 == 0) return n4;
                    if (n4 != 0) break block5;
                    n4 = mc17992.is(Items.DETECTOR_RAIL) ? 1 : 0;
                    if (n3 == 0) return n4;
                    if (n4 != 0) break block5;
                    n4 = mc17992.is(Items.ACTIVATOR_RAIL) ? 1 : 0;
                    if (n3 == 0) return n4;
                    if (n4 == 0) break block6;
                }
                n4 = n2;
                return n4;
            }
            ++n2;
        } while (n3 != 0);
        return -1;
    }

    /*
     * Exception decompiling
     */
    private int findMinecartSlot(Object[] var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * java.lang.UnsupportedOperationException
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.considerAsDoLoopStart(LoopIdentifier.java:383)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.identifyLoops1(LoopIdentifier.java:65)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:681)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Unable to fully structure code
     */
    static {
        block21: {
            block20: {
                block19: {
                    block18: {
                        CartAssist.x = kuzi.obf.h.b.v.a(-7751015267264477763L, 7070458668701151092L, MethodHandles.lookup().lookupClass()).a(5867469737532L);
                        CartAssist.E = new Object[66];
                        CartAssist.F = new String[66];
                        CartAssist.c();
                        CartAssist.A = new HashMap<K, V>(13);
                        var11 = CartAssist.x ^ 115987196180217L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[5];
                        var18_4 = 0;
                        var17_5 = "\u00de\u00ba%n\u001d}\u00fd\u00e7\u0091\u00cf%\u00ea\u00e5an\u00c4 \u0096\u00b9\u00e3r\u00a4Z\u00ee\u00a3\u00ef\u000eG\u00dcP\u0096\u00d6\u00c8h\u008d\u001cl;7^\u0002\u00b2\u0088^ncb\u001fP\u0018+\u00aa\u0019C\u00fc\u0083\u001cWt\u00ac\n\u001b\u00cf\u0011M\u00d9\u00f0\u0004\u00e8\u0091\u0091\u00a1\u0013(";
                        var19_6 = "\u00de\u00ba%n\u001d}\u00fd\u00e7\u0091\u00cf%\u00ea\u00e5an\u00c4 \u0096\u00b9\u00e3r\u00a4Z\u00ee\u00a3\u00ef\u000eG\u00dcP\u0096\u00d6\u00c8h\u008d\u001cl;7^\u0002\u00b2\u0088^ncb\u001fP\u0018+\u00aa\u0019C\u00fc\u0083\u001cWt\u00ac\n\u001b\u00cf\u0011M\u00d9\u00f0\u0004\u00e8\u0091\u0091\u00a1\u0013(".length();
                        var16_7 = 16;
                        var15_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block18;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = CartAssist.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "\u00870\u0018\u00b8\u00b7&\u00c38d\u00cf\u00ab\u00a0\u0089k\u00b4\u0011\u00b7],\u000bKH\u000b\u00ba\u009c\u0091\u00fe\u00d9\u00de\u00b0\u00c8\u00a9x\u00b4l\u001a\u0097\u00ec \u00c9[lQ\u00b94\u00d5\u009d\u00dd\u00dd\u00bfW\u009f\u00ac\u00a2\u00d2\u0007&Dw\u00e1\u00be1\u00be\u00dc\u00ab\u009bf\u00a5\u00baY\u00a8I\u00d9\u00df\u00108Cd\u0006\u0019k\u0087O\u0083\u00c8\u00ef\u001c($\u0087x)\u00d9\u00fe9/H\u0019.\u008d@\u00c0\u00e3TW7\u00a1\u00e79\u00b0\u00f9\u009b\u00c8\u00ab$\u0098\u00c8 \u00c9]\u0000\u00bb\u00f0\u00f5\b\u009b\u0003\u00eb\u009bg\u00b6\u0099\u0096H\u00cd\u00ff\u009c\u008dJd\u00c7\u00c2\u00bd%\u00b8,\u00d6\u00a1KY'\u00ee/";
                            var19_6 = "\u00870\u0018\u00b8\u00b7&\u00c38d\u00cf\u00ab\u00a0\u0089k\u00b4\u0011\u00b7],\u000bKH\u000b\u00ba\u009c\u0091\u00fe\u00d9\u00de\u00b0\u00c8\u00a9x\u00b4l\u001a\u0097\u00ec \u00c9[lQ\u00b94\u00d5\u009d\u00dd\u00dd\u00bfW\u009f\u00ac\u00a2\u00d2\u0007&Dw\u00e1\u00be1\u00be\u00dc\u00ab\u009bf\u00a5\u00baY\u00a8I\u00d9\u00df\u00108Cd\u0006\u0019k\u0087O\u0083\u00c8\u00ef\u001c($\u0087x)\u00d9\u00fe9/H\u0019.\u008d@\u00c0\u00e3TW7\u00a1\u00e79\u00b0\u00f9\u009b\u00c8\u00ab$\u0098\u00c8 \u00c9]\u0000\u00bb\u00f0\u00f5\b\u009b\u0003\u00eb\u009bg\u00b6\u0099\u0096H\u00cd\u00ff\u009c\u008dJd\u00c7\u00c2\u00bd%\u00b8,\u00d6\u00a1KY'\u00ee/".length();
                            var16_7 = 32;
                            var15_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block18;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = CartAssist.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block19;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                CartAssist.y = var20_3;
                CartAssist.z = new String[5];
                CartAssist.D = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[4];
                var3_13 = 0;
                var4_14 = "w\u00f3\u00b9lUc\u001c\u00ee'\u007fR\u00197wF`";
                var5_15 = "w\u00f3\u00b9lUc\u001c\u00ee'\u007fR\u00197wF`".length();
                var2_16 = 0;
                while (true) {
                    var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                    v10 = var6_12;
                    v11 = var3_13++;
                    v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                    v13 = -1;
                    break block20;
                    break;
                }
lbl81:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    var4_14 = "\u00a1\u00c0-V\u00fe\u009d\u008e\u00de\u00bf\u00be\u00d3\u0098;\u00d52G";
                    var5_15 = "\u00a1\u00c0-V\u00fe\u009d\u008e\u00de\u00bf\u00be\u00d3\u0098;\u00d52G".length();
                    var2_16 = 0;
                    while (true) {
                        var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                        v10 = var6_12;
                        v11 = var3_13++;
                        v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                        v13 = 0;
                        break block20;
                        break;
                    }
                    break;
                }
lbl94:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    break block21;
                    break;
                }
            }
            var8_18 = v12;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            v14 = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
            switch (v13) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl107:
                // 1 sources

                ** continue;
            }
        }
        CartAssist.B = var6_12;
        CartAssist.C = new Integer[4];
    }

    private static Throwable a(Throwable throwable) {
        return throwable;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0xE30;
        if (C[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = B[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])D.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    D.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/c/H", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            CartAssist.C[n3] = n4;
        }
        return C[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = CartAssist.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/c/H" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static void c() {
        Object[] objectArray = E;
        E[0] = "\u0011\u00026,\tX\u001a\u00024, ";
        objectArray[1] = "M1U\u0001Ee8\u0011^\u000eT*Y\u001fU\u0005Pp-";
        objectArray[2] = Void.TYPE;
        CartAssist.F[2] = "java/lang/Void";
        objectArray[3] = ")O1\tCM\\o:\u0006R\u0002=a1\rVXI";
        objectArray[4] = "X\u0019]$+-S\u0019_$#";
        objectArray[5] = "\u007f7\u001ciTk\u007f7\u000b5Xde|\u000b+Xqb\rZs\n";
        objectArray[6] = "`N\u001e\u000ez~`N\tRvqz\u0005\tLvd}tX\u0013$/";
        objectArray[7] = Integer.TYPE;
        CartAssist.F[7] = "java/lang/Integer";
        objectArray[8] = "@WO\u001a2;^_UUO+^";
        objectArray[9] = ")6T\\\u001e\f\"6_";
        objectArray[10] = "H\u0000cjLSH\u0000t6@\\RKt(@IU:$u\u0011";
        objectArray[11] = "k\u000e\\|\u0019/b\u000e_|\u0015";
        objectArray[12] = "\u0010e\u0015hw0eE\u001egf\u007f\u0004K\u0015lb%p";
        objectArray[13] = "<}R]NnI]YR_!(SRY[{\\";
        objectArray[14] = "v(M\u0002\u001c\\g(Mm";
        objectArray[15] = "\f`\u007fl$/\f`h0( \u0016+h.(5\u0011Z8{\u007fs";
        objectArray[16] = Boolean.TYPE;
        CartAssist.F[16] = "java/lang/Boolean";
        objectArray[17] = "\b!6Q\u0002>\u0001!5Q\u0002";
        objectArray[18] = "\u0003U\u00007j\u0016\bZ\u0011x\u000b\u0018\u0003Q\u0015\"";
        objectArray[19] = "=P\u0011Mg\u000b6P\u0013Mh";
        objectArray[20] = "zG(y%*\u000fg#v4eni(}0?\u001a";
        objectArray[21] = "zY\"?b\tqV3p\u0018\rbW#?.\tu";
        objectArray[22] = "NLD\"YVELL";
        objectArray[23] = "\u00149/,gB\u001d9,,e";
        objectArray[24] = "\u0001\u0007q1j9t'z>{v\u0015)q5\u007f,a";
        objectArray[25] = "L Ua\u0015f] U-";
        objectArray[26] = "mWPX_\u0005mWG\u0004S\nw\u001cG\u001aS\u001fpm\u0016E\u0007\\";
        objectArray[27] = "E\u001f`\u001c|)T\u001f[";
        objectArray[28] = "JUN\u0007\t\u000e?uE\b\u0018A^{N\u0003\u001c\u001b*";
        objectArray[29] = "1\u0006\u001c\u0013{8D&\u0017\u001cjw%(\u001c\u0017n-Q";
        objectArray[30] = "d-xXCd\u0011\rsWR+p\u0003x\\Vq\u0004";
        objectArray[31] = "\u00158W\u001bit\u0011zW%j\u001f@m\u001d[rq\u0015eIB";
        objectArray[32] = ",\u0012B2|&(PB\faMr@Nge$wB\tc";
        objectArray[33] = "8\u000e\rcp\"<L\r]|I9]\u0001gn#lK\u00020\u0015p;\u000e\u00008j92V\u001c]";
        objectArray[34] = "=f\\\u00022?h5H\u0001\\*QjX\r#9;)^\u001f`@";
        objectArray[35] = "ve\u0018.>Sr'\u0018\u0010&8/7\u0011*kT#a\u001ab";
        objectArray[36] = "\u0002qG\u0011g$\u000e*DWZ#bq\u0014\u0015f$[|\u0014Of";
        objectArray[37] = "\u0003p\bmcR\u000egVo_\u0005bh\u0005ae\u0014\b=\u0013b2o\u0002m\u0005 b\u0004\u000e6\u0006f_";
        objectArray[38] = "a\u0017dIpweUdws\u001c`DhMnv5Rk\u001a\u0015%b\u0017i\u0012jlkOuw";
        objectArray[39] = "6B=Ki(#\t?T\n:_\u0011 Il(f\u0006`\u0003eS5\u00022Qrh%\u001b5L\nj9D.Vu#0\u001c23";
        objectArray[40] = "%N7C\n\f!\f7}\u0010g}\u0011>\u0003\u0012\u000b)\u00149C";
        objectArray[41] = "#l\u0018CF\u001b.(GM4\tH>\u001b\u0016\u000b\u0007+m\u0001VD`";
        objectArray[42] = "_F\u0005sfK[\u0004\u0005Mj ^\u0015\twxJ\u000b\u0003\n \u0003\u001cD\u0013\b4i_B\u0001KM";
        objectArray[43] = "W!v&&\fScv\u0018*g_l;gsVVo<#C\nC\"{(r\u0003@%?\u0018";
        objectArray[44] = "\u000eb\u000f\rL'\u00029\fKq!n8\u0002\b\u0001!Wz\u001a\rN";
        objectArray[45] = "X*$\\\u000f^](cXsv/\u0000\u00177HY\u001d/&^M[Z+";
        objectArray[46] = "|\u0004M\r\u001aX%\u0004\u0017\u0007jZB\u000b\u0012\n\u0018\r}LMY\r";
        objectArray[47] = "p:x^a]u8?Z\u001dn\u0002\u0015B5&Z5?z\\#Xr;";
        objectArray[48] = "D(Tl}\u0005@jTRvnE{Xhc\u0004\u0010m[?\u0018WG(Y7g\u001eNpER";
        objectArray[49] = "6\u001bVRhY2YVlf27HZVvXb^Y\u0001\r\u000e-N[\u0015gM+\\\u0018l";
        objectArray[50] = "<\t],\n'0R^j7&\\\u0002HpU4g\u0012QwH";
        objectArray[51] = "w\u000e\u001a3_[sL\u001a\rD0)PR}W\tkHW2";
        objectArray[52] = "?%dN\u0018/;gdp\u0006Dfg\u007f\u000f\u0004.%amL";
        objectArray[53] = "\u0015\u0001\":\u0014~\u0011C\"\u0004\u0014\u0015\u0014R.>\n\u007fAD-iq,\u0016\u0001/a\u000ee\u001fY3\u0004";
        objectArray[54] = "\tH'=\u001b,XP'2{\u0004 k\u001f\u0015'O\tH'=\u001b,XP'2";
        objectArray[55] = "L72\u000b\u000e\tHu25\fbF;0YS\\Ka|Z";
        objectArray[56] = ",&uHj2)$2L\u0016\u0010^\u0012W#-5i#wJ(7.'";
        objectArray[57] = "~\u001f)\u00193ez])'*\u000e'M \u001dfb+\u001b+U";
        objectArray[58] = "o|\u001f~\u0019lk>\u001f@\u0005\u00076>\u0004?\u0005mu8\u0016|";
        objectArray[59] = ":esR\u001b\u001e?g4Vg-LPQ~=:\u00010cG\f\u000bh5a\u0000\b";
        objectArray[60] = "A-\u0005t-DEo\u0005J2/\u0018o\u001e51E[i\fv";
        objectArray[61] = "5l\u0006*\fj1.\u0006\u0014\u0002\u00014?\n.\u0012ka)\tyi86l\u000bq\u0016q?4\u0017\u0014";
        objectArray[62] = "yh#Y`l,;7Z\u000ex\u0015d'Vqj\u007f'!D2\u0013";
        objectArray[63] = "-cim\u0013]!8j+.]M>h)\u0014\u0006!2>\"\\";
        objectArray[64] = "?b![&\u000ffb{QV\u0000\u00016*\u001el\u001fkc<\u001d;d84y\u001f3\u001bq=!\u0003V";
        Object[] objectArray2 = objectArray;
        objectArray[65] = "f\u0016\u0018\b,9bT\u00186,R3CRH7<fK\u0006Q";
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = CartAssist.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = CartAssist.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = CartAssist.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = CartAssist.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(CartAssist.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

