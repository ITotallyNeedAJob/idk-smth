// === Kuzi module: AutoDoubleHand ===
// Category   : COMBAT
// Description: Switches to a totem and refills your offhand on pop or low health
// Payload    : a.a.a.j.c.t (verified: True)

package kuzi.modules.combat;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.core.Client;
import kuzi.mixin.MixinExposed;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.module.Module;
import kuzi.obf.h.b.v;
import kuzi.obf.m.r;
import kuzi.obf.p.m_0;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.Entity;
import net.minecraft.Player;
import net.minecraft.ClickType;
import net.minecraft.Items;
import net.minecraft.Level;
import net.minecraft.ClientboundEntityEventPacket;
import net.minecraft.Minecraft;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class AutoDoubleHand
extends BaseModule
implements Module {
    private final BoolSetting onPop;
    private final BoolSetting onHealth;
    private final SliderSetting health;
    private final BoolSetting autoOffhand;
    private final SliderSetting delay;
    private final BoolSetting randomDelay;
    private int savedSlot;
    private boolean lowHealth;
    private volatile int swapCountdown;
    private static final long v;
    private static final String[] w;
    private static final String[] x;
    private static final Map y;
    private static final long[] z;
    private static final Integer[] A;
    private static final Map B;
    private static final Object[] C;
    private static final String[] D;

    public AutoDoubleHand() {
        long l2 = v ^ 0x4D1B62D8A42DL;
        long l3 = l2 ^ 0x57F3DBD7F278L;
        super("AutoDoubleHand", "Switches to a totem and refills your offhand on pop or low health", Category.COMBAT);
        this.onPop = new BoolSetting("On Pop", true);
        this.onHealth = new BoolSetting("On Health", true);
        this.health = new SliderSetting("Health", 10.0, 0.0, 20.0, 1.0);
        this.autoOffhand = new BoolSetting("Auto Offhand", true);
        this.delay = new SliderSetting("Delay", 0.0, 0.0, 20.0, 1.0);
        this.randomDelay = new BoolSetting("Random Delay", false);
        this.savedSlot = -1;
        this.lowHealth = false;
        this.swapCountdown = -1;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.onPop, this.onHealth, this.health, this.autoOffhand, this.delay, this.randomDelay};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        long l2 = v ^ 0x50860E046A8DL;
        long l3 = l2 ^ 0x44CB02D9312L;
        Client.a().a(Module.class, this);
        super.d();
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.a(objectArray);
    }

    @Override
    public void e() {
        long l2 = v ^ 0x45FA17E50AA3L;
        long l3 = l2 ^ 0x1130A9CCF33CL;
        Client.a().b(Module.class, this);
        super.e();
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.a(objectArray);
    }

    private void a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = v ^ l2;
        this.savedSlot = -1;
        this.lowHealth = false;
        this.swapCountdown = -1;
    }

    @Override
    public void b() {
        block4: {
            float f2;
            block5: {
                long l2;
                long l3 = l2 = v ^ 0x2365559F1584L;
                long l4 = l3 ^ 0x3E9263626C18L;
                long l5 = l3 ^ 0x8CF066B2D89L;
                if (BaseModule.a.player == null || BaseModule.a.level == null || BaseModule.a.gameMode == null) {
                    return;
                }
                if (this.swapCountdown == 0) {
                    this.swapCountdown = -1;
                    Object[] objectArray = new Object[1];
                    objectArray[0] = l4;
                    this.f(objectArray);
                } else if (this.swapCountdown > 0) {
                    --this.swapCountdown;
                }
                if (!((Boolean)this.onHealth.a()).booleanValue()) break block4;
                f2 = BaseModule.a.player.getHealth();
                if (!(f2 <= ((Double)this.health.a()).floatValue()) || this.lowHealth) break block5;
                Object[] objectArray = new Object[1];
                objectArray[0] = l5;
                this.c(objectArray);
                this.lowHealth = true;
                break block4;
            }
            if (!(f2 > ((Double)this.health.a()).floatValue())) break block4;
            this.lowHealth = false;
        }
    }

    @MixinExposed
    public void a(ClientboundEntityEventPacket mc26632) {
        long l2 = v ^ 0x19BDE91433E2L;
        long l3 = l2 ^ 0x3217BAE00BEFL;
        if (mc26632.getEventId() != 35 || BaseModule.a.player == null || BaseModule.a.level == null || !((Boolean)this.onPop.a()).booleanValue()) {
            return;
        }
        Entity mc12972 = mc26632.getEntity((Level)BaseModule.a.level);
        if (mc12972 == null || !mc12972.equals((Object)BaseModule.a.player)) {
            return;
        }
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.c(objectArray);
    }

    private void c(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = (l2 = v ^ l2) ^ 0x65205B563FC8L;
        int n2 = 0;
        if (this.swapCountdown >= 0) {
            return;
        }
        int delayTicks = ((Double)this.delay.a()).intValue();
        AutoDoubleHand autoDoubleHand = this;
        int countdown = n2;
        if (l2 > 0L) {
            if (countdown == 0) {
                if (((Boolean)autoDoubleHand.randomDelay.a()).booleanValue() && delayTicks > 0) {
                    Object[] objectArray2 = new Object[3];
                    objectArray2[2] = l3;
                    objectArray2[1] = delayTicks + 1;
                    objectArray2[0] = 0;
                    delayTicks = m_0.a(objectArray2);
                }
                autoDoubleHand = this;
            }
            countdown = delayTicks;
        }
        autoDoubleHand.swapCountdown = countdown;
    }

    private void f(Object[] objectArray) {
        block3: {
            AutoDoubleHand autoDoubleHand;
            long l2;
            block2: {
                long l3 = (Long)objectArray[0];
                long l4 = l3 = v ^ l3;
                long l5 = l4 ^ 0x5630571CF5EEL;
                l2 = l4 ^ 0x3D5D672AC882L;
                Object[] objectArray2 = new Object[1];
                objectArray2[0] = l5;
                this.m(objectArray2);
                int n2 = 66;
                autoDoubleHand = this;
                if (n2 == 0) break block2;
                if (!((Boolean)autoDoubleHand.p.a()).booleanValue()) break block3;
                autoDoubleHand = this;
            }
            Object[] objectArray3 = new Object[1];
            objectArray3[0] = l2;
            autoDoubleHand.n(objectArray3);
        }
    }

    /*
     * Unable to fully structure code
     */
    private void m(Object[] var1_1) {
        block12: {
            block10: {
                block11: {
                    block9: {
                        var2_2 = (Long)var1_1[0];
                        v0 = var2_2 = AutoDoubleHand.v ^ var2_2;
                        var4_3 = v0 ^ 93415319677663L;
                        var6_4 = v0 ^ 105484766541671L;
                        var8_5 = 66;
                        if (BaseModule.a.player == null) {
                            return;
                        }
                        v1 = var9_6 = Client.a().a((String)AutoDoubleHand.b("v", (int)11229, (long)(1138109840333554817L ^ var2_2)));
                        if (var2_2 < 0L) break block9;
                        if (v1 == null) ** GOTO lbl-1000
                        v1 = var9_6;
                    }
                    if (v1.d()) {
                        v2 = true;
                    } else lbl-1000:
                    // 2 sources

                    {
                        v2 = var10_7 = false;
                    }
                    if (var10_7) {
                        v3 = new Object[1];
                        v3[0] = var4_3;
                        v4 = this.a(v3);
                    } else {
                        v5 = new Object[1];
                        v5[0] = var6_4;
                        v4 = var11_8 = this.c(v5);
                    }
                    if (var11_8 == -1) {
                        return;
                    }
                    v6 = this;
                    v7 = var8_5;
                    if (var2_2 < 0L) break block10;
                    if (v7 == 0) break block11;
                    if (v6.savedSlot != -1) break block12;
                    v6 = this;
                }
                v7 = BaseModule.a.player.getInventory().getSelectedSlot();
            }
            v6.savedSlot = v7;
        }
        BaseModule.a.player.getInventory().setSelectedSlot(var11_8);
    }

    private void n(Object[] objectArray) {
        block20: {
            int n2;
            int n3;
            int n4;
            int n5;
            long l2;
            block19: {
                int n6;
                long l3;
                block13: {
                    int n7;
                    block14: {
                        block15: {
                            Minecraft mc3102;
                            block17: {
                                block18: {
                                    block16: {
                                        l2 = (Long)objectArray[0];
                                        l3 = (l2 = v ^ l2) ^ 0x349D263FCA0BL;
                                        n7 = 66;
                                        if (BaseModule.a.player == null) break block16;
                                        mc3102 = BaseModule.a;
                                        if (l2 <= 0L) break block17;
                                        if (mc3102.gameMode != null) break block18;
                                    }
                                    return;
                                }
                                mc3102 = BaseModule.a;
                            }
                            if (mc3102.player.getOffhandItem().getItem() == Items.TOTEM_OF_UNDYING) {
                                return;
                            }
                            int n8 = BaseModule.a.player.getInventory().getSelectedSlot();
                            n5 = -1;
                            for (n4 = 0; n4 < AutoDoubleHand.c("j", (int)1082, (long)(0x43B910129AA48CB8L ^ l2)); ++n4) {
                                n3 = n4;
                                n2 = n8;
                                n6 = n7;
                                if (l2 < 0L) break block13;
                                if (n6 == 0) break block14;
                                if (n3 == n2 && l2 >= 0L || BaseModule.a.player.getInventory().getItem(n4).getItem() != Items.TOTEM_OF_UNDYING) continue;
                                n5 = n4;
                                n3 = n7;
                                if (l2 > 0L) {
                                    if (n3 != 0) break;
                                    continue;
                                }
                                break block15;
                            }
                            n3 = n5;
                        }
                        n2 = -1;
                    }
                    n6 = n7;
                }
                if (n6 == 0) break block19;
                if (n3 == n2) {
                    Object[] objectArray2 = new Object[1];
                    objectArray2[0] = l3;
                    n5 = this.c(objectArray2);
                }
                if (l2 < 0L) break block20;
                n3 = n5;
                n2 = -1;
            }
            if (n3 == n2) {
                return;
            }
            n4 = BaseModule.a.player.inventoryMenu.containerId;
            BaseModule.a.gameMode.handleInventoryMouseClick(n4, (int)(AutoDoubleHand.c("j", (int)28987, (long)(0x7C829A7FE966F9BBL ^ l2)) + n5), (int)AutoDoubleHand.c("j", (int)8669, (long)(0x5271091BB777295EL ^ l2)), ClickType.SWAP, (Player)BaseModule.a.player);
        }
    }

    /*
     * Unable to fully structure code
     */
    private int a(Object[] var1_1) {
        var2_2 = (Long)var1_1[0];
        var2_2 = AutoDoubleHand.v ^ var2_2;
        var5_3 = 0;
        var6_4 = 0;
        var4_5 = 0;
        while (var6_4 < AutoDoubleHand.c("j", (int)4907, (long)(2744277124230988121L ^ var2_2))) {
            block6: {
                block7: {
                    block5: {
                        block4: {
                            if (var2_2 < 0L) break block4;
                            if (BaseModule.a.player.getInventory().getItem(var6_4).getItem() != Items.TOTEM_OF_UNDYING) break block5;
                            ++var5_3;
                        }
                        v0 = var4_5;
                        if (var2_2 < 0L) break block6;
                        if (v0 == 0) {
                            if (var5_3 == 2) {
                                return var6_4;
                            } else {
                                ** GOTO lbl18
                            }
                        }
                        break block7;
                    }
                    ++var6_4;
                }
                v0 = var4_5;
            }
lbl23:
            // 2 sources

            ** while (v0 != 0)
lbl24:
            // 1 sources

        }
lbl25:
        // 2 sources

        v0 = -1;
        if (var2_2 <= 0L) ** GOTO lbl23
        return v0;
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private int c(Object[] var1_1) {
        var2_2 = (Long)var1_1[0];
        var2_2 = AutoDoubleHand.v ^ var2_2;
        var5_3 = 0;
        var4_4 = AutoDoubleHand.d("\u00f3", (long)8871683461106388893L, (long)var2_2);
        while (var5_3 < AutoDoubleHand.c("j", (int)1082, (long)(4879966323278973939L ^ var2_2))) {
            block5: {
                try {
                    if (var2_2 <= 0L) break block5;
                    if (AutoDoubleHand.d("\u00e9", (long)8871471578462494870L, (long)var2_2).player.getInventory().getItem(var5_3).getItem() == Items.TOTEM_OF_UNDYING) {
                        return var5_3;
                    }
                }
                catch (r v0) {
                    throw AutoDoubleHand.d("\u00f3", (Object)v0, (long)8871265570306328768L, (long)var2_2);
                }
                ++var5_3;
            }
            v1 /* !! */  = (int)var4_4;
lbl17:
            // 2 sources

            ** while (v1 /* !! */  == 0)
lbl18:
            // 1 sources

        }
lbl19:
        // 2 sources

        v1 /* !! */  = -1;
        if (var2_2 < 0L) ** GOTO lbl17
        return v1 /* !! */ ;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block21: {
            block20: {
                block19: {
                    block18: {
                        AutoDoubleHand.v = kuzi.obf.h.b.v.a(-7336590496778753065L, -1994249432466793969L, MethodHandles.lookup().lookupClass()).a(61456392025516L);
                        AutoDoubleHand.C = new Object[48];
                        AutoDoubleHand.D = new String[48];
                        AutoDoubleHand.c();
                        AutoDoubleHand.y = new HashMap<K, V>(13);
                        var11 = AutoDoubleHand.v ^ 44451919641938L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[9];
                        var18_4 = 0;
                        var17_5 = "zx\u0017\u00f4\u00e9\u00f0\u00d4\u00d7\u00ca\u0000{xJ\u008co<\u00f1)\u00d4\u00fc\u00b5$\tS\u00adX\u00fa\u00c1+\u00fd\u00b4\u00c7\u0010ZD\u00cc\u0098\u00a3\u0095\u0017\u00d7\u00eb\u00c2eG)[\u00dc\u0002\u0010\u00d6[ q\u0019\u00ec\u0096%\u0012P\u00f9E.l\u00b9j\u0018\u00f46e\u00b7c\u00d1\u0007\u00d2\u00fd\u00b3\u007f\u00f9k\"\u0083J\u00e7\u000e83\u0097\u0000\u00d4G\u0018$:J\u00fd\u0090\u00c9\u00bd\u0016\u00a9\u00b4i\u0019\u00f0#\u008f\u00bb\u00bf\u00f7\u001c\u00df#\u00e7\u0014f \u00c5U\u00f3\u00ee\u00de\u00bc\u00a5\u00a4.\u0088\u00beE\u0015s\u00b0\u00d0-r\u00d5\u001e6-\u0081D\u001d\u007f\u00bf\u00ca[\u00ba\u00e8\u0000 \u00a7\u00c9P\u0094\u001b&`Ck\u00e3J\u00e8vt\u00c6g\u00f0\u0014\u001cE\u0087\u00bbdZ\u00ff\u00b8\u00cc\u00c98$A\u009a";
                        var19_6 = "zx\u0017\u00f4\u00e9\u00f0\u00d4\u00d7\u00ca\u0000{xJ\u008co<\u00f1)\u00d4\u00fc\u00b5$\tS\u00adX\u00fa\u00c1+\u00fd\u00b4\u00c7\u0010ZD\u00cc\u0098\u00a3\u0095\u0017\u00d7\u00eb\u00c2eG)[\u00dc\u0002\u0010\u00d6[ q\u0019\u00ec\u0096%\u0012P\u00f9E.l\u00b9j\u0018\u00f46e\u00b7c\u00d1\u0007\u00d2\u00fd\u00b3\u007f\u00f9k\"\u0083J\u00e7\u000e83\u0097\u0000\u00d4G\u0018$:J\u00fd\u0090\u00c9\u00bd\u0016\u00a9\u00b4i\u0019\u00f0#\u008f\u00bb\u00bf\u00f7\u001c\u00df#\u00e7\u0014f \u00c5U\u00f3\u00ee\u00de\u00bc\u00a5\u00a4.\u0088\u00beE\u0015s\u00b0\u00d0-r\u00d5\u001e6-\u0081D\u001d\u007f\u00bf\u00ca[\u00ba\u00e8\u0000 \u00a7\u00c9P\u0094\u001b&`Ck\u00e3J\u00e8vt\u00c6g\u00f0\u0014\u001cE\u0087\u00bbdZ\u00ff\u00b8\u00cc\u00c98$A\u009a".length();
                        var16_7 = 32;
                        var15_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block18;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = AutoDoubleHand.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "-Y{|-C\u00b2W\u00e9\u00d3A\u00dbC\u00c0W\u00cap\u00f9\u00af\u00a8\u00b6SV^$\u00db\u001c7A\u00a3\u0084(\u00e5U\u00d7Y\u0080\u00c3/\u0004@i\u001d\u0084R\u0002\u00cb\u00ca\u0090\u00d6\u0015u\u00e6\u008e\u00dc+\u00ad\u00a6\u0088\u0087,\u008c\u00a9\u00e8\u009a\u00be\u00c3\u0087D\u00ab\u009d)\u00d1\u00b467\u00db\u00ad\u00c0E\u00ab\u009c\f\u001bL=\u00be\u00a7G\u00ae\u009bg\u00ce[[\u00817\u00ac\u00c0\u00e4\u0090\u00f5\u00d9\u00e2\u00d9\u00df\u00a8]\u00c1\\F\u00d3\u00e1\u00800\u00b8\u00fd\u00b7p\u008eKY\u001f\u00a2\u00fd\u0087!pe";
                            var19_6 = "-Y{|-C\u00b2W\u00e9\u00d3A\u00dbC\u00c0W\u00cap\u00f9\u00af\u00a8\u00b6SV^$\u00db\u001c7A\u00a3\u0084(\u00e5U\u00d7Y\u0080\u00c3/\u0004@i\u001d\u0084R\u0002\u00cb\u00ca\u0090\u00d6\u0015u\u00e6\u008e\u00dc+\u00ad\u00a6\u0088\u0087,\u008c\u00a9\u00e8\u009a\u00be\u00c3\u0087D\u00ab\u009d)\u00d1\u00b467\u00db\u00ad\u00c0E\u00ab\u009c\f\u001bL=\u00be\u00a7G\u00ae\u009bg\u00ce[[\u00817\u00ac\u00c0\u00e4\u0090\u00f5\u00d9\u00e2\u00d9\u00df\u00a8]\u00c1\\F\u00d3\u00e1\u00800\u00b8\u00fd\u00b7p\u008eKY\u001f\u00a2\u00fd\u0087!pe".length();
                            var16_7 = 16;
                            var15_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block18;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = AutoDoubleHand.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block19;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                AutoDoubleHand.w = var20_3;
                AutoDoubleHand.x = new String[9];
                AutoDoubleHand.B = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[6];
                var3_13 = 0;
                var4_14 = "\u00be\u00a3t%!\u00ab7\u0000\u00f5#x\u0005j\u0002\u00c1\u00b5N\u0091\u0006\u00ea\f\u00dc\u00f9T\u00b01\u00f9S_h\u00af\"";
                var5_15 = "\u00be\u00a3t%!\u00ab7\u0000\u00f5#x\u0005j\u0002\u00c1\u00b5N\u0091\u0006\u00ea\f\u00dc\u00f9T\u00b01\u00f9S_h\u00af\"".length();
                var2_16 = 0;
                while (true) {
                    var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                    v10 = var6_12;
                    v11 = var3_13++;
                    v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                    v13 = -1;
                    break block20;
                    break;
                }
lbl81:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    var4_14 = "\u00c8\u00e4\u00a7\u00db\u0019\b\u00a4B\u00e7\u0000\u00c2\u0002\u0011\u00c9\u00e6\u00c3";
                    var5_15 = "\u00c8\u00e4\u00a7\u00db\u0019\b\u00a4B\u00e7\u0000\u00c2\u0002\u0011\u00c9\u00e6\u00c3".length();
                    var2_16 = 0;
                    while (true) {
                        var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                        v10 = var6_12;
                        v11 = var3_13++;
                        v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                        v13 = 0;
                        break block20;
                        break;
                    }
                    break;
                }
lbl94:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    break block21;
                    break;
                }
            }
            var8_18 = v12;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            v14 = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
            switch (v13) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl107:
                // 1 sources

                ** continue;
            }
        }
        AutoDoubleHand.z = var6_12;
        AutoDoubleHand.A = new Integer[6];
    }

    private static r a(r r2) {
        return r2;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static String b(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x2E68;
        if (x[n3] == null) {
            Object[] objectArray;
            try {
                Long l3 = Thread.currentThread().threadId();
                objectArray = (Object[])y.get(l3);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    y.put(l3, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/c/t", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l2 >>> 56);
            for (int i2 = 1; i2 < 8; ++i2) {
                byArray[i2] = (byte)(l2 << i2 * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = w[n3].getBytes("ISO-8859-1");
            AutoDoubleHand.x[n3] = AutoDoubleHand.b(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return x[n3];
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        String string2 = AutoDoubleHand.b(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static CallSite b(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/c/t" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x74DC;
        if (A[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = z[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])B.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    B.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/c/t", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            AutoDoubleHand.A[n3] = n4;
        }
        return A[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = AutoDoubleHand.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/c/t" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (D[n4] != null) {
            return n4;
        }
        Object object = C[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 48;
            case 1 -> 6;
            case 2 -> 5;
            case 3 -> 40;
            case 4 -> 35;
            case 5 -> 47;
            case 6 -> 27;
            case 7 -> 46;
            case 8 -> 60;
            case 9 -> 50;
            case 10 -> 42;
            case 11 -> 43;
            case 12 -> 61;
            case 13 -> 52;
            case 14 -> 16;
            case 15 -> 20;
            case 16 -> 63;
            case 17 -> 30;
            case 18 -> 33;
            case 19 -> 36;
            case 20 -> 45;
            case 21 -> 2;
            case 22 -> 7;
            case 23 -> 55;
            case 24 -> 54;
            case 25 -> 49;
            case 26 -> 14;
            case 27 -> 37;
            case 28 -> 57;
            case 29 -> 23;
            case 30 -> 58;
            case 31 -> 10;
            case 32 -> 19;
            case 33 -> 56;
            case 34 -> 44;
            case 35 -> 28;
            case 36 -> 3;
            case 37 -> 34;
            case 38 -> 4;
            case 39 -> 41;
            case 40 -> 22;
            case 41 -> 1;
            case 42 -> 51;
            case 43 -> 26;
            case 44 -> 39;
            case 45 -> 25;
            case 46 -> 32;
            case 47 -> 13;
            case 48 -> 24;
            case 49 -> 11;
            case 50 -> 17;
            case 51 -> 21;
            case 52 -> 29;
            case 53 -> 15;
            case 54 -> 18;
            case 55 -> 8;
            case 56 -> 62;
            case 57 -> 31;
            case 58 -> 12;
            case 59 -> 38;
            case 60 -> 59;
            case 61 -> 0;
            case 62 -> 53;
            default -> 9;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        AutoDoubleHand.D[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = C;
        C[0] = "\u0011i\u0000yrb\u001ai\u0002yg";
        objectArray[1] = "\\C*\u001aVKUC)\u001aT";
        objectArray[2] = Boolean.TYPE;
        AutoDoubleHand.D[2] = "java/lang/Boolean";
        objectArray[3] = "*q\b\u001dz\u0017#q\u000b\u001dv";
        objectArray[4] = Integer.TYPE;
        AutoDoubleHand.D[4] = "java/lang/Integer";
        objectArray[5] = "\u0018`\u001bn\u001cU\u0013`\u0013";
        objectArray[6] = "'\u0011$(\u0015p,\u0011/";
        objectArray[7] = "}:Xr\"2\b\u001aS}3}i\u0014Xv7'\u001d";
        objectArray[8] = Void.TYPE;
        AutoDoubleHand.D[8] = "java/lang/Void";
        objectArray[9] = "Fe\u0006mEH3E\rbT\u0007RK\u0006iP]&";
        objectArray[10] = "\u00064Eb\u001f+s\u0014Nm\u000ed\u0012\u001aEf\n>f";
        objectArray[11] = "p\u001f\u0011\u001a\u0006G|\u001f\u0002";
        objectArray[12] = "JuUe+\u0015?U^j:Z^[Ua>\u0000*";
        objectArray[13] = " 1H2kF)1K2k";
        objectArray[14] = "\u001d%Q<\u0015J\u0016*@stD\u001d!D)";
        objectArray[15] = "'\u0010\u0018\u000eD\u001d,\u0010\u001a\u000eK";
        objectArray[16] = "zC\r\u0017 ykC!";
        objectArray[17] = "N\\h\"Sd;|c-B+Zrh&Fq.";
        objectArray[18] = "[W\u0019ic\u0005[W\u000e5o\nA\u001c\u000e+o\u001fFm^v>";
        objectArray[19] = "<ZtV\u0005xIz\u007fY\u00147(ttR\u0010m\\";
        objectArray[20] = "\b\u00126#W!}2=,Fn\u001c<6'B4h";
        objectArray[21] = "\f=\b5\u0012jy\u001d\u0003:\u0003%\u0018\u0013\b1\u0007\u007fl";
        objectArray[22] = "*\u0001QTGH_!Z[V\u0007>/QPR]J";
        objectArray[23] = "4)\u0011/FS7l\b (\u0005^y\u0013.QU:~\fu\u0012le{\u0017yZ\u00148+Iq(";
        objectArray[24] = "1d[\u001e\nh=i \u0000la=nJ\u0003\rw.`";
        objectArray[25] = "z\u0018nc#\u0015v\u0015\u0015`E\u001cv\u0012\u007f~$\ne\u001c";
        objectArray[26] = "\ril*\u0003\u000e\u0001d\u00176eM\u0004b+h^N\u0011jl";
        objectArray[27] = "\u007f\u000b+QVTs\u0006PS0\u0017v\u0000l\u0013\u000b\u0014c\b+";
        objectArray[28] = "\r^`,a@\f^1*\\\u001ag\\l*5\u0002\u001f\u0001<t=p";
        objectArray[29] = "2UR\fHB>X)\u0019.U8\u0005PNJR'^\u0013w\u0013]#\n\u0017\u001c\u0014J$@)";
        objectArray[30] = "\u001f&z=\ns\u0013+\u0001#ld\u0015vx\u007f\bc\n-;FQl\u000ey?-V{\t3\u0001";
        objectArray[31] = "ICB*\r~EN97kwEIS7\naVG";
        objectArray[32] = "D\u0013TT\u000f>H\u001e/FixUCK^\u0015-TGR/V;\u0017\u0019^S\u0003:\u0013\u0000/";
        objectArray[33] = "~i4\u0015o\u0006.d \u0001^\tO0z\u0005:\rr`1Vc`";
        objectArray[34] = "\u00125\nvE~\u001e8qf#i\u0018e\b4Gn\u0007>K\r\u001ea\u0003jOf\u0019v\u0004 q";
        objectArray[35] = "Ls=]\\\u001e\u0016moP-\u0010pzrTC\u0007M(n\bM";
        objectArray[36] = "*]r;Iv&P\t)/a \rpyKf?V3@\u0014c$Z{8I3zR\t";
        objectArray[37] = "`J\u0019j;hlGbm]+7]\u000bxb+j\u0015\f";
        objectArray[38] = "\n$t\u0010s\u0006\u0006)\u000f\u0016\u0015D\u000b)f\u0019m\u0019[wn";
        objectArray[39] = "&d\u000e\fR$|z\\\u0001#/\u001a<\u0005\u001bJ*%<XSMC";
        objectArray[40] = "\u0003\u0002O|\u0005b\u000f\u000f4|c \u0002\u000f]u\u001b}RQU";
        objectArray[41] = "\u0014\u0010\u001eO\u0017'\u0018\u001de]q0\u001e@\u001c\r\u00157\u0001\u001b_4L8\u0005O[_K/\u0002\u0005e";
        objectArray[42] = "D@+\u00021T\u000f\u00017\u001d@d8z\f$\u001c/D@+\u00021T\u000f\u00017\u001d";
        objectArray[43] = "a\u000b0txhm\u0006Ku\u001eam\u0001!i\u007fw~\u000f";
        objectArray[44] = "0]4\u00023u<PO\u0012Ub:\r6@1e%Vuyn`>Z=\u000130`RO";
        objectArray[45] = "\u0016\u0007i/M2\u001a\n\u00122+%\u001cWkmO\"\u0003\f(T\u0016-\u0007X,?\u0011:\u0000\u0012\u0012";
        objectArray[46] = "Cj\f\u0001P<Bj]\u0007mg)h\u0000\u0007\u0004~Q5PY\f\f";
        Object[] objectArray2 = objectArray;
        objectArray[47] = "D\u001e-~^s\u001e\u0000\u007fs/px\u0012{.V-\u001c\u0015du\u0015\u0014E\u001a`!\u0011\u007fB\rgk/";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = AutoDoubleHand.e(l2, l3);
            object = C[n2];
            try {
                if (!(object instanceof String)) break block2;
                AutoDoubleHand.C[n2] = clazz = Class.forName(D[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = AutoDoubleHand.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = AutoDoubleHand.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = AutoDoubleHand.e(l2, l3);
        Object object = C[n2];
        if (object instanceof String) {
            String string = D[n2];
            int n3 = string.indexOf(8);
            Class clazz = AutoDoubleHand.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = AutoDoubleHand.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = AutoDoubleHand.c(clazz3, string2, clazz2)) != null) {
                    AutoDoubleHand.C[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = AutoDoubleHand.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        AutoDoubleHand.C[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = AutoDoubleHand.f(1038998655021389L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = AutoDoubleHand.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = AutoDoubleHand.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = AutoDoubleHand.e(l2, l3);
        Object object = C[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = D[n2];
                int n4 = string2.indexOf(8);
                clazz3 = AutoDoubleHand.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = AutoDoubleHand.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = AutoDoubleHand.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        AutoDoubleHand.C[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = AutoDoubleHand.f(1038998655021389L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = AutoDoubleHand.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        AutoDoubleHand.C[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = AutoDoubleHand.f(1038998655021389L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == 'r' || c2 == 'z' || c2 == '\u00e9' || c2 == '\u00db') {
                field = AutoDoubleHand.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == 'r' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == 'z' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == '\u00e9' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = AutoDoubleHand.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == 'h' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == '\u00f3' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = AutoDoubleHand.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_2().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/c/t" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(AutoDoubleHand.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(AutoDoubleHand.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_2() {
        try {
            return MethodHandles.lookup().findStatic(AutoDoubleHand.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

