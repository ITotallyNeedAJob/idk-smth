// === Kuzi module: Piercing ===
// Category   : COMBAT
// Description: (identified by constant match; old tree Piercing.java)
// Payload    : a.a.a.j.c.T (verified: constant-match)

package kuzi.modules.combat;

import a.a.a.j.c.m;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Optional;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.g.a.q;
import kuzi.obf.h.b.l;
import kuzi.obf.m.r;
import kuzi.obf.p.F;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import net.minecraft.Entity;
import net.minecraft.LivingEntity;
import net.minecraft.Player;
import net.minecraft.AABB;
import net.minecraft.HitResult;
import net.minecraft.Vec3;
import net.minecraft.Minecraft;
import net.minecraft.ClipContext;
import net.minecraft.EntityHitResult;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class Piercing
extends BaseModule
implements q {
    private final BoolSetting blocks;
    private final l sortBy;
    private static final long o = 137560153752367L;
    private static final Object[] s = new Object[]{"C;sMu=H;qMy", "\u0012xt+\u000f\"\u0019xv+:", "\u0005ZP=KL\fZS=I", "\u0011\u007f2P)g\u001a\u007f:", ",rKr,4'r@", "3\u0010=dZ\tF06kKF'>=`O\u001cS", Void.TYPE, "\u0001e\u0014Kf\b\be\u0017Kk", "Q,:\u0014g<Q,-Hk3Kg-Vk&L\u0016}\u000b:", "5^y]d\u0011>^{]k", Integer.TYPE, "\u0005y4(UkpY?'D$\u0011W4,@~e", Boolean.TYPE, "uR`#4'yRs", "z$\u0000N\u0003\ts$\u0003N\u0003", "\u0017\u0019\u0005>}\u007f\u001c\u0016\u0014q\u001cq\u0017\u001d\u0010+", "w\u001e=\u0014hH\u0002>6\u001by\u0007c0=\u0010}]\u0017", "\u0004l\u0005!\u0019s\u0004l\u0012}\u0015|\u001e'\u0012c\u0015i\u0019V@<D#", "PI_\u0017\u0007sAIx", "\u00183[SLg\u0013<J\u001c1\u007f\u0000;CU", "\u000fXUA}?\u0004\u0014P\u001f\u001e(4[\u0016_.![\u0002QG{", ".5+z\u0006\t-nd\u001f\u0006j91x\"\u001dR(~&#o\u0001ovtg\u0013\u0014=0&\u001f", "n6)H7%4,'\u001f\u0006wPx1\u0000:'=7{\u0003`\u001d", "FQ4@\u0007 W\n|/#\u000fr6Ys\"\u0017ej`\u0014Y=L\u0018qO\u0011", ":>7LG\f9ex)Go-:d\u0014\\W<u:\u0015._'~k\u0019\u0017\u000b$c?)", "g\u0019V\u0010;CdB\u0019u7 #A\u0018\f*Dh\u0010\u0016\u0014", "]\u0019\u0011\bLR^B^mL1\u0011G\u0011\u001dO\fQY\u001f\u0006%\u0000G\u0011P\u0007\u0018@Y\u001fKm", "_p'*\u001cf\u001f+p+'\u001c\"_T\f{W_p'*\u001cf\u001f+p+", "(\u0001&qx.|\rvk\u001e>C\u001ftp{o\"Is{zUs\u0013d|.l'\u0010y(\u001e", "Cj\u001f\u0018,CJ.XN\\E*<B\u0012'Q\u001aiT^!,", "F\n\ntBG\u001c\u0010\u0004#s\u0014xD\u0012<OE\u0015\u000bX?\u0015\u007f", "r{_,6Xy7ZrUBI,\u001e.hTq=Qpi&uw\u001bq7Xt%H4U", "\u001e,cC}$\u001dw,&rG^(5Li%\u0011ibW"};
    private static final String[] t = new String[]{null, null, null, null, null, null, "java/lang/Void", null, null, null, "java/lang/Integer", null, "java/lang/Boolean", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null};

    public Piercing() {
        long l2 = o ^ 0x462D9669E6AAL;
        long l3 = l2 ^ 0x1AD2A50DFE90L;
        super("Piercing", "Hit through entities and blocks.", Category.COMBAT);
        this.blocks = new BoolSetting("Blocks", true);
        this.sortBy = new l("Sort By", (Enum)a.a.a.j.c.m.HURT_TIME, m.class);
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.blocks, this.sortBy};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        Client.a().a(q.class, this);
    }

    @Override
    public void e() {
        Client.a().b(q.class, this);
    }

    @Override
    public void a() {
        long l2 = o ^ 0x355F07B0EEF9L;
        long l3 = l2 ^ 0x30E0A3CD88F6L;
        if (BaseModule.a.player == null || BaseModule.a.level == null || BaseModule.a.screen != null) {
            return;
        }
        if (!BaseModule.a.options.keyAttack.isDown()) {
            return;
        }
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        LivingEntity target = this.a(objectArray);
        if (target == null) {
            return;
        }
        BaseModule.a.hitResult = new EntityHitResult((Entity)target);
        BaseModule.a.crosshairPickEntity = target;
    }

    private LivingEntity a(Object[] objectArray) {
        ArrayList<Object> resultList;
        block34: {
            ArrayList<LivingEntity> targets;
            block35: {
                block33: {
                    Object object;
                    int n2;
                    long l2;
                    block23: {
                        int n3;
                        int n4;
                        block31: {
                            block32: {
                                block24: {
                                    block25: {
                                        AABB searchBox;
                                        Minecraft mc;
                                        double reachDistanceSq;
                                        Vec3 rayEnd;
                                        double rayLength;
                                        Vec3 lookVector;
                                        Vec3 eyePos;
                                        long l3;
                                        block27: {
                                            block26: {
                                                double d4;
                                                block28: {
                                                    double d5;
                                                    l2 = (Long)objectArray[0];
                                                    l3 = (l2 = o ^ l2) ^ 0x217A5D855491L;
                                                    float partialTick = BaseModule.a.getDeltaTracker().getGameTimeDeltaPartialTick(false);
                                                    eyePos = BaseModule.a.player.getEyePosition(partialTick);
                                                    lookVector = BaseModule.a.player.getViewVector(partialTick);
                                                    double entityRange = BaseModule.a.player.entityInteractionRange();
                                                    n2 = 0;
                                                    rayLength = Math.max(entityRange, BaseModule.a.player.blockInteractionRange());
                                                    rayEnd = eyePos.add(lookVector.scale(rayLength));
                                                    reachDistanceSq = entityRange * entityRange;
                                                    if (((Boolean)this.blocks.a()).booleanValue()) break block26;
                                                    mc = BaseModule.a;
                                                    if (n2 != 0) break block27;
                                                    searchBox = mc.level.clip(new ClipContext(eyePos, rayEnd, ClipContext.mc3960.OUTLINE, ClipContext.mc242.NONE, (Entity)BaseModule.a.player));
                                                    if (searchBox.getType() == HitResult.mc240.MISS) break block26;
                                                    d4 = d5 = eyePos.distanceToSqr(searchBox.getLocation());
                                                    if (n2 != 0) break block28;
                                                    if (!(d4 < reachDistanceSq)) break block26;
                                                    d4 = d5;
                                                }
                                                reachDistanceSq = d4;
                                            }
                                            mc = BaseModule.a;
                                        }
                                        searchBox = mc.player.getBoundingBox().expandTowards(lookVector.scale(rayLength)).inflate(1.0, 1.0, 1.0);
                                        targets = new ArrayList<LivingEntity>();
                                        Iterator iterator = BaseModule.a.level.getEntities((Entity)BaseModule.a.player, searchBox, Piercing::lambda$findTarget$0).iterator();
                                        block0: while (true) {
                                            int n5 = iterator.hasNext();
                                            while (n5 != 0) {
                                                block30: {
                                                    int n6;
                                                    LivingEntity target;
                                                    block29: {
                                                        Entity entity;
                                                        Entity candidate = (Entity)iterator.next();
                                                        object = candidate;
                                                        if (l2 < 0L) break block23;
                                                        if (n2 == 0) {
                                                            int n3 = object instanceof LivingEntity;
                                                            n3 = n2;
                                                            if (l2 < 0L) break block24;
                                                            if (n3 != 0) break block25;
                                                            if (n4 == 0) continue block0;
                                                            entity = candidate;
                                                        }
                                                        target = (LivingEntity)entity;
                                                        Object[] objectArray2 = new Object[2];
                                                        objectArray2[1] = l3;
                                                        objectArray2[0] = target;
                                                        if (!this.a(objectArray2)) continue block0;
                                                        AABB entityBox = candidate.getBoundingBox().inflate((double)candidate.getPickRadius());
                                                        Optional clipResult = entityBox.clip(eyePos, rayEnd);
                                                        int n6 = clipResult.isEmpty();
                                                        n6 = n2;
                                                        if (l2 < 0L) break block29;
                                                        if (n6 == 0) {
                                                            if (n5 != 0 && l2 >= 0L) continue block0;
                                                            double d5 = eyePos.distanceToSqr((Vec3)clipResult.get()) - reachDistanceSq;
                                                            n5 = d5 == 0.0 ? 0 : (d5 > 0.0 ? 1 : -1);
                                                        }
                                                        if (l2 < 0L) break block30;
                                                        n6 = n2;
                                                    }
                                                    if (n6 == 0) {
                                                        if (n5 > 0 && l2 > 0L) continue block0;
                                                        targets.add(target);
                                                    }
                                                    n5 = n2;
                                                }
                                                if (l2 <= 0L) continue;
                                                if (n5 != 0) break block0;
                                                continue block0;
                                            }
                                            break;
                                        }
                                        n4 = targets.isEmpty();
                                    }
                                    n3 = n2;
                                }
                                if (l2 < 0L) break block31;
                                if (n3 != 0) break block32;
                                if (n4 != 0) {
                                    return null;
                                }
                                object = targets;
                                if (l2 < 0L || n2 != 0) break block23;
                                n4 = object.size();
                            }
                            n3 = 1;
                        }
                        if (n4 == n3) {
                            return (LivingEntity)targets.get(0);
                        }
                        object = this.sortBy.a();
                    }
                    if (object != a.a.a.j.c.m.HURT_TIME) break block33;
                    resultList = targets;
                    if (l2 <= 0L) break block34;
                    targets.sort(Comparator.comparingInt(Piercing::lambda$findTarget$1));
                    if (n2 == 0) break block35;
                }
                targets.sort(Comparator.comparingDouble(LivingEntity::getHealth));
            }
            resultList = targets.get(0);
        }
        return (LivingEntity)resultList;
    }

    private boolean a(Object[] objectArray) {
        boolean bl;
        float f2;
        LivingEntity target;
        block6: {
            boolean bl2;
            block7: {
                block8: {
                    block5: {
                        target = (LivingEntity)objectArray[0];
                        long l2 = (Long)objectArray[1];
                        l2 = o ^ l2;
                        bl2 = false;
                        if (target == BaseModule.a.player || !target.isAlive()) break block5;
                        float f3 = target.getHealth() - 0.0f;
                        f2 = f3 == 0.0f ? 0 : (f3 < 0.0f ? -1 : 1);
                        bl = bl2;
                        if (l2 < 0L) break block6;
                        if (bl) break block7;
                        if (f2 > 0) break block8;
                    }
                    return false;
                }
                f2 = (float)(target instanceof Player);
            }
            bl = bl2;
        }
        if (!bl) {
            if (f2 != false) {
                Player player = (Player)target;
                return !F.c(player.getName().getString());
            }
            f2 = 1.0f;
        }
        return (boolean)f2;
    }

    private static int lambda$findTarget$1(LivingEntity target) {
        return target.hurtTime;
    }

    private static boolean lambda$findTarget$0(Entity entity) {
        return entity instanceof LivingEntity;
    }

    private static r a(r r2) {
        return r2;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = Piercing.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = Piercing.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = Piercing.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = Piercing.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }
}

