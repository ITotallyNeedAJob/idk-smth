// === Kuzi module: ModuleZ ===
// Category   : COMBAT
// Description: 
// Payload    : a.a.a.j.c.Z (verified: False)

package kuzi.modules.combat;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.Map;
import kn.bb542ffe4b746c218.L;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.module.Module;
import kuzi.obf.h.b.k;
import kuzi.obf.h.b.l;
import kuzi.obf.j.c.n;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.Player;
import net.minecraft.BlockPos;
import net.minecraft.Vec3;
import net.minecraft.BlockHitResult;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Duplicate member names - consider using --renamedupmembers true
 */
public class ModuleZ
extends BaseModule
implements Module {
    private final SliderSetting m;
    private final SliderSetting n;
    private final SliderSetting o;
    private final SliderSetting p;
    private final SliderSetting q;
    private final SliderSetting r;
    private final l s;
    private final k t;
    private final BoolSetting u;
    private final BoolSetting v;
    private static final int w = 20;
    private int x;
    private int y;
    private int z;
    private int A;
    private int B;
    private boolean C;
    private Vec3 D;
    private Vec3 E;
    private double F;
    private int G;
    private BlockHitResult H;
    private BlockPos I;
    private float J;
    private float K;
    private static final long L;
    private static final String[] M;
    private static final String[] N;
    private static final Map O;

    public ModuleZ() {
        long l2 = L ^ 0xE69F3846090L;
        long l3 = l2 ^ 0x309DA6424B2EL;
        super((String)((Object)ModuleZ.b("z", (int)12180, (long)(0x43DF0795D214BA5BL ^ l2))), (String)((Object)ModuleZ.b("z", (int)14476, (long)(0x34FEE0DA1407AD45L ^ l2))), Category.COMBAT);
        this.m = new SliderSetting((String)((Object)ModuleZ.b("z", (int)20530, (long)(0x224FAD3AF898C5F2L ^ l2))), 6.0, 2.0, 12.0, 0.5);
        this.n = new SliderSetting((String)((Object)ModuleZ.b("z", (int)9077, (long)(0x17825989975836BDL ^ l2))), 4.5, 2.0, 5.0, 0.1);
        this.o = new SliderSetting((String)((Object)ModuleZ.b("z", (int)22466, (long)(0x2897C74D9089C20FL ^ l2))), 40.0, 5.0, 120.0, 1.0);
        this.p = new SliderSetting((String)((Object)ModuleZ.b("z", (int)28471, (long)(0x6CC46E3FEC587AFBL ^ l2))), 1.5, 0.0, 8.0, 0.1);
        this.q = new SliderSetting((String)((Object)ModuleZ.b("z", (int)300, (long)(0x312E81AF49F614EDL ^ l2))), 1.0, 1.0, 10.0, 1.0);
        this.r = new SliderSetting((String)((Object)ModuleZ.b("z", (int)19245, (long)(0x763452DD13AF5EE7L ^ l2))), 6.0, 0.0, 40.0, 1.0);
        this.s = new l((String)((Object)ModuleZ.b("z", (int)24392, (long)(0x3CC5EBDC3B534A83L ^ l2))), kuzi.obf.j.c.n.Silent, n.class);
        this.t = new k((String)((Object)ModuleZ.b("z", (int)16043, (long)(0x43DBCF9D5C1C2B65L ^ l2))), 1.0, 20.0, 0.5, 5.0, 9.0);
        this.u = new BoolSetting((String)((Object)ModuleZ.b("z", (int)27246, (long)(0x4A46CF9B2486FFADL ^ l2))), true);
        this.v = new BoolSetting((String)((Object)ModuleZ.b("z", (int)32502, (long)(0x6136C60F10A6EB34L ^ l2))), true);
        this.x = -1;
        this.y = 0;
        this.z = 0;
        this.A = -1;
        this.B = 0;
        this.C = false;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.m, this.n, this.o, this.p, this.q, this.r, this.s, this.t, this.u, this.v};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public native void d();

    @Override
    public native void e();

    @Override
    public native void h();

    private native void a();

    @Override
    public native void b();

    private native void a(float var1, float var2);

    private native boolean a(Vec3 var1);

    private native boolean b(Vec3 var1);

    private native boolean a();

    private native BlockHitResult a(BlockPos var1);

    private native void c();

    private native void f();

    private native BlockHitResult a(Player var1, Vec3 var2, Vec3 var3);

    private native Player a();

    private native int a();

    private native void l();

    private native Vec3 lambda$smoothAim$0();

    static {
        kn.bb542ffe4b746c218.L.init(ModuleZ.class, 4);
        ModuleZ.6137e0616f1d1895();
    }

    private static native String b(byte[] var0);

    private static native String b(int var0, long var1);

    private static native Object b(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native CallSite b(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native /* synthetic */ void 6137e0616f1d1895();
}

