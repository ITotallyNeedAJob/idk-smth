// === Kuzi module: AutoCob ===
// Category   : COMBAT
// Description: Places a cobweb at an enemy's feet when you look at the block they're standing on.
// Payload    : a.a.a.j.c.s (verified: True)

package kuzi.modules.combat;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.module.Module;
import kuzi.obf.m.r;
import kuzi.obf.p.aA;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.Entity;
import net.minecraft.Player;
import net.minecraft.BlockPos;
import net.minecraft.HitResult;
import net.minecraft.BlockHitResult;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class AutoCob
extends BaseModule
implements Module {
    private final SliderSetting range;
    private final BoolSetting switchBack;
    private final SliderSetting switchBackDelay;
    private final BoolSetting ignoreFriends;
    private int previousSlot;
    private int switchBackTicks;
    private int cooldownTicks;
    private static final long t = 75716963128352L;
    private static final String[] u;
    private static final String[] v;
    private static final Map w;
    private static final long x;
    private static final Object[] y;
    private static final String[] z;

    public AutoCob() {
        long l2 = t ^ 0x19B64E9B9341L;
        long l3 = l2 ^ 0x7C887F56DC74L;
        super("AutoCob", "Places a cobweb at an enemy's feet when you look at the block they're standing on.", Category.COMBAT);
        this.range = new SliderSetting("Range", 5.0, 1.0, 8.0, 0.5);
        this.switchBack = new BoolSetting("Switch Back", true);
        this.switchBackDelay = new SliderSetting("Switch Back Delay", 2.0, 0.0, 20.0, 1.0);
        this.ignoreFriends = new BoolSetting("Ignore Friends", true);
        this.previousSlot = -1;
        this.switchBackTicks = 0;
        this.cooldownTicks = 0;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.range, this.switchBack, this.switchBackDelay, this.ignoreFriends};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        Client.a().a(Module.class, this);
        super.d();
        this.previousSlot = -1;
        this.switchBackTicks = 0;
        this.cooldownTicks = 0;
    }

    @Override
    public void e() {
        long l2 = t ^ 0x3A2C9F2713C3L;
        long l3 = l2 ^ 0x1258A807D225L;
        Client.a().b(Module.class, this);
        super.e();
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.a(objectArray);
        this.switchBackTicks = 0;
        this.cooldownTicks = 0;
    }

    @Override
    public void b() {
        BlockHitResult blockHit;
        long l2;
        long l3 = l2 = t ^ 0x5CB3DD5D0CE4L;
        long l4 = l3 ^ 0x29C6ABDB0BD8L;
        long l5 = l3 ^ 0x7CA01CC1FEA4L;
        int n2 = (int)(l5 >>> 48);
        int n3 = (int)(l5 << 16 >>> 32);
        int n4 = (int)(l5 << 48 >>> 48);
        long l6 = l3 ^ 0x74C7EA7DCD02L;
        if (BaseModule.a.player == null || BaseModule.a.level == null || BaseModule.a.gameMode == null) {
            return;
        }
        if (BaseModule.a.screen != null) {
            return;
        }
        if (this.switchBackTicks > 0) {
            --this.switchBackTicks;
            if (this.switchBackTicks == 0) {
                Object[] objectArray = new Object[1];
                objectArray[0] = l6;
                this.a(objectArray);
            }
            return;
        }
        if (this.cooldownTicks > 0) {
            --this.cooldownTicks;
            return;
        }
        HitResult hitOrTarget = BaseModule.a.hitResult;
        if (!(hitOrTarget instanceof BlockHitResult) || (blockHit = (BlockHitResult)hitOrTarget).getType() != HitResult.mc240.BLOCK) {
            return;
        }
        Object[] objectArray = new Object[3];
        objectArray[2] = (int)((char)n4);
        objectArray[1] = n3;
        objectArray[0] = (int)((char)n2);
        hitOrTarget = this.a(objectArray);
        if (hitOrTarget == null) {
            return;
        }
        BlockPos targetPos = hitOrTarget.blockPosition();
        BlockPos placePos = blockHit.getBlockPos().relative(blockHit.getDirection());
        if (!placePos.equals((Object)targetPos) && !placePos.equals((Object)targetPos.above())) {
            return;
        }
        if (!BaseModule.a.level.getBlockState(placePos).canBeReplaced()) {
            return;
        }
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l4;
        int slot = this.a(objectArray2);
        if (slot == -1) {
            return;
        }
        if (((Boolean)this.switchBack.a()).booleanValue()) {
            this.previousSlot = BaseModule.a.player.getInventory().getSelectedSlot();
        }
        BaseModule.a.player.getInventory().setSelectedSlot(slot);
        aA.a(blockHit, true);
        int delayTicks = Math.max(1, ((Double)this.switchBackDelay.a()).intValue());
        if (((Boolean)this.switchBack.a()).booleanValue()) {
            this.switchBackTicks = delayTicks;
        }
        this.cooldownTicks = delayTicks + 1;
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private Player a(Object[] var1_1) {
        block23: {
            var3_2 = (Integer)var1_1[0];
            var4_3 = (Integer)var1_1[1];
            var2_4 = (Integer)var1_1[2];
            var5_5 = ((long)var3_2 << 48 | (long)var4_3 << 32 >>> 16 | (long)var2_4 << 48 >>> 48) ^ AutoCob.t;
            var8_6 = (Double)AutoCob.c("\u00fd", (Object)AutoCob.c("P", (Object)this, (long)-987968933124854879L, (long)var5_5), (long)-988186062891931216L, (long)var5_5);
            var10_7 = var8_6 * var8_6;
            var12_8 = null;
            var13_9 = AutoCob.c("Y", (long)-988911006030359638L, (long)var5_5).level.players().iterator();
            var7_10 = AutoCob.c("r", (long)-988561065808210885L, (long)var5_5);
            block18: while (true) {
                v0 = var13_9.hasNext();
                while (v0 != 0) {
                    block33: {
                        block34: {
                            block31: {
                                block32: {
                                    block30: {
                                        block29: {
                                            block28: {
                                                block26: {
                                                    block27: {
                                                        block25: {
                                                            block24: {
                                                                var14_11 = (Player)var13_9.next();
                                                                try {
                                                                    try {
                                                                        v1 = var14_11;
                                                                        if (var2_4 <= 0) break block23;
                                                                        v2 = var7_10;
                                                                        if (var4_3 > 0) {
                                                                            if (v2 != false) break block23;
                                                                            v2 = var7_10;
                                                                        }
                                                                        if (v2 != false) break block24;
                                                                    }
                                                                    catch (r v3) {
                                                                        throw AutoCob.c("r", (Object)v3, (long)-989092158946786350L, (long)var5_5);
                                                                    }
                                                                    if (v1 == AutoCob.c("Y", (long)-988911006030359638L, (long)var5_5).player) continue block18;
                                                                }
                                                                catch (r v4) {
                                                                    throw AutoCob.c("r", (Object)v4, (long)-989092158946786350L, (long)var5_5);
                                                                }
                                                                v5 = var14_11;
                                                            }
                                                            try {
                                                                v6 /* !! */  = v5.isDeadOrDying();
                                                                v7 = var7_10;
                                                                if (var2_4 >= 0) {
                                                                    if (v7 != false) break block25;
                                                                    if (v6 /* !! */ ) continue block18;
                                                                }
                                                                ** GOTO lbl47
                                                            }
                                                            catch (r v8) {
                                                                throw AutoCob.c("r", (Object)v8, (long)-989092158946786350L, (long)var5_5);
                                                            }
                                                            v6 /* !! */  = var14_11.isSpectator();
                                                        }
                                                        try {
                                                            v7 = var7_10;
lbl47:
                                                            // 2 sources

                                                            if (var3_2 >= 0) {
                                                                if (v7 != false) break block26;
                                                                if (!v6 /* !! */ ) break block27;
                                                            }
                                                            ** GOTO lbl62
                                                        }
                                                        catch (r v9) {
                                                            throw AutoCob.c("r", (Object)v9, (long)-989092158946786350L, (long)var5_5);
                                                        }
                                                        if (var4_3 >= 0) continue block18;
                                                    }
                                                    v6 /* !! */  = (Boolean)AutoCob.c("\u00fd", (Object)AutoCob.c("P", (Object)this, (long)-989158408024845642L, (long)var5_5), (long)-988186062891931216L, (long)var5_5);
                                                }
                                                try {
                                                    try {
                                                        try {
                                                            v7 = var7_10;
lbl62:
                                                            // 2 sources

                                                            if (v7 != false) break block28;
                                                            if (!v6 /* !! */ ) break block29;
                                                        }
                                                        catch (r v10) {
                                                            throw AutoCob.c("r", (Object)v10, (long)-989092158946786350L, (long)var5_5);
                                                        }
                                                        v11 = var14_11;
                                                        if (var7_10 != false) break block30;
                                                    }
                                                    catch (r v12) {
                                                        throw AutoCob.c("r", (Object)v12, (long)-989092158946786350L, (long)var5_5);
                                                    }
                                                    v6 /* !! */  = AutoCob.c("r", v11.getName().getString(), (long)-988510504263561854L, (long)var5_5);
                                                }
                                                catch (r v13) {
                                                    throw AutoCob.c("r", (Object)v13, (long)-989092158946786350L, (long)var5_5);
                                                }
                                            }
                                            if (v6 /* !! */ ) continue block18;
                                        }
                                        v11 = var14_11;
                                    }
                                    var15_12 = v11.distanceToSqr((Entity)AutoCob.c("Y", (long)-988911006030359638L, (long)var5_5).player);
                                    try {
                                        try {
                                            if (var3_2 < 0) break block31;
                                            v14 = var15_12;
                                            if (var7_10 != false) break block32;
                                            cfr_temp_0 = v14 - var10_7;
                                            v0 = cfr_temp_0 == 0.0 ? 0 : (cfr_temp_0 < 0.0 ? -1 : 1);
                                            if (var4_3 < 0) break block33;
                                            if (v0 > 0) break block34;
                                        }
                                        catch (r v15) {
                                            throw AutoCob.c("r", (Object)v15, (long)-989092158946786350L, (long)var5_5);
                                        }
                                        v14 = var15_12;
                                    }
                                    catch (r v16) {
                                        throw AutoCob.c("r", (Object)v16, (long)-989092158946786350L, (long)var5_5);
                                    }
                                }
                                var10_7 = v14;
                            }
                            var12_8 = var14_11;
                        }
                        v0 = var7_10;
                    }
                    if (var2_4 <= 0) continue;
                    if (v0 != 0) break block18;
                    continue block18;
                }
                break;
            }
            v1 = var12_8;
        }
        return v1;
    }

    /*
     * Exception decompiling
     */
    private int a(Object[] var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * java.lang.UnsupportedOperationException
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.considerAsDoLoopStart(LoopIdentifier.java:383)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.identifyLoops1(LoopIdentifier.java:65)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:681)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private void a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = t ^ l2;
        if (this.previousSlot != -1 && BaseModule.a.player != null) {
            BaseModule.a.player.getInventory().setSelectedSlot(this.previousSlot);
            this.previousSlot = -1;
        }
    }

    static {
        y = new Object[]{"l\u001bm]9Vg\u001bo]+", "T\u000fJ\u0004\u0011\u0014X\u000fY", "`A7\u001c~\u001akA<", "6\u00115\u0005k\u001f6\u0011\"Yg\u0010,Z\"Gg\u0005++r\u001a6", "\u0000\u001ci%V\n\u000b\u001ck%Y", Integer.TYPE, "{(o\u001b\u0010\u001cr(l\u001b\u0012", "R?2\u001e\u0001\u0000C?\u0015", "\u0003\u0002.zS\n\b\r?5.\u0012\u001b\n6|", Boolean.TYPE, "E\u0016D\t%lL\u0016G\t%", "1k{\u000f{<:dj@\u001a21on\u001a", "N\u0010)\u0015c?G\u0010*\u0015o", "IBK\u000ft\\<b@\u0000e\u0013]lK\u000baI)", Void.TYPE, "yC\u0014\u001e8^\fc\u001f\u0011)\u0011mm\u0014\u001a-K\u0019", "yiD\u00131AyiSO=Nc\"SQ=[dS\u0001\u000bi\u001f", "-&\t\u0003O\\X\u0006\u0002\f^\u00139\b\t\u0007ZIM", "s&\u001b\u0005\u000b\"b&\u001bj", "\u0017\u001aZdPt\u0017\u001aM8\\{\rQM&\\n\n \u001ds\u000b(", "\u0004[ Om\u0011\u000f[(", "h\u001e\u0014;q\"\u001d>\u001f4`m|0\u0014?d7\b", "5\u000e\u0010ZX,;U\tcZ^7\n\u001f\u0004H,6^\u0019Y370T\u000b^L0$U\u0007c", "~C4=G#p\u0018-\u0004TQ.Ga~Gkr\u0015:~", "ka![P\u0018e:8bRjx2.\u0012[\u0014h#1bD\u0003c+*\u001cT\u0012|[", "C\u0012\u007fC`\u001bMIfzpi\u0013\u0013)Ku\u0015APz\u0017", "g\u0013a]w\u00009\u0013&\u001bJ\b^PrOz\u000b;U*L4", "N~\u0013\bH\u0010@%\n1Zb\u001e\u007fE\u0000]\u001eL<\u0016\\", "Obf\\O0A9\u007feMBMfi\u0002_0L2o_$(F\"s\u0014_'Y$ve", "'EN-\u001a\\)\u001eW\u0014\u0016.{\u0014\u001b+HWuC[~", "t57U>=zn.l<Ov18\u000b.=we>VUs#2m\u0012)!`a1l", "J\u0015<\u001a@9IXd\u0003 5pXn[\u0011!\f\n-\bM_", "\f]\u0013\u007f0uLPD\u007fPz0\u0013\u0016}-.AO\u0017~:\u0013\u000eBO.-kT\u001dZ~P", "yQJ\u0003\u000f.w\nS:\u0002\\)U\u001f@\u000ffu\u0007D@", "GO\u001b_wKI\u0017VY\n~m6nlV5GO\u001b_wKI\u0017VY", "3\u000e:iA_<\u001d`<3\u000bX\u0001d<\\^b\t${Cbf\u0002?jN\u001a<]*:3\u000b1\r*8L\f%\f&\u0005", "p+N\u0010OQ~pW)^# *\u0018\u0018Z_riKD", "$\u0002EO?+ \u0004\u0007\f\u0000 \u001bTG\u001919dPQOnI", "}l\u0004s<1~!\\j\\<G!V2m);s\u0015a1W", "l#\u001c\u000bTe2#[Mi`U4X\u0010\u000e\u007f'5\f\u0016S\u0004<3\u0006\u0004T{;'\u0007\bi", "U\u001c4d\u0014_[G-]\u001a-\tMabFT\u0007\u001a!7"};
        z = new String[]{null, null, null, null, null, "java/lang/Integer", null, null, null, "java/lang/Boolean", null, null, null, null, "java/lang/Void", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null};
        x = -6510056941874577399L;
    }

    private static r a(r r2) {
        return r2;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (z[n4] != null) {
            return n4;
        }
        Object object = y[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 22;
            case 1 -> 14;
            case 2 -> 30;
            case 3 -> 7;
            case 4 -> 54;
            case 5 -> 26;
            case 6 -> 23;
            case 7 -> 34;
            case 8 -> 35;
            case 9 -> 60;
            case 10 -> 48;
            case 11 -> 44;
            case 12 -> 56;
            case 13 -> 49;
            case 14 -> 39;
            case 15 -> 24;
            case 16 -> 59;
            case 17 -> 3;
            case 18 -> 52;
            case 19 -> 6;
            case 20 -> 38;
            case 21 -> 19;
            case 22 -> 31;
            case 23 -> 32;
            case 24 -> 47;
            case 25 -> 8;
            case 26 -> 12;
            case 27 -> 46;
            case 28 -> 45;
            case 29 -> 57;
            case 30 -> 27;
            case 31 -> 28;
            case 32 -> 17;
            case 33 -> 41;
            case 34 -> 13;
            case 35 -> 1;
            case 36 -> 11;
            case 37 -> 2;
            case 38 -> 10;
            case 39 -> 53;
            case 40 -> 33;
            case 41 -> 15;
            case 42 -> 50;
            case 43 -> 55;
            case 44 -> 37;
            case 45 -> 42;
            case 46 -> 4;
            case 47 -> 5;
            case 48 -> 16;
            case 49 -> 20;
            case 50 -> 51;
            case 51 -> 36;
            case 52 -> 21;
            case 53 -> 61;
            case 54 -> 62;
            case 55 -> 43;
            case 56 -> 0;
            case 57 -> 63;
            case 58 -> 18;
            case 59 -> 29;
            case 60 -> 40;
            case 61 -> 58;
            case 62 -> 25;
            default -> 9;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        AutoCob.z[n4] = new String(cArray);
        return n4;
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = AutoCob.e(l2, l3);
            object = y[n2];
            try {
                if (!(object instanceof String)) break block2;
                AutoCob.y[n2] = clazz = Class.forName(z[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = AutoCob.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = AutoCob.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = AutoCob.e(l2, l3);
        Object object = y[n2];
        if (object instanceof String) {
            String string = z[n2];
            int n3 = string.indexOf(8);
            Class clazz = AutoCob.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = AutoCob.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = AutoCob.c(clazz3, string2, clazz2)) != null) {
                    AutoCob.y[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = AutoCob.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        AutoCob.y[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = AutoCob.f(783349824635907L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = AutoCob.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = AutoCob.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = AutoCob.e(l2, l3);
        Object object = y[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = z[n2];
                int n4 = string2.indexOf(8);
                clazz3 = AutoCob.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = AutoCob.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = AutoCob.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        AutoCob.y[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = AutoCob.f(783349824635907L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = AutoCob.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        AutoCob.y[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = AutoCob.f(783349824635907L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == 'P' || c2 == '\u00aa' || c2 == 'Y' || c2 == '$') {
                field = AutoCob.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == 'P' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == '\u00aa' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == 'Y' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = AutoCob.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == '\u00fd' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == 'r' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = AutoCob.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/c/s" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(AutoCob.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

