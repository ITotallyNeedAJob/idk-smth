// === Kuzi module: PlacementOptimizer ===
// Category   : COMBAT
// Description: Adjusts block/crystal placement delays
// Payload    : a.a.a.j.c.U (verified: False)

package kuzi.modules.combat;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import kuzi.core.Client;
import kuzi.mixin.MixinExposed;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.module.Module;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class PlacementOptimizer
extends BaseModule
implements Module {
    private final BoolSetting excludeAnchorsGlowstone;
    private final SliderSetting blockDelay;
    private final SliderSetting crystalDelay;
    private static final long p = 112925397443807L;
    private static final Object[] t = new Object[]{"i)(iL&b)*ix", "dP^pU\u0013mP]pY", "OS%_v=FS&_v", "\"mqdIp)b`+(~\"idq", "\u001arp!B]\u0013rs!@", "4|]uq\\?|U", "%_IjZs._B", "l\u001f\u00189\u0017S\u0019?\u00136\u0006\u001cx1\u0018=\u0002F\f", Void.TYPE, "S~s#?C\u001ab.bQv/_Z\u0017\r=S~s#?C\u001ab.b", "\\\t6\u0016B7@\u0016!(D\u000eHD*K\u0013d@\u0000c", "wkn6B\u001but\u007f!#\u0000N)lk\u001a\u0007%(3 Oi", "\f\u0003o]w\u0018\u0010\u001cxcr!Q\u001f;\u000f)F\bMx\u0002", "\u0005'\u0000ALY\u00198\u0017\u007fK`\u0011j\u001c\u001c\u001d\n\u0019.U", "\u0010X\u0002\u0014l_NDS\u0013\u0013P,\u0007\u0002\u0015pHU\u0006\u0000\u0011#4\u0011^II/\u000eCYY\u001e\u0013"};
    private static final String[] u = new String[]{null, null, null, null, null, null, null, null, "java/lang/Void", null, null, null, null, null, null};

    public PlacementOptimizer() {
        long l2 = p ^ 0x2A6DE23E6D98L;
        long l3 = l2 ^ 0x6D3A97709252L;
        super("Placement Optimizer", "Adjusts block/crystal placement delays", Category.COMBAT);
        this.excludeAnchorsGlowstone = new BoolSetting("Exclude Anchors/Glowstone", true);
        this.blockDelay = new SliderSetting("Block delay", 3.0, 0.0, 5.0, 0.1);
        this.crystalDelay = new SliderSetting("Crystal delay", 0.0, 0.0, 2.0, 1.0);
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.excludeAnchorsGlowstone, this.blockDelay, this.crystalDelay};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        Client.a().a(Module.class, this);
        super.d();
    }

    @Override
    public void e() {
        Client.a().b(Module.class, this);
        super.e();
    }

    @Override
    public void b() {
    }

    @MixinExposed
    public boolean a() {
        return (Boolean)this.excludeAnchorsGlowstone.a();
    }

    @MixinExposed
    public int a() {
        return ((Double)this.blockDelay.a()).intValue();
    }

    @MixinExposed
    public int c() {
        return ((Double)this.crystalDelay.a()).intValue();
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = PlacementOptimizer.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = PlacementOptimizer.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = PlacementOptimizer.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = PlacementOptimizer.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }
}

