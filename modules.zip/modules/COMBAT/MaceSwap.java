// === Kuzi module: MaceSwap ===
// Category   : COMBAT
// Description: Switches to mace when hitting
// Payload    : a.a.a.j.c.Q (verified: True)

package kuzi.modules.combat;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Optional;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.g.a.b;
import kuzi.obf.g.a.n;
import kuzi.obf.h.b.v;
import kuzi.obf.m.r;
import kuzi.obf.p.K;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.EndCrystal;
import net.minecraft.AxeItem;
import net.minecraft.ItemStack;
import net.minecraft.Items;
import net.minecraft.ResourceKey;
import net.minecraft.Holder;
import net.minecraft.ItemEnchantments;
import net.minecraft.DataComponents;
import net.minecraft.MaceItem;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class MaceSwap
extends BaseModule
implements n {
    private final BoolSetting switchBack;
    private final SliderSetting switchBackDelay;
    private final BoolSetting instaSwap;
    private final BoolSetting weaponOnly;
    private final BoolSetting notOnAxe;
    private final BoolSetting ignoreEndCrystals;
    private final BoolSetting smart;
    private final SliderSetting densityHeight;
    private int previousSlot;
    private int switchBackTicks;
    private double peakY;
    private static final long x;
    private static final String[] y;
    private static final String[] z;
    private static final Map A;
    private static final long[] B;
    private static final Integer[] C;
    private static final Map D;
    private static final Object[] E;
    private static final String[] F;

    public MaceSwap() {
        long l2 = x ^ 0x24918881A128L;
        long l3 = l2 ^ 0x68D55383DF68L;
        super("MaceSwap", "Switches to mace when hitting", Category.COMBAT);
        this.switchBack = new BoolSetting("Switch Back", true);
        this.switchBackDelay = new SliderSetting("Switch Back Delay", 1.0, 0.0, 20.0, 1.0);
        this.instaSwap = new BoolSetting("Insta Swap", false);
        this.weaponOnly = new BoolSetting("Weapon Only", true);
        this.notOnAxe = new BoolSetting("Not On Axe", true);
        this.ignoreEndCrystals = new BoolSetting("Ignore End Crystals", false);
        this.smart = new BoolSetting("Smart", true);
        this.densityHeight = new SliderSetting("Density Height", 3.0, 0.0, 10.0, 0.5);
        this.previousSlot = -1;
        this.switchBackTicks = 0;
        this.peakY = 0.0;
        Setting[] settingArray = new Setting[]{this.switchBack, this.switchBackDelay, this.instaSwap, this.weaponOnly, this.notOnAxe, this.ignoreEndCrystals, this.smart, this.densityHeight};
        Object[] objectArray = new Object[2];
        objectArray[1] = settingArray;
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        block3: {
            block2: {
                Client.c.a(n.class, this);
                int n2 = 66;
                super.d();
                this.previousSlot = -1;
                MaceSwap self = this;
                if (n2 == 0) break block2;
                self.switchBackTicks = 0;
                if (BaseModule.a.player == null) break block3;
                self = this;
            }
            self.peakY = BaseModule.a.player.getY();
        }
    }

    @Override
    public void e() {
        Client.c.b(n.class, this);
        super.e();
    }

    @Override
    public void a(b event) {
        long l2;
        long l3 = l2 = x ^ 0x5CD969F94182L;
        long l4 = l3 ^ 0x3F655B583679L;
        long l5 = l3 ^ 0x2F895BC2FE64L;
        if (BaseModule.a.player == null || BaseModule.a.level == null) {
            return;
        }
        if (((Boolean)this.ignoreEndCrystals.a()).booleanValue() && event.c instanceof EndCrystal) {
            return;
        }
        ItemStack heldItem = BaseModule.a.player.getMainHandItem();
        if (heldItem.getItem() instanceof MaceItem) {
            return;
        }
        if (((Boolean)this.weaponOnly.a()).booleanValue()) {
            Object[] objectArray = new Object[2];
            objectArray[1] = l4;
            objectArray[0] = heldItem;
            if (!this.isWeapon(objectArray)) {
                return;
            }
        }
        if (((Boolean)this.notOnAxe.a()).booleanValue() && heldItem.getItem() instanceof AxeItem) {
            return;
        }
        Object[] objectArray = new Object[1];
        objectArray[0] = l5;
        int maceSlot = this.findMaceSlot(objectArray);
        if (maceSlot == -1) {
            return;
        }
        if (((Boolean)this.switchBack.a()).booleanValue()) {
            this.previousSlot = BaseModule.a.player.getInventory().getSelectedSlot();
        }
        BaseModule.a.player.getInventory().setSelectedSlot(maceSlot);
        if (((Boolean)this.switchBack.a()).booleanValue() && this.previousSlot != -1) {
            this.switchBackTicks = (Boolean)this.instaSwap.a() != false ? 1 : ((Double)this.switchBackDelay.a()).intValue();
        }
    }

    @Override
    public void i() {
        if (BaseModule.a.player == null || BaseModule.a.level == null) {
            return;
        }
        this.peakY = BaseModule.a.player.onGround() ? BaseModule.a.player.getY() : Math.max(this.peakY, BaseModule.a.player.getY());
        if (this.switchBackTicks > 0) {
            --this.switchBackTicks;
            if (this.switchBackTicks == 0 && this.previousSlot != -1) {
                BaseModule.a.player.getInventory().setSelectedSlot(this.previousSlot);
                this.previousSlot = -1;
            }
        }
    }

    private int findMaceSlot(Object[] objectArray) {
        long l2;
        long l3;
        block6: {
            int n2;
            block8: {
                int n3;
                int n4;
                long l4;
                block7: {
                    l3 = (Long)objectArray[0];
                    long l5 = l3 = x ^ l3;
                    l2 = l5 ^ 0x307539726352L;
                    l4 = l5 ^ 0x325C6A4EEF66L;
                    int n5 = 0;
                    if (!((Boolean)this.smart.a()).booleanValue()) {
                        Object[] objectArray2 = new Object[1];
                        objectArray2[0] = l4;
                        return this.findPlainMaceSlot(objectArray2);
                    }
                    double fallDistance = Math.max(0.0, this.peakY - BaseModule.a.player.getY());
                    if (!(fallDistance > (Double)this.densityHeight.a())) break block6;
                    Object[] objectArray3 = new Object[2];
                    objectArray3[1] = l2;
                    objectArray3[0] = new String[]{MaceSwap.b("y", (int)21449, (long)(0x26C043F6F398D6B4L ^ l3)), MaceSwap.b("y", (int)16605, (long)(0x29745BE1AEEFC5A5L ^ l3))};
                    n2 = n4 = this.findBestMaceSlot(objectArray3);
                    n3 = n5;
                    if (l3 <= 0L) break block7;
                    if (n3 != 0) break block8;
                    n3 = -1;
                }
                if (n2 != n3) {
                    n2 = n4;
                } else {
                    Object[] objectArray4 = new Object[1];
                    objectArray4[0] = l4;
                    n2 = this.findPlainMaceSlot(objectArray4);
                }
            }
            return n2;
        }
        Object[] objectArray5 = new Object[2];
        objectArray5[1] = l2;
        objectArray5[0] = new String[]{MaceSwap.b("y", (int)15940, (long)(0x2A2A29C0B913B36L ^ l3))};
        return this.findBestMaceSlot(objectArray5);
    }

    private boolean isWeapon(Object[] objectArray) {
        ItemStack item = (ItemStack)objectArray[0];
        long l2 = (Long)objectArray[1];
        l2 = x ^ l2;
        if (item.isEmpty()) {
            return false;
        }
        return item.getItem() instanceof MaceItem || item.getItem() instanceof AxeItem || K.a(item);
    }

    private int findPlainMaceSlot(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = x ^ l2;
        int n2 = 0;
        int n3 = 66;
        while (n2 < MaceSwap.c("h", (int)23423, (long)(0x54897D350B102A4L ^ l2))) {
            ItemStack stack = BaseModule.a.player.getInventory().getItem(n2);
            int n4 = n3;
            if (l2 >= 0L) {
                if (n4 != 0) {
                    if (stack.getItem() == Items.MACE) {
                        return n2;
                    }
                    ++n2;
                }
                n4 = n3;
            }
            if (n4 != 0) continue;
        }
        return -1;
    }

    private int findBestMaceSlot(Object[] objectArray) {
        String[] enchantNames = (String[])objectArray[0];
        long l2 = (Long)objectArray[1];
        long l3 = (l2 = x ^ l2) ^ 0x58F67DF41C91L;
        int bestSlot = -1;
        boolean bl = false;
        int bestLevel = 0;
        int n4 = 0;
        while (n4 < MaceSwap.c("h", (int)13479, (long)(0x5F5507F9399BE14AL ^ l2))) {
            boolean bl2;
            block6: {
                block7: {
                    block5: {
                        ItemStack stack = BaseModule.a.player.getInventory().getItem(n4);
                        if (stack.getItem() != Items.MACE) break block5;
                        Object[] objectArray2 = new Object[3];
                        objectArray2[2] = enchantNames;
                        objectArray2[1] = stack;
                        objectArray2[0] = l3;
                        int level = this.maxEnchantLevel(objectArray2);
                        bl2 = bl;
                        if (l2 < 0L) break block6;
                        if (bl2) break block7;
                        if (level > bestLevel) {
                            bestLevel = level;
                            bestSlot = n4;
                        }
                    }
                    ++n4;
                }
                bl2 = bl;
            }
            if (!bl2) continue;
        }
        return bestSlot;
    }

    private int maxEnchantLevel(Object[] objectArray) {
        int n2;
        block9: {
            long l2 = (Long)objectArray[0];
            ItemStack item = (ItemStack)objectArray[1];
            String[] enchantNames = (String[])objectArray[2];
            l2 = x ^ l2;
            ItemEnchantments enchantments = (ItemEnchantments)item.get(DataComponents.ENCHANTMENTS);
            int n3 = 66;
            if (enchantments == null) {
                return 0;
            }
            int maxLevel = 0;
            Iterator iterator = enchantments.keySet().iterator();
            block0: while (true) {
                int n5 = iterator.hasNext();
                block1: while (n5 != 0) {
                    int n6;
                    Holder enchantmentHolder = (Holder)iterator.next();
                    Optional enchantKey = enchantmentHolder.unwrapKey();
                    if (n3 != 0) {
                        n2 = enchantKey.isEmpty() ? 1 : 0;
                        if (n3 == 0) break block9;
                        if (n2 != 0 && l2 > 0L) continue block0;
                        enchantKey = enchantmentHolder.unwrapKey().get();
                    }
                    String enchantId = ((ResourceKey)enchantKey).identifier().getPath();
                    String[] names = enchantNames;
                    int n7 = names.length;
                    int n8 = n6 = 0;
                    while (n6 < n7) {
                        String wantedEnchant = names[n6];
                        int n9 = n3;
                        if (l2 > 0L) {
                            if (n9 != 0) {
                                n5 = enchantId.contains(wantedEnchant) ? 1 : 0;
                                if (n3 == 0) continue block1;
                                if (l2 < 0L) continue;
                                if (n5 != 0) {
                                    maxLevel = Math.max(maxLevel, enchantments.getLevel(enchantmentHolder));
                                }
                                ++n6;
                            }
                            n9 = n3;
                        }
                        if (n9 != 0) continue;
                    }
                    n5 = n3;
                    if (l2 < 0L) continue;
                    if (n5 == 0) break block0;
                    continue block0;
                }
                break;
            }
            n2 = maxLevel;
        }
        return n2;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block21: {
            block20: {
                block19: {
                    block18: {
                        MaceSwap.x = kuzi.obf.h.b.v.a(3774986918100614568L, 4593509595821923367L, MethodHandles.lookup().lookupClass()).a(141187477882018L);
                        MaceSwap.E = new Object[46];
                        MaceSwap.F = new String[46];
                        MaceSwap.c();
                        MaceSwap.A = new HashMap<K, V>(13);
                        var11 = MaceSwap.x ^ 74214270569310L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[13];
                        var18_4 = 0;
                        var17_5 = "z\u00bc\bng\u0001qb`/\u00de\u0080S*\u00da\u00f7\u0010$tg=qb/ \u00ec\u00f6\u0018xU\u0089~J\rds1G\u0003\u0010\u0085\u00012\u00aam\u0016\b\u00e1X\u00e9\r\u00a5H\u0002\u00d7\u00af^(\u00f9d\u008f2$1\u007f\u00e4\u009fD\u0087\u00aeF\u0092\u00d4\u000b\u008a\u00a3\u000e\u00a7\u007f\u0019\u00d7\u00b3f\u00b6\u0019?^\u008f\u007f\u00df\u0092\u00bfq\u00c1\u0015\u0017\u0086\u00ff\u0010\u00bd\u00ef\u00d0O\u008f\u0015\u00e0/\u0010\u00ff%\u00e63\u00ff-\u00f8 \u00f2\u0099-r\u00b0\u0088.\u00ba\u0004\u0093p%d\u0017c\u00d6\u0086\u00bbg\u0081Ua\u00d8C\u0094\u00d3\u00d9\u00ba\u00ee\u0088Z\u009e\u00108$l]\u00bf\u009aA~\u0087\u0082Y`\u00b2\u00b0\u00c4\u0002 \u009eD\u00a9\u008cD\u009bd\u00a6?\u00b2\u00ee\u00b6\u00f4\u00ba\u009cZ\u0010\u008d\u00f3v\u00f4\u00b8\u0097\r\u00cf\u0091\u0016\u009b\u008c\u00cb\u00f5\u001b\u0018\u0082\u001a\u001d\u0012\u00d0\u0017\u00e1%\u0006O%\u0091\u008dhH\u000e?;0\f\u001fF\"\u00b90\u00f5\u00ad\u008b\u0002C-\u0099Q\u00b6\u00f9\u00df\u00eb\u0081\u00e4\u0081~,\u00fe\u0002\u00aey\u00fc\u0083\u00cf\u00a5\u0087\u00ca\u00bdl\u00c5\u00b5\u0092p\u001a\u00d8g\u00ea0\u00c8\u00f1}\u00956`\u00d7\n\u0013\u00f7 \u00e7\u00d0\u00e6\u0094'\u00e4f\u000e\u00edu\".Z4\u00e4O\u0001\u00c2\u0093\f\u00bd\u001e\u0015_\u008fmz\u00ea9\u009b\u009f<8\u009a\u00e5\u001c\u0097\u00f6\u008f\u00c5\u0014\u0001]\u0080M\nl\u00fef\u00dd\u00d3\u00cf\u0010\u009f\u00dd\u00c9~\u00f4V\u00e5S\u00c1\u00fe\u00b0\u00b2\u00f4\u00e7K\u00cf]\u0019\u0081\u00a0\u0012.1\u00e5p0\u008fDI\u00b6\u0092\u0010b\u00ef~\u0097";
                        var19_6 = "z\u00bc\bng\u0001qb`/\u00de\u0080S*\u00da\u00f7\u0010$tg=qb/ \u00ec\u00f6\u0018xU\u0089~J\rds1G\u0003\u0010\u0085\u00012\u00aam\u0016\b\u00e1X\u00e9\r\u00a5H\u0002\u00d7\u00af^(\u00f9d\u008f2$1\u007f\u00e4\u009fD\u0087\u00aeF\u0092\u00d4\u000b\u008a\u00a3\u000e\u00a7\u007f\u0019\u00d7\u00b3f\u00b6\u0019?^\u008f\u007f\u00df\u0092\u00bfq\u00c1\u0015\u0017\u0086\u00ff\u0010\u00bd\u00ef\u00d0O\u008f\u0015\u00e0/\u0010\u00ff%\u00e63\u00ff-\u00f8 \u00f2\u0099-r\u00b0\u0088.\u00ba\u0004\u0093p%d\u0017c\u00d6\u0086\u00bbg\u0081Ua\u00d8C\u0094\u00d3\u00d9\u00ba\u00ee\u0088Z\u009e\u00108$l]\u00bf\u009aA~\u0087\u0082Y`\u00b2\u00b0\u00c4\u0002 \u009eD\u00a9\u008cD\u009bd\u00a6?\u00b2\u00ee\u00b6\u00f4\u00ba\u009cZ\u0010\u008d\u00f3v\u00f4\u00b8\u0097\r\u00cf\u0091\u0016\u009b\u008c\u00cb\u00f5\u001b\u0018\u0082\u001a\u001d\u0012\u00d0\u0017\u00e1%\u0006O%\u0091\u008dhH\u000e?;0\f\u001fF\"\u00b90\u00f5\u00ad\u008b\u0002C-\u0099Q\u00b6\u00f9\u00df\u00eb\u0081\u00e4\u0081~,\u00fe\u0002\u00aey\u00fc\u0083\u00cf\u00a5\u0087\u00ca\u00bdl\u00c5\u00b5\u0092p\u001a\u00d8g\u00ea0\u00c8\u00f1}\u00956`\u00d7\n\u0013\u00f7 \u00e7\u00d0\u00e6\u0094'\u00e4f\u000e\u00edu\".Z4\u00e4O\u0001\u00c2\u0093\f\u00bd\u001e\u0015_\u008fmz\u00ea9\u009b\u009f<8\u009a\u00e5\u001c\u0097\u00f6\u008f\u00c5\u0014\u0001]\u0080M\nl\u00fef\u00dd\u00d3\u00cf\u0010\u009f\u00dd\u00c9~\u00f4V\u00e5S\u00c1\u00fe\u00b0\u00b2\u00f4\u00e7K\u00cf]\u0019\u0081\u00a0\u0012.1\u00e5p0\u008fDI\u00b6\u0092\u0010b\u00ef~\u0097".length();
                        var16_7 = 24;
                        var15_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block18;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = MaceSwap.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "\u001f\u00e8vxT\u00c7e\u00ff\u00f0\u00f6\u0096\u000ek\u0096\u0080\u001e(*\u0005A\u00cd\u00a7\u00c6\u0095g\u00ed\u00bf\u00921\\\u0093\\\u0010I\u008f\u008c\u0082;\u00a3\u00d94\u00fc\u0090\u00dc\u00eb\u00bb\u00bb?t";
                            var19_6 = "\u001f\u00e8vxT\u00c7e\u00ff\u00f0\u00f6\u0096\u000ek\u0096\u0080\u001e(*\u0005A\u00cd\u00a7\u00c6\u0095g\u00ed\u00bf\u00921\\\u0093\\\u0010I\u008f\u008c\u0082;\u00a3\u00d94\u00fc\u0090\u00dc\u00eb\u00bb\u00bb?t".length();
                            var16_7 = 32;
                            var15_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block18;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = MaceSwap.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block19;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                MaceSwap.y = var20_3;
                MaceSwap.z = new String[13];
                MaceSwap.D = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[5];
                var3_13 = 0;
                var4_14 = "\u0099\u008d\u00ae\u00a2\u00e1\u0081\u00f1\u000f\u00bd@{\u00ed(\u00ee\u00b29\u000f\u00fcG\u001f\u00d6\u00a6}\u00b4";
                var5_15 = "\u0099\u008d\u00ae\u00a2\u00e1\u0081\u00f1\u000f\u00bd@{\u00ed(\u00ee\u00b29\u000f\u00fcG\u001f\u00d6\u00a6}\u00b4".length();
                var2_16 = 0;
                while (true) {
                    var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                    v10 = var6_12;
                    v11 = var3_13++;
                    v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                    v13 = -1;
                    break block20;
                    break;
                }
lbl81:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    var4_14 = "\u0096J\u00bekR#iP\u0014Yk\u00d3\u0016\u00eb\u0017\u00e1";
                    var5_15 = "\u0096J\u00bekR#iP\u0014Yk\u00d3\u0016\u00eb\u0017\u00e1".length();
                    var2_16 = 0;
                    while (true) {
                        var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                        v10 = var6_12;
                        v11 = var3_13++;
                        v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                        v13 = 0;
                        break block20;
                        break;
                    }
                    break;
                }
lbl94:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    break block21;
                    break;
                }
            }
            var8_18 = v12;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            v14 = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
            switch (v13) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl107:
                // 1 sources

                ** continue;
            }
        }
        MaceSwap.B = var6_12;
        MaceSwap.C = new Integer[5];
    }

    private static r a(r r2) {
        return r2;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static String b(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x3A97;
        if (z[n3] == null) {
            Object[] objectArray;
            try {
                Long l3 = Thread.currentThread().threadId();
                objectArray = (Object[])A.get(l3);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    A.put(l3, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/c/Q", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l2 >>> 56);
            for (int i2 = 1; i2 < 8; ++i2) {
                byArray[i2] = (byte)(l2 << i2 * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = y[n3].getBytes("ISO-8859-1");
            MaceSwap.z[n3] = MaceSwap.b(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return z[n3];
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        String string2 = MaceSwap.b(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static CallSite b(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/c/Q" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x6C0D;
        if (C[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = B[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])D.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    D.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/c/Q", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            MaceSwap.C[n3] = n4;
        }
        return C[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = MaceSwap.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/c/Q" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static void c() {
        Object[] objectArray = E;
        E[0] = "\u0004yv#(t\u000fy}";
        objectArray[1] = "\u0018\u001c%Q\u0019y\u0018\u001c2\r\u0015v\u0002W2\u0013\u0015c\u0005&bND";
        objectArray[2] = "Ft\t\u0006\u001awMt\u000b\u0006*";
        objectArray[3] = ">\u001f>~e~K?5qt1*1>zpk^";
        objectArray[4] = Integer.TYPE;
        MaceSwap.F[4] = "java/lang/Integer";
        objectArray[5] = "Cd\tS\u0003FHd\u000bS\f";
        objectArray[6] = "Y$x:2\u0002U$k";
        objectArray[7] = Double.TYPE;
        MaceSwap.F[7] = "java/lang/Double";
        objectArray[8] = "jIA0\u0011K\u001fiJ?\u0000\u0004~gA4\u0004^\n";
        objectArray[9] = "n\u000e\u001b6{M\u001b.\u00109j\u0002z \u001b2nX\u000e";
        objectArray[10] = "5D@\\}}<DC\\\u007f";
        objectArray[11] = "\u0012>xR\r%\u001b>{R\u0001";
        objectArray[12] = "t\fgz@\r}\fdz@";
        objectArray[13] = "4\u007f5w#8?p$8B64{ b";
        objectArray[14] = "\u000e6\u0004g\"${\u0016\u000fh3k\u001a\u0018\u0004c71n";
        objectArray[15] = "|\u001bGd6\u001c\t;Lk'Sh5G`#\t\u001c";
        objectArray[16] = Boolean.TYPE;
        MaceSwap.F[16] = "java/lang/Boolean";
        objectArray[17] = "-m\bV\u0000i<m\"";
        objectArray[18] = "w\u0000B\u0002gKw\u0000U^kDmKU@kQj:\u0007\u001b3\u001b";
        objectArray[19] = "t\nMn\u0018l\u007f\nE";
        objectArray[20] = "uq5\u001cJf\u0000Q>\u0013[)a_5\u0018_s\u0015";
        objectArray[21] = Void.TYPE;
        MaceSwap.F[21] = "java/lang/Void";
        objectArray[22] = "Ir3:;wK0-:\u0002bs'9\u007f9cB*%n:\u000eHruf?qJp&e\u0002";
        objectArray[23] = "YPq:7\u000b[\u0012o:\u000e\bcV1d4\u0010YR;x4";
        objectArray[24] = "EQtXY:G\u0013jX`:\u007fW4\u0006Z!ES>\u001aZ";
        objectArray[25] = "\u0007dy?\u0013a\u0005&g?*~=m2=PtB`n:X";
        objectArray[26] = "\".\u0002DvD}t\u000f-o?x*\u0007CzNxx\nC";
        objectArray[27] = "\u000b%\r\u001b~\u000f\tg\u0013\u001bG\u00131#ME}\u0014\u000b'GY}";
        objectArray[28] = "0P\u001a?\t 2\u0012\u0004?04\n\u0005\u0010z\u000b4;\b\fk\bY1P\\c\r&3R\u000f`0";
        objectArray[29] = "B\u0017r$E0@Ul$|6x\u00134{\u0015$H\u001eraF";
        objectArray[30] = "u\u001f\u0000\u0011\u0016-w]\u001e\u0011/3O\u0019@O\u00156u\u001dJS\u0015";
        objectArray[31] = "C+`NS\"Ai~Nj0y~j\u000bQ6Hsv\u001aR[B+&\u0012W$@)u\u0011j";
        objectArray[32] = "[s\u001cy\u00079I&\u0002d~10'\u000f1\u0010!M0\u001bv\u0005XZw\u0018wA2\t'\u0005h~";
        objectArray[33] = "|NvmgQ~\fhm^PFH63dJ|L</d";
        objectArray[34] = "t!\u0000(iX#~\n\u007f\u0005NO{Brb\u00190y@!a$";
        objectArray[35] = "L>\u001dr.\u0007N|\u0003r\u0017\u0017v;X0e\u000eKy\u0003p&~J9\u001f;gC\bb_x\u0017";
        objectArray[36] = "\u001c\f\u00056\u0004#\u001eN\u001b6=!&\nEh\u00078\u001c\u000eOt\u0007";
        objectArray[37] = "bD\fH.c`\u0006\u0012H\u0017gXFNNp''DL\u001ds";
        objectArray[38] = "Y\u0001%}9s[C;}\u0000ccT/8;gRY3)8\nX\u0001c!=uZ\u00030\"\u0000";
        objectArray[39] = "\u001b;iq[\f\u0017xmo?;0OHCcp\u001b;iq[\f\u0017xmo";
        objectArray[40] = "'\u001c\u0003K\u0006\u0005%^\u001dK?\u0000\u001d\u0015HIE\u0010b\u0018\u0014NM";
        objectArray[41] = "lqu&X)n3k&a9V$\u007fcZ=g)crYP<sic^:o#t|a";
        objectArray[42] = "+X\u001c\u000e\u0014&|\u0007\u0016Yx1\u0010\u0002^T\u001fgo\u0000\\\u0007\u001cZ";
        objectArray[43] = "gS`v2\u001e/S:h\\\rW\u001fm6m\u0004mJpsdd";
        objectArray[44] = "'\u0014wyC&%Viyz!\u001d\u00165\u007f\u001dbb\u00147,\u001e";
        Object[] objectArray2 = objectArray;
        objectArray[45] = "x 'u\u0016\u007f'z*\u001c\u0002\u0004wn2'\u000b5zr#$fikfss\rez!%\u001c";
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = MaceSwap.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = MaceSwap.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = MaceSwap.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = MaceSwap.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(MaceSwap.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(MaceSwap.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

