// === Kuzi module: WindPearlMacro ===
// Category   : COMBAT
// Description: Press a trigger key to throw an ender pearl followed by a wind charge.
// Payload    : a.a.a.j.c.aa (verified: True)

package kuzi.modules.combat;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.module.Module;
import kuzi.obf.h.b.v;
import kuzi.obf.i.k_0;
import kuzi.obf.m.r;
import kuzi.obf.p.L;
import kuzi.settings.BoolSetting;
import kuzi.settings.KeyBinding;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.Player;
import net.minecraft.Inventory;
import net.minecraft.Item;
import net.minecraft.ItemStack;
import net.minecraft.Items;
import net.minecraft.Minecraft;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class WindPearlMacro
extends BaseModule
implements Module {
    private final KeyBinding m;
    private final SliderSetting switchDelayMin;
    private final SliderSetting switchDelayMax;
    private final SliderSetting windDelayMin;
    private final SliderSetting windDelayMax;
    private final BoolSetting r;
    private static final int s = 1;
    private final Random t;
    private boolean u;
    private boolean v;
    private int w;
    private int x;
    private long y;
    private int z;
    private long A;
    private long B;
    private static final long C;
    private static final String[] D;
    private static final String[] E;
    private static final Map F;
    private static final long[] G;
    private static final Integer[] H;
    private static final Map I;
    private static final Object[] J;
    private static final String[] K;

    public WindPearlMacro() {
        long l2 = C ^ 0x3FE9BFB4C27L;
        long l3 = l2 ^ 0x2CB503D26B09L;
        super("WindPearlMacro", "Press a trigger key to throw an ender pearl followed by a wind charge.", Category.COMBAT);
        this.m = new KeyBinding("Trigger Key", -1);
        this.switchDelayMin = new SliderSetting("Switch Delay Min", 5.0, 0.0, 500.0, 1.0);
        this.switchDelayMax = new SliderSetting("Switch Delay Max", 20.0, 0.0, 500.0, 1.0);
        this.windDelayMin = new SliderSetting("Wind Delay Min", 5.0, 0.0, 200.0, 1.0);
        this.windDelayMax = new SliderSetting("Wind Delay Max", 20.0, 0.0, 200.0, 1.0);
        this.r = new BoolSetting("Swap Back", true);
        this.t = new Random();
        this.u = false;
        this.v = false;
        this.z = -1;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.m, this.switchDelayMin, this.switchDelayMax, this.windDelayMin, this.windDelayMax, this.r};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        Client.a().a(Module.class, this);
        this.u = false;
        this.v = false;
        this.w = 0;
        this.x = 0;
        this.z = -1;
    }

    @Override
    public void e() {
        Client.a().b(Module.class, this);
        this.u = false;
        this.w = 0;
        this.x = 0;
        this.z = -1;
    }

    private void a(Object[] payload) {
        long l2 = (Long)payload[0];
        long l3 = (l2 = C ^ l2) ^ 0x2FD389B45900L;
        int n2 = (int)(l3 >>> 48);
        int n3 = (int)(l3 << 16 >>> 32);
        int n4 = (int)(l3 << 48 >>> 48);
        this.u = true;
        this.w = 0;
        this.x = 0;
        this.y = System.currentTimeMillis();
        this.z = -1;
        Object[] objectArray2 = new Object[5];
        objectArray2[4] = (double)((Double)this.switchDelayMax.a());
        objectArray2[3] = n4;
        objectArray2[2] = n3;
        objectArray2[1] = (int)((short)n2);
        objectArray2[0] = (double)((Double)this.switchDelayMin.a());
        this.A = this.a(objectArray2);
        Object[] objectArray3 = new Object[5];
        objectArray3[4] = (double)((Double)this.windDelayMax.a());
        objectArray3[3] = n4;
        objectArray3[2] = n3;
        objectArray3[1] = (int)((short)n2);
        objectArray3[0] = (double)((Double)this.windDelayMin.a());
        this.B = this.a(objectArray3);
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public void b() {
        v0 = var1_1 = WindPearlMacro.C ^ 25041617642751L;
        var3_2 = v0 ^ 35385844438825L;
        var5_3 = v0 ^ 109769866049994L;
        var7_4 = v0 ^ 124092109235742L;
        var9_5 = v0 ^ 42501076029536L;
        var11_6 = v0 ^ 65259986634674L;
        var13_7 = v0 ^ 35706402726850L;
        var15_8 = v0 ^ 47766516059661L;
        var17_9 = 66;
        if (BaseModule.a.player == null || BaseModule.a.level == null || BaseModule.a.player.isSpectator()) {
            this.u = false;
            return;
        }
        triggerKeyCode = (Integer)this.m.a();
        if (triggerKeyCode <= 0 || BaseModule.a.screen != null) ** GOTO lbl-1000
        v1 = new Object[2];
        v1[1] = var7_4;
        v1[0] = triggerKeyCode;
        if (L.a(v1)) {
            v2 = true;
        } else lbl-1000:
        // 2 sources

        {
            v2 = triggerDown = false;
        }
        if (triggerDown && !this.v && !this.u) {
            v3 = new Object[1];
            v3[0] = var5_3;
            this.a(v3);
        }
        this.v = triggerDown;
        if (!this.u) {
            return;
        }
        ++this.x;
        switch (this.w) {
            case 0: {
                this.z = BaseModule.a.player.getInventory().getSelectedSlot();
                v4 = new Object[2];
                v4[1] = var3_2;
                v4[0] = Items.ENDER_PEARL;
                pearlSlot = this.a(v4);
                if (pearlSlot == -1) {
                    v5 = new Object[1];
                    v5[0] = var13_7;
                    this.c(v5);
                    return;
                }
                v6 = new Object[1];
                v6[0] = var15_8;
                this.m(v6);
                v7 = new Object[2];
                v7[1] = pearlSlot;
                v7[0] = var9_5;
                this.b(v7);
                this.w = 1;
                this.x = 0;
                return;
            }
            case 1: {
                if (this.x < 1) {
                    return;
                }
                v8 = new Object[1];
                v8[0] = var11_6;
                this.f(v8);
                this.y = System.currentTimeMillis();
                this.w = 2;
                this.x = 0;
                return;
            }
            case 2: {
                if (System.currentTimeMillis() - this.y < this.A) {
                    return;
                }
                v9 = new Object[2];
                v9[1] = var3_2;
                v9[0] = Items.WIND_CHARGE;
                var20_13 = this.a(v9);
                if (var20_13 == -1) {
                    v10 = new Object[1];
                    v10[0] = var13_7;
                    this.c(v10);
                    return;
                }
                v11 = new Object[1];
                v11[0] = var15_8;
                this.m(v11);
                v12 = new Object[2];
                v12[1] = var20_13;
                v12[0] = var9_5;
                this.b(v12);
                this.w = 3;
                this.x = 0;
                return;
            }
            case 3: {
                if (this.x < 1) {
                    return;
                }
                v13 = new Object[1];
                v13[0] = var11_6;
                this.f(v13);
                this.y = System.currentTimeMillis();
                this.w = 4;
                this.x = 0;
                return;
            }
            case 4: {
                if (System.currentTimeMillis() - this.y >= this.B) {
                    v14 = new Object[1];
                    v14[0] = var13_7;
                    this.c(v14);
                }
                return;
            }
        }
    }

    private void c(Object[] payload) {
        int n2;
        block5: {
            block6: {
                WindPearlMacro self;
                block7: {
                    block4: {
                        long l2 = (Long)payload[0];
                        long l3 = (l2 = C ^ l2) ^ 0x87695ADCF99L;
                        int n3 = 66;
                        if (!((Boolean)this.r.a()).booleanValue()) break block4;
                        self = this;
                        n2 = n3;
                        if (l2 < 0L) break block5;
                        if (n2 == 0) break block6;
                        if (l2 < 0L) break block7;
                        if (self.z != -1) {
                            Object[] objectArray2 = new Object[2];
                            objectArray2[1] = this.z;
                            objectArray2[0] = l3;
                            this.b(objectArray2);
                        }
                    }
                    this.z = -1;
                    this.w = 0;
                    WindPearlMacro self2 = this;
                }
                self2.x = 0;
                self = this;
            }
            n2 = 0;
        }
        self.u = n2;
    }

    private void f(Object[] payload) {
        long l2 = (Long)payload[0];
        l2 = C ^ l2;
        ((k_0)BaseModule.a).invokeDoItemUse();
    }

    private void b(Object[] payload) {
        block11: {
            int n2;
            Inventory inventory;
            block9: {
                int targetSlot;
                block10: {
                    Object limit;
                    int currentSlot;
                    block7: {
                        int n5;
                        long l2;
                        block8: {
                            block4: {
                                block5: {
                                    block6: {
                                        l2 = (Long)payload[0];
                                        targetSlot = (Integer)payload[1];
                                        l2 = C ^ l2;
                                        n5 = 0;
                                        if (BaseModule.a.player == null) break block4;
                                        currentSlot = targetSlot;
                                        limit = n5;
                                        if (l2 < 0L) break block5;
                                        if (limit != 0) break block6;
                                        if (currentSlot < 0) break block4;
                                        currentSlot = targetSlot;
                                    }
                                    limit = WindPearlMacro.c("d", (int)32244, (long)(0x239A29F464E5F24L ^ l2));
                                }
                                if (l2 <= 0L) break block7;
                                if (currentSlot <= limit) break block8;
                            }
                            return;
                        }
                        inventory = BaseModule.a.player.getInventory();
                        n2 = n5;
                        if (l2 <= 0L) break block9;
                        if (n2 != 0) break block10;
                        currentSlot = inventory.getSelectedSlot();
                        limit = targetSlot;
                    }
                    if (currentSlot == limit) break block11;
                    inventory = BaseModule.a.player.getInventory();
                }
                n2 = targetSlot;
            }
            inventory.setSelectedSlot(n2);
        }
    }

    private void m(Object[] payload) {
        Minecraft mc;
        block6: {
            block5: {
                long l2 = (Long)payload[0];
                l2 = C ^ l2;
                boolean bl = false;
                if (BaseModule.a.player == null || BaseModule.a.gameMode == null) break block5;
                mc = BaseModule.a;
                if (l2 < 0L) break block6;
                if (mc.player.isUsingItem()) {
                    BaseModule.a.gameMode.releaseUsingItem((Player)BaseModule.a.player);
                }
            }
            mc = BaseModule.a;
        }
        if (mc.options != null) {
            BaseModule.a.options.keyUse.setDown(false);
        }
    }

    private int a(Object[] payload) {
        int result;
        block3: {
            Item targetItem = (Item)payload[0];
            long l2 = (Long)payload[1];
            l2 = C ^ l2;
            int slotIndex = 0;
            int guard = 66;
            while (slotIndex < WindPearlMacro.c("d", (int)5908, (long)(0x1B402E6301D6B28CL ^ l2))) {
                int n5;
                block4: {
                    block5: {
                        block6: {
                            int foundSlot;
                            block7: {
                                ItemStack slotItem = BaseModule.a.player.getInventory().getItem(slotIndex);
                                n5 = guard;
                                if (l2 <= 0L) break block4;
                                if (n5 == 0) break block5;
                                result = slotItem.isEmpty() ? 1 : 0;
                                if (guard == 0) break block3;
                                if (result != 0) break block6;
                                foundSlot = slotItem.is(targetItem);
                                if (guard == 0) break block7;
                                if (foundSlot == 0) break block6;
                                foundSlot = slotIndex;
                            }
                            return foundSlot;
                        }
                        ++slotIndex;
                    }
                    n5 = guard;
                }
                if (n5 != 0) continue;
            }
            result = -1;
        }
        return result;
    }

    private long a(Object[] payload) {
        double jitter;
        double baseDelay;
        block4: {
            long l2;
            double maxDelay;
            double minDelay;
            block5: {
                minDelay = (Double)payload[0];
                int n2 = (Integer)payload[1];
                int n3 = (Integer)payload[2];
                int n4 = (Integer)payload[3];
                maxDelay = (Double)payload[4];
                l2 = ((long)n2 << 48 | (long)n3 << 32 >>> 16 | (long)n4 << 48 >>> 48) ^ C;
                CallSite randomCheck = WindPearlMacro.d("\u00e0", (long)-575755835054963645L, (long)l2);
                try {
                    try {
                        baseDelay = minDelay;
                        jitter = maxDelay;
                        if (randomCheck == false) break block4;
                        if (!(baseDelay >= jitter)) break block5;
                    }
                    catch (r r2) {
                        throw WindPearlMacro.d("\u00e0", (Object)r2, (long)-574491704312904231L, (long)l2);
                    }
                    return (long)minDelay;
                }
                catch (r r3) {
                    throw WindPearlMacro.d("\u00e0", (Object)r3, (long)-574491704312904231L, (long)l2);
                }
            }
            baseDelay = minDelay;
            jitter = ((Random)((Object)WindPearlMacro.d("\u00e4", (Object)this, (long)-573854493589493416L, (long)l2))).nextDouble() * (maxDelay - minDelay);
        }
        return (long)(baseDelay + jitter);
    }

    /*
     * Unable to fully structure code
     */
    static {
        block21: {
            block20: {
                block19: {
                    block18: {
                        WindPearlMacro.C = kuzi.obf.h.b.v.a(-4330117276214335603L, 8094548301760217925L, MethodHandles.lookup().lookupClass()).a(69338508502078L);
                        WindPearlMacro.J = new Object[56];
                        WindPearlMacro.K = new String[56];
                        WindPearlMacro.c();
                        WindPearlMacro.F = new HashMap<K, V>(13);
                        var11 = WindPearlMacro.C ^ 39114108042908L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[8];
                        var18_4 = 0;
                        var17_5 = "\u0097\u0087\u00fe\u008f\u00f6\u00b0\u00c8\u008b\u0014\u00c3R\u00ec\u00f2&G\u00bc*\u000e\u00c2@\u00dbe\u00d8\u0018 \u00e6@\u00bb\u000e\u00ac\u0089\u008aR\u008f\u00f6(Zf\u00fb\u009b\u00cd\u00b6#\u00a79\u008f[i\u00ae&m\u0006SYAq\u00e2\u0018\u000bl\u008c\u00f5F\u00ea\u001e)\u00f2\u00b7\u0004\u00c3{>\u00bb\u00a0\u001c\u00f3\u0092~\u00deVD\u00ed\u0018\u000e\u00d7\u0017\u00eb\u001b}kJ\u00f8Z\u00bf\u00d7\t\u00a3\u00b1=\u0086\u00f5y0\u0011l\u008dA T7!\u00c4J\u00a3\u008f\u00c3\bbJ[\u009cM\u00f1\u00a9\u00ec\u00b7\u00b3\u009e\u009e\u0007m\u00c2f\u0082\u009d\u00c1\u00a1\u00e3+\u0084p\u00a8F>\u0093e\u00ba\u00b3.:\u00d3\u00d2_\u001a\u008e\u00d3\u00e7L\u00cf,\u009f\u00bb4\u00803\u00aa\u00b1\u0093A\u00a1\u00af\u00cd\u00f6'\u00dfCP\u000fEy\u00b466f\u009b\u0093!^\u00bdv\u00a8#\u00a4\u00d0\u00af\rDd\u009b{0W\u000e\u007f 6\u008e\u00c2\u00ec\u009d\u000f\u00c0\u00052\u00fc]-\u00cc0\u00f3,\u0017\u000b\u00b9Hl\u00a5\u001a\u00fa\u00c6\u00de\u0018\u008aM\u00ae))\u00aa\u0004\u00e4\u00c8\u0085Qb\u0094\u00b4\u009d\u00c8C\u00028\u00ee\u00c0";
                        var19_6 = "\u0097\u0087\u00fe\u008f\u00f6\u00b0\u00c8\u008b\u0014\u00c3R\u00ec\u00f2&G\u00bc*\u000e\u00c2@\u00dbe\u00d8\u0018 \u00e6@\u00bb\u000e\u00ac\u0089\u008aR\u008f\u00f6(Zf\u00fb\u009b\u00cd\u00b6#\u00a79\u008f[i\u00ae&m\u0006SYAq\u00e2\u0018\u000bl\u008c\u00f5F\u00ea\u001e)\u00f2\u00b7\u0004\u00c3{>\u00bb\u00a0\u001c\u00f3\u0092~\u00deVD\u00ed\u0018\u000e\u00d7\u0017\u00eb\u001b}kJ\u00f8Z\u00bf\u00d7\t\u00a3\u00b1=\u0086\u00f5y0\u0011l\u008dA T7!\u00c4J\u00a3\u008f\u00c3\bbJ[\u009cM\u00f1\u00a9\u00ec\u00b7\u00b3\u009e\u009e\u0007m\u00c2f\u0082\u009d\u00c1\u00a1\u00e3+\u0084p\u00a8F>\u0093e\u00ba\u00b3.:\u00d3\u00d2_\u001a\u008e\u00d3\u00e7L\u00cf,\u009f\u00bb4\u00803\u00aa\u00b1\u0093A\u00a1\u00af\u00cd\u00f6'\u00dfCP\u000fEy\u00b466f\u009b\u0093!^\u00bdv\u00a8#\u00a4\u00d0\u00af\rDd\u009b{0W\u000e\u007f 6\u008e\u00c2\u00ec\u009d\u000f\u00c0\u00052\u00fc]-\u00cc0\u00f3,\u0017\u000b\u00b9Hl\u00a5\u001a\u00fa\u00c6\u00de\u0018\u008aM\u00ae))\u00aa\u0004\u00e4\u00c8\u0085Qb\u0094\u00b4\u009d\u00c8C\u00028\u00ee\u00c0".length();
                        var16_7 = 24;
                        var15_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block18;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = WindPearlMacro.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "\u00f8\u00078\u00b43\u00c5L2\u00d4\u0097\u00dc1J\u00fe\u00ec\u00d0\u009f\u00dcM+\u0098|{\u00d4*0Q\u00df\u00ff\u00d8z\u00b5D\u00df<\u009a\u0097\u00c5L\u00ce(\u000egG.\u0004\u00e1\u0012qU\u0006\u00e8\u0086t0r\u008f\u00dbu\u00e7\u00fa\u001d\u00b6\u0080mP\u0013d\u00e5\u00c1\u00aeQ\u00b8\u00d6sFG\u00c1\u00b3X\u00d0";
                            var19_6 = "\u00f8\u00078\u00b43\u00c5L2\u00d4\u0097\u00dc1J\u00fe\u00ec\u00d0\u009f\u00dcM+\u0098|{\u00d4*0Q\u00df\u00ff\u00d8z\u00b5D\u00df<\u009a\u0097\u00c5L\u00ce(\u000egG.\u0004\u00e1\u0012qU\u0006\u00e8\u0086t0r\u008f\u00dbu\u00e7\u00fa\u001d\u00b6\u0080mP\u0013d\u00e5\u00c1\u00aeQ\u00b8\u00d6sFG\u00c1\u00b3X\u00d0".length();
                            var16_7 = 40;
                            var15_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block18;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = WindPearlMacro.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block19;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                WindPearlMacro.D = var20_3;
                WindPearlMacro.E = new String[8];
                WindPearlMacro.I = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[6];
                var3_13 = 0;
                var4_14 = "\u00e6\u00a3\u0004\u00e7\u00fdv\u001a\u0085\u00aa\b\u00b8\u0005.~$\u0019\u00ba\u0011@n,\u00df\u00fc\u00ca\u00b3^\u0007y\u00e3$s\u008b";
                var5_15 = "\u00e6\u00a3\u0004\u00e7\u00fdv\u001a\u0085\u00aa\b\u00b8\u0005.~$\u0019\u00ba\u0011@n,\u00df\u00fc\u00ca\u00b3^\u0007y\u00e3$s\u008b".length();
                var2_16 = 0;
                while (true) {
                    var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                    v10 = var6_12;
                    v11 = var3_13++;
                    v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                    v13 = -1;
                    break block20;
                    break;
                }
lbl81:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    var4_14 = "4`\u00f7`;\u00ea\u001e\u00c0\u00d8\u00a1nd\u00d2/\u00a3\u00cb";
                    var5_15 = "4`\u00f7`;\u00ea\u001e\u00c0\u00d8\u00a1nd\u00d2/\u00a3\u00cb".length();
                    var2_16 = 0;
                    while (true) {
                        var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                        v10 = var6_12;
                        v11 = var3_13++;
                        v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                        v13 = 0;
                        break block20;
                        break;
                    }
                    break;
                }
lbl94:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    break block21;
                    break;
                }
            }
            var8_18 = v12;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            v14 = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
            switch (v13) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl107:
                // 1 sources

                ** continue;
            }
        }
        WindPearlMacro.G = var6_12;
        WindPearlMacro.H = new Integer[6];
    }

    private static r a(r value) {
        return value;
    }

    private static String b(byte[] byArray) {
        int outIndex = 0;
        int inputLength = byArray.length;
        char[] cArray = new char[inputLength];
        for (int index = 0; index < inputLength; ++index) {
            char ch;
            int byteValue = 0xFF & byArray[index];
            if (byteValue < 192) {
                cArray[outIndex++] = (char)byteValue;
                continue;
            }
            if (byteValue < 224) {
                ch = (char)((char)(byteValue & 0x1F) << 6);
                byteValue = byArray[++index];
                ch = (char)(ch | (char)(byteValue & 0x3F));
                cArray[outIndex++] = ch;
                continue;
            }
            if (index >= inputLength - 2) continue;
            ch = (char)((char)(byteValue & 0xF) << 12);
            byteValue = byArray[++index];
            ch = (char)(ch | (char)(byteValue & 0x3F) << 6);
            byteValue = byArray[++index];
            ch = (char)(ch | (char)(byteValue & 0x3F));
            cArray[outIndex++] = ch;
        }
        return new String(cArray, 0, outIndex);
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x564E;
        if (H[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = G[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])I.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    I.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/c/aa", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            WindPearlMacro.H[n3] = n4;
        }
        return H[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = WindPearlMacro.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/c/aa" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (K[n4] != null) {
            return n4;
        }
        Object object = J[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 9;
            case 1 -> 8;
            case 2 -> 23;
            case 3 -> 12;
            case 4 -> 11;
            case 5 -> 0;
            case 6 -> 29;
            case 7 -> 20;
            case 8 -> 24;
            case 9 -> 46;
            case 10 -> 6;
            case 11 -> 28;
            case 12 -> 3;
            case 13 -> 41;
            case 14 -> 21;
            case 15 -> 51;
            case 16 -> 61;
            case 17 -> 19;
            case 18 -> 58;
            case 19 -> 48;
            case 20 -> 30;
            case 21 -> 22;
            case 22 -> 55;
            case 23 -> 25;
            case 24 -> 31;
            case 25 -> 26;
            case 26 -> 10;
            case 27 -> 40;
            case 28 -> 35;
            case 29 -> 44;
            case 30 -> 43;
            case 31 -> 49;
            case 32 -> 59;
            case 33 -> 36;
            case 34 -> 33;
            case 35 -> 62;
            case 36 -> 37;
            case 37 -> 14;
            case 38 -> 17;
            case 39 -> 50;
            case 40 -> 57;
            case 41 -> 60;
            case 42 -> 13;
            case 43 -> 54;
            case 44 -> 5;
            case 45 -> 38;
            case 46 -> 34;
            case 47 -> 52;
            case 48 -> 18;
            case 49 -> 16;
            case 50 -> 4;
            case 51 -> 47;
            case 52 -> 56;
            case 53 -> 63;
            case 54 -> 45;
            case 55 -> 2;
            case 56 -> 42;
            case 57 -> 39;
            case 58 -> 53;
            case 59 -> 27;
            case 60 -> 1;
            case 61 -> 15;
            case 62 -> 7;
            default -> 32;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        WindPearlMacro.K[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = J;
        J[0] = "p@I\u0001\u001dv{@K\u0001\u001d9";
        objectArray[1] = "I1\u0010;zp@1\u0013;v";
        objectArray[2] = Integer.TYPE;
        WindPearlMacro.K[2] = "java/lang/Integer";
        objectArray[3] = Boolean.TYPE;
        WindPearlMacro.K[3] = "java/lang/Boolean";
        objectArray[4] = "j\u0018\u0014\u0015\u0015na\u0018\u001c";
        objectArray[5] = "?d0V\u0014\u00186d3V\u001f";
        objectArray[6] = "\f\"\u007f>\u0018C\u0007\"t";
        objectArray[7] = "Ot2=\u000f[:T92\u001e\u0014[Z29\u001aN/";
        objectArray[8] = Void.TYPE;
        WindPearlMacro.K[8] = "java/lang/Void";
        objectArray[9] = "d}\t%E\"m}\n%G";
        objectArray[10] = "*Za\u001b'Q*ZvG+^0\u0011vY+K7`&\u0004z";
        objectArray[11] = Long.TYPE;
        WindPearlMacro.K[11] = "java/lang/Long";
        objectArray[12] = "^Z\u0007t\t]OZ*";
        objectArray[13] = "!\u0018W\u0017\u0018FT8\\\u0018\t\t56W\u0013\rSA";
        objectArray[14] = "c\r=\u0003\u0007f\u0016-6\f\u0016)w#=\u0007\u0012s\u0003";
        objectArray[15] = "8|6$;gM\\=+*(,R6 .rX";
        objectArray[16] = "Cb \tJPOb3";
        objectArray[17] = "Wuxxby\"Usws6C[x|wl7";
        objectArray[18] = "c~ %\u0015e\u0016^+*\u0004*wP !\u0000p\u0003";
        objectArray[19] = "mX9+5bdX:+5";
        objectArray[20] = "5~2p6\u0017>q#?W\u00195z'e";
        objectArray[21] = "c3\u00051^\u0001h3\u00071Q";
        objectArray[22] = "Wf6hU#\"F=gDlCH6l@67";
        objectArray[23] = "xDv1[h\rd}>J'ljv5N}\u0018";
        objectArray[24] = "h,[\u0018.*\u001d\fP\u0017?e|\u0002[\u001c;?\b";
        objectArray[25] = "\u00145uGMh\n=o\b1|\u00100lK";
        objectArray[26] = "j@\u001a5\u0005_<PFS flD\u001d2\n\u0003l\u0005@#";
        objectArray[27] = "|Vc\u000f\u000e\b*F?i\u000b1*Te\u0002\u0000@;\u0013`\fb\u000e?Ob\n\u0007\u000e~\u0012si";
        objectArray[28] = "prr-Fg&b.KV^)`~tFa(gq4";
        objectArray[29] = "D\u001a\u0004,T7\u0012\nXJ^\u000e\u0004Z\u0007.U4\u0016Z_";
        objectArray[30] = "=,\bZ\u007fqk<T<lH>hXLyp`8TD";
        objectArray[31] = "9\fXYE\u0005o\u001c\u0004?B<o\u000e^TKM~I[Z)\u0001pI\u0005\u0000CYmC\u0000?";
        objectArray[32] = "S\r_jgi\u0005\u001d\u0003\feP\u0005\u000fYgi!\u0014H\\i\u000bm\u001aH\u00023a5\u0007B\u0007\f";
        objectArray[33] = "{.\u000eK\u001b1)l\u0004@g2\u0015(R\u0016\u00172-v\u0002\u001a\u001fX";
        objectArray[34] = "{\"\u0017o\n{-2K\t\u000fB(=K4Zx}2\u00139f(#`J5\\},8G\t";
        objectArray[35] = "lf3tOl:vo\u0012QUo\"cbIm1roj";
        objectArray[36] = ")4j[\u0000&\u007f$6=\u0015\u001fitiY\u0001%{t1";
        objectArray[37] = "\u007fMQ\u00040O)]\rb\"v|V]R'M4\nO\t";
        objectArray[38] = "\f\t 7ySZ\u0019|Q|jZ\u000b&:w\u001bKL#4\u0015WEL}n\u007f\u000fXFxQ";
        objectArray[39] = "\u0000\u001dt4f-\u000e\u0007o%\u00015l\tt+o-\u0010^lpp\\";
        objectArray[40] = "x{\r\u0014A\u0016.kQrH/.y\u000b\u0019O^?>\u000e\u0017-\u00121>PMGJ,4Ur";
        objectArray[41] = ";UO\u0001lnmE\u0013gzW<IT[`+3DQV";
        objectArray[42] = "\b\u0005\u0012k`iB\u0006\u0015l\u000f|8\b\u0011ddwI\u0019Vaj\u0015\u0002\u0002\u00012t.J^\u0013i\u000f";
        objectArray[43] = "\u001c4S\nw\\]e\r\u0018\u000bS d[\u0015;BOj\b\u001b;";
        objectArray[44] = ",D\frR\u001fzTP\u0014O&*@\u000bu]C*\u0001Vd";
        objectArray[45] = "\u0015X8\u000f#`CHdi(YU\u0018;\r\"cG\u0018c";
        objectArray[46] = "z&\u0016n\u0010E>g\f<na\u0007\u001d6N2*z&\u0016n\u0010E>g\f<";
        objectArray[47] = "x:\u0019owI.*E\tcp8z\u001amvJ*zB";
        objectArray[48] = "*\u0004e\u000b|R|\u00149myk|\u0006c\u0006r\u001amAf\b\u0010Q)Ju\u0007(\u000fyF}m";
        objectArray[49] = "\u0013\u0001[JQhE\u0011\u0007,XQ\u0011\u001c\u0007IOaT\r\u0004\u0010";
        objectArray[50] = "&p\u0002\u001dscp`^{bZ%k\u000eKdam7\u001c\u0010";
        objectArray[51] = "\t\u0004 |Mo[F*w1mg\u0002|!Al_\\,-I\u0006";
        objectArray[52] = "$nA\u0014\tUr~\u001dr\u0015l'*\u0011\u0002\u000fTyz\u001d\n";
        objectArray[53] = "\u0004yd\u0016\u0012#E(:\u0004n!8yz\u000f\u0005'Ih=\n\u000bE\u0005f=TQ/]{7Qn";
        objectArray[54] = "Mk0Vj(\u001b{l0l\u0011\u001bi6[d`\n.3U\u0006,\u0004.m\u000flt\u0019$h0";
        Object[] objectArray2 = objectArray;
        objectArray[55] = "\u0006b0acCPrl\u0007Ez\u0000f7fl\u001f\u0000'jw";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = WindPearlMacro.e(l2, l3);
            object = J[n2];
            try {
                if (!(object instanceof String)) break block2;
                WindPearlMacro.J[n2] = clazz = Class.forName(K[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = WindPearlMacro.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int index = 0; index < classArray.length; ++index) {
                field = WindPearlMacro.d(classArray[index], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = WindPearlMacro.e(l2, l3);
        Object object = J[n2];
        if (object instanceof String) {
            String string = K[n2];
            int n3 = string.indexOf(8);
            Class clazz = WindPearlMacro.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = WindPearlMacro.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = WindPearlMacro.c(clazz3, string2, clazz2)) != null) {
                    WindPearlMacro.J[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int index = 0; index < classArray.length; ++index) {
                        field = WindPearlMacro.d(classArray[index], string2, clazz2);
                        if (field == null) continue;
                        WindPearlMacro.J[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = WindPearlMacro.f(1473986318902702L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int parameterCount, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != parameterCount) continue;
            for (int index = 0; index < parameterCount; ++index) {
                if (classArray2[index] != classArray[index]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int parameterCount, Class[] classArray) {
        Method method = WindPearlMacro.c(clazz, string, clazz2, parameterCount, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int index = 0; index < classArray2.length; ++index) {
                method = WindPearlMacro.d(classArray2[index], string, clazz2, parameterCount, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = WindPearlMacro.e(l2, l3);
        Object object = J[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = K[n2];
                int n4 = string2.indexOf(8);
                clazz3 = WindPearlMacro.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int paramIndex = 0; paramIndex < n6; ++paramIndex) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = WindPearlMacro.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (paramIndex < n3) {
                        classArray2[paramIndex] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = WindPearlMacro.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        WindPearlMacro.J[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = WindPearlMacro.f(1473986318902702L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = WindPearlMacro.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        WindPearlMacro.J[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = WindPearlMacro.f(1473986318902702L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == '\u00e4' || c2 == '\u00df' || c2 == '\u00b5' || c2 == 't') {
                field = WindPearlMacro.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == '\u00e4' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == '\u00df' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == '\u00b5' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = WindPearlMacro.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == '\u00de' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == '\u00e0' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = WindPearlMacro.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/c/aa" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(WindPearlMacro.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(WindPearlMacro.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

