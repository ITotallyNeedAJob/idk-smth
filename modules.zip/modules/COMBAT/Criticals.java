// === Kuzi module: Criticals ===
// Category   : COMBAT
// Description: Ensures critical hits.
// Payload    : a.a.a.j.c.I (verified: False)

package kuzi.modules.combat;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.module.Module;
import kuzi.obf.g.a.b;
import kuzi.obf.g.a.n;
import kuzi.obf.h.b.l;
import kuzi.obf.j.c.j;
import kuzi.obf.m.r;
import kuzi.settings.Setting;
import net.minecraft.MobEffects;
import net.minecraft.LivingEntity;
import net.minecraft.Packet;
import net.minecraft.ServerboundMovePlayerPacket;
import net.minecraft.LocalPlayer;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class Criticals
extends BaseModule
implements Module,
n {
    private final l mode;
    private boolean sprintStopped;
    private static final long o = 101059903459533L;
    private static final Object[] s = new Object[]{"4v@YM;?vK", "=V\u0018\u000f\u0014\u000b=V\u000fS\u0018\u0004'\u001d\u000fM\u0018\u0011 l_\u0010I", "\rX\u001b),e\u0006X\u0019)#", Integer.TYPE, Boolean.TYPE, "AK1\u001bI^JK3\u001ba", "@\u0019GHx\u001bL\u0019T", "\f~\u0004n*q\u0005~\u0007n'", "\u0014g|U\u007fw\u001dg\u007fU\u007f", "Vt\u0011m(~]{\u0000\"IpVp\u0004x", "x\u0014*4j\u000fs\u0014(4a", "\u001cS(\u001b3Eis#\u0014\"\n\b}(\u001f&P|", Void.TYPE, "#lH5\u00137(l@", "!$\u001f\u00006+T\u0004\u0014\u000f'd5\n\u001f\u0004#>A", "\u000fq\f\u0005\u0003\u000ezQ\u0007\n\u0012A\u001b_\f\u0001\u0016\u001bo", "P\u001ar\u0007K\u000f%:y\bZ@D4r\u0003^\u001a0", "\f\u000ft\u001a}\u001a\u0007P{z$ S\u000en\u001f,R\u0000\u000ej\u0017", "h\u0015(S\u0000\u00024\b{\bj\u000fS\u0001}\u0013\f\u001d(\u001a|\u0004Pdc\u0000xQ\n\u0003)\u0004z\fj", "I\u0019p>S{N\u000b(?k\u000500J\u0002;\r3k,1\t=OP+#Q<", "\u0012\fS|f\u001a\u0011H\u0004\u007f\u001f\u0011(\u000f\u000f-|\u0006DI\b7 {", "\u0006\u0011-BV\u0007\rN\"\"\n=ZR.KX\u0006\u001bFbPf", "\u001di\\T>\u001eAt\u000f\u000fT\u001e&-L\u0012=F\u001dlX^&", "\u001fXl7\u0018jCE?lrb$L9w\u0014u_W8`H\f\u001eX~dL7_L2\u007fr", "Ua50\u001bN\u000b%6(a=#\u001b\u001f\u0006=vUa50\u001bN\u000b%6(", "d_-)uF8B~r\u001fI_\u001d o/\u001a<J{pa cB?#%C4\u0019 m\u001f", "^7\u00167\u0003\"\u0002*Eli!et\u0014n\u0006-_(\u001f\u007f\u0010", "\u0001d\u000eICHVc\rG?A<&\u0019XZ\u0013Fj^FB(", "VYEM}$U\u001d\u0012N\u0004.lZ\u0019\u001cg8\u0000\u001c\u001e\u0006;E", "\u007f\bA!Jb#\u0015\u0012z mD\u001c\u0014aF}?\u0007\u0015v\u001a\u0004t\u001d\u0011#@c>\u0019\u0013~ ", "\u0003V\u0004\n\u0014/\u0004D\\\u000b,Jtb'3h]=\u001a\u0014\u0015Q,\u0006\u001d\u0006MP", "]RnXZ\u0015Z@6Ybj.oMyb\u0010\u0011Bq\u001dY\u0017\u0003\u001ap", "wdM\f\r |;BlY\u001a{bH\nDa`c_V=*zg\n\fZ`~eWl"};
    private static final String[] t = new String[]{null, null, null, "java/lang/Integer", "java/lang/Boolean", null, null, null, null, null, null, null, "java/lang/Void", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null};

    public Criticals() {
        long l2 = o ^ 0x34B7275CEB7CL;
        long l3 = l2 ^ 0x4EBDFB84E0A4L;
        super("Criticals", "Ensures critical hits.", Category.COMBAT);
        this.mode = new l("Mode", j.LEGIT, j.class);
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.mode};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        Client.a().a(Module.class, this);
        Client.a().a(n.class, this);
    }

    @Override
    public void e() {
        long l2 = o ^ 0x25187232572EL;
        long l3 = l2 ^ 0x6CA07A81977BL;
        Client.a().b(Module.class, this);
        Client.a().b(n.class, this);
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.c(objectArray);
    }

    @Override
    public void b() {
        boolean bl;
        long l2 = o ^ 0x438730484809L;
        long l3 = l2 ^ 0xA3F38FB885CL;
        if (BaseModule.a.player == null || BaseModule.a.level == null) {
            Object[] objectArray = new Object[1];
            objectArray[0] = l3;
            this.c(objectArray);
            return;
        }
        if (this.mode.a() != j.LEGIT) {
            Object[] objectArray = new Object[1];
            objectArray[0] = l3;
            this.c(objectArray);
            return;
        }
        boolean bl2 = bl = !BaseModule.a.player.onGround() && BaseModule.a.player.getDeltaMovement().y <= 0.0;
        if (bl) {
            BaseModule.a.options.keySprint.setDown(false);
            this.sprintStopped = true;
        } else {
            Object[] objectArray = new Object[1];
            objectArray[0] = l3;
            this.c(objectArray);
        }
    }

    @Override
    public void a(b event) {
        long l2;
        long l3 = l2 = o ^ 0x6A976E23341AL;
        long l4 = l3 ^ 0x6ECFF878BAFBL;
        long l5 = l3 ^ 0x6A6E25496411L;
        if (BaseModule.a.player == null || BaseModule.a.getConnection() == null) {
            return;
        }
        if (!(event.c instanceof LivingEntity)) {
            return;
        }
        Object[] objectArray = new Object[1];
        objectArray[0] = l5;
        if (this.f(objectArray)) {
            return;
        }
        double x = BaseModule.a.player.getX();
        double y = BaseModule.a.player.getY();
        double z = BaseModule.a.player.getZ();
        boolean onGround = BaseModule.a.player.onGround();
        boolean horizontalCollision = BaseModule.a.player.horizontalCollision;
        if (this.mode.a() == j.VANILLA) {
            Object[] objectArray2 = new Object[6];
            objectArray2[5] = l4;
            objectArray2[4] = horizontalCollision;
            objectArray2[3] = onGround;
            objectArray2[2] = z;
            objectArray2[1] = y + 0.2;
            objectArray2[0] = x;
            this.a(objectArray2);
            Object[] objectArray3 = new Object[6];
            objectArray3[5] = l4;
            objectArray3[4] = horizontalCollision;
            objectArray3[3] = onGround;
            objectArray3[2] = z;
            objectArray3[1] = y + 0.1;
            objectArray3[0] = x;
            this.a(objectArray3);
        } else if (this.mode.a() == j.MOSPIXEL) {
            Object[] objectArray4 = new Object[6];
            objectArray4[5] = l4;
            objectArray4[4] = horizontalCollision;
            objectArray4[3] = onGround;
            objectArray4[2] = z;
            objectArray4[1] = y + 2.71875E-7;
            objectArray4[0] = x;
            this.a(objectArray4);
            Object[] objectArray5 = new Object[6];
            objectArray5[5] = l4;
            objectArray5[4] = horizontalCollision;
            objectArray5[3] = onGround;
            objectArray5[2] = z;
            objectArray5[1] = y;
            objectArray5[0] = x;
            this.a(objectArray5);
        }
    }

    private void a(Object[] objectArray) {
        double x = (Double)objectArray[0];
        double y = (Double)objectArray[1];
        double z = (Double)objectArray[2];
        boolean onGround = (Boolean)objectArray[3];
        boolean horizontalCollision = (Boolean)objectArray[4];
        long l2 = (Long)objectArray[5];
        l2 = o ^ l2;
        BaseModule.a.getConnection().send((Packet)new ServerboundMovePlayerPacket.mc2829(x, y, z, onGround, horizontalCollision));
    }

    private void c(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = o ^ l2;
        if (this.sprintStopped) {
            this.sprintStopped = false;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = o ^ l2;
        boolean bl = false;
        if (!this.d()) return false;
        if (this.mode.a() != j.LEGIT) return false;
        LocalPlayer mc7462 = BaseModule.a.player;
        if (l2 > 0L) {
            if (mc7462 == null) {
                return false;
            }
            mc7462 = BaseModule.a.player;
        }
        int n2 = mc7462.onGround();
        boolean bl2 = bl;
        if (l2 >= 0L) {
            if (!bl2) {
                if (n2 != 0) return 0 != 0;
                double d2 = BaseModule.a.player.getDeltaMovement().y - 0.0;
                n2 = d2 == 0.0 ? 0 : (d2 < 0.0 ? -1 : 1);
            }
            bl2 = bl;
        }
        if (l2 > 0L) {
            if (!bl2) {
                if (n2 >= 0) return 0 != 0;
                n2 = BaseModule.a.player.isInWater() ? 1 : 0;
            }
            bl2 = bl;
        }
        if (l2 > 0L) {
            if (!bl2) {
                if (n2 != 0) return 0 != 0;
                n2 = BaseModule.a.player.isFallFlying() ? 1 : 0;
            }
            bl2 = bl;
        }
        if (l2 >= 0L) {
            if (!bl2) {
                if (n2 != 0) return 0 != 0;
                n2 = BaseModule.a.player.getAbilities().flying ? 1 : 0;
            }
            bl2 = bl;
        }
        if (l2 >= 0L) {
            if (!bl2) {
                if (n2 != 0) return 0 != 0;
                n2 = BaseModule.a.player.onClimbable() ? 1 : 0;
            }
            bl2 = bl;
        }
        if (bl2) return n2 != 0;
        if (n2 != 0) return 0 != 0;
        return 1 != 0;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean f(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = o ^ l2;
        int n2 = 66;
        if (BaseModule.a.player == null) {
            return false;
        }
        int n3 = BaseModule.a.player.onGround();
        int n4 = n2;
        if (l2 > 0L) {
            if (n4 != 0) {
                if (n3 != 0) return 0 != 0;
                double d2 = BaseModule.a.player.getDeltaMovement().y - 0.0;
                n3 = d2 == 0.0 ? 0 : (d2 < 0.0 ? -1 : 1);
            }
            n4 = n2;
        }
        if (l2 >= 0L) {
            if (n4 != 0) {
                if (n3 >= 0) return 0 != 0;
                n3 = BaseModule.a.player.isInWater() ? 1 : 0;
            }
            n4 = n2;
        }
        if (l2 >= 0L) {
            if (n4 != 0) {
                if (n3 != 0) return 0 != 0;
                n3 = BaseModule.a.player.onClimbable() ? 1 : 0;
            }
            n4 = n2;
        }
        if (l2 > 0L) {
            if (n4 != 0) {
                if (n3 != 0) return 0 != 0;
                n3 = BaseModule.a.player.isFallFlying() ? 1 : 0;
            }
            n4 = n2;
        }
        if (l2 >= 0L) {
            if (n4 != 0) {
                if (n3 != 0) return 0 != 0;
                n3 = BaseModule.a.player.isPassenger() ? 1 : 0;
            }
            n4 = n2;
        }
        if (l2 >= 0L) {
            if (n4 != 0) {
                if (n3 != 0) return 0 != 0;
                n3 = BaseModule.a.player.hasEffect(MobEffects.BLINDNESS) ? 1 : 0;
            }
            n4 = n2;
        }
        if (n4 == 0) return n3 != 0;
        if (n3 != 0) return 0 != 0;
        return 1 != 0;
    }

    private static r a(r r2) {
        return r2;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = Criticals.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = Criticals.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = Criticals.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = Criticals.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }
}

