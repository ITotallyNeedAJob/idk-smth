// === Kuzi module: LungeMacro ===
// Category   : COMBAT
// Description: Press the Trigger Key to swap to a lunge spear, lunge, and swap back.
// Payload    : a.a.a.j.c.P (verified: True)

package kuzi.modules.combat;

import it.unimi.dsi.fastutil.objects.Object2IntMap;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.module.Module;
import kuzi.obf.h.b.v;
import kuzi.obf.i.k_0;
import kuzi.obf.m.r;
import kuzi.obf.p.L;
import kuzi.settings.BoolSetting;
import kuzi.settings.KeyBinding;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.ItemStack;
import net.minecraft.Items;
import net.minecraft.Enchantment;
import net.minecraft.Identifier;
import net.minecraft.ResourceKey;
import net.minecraft.Holder;
import net.minecraft.ItemEnchantments;
import net.minecraft.DataComponents;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class LungeMacro
extends BaseModule
implements Module {
    private final KeyBinding triggerKey;
    private final BoolSetting continuous;
    private final SliderSetting continuousDelayMs;
    private final BoolSetting swapBack;
    private final SliderSetting swapBackDelay;
    private final BoolSetting randomization;
    private final SliderSetting minRandom;
    private final SliderSetting maxRandom;
    private boolean lunging;
    private boolean triggerWasDown;
    private int previousSlot;
    private int ticksSinceSwap;
    private int swapBackTicks;
    private long lastTriggerTime;
    private static final long A;
    private static final String[] B;
    private static final String[] C;
    private static final Map D;
    private static final long[] E;
    private static final Integer[] F;
    private static final Map G;
    private static final Object[] H;
    private static final String[] I;

    public LungeMacro() {
        long l2 = A ^ 0x7A40FA8B2651L;
        long l3 = l2 ^ 0x5E94553862AL;
        super("LungeMacro", "Press the Trigger Key to swap to a lunge spear, lunge, and swap back.", Category.COMBAT);
        this.triggerKey = new KeyBinding("Trigger Key", -1);
        this.continuous = new BoolSetting("Continuous", false);
        this.continuousDelayMs = new SliderSetting("Continuous Delay (ms)", 450.0, 0.0, 2000.0, 25.0);
        this.swapBack = new BoolSetting("Swap Back", true);
        this.swapBackDelay = new SliderSetting("Swap Back Delay", 1.0, 1.0, 10.0, 1.0);
        this.randomization = new BoolSetting("Randomization", false);
        this.minRandom = new SliderSetting("Min Random", 0.0, 0.0, 10.0, 1.0);
        this.maxRandom = new SliderSetting("Max Random", 1.0, 0.0, 10.0, 1.0);
        this.lunging = false;
        this.triggerWasDown = false;
        this.previousSlot = -1;
        this.ticksSinceSwap = 0;
        this.swapBackTicks = 1;
        this.lastTriggerTime = 0L;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.triggerKey, this.continuous, this.continuousDelayMs, this.swapBack, this.swapBackDelay, this.randomization, this.minRandom, this.maxRandom};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        Client.a().a(Module.class, this);
        this.lunging = false;
        this.triggerWasDown = false;
        this.previousSlot = -1;
        this.ticksSinceSwap = 0;
        super.d();
    }

    @Override
    public void e() {
        Client.a().b(Module.class, this);
        this.lunging = false;
        this.previousSlot = -1;
        this.ticksSinceSwap = 0;
        super.e();
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public void b() {
        block6: {
            v0 = var1_1 = LungeMacro.A ^ 77121830052778L;
            var3_2 = v0 ^ 19310780977557L;
            var5_3 = v0 ^ 124092109235742L;
            var7_4 = v0 ^ 111239915913786L;
            var9_5 = false;
            if (BaseModule.a.player == null) {
                this.lunging = false;
                return;
            }
            if (this.lunging) break block6;
            keyCode = (Integer)this.triggerKey.a();
            if (keyCode <= 0 || BaseModule.a.screen != null) ** GOTO lbl-1000
            v1 = new Object[2];
            v1[1] = var5_3;
            v1[0] = keyCode;
            if (L.a(v1)) {
                keyPressed = true;
            } else lbl-1000:
            // 2 sources

            {
                keyPressed = false;
            }
            triggerDown = keyPressed;
            triggerJustPressed = triggerDown != false && this.triggerWasDown == false;
            this.triggerWasDown = triggerDown;
            continuousActive = (Boolean)this.continuous.a() != false && BaseModule.a.screen == null && System.currentTimeMillis() - this.lastTriggerTime >= ((Double)this.continuousDelayMs.a()).longValue() && BaseModule.a.player.getAttackStrengthScale(0.0f) >= 1.0f;
            if (triggerJustPressed || continuousActive) {
                v4 = new Object[1];
                v4[0] = var3_2;
                this.a(v4);
            }
            return;
        }
        ++this.ticksSinceSwap;
        if (this.ticksSinceSwap >= this.swapBackTicks) {
            if (((Boolean)this.swapBack.a()).booleanValue() && this.previousSlot != -1) {
                v5 = new Object[2];
                v5[1] = var7_4;
                v5[0] = this.previousSlot;
                this.b(v5);
            }
            this.lunging = false;
        }
    }

    private void a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = l2 = A ^ l2;
        long l4 = l3 ^ 0x2AF69F34E8C1L;
        long l5 = l3 ^ 0x85999FE299EL;
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l5;
        int slot = this.a(objectArray2);
        boolean guard = false;
        int checkFlag = slot;
        if (!guard) {
            if (checkFlag == -1) {
                return;
            }
            this.lastTriggerTime = System.currentTimeMillis();
            this.previousSlot = BaseModule.a.player.getInventory().getSelectedSlot();
            this.swapBackTicks = ((Double)this.swapBackDelay.a()).intValue();
            checkFlag = ((Boolean)this.randomization.a()).booleanValue() ? 1 : 0;
        }
        boolean guardCopy = guard;
        if (l2 >= 0L) {
            if (!guardCopy) {
                if (checkFlag != 0) {
                    this.swapBackTicks += (int)(Math.random() * 2.0);
                }
                Object[] objectArray3 = new Object[2];
                objectArray3[1] = l4;
                objectArray3[0] = slot;
                this.b(objectArray3);
                this.lunging = true;
                this.ticksSinceSwap = 0;
                float attackStrength = BaseModule.a.player.getAttackStrengthScale(0.0f) - 1.0f;
                checkFlag = attackStrength == 0.0f ? 0 : (attackStrength > 0.0f ? 1 : -1);
            }
            guardCopy = guard;
        }
        if (!guardCopy && checkFlag >= 0) {
            checkFlag = ((k_0)BaseModule.a).invokeDoAttack() ? 1 : 0;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private int a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = (l2 = A ^ l2) ^ 0x591A57117311L;
        int n2 = 66;
        block0: for (int slot = 0; slot < LungeMacro.c("g", (int)26227, (long)(0x26B13E96C62147A0L ^ l2)); ++slot) {
            do {
                int foundSlot;
                Object[] objectArray2 = new Object[2];
                objectArray2[1] = BaseModule.a.player.getInventory().getItem(slot);
                objectArray2[0] = l3;
                int isMatch = this.a(objectArray2) ? 1 : 0;
                int n5 = n2;
                if (l2 > 0L) {
                    if (n5 == 0) return isMatch;
                    n5 = n2;
                }
                if (n5 == 0) return foundSlot;
                if (isMatch == 0) continue block0;
                foundSlot = slot;
                return foundSlot;
            } while (l2 <= 0L);
        }
        return -1;
    }

    private boolean a(Object[] objectArray) {
        boolean matches;
        block7: {
            boolean isLungeWeapon;
            long l2 = (Long)objectArray[0];
            ItemStack itemStack = (ItemStack)objectArray[1];
            l2 = A ^ l2;
            int n2 = 66;
            if (itemStack.isEmpty()) {
                return false;
            }
            boolean bl3 = isLungeWeapon = itemStack.is(Items.TRIDENT) || itemStack.getHoverName().getString().toLowerCase(Locale.ROOT).contains((CharSequence)((Object)LungeMacro.b("d", (int)20938, (long)(0x6602A675747B6612L ^ l2))));
            if (!isLungeWeapon) {
                return false;
            }
            ItemEnchantments enchantments = (ItemEnchantments)itemStack.get(DataComponents.ENCHANTMENTS);
            if (enchantments == null) {
                return false;
            }
            for (Object2IntMap.Entry entry : enchantments.entrySet()) {
                Holder enchantmentHolder = (Holder)entry.getKey();
                String enchantmentId = enchantmentHolder.unwrapKey().map(ResourceKey::identifier).map(Identifier::toString).orElse("").toLowerCase(Locale.ROOT);
                String enchantmentName = Enchantment.getFullname((Holder)enchantmentHolder, (int)entry.getIntValue()).getString().toLowerCase(Locale.ROOT);
                matches = enchantmentId.contains((CharSequence)((Object)LungeMacro.b("d", (int)19932, (long)(0x590157E5C58F7A07L ^ l2))));
                int n3 = n2;
                if (l2 >= 0L) {
                    if (n3 == 0) break block7;
                    n3 = n2;
                }
                if (n3 != 0) {
                    if (!matches && !enchantmentName.contains((CharSequence)((Object)LungeMacro.b("d", (int)32157, (long)(0x591D9138EA91CA4EL ^ l2))))) continue;
                    matches = true;
                }
                return matches;
            }
            matches = false;
        }
        return matches;
    }

    private void b(Object[] objectArray) {
        block1: {
            Object object;
            int checkedSlot;
            int slot;
            block2: {
                long l2;
                block3: {
                    slot = (Integer)objectArray[0];
                    l2 = (Long)objectArray[1];
                    l2 = A ^ l2;
                    int n4 = 0;
                    if (BaseModule.a.player == null) break block1;
                    checkedSlot = slot;
                    object = n4;
                    if (l2 <= 0L) break block2;
                    if (object != 0) break block3;
                    if (checkedSlot < 0) break block1;
                    checkedSlot = slot;
                }
                object = LungeMacro.c("g", (int)22540, (long)(0x5495A2D83B80B886L ^ l2));
            }
            if (checkedSlot <= object) {
                BaseModule.a.player.getInventory().setSelectedSlot(slot);
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block21: {
            block20: {
                block19: {
                    block18: {
                        LungeMacro.A = kuzi.obf.h.b.v.a(-5603148426302780841L, 5304353103898212730L, MethodHandles.lookup().lookupClass()).a(106739554413449L);
                        LungeMacro.H = new Object[48];
                        LungeMacro.I = new String[48];
                        LungeMacro.c();
                        LungeMacro.D = new HashMap<K, V>(13);
                        var11 = LungeMacro.A ^ 70606385063632L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[13];
                        var18_4 = 0;
                        var17_5 = "\fJ\u00a3\u009d\u0096T%\u00c7\u00ad\u00d1\u00a3]iJ\u008e]\u0093WQ\u00f1\u008a\u00a1R$\u00c7cL\u00f0i\u00e5\u007f\u001f\u00e1G\u00f8P\u00bf\u00c5C\u00b5\u0018\u0016\u00c0f\u00e8\u00a05l\u00a0V\u00bc\u00a6Rj\u00ba\u0017m\u00f3\u0099\u00a7\u00f0(\u00af\u00ca8\u00a7\u00d9\u00fd\u00c5h\u00ad\u00f0\u00eb!\u0005\u00db\u00a1\u0082\u00b91\u0012.I;X\u00f7N\u00e7\u00b5\u00ff}<\u00df\u009fY\u00a3/uB\u0017u\u00b5\u001d\u0007\u0088\u0095(:\u009f\u00d3)\u00ec\u0010W\u00d8\u0006\u00901\u008eQjs\u00fc\u0005\t_\u001b\u00bd\u00fa \u001e\u008b\u0086\u00b6\u00e0F&\u001e\u00f0\u00a4\u0017\u00fa'\u0080\u0013r\u0080v\u00a5\u00dcF\u00b0\u00fa\u00af\u0086@\u00ddn\u00c9\u00b9\u00e1\u00e8 \u00c0\u00b8\u009fEMX$\u00a8w \t\u00c76\u00cag\u00f5\u00fe\u001f\u0083A>)\u0010\u0092+\u008e\u00fd\u00e7+\u00f3\u0003$ \u0006zM\u0005 \u00c1\u00c5R\u009c*Wn\u00d7\u00f5`\u00e2?\u0081\u00d6\u00b5\u0019\u00a6\u009a2\u0098.\u0081p\u008f,\u00f6\u0000 \u00be\u0010\u00e6<Q<2\u009d\u0096\u00e1\u0000\u00bb\u00d6\u009b\u00f3\u0094\u0015@@\u0005\t\u001c\u00f5ne\u00cc\u0093G\u0097O\u00a1\\ \u001d\u00b5\u0012\u00fb\u0016\u0096,\u00f9B#\u0006\u00cd\u00ae8A5\u0010\u00ef\u0099P^\u00cf`\u00a1\\\u008c\u00fd\u00aeV\n\u0003\u00be &\u00ed\u0087\u00cbt\u0010~\u00873\u0093r>G\".\u0091\u00e2\u00ca\u00b1r_Mo\u00f2\u00b1\u008f\u009ab\u00a4\u00f8z\u00de\u0018\u00a0\u001b^\u00f3\u00138\u0081\u000eh\u00e2q\u00f4\u00b4\u008d\u008d\u00aam\u0018[\u00ac\u009e\u001d\u00ef\u00e3\u0010\u00e9\u0080\u0089\u00e3\u00fd\u00a4\u0000D_\u00805\u00e0\u00cd\u00bcJU\u0010\u00e7\u00b2\u00b6\u00f56\u00c4}\u00d7\u00e7\u00ff\u00a5\u0092\u00b9\u00da\u00e7)";
                        var19_6 = "\fJ\u00a3\u009d\u0096T%\u00c7\u00ad\u00d1\u00a3]iJ\u008e]\u0093WQ\u00f1\u008a\u00a1R$\u00c7cL\u00f0i\u00e5\u007f\u001f\u00e1G\u00f8P\u00bf\u00c5C\u00b5\u0018\u0016\u00c0f\u00e8\u00a05l\u00a0V\u00bc\u00a6Rj\u00ba\u0017m\u00f3\u0099\u00a7\u00f0(\u00af\u00ca8\u00a7\u00d9\u00fd\u00c5h\u00ad\u00f0\u00eb!\u0005\u00db\u00a1\u0082\u00b91\u0012.I;X\u00f7N\u00e7\u00b5\u00ff}<\u00df\u009fY\u00a3/uB\u0017u\u00b5\u001d\u0007\u0088\u0095(:\u009f\u00d3)\u00ec\u0010W\u00d8\u0006\u00901\u008eQjs\u00fc\u0005\t_\u001b\u00bd\u00fa \u001e\u008b\u0086\u00b6\u00e0F&\u001e\u00f0\u00a4\u0017\u00fa'\u0080\u0013r\u0080v\u00a5\u00dcF\u00b0\u00fa\u00af\u0086@\u00ddn\u00c9\u00b9\u00e1\u00e8 \u00c0\u00b8\u009fEMX$\u00a8w \t\u00c76\u00cag\u00f5\u00fe\u001f\u0083A>)\u0010\u0092+\u008e\u00fd\u00e7+\u00f3\u0003$ \u0006zM\u0005 \u00c1\u00c5R\u009c*Wn\u00d7\u00f5`\u00e2?\u0081\u00d6\u00b5\u0019\u00a6\u009a2\u0098.\u0081p\u008f,\u00f6\u0000 \u00be\u0010\u00e6<Q<2\u009d\u0096\u00e1\u0000\u00bb\u00d6\u009b\u00f3\u0094\u0015@@\u0005\t\u001c\u00f5ne\u00cc\u0093G\u0097O\u00a1\\ \u001d\u00b5\u0012\u00fb\u0016\u0096,\u00f9B#\u0006\u00cd\u00ae8A5\u0010\u00ef\u0099P^\u00cf`\u00a1\\\u008c\u00fd\u00aeV\n\u0003\u00be &\u00ed\u0087\u00cbt\u0010~\u00873\u0093r>G\".\u0091\u00e2\u00ca\u00b1r_Mo\u00f2\u00b1\u008f\u009ab\u00a4\u00f8z\u00de\u0018\u00a0\u001b^\u00f3\u00138\u0081\u000eh\u00e2q\u00f4\u00b4\u008d\u008d\u00aam\u0018[\u00ac\u009e\u001d\u00ef\u00e3\u0010\u00e9\u0080\u0089\u00e3\u00fd\u00a4\u0000D_\u00805\u00e0\u00cd\u00bcJU\u0010\u00e7\u00b2\u00b6\u00f56\u00c4}\u00d7\u00e7\u00ff\u00a5\u0092\u00b9\u00da\u00e7)".length();
                        var16_7 = 112;
                        var15_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block18;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = LungeMacro.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "h\u00b0\u00a9=\u0092%SW\u00ac\u0005\u0081\u00b4\u0013\u00bc\u00d1\u00e3\u00e8\u00e0Zx&c\u001f\u00dd_GA^\u001f\u00c4\r\u00cd \u0018\u00c5\u00c1\u00a1L%\u008b\u0018Et\u0010\u00fd\u00e8G\u00df\u00b7\u00ebk\u0014\u00b1\u001flL\u008d\u001a\u00adc~\u00eeY\u00e9\u00ab";
                            var19_6 = "h\u00b0\u00a9=\u0092%SW\u00ac\u0005\u0081\u00b4\u0013\u00bc\u00d1\u00e3\u00e8\u00e0Zx&c\u001f\u00dd_GA^\u001f\u00c4\r\u00cd \u0018\u00c5\u00c1\u00a1L%\u008b\u0018Et\u0010\u00fd\u00e8G\u00df\u00b7\u00ebk\u0014\u00b1\u001flL\u008d\u001a\u00adc~\u00eeY\u00e9\u00ab".length();
                            var16_7 = 32;
                            var15_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block18;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = LungeMacro.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block19;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                LungeMacro.B = var20_3;
                LungeMacro.C = new String[13];
                LungeMacro.G = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[5];
                var3_13 = 0;
                var4_14 = "h\u00c4\u00e9k\u0007\u00b3\t\u00be\b#\u0011}O\u00c3\u00ab\u0087+\u0014\u009eM\u00f9\u00f3\u00f6~";
                var5_15 = "h\u00c4\u00e9k\u0007\u00b3\t\u00be\b#\u0011}O\u00c3\u00ab\u0087+\u0014\u009eM\u00f9\u00f3\u00f6~".length();
                var2_16 = 0;
                while (true) {
                    var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                    v10 = var6_12;
                    v11 = var3_13++;
                    v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                    v13 = -1;
                    break block20;
                    break;
                }
lbl81:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    var4_14 = "\u00f5\u00ef\u00a4\u00ffF\u00da\u00c3\u001eC\u0087\u00a6\u00d0r^'M";
                    var5_15 = "\u00f5\u00ef\u00a4\u00ffF\u00da\u00c3\u001eC\u0087\u00a6\u00d0r^'M".length();
                    var2_16 = 0;
                    while (true) {
                        var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                        v10 = var6_12;
                        v11 = var3_13++;
                        v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                        v13 = 0;
                        break block20;
                        break;
                    }
                    break;
                }
lbl94:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    break block21;
                    break;
                }
            }
            var8_18 = v12;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            v14 = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
            switch (v13) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl107:
                // 1 sources

                ** continue;
            }
        }
        LungeMacro.E = var6_12;
        LungeMacro.F = new Integer[5];
    }

    private static r a(r r2) {
        return r2;
    }

    private static String b(byte[] byArray) {
        int charCount = 0;
        int length = byArray.length;
        char[] chars = new char[length];
        for (int index = 0; index < length; ++index) {
            char character;
            int byteValue = 0xFF & byArray[index];
            if (byteValue < 192) {
                chars[charCount++] = (char)byteValue;
                continue;
            }
            if (byteValue < 224) {
                character = (char)((char)(byteValue & 0x1F) << 6);
                byteValue = byArray[++index];
                character = (char)(character | (char)(byteValue & 0x3F));
                chars[charCount++] = character;
                continue;
            }
            if (index >= length - 2) continue;
            character = (char)((char)(byteValue & 0xF) << 12);
            byteValue = byArray[++index];
            character = (char)(character | (char)(byteValue & 0x3F) << 6);
            byteValue = byArray[++index];
            character = (char)(character | (char)(byteValue & 0x3F));
            chars[charCount++] = character;
        }
        return new String(chars, 0, charCount);
    }

    private static String b(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x1F62;
        if (C[n3] == null) {
            Object[] objectArray;
            try {
                Long l3 = Thread.currentThread().threadId();
                objectArray = (Object[])D.get(l3);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    D.put(l3, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/c/P", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l2 >>> 56);
            for (int i2 = 1; i2 < 8; ++i2) {
                byArray[i2] = (byte)(l2 << i2 * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = B[n3].getBytes("ISO-8859-1");
            LungeMacro.C[n3] = LungeMacro.b(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return C[n3];
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        String string2 = LungeMacro.b(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static CallSite b(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/c/P" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x411E;
        if (F[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = E[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])G.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    G.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/c/P", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            LungeMacro.F[n3] = n4;
        }
        return F[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = LungeMacro.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/c/P" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static void c() {
        Object[] objectArray = H;
        H[0] = "\r?~3U9\u0006?|3d";
        objectArray[1] = "\u0003~\\+T\u0017\u000f~O";
        objectArray[2] = ".3nJ`4%3lJo";
        objectArray[3] = Integer.TYPE;
        LungeMacro.I[3] = "java/lang/Integer";
        objectArray[4] = Boolean.TYPE;
        LungeMacro.I[4] = "java/lang/Boolean";
        objectArray[5] = "~Ue2\t%uUn";
        objectArray[6] = "G -8\u0018\u0002G :d\u0014\r]k:z\u0014\u0018Z\u001aj'E";
        objectArray[7] = Long.TYPE;
        LungeMacro.I[7] = "java/lang/Long";
        objectArray[8] = "HKA}_kAKB}S";
        objectArray[9] = "5`,~\tv<`/~\u000b";
        objectArray[10] = "=\u000f\u000f,8\u001a6\u000f\u0007";
        objectArray[11] = "\u0000\n\u0013w<a\t\n\u0010w7";
        objectArray[12] = "Bmnj+L7Mee:\u0003VCnn>Y\"";
        objectArray[13] = Void.TYPE;
        LungeMacro.I[13] = "java/lang/Void";
        objectArray[14] = "hxh'\u0001ryxE";
        objectArray[15] = "\u0016s\u0005\u001e/QcS\u000e\u0011>\u001e\u0002]\u0005\u001a:Dv";
        objectArray[16] = "\rye?q>xYn0`q\u0019We;d+m";
        objectArray[17] = "Q\u0001J?$9$!A05vE/J;1,1";
        objectArray[18] = "\u0016ao\u0001jX\u001fal\u0001j";
        objectArray[19] = "\u007f8A($gt7PgEi\u007f<T=";
        objectArray[20] = "\u0018\u0015\"_4>m5)P%q\f;\"[!+x";
        objectArray[21] = "o0z{\u000eP\u001a\u0010qt\u001f\u001f{\u001ez\u007f\u001bE\u000f";
        objectArray[22] = "x\u007f\u0018z\u000f\u001f,k\u0003\u0016\rx~,\u001b)\u0012\u0004.k\u0018l";
        objectArray[23] = "^iX\u000ePj\n}CbI\r\u000b8HX\u001c7\u0004hZ\u0003 6\n:_ZJd\u0019vSb";
        objectArray[24] = "\u001aG\u001f\u0011\u001aMNS\u0004}\u0014*\u001aEC\u0018R@HV\u000f\u0014";
        objectArray[25] = "03B\n2'd'Yf+@2f\u001a\u001fr}n<]_By3dYV\u007f%i#\u0019f";
        objectArray[26] = "R\u0001FH\u000fs\u0006\u0015]$\u0016\u0014\u0007PV\u001eC.\b\u0000DE\u007f%\f\u0011\u001aJ\u0016t\nUF$";
        objectArray[27] = "@v)\u0003 u\u0003suELyy1!]0)Ik5Es\u0013";
        objectArray[28] = "4'1U/4`3*9.S5#1Eeco7)\u0006";
        objectArray[29] = "\u001d\u0004\u0007\u00125*I\u0010\u001c~5M\u001c\u0000\u0007\u0002\u007f}F\u0014\u001fA";
        objectArray[30] = "H*>\u0016t\u0011\u001c6$_\u000b\u0014#:!\u0005p\u001dX8)\rd}";
        objectArray[31] = "HA\u0001\u0010 \u0000\u001cU\u001a|5gLU\u001fDl\nM\u0017SM";
        objectArray[32] = "8:\u0017~L!l.\f\u0012GF>/Oo\u0002wi1\f{";
        objectArray[33] = "f\"8$k\u001f26#Hfxf d-#\u001243(!";
        objectArray[34] = "3El}S>b\u00025z.'\u0002S0l\u0014r8\\`~ON9R2{\u0016$kA~w.";
        objectArray[35] = "\u0001R\u0006\u001f\\.SQ\bU`>:\b\r^\u001d'\u0006K\r^\u0000";
        objectArray[36] = "w|&#6a#h=O,\u0006\"-6uz<-}$.F7)lz!/f/(&O";
        objectArray[37] = "y\u0017|\u0005i\u0007-\u0003gi~`\u007f\u0002$\u0014'Q(\u001cg\u0000";
        objectArray[38] = "uL~O\u0014\r!Xe#\u001bjtH~_^Z.\\f\u001c";
        objectArray[39] = "\u0001L+ \u0019XUX0L\u0010?\u0007Ys1W\u000ePG0%";
        objectArray[40] = ",\u0006cY'Kx\u0012x5/,)[e\u0004k\u001ci\u0017hV";
        objectArray[41] = "\u0010\u00117}\"fW\u0015)y]Mho\u0006I\u0001\u0006\u0010\u00117}\"fW\u0015)y";
        objectArray[42] = "\\qYnK\u001c\beB\u0002R{\t I8\u0007A\u0006p[c;A\u000e~G8\u000b\u001b\u001af\u0004\u0002";
        objectArray[43] = "\u000fpc'Q4Lu?a=967kyAh\u0006m\u007fa\u0002R";
        objectArray[44] = "Xn\fL\u0005Y\fz\u0017 \t>^{T]K\u000f\te\u0017I";
        objectArray[45] = "BzdC^v\u0010yj\tbkyr8\u0001X3C}h\u0013\u0003\u000fHyyM\ff\u0019\u007f=\u0011b";
        objectArray[46] = "\u00006\nb\u0007/T\"\u0011\u000e\u0011H\u0005k\f?KxE'\u0001m";
        Object[] objectArray2 = objectArray;
        objectArray[47] = "\u0003K\t$f;W_\u0012Hl\\\u0006\u0016\u000fy*lFZ\u0002+";
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = LungeMacro.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = LungeMacro.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = LungeMacro.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = LungeMacro.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(LungeMacro.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(LungeMacro.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

