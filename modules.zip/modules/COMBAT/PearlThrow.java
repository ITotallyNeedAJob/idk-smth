// === Kuzi module: PearlThrow ===
// Category   : COMBAT
// Description: Throws an ender pearl on Activate.
// Payload    : a.a.a.j.c.S (verified: False)

package kuzi.modules.combat;

import a.a.a.p.J;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.module.Module;
import kuzi.obf.g.a.j;
import kuzi.obf.g.a.p;
import kuzi.obf.m.r;
import kuzi.obf.p.L;
import kuzi.settings.KeyBinding;
import kuzi.settings.Setting;
import net.minecraft.Item;
import net.minecraft.Items;
import net.minecraft.Minecraft;
import net.minecraft.Options;

public final class PearlThrow
extends BaseModule
implements p,
Module {
    private final KeyBinding triggerKey;
    private boolean pendingThrow;
    private boolean keyDown;
    private boolean useKeyDown;
    private int q;
    private int savedSlot;
    private int holdTicks;
    private static final long t = 26633179386534L;
    private static final Object[] x = new Object[]{"t\u0006\u0010H\u007fj\u007f\u0006\u0012HM", "c\u0016\u000eO_\bo\u0016\u001d", Boolean.TYPE, "\u007fm~[wFnmS", "(8\u0010N\u00179]\u0018\u001bA\u0006v<\u0016\u0010J\u0002,H", "]v\u0004,\u00043Vv\u000f", "4%:1\u007f\u001c4%-ms\u0013.n-ss\u0006)\u001f}.\"", "S\\/cM0&|$l\\\u007fGr/gX%3", Void.TYPE, Integer.TYPE, "AD-s<*HD.s7", "kvy:'Jbvz:'", "8\u0015lNa<3\u001a}\u0001\u000028\u0011y[", "AR71.9JR51!", "\u0010\u0010ClF\u0004\u0001\u0010h", "v\u0014\u001438|v\u0014\u0003o4sl_\u0003q4fk.Q*l'", "\u000b@i0\u0007g\u0000@a", "dqHt#j\u0011QC{2%p_Hp6\u007f\u0004", "/_ibk|Z\u007fbmz3;qif~iO", ",Ae+\u0006e3\u000e;\u0010\u0001\u0000:T>p\fktY>\u0010\u0018j(^8{Vg(>", "\u0010N-L>2\u000f\u0001sw7WOLrO<l\u0018\nhK", "07Z\u001b]4oiQ\u0019ff\n<Y\f^dhjX\u0000W\u000f3*N_\n4dlT[f", ")t\u0002\u001c\u007fS\"h\u0018\u0014\u0004J\u00126\tQ\u007f\u001d`n\u001eRx", "wDW5\u0016\fh\u000b\t\u000e\u0011izJ\u00056\u0013\u000b,K\t?xTc\u0004\u0010i\u0015\biJ\u0014\u000e", "\u0012$|\u001d\u00171\rk\"&\u0003TJj<\u0017\u0017,M&*^", "YNd_s;F\u0001:d{^\u0006L;\\qeQ\n!X", "u\u0013Qu<\u001aj\\\u000fN)\u007f-]\u0011\u007f<\u0007*\u0011\u00076", "\u0017;\u001e>R6\u001c.\u001enh &lCxY$^k\u000fn\u0010J", "to\u0013\t#\u0018p>\u001fXL<YD>!\u0010wto\u0013\t#\u0018p>\u001fX", "[>\u000e9~+DqP\u0002iN\u0003pN3~6\u0004<Xz", "\u0017L\u000ew^\u0011\b\u0003PLHtHNQt\\O\u001f\bKp", "8X^?h9'\u0017\u0000\u0004m\\5V\f<m>cW\u00005\u0006a,\u0018\u0019ck=&V\u001d\u0004", "'\u0017n\u000b`\tx\u0016:\u0004]\\\u0016R1Ml[nU}[%5+\u001e?J:Xw\u0014qN]", "biGt\u001fH}&\u0019O\u0014-;r\u00100\u0016IhtNq", "tf\u000eQll46\u0007IP>Dl\u001c\u0006)g/'\u0000\b2W", "\t\u0011\u0014`ub\u0002\u0004\u00140Ou8FI&~p@A\u000507\u001e", "}$+GHl\"%\u007fHu9L67C\u000eh'9\u007f\t\u0019Pu\"#@\u0019k\"d9Du", "nt\u0001)n\u0019eh\u001b!\u0015\rUa\u00140-\u000277\u0015<$ihxZ%r\u00044r\u0014!\u0015"};
    private static final String[] y = new String[]{null, null, "java/lang/Boolean", null, null, null, null, null, "java/lang/Void", "java/lang/Integer", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null};

    public PearlThrow() {
        long l2 = t ^ 0x61645167F7ABL;
        long l3 = l2 ^ 0x58BE5F283E18L;
        super("PearlThrow", "Throws an ender pearl on Activate.", Category.COMBAT);
        this.triggerKey = new KeyBinding("Trigger Key", -1);
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.triggerKey};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        long l2 = t ^ 0x73B4B944F56BL;
        long l3 = l2 ^ 0x1C124B3BAA29L;
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.c(objectArray);
        super.d();
        Client.c.a(p.class, this);
        Client.c.a(Module.class, this);
    }

    @Override
    public void e() {
        block3: {
            Options options;
            block4: {
                Minecraft mc;
                boolean bl;
                block2: {
                    super.e();
                    Client.c.b(p.class, this);
                    bl = false;
                    Client.c.b(Module.class, this);
                    mc = BaseModule.a;
                    if (bl) break block2;
                    if (mc == null) break block3;
                    mc = BaseModule.a;
                }
                options = mc.options;
                if (bl) break block4;
                if (options == null) break block3;
                options = BaseModule.a.options;
            }
            options.keyUse.setDown(false);
        }
    }

    @Override
    public void b() {
        long l2;
        long l3 = l2 = t ^ 0x57E2DF8A62L;
        long l4 = l3 ^ 0x3035DE1A3DA3L;
        long l5 = l3 ^ 0x70DC7217261EL;
        if (BaseModule.a.screen != null) {
            return;
        }
        Object[] objectArray = new Object[2];
        objectArray[1] = l5;
        objectArray[0] = (int)((Integer)this.triggerKey.a());
        boolean keyDown = L.a(objectArray);
        if (keyDown && !this.keyDown && !this.pendingThrow) {
            this.pendingThrow = true;
        }
        this.keyDown = keyDown;
        if (this.pendingThrow) {
            if (this.savedSlot == -1) {
                this.savedSlot = BaseModule.a.player.getInventory().getSelectedSlot();
            }
            J.a((Item)Items.ENDER_PEARL);
            if (!this.useKeyDown) {
                BaseModule.a.options.keyUse.setDown(true);
                this.useKeyDown = true;
                this.holdTicks = 0;
                return;
            }
            BaseModule.a.options.keyUse.setDown(false);
            ++this.holdTicks;
            if (this.holdTicks >= 1) {
                Object[] objectArray2 = new Object[1];
                objectArray2[0] = l4;
                this.a(objectArray2);
            }
        }
    }

    private void a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = (l2 = t ^ l2) ^ 0x47FDCB88BA25L;
        J.a((int)this.savedSlot);
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l3;
        this.c(objectArray2);
    }

    private void c(Object[] objectArray) {
        block3: {
            Options options;
            block4: {
                Minecraft mc;
                boolean bl;
                block2: {
                    long l2 = (Long)objectArray[0];
                    l2 = t ^ l2;
                    this.savedSlot = -1;
                    this.holdTicks = 0;
                    bl = false;
                    this.q = 0;
                    this.pendingThrow = false;
                    this.useKeyDown = false;
                    mc = BaseModule.a;
                    if (bl) break block2;
                    if (mc == null) break block3;
                    mc = BaseModule.a;
                }
                options = mc.options;
                if (bl) break block4;
                if (options == null) break block3;
                options = BaseModule.a.options;
            }
            options.keyUse.setDown(false);
        }
    }

    @Override
    public void a(j j2) {
    }

    private static r a(r r2) {
        return r2;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = PearlThrow.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = PearlThrow.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = PearlThrow.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = PearlThrow.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }
}

