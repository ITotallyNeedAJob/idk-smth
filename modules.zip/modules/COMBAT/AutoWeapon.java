// === Kuzi module: AutoWeapon ===
// Category   : COMBAT
// Description: Switches to the best weapon when attacking
// Payload    : a.a.a.j.c.F (verified: False)

package kuzi.modules.combat;

import a.a.a.p.J;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Iterator;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.g.a.b;
import kuzi.obf.g.a.n;
import kuzi.obf.m.r;
import kuzi.obf.p.K;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import net.minecraft.AxeItem;
import net.minecraft.ItemStack;
import net.minecraft.Attributes;
import net.minecraft.EquipmentSlotGroup;
import net.minecraft.ItemAttributeModifiers;
import net.minecraft.DataComponents;
import net.minecraft.MaceItem;

public class AutoWeapon
extends BaseModule
implements n {
    private final BoolSetting preferMace;
    private static final long n = 35228356103312L;
    private static final long r;
    private static final Object[] s;
    private static final String[] t;

    public AutoWeapon() {
        long l2 = n ^ 0x29B01BCC64A4L;
        long l3 = l2 ^ 0x28592D173321L;
        super("Auto Weapon", "Switches to the best weapon when attacking", Category.COMBAT);
        this.preferMace = new BoolSetting("Prefer Mace", true);
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.preferMace};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        Client.a().a(n.class, this);
        super.d();
    }

    @Override
    public void e() {
        Client.a().b(n.class, this);
        super.e();
    }

    @Override
    public void a(b b2) {
        long l2 = n ^ 0x117484206847L;
        long l3 = l2 ^ 0x6C9C98F8CAF4L;
        if (BaseModule.a.player == null) {
            return;
        }
        int bestSlot = -1;
        double bestDamage = -1.0;
        for (int slot = 0; slot < (int)r; ++slot) {
            ItemStack stack = BaseModule.a.player.getInventory().getItem(slot);
            if (stack.isEmpty() || !K.a(stack) && !(stack.getItem() instanceof AxeItem) && !(stack.getItem() instanceof MaceItem)) continue;
            Object[] objectArray = new Object[2];
            objectArray[1] = stack;
            objectArray[0] = l3;
            double damage = this.computeAttackDamage(objectArray);
            if (((Boolean)this.preferMace.a()).booleanValue() && stack.getItem() instanceof MaceItem) {
                damage += 100.0;
            }
            if (!(damage > bestDamage)) continue;
            bestDamage = damage;
            bestSlot = slot;
        }
        if (bestSlot != -1 && bestSlot != BaseModule.a.player.getInventory().getSelectedSlot()) {
            J.a((int)bestSlot);
        }
    }

    private double computeAttackDamage(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        ItemStack stack = (ItemStack)objectArray[1];
        l2 = n ^ l2;
        ItemAttributeModifiers modifiers = (ItemAttributeModifiers)stack.get(DataComponents.ATTRIBUTE_MODIFIERS);
        int guard = 66;
        if (modifiers == null) {
            return 0.0;
        }
        double totalDamage = 0.0;
        Iterator iterator = modifiers.comp_2393().iterator();
        while (iterator.hasNext()) {
            int isAttackDamage;
            block6: {
                block7: {
                    ItemAttributeModifiers.mc9287 entry;
                    block9: {
                        EquipmentSlotGroup slotGroup;
                        EquipmentSlotGroup requiredGroup;
                        block8: {
                            ItemAttributeModifiers.mc9287 entryRef;
                            block5: {
                                entryRef = entry = (ItemAttributeModifiers.mc9287)iterator.next();
                                if (l2 < 0L || guard == 0) break block5;
                                isAttackDamage = entryRef.comp_2395().equals((Object)Attributes.ATTACK_DAMAGE);
                                if (l2 < 0L) break block6;
                                if (isAttackDamage == 0) break block7;
                                entryRef = entry;
                            }
                            slotGroup = entryRef.comp_2397();
                            requiredGroup = EquipmentSlotGroup.MAINHAND;
                            if (guard == 0) break block8;
                            if (slotGroup == requiredGroup) break block9;
                            slotGroup = entry.comp_2397();
                            requiredGroup = EquipmentSlotGroup.ANY;
                        }
                        if (slotGroup != requiredGroup) break block7;
                    }
                    totalDamage += entry.comp_2396().comp_2449();
                }
                isAttackDamage = guard;
            }
            if (isAttackDamage != 0) continue;
        }
        return totalDamage;
    }

    static {
        s = new Object[]{"4q?\u0019mm?q=\u0019J", "%ILH?\u0014,IOH=", "\t^g6\u0006\r\u0002^o", "i\u000e~$\u0016\nb\u000eu", "\u007f/\u0000\u0016Q\u0002\n\u000f\u000b\u0019@Mk\u0001\u0000\u0012D\u0017\u001f", Void.TYPE, "xu\u000e<{stu\u001d", "`pF(\u001dVkpD(\u0012", Integer.TYPE, "\u001c{oI\u001b\u001a\u001c{x\u0015\u0017\u0015\u00060x\u000b\u0017\u0000\u0001A(VF", "ec\t{G3\u0010C\u0002tV|qM\t\u007fR&\u0005", Double.TYPE, "yj:MSahj\u0010", "F$=V)KF$*\n%D\\o*\u0014%Q[\u001exO}\u001b", Boolean.TYPE, "\tU\u007f&1|\u0018UT", "l4rDJ\be4qDJ", "U]{\u0001=a^RjN\\oUYn\u0014", "\fL]C\u0015=UH_\u0010y\nrsjd%A\fL]C\u0015=UH_\u0010", "\u00004\u0007=s\u0010\\5\u0015Eb{\u0001&\u0017&l\u0016B|\u0011$\u000bGV0\t\"f\u0004\f6\u000bE", "|\reX\u0013}&\u0000'L\"tFXcQY!\u007f\u001e\"QB", "\n]!\u001cI>V\\3dTU\u000eM.\n\u000f/P\u0014#\u0016", "M\u0004+E1\u0002B[eA\u000bW$W'\u0005nNI\r3Ae>\u001f\b'DbSE\u00039\u0011\u000b", "~\u0015p)F\r{[uj=\u0019C\u0016?iX\u0002.L+-Sr", "\u000f6\"%WIS70]F\"\r.6!I\u001cYv %/\u0012\u000e&2;\u0017\u0012\u000f)%]", "\u000b\u000eWeG^\u0005\u0003N.%\faUCj^]QGNlFe", "a17 Ffj9p66\u007fQyf8\u000b{`t?gY\u0016`0c`\u000fjls2e6", "\u0014*Kbo\u0007N'\tv^\u0003.~Tk\"\u0001\u0010*\f}&g\u0015#G)7\nO(Y|^", "v?H11\rsqMrJ\u0018K<\u0007q/\u0002&f\u00135$r"};
        t = new String[]{null, null, null, null, null, "java/lang/Void", null, null, "java/lang/Integer", null, null, "java/lang/Double", null, null, "java/lang/Boolean", null, null, null, null, null, null, null, null, null, null, null, null, null, null};
        r = 5249180648303755273L;
    }

    private static r a(r r2) {
        return r2;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = AutoWeapon.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = AutoWeapon.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = AutoWeapon.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = AutoWeapon.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }
}

