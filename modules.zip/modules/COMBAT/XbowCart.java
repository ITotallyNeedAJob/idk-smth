// === Kuzi module: XbowCart ===
// Category   : COMBAT
// Description: Builds a TNT-minecart + fire (+ slab) trap and fires your crossbow through the fire.
// Payload    : a.a.a.j.c.ab (verified: True)

package kuzi.modules.combat;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.module.Module;
import kuzi.obf.h.b.v;
import kuzi.obf.i.k_0;
import kuzi.obf.j.c.o;
import kuzi.obf.m.r;
import kuzi.obf.p.L;
import kuzi.settings.BoolSetting;
import kuzi.settings.KeyBinding;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.BlockItem;
import net.minecraft.ItemStack;
import net.minecraft.Items;
import net.minecraft.BlockPos;
import net.minecraft.Direction;
import net.minecraft.Vec3;
import net.minecraft.SlabBlock;
import net.minecraft.Minecraft;
import net.minecraft.BlockTags;
import net.minecraft.BlockHitResult;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class XbowCart
extends BaseModule
implements Module {
    private final KeyBinding m;
    private final BoolSetting hTSafeBow;
    private final BoolSetting autoShoot;
    private final SliderSetting placeDelay;
    private final BoolSetting switchBack;
    private o trapState;
    private int actionDelay;
    private int triggerCooldown;
    private int previousSlot;
    private boolean triggerWasDown;
    private BlockPos railPos;
    private BlockPos cartPos;
    private BlockPos firePos;
    private BlockPos slabPos;
    private static final long A;
    private static final String[] B;
    private static final String[] C;
    private static final Map D;
    private static final long[] E;
    private static final Integer[] F;
    private static final Map G;
    private static final Object[] H;
    private static final String[] I;

    public XbowCart() {
        long l2 = A ^ 0x5B610AFF46BFL;
        long l3 = l2 ^ 0x76A754DE37F8L;
        super("XbowCart", "Builds a TNT-minecart + fire (+ slab) trap and fires your crossbow through the fire.", Category.COMBAT);
        this.m = new KeyBinding("Trigger Key", -1);
        this.hTSafeBow = new BoolSetting("HT Safe Bow", true);
        this.autoShoot = new BoolSetting("Auto Shoot", true);
        this.placeDelay = new SliderSetting("Place Delay", 2.0, 1.0, 10.0, 1.0);
        this.switchBack = new BoolSetting("Switch Back", true);
        this.trapState = kuzi.obf.j.c.o.IDLE;
        this.actionDelay = 0;
        this.triggerCooldown = 0;
        this.previousSlot = -1;
        this.triggerWasDown = false;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.m, this.hTSafeBow, this.autoShoot, this.placeDelay, this.switchBack};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        long l2 = A ^ 0x67A8E92A4D9FL;
        long l3 = l2 ^ 0x26FE3868C26EL;
        Client.a().a(Module.class, this);
        super.d();
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.a(objectArray);
    }

    @Override
    public void e() {
        long l2;
        long l3 = l2 = A ^ 0x72D4F0CB2DB1L;
        long l4 = l3 ^ 0x67F50E7967C4L;
        long l5 = l3 ^ 0x33822189A240L;
        Client.a().b(Module.class, this);
        super.e();
        Object[] objectArray = new Object[1];
        objectArray[0] = l4;
        this.m(objectArray);
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l5;
        this.a(objectArray2);
    }

    @Override
    public void h() {
        long l2 = A ^ 0x2D39F0BE96AFL;
        long l3 = l2 ^ 0x6C6F21FC195EL;
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.a(objectArray);
    }

    private void a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = A ^ l2;
        this.trapState = kuzi.obf.j.c.o.IDLE;
        this.actionDelay = 0;
        this.triggerCooldown = 0;
        this.previousSlot = -1;
        this.triggerWasDown = false;
        this.slabPos = null;
        this.firePos = null;
        this.cartPos = null;
        this.railPos = null;
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public void b() {
        v0 = var1_1 = XbowCart.A ^ 22315353059990L;
        var3_2 = v0 ^ 15777749665326L;
        var5_3 = v0 ^ 124092109235742L;
        var7_4 = v0 ^ 9613631208983L;
        var9_5 = v0 ^ 93584719330663L;
        var11_6 = 66;
        if (BaseModule.a.player == null || BaseModule.a.level == null || BaseModule.a.gameMode == null) {
            v1 = new Object[1];
            v1[0] = var9_5;
            this.a(v1);
            return;
        }
        if (this.trapState != kuzi.obf.j.c.o.IDLE) {
            v2 = new Object[1];
            v2[0] = var7_4;
            this.f(v2);
            return;
        }
        if (this.triggerCooldown > 0) {
            --this.triggerCooldown;
        }
        if ((var12_7 = ((Integer)this.m.a()).intValue()) <= 0 || BaseModule.a.screen != null) ** GOTO lbl-1000
        v3 = new Object[2];
        v3[1] = var5_3;
        v3[0] = var12_7;
        if (L.a(v3)) {
            v4 = true;
        } else lbl-1000:
        // 2 sources

        {
            v4 = false;
        }
        var13_8 = v4;
        var14_9 = var13_8 != false && this.triggerWasDown == false;
        this.triggerWasDown = var13_8;
        if (var14_9 && this.triggerCooldown == 0) {
            v5 = new Object[1];
            v5[0] = var3_2;
            this.c(v5);
        }
    }

    private void c(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = A ^ l2;
        Direction mc23502 = BaseModule.a.player.getDirection();
        BlockPos mc23382 = BaseModule.a.player.blockPosition().below();
        this.slabPos = mc23382.relative(mc23502);
        this.firePos = mc23382.relative(mc23502, 2);
        this.railPos = mc23382.relative(mc23502, 3);
        this.cartPos = this.railPos.above();
        this.previousSlot = BaseModule.a.player.getInventory().getSelectedSlot();
        this.actionDelay = 0;
        this.trapState = kuzi.obf.j.c.o.RAIL;
    }

    /*
     * Unable to fully structure code
     */
    private void f(Object[] var1_1) {
        block35: {
            block34: {
                var2_2 = (Long)var1_1[0];
                v0 = var2_2 = XbowCart.A ^ var2_2;
                var4_3 = v0 ^ 5225458648431L;
                var6_4 = v0 ^ 6229967671598L;
                var8_5 = v0 ^ 6533724056742L;
                var10_6 = v0 ^ 55641366645547L;
                var12_7 = v0 ^ 21616914808742L;
                var14_8 = 66;
                if (this.actionDelay-- > 0) {
                    return;
                }
                var15_9 = Math.max(1, ((Double)this.placeDelay.a()).intValue());
                v1 = this;
                v2 = -8318368857670341968L;
                if (var2_2 <= 0L) break block34;
                switch (v1.trapState.ordinal()) {
                    case 1: {
                        v3 = new Object[1];
                        v3[0] = var10_6;
                        var16_10 = this.a(v3);
                        v4 = var14_8;
                        if (var2_2 < 0L) ** GOTO lbl37
                        if (v4 != 0) {
                            if (var16_10 != -1) {
                                v5 = new Object[3];
                                v5[2] = this.a(new Object[]{this.railPos});
                                v5[1] = var16_10;
                                v5[0] = var4_3;
                                this.b(v5);
                            }
                            this.actionDelay = var15_9;
                            this.trapState = kuzi.obf.j.c.o.CART;
                        }
                        if (var2_2 <= 0L) ** GOTO lbl38
                        v4 = var14_8;
lbl37:
                        // 2 sources

                        if (v4 != 0) break block35;
                    }
lbl38:
                    // 3 sources

                    case 2: {
                        if (var2_2 <= 0L) ** GOTO lbl61
                        v6 = this;
                        if (var2_2 < 0L) ** GOTO lbl59
                        if (v6.cartPos == null || !BaseModule.a.level.getBlockState(this.cartPos).is(BlockTags.RAILS)) ** GOTO lbl58
                        v7 = new Object[2];
                        v7[1] = Items.TNT_MINECART;
                        v7[0] = var12_7;
                        var16_10 = this.d(v7);
                        v8 = var14_8;
                        if (var2_2 <= 0L) ** GOTO lbl62
                        if (v8 == 0) ** GOTO lbl61
                        if (var16_10 != -1) {
                            v9 = new Object[3];
                            v9[2] = this.a(new Object[]{this.cartPos});
                            v9[1] = var16_10;
                            v9[0] = var4_3;
                            this.b(v9);
                        }
lbl58:
                        // 4 sources

                        v6 = this;
lbl59:
                        // 2 sources

                        v6.actionDelay = var15_9;
                        this.trapState = kuzi.obf.j.c.o.FIRE;
lbl61:
                        // 3 sources

                        v8 = var14_8;
lbl62:
                        // 2 sources

                        if (var2_2 <= 0L) ** GOTO lbl70
                        if (v8 != 0) break block35;
                    }
                    case 3: {
                        v10 = new Object[2];
                        v10[1] = Items.FLINT_AND_STEEL;
                        v10[0] = var12_7;
                        v8 = var16_10 = this.d(v10);
lbl70:
                        // 2 sources

                        if (var2_2 > 0L) {
                            if (var16_10 != -1) {
                                v11 = new Object[3];
                                v11[2] = this.a(new Object[]{this.firePos});
                                v11[1] = var16_10;
                                v11[0] = var4_3;
                                this.b(v11);
                            }
                            this.actionDelay = var15_9;
                        }
                        v12 = (Boolean)this.hTSafeBow.a();
                        if (var2_2 <= 0L) ** GOTO lbl85
                        if (v12) {
                            v13 = kuzi.obf.j.c.o.SLAB;
                        } else {
                            v12 = (Boolean)this.autoShoot.a();
lbl85:
                            // 2 sources

                            v13 = v12 != false ? kuzi.obf.j.c.o.SHOOT : kuzi.obf.j.c.o.RESTORE;
                        }
                        this.trapState = v13;
                        v14 = var14_8;
                        if (var2_2 < 0L) ** GOTO lbl97
                        if (v14 != 0) break block35;
                    }
                    case 4: {
                        v15 = new Object[1];
                        v15[0] = var6_4;
                        var16_10 = this.c(v15);
                        if (var2_2 <= 0L) ** GOTO lbl106
                        v14 = var14_8;
lbl97:
                        // 2 sources

                        if (v14 != 0) {
                            if (var16_10 != -1) {
                                v16 = new Object[3];
                                v16[2] = this.a(new Object[]{this.slabPos});
                                v16[1] = var16_10;
                                v16[0] = var4_3;
                                this.b(v16);
                            }
                            this.actionDelay = var15_9;
                        }
lbl106:
                        // 4 sources

                        this.trapState = (Boolean)this.autoShoot.a() != false ? kuzi.obf.j.c.o.SHOOT : kuzi.obf.j.c.o.RESTORE;
                        v17 = var14_8;
                        if (var2_2 <= 0L) ** GOTO lbl117
                        if (v17 != 0) break block35;
                    }
                    case 5: {
                        v18 = new Object[2];
                        v18[1] = Items.CROSSBOW;
                        v18[0] = var12_7;
                        var16_10 = this.d(v18);
                        v17 = var14_8;
lbl117:
                        // 2 sources

                        if (var2_2 >= 0L) {
                            if (v17 != 0) {
                                if (var16_10 != -1) {
                                    BaseModule.a.player.getInventory().setSelectedSlot(var16_10);
                                    ((k_0)BaseModule.a).invokeDoItemUse();
                                }
                                this.actionDelay = var15_9;
                                this.trapState = kuzi.obf.j.c.o.RESTORE;
                            }
                            v17 = var14_8;
                        }
                        if (var2_2 < 0L) ** GOTO lbl135
                        if (v17 != 0) break block35;
                    }
                    case 6: {
                        v19 = new Object[1];
                        v19[0] = var8_5;
                        this.m(v19);
                        this.triggerCooldown = var15_9 + 2;
                        this.trapState = kuzi.obf.j.c.o.IDLE;
                        v17 = var14_8;
lbl135:
                        // 2 sources

                        if (v17 == 0) {
                            break;
                        } else {
                            ** GOTO lbl138
                        }
                    }
                    {
lbl138:
                        // 2 sources

                        break block35;
                    }
                }
                v1 = this;
                v2 = var8_5;
            }
            v20 = new Object[1];
            v20[0] = v2;
            v1.m(v20);
            this.trapState = kuzi.obf.j.c.o.IDLE;
        }
    }

    private void b(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        int n2 = (Integer)objectArray[1];
        BlockHitResult mc39652 = (BlockHitResult)objectArray[2];
        l2 = A ^ l2;
        ((Minecraft)XbowCart.d("\u00d6", (long)2573708671017350117L, (long)l2)).player.getInventory().setSelectedSlot(n2);
        XbowCart.d("A", (Object)mc39652, (boolean)true, (long)2573264136064722561L, (long)l2);
    }

    private BlockHitResult a(Object[] objectArray) {
        BlockPos mc23382 = (BlockPos)objectArray[0];
        Vec3 VanillaChestLoot = new Vec3((double)mc23382.getX() + 0.5, (double)mc23382.getY() + 1.0, (double)mc23382.getZ() + 0.5);
        return new BlockHitResult(VanillaChestLoot, Direction.UP, mc23382, false);
    }

    private void m(Object[] objectArray) {
        int n2;
        block5: {
            block6: {
                XbowCart xbowCart;
                block4: {
                    long l2 = (Long)objectArray[0];
                    l2 = A ^ l2;
                    int n3 = 66;
                    if (!((Boolean)this.switchBack.a()).booleanValue()) break block4;
                    xbowCart = this;
                    n2 = n3;
                    if (l2 < 0L) break block5;
                    if (n2 == 0) break block6;
                    if (xbowCart.previousSlot != -1 && BaseModule.a.player != null) {
                        BaseModule.a.player.getInventory().setSelectedSlot(this.previousSlot);
                    }
                }
                xbowCart = this;
            }
            n2 = -1;
        }
        xbowCart.previousSlot = n2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private int a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = A ^ l2;
        int n2 = 0;
        int n3 = 66;
        do {
            block6: {
                int n4;
                block5: {
                    if (n2 >= XbowCart.c("u", (int)5976, (long)(0x67F1B3BACDFEBB28L ^ l2))) return -1;
                    ItemStack mc17992 = BaseModule.a.player.getInventory().getItem(n2);
                    int n5 = mc17992.is(Items.RAIL) ? 1 : 0;
                    int n6 = n3;
                    if (l2 >= 0L) {
                        if (n6 == 0) return n5;
                        n6 = n3;
                    }
                    if (n6 == 0) return n4;
                    if (n5 != 0) break block5;
                    n4 = mc17992.is(Items.POWERED_RAIL) ? 1 : 0;
                    if (n3 == 0) return n4;
                    if (n4 != 0) break block5;
                    n4 = mc17992.is(Items.DETECTOR_RAIL) ? 1 : 0;
                    if (n3 == 0) return n4;
                    if (n4 != 0) break block5;
                    n4 = mc17992.is(Items.ACTIVATOR_RAIL) ? 1 : 0;
                    if (n3 == 0) return n4;
                    if (n4 == 0) break block6;
                }
                n4 = n2;
                return n4;
            }
            ++n2;
        } while (n3 != 0);
        return -1;
    }

    /*
     * Unable to fully structure code
     */
    private int c(Object[] var1_1) {
        block3: {
            var2_2 = (Long)var1_1[0];
            var2_2 = XbowCart.A ^ var2_2;
            var5_3 = 0;
            var4_4 = 0;
            while (var5_3 < XbowCart.c("u", (int)24602, (long)(1189282051911521902L ^ var2_2))) {
                block7: {
                    block5: {
                        block6: {
                            block4: {
                                var6_5 = BaseModule.a.player.getInventory().getItem(var5_3).getItem();
                                v0 = var4_4;
                                if (var2_2 <= 0L) break block4;
                                if (v0 != 0) break block5;
                                v0 = var6_5 instanceof BlockItem;
                            }
                            if (var4_4 != 0) break block3;
                            if (v0 == 0) break block6;
                            var7_6 = (BlockItem)var6_5;
                            v1 = var4_4;
                            if (var2_2 < 0L) break block7;
                            if (v1 == 0) {
                                if (var7_6.getBlock() instanceof SlabBlock) {
                                    return var5_3;
                                } else {
                                    ** GOTO lbl22
                                }
                            }
                            break block5;
                        }
                        ++var5_3;
                    }
                    v1 = var4_4;
                }
                if (v1 == 0) continue;
            }
            v0 = -1;
        }
        return v0;
    }

    /*
     * Exception decompiling
     */
    private int d(Object[] var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * java.lang.UnsupportedOperationException
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.considerAsDoLoopStart(LoopIdentifier.java:383)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.identifyLoops1(LoopIdentifier.java:65)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:681)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Unable to fully structure code
     */
    static {
        block16: {
            block15: {
                block14: {
                    block13: {
                        XbowCart.A = kuzi.obf.h.b.v.a(361085591614293293L, 3707137381634477422L, MethodHandles.lookup().lookupClass()).a(135523473628180L);
                        XbowCart.H = new Object[69];
                        XbowCart.I = new String[69];
                        XbowCart.c();
                        XbowCart.D = new HashMap<K, V>(13);
                        var11 = XbowCart.A ^ 12286226904840L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[7];
                        var18_4 = 0;
                        var17_5 = "\u00b7\u00a1_\u00078\u00c2B\u00ef\u001eUWV\u00c4\u00f6\u0086%\u00d3\u00d0\u00ccV \u009d\u00be<\u009fsP\u0099(\u001e\u009a\u00bfuVd\u00a9\u0004\u00a6\u00ed\u0002\u00d2\u00c1{\\\u00deD\u00972s\u00ceC\u00f6?\u0091\u0013\u001f\u0010\u00ba\u00bd\u0006\u00aa!l\u00b9r\\H\u00d2A\u009c\u00e3|$P\u008c\\s~\u00ff^\u0016\u00c6\u00b0\u00d2\u00c0y\u00ba\u00d8\u00f0\u0096\u009b\u00c2\u008c\u0086\u000f]\u0084\u0015k\u00d3\\\u00d1\u00b3\u00bf\u0018f;\u00b6\u00be=}\u00a5/\u00c9\u0099Y\u008b\u00aasO\u00c6k#\u00f2\u00e7~\u0004\u00e2 \u0011a R\u00a4\u0016n\u00fb;\u00ba\u00d8\u00c3\u0086\u00b5YX\\q\u0019^\u00ce#\u00d5\u0001qJ\u001cd\u0089\u00f3\u00f6\u009b \u008e\u00a0\u00fa\u00a9/\u009fS \u009b\u00e8\u00c3\u0099\u00bc`\u0082EMG\u00fcG\u009c\"P9a\u00d6\u0018\u00191\u0088m0 \bf@\u00be\u0007\u0016\u008d\u00a0\u00fc\u00d77\u0089\u008f\u009c\u00af\u00cf$n\u00f7\u00d7!\u0089\u00f3\u0093r\u001a\u00e8\u001eT\u00caa\u00de +\u009e\u00e1\u0013qR\u00de:\u0080\u0003\u00e3\u00f3\u0086 c\u00169\u000b\u00f5\u00ca\u0005c\u00a66\u00e9\"\u00e0\u00a2\u008a?\u00fe\u00ff";
                        var19_6 = "\u00b7\u00a1_\u00078\u00c2B\u00ef\u001eUWV\u00c4\u00f6\u0086%\u00d3\u00d0\u00ccV \u009d\u00be<\u009fsP\u0099(\u001e\u009a\u00bfuVd\u00a9\u0004\u00a6\u00ed\u0002\u00d2\u00c1{\\\u00deD\u00972s\u00ceC\u00f6?\u0091\u0013\u001f\u0010\u00ba\u00bd\u0006\u00aa!l\u00b9r\\H\u00d2A\u009c\u00e3|$P\u008c\\s~\u00ff^\u0016\u00c6\u00b0\u00d2\u00c0y\u00ba\u00d8\u00f0\u0096\u009b\u00c2\u008c\u0086\u000f]\u0084\u0015k\u00d3\\\u00d1\u00b3\u00bf\u0018f;\u00b6\u00be=}\u00a5/\u00c9\u0099Y\u008b\u00aasO\u00c6k#\u00f2\u00e7~\u0004\u00e2 \u0011a R\u00a4\u0016n\u00fb;\u00ba\u00d8\u00c3\u0086\u00b5YX\\q\u0019^\u00ce#\u00d5\u0001qJ\u001cd\u0089\u00f3\u00f6\u009b \u008e\u00a0\u00fa\u00a9/\u009fS \u009b\u00e8\u00c3\u0099\u00bc`\u0082EMG\u00fcG\u009c\"P9a\u00d6\u0018\u00191\u0088m0 \bf@\u00be\u0007\u0016\u008d\u00a0\u00fc\u00d77\u0089\u008f\u009c\u00af\u00cf$n\u00f7\u00d7!\u0089\u00f3\u0093r\u001a\u00e8\u001eT\u00caa\u00de +\u009e\u00e1\u0013qR\u00de:\u0080\u0003\u00e3\u00f3\u0086 c\u00169\u000b\u00f5\u00ca\u0005c\u00a66\u00e9\"\u00e0\u00a2\u008a?\u00fe\u00ff".length();
                        var16_7 = 128;
                        var15_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block13;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = XbowCart.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "\u00f7ffJ\u0082|\u0019M\u00c2\u00abkG\u00ff+\u0000R:\u007fn\u00ea\u008f;\f\u0010 RBh!7\u008c[\u009b'\u009b\u0006\u0016eV\u00e7\u00ab[1\u00d2x\t\u000f\u00feWz\u00fc\u00a2\u00fe\u00e5\u0091,1";
                            var19_6 = "\u00f7ffJ\u0082|\u0019M\u00c2\u00abkG\u00ff+\u0000R:\u007fn\u00ea\u008f;\f\u0010 RBh!7\u008c[\u009b'\u009b\u0006\u0016eV\u00e7\u00ab[1\u00d2x\t\u000f\u00feWz\u00fc\u00a2\u00fe\u00e5\u0091,1".length();
                            var16_7 = 24;
                            var15_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block13;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = XbowCart.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block14;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                XbowCart.B = var20_3;
                XbowCart.C = new String[7];
                XbowCart.G = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[2];
                var3_13 = 0;
                var4_14 = "\u007f\u000b\u008f<,\u00b9\u00f7a\u009d\u001c\u00da\u00e8k(\u00adx";
                var5_15 = "\u007f\u000b\u008f<,\u00b9\u00f7a\u009d\u001c\u00da\u00e8k(\u00adx".length();
                var2_16 = 0;
                while (true) {
                    break block15;
                    break;
                }
lbl76:
                // 1 sources

                while (true) {
                    var6_12[v10] = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
                    if (var2_16 < var5_15) ** continue;
                    break block16;
                    break;
                }
            }
            var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
            v10 = var3_13++;
            var8_18 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            ** while (true)
        }
        XbowCart.E = var6_12;
        XbowCart.F = new Integer[2];
    }

    private static r a(r r2) {
        return r2;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x188;
        if (F[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = E[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])G.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    G.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/c/ab", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            XbowCart.F[n3] = n4;
        }
        return F[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = XbowCart.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/c/ab" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (I[n4] != null) {
            return n4;
        }
        Object object = H[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 51;
            case 1 -> 6;
            case 2 -> 10;
            case 3 -> 63;
            case 4 -> 56;
            case 5 -> 11;
            case 6 -> 19;
            case 7 -> 58;
            case 8 -> 18;
            case 9 -> 44;
            case 10 -> 53;
            case 11 -> 41;
            case 12 -> 48;
            case 13 -> 39;
            case 14 -> 49;
            case 15 -> 34;
            case 16 -> 59;
            case 17 -> 61;
            case 18 -> 32;
            case 19 -> 46;
            case 20 -> 43;
            case 21 -> 54;
            case 22 -> 60;
            case 23 -> 30;
            case 24 -> 9;
            case 25 -> 27;
            case 26 -> 16;
            case 27 -> 35;
            case 28 -> 40;
            case 29 -> 33;
            case 30 -> 29;
            case 31 -> 20;
            case 32 -> 28;
            case 33 -> 62;
            case 34 -> 42;
            case 35 -> 21;
            case 36 -> 50;
            case 37 -> 36;
            case 38 -> 0;
            case 39 -> 31;
            case 40 -> 5;
            case 41 -> 25;
            case 42 -> 52;
            case 43 -> 47;
            case 44 -> 45;
            case 45 -> 55;
            case 46 -> 38;
            case 47 -> 14;
            case 48 -> 24;
            case 49 -> 26;
            case 50 -> 7;
            case 51 -> 23;
            case 52 -> 37;
            case 53 -> 17;
            case 54 -> 1;
            case 55 -> 15;
            case 56 -> 2;
            case 57 -> 8;
            case 58 -> 3;
            case 59 -> 4;
            case 60 -> 13;
            case 61 -> 22;
            case 62 -> 57;
            default -> 12;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        XbowCart.I[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = H;
        H[0] = "G8\u0010\u0006!\u0006L8\u001b";
        objectArray[1] = ":\u0002W'l,:\u0002@{`# I@e`6'8\u001081";
        objectArray[2] = "O\"e\bX>D\"g\bXr";
        objectArray[3] = "J\u0003-vw\u001eF\u0003>";
        objectArray[4] = "W)c`S\u000f\\)a`\\";
        objectArray[5] = Integer.TYPE;
        XbowCart.I[5] = "java/lang/Integer";
        objectArray[6] = "d!L\u0000\u001f\u001au!Lo";
        objectArray[7] = "<AETC+<AR\bO$&\nR\u0016O1!{\u0002C\u0018w";
        objectArray[8] = Boolean.TYPE;
        XbowCart.I[8] = "java/lang/Boolean";
        objectArray[9] = Void.TYPE;
        XbowCart.I[9] = "java/lang/Void";
        objectArray[10] = "84~m_c84i1Sl\"\u007fi/Sy%\u000e8p\u00012";
        objectArray[11] = "\n)\u00073\u001bi\u0001)\u00053\u0015";
        objectArray[12] = "6B]O\u0000%CbV@\u0011j\"l]K\u00150V";
        objectArray[13] = "-\u001fIf\u0011\u0005$\u001fJf\u0011";
        objectArray[14] = "@tE-z1K{Tb\u001b?@pP8";
        objectArray[15] = "l;\u0015A38\u0019\u001b\u001eN\"wx\u0015\u0015E&-\f";
        objectArray[16] = "\u000e^I6\u001dF\u0007^J6\u001f";
        objectArray[17] = "n0\u0006j\u0001\u0013\u001b\u0010\re\u0010\\z\u001e\u0006n\u0014\u0006\u000e";
        objectArray[18] = "2,V\u007fpPG\f]pa\u001f&\u0002V{eER";
        objectArray[19] = "\u0014XN,\u0016yaxE#\u00076\u0000vN(\u0003lt";
        objectArray[20] = "op;\u0005 ^\u001aP0\n1\u0011{^;\u00015K\u000f";
        objectArray[21] = "\u007fC\u001b$v\u0018vC\u0018$z";
        objectArray[22] = "\u001av\bG\r\u0000\u0011v\u0000";
        objectArray[23] = "\u0016p_I\u0014^\u001fp\\I\u001f";
        objectArray[24] = "4yae?QAYjj.\u001e Waa*DT";
        objectArray[25] = "]I\u001deR,(i\u0016jCcIg\u001daG9=";
        objectArray[26] = "\u0017/p\\\u0007\u001cb\u000f{S\u0016S\u0003\u0001pX\u0012\tw";
        objectArray[27] = "\\l\u0011\u0016\u0018HMl<";
        objectArray[28] = "\u001e[\u0002zF!k{\tuWn\nu\u0002~S4~";
        objectArray[29] = "VCoo\rc#cd`\u001c,Bmok\u0018v6";
        objectArray[30] = "(l!6%\u0011lx>&\u0015&WP\u001a\u0001\u0015Blk6my\u0006xt&";
        objectArray[31] = "[\u0003\u0007YaK\u000fU\fG]\fa\u0005CL8\n\u0004@F\u0005'";
        objectArray[32] = "[*;~\f*\u000f|0`0ba-)eMu\u001dj)aN";
        objectArray[33] = "\u0017L(\u00116*C\u001a#\u000f\nh-O3\u001fj-\u0016\to\u0017u";
        objectArray[34] = "Q\u0018O\u001d7\u001d\u0005ND\u0003\u000bTk\u001f]\u0006vB\u0017X]\u0002u";
        objectArray[35] = "\u001a&8\u000f\u001c\u0017^2'\u001f,!l\u001c\u0000d\u0013\u0000Y6t\bW\u0014F&";
        objectArray[36] = "k*Xc]Q?|S}a\u001aQ-Jx\u001c\u000e-jJ|\u001f";
        objectArray[37] = "cI\u001a\u001f|\u0010#AFNLDXJ\u0014L,\u0010c\fHD3.";
        objectArray[38] = "3\u0006\u001a-Fxw\u0012\u0005=vZM'+FIop\u0016V*\r{o\u0006";
        objectArray[39] = "1mJC>Ye;A]\u0002\t\u000b6\f\u001dk\u00185:K\u001bg`52PMs\u001e26Y\u0015\u0002";
        objectArray[40] = "\u000fi1wuU\u0003`7l\fV3?nc6\u0006\ne/`v?\r? ttZH:ik\f\u0001Ta;`r\u0006Phc\u0011";
        objectArray[41] = "(z\f\u0006\b%ln\u0013\u00168\u0012SH:m\u00072kj@\u0001C&tz";
        objectArray[42] = "=HRF/\u0011i\u001eYX\u0013M\u0007\u0013\u0014\u0018zP9\u001fS\u001ev(9\u0017HHbV>\u0013A\u0010\u0013";
        objectArray[43] = "RCJ\u000e\t:\u000eDP\u0000s/c\u0016F]\u000f%\u0002L\u0004\u0016\u0017F";
        objectArray[44] = "&\u0017\u00125OjrA\u0019+s=\u001cLTk\u001a+\"@\u0013m\u0016S\"H\b;\u0002-%L\u0001cs";
        objectArray[45] = "9\u000fZWwr6\u000eW\u001cKdX\u0013\u0015W\"uf\u001fRQ.\rfMX\u000b3h#H\u0011\u0014K";
        objectArray[46] = "KKru\nVSR{\u001e\u0012$\u0010\ffq\u001bBBN!n";
        objectArray[47] = ">U J\u0017&j\u0003+T+v\u0004W0\u0014Q{dR7\u001d\u0016\u001f>\u0004`WO\u007f;\u0003i\u0010+";
        objectArray[48] = "8\f\u007f\b\u0004blZt\u001687\u0002W9VQ#<[~P][9Vo\u000f\u0006`\u007f\ng\u00108";
        objectArray[49] = "j\u007fSz3K>)Xd\u000f\rPxAar\u0014,?Aeq";
        objectArray[50] = "U5cyIP\u0001chgu\u000eogw\u007f\u0014\u0013\u000en$u\u0014";
        objectArray[51] = ">R,E=Lj\u0004'[\u0001\f\u0004\u00008C`\u000fe\tkI`";
        objectArray[52] = "\u0017-\"k\u001f\u0019C{)u#K-vd5JX\u0013z#3F \u0013r8eR^\u0014v1=#";
        objectArray[53] = "Du\u001cf{\u0018\u0010#\u0017xGK~.Z8.Y@\"\u001d>\"!@*\u0006h6_G.\u000f0G";
        objectArray[54] = "\"n\u00014Nlfz\u001e$~ZPN!\u0018$M\u001d*\u0006#\u00150qn\u0012<\u0005";
        objectArray[55] = "\u0010^\u0012Pd`D\b\u0019NX?*\f\u0006V9#K\u0005U\\9";
        objectArray[56] = "\n\u0010\\\"#M^FW<\u001f\u000e0\u0017^9tD\\SJ&d";
        objectArray[57] = "\tnsN\u0002+Mzl^2\u0006zQB%\r<J~?II(Un";
        objectArray[58] = "O\u000b\u001e0Km\u000b\u001f\u0001 {J9*>[Dz\f\u001bR7\u0000n\u0013\u000b";
        objectArray[59] = "\u0003\u0010}\b\u00132WFv\u0016/w9\u0013f\u0006O5\u0002U:\u000eP";
        objectArray[60] = "\u001bG\u0010\u000e\u0015?O\u0011\u001b\u0010)o!\u001cVP@~\u001f\u0010\u0011VL\u0006\u001cC\u001bS\u0010?F\u0002\u0018\u0013)";
        objectArray[61] = "\u0011w\u00119-4\u0014tOcO\u00078Tb\u0015\u0013L\u0011w\u00119-4\u0014tOc";
        objectArray[62] = "0\u000b\u001b{||d]\u0010e@,\nP]%)=4\\\u001a#%E1Q\u000b|~~w\r\u0003c@";
        objectArray[63] = "^naMi&\u001ef=\u001cYsemo\u001e9&^+3\u0016&\u0018";
        objectArray[64] = "NB\u000b\u000buT\u001a\u0014\u0000\u0015I\bt\u0015\u0018\n1\u0004O\n\u0010\f4";
        objectArray[65] = "LcM9+~\u00185F'\u0017:v`V7wyM&\n?h";
        objectArray[66] = "~q0\rqt*';\u0013M&D*vS$5z&1U(M\u007f+ \nsv9w(\u0015M";
        objectArray[67] = "\u0004C\bv\u001a6\u001cZ\u0001\u001d\u000fD\u0005\u0006_t\u0013z\tAYxkz\u0001Z\u000fl\u0015}\u0005SW\u001d";
        Object[] objectArray2 = objectArray;
        objectArray[68] = "\u0013O/B}\u0010G\u0019$\\AQ)\u001a/U3\u0013CF6\u001d!";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = XbowCart.e(l2, l3);
            object = H[n2];
            try {
                if (!(object instanceof String)) break block2;
                XbowCart.H[n2] = clazz = Class.forName(I[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = XbowCart.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = XbowCart.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = XbowCart.e(l2, l3);
        Object object = H[n2];
        if (object instanceof String) {
            String string = I[n2];
            int n3 = string.indexOf(8);
            Class clazz = XbowCart.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = XbowCart.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = XbowCart.c(clazz3, string2, clazz2)) != null) {
                    XbowCart.H[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = XbowCart.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        XbowCart.H[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = XbowCart.f(1012999551920733L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = XbowCart.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = XbowCart.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = XbowCart.e(l2, l3);
        Object object = H[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = I[n2];
                int n4 = string2.indexOf(8);
                clazz3 = XbowCart.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = XbowCart.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = XbowCart.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        XbowCart.H[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = XbowCart.f(1012999551920733L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = XbowCart.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        XbowCart.H[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = XbowCart.f(1012999551920733L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == 'Z' || c2 == '\u00d1' || c2 == '\u00d6' || c2 == '\u00ea') {
                field = XbowCart.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == 'Z' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == '\u00d1' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == '\u00d6' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = XbowCart.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == '\u00d0' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == 'A' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = XbowCart.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/c/ab" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(XbowCart.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(XbowCart.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

