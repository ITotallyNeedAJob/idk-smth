// === Kuzi module: AutoMaceShield ===
// Category   : COMBAT
// Description: Raises a shield and looks at an enemy that is falling onto you (anti-mace).
// Payload    : a.a.a.j.c.B (verified: True)

package kuzi.modules.combat;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.module.Module;
import kuzi.obf.h.b.v;
import kuzi.obf.m.r;
import kuzi.obf.p.F;
import kuzi.obf.p.ah;
import kuzi.obf.p.l_0;
import kuzi.obf.p.m;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.InteractionHand;
import net.minecraft.Entity;
import net.minecraft.Player;
import net.minecraft.Items;
import net.minecraft.Vec3;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class AutoMaceShield
extends BaseModule
implements Module {
    private final SliderSetting range;
    private final SliderSetting minHeight;
    private final SliderSetting holdTime;
    private final BoolSetting equipShield;
    private final BoolSetting autoLook;
    private final BoolSetting ignoreFriends;
    private long holdUntilMs;
    private int previousSlot;
    private boolean useKeyHeld;
    private static final long v;
    private static final String[] w;
    private static final String[] x;
    private static final Map y;
    private static final long[] z;
    private static final Integer[] A;
    private static final Map B;
    private static final Object[] C;
    private static final String[] D;

    public AutoMaceShield() {
        long l2 = v ^ 0x3341070BFFA0L;
        long l3 = l2 ^ 0x2E04AE1D92D7L;
        super("AutoMaceShield", "Raises a shield and looks at an enemy that is falling onto you (anti-mace).", Category.COMBAT);
        this.range = new SliderSetting("Range", 6.0, 1.0, 20.0, 0.5);
        this.minHeight = new SliderSetting("Min Height", 1.5, 0.0, 12.0, 0.5);
        this.holdTime = new SliderSetting("Hold Time", 700.0, 0.0, 3000.0, 50.0);
        this.equipShield = new BoolSetting("Equip Shield", true);
        this.autoLook = new BoolSetting("Auto Look", true);
        this.ignoreFriends = new BoolSetting("Ignore Friends", true);
        this.holdUntilMs = 0L;
        this.previousSlot = -1;
        this.useKeyHeld = false;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.range, this.minHeight, this.holdTime, this.equipShield, this.autoLook, this.ignoreFriends};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        Client.a().a(Module.class, this);
        super.d();
        this.holdUntilMs = 0L;
        this.previousSlot = -1;
        this.useKeyHeld = false;
    }

    @Override
    public void e() {
        long l2 = v ^ 0x425707FC3181L;
        long l3 = l2 ^ 0x7F833C45C6D7L;
        Client.a().b(Module.class, this);
        super.e();
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.c(objectArray);
    }

    @Override
    public void b() {
        long l2;
        long l3 = l2 = v ^ 0x24C845862EA6L;
        long l4 = l3 ^ 0x191C7E3FD9F0L;
        long l5 = l3 ^ 0x66EEDB4285ECL;
        long l6 = l3 ^ 0x7D28D9C27549L;
        boolean bl = false;
        if (BaseModule.a.player == null || BaseModule.a.level == null || BaseModule.a.gameMode == null) {
            return;
        }
        if (BaseModule.a.screen != null) {
            Object[] objectArray = new Object[1];
            objectArray[0] = l4;
            this.c(objectArray);
            return;
        }
        Object[] objectArray = new Object[1];
        objectArray[0] = l6;
        Player target = this.a(objectArray);
        long l7 = System.currentTimeMillis();
        if (target != null) {
            this.holdUntilMs = l7 + (long)((Double)this.holdTime.a()).doubleValue();
            if (((Boolean)this.autoLook.a()).booleanValue()) {
                Vec3 targetEyePos = target.getEyePosition();
                ah.a(this, l_0.HIGH, () -> AutoMaceShield.lambda$onTick2$0(targetEyePos), 9.0, kuzi.obf.p.m.SMOOTH, 0.0, false, false);
            }
        }
        if (l7 <= this.holdUntilMs) {
            Object[] objectArray2 = new Object[1];
            objectArray2[0] = l5;
            this.a(objectArray2);
        } else {
            Object[] objectArray3 = new Object[1];
            objectArray3[0] = l4;
            this.c(objectArray3);
        }
    }

    private Player a(Object[] objectArray) {
        Player mc16572;
        block21: {
            long l2 = (Long)objectArray[0];
            l2 = v ^ l2;
            double d2 = (Double)this.range.a();
            int n2 = 0;
            double d3 = d2 * d2;
            double d4 = (Double)this.minHeight.a();
            Player mc16573 = null;
            Iterator iterator = BaseModule.a.level.players().iterator();
            block0: while (true) {
                int n3 = iterator.hasNext();
                while (n3 != 0) {
                    block29: {
                        block30: {
                            Player mc16574;
                            block27: {
                                double d5;
                                block28: {
                                    double d6;
                                    block26: {
                                        double d7;
                                        int n4;
                                        block25: {
                                            int n5;
                                            block24: {
                                                block22: {
                                                    double d8;
                                                    block23: {
                                                        Player mc16575;
                                                        mc16572 = mc16574 = (Player)iterator.next();
                                                        if (l2 <= 0L) break block21;
                                                        int n6 = n2;
                                                        if (l2 > 0L) {
                                                            if (n6 != 0) break block21;
                                                            n6 = n2;
                                                        }
                                                        if (n6 == 0) {
                                                            if (mc16572 == BaseModule.a.player) continue block0;
                                                            mc16575 = mc16574;
                                                        }
                                                        int n7 = mc16575.isDeadOrDying();
                                                        n7 = n2;
                                                        if (l2 > 0L) {
                                                            if (n7 == 0) {
                                                                if (n4 != 0) continue block0;
                                                                n4 = mc16574.isSpectator();
                                                            }
                                                            n7 = n2;
                                                        }
                                                        if (l2 >= 0L) {
                                                            if (n7 == 0) {
                                                                if (n4 != 0 && l2 > 0L) continue block0;
                                                                n4 = ((Boolean)this.ignoreFriends.a()).booleanValue();
                                                            }
                                                            n7 = n2;
                                                        }
                                                        if (n7 != 0) break block22;
                                                        if (n4 == 0) break block23;
                                                        int n5 = F.a(mc16574.getName().getString());
                                                        n5 = n2;
                                                        if (l2 < 0L) break block24;
                                                        if (n5 == 0) {
                                                            if (n4 != 0 && l2 > 0L) continue block0;
                                                        }
                                                        break block22;
                                                    }
                                                    n4 = (d8 = mc16574.getY() - BaseModule.a.player.getY() - d4) == 0.0 ? 0 : (d8 < 0.0 ? -1 : 1);
                                                }
                                                n5 = n2;
                                            }
                                            if (l2 > 0L) {
                                                if (n5 == 0) {
                                                    if (n4 < 0 && l2 > 0L) continue block0;
                                                    n4 = mc16574.onGround() ? 1 : 0;
                                                }
                                                n5 = n2;
                                            }
                                            if (n5 != 0) break block25;
                                            if (n4 != 0 && l2 > 0L) continue block0;
                                            d7 = mc16574.getDeltaMovement().y;
                                            if (n2 != 0) break block26;
                                            double d9 = d7 - -0.08;
                                            n4 = d9 == 0.0 ? 0 : (d9 > 0.0 ? 1 : -1);
                                        }
                                        if (n4 >= 0) continue block0;
                                        d7 = d6 = mc16574.distanceToSqr((Entity)BaseModule.a.player);
                                    }
                                    if (l2 < 0L) break block27;
                                    d5 = d6;
                                    if (n2 != 0) break block28;
                                    double d10 = d5 - d3;
                                    n3 = d10 == 0.0 ? 0 : (d10 < 0.0 ? -1 : 1);
                                    if (l2 <= 0L) break block29;
                                    if (n3 > 0) break block30;
                                    d5 = d6;
                                }
                                d3 = d5;
                            }
                            mc16573 = mc16574;
                        }
                        n3 = n2;
                    }
                    if (l2 < 0L) continue;
                    if (n3 != 0) break block0;
                    continue block0;
                }
                break;
            }
            mc16572 = mc16573;
        }
        return mc16572;
    }

    private void a(Object[] objectArray) {
        block16: {
            int n2;
            InteractionHand shieldHand;
            block15: {
                InteractionHand hand;
                int n3;
                long l2;
                block8: {
                    block9: {
                        int n4;
                        block14: {
                            int n5;
                            block12: {
                                block13: {
                                    AutoMaceShield self;
                                    int n6;
                                    int n7;
                                    block11: {
                                        int n8;
                                        block10: {
                                            l2 = (Long)objectArray[0];
                                            long l3 = l2 = v ^ l2;
                                            long l4 = l3 ^ 0x7DA5CD87AB2AL;
                                            long l5 = l3 ^ 0x283CA8C60263L;
                                            Object[] objectArray2 = new Object[1];
                                            objectArray2[0] = l5;
                                            shieldHand = this.a(objectArray2);
                                            n3 = 66;
                                            hand = shieldHand;
                                            if (n3 == 0) break block8;
                                            if (hand != null) break block9;
                                            n8 = ((Boolean)this.equipShield.a()).booleanValue();
                                            if (n3 == 0) break block10;
                                            if (n8 == 0) break block9;
                                            Object[] objectArray3 = new Object[1];
                                            objectArray3[0] = l4;
                                            n8 = this.a(objectArray3);
                                        }
                                        n7 = n4 = n8;
                                        n6 = -1;
                                        if (n3 == 0) break block11;
                                        if (n7 == n6) break block9;
                                        self = this;
                                        n5 = n3;
                                        if (l2 <= 0L) break block12;
                                        if (n5 == 0) break block13;
                                        n7 = self.previousSlot;
                                        n6 = -1;
                                    }
                                    if (n7 != n6) break block14;
                                    self = this;
                                }
                                n5 = BaseModule.a.player.getInventory().getSelectedSlot();
                            }
                            self.previousSlot = n5;
                        }
                        BaseModule.a.player.getInventory().setSelectedSlot(n4);
                        shieldHand = InteractionHand.MAIN_HAND;
                    }
                    hand = shieldHand;
                }
                if (hand == null) {
                    return;
                }
                BaseModule.a.options.keyUse.setDown(true);
                n2 = n3;
                if (l2 < 0L) break block15;
                if (n2 == 0) break block16;
                n2 = BaseModule.a.player.isUsingItem() ? 1 : 0;
            }
            if (n2 == 0) {
                BaseModule.a.gameMode.useItem((Player)BaseModule.a.player, shieldHand);
            }
            this.useKeyHeld = true;
        }
    }

    private void c(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = v ^ l2;
        boolean bl = false;
        if (this.useKeyHeld) {
            BaseModule.a.options.keyUse.setDown(false);
            this.useKeyHeld = false;
        }
        ah.c(this);
        if (this.previousSlot != -1 && BaseModule.a.player != null) {
            BaseModule.a.player.getInventory().setSelectedSlot(this.previousSlot);
            this.previousSlot = -1;
        }
    }

    private InteractionHand a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = v ^ l2;
        int n2 = 66;
        if (BaseModule.a.player.getMainHandItem().is(Items.SHIELD)) {
            return InteractionHand.MAIN_HAND;
        }
        if (BaseModule.a.player.getOffhandItem().is(Items.SHIELD)) {
            return InteractionHand.OFF_HAND;
        }
        return null;
    }

    /*
     * Exception decompiling
     */
    private int a(Object[] var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * java.lang.UnsupportedOperationException
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.considerAsDoLoopStart(LoopIdentifier.java:383)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.identifyLoops1(LoopIdentifier.java:65)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:681)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private static Vec3 lambda$onTick2$0(Vec3 eyePos) {
        return eyePos;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block16: {
            block15: {
                block14: {
                    block13: {
                        AutoMaceShield.v = kuzi.obf.h.b.v.a(4476736513891075917L, -7295909990615224001L, MethodHandles.lookup().lookupClass()).a(208467899136270L);
                        AutoMaceShield.C = new Object[55];
                        AutoMaceShield.D = new String[55];
                        AutoMaceShield.c();
                        AutoMaceShield.y = new HashMap<K, V>(13);
                        var11 = AutoMaceShield.v ^ 94420273395435L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[8];
                        var18_4 = 0;
                        var17_5 = "?\u00daFv\u00f0\u00a7\u00faF\u00d54\u0096$\u0015\n\u00ca\u00bb\u0083\u009b\u0091\u001a\u00f2%n\u009f\u00a61\u0080\u00a5\u0011L\u0081\u00ff \u00c9\u0096\u00d1\\\u00ce \u0099B\u00e4\u00a7\u009bMm\u00eb|\u00dd\u00dc\u00ca\u00f4\u00ac\u00ed\u001c\u00c3\u00c0\u00c8\u0093\u00ad\u0005\u00e5\u0014\u00f8\u00f2\u0010\u0005\u00bb\u001d0\u00db\u00f9\u0083\u009d\u00af\u00f6\u00bb\u0095S\u008c\u00bb\u009d \u00eb\u0007\u00feW\u0098\u00f2\u0010\u0093x-\u00ddJ$\u00f5V6\u00fe\u0092\u00cc\u00dd\u00992\"\u00e1\u00b6\u00ba\u00d3\u001d\u00c5\\p\u0094\u0018\u00ae\u00a1;\u00e616\u0096\u00e8\u00a6\u00fa\u0080\u00e4!\u0097s\u0016v\u0004\r\u0004\u00ec\u009c\u00f5\u0093 \u00cd\u00a2\u0094#G\u00ee\u0085\u00fb\u00df\u00a0\u0004\u00a3\u00b6\u00bf\b\u00ee\u00ef\u00a5j\u00ce_\u00f3\u00f0\u0099\u00e6\u00c5\u00c0-\u001aFaA";
                        var19_6 = "?\u00daFv\u00f0\u00a7\u00faF\u00d54\u0096$\u0015\n\u00ca\u00bb\u0083\u009b\u0091\u001a\u00f2%n\u009f\u00a61\u0080\u00a5\u0011L\u0081\u00ff \u00c9\u0096\u00d1\\\u00ce \u0099B\u00e4\u00a7\u009bMm\u00eb|\u00dd\u00dc\u00ca\u00f4\u00ac\u00ed\u001c\u00c3\u00c0\u00c8\u0093\u00ad\u0005\u00e5\u0014\u00f8\u00f2\u0010\u0005\u00bb\u001d0\u00db\u00f9\u0083\u009d\u00af\u00f6\u00bb\u0095S\u008c\u00bb\u009d \u00eb\u0007\u00feW\u0098\u00f2\u0010\u0093x-\u00ddJ$\u00f5V6\u00fe\u0092\u00cc\u00dd\u00992\"\u00e1\u00b6\u00ba\u00d3\u001d\u00c5\\p\u0094\u0018\u00ae\u00a1;\u00e616\u0096\u00e8\u00a6\u00fa\u0080\u00e4!\u0097s\u0016v\u0004\r\u0004\u00ec\u009c\u00f5\u0093 \u00cd\u00a2\u0094#G\u00ee\u0085\u00fb\u00df\u00a0\u0004\u00a3\u00b6\u00bf\b\u00ee\u00ef\u00a5j\u00ce_\u00f3\u00f0\u0099\u00e6\u00c5\u00c0-\u001aFaA".length();
                        var16_7 = 32;
                        var15_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block13;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = AutoMaceShield.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "\u0098\u00aca\u00eb\u00f0\u0081W\u00a7&zo\u00f3\u00833\u009c\u0098Q\u000bK\u0011\u001f\u0006\u00f8\u00c7/\"F\u00b3\u00a2\u00ea\u0013\u00f40\u00cb\u00b6v<\u00bcE\u00ef]\u0017\u0007\u00ddJm\u00ea\u00e7h\u00a8\u00d3R\u00c3'\u00adE\u00c36L\u008e\u00f8Dg}S\u00af\u00bc\u00aa\u00cb\u00ba\u00b5\u00d1/g\u00a8\u00a0\u00a2\u00c9\u00dbqX\u00d0c3\u00f0\u00ac\u00b5\u008e\u00f3S\u0099\u00d2\u0088\u001c\u007f\u00db-\u00f7{\u00c9\u0083\u008d}`\u0081\u0000\u0096\u00fd\u00d0)<,\u008a\b\u0081\u0087+\u00f9\u00e3\b\u0018\u00e3k]h\u0005V\u00f2)\u008b\u00c8\u00ae\u00e6\u00fa\u00f8\u0014\u00dci\u0082\u00e0\u0097\\R\u00ef\u00a4";
                            var19_6 = "\u0098\u00aca\u00eb\u00f0\u0081W\u00a7&zo\u00f3\u00833\u009c\u0098Q\u000bK\u0011\u001f\u0006\u00f8\u00c7/\"F\u00b3\u00a2\u00ea\u0013\u00f40\u00cb\u00b6v<\u00bcE\u00ef]\u0017\u0007\u00ddJm\u00ea\u00e7h\u00a8\u00d3R\u00c3'\u00adE\u00c36L\u008e\u00f8Dg}S\u00af\u00bc\u00aa\u00cb\u00ba\u00b5\u00d1/g\u00a8\u00a0\u00a2\u00c9\u00dbqX\u00d0c3\u00f0\u00ac\u00b5\u008e\u00f3S\u0099\u00d2\u0088\u001c\u007f\u00db-\u00f7{\u00c9\u0083\u008d}`\u0081\u0000\u0096\u00fd\u00d0)<,\u008a\b\u0081\u0087+\u00f9\u00e3\b\u0018\u00e3k]h\u0005V\u00f2)\u008b\u00c8\u00ae\u00e6\u00fa\u00f8\u0014\u00dci\u0082\u00e0\u0097\\R\u00ef\u00a4".length();
                            var16_7 = 120;
                            var15_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block13;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = AutoMaceShield.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block14;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                AutoMaceShield.w = var20_3;
                AutoMaceShield.x = new String[8];
                AutoMaceShield.B = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[2];
                var3_13 = 0;
                var4_14 = "\u008b\u00baw\u001f\u00df\\\u00a4\u00d3\u00ab\u00c4~0\u00f1\u00f5\nI";
                var5_15 = "\u008b\u00baw\u001f\u00df\\\u00a4\u00d3\u00ab\u00c4~0\u00f1\u00f5\nI".length();
                var2_16 = 0;
                while (true) {
                    break block15;
                    break;
                }
lbl76:
                // 1 sources

                while (true) {
                    var6_12[v10] = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
                    if (var2_16 < var5_15) ** continue;
                    break block16;
                    break;
                }
            }
            var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
            v10 = var3_13++;
            var8_18 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            ** while (true)
        }
        AutoMaceShield.z = var6_12;
        AutoMaceShield.A = new Integer[2];
    }

    private static r a(r r2) {
        return r2;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x69DE;
        if (A[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = z[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])B.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    B.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/c/B", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            AutoMaceShield.A[n3] = n4;
        }
        return A[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = AutoMaceShield.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/c/B" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static void c() {
        Object[] objectArray = C;
        C[0] = "(RBJ'v9RB\f";
        objectArray[1] = "z:|@/9q5m\u000fN7z>iU";
        objectArray[2] = "V\u000f'\u0003\u0018fG\u000f*";
        objectArray[3] = "-@\u0015\u0015_\u000b3H\u000fZ\u0017\u000b)B\u0017\u001d\u001e\u0010ir\u0016\u0004\u0001\u0012.D\u0011";
        objectArray[4] = Double.TYPE;
        AutoMaceShield.D[4] = "java/lang/Double";
        objectArray[5] = "\u0019_\n?G4\b_\u0006";
        objectArray[6] = Boolean.TYPE;
        AutoMaceShield.D[6] = "java/lang/Boolean";
        objectArray[7] = Void.TYPE;
        AutoMaceShield.D[7] = "java/lang/Void";
        objectArray[8] = "\n \u00196U\u001a\u0001 \u001b6v";
        objectArray[9] = "<n\u0002V2\r5n\u0001V0";
        objectArray[10] = "O>\u0000\u0016\u0010RD>\u000b";
        objectArray[11] = "\u001c%\u0019RC/\u001c%\u000e\u000eO \u0006n\u000e\u0010O5\u0001\u001f^M\u001e";
        objectArray[12] = "x,V+-]t,E";
        objectArray[13] = "WoT`;-\"O_o*bCATd.87";
        objectArray[14] = "`Q\u0010/\f<\u0015q\u001b \u001dst\u007f\u0010+\u0019)\u0000";
        objectArray[15] = ";\u001d\u0019\u001805;\u001d\u000eD<:!V\u000eZ</&'\\\u0000hk";
        objectArray[16] = "\u0014sK1\u001fWaS@>\u000e\u0018\u0000]K5\nBt";
        objectArray[17] = "\\lX\t\f>WlZ\t\u0003";
        objectArray[18] = Integer.TYPE;
        AutoMaceShield.D[18] = "java/lang/Integer";
        objectArray[19] = "\bBi0vd\u0001Bj0z";
        objectArray[20] = "z)%R/Ps)&R/";
        objectArray[21] = Long.TYPE;
        AutoMaceShield.D[21] = "java/lang/Long";
        objectArray[22] = "{\u00032r\u0012Oj\u0003\u0015";
        objectArray[23] = "u\u0001LT\u0013\"~\u000e]\u001bn:m\tTR";
        objectArray[24] = "raNqx&yaF";
        objectArray[25] = "ZIl/HL/ig Y\u0003Ngl+]Y:";
        objectArray[26] = "x|K2[\n\r\\@=JElRK6N\u001f\u0018";
        objectArray[27] = "S&OpG<&\u0006D\u007fVsG\bOtR)3";
        objectArray[28] = ",\f\u001f:0\u001e,\f\bf<\u00116G\bx<\u000416Z&kO";
        objectArray[29] = "EwT(O\u001c\u001cw\u0013?4\u0006x0\u0001t\rBHi\u0011'\b";
        objectArray[30] = "k0\u0013\u00019\u007f20T\u0016BuVyV]!m)rZ^$\u001cf5\u0010\u00043cm9\u0013\u0001B";
        objectArray[31] = "\u001f9\u0018\u0004\u0010J\nn_\u0012qNti\u0018\u0005\u0018Y\fc\u0004RH$";
        objectArray[32] = "G#\u0014o]\u0017\u00155\u0012\u0014[jP!CxB\bQ&\u001a\u0014\rV\u0017r\n}\nV\u0012ws";
        objectArray[33] = "^y\u007f\u0016\t=\u0007y8\u0001r$c>*JKcSg:\u0019N";
        objectArray[34] = "k\u0005K\u000fK78NJH\"8\u0006JXCN#dK_\u001a\"";
        objectArray[35] = "\u001a[*{T0C[ml/('Om~B>D\u0018v{K";
        objectArray[36] = "(m?T*%qmxCQ \u0015xg\u0003m4wt:T6";
        objectArray[37] = "z\b{un+(\u001e}\u000ejVm\n,bq4l\ru\u000e9lt\u0005 p2$~\u001c\u001c4y/mXaq;=/g&tq:,\b`\u007fbi\u0013\\{`x3,\u0017 cqV)\u001dnb<9o\u0016}1\u0003j#W%2bj(^%\u000e?f#^ o?m*^\u001c3?o-\u001eu4?j(g";
        objectArray[38] = "nFK\u0013M\u00197F\f\u00046\u001fSS\u0013D\n\b1_N\u0013Q";
        objectArray[39] = "\u0018\u0015\t\r\u0003zH\u000bS\n\u007fx'D\u0013SFz\\\u001e\\\bB";
        objectArray[40] = "\u001d\u0018-L&UD\u0018j[]] \u0003}\u001blFE\u0001-\u0016#6\u001d]-\u0014$_\u001a](\u0011]";
        objectArray[41] = "2[h[_gk[/L$x\u000fI-VMywC1\u0001\u001d";
        objectArray[42] = "\u0014{m\u0000\u0014+M{*\u0017o!)`=W^8LbmZ\u0011H@x)\u0018R-@<l\ro";
        objectArray[43] = "9\u0016B7\rD2^H.1zBceU\u000b\u0000dN\u0019+\u0000HnW";
        objectArray[44] = "\f8\u0007\u001e)wU8@\tR}1#WIcdT!\u0007D,\u0014\f}\u0007F+}\u000b}\u0002CR";
        objectArray[45] = "+>\u0005^\u0002&r>BIy\"\u0016+]\tE7t'\u0000^\u001e";
        objectArray[46] = "y#UjC\t,wT0,\u0003\u0017#\u00063\u001c\u0015np\tnWj+|]7\u0010\u000b+wT7,";
        objectArray[47] = "\u0002\f\u0011\n\u0004\u001c[\fV\u001d\u007f\u0002?I\u0018\\FC^I\u0013UF";
        objectArray[48] = "\u00046h\u001ah\u007f\u0019>(B\tP,\u0015\u001ciU\u001b\u00046h\u001ah\u007f\u0019>(B";
        objectArray[49] = "1\u0018nBd=h\u0018)U\u001f&\f_;\u001e&c<\u0006+M#";
        objectArray[50] = "mJfWC\u00144J!@8\u001ePQ6\u0000\t\u00075Sf\rFw;O4XE\u000f1Sc\b8";
        objectArray[51] = "\u0002\\\u0015t9aI\u0007\u0016}\\\u0005||<S\u001c^\u0002\\\u0015t9aI\u0007\u0016}";
        objectArray[52] = "8=\u000fRse-jHD\u0012`Sm\u000fS{v+g\u0013\u0004+\u000b";
        objectArray[53] = "l9\u00068/R59A/TXQ\"VoeA4 \u0006b*13\"M/dU,\"T#T";
        Object[] objectArray2 = objectArray;
        objectArray[54] = "]t\u0001(\u007f&\rj[/\u0003)bx\rx2=\u0007z]u}M_&]wz$X&Xr\u0003";
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = AutoMaceShield.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = AutoMaceShield.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = AutoMaceShield.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = AutoMaceShield.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(AutoMaceShield.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

