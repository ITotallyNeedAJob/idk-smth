// === Kuzi module: AutoMace ===
// Category   : COMBAT
// Description: boing boing smash boing
// Payload    : a.a.a.j.c.A (verified: True)

package kuzi.modules.combat;

import a.a.a.p.q;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.module.Module;
import kuzi.obf.g.a.d;
import kuzi.obf.g.a.j;
import kuzi.obf.g.a.p;
import kuzi.obf.g.a.r;
import kuzi.obf.h.b.l;
import kuzi.obf.h.b.v;
import kuzi.obf.i.n_0;
import kuzi.obf.j.c.e;
import kuzi.obf.j.c.f;
import kuzi.obf.p.D;
import kuzi.obf.p.F;
import kuzi.obf.p.K;
import kuzi.obf.p.ah;
import kuzi.obf.p.l_0;
import kuzi.obf.p.m;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.MobEffects;
import net.minecraft.Entity;
import net.minecraft.EquipmentSlot;
import net.minecraft.Player;
import net.minecraft.Inventory;
import net.minecraft.AxeItem;
import net.minecraft.ItemStack;
import net.minecraft.Items;
import net.minecraft.AABB;
import net.minecraft.HitResult;
import net.minecraft.Vec3;
import net.minecraft.Minecraft;
import net.minecraft.Options;
import net.minecraft.ItemTags;
import net.minecraft.Mth;
import net.minecraft.EntityHitResult;
import net.minecraft.Attributes;
import net.minecraft.ResourceKey;
import net.minecraft.Holder;
import net.minecraft.LocalPlayer;
import net.minecraft.ItemEnchantments;
import net.minecraft.DataComponents;
import net.minecraft.MaceItem;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class AutoMace
extends BaseModule
implements r,
p,
Module {
    private static final double m = 2.95;
    private static final double n = 4.5;
    private static final double o = 5.0;
    private final SliderSetting swingRange;
    private final SliderSetting aimRange;
    private final SliderSetting aimInAir;
    private final BoolSetting autoSwitch;
    private final BoolSetting swapBack;
    private final SliderSetting aimSpeed;
    private final SliderSetting minFallDist;
    private final SliderSetting cooldownMs;
    private final SliderSetting maceSwapDelay;
    private final BoolSetting stunSlam;
    private final BoolSetting weaponOnly;
    private final l aimMode;
    private final l stopAim;
    private final SliderSetting hitboxAccuracy;
    private final BoolSetting ignoreFriends;
    private final BoolSetting targetLock;
    private final BoolSetting snapOnSmash;
    private final BoolSetting noAim;
    private final BoolSetting noAimOnEly;
    private final BoolSetting spearDoublePop;
    private final BoolSetting ignoreWebs;
    private final BoolSetting breachHealthCheck;
    private final SliderSetting targetProtection;
    private final SliderSetting strength;
    private final BoolSetting fakeCounter;
    private Player target;
    private Player lockedTarget;
    private int Q;
    private int R;
    private int savedSlot;
    private long T;
    private long U;
    private int V;
    private double W;
    private int X;
    private int Y;
    private Player Z;
    private boolean aa;
    private Vec3 ab;
    private boolean ac;
    private boolean ad;
    private boolean ae;
    private int switchSlot;
    private static final long bb;
    private static final String[] db;
    private static final String[] hb;
    private static final Map ib;
    private static final long[] jb;
    private static final Integer[] kb;
    private static final Map lb;
    private static final long mb;

    public AutoMace() {
        block0: {
            long l2;
            long l3 = l2 = bb ^ 0x5021A751D716L;
            long l4 = l3 ^ 0x2487254F7471L;
            long l5 = l3 ^ 0x7206429644F9L;
            long l6 = l3 ^ 0x47FAF316D99BL;
            long l7 = l3 ^ 0x25F78400487CL;
            super("AutoMace", "boing boing smash boing", Category.COMBAT);
            this.swingRange = new SliderSetting("Swing Range", 3.0, 2.5, 3.0, 0.1);
            this.aimRange = new SliderSetting("Aim Range", 15.0, 0.0, 20.0, 0.5);
            this.aimInAir = new SliderSetting("Aim In Air", 4.5, 0.0, 15.0, 0.5);
            this.autoSwitch = new BoolSetting("Auto Switch", true);
            this.swapBack = new BoolSetting("Swap Back", true);
            this.aimSpeed = new SliderSetting("Aim Speed", 24.0, 0.0, 35.0, 0.5);
            this.minFallDist = new SliderSetting("Min Fall Dist", 1.5, 0.0, 5.0, 0.1);
            this.cooldownMs = new SliderSetting("Cooldown (ms)", 250.0, 0.0, 2000.0, 10.0);
            this.maceSwapDelay = new SliderSetting("Mace Swap Delay (ms)", 50.0, 0.0, 100.0, 1.0);
            this.stunSlam = new BoolSetting("Stun Slam", true);
            this.weaponOnly = new BoolSetting("Weapon Only", false);
            this.aimMode = new l("Aim Mode", kuzi.obf.j.c.e.STRICT, e.class);
            this.stopAim = new l("Stop Aim", kuzi.obf.j.c.f.HITBOX_EDGE, f.class);
            this.hitboxAccuracy = new SliderSetting("Hitbox Accuracy", 0.3, 0.0, 1.0, 0.05);
            this.ignoreFriends = new BoolSetting("Ignore Friends", true);
            this.targetLock = new BoolSetting("Target Lock", false);
            this.snapOnSmash = new BoolSetting("Snap On Smash", true);
            this.noAim = new BoolSetting("No Aim", false);
            this.noAimOnEly = new BoolSetting("No Aim On Ely", true);
            this.spearDoublePop = new BoolSetting("Spear Double Pop", false);
            this.ignoreWebs = new BoolSetting("Ignore Webs", false);
            this.breachHealthCheck = new BoolSetting("Breach Health Check", false);
            this.targetProtection = new SliderSetting("Target Protection", 4.0, 0.0, 4.0, 1.0);
            this.strength = new SliderSetting("Strength", 0.0, 0.0, 2.0, 1.0);
            this.fakeCounter = new BoolSetting("Fake Counter", true);
            this.target = null;
            this.lockedTarget = null;
            this.Q = 0;
            this.R = -1;
            this.savedSlot = -1;
            this.T = 0L;
            this.U = 0L;
            this.V = 0;
            this.W = 0.0;
            this.X = 0;
            this.Y = -1;
            int n2 = 66;
            this.Z = null;
            this.aa = false;
            this.ab = null;
            this.ac = false;
            this.ad = false;
            this.ae = false;
            this.switchSlot = -1;
            Object[] objectArray = new Object[2];
            objectArray[1] = new Setting[]{this.swingRange, this.aimRange, this.aimInAir, this.autoSwitch, this.swapBack, this.aimSpeed, this.minFallDist, this.cooldownMs, this.maceSwapDelay, this.stunSlam, this.weaponOnly, this.aimMode, this.stopAim, this.hitboxAccuracy, this.ignoreFriends, this.targetLock, this.snapOnSmash, this.noAim, this.noAimOnEly, this.spearDoublePop, this.ignoreWebs, this.breachHealthCheck, this.targetProtection, this.strength, this.fakeCounter};
            objectArray[0] = l7;
            this.l(objectArray);
            Object[] objectArray2 = new Object[2];
            objectArray2[1] = l6;
            objectArray2[0] = (arg_0, arg_1) -> this.lambda$new$0(l5, arg_0, arg_1);
            this.breachHealthCheck.a(objectArray2);
            Object[] objectArray3 = new Object[2];
            objectArray3[1] = l4;
            objectArray3[0] = (boolean)((Boolean)this.breachHealthCheck.a());
            this.a(objectArray3);
            if (n2 != 0) break block0;
            BaseModule.b(new int[3]);
        }
    }

    private void a(Object[] objectArray) {
        boolean bl = (Boolean)objectArray[0];
        long l2 = (Long)objectArray[1];
        long l3 = (l2 = bb ^ l2) ^ 0x660262BED633L;
        boolean bl2 = false;
        Object[] objectArray2 = new Object[2];
        objectArray2[1] = l3;
        objectArray2[0] = !bl;
        this.targetProtection.b(objectArray2);
        Object[] objectArray3 = new Object[2];
        objectArray3[1] = l3;
        objectArray3[0] = !bl;
        this.strength.b(objectArray3);
    }

    @Override
    public void d() {
        Client.c.a(r.class, this);
        int n2 = 66;
        Client.c.a(p.class, this);
        Client.c.a(Module.class, this);
        if (n2 != 0) {
            if (BaseModule.a.player != null) {
                this.W = BaseModule.a.player.getY();
            }
            super.d();
        }
    }

    @Override
    public void a(d d2) {
        block0: {
            boolean bl = false;
            if (!((Boolean)this.spearDoublePop.a()).booleanValue() || this.X <= 0) break block0;
            d2.a();
        }
    }

    /*
     * Unable to fully structure code
     */
    private void c(Object[] var1_1) {
        block33: {
            block32: {
                block31: {
                    block30: {
                        block28: {
                            block29: {
                                block26: {
                                    block27: {
                                        block25: {
                                            block24: {
                                                var2_2 = (Long)var1_1[0];
                                                v0 = var2_2 = AutoMace.bb ^ var2_2;
                                                var4_3 = v0 ^ 12636979945794L;
                                                var6_4 = v0 ^ 92709599335900L;
                                                var8_5 = v0 ^ 55464607463647L;
                                                var10_6 = v0 ^ 32757815636496L;
                                                var12_7 = v0 ^ 12036590321514L;
                                                var14_8 = v0 ^ 124623528273608L;
                                                var16_9 = 66;
                                                if (BaseModule.a.player == null || BaseModule.a.level == null) {
                                                    return;
                                                }
                                                v1 = this.X--;
                                                v2 = var16_9;
                                                if (var2_2 < 0L) break block24;
                                                if (v2 != 0) {
                                                    if (v1 > 0) {
                                                        // empty if block
                                                    }
                                                    v3 = new Object[1];
                                                    v3[0] = var10_6;
                                                    v1 = (int)this.f(v3);
                                                }
                                                if (var2_2 < 0L) break block25;
                                                v2 = var16_9;
                                            }
                                            if (v2 != 0) {
                                                if (v1 == 0) {
                                                    v4 = new Object[1];
                                                    v4[0] = var4_3;
                                                    this.f(v4);
                                                    return;
                                                }
                                                v5 = new Object[2];
                                                v5[1] = this.Z;
                                                v5[0] = var6_4;
                                                v1 = (int)this.a(v5);
                                            }
                                        }
                                        if (v1 != 0) {
                                            v6 = this.Z;
                                        } else {
                                            v7 = new Object[1];
                                            v7[0] = var14_8;
                                            v6 = this.a(v7);
                                        }
                                        v8 = var17_10 = v6;
                                        v9 = var16_9;
                                        if (var2_2 > 0L) {
                                            if (v9 != 0) {
                                                if (v8 == null) {
                                                    v10 = new Object[1];
                                                    v10[0] = var4_3;
                                                    this.f(v10);
                                                    return;
                                                }
                                                v8 = var17_10;
                                            }
                                            v9 = var16_9;
                                        }
                                        if (v9 != 0) {
                                            if (v8 != this.Z) {
                                                this.Z = var17_10;
                                                this.Y = -1;
                                            }
                                            v8 = var17_10;
                                        }
                                        var18_11 = v8.hurtTime;
                                        v11 = this.Y;
                                        v12 = var16_9;
                                        if (var2_2 < 0L) break block26;
                                        if (v12 == 0) break block27;
                                        if (v11 < 0) ** GOTO lbl-1000
                                        v11 = var18_11;
                                    }
                                    v12 = var16_9;
                                }
                                if (var2_2 < 0L) break block28;
                                if (v12 == 0) break block29;
                                if (v11 <= 0) ** GOTO lbl-1000
                                v11 = var18_11;
                            }
                            v12 = var16_9;
                        }
                        if (var2_2 <= 0L) break block30;
                        if (v12 == 0) break block31;
                        v12 = this.Y;
                    }
                    ** if (v11 < v12) goto lbl-1000
lbl-1000:
                    // 1 sources

                    {
                        v11 = 1;
                        ** GOTO lbl90
                    }
lbl-1000:
                    // 3 sources

                    {
                        v11 = 0;
                    }
                }
                var19_12 = v11;
                v13 = this;
                if (var2_2 < 0L) break block32;
                v13.Y = var18_11;
                if (var19_12 == 0) break block33;
                v14 = new Object[1];
                v14[0] = var8_5;
                this.m(v14);
                v15 = new Object[1];
                v15[0] = var12_7;
                this.n(v15);
                v13 = this;
            }
            v16 = new Object[1];
            v16[0] = var4_3;
            v13.f(v16);
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        Player mc16572 = (Player)objectArray[1];
        l2 = bb ^ l2;
        int n2 = 66;
        if (mc16572 == null) return 0 != 0;
        int n3 = mc16572.isAlive();
        int n4 = n2;
        if (l2 >= 0L) {
            if (n4 != 0) {
                if (n3 == 0) return 0 != 0;
                n3 = mc16572.isRemoved();
            }
            n4 = n2;
        }
        if (l2 >= 0L) {
            if (n4 != 0) {
                if (n3 != 0) return 0 != 0;
                double d2 = (double)BaseModule.a.player.distanceTo((Entity)mc16572) - 6.0;
                n3 = d2 == 0.0 ? 0 : (d2 < 0.0 ? -1 : 1);
            }
            n4 = n2;
        }
        if (n4 == 0) return n3 != 0;
        if (n3 > 0) return 0 != 0;
        return 1 != 0;
    }

    private void f(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = bb ^ l2;
        this.Z = null;
        this.Y = -1;
    }

    private void m(Object[] objectArray) {
        block3: {
            Options options;
            block2: {
                long l2 = (Long)objectArray[0];
                l2 = bb ^ l2;
                this.X = (int)AutoMace.c("b", (int)1290, (long)(0x2C233402D9A605FFL ^ l2));
                boolean bl = false;
                options = BaseModule.a.options;
                if (bl) break block2;
                if (options == null) break block3;
                options = BaseModule.a.options;
            }
            options.keyUse.setDown(false);
        }
    }

    private void n(Object[] objectArray) {
        int n2;
        int n3;
        long l2;
        block11: {
            block10: {
                Object object;
                int n4;
                block8: {
                    block9: {
                        l2 = (Long)objectArray[0];
                        long l3 = (l2 = bb ^ l2) ^ 0x7915D81CC41EL;
                        n3 = 66;
                        if (!((Boolean)this.autoSwitch.a()).booleanValue() || BaseModule.a.player == null) {
                            return;
                        }
                        Object[] objectArray2 = new Object[1];
                        objectArray2[0] = l3;
                        n4 = n2 = this.a(objectArray2);
                        object = n3;
                        if (l2 < 0L) break block8;
                        if (object == 0) break block9;
                        if (n4 < 0) break block10;
                        n4 = n2;
                    }
                    object = AutoMace.c("b", (int)12378, (long)(0x3115F49C742E3711L ^ l2));
                }
                if (n4 <= object) break block11;
            }
            return;
        }
        Inventory mc16612 = BaseModule.a.player.getInventory();
        int n5 = n3;
        if (l2 > 0L) {
            if (n5 != 0) {
                if (mc16612.getSelectedSlot() == n2) {
                    return;
                }
                mc16612 = BaseModule.a.player.getInventory();
            }
            n5 = n2;
        }
        mc16612.setSelectedSlot(n5);
        if (BaseModule.a.gameMode != null) {
            ((n_0)BaseModule.a.gameMode).syncSlot();
        }
    }

    private Player a(Object[] objectArray) {
        Player mc16572;
        block18: {
            long l2 = (Long)objectArray[0];
            long l3 = (l2 = bb ^ l2) ^ 0x4CE39AE0CFDL;
            Vec3 eyePos = BaseModule.a.player.getEyePosition();
            Vec3 viewVector = BaseModule.a.player.getViewVector(1.0f);
            Player mc16573 = null;
            boolean bl = false;
            double d2 = 5.5;
            Object[] objectArray2 = new Object[1];
            objectArray2[0] = l3;
            Iterator iterator = this.b(objectArray2).iterator();
            block0: while (true) {
                boolean bl2 = iterator.hasNext();
                while (bl2) {
                    block24: {
                        Player mc16574;
                        block22: {
                            double d3;
                            block23: {
                                double d4;
                                double d5;
                                block21: {
                                    block20: {
                                        boolean bl3;
                                        block19: {
                                            Player mc16575;
                                            mc16572 = mc16574 = (Player)iterator.next();
                                            if (l2 <= 0L) break block18;
                                            boolean bl4 = bl;
                                            if (l2 >= 0L) {
                                                if (bl4) break block18;
                                                bl4 = bl;
                                            }
                                            if (l2 >= 0L) {
                                                if (!bl4) {
                                                    if (mc16572 == BaseModule.a.player) continue block0;
                                                    mc16575 = mc16574;
                                                }
                                                bl4 = bl;
                                            }
                                            if (!bl4) {
                                                if (!mc16575.isAlive()) continue block0;
                                                mc16575 = mc16574;
                                            }
                                            String string = mc16575.getName().getString();
                                            bl3 = kuzi.obf.p.F.c(string);
                                            boolean bl5 = bl;
                                            if (l2 >= 0L) {
                                                if (!bl5) {
                                                    if (bl3 && l2 > 0L) continue block0;
                                                    bl3 = (Boolean)this.ignoreFriends.a();
                                                }
                                                bl5 = bl;
                                            }
                                            if (bl5) break block19;
                                            if (!bl3) break block20;
                                            bl3 = kuzi.obf.p.F.a(string);
                                        }
                                        if (bl3) continue block0;
                                    }
                                    if ((d5 = (double)BaseModule.a.player.distanceTo((Entity)mc16574)) > 5.5) continue block0;
                                    Vec3 eyeToTarget = mc16574.getBoundingBox().getCenter().subtract(eyePos);
                                    double d6 = eyeToTarget.length();
                                    double d7 = d6 - 1.0E-4;
                                    d4 = d7 == 0.0 ? 0 : (d7 < 0.0 ? -1 : 1);
                                    boolean bl6 = bl;
                                    if (l2 >= 0L) {
                                        if (!bl6) {
                                            if (d4 < 0 && l2 >= 0L) continue block0;
                                            double d8 = viewVector.dot(eyeToTarget.scale(1.0 / d6)) - 0.5;
                                            d4 = d8 == 0.0 ? 0 : (d8 < 0.0 ? -1 : 1);
                                        }
                                        bl6 = bl;
                                    }
                                    if (bl6) break block21;
                                    if (d4 < 0 && l2 > 0L) continue block0;
                                    if (l2 <= 0L) break block22;
                                    d3 = d5;
                                    if (bl) break block23;
                                    double d9 = d3 - d2;
                                    d4 = d9 == 0.0 ? 0 : (d9 < 0.0 ? -1 : 1);
                                }
                                if (d4 >= 0) break block24;
                                d3 = d5;
                            }
                            d2 = d3;
                        }
                        mc16573 = mc16574;
                    }
                    bl2 = bl;
                    if (l2 < 0L) continue;
                    if (bl2) break block0;
                    continue block0;
                }
                break;
            }
            mc16572 = mc16573;
        }
        return mc16572;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean f(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = bb ^ l2;
        int n2 = 66;
        if (BaseModule.a.player == null) {
            return false;
        }
        boolean bl = BaseModule.a.player.getMainHandItem().is(ItemTags.SPEARS);
        int n3 = n2;
        if (l2 >= 0L) {
            if (n3 != 0) {
                if (bl) {
                    return true;
                }
                bl = BaseModule.a.player.isUsingItem();
            }
            n3 = n2;
        }
        if (l2 > 0L) {
            if (n3 != 0) {
                if (!bl) return false;
                bl = BaseModule.a.player.getUseItem().is(ItemTags.SPEARS);
            }
            n3 = n2;
        }
        if (n3 == 0) return bl;
        if (!bl) return false;
        return true;
    }

    private boolean g(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = bb ^ l2;
        boolean bl = false;
        return BaseModule.a.player != null && BaseModule.a.player.getItemBySlot(EquipmentSlot.CHEST).is(Items.ELYTRA);
    }

    @Override
    public void a(j j2) {
        long l2 = bb ^ 0x4360F2DFAD4CL;
        long l3 = l2 ^ 0x6D9E804B79ADL;
        int n2 = 66;
        if (BaseModule.a.player == null || BaseModule.a.level == null || BaseModule.a.gameMode == null) {
            return;
        }
        this.ac = false;
        this.ad = false;
        this.ae = false;
        this.switchSlot = -1;
        this.aa = this.Q > 0;
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.o(objectArray);
    }

    @Override
    public void b() {
        long l2;
        long l3 = l2 = bb ^ 0x4C5BCFC1DCBBL;
        long l4 = l3 ^ 0x57B48FD39B41L;
        long l5 = l3 ^ 0x3CCC8621E71L;
        long l6 = l3 ^ 0x1C68F02243B6L;
        long l7 = l3 ^ 0x5CB797E02150L;
        int n2 = 66;
        if (BaseModule.a.player == null || BaseModule.a.level == null || BaseModule.a.gameMode == null) {
            return;
        }
        if (((Boolean)this.spearDoublePop.a()).booleanValue()) {
            Object[] objectArray = new Object[1];
            objectArray[0] = l7;
            this.c(objectArray);
        }
        if (this.ad) {
            Object[] objectArray = new Object[1];
            objectArray[0] = l6;
            this.q(objectArray);
        } else if (this.ae) {
            Object[] objectArray = new Object[1];
            objectArray[0] = l5;
            this.s(objectArray);
        } else if (this.ac) {
            Object[] objectArray = new Object[1];
            objectArray[0] = l4;
            this.u(objectArray);
        }
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public void e() {
        block6: {
            block5: {
                v0 = var1_1 = AutoMace.bb ^ 47023679849372L;
                var3_2 = v0 ^ 50543840698603L;
                var5_3 = v0 ^ 94611695440840L;
                Client.c.b(r.class, this);
                Client.c.b(p.class, this);
                Client.c.b(Module.class, this);
                v1 = new Object[1];
                v1[0] = var5_3;
                this.x(v1);
                var7_4 = 66;
                v2 = new Object[1];
                v2[0] = var3_2;
                this.v(v2);
                ah.c(this);
                this.target = null;
                this.lockedTarget = null;
                this.Q = 0;
                this.R = -1;
                this.savedSlot = -1;
                this.V = 0;
                this.T = 0L;
                v3 = BaseModule.a.player;
                if (var7_4 == 0) ** GOTO lbl29
                if (v3 != null) {
                    v3 = BaseModule.a.player;
lbl29:
                    // 2 sources

                    v4 = v3.getY();
                } else {
                    v4 = 0.0;
                }
                this.W = v4;
                this.ac = false;
                this.ad = false;
                this.ae = false;
                this.switchSlot = -1;
                this.X = 0;
                this.Y = -1;
                this.Z = null;
                this.aa = false;
                this.ab = null;
                v5 = BaseModule.a.options;
                if (var7_4 == 0) break block5;
                if (v5 == null) break block6;
                v5 = BaseModule.a.options;
            }
            v5.keyUse.setDown(false);
        }
    }

    private boolean h(Object[] objectArray) {
        long l2;
        block6: {
            block5: {
                long l3 = (Long)objectArray[0];
                long l4 = l3 = bb ^ l3;
                long l5 = l4 ^ 0x75E6871C907AL;
                l2 = l4 ^ 0x15334C42C790L;
                long l6 = l4 ^ 0x2F85820B8253L;
                int n2 = 66;
                if (BaseModule.a.player == null || this.target == null) {
                    return false;
                }
                if (!a.a.a.p.q.b((Minecraft)BaseModule.a)) {
                    return false;
                }
                Object[] objectArray2 = new Object[1];
                objectArray2[0] = l5;
                double d2 = this.c(objectArray2);
                if (!BaseModule.a.player.hasLineOfSight((Entity)this.target)) break block5;
                Object[] objectArray3 = new Object[3];
                objectArray3[2] = d2;
                objectArray3[1] = l6;
                objectArray3[0] = this.target;
                if (this.t(objectArray3)) break block6;
            }
            return false;
        }
        Object[] objectArray4 = new Object[2];
        objectArray4[1] = l2;
        objectArray4[0] = this.target;
        return this.v(objectArray4);
    }

    private boolean i(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = bb ^ l2;
        return a.a.a.p.q.a((Minecraft)BaseModule.a);
    }

    private boolean j(Object[] objectArray) {
        long l2;
        block16: {
            boolean bl;
            block14: {
                block15: {
                    int n2;
                    int n3;
                    long l3;
                    long l4;
                    long l5;
                    block11: {
                        block12: {
                            long l6;
                            block13: {
                                block9: {
                                    Player mc16572;
                                    block10: {
                                        l5 = (Long)objectArray[0];
                                        long l7 = l5 = bb ^ l5;
                                        l4 = l7 ^ 0x5098A87B5AA7L;
                                        l6 = l7 ^ 0x1D6AF8B38A3CL;
                                        l2 = l7 ^ 0x1CBEA3114357L;
                                        l3 = l7 ^ 0xAFBAD6C488EL;
                                        n3 = 66;
                                        if (BaseModule.a.player == null) break block9;
                                        mc16572 = this.target;
                                        if (l5 <= 0L) break block10;
                                        if (mc16572 == null) break block9;
                                        mc16572 = this.target;
                                    }
                                    bl = mc16572.isAlive();
                                    n2 = n3;
                                    if (l5 <= 0L) break block11;
                                    if (n2 == 0) break block12;
                                    if (bl) break block13;
                                }
                                return false;
                            }
                            Object[] objectArray2 = new Object[2];
                            objectArray2[1] = l6;
                            objectArray2[0] = BaseModule.a;
                            bl = a.a.a.p.q.d((Object[])objectArray2);
                        }
                        n2 = n3;
                    }
                    if (l5 >= 0L) {
                        if (n2 != 0) {
                            if (!bl) {
                                return false;
                            }
                            bl = BaseModule.a.player.hasLineOfSight((Entity)this.target);
                        }
                        n2 = n3;
                    }
                    if (n2 == 0) break block14;
                    if (!bl) break block15;
                    Object[] objectArray3 = new Object[1];
                    objectArray3[0] = l4;
                    Object[] objectArray4 = new Object[3];
                    objectArray4[2] = this.c(objectArray3);
                    objectArray4[1] = l3;
                    objectArray4[0] = this.target;
                    if (this.t(objectArray4)) break block16;
                }
                bl = false;
            }
            return bl;
        }
        Object[] objectArray5 = new Object[4];
        objectArray5[3] = (Boolean)this.ignoreWebs.a() == false;
        objectArray5[2] = l2;
        objectArray5[1] = this.target;
        objectArray5[0] = BaseModule.a;
        return a.a.a.p.q.c((Object[])objectArray5);
    }

    private boolean k(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = bb ^ l2;
        boolean bl = false;
        return a.a.a.p.q.a((Minecraft)BaseModule.a, (Entity)this.target, ((Boolean)this.ignoreWebs.a() == false ? 1 : 0) != 0);
    }

    private boolean l(Object[] objectArray) {
        boolean bl;
        long l2 = (Long)objectArray[0];
        long l3 = (l2 = bb ^ l2) ^ 0x1E37625200A8L;
        int n2 = 66;
        if (((Boolean)this.noAim.a()).booleanValue()) {
            bl = a.a.a.p.q.a((Minecraft)BaseModule.a);
        } else {
            Object[] objectArray2 = new Object[1];
            objectArray2[0] = l3;
            bl = this.k(objectArray2);
        }
        return bl;
    }

    private boolean m(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = bb ^ l2;
        return this.aimMode.a() == kuzi.obf.j.c.e.HORIZONTAL;
    }

    private boolean n(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = (l2 = bb ^ l2) ^ 0x65DFF9BC12FAL;
        boolean bl = false;
        if (((Boolean)this.noAim.a()).booleanValue()) {
            return false;
        }
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l3;
        boolean bl3 = this.m(objectArray2);
        bl3 = bl;
        if (l2 > 0L) {
            if (!bl3) {
                if (!bl2) {
                    return (Double)this.aimRange.a() > 0.0;
                }
                double d2 = (Double)this.aimRange.a() - 0.0;
                bl2 = d2 == 0.0 ? 0 : (d2 > 0.0 ? 1 : -1);
            }
            bl3 = bl;
        }
        if (!bl3) {
            bl2 = bl2 > false || (Double)this.aimInAir.a() > 0.0;
        }
        return bl2;
    }

    /*
     * Exception decompiling
     */
    private void o(Object[] var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Statement already marked as first in another block
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.markFirstStatementInBlock(Op03SimpleStatement.java:461)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc.markWholeBlock(Misc.java:251)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.considerAsSimpleIf(ConditionalRewriter.java:673)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.identifyNonjumpingConditionals(ConditionalRewriter.java:56)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:722)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    private boolean o(Object[] var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * java.lang.UnsupportedOperationException
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.considerAsDoLoopStart(LoopIdentifier.java:383)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.identifyLoops1(LoopIdentifier.java:65)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:681)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private void p(Object[] objectArray) {
        block10: {
            int n2;
            block14: {
                int n3;
                block15: {
                    AutoMace autoMace;
                    int n4;
                    double d2;
                    double d3;
                    block13: {
                        int n5;
                        int n6;
                        long l2;
                        block11: {
                            block12: {
                                double d4;
                                long l3;
                                block9: {
                                    l2 = (Long)objectArray[0];
                                    long l4 = l2 = bb ^ l2;
                                    long l5 = l4 ^ 0x460387CD6FD7L;
                                    l3 = l4 ^ 0x52896CD02D55L;
                                    long l6 = l4 ^ 0x6CCB1876E455L;
                                    long l7 = l4 ^ 0x31FADA4F6D1DL;
                                    long l8 = l4 ^ 0x51F3362C44D0L;
                                    long l9 = l4 ^ 0x22D7CFD72935L;
                                    long l10 = l4 ^ 0x4D4A9D99FB9EL;
                                    Object[] objectArray2 = new Object[1];
                                    objectArray2[0] = l9;
                                    double d5 = this.b(objectArray2);
                                    n6 = 0;
                                    double d6 = (double)BaseModule.a.player.distanceTo((Entity)this.target) - d5;
                                    d4 = d6 == 0.0 ? 0 : (d6 > 0.0 ? 1 : -1);
                                    if (n6 == 0) {
                                        if (d4 > 0) {
                                            Object[] objectArray3 = new Object[1];
                                            objectArray3[0] = l10;
                                            this.x(objectArray3);
                                            this.target = null;
                                            this.Q = 0;
                                            this.R = -1;
                                            return;
                                        }
                                        Object[] objectArray4 = new Object[1];
                                        objectArray4[0] = l5;
                                        d4 = (double)this.n(objectArray4);
                                    }
                                    int n7 = n6;
                                    if (l2 >= 0L) {
                                        if (n7 == 0) {
                                            if (d4 != false) {
                                                Object[] objectArray5 = new Object[2];
                                                objectArray5[1] = l_0.HIGH;
                                                objectArray5[0] = l6;
                                                this.b(objectArray5);
                                            }
                                            Object[] objectArray6 = new Object[1];
                                            objectArray6[0] = l8;
                                            d4 = (double)this.h(objectArray6);
                                        }
                                        n7 = n6;
                                    }
                                    if (n7 != 0) break block9;
                                    if (d4 == false) break block10;
                                    Object[] objectArray7 = new Object[1];
                                    objectArray7[0] = l7;
                                    d4 = this.e(objectArray7);
                                }
                                d3 = d4;
                                Object[] objectArray8 = new Object[1];
                                objectArray8[0] = l3;
                                n3 = this.a(objectArray8);
                                d2 = d3;
                                n4 = -1;
                                n5 = n6;
                                if (l2 < 0L) break block11;
                                if (n5 != 0) break block12;
                                if (d2 == n4) break block10;
                                d2 = n3;
                                n4 = -1;
                            }
                            if (l2 <= 0L) break block13;
                            n5 = n6;
                        }
                        if (n5 != 0) break block13;
                        if (d2 == n4) break block10;
                        autoMace = this;
                        n2 = n6;
                        if (l2 < 0L) break block14;
                        if (n2 != 0) break block15;
                        d2 = autoMace.savedSlot;
                        n4 = -1;
                    }
                    if (d2 == n4) {
                        this.savedSlot = BaseModule.a.player.getInventory().getSelectedSlot();
                    }
                    this.ad = true;
                    this.switchSlot = (int)d3;
                    autoMace = this;
                }
                n2 = n3;
            }
            autoMace.R = n2;
        }
    }

    private void q(Object[] objectArray) {
        block16: {
            int n2;
            block12: {
                block13: {
                    AutoMace autoMace;
                    block15: {
                        long l2;
                        block14: {
                            boolean bl;
                            long l3;
                            long l4;
                            block10: {
                                int n3;
                                long l5;
                                block11: {
                                    block9: {
                                        int n4;
                                        block7: {
                                            block8: {
                                                l4 = (Long)objectArray[0];
                                                long l6 = l4 = bb ^ l4;
                                                l2 = l6 ^ 0x33ABDDFF805L;
                                                long l7 = l6 ^ 0x6477B1BE7468L;
                                                long l8 = l6 ^ 0x734D0AD7259DL;
                                                l5 = l6 ^ 0x5DBDE1FC9BDFL;
                                                l3 = l6 ^ 0x7A381F7ACAF3L;
                                                n3 = 66;
                                                if (this.target == null) {
                                                    return;
                                                }
                                                Object[] objectArray2 = new Object[1];
                                                objectArray2[0] = l8;
                                                bl = this.s(objectArray2);
                                                n4 = n3;
                                                if (l4 < 0L) break block7;
                                                if (n4 == 0) break block8;
                                                if (!bl) break block9;
                                                Object[] objectArray3 = new Object[1];
                                                objectArray3[0] = l7;
                                                bl = this.h(objectArray3);
                                            }
                                            if (l4 < 0L) break block10;
                                            n4 = n3;
                                        }
                                        if (n4 == 0) break block10;
                                        if (bl) break block11;
                                    }
                                    return;
                                }
                                autoMace = this;
                                n2 = n3;
                                if (l4 < 0L) break block12;
                                if (n2 == 0) break block13;
                                Object[] objectArray4 = new Object[1];
                                objectArray4[0] = l5;
                                bl = autoMace.i(objectArray4);
                            }
                            if (!bl) break block14;
                            AutoMace autoMace2 = this;
                            if (l4 >= 0L) {
                                if (l4 >= 0L) {
                                    if (((Boolean)autoMace2.N.a()).booleanValue()) {
                                        Object[] objectArray5 = new Object[1];
                                        objectArray5[0] = l3;
                                        kuzi.obf.p.D.a(objectArray5);
                                    }
                                    AutoMace autoMace3 = this;
                                }
                                autoMace3.Q = 1;
                                autoMace2 = this;
                            }
                            autoMace2.U = System.currentTimeMillis();
                            if (l4 < 0L) break block15;
                            break block16;
                        }
                        Object[] objectArray6 = new Object[1];
                        objectArray6[0] = l2;
                        this.v(objectArray6);
                    }
                    autoMace = this;
                }
                n2 = -1;
            }
            autoMace.R = n2;
        }
    }

    private void r(Object[] objectArray) {
        block22: {
            int n2;
            block23: {
                block24: {
                    AutoMace autoMace;
                    double d2;
                    block20: {
                        int n3;
                        long l2;
                        long l3;
                        block21: {
                            int n4;
                            long l4;
                            long l5;
                            block19: {
                                block18: {
                                    AutoMace autoMace2;
                                    long l6;
                                    block17: {
                                        double d3;
                                        block15: {
                                            long l7;
                                            block16: {
                                                block14: {
                                                    AutoMace autoMace3;
                                                    block11: {
                                                        AutoMace autoMace4;
                                                        long l8;
                                                        block12: {
                                                            block13: {
                                                                l3 = (Long)objectArray[0];
                                                                long l9 = l3 = bb ^ l3;
                                                                l7 = l9 ^ 0x771CCA331C27L;
                                                                l6 = l9 ^ 0x5DD4558897A5L;
                                                                l5 = l9 ^ 0x7A177B3BB4DL;
                                                                long l10 = l9 ^ 0x13C882295AC5L;
                                                                l2 = l9 ^ 0x459254B5FDFDL;
                                                                l4 = l9 ^ 0x7C55D067886EL;
                                                                Object[] objectArray2 = new Object[1];
                                                                objectArray2[0] = l10;
                                                                double d4 = this.b(objectArray2);
                                                                n3 = 66;
                                                                autoMace3 = this;
                                                                if (n3 == 0) break block11;
                                                                l8 = -2565982998537884183L;
                                                                if (l3 < 0L) break block12;
                                                                if (autoMace3.target == null) break block13;
                                                                if (l3 < 0L) break block14;
                                                                autoMace3 = this;
                                                                if (n3 == 0) break block11;
                                                                l8 = -2565982998537884183L;
                                                                if (l3 <= 0L) break block12;
                                                                if (!autoMace3.target.isAlive()) break block13;
                                                                double d5 = (double)BaseModule.a.player.distanceTo((Entity)this.target) - d4;
                                                                d3 = d5 == 0.0 ? 0 : (d5 > 0.0 ? 1 : -1);
                                                                if (n3 == 0) break block15;
                                                                if (d3 <= 0) break block16;
                                                            }
                                                            autoMace4 = this;
                                                            l8 = l5;
                                                        }
                                                        Object[] objectArray3 = new Object[1];
                                                        objectArray3[0] = l8;
                                                        autoMace4.v(objectArray3);
                                                        this.Q = 0;
                                                        this.R = -1;
                                                        autoMace3 = this;
                                                    }
                                                    Object[] objectArray4 = new Object[1];
                                                    objectArray4[0] = l4;
                                                    autoMace3.x(objectArray4);
                                                }
                                                return;
                                            }
                                            autoMace2 = this;
                                            if (n3 == 0) break block17;
                                            Object[] objectArray5 = new Object[1];
                                            objectArray5[0] = l7;
                                            d3 = (double)autoMace2.n(objectArray5);
                                        }
                                        if (d3 == false) break block18;
                                        autoMace2 = this;
                                    }
                                    Object[] objectArray6 = new Object[2];
                                    objectArray6[1] = l_0.HIGHEST;
                                    objectArray6[0] = l6;
                                    autoMace2.b(objectArray6);
                                }
                                long l11 = System.currentTimeMillis() - this.U;
                                double d6 = (double)l11 - (Double)this.maceSwapDelay.a();
                                d2 = d6 == 0.0 ? 0 : (d6 < 0.0 ? -1 : 1);
                                n4 = n3;
                                if (l3 < 0L) break block19;
                                if (n4 != 0) {
                                    if (d2 < 0) {
                                        return;
                                    }
                                    long l12 = l11 - mb;
                                    d2 = l12 == 0L ? 0 : (l12 < 0L ? -1 : 1);
                                }
                                if (l3 <= 0L) break block20;
                                n4 = n3;
                            }
                            if (n4 == 0) break block20;
                            if (d2 <= 0) break block21;
                            Object[] objectArray7 = new Object[1];
                            objectArray7[0] = l5;
                            this.v(objectArray7);
                            this.Q = 0;
                            this.R = -1;
                            Object[] objectArray8 = new Object[1];
                            objectArray8[0] = l4;
                            this.x(objectArray8);
                            if (n3 != 0) break block22;
                        }
                        autoMace = this;
                        n2 = n3;
                        if (l3 <= 0L) break block23;
                        if (n2 == 0) break block24;
                        Object[] objectArray9 = new Object[1];
                        objectArray9[0] = l2;
                        d2 = (double)autoMace.j(objectArray9);
                    }
                    if (d2 == false) break block22;
                    this.ae = true;
                    autoMace = this;
                }
                n2 = this.R;
            }
            autoMace.switchSlot = n2;
        }
    }

    private void s(Object[] objectArray) {
        block13: {
            int n2;
            block9: {
                block10: {
                    AutoMace autoMace;
                    block12: {
                        long l2;
                        block11: {
                            boolean bl;
                            long l3;
                            long l4;
                            block7: {
                                int n3;
                                long l5;
                                block8: {
                                    block6: {
                                        l4 = (Long)objectArray[0];
                                        long l6 = l4 = bb ^ l4;
                                        l2 = l6 ^ 0x1C9E859FA5C2L;
                                        l5 = l6 ^ 0x7B8198713853L;
                                        long l7 = l6 ^ 0x6CE93297785AL;
                                        long l8 = l6 ^ 0x5EADA699E372L;
                                        l3 = l6 ^ 0x659C273A9734L;
                                        n3 = 0;
                                        Object[] objectArray2 = new Object[1];
                                        objectArray2[0] = l7;
                                        if (!this.s(objectArray2)) break block6;
                                        Object[] objectArray3 = new Object[1];
                                        objectArray3[0] = l8;
                                        bl = this.j(objectArray3);
                                        if (l4 <= 0L) break block7;
                                        if (bl) break block8;
                                    }
                                    return;
                                }
                                autoMace = this;
                                n2 = n3;
                                if (l4 <= 0L) break block9;
                                if (n2 != 0) break block10;
                                Object[] objectArray4 = new Object[1];
                                objectArray4[0] = l5;
                                bl = autoMace.l(objectArray4);
                            }
                            if (!bl) break block11;
                            AutoMace autoMace2 = this;
                            if (l4 > 0L) {
                                if (l4 >= 0L) {
                                    if (((Boolean)autoMace2.N.a()).booleanValue()) {
                                        Object[] objectArray5 = new Object[1];
                                        objectArray5[0] = l3;
                                        kuzi.obf.p.D.a(objectArray5);
                                    }
                                    this.Q = 0;
                                    AutoMace autoMace3 = this;
                                }
                                autoMace3.V = (int)AutoMace.c("b", (int)19867, (long)(0x2527398F26BF4EE7L ^ l4));
                                autoMace2 = this;
                            }
                            autoMace2.T = System.currentTimeMillis();
                            if (l4 < 0L) break block12;
                            break block13;
                        }
                        Object[] objectArray6 = new Object[1];
                        objectArray6[0] = l2;
                        this.v(objectArray6);
                        this.Q = 0;
                    }
                    autoMace = this;
                }
                n2 = -1;
            }
            autoMace.R = n2;
        }
    }

    private void t(Object[] objectArray) {
        block17: {
            int n2;
            block19: {
                double d2;
                block20: {
                    AutoMace autoMace;
                    int n3;
                    double d3;
                    block18: {
                        double d4;
                        int n4;
                        long l2;
                        block16: {
                            int n5;
                            long l3;
                            long l4;
                            long l5;
                            block13: {
                                block14: {
                                    long l6;
                                    block15: {
                                        block12: {
                                            AutoMace autoMace2;
                                            long l7;
                                            block10: {
                                                block11: {
                                                    l2 = (Long)objectArray[0];
                                                    long l8 = l2 = bb ^ l2;
                                                    l6 = l8 ^ 0x1071D69106A7L;
                                                    l5 = l8 ^ 0x4FB3D8C4425L;
                                                    l4 = l8 ^ 0x3AB9492A8D25L;
                                                    long l9 = l8 ^ 0x74A59E8B4045L;
                                                    l3 = l8 ^ 0x22FF4817E77DL;
                                                    l7 = l8 ^ 0x1B38CCC592EEL;
                                                    Object[] objectArray2 = new Object[1];
                                                    objectArray2[0] = l9;
                                                    double d5 = this.b(objectArray2);
                                                    n4 = 0;
                                                    autoMace2 = this;
                                                    if (n4 != 0) break block10;
                                                    if (autoMace2.target == null) break block11;
                                                    if (l2 <= 0L) break block12;
                                                    autoMace2 = this;
                                                    if (n4 != 0) break block10;
                                                    if (!autoMace2.target.isAlive()) break block11;
                                                    double d6 = (double)BaseModule.a.player.distanceTo((Entity)this.target) - d5;
                                                    d4 = d6 == 0.0 ? 0 : (d6 > 0.0 ? 1 : -1);
                                                    n5 = n4;
                                                    if (l2 < 0L) break block13;
                                                    if (n5 != 0) break block14;
                                                    if (d4 <= 0) break block15;
                                                }
                                                autoMace2 = this;
                                            }
                                            Object[] objectArray3 = new Object[1];
                                            objectArray3[0] = l7;
                                            autoMace2.x(objectArray3);
                                        }
                                        return;
                                    }
                                    Object[] objectArray4 = new Object[1];
                                    objectArray4[0] = l6;
                                    d4 = (double)this.n(objectArray4);
                                }
                                n5 = n4;
                            }
                            if (l2 > 0L) {
                                if (n5 == 0) {
                                    if (d4 != false) {
                                        Object[] objectArray5 = new Object[2];
                                        objectArray5[1] = l_0.HIGH;
                                        objectArray5[0] = l4;
                                        this.b(objectArray5);
                                    }
                                    Object[] objectArray6 = new Object[1];
                                    objectArray6[0] = l3;
                                    d4 = (double)this.j(objectArray6);
                                }
                                n5 = n4;
                            }
                            if (n5 != 0) break block16;
                            if (d4 == false) break block17;
                            Object[] objectArray7 = new Object[1];
                            objectArray7[0] = l5;
                            d4 = this.a(objectArray7);
                        }
                        d3 = d2 = d4;
                        n3 = -1;
                        if (l2 < 0L || n4 != 0) break block18;
                        if (d3 == n3) break block17;
                        autoMace = this;
                        n2 = n4;
                        if (l2 < 0L) break block19;
                        if (n2 != 0) break block20;
                        d3 = autoMace.savedSlot;
                        n3 = -1;
                    }
                    if (d3 == n3) {
                        this.savedSlot = BaseModule.a.player.getInventory().getSelectedSlot();
                    }
                    this.ac = true;
                    autoMace = this;
                }
                n2 = d2;
            }
            autoMace.switchSlot = n2;
        }
    }

    private void u(Object[] objectArray) {
        block12: {
            AutoMace autoMace;
            long l2;
            block11: {
                block9: {
                    Object object;
                    block10: {
                        boolean bl;
                        int n2;
                        long l3;
                        long l4;
                        block7: {
                            long l5;
                            block8: {
                                block6: {
                                    l4 = (Long)objectArray[0];
                                    long l6 = l4 = bb ^ l4;
                                    l2 = l6 ^ 0x48E6C22E20F2L;
                                    l5 = l6 ^ 0x2FF9DFC0BD63L;
                                    long l7 = l6 ^ 0x38917526FD6AL;
                                    long l8 = l6 ^ 0xAD5E1286642L;
                                    l3 = l6 ^ 0x31E4608B1204L;
                                    n2 = 0;
                                    Object[] objectArray2 = new Object[1];
                                    objectArray2[0] = l7;
                                    if (!this.s(objectArray2)) break block6;
                                    Object[] objectArray3 = new Object[1];
                                    objectArray3[0] = l8;
                                    bl = this.j(objectArray3);
                                    if (l4 <= 0L) break block7;
                                    if (bl) break block8;
                                }
                                return;
                            }
                            Object[] objectArray4 = new Object[1];
                            objectArray4[0] = l5;
                            bl = this.l(objectArray4);
                        }
                        if (!bl) break block9;
                        autoMace = this;
                        object = n2;
                        if (l4 < 0L) break block10;
                        if (object == 0) {
                            long l9 = 5175460892587033062L;
                            long l10 = l4;
                            if (l4 >= 0L) {
                                if (((Boolean)autoMace.N.a()).booleanValue()) {
                                    Object[] objectArray5 = new Object[1];
                                    objectArray5[0] = l3;
                                    kuzi.obf.p.D.a(objectArray5);
                                }
                                AutoMace autoMace2 = this;
                                l9 = System.currentTimeMillis();
                                l10 = 5175337777621888869L;
                            }
                            autoMace2.T = l9;
                            autoMace = this;
                        }
                        if (l4 < 0L) break block11;
                        object = AutoMace.c("b", (int)25625, (long)(0x1DC54551D562E251L ^ l4));
                    }
                    autoMace.V = object;
                    break block12;
                }
                autoMace = this;
            }
            Object[] objectArray6 = new Object[1];
            objectArray6[0] = l2;
            autoMace.v(objectArray6);
        }
    }

    private void v(Object[] objectArray) {
        int n2;
        block5: {
            block6: {
                AutoMace autoMace;
                block4: {
                    long l2 = (Long)objectArray[0];
                    l2 = bb ^ l2;
                    int n3 = 66;
                    if (!((Boolean)this.swapBack.a()).booleanValue() || !((Boolean)this.autoSwitch.a()).booleanValue() || this.savedSlot < 0) break block4;
                    autoMace = this;
                    n2 = n3;
                    if (l2 < 0L) break block5;
                    if (n2 == 0) break block6;
                    if (autoMace.savedSlot < AutoMace.c("b", (int)12653, (long)(0x146BD863C5793AAL ^ l2))) {
                        BaseModule.a.player.getInventory().setSelectedSlot(this.savedSlot);
                    }
                }
                autoMace = this;
            }
            n2 = -1;
        }
        autoMace.savedSlot = n2;
    }

    private void w(Object[] objectArray) {
        block8: {
            AutoMace autoMace;
            long l2;
            block7: {
                int n2;
                long l3;
                block6: {
                    boolean bl;
                    block4: {
                        block5: {
                            long l4 = (Long)objectArray[0];
                            long l5 = l4 = bb ^ l4;
                            long l6 = l5 ^ 0xA612D4A06EDL;
                            long l7 = l5 ^ 0x20A9B2F18D6FL;
                            l3 = l5 ^ 0x7ADC90CAA187L;
                            long l8 = l5 ^ 0x6EB56550400FL;
                            l2 = l5 ^ 0x128371E92A4L;
                            --this.V;
                            bl = false;
                            Object[] objectArray2 = new Object[1];
                            objectArray2[0] = l8;
                            double d2 = this.b(objectArray2);
                            autoMace = this;
                            if (bl) break block4;
                            if (autoMace.target == null) break block5;
                            n2 = this.target.isAlive() ? 1 : 0;
                            if (bl) break block6;
                            if (n2 == 0) break block5;
                            double d3 = (double)BaseModule.a.player.distanceTo((Entity)this.target) - d2;
                            n2 = d3 == 0.0 ? 0 : (d3 < 0.0 ? -1 : 1);
                            if (bl) break block6;
                            if (n2 > 0) break block5;
                            Object[] objectArray3 = new Object[1];
                            objectArray3[0] = l6;
                            n2 = this.n(objectArray3) ? 1 : 0;
                            if (l4 <= 0L || bl) break block6;
                            if (n2 != 0) {
                                Object[] objectArray4 = new Object[2];
                                objectArray4[1] = l_0.HIGH;
                                objectArray4[0] = l7;
                                this.b(objectArray4);
                            }
                        }
                        autoMace = this;
                    }
                    if (bl) break block7;
                    n2 = autoMace.V;
                }
                if (n2 > 0) break block8;
                Object[] objectArray5 = new Object[1];
                objectArray5[0] = l3;
                this.v(objectArray5);
                autoMace = this;
            }
            Object[] objectArray6 = new Object[1];
            objectArray6[0] = l2;
            autoMace.x(objectArray6);
        }
    }

    private boolean p(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = bb ^ l2;
        boolean bl = false;
        if (BaseModule.a.player == null) {
            return false;
        }
        ItemStack mc17992 = BaseModule.a.player.getMainHandItem();
        return mc17992.getItem() instanceof MaceItem || kuzi.obf.p.K.a(mc17992) || mc17992.getItem() instanceof AxeItem;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean d(Object[] objectArray) {
        Player mc16572 = (Player)objectArray[0];
        long l2 = (Long)objectArray[1];
        l2 = bb ^ l2;
        int n2 = 66;
        if (mc16572 == null) {
            return false;
        }
        boolean bl = mc16572.isBlocking();
        if (l2 >= 0L) {
            if (bl) {
                return true;
            }
            bl = mc16572.isUsingItem();
        }
        if (l2 < 0L) return bl;
        if (!bl) {
            return false;
        }
        ItemStack mc17992 = mc16572.getUseItem();
        boolean bl2 = mc17992.isEmpty();
        int n3 = n2;
        if (l2 > 0L) {
            if (n3 != 0) {
                if (bl2) return false;
                bl2 = mc17992.is(Items.SHIELD);
            }
            n3 = n2;
        }
        if (n3 == 0) return bl2;
        if (!bl2) return false;
        return true;
    }

    private boolean q(Object[] objectArray) {
        double d2;
        Player mc16572 = (Player)objectArray[0];
        long l2 = (Long)objectArray[1];
        l2 = bb ^ l2;
        int n2 = 66;
        if (BaseModule.a.player == null || mc16572 == null || !BaseModule.a.player.hasLineOfSight((Entity)mc16572)) {
            return false;
        }
        Vec3 eyePos = BaseModule.a.player.getEyePosition();
        Vec3 targetCenter = mc16572.getBoundingBox().getCenter();
        double d3 = targetCenter.x - eyePos.x;
        double d4 = targetCenter.z - eyePos.z;
        double d5 = d3 * d3 + d4 * d4;
        if (l2 > 0L) {
            if (d5 <= 1.0E-6) {
                return true;
            }
            d5 = Math.toDegrees(Math.atan2(d4, d3));
        }
        float f2 = (float)d5 - 90.0f;
        float f3 = Math.abs(Mth.wrapDegrees((float)(BaseModule.a.player.getYRot() - f2)));
        return (double)f3 <= (d2 = Mth.clamp((double)((Integer)BaseModule.a.options.fov().get()).intValue(), (double)30.0, (double)170.0)) * 0.5;
    }

    private int a(Object[] objectArray) {
        int n2;
        block7: {
            long l2 = (Long)objectArray[0];
            long l3 = l2 = bb ^ l2;
            long l4 = l3 ^ 0x653BF343ADB8L;
            long l5 = l3 ^ 0x257066A9A73EL;
            Object[] objectArray2 = new Object[1];
            objectArray2[0] = l5;
            int n3 = this.d(objectArray2);
            int n4 = 66;
            int n5 = n3;
            if (n4 != 0) {
                if (n5 != -1) {
                    return n3;
                }
                n5 = -1;
            }
            int n6 = n5;
            int n7 = -1;
            int n8 = 0;
            while (n8 < AutoMace.c("b", (int)16753, (long)(0x1430AF2C5B768648L ^ l2))) {
                int n9;
                block11: {
                    block9: {
                        block10: {
                            ItemStack mc17992;
                            block8: {
                                mc17992 = BaseModule.a.player.getInventory().getItem(n8);
                                n2 = n4;
                                if (l2 <= 0L) break block8;
                                if (n2 == 0) break block9;
                                n2 = mc17992.getItem() instanceof MaceItem;
                            }
                            if (n4 == 0) break block7;
                            if (n2 == 0) break block10;
                            Object[] objectArray3 = new Object[3];
                            objectArray3[2] = AutoMace.b("m", (int)16515, (long)(0x16EF06B4CF698790L ^ l2));
                            objectArray3[1] = mc17992;
                            objectArray3[0] = l4;
                            int n10 = this.c(objectArray3);
                            n9 = n4;
                            if (l2 < 0L) break block11;
                            if (n9 == 0) break block9;
                            if (n10 > n7) {
                                n7 = n10;
                                n6 = n8;
                            }
                        }
                        ++n8;
                    }
                    n9 = n4;
                }
                if (n9 != 0) continue;
            }
            n2 = n6;
        }
        return n2;
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private int c(Object[] var1_1) {
        block25: {
            block23: {
                block24: {
                    block21: {
                        block22: {
                            var4_2 = (Long)var1_1[0];
                            var2_3 = (ItemStack)var1_1[1];
                            var3_4 = (String)var1_1[2];
                            var4_2 = AutoMace.bb ^ var4_2;
                            var6_5 = kuzi.obf.j.c.n.c();
                            try {
                                try {
                                    v0 /* !! */  = var2_3;
                                    if (var6_5 == false) break block21;
                                    if (!v0 /* !! */ .isEmpty()) break block22;
                                }
                                catch (IndexOutOfBoundsException v1) {
                                    throw AutoMace.a(v1);
                                }
                                return 0;
                            }
                            catch (IndexOutOfBoundsException v2) {
                                throw AutoMace.a(v2);
                            }
                        }
                        v0 /* !! */  = var2_3.get(DataComponents.ENCHANTMENTS);
                    }
                    var7_6 = (ItemEnchantments)v0 /* !! */ ;
                    try {
                        try {
                            v3 = var7_6;
                            if (var6_5 == false) break block23;
                            if (v3 != null) break block24;
                        }
                        catch (IndexOutOfBoundsException v4) {
                            throw AutoMace.a(v4);
                        }
                        return 0;
                    }
                    catch (IndexOutOfBoundsException v5) {
                        throw AutoMace.a(v5);
                    }
                }
                v3 = var7_6;
            }
            for (Holder var9_8 : v3.keySet()) {
                block27: {
                    block28: {
                        block29: {
                            block26: {
                                try {
                                    try {
                                        try {
                                            v6 = (int)var9_8.unwrapKey().isPresent();
                                            v7 = var6_5;
                                            if (var4_2 > 0L) {
                                                if (v7 == false) break block25;
                                                v7 = var6_5;
                                            }
                                            if (var4_2 >= 0L) {
                                                if (v7 == false) break block26;
                                            }
                                            ** GOTO lbl64
                                        }
                                        catch (IndexOutOfBoundsException v8) {
                                            throw AutoMace.a(v8);
                                        }
                                        if (var4_2 < 0L) break block27;
                                        if (v6 == 0) break block28;
                                    }
                                    catch (IndexOutOfBoundsException v9) {
                                        throw AutoMace.a(v9);
                                    }
                                    v10 = (int)((ResourceKey)var9_8.unwrapKey().get()).identifier().getPath().contains(var3_4);
                                }
                                catch (IndexOutOfBoundsException v11) {
                                    throw AutoMace.a(v11);
                                }
                            }
                            try {
                                try {
                                    v7 = var6_5;
lbl64:
                                    // 2 sources

                                    if (v7 == false) break block29;
                                    if (v10 == false) break block28;
                                }
                                catch (IndexOutOfBoundsException v12) {
                                    throw AutoMace.a(v12);
                                }
                                v10 = var7_6.getLevel(var9_8);
                            }
                            catch (IndexOutOfBoundsException v13) {
                                throw AutoMace.a(v13);
                            }
                        }
                        return v10;
                    }
                    v14 = var6_5;
                }
                if (v14 != false) continue;
            }
            v6 = 0;
        }
        return v6;
    }

    /*
     * Enabled aggressive block sorting
     */
    private int d(Object[] objectArray) {
        float f2;
        block31: {
            int n2;
            int n3;
            block29: {
                int n4;
                block30: {
                    long l2;
                    long l3;
                    block28: {
                        int n5;
                        int n6;
                        block21: {
                            block22: {
                                LocalPlayer mc7462;
                                long l4;
                                block24: {
                                    int n7;
                                    block23: {
                                        l3 = (Long)objectArray[0];
                                        long l5 = l3 = bb ^ l3;
                                        l4 = l5 ^ 0x147EBDC60EF9L;
                                        l2 = l5 ^ 0x7FA94117474AL;
                                        n4 = 0;
                                        if (!((Boolean)this.breachHealthCheck.a()).booleanValue()) {
                                            return -1;
                                        }
                                        mc7462 = BaseModule.a.player;
                                        n7 = n4;
                                        if (l3 < 0L) break block23;
                                        if (n7 == 0) {
                                            if (mc7462 == null) return -1;
                                            mc7462 = this.target;
                                        }
                                        if (l3 <= 0L) break block24;
                                        n7 = n4;
                                    }
                                    if (n7 == 0) {
                                        if (mc7462 == null) return -1;
                                        mc7462 = this.target;
                                    }
                                }
                                if (!mc7462.isAlive()) {
                                    return -1;
                                }
                                n3 = -1;
                                int n8 = 0;
                                int n9 = 0;
                                while (n9 < AutoMace.c("b", (int)12653, (long)(0x146A8F4244FD503L ^ l3))) {
                                    int n10;
                                    block26: {
                                        block27: {
                                            block25: {
                                                ItemStack mc17992 = BaseModule.a.player.getInventory().getItem(n9);
                                                n6 = mc17992.getItem() instanceof MaceItem;
                                                n5 = n4;
                                                if (l3 < 0L) break block21;
                                                if (n5 != 0) break block22;
                                                if (n6 == 0 && l3 > 0L) break block25;
                                                Object[] objectArray2 = new Object[3];
                                                objectArray2[2] = AutoMace.b("m", (int)30294, (long)(0x1F52F65E42961208L ^ l3));
                                                objectArray2[1] = mc17992;
                                                objectArray2[0] = l4;
                                                int n11 = this.c(objectArray2);
                                                n10 = n4;
                                                if (l3 <= 0L) break block26;
                                                if (n10 != 0) break block27;
                                                if (n11 > n8) {
                                                    n8 = n11;
                                                    n3 = n9;
                                                }
                                            }
                                            ++n9;
                                        }
                                        n10 = n4;
                                    }
                                    if (n10 == 0) continue;
                                }
                                if (l3 < 0L) break block28;
                                n6 = n3;
                            }
                            n5 = n4;
                        }
                        if (l3 > 0L) {
                            if (n5 != 0) return n6;
                            n5 = -1;
                        }
                        if (n6 == n5) {
                            return -1;
                        }
                    }
                    Object[] objectArray3 = new Object[3];
                    objectArray3[2] = l2;
                    objectArray3[1] = this.target;
                    objectArray3[0] = BaseModule.a.player.getInventory().getItem(n3);
                    float f3 = this.a(objectArray3);
                    float f4 = f3 - 0.0f;
                    f2 = f4 == 0.0f ? 0 : (f4 > 0.0f ? 1 : -1);
                    n2 = n4;
                    if (l3 < 0L) break block29;
                    if (n2 != 0) break block30;
                    if (f2 <= 0) break block31;
                    float f5 = f3 - (this.target.getHealth() + this.target.getAbsorptionAmount());
                    f2 = f5 == 0.0f ? 0 : (f5 > 0.0f ? 1 : -1);
                }
                n2 = n4;
            }
            if (n2 != 0) return (int)f2;
            if (f2 >= 0) {
                f2 = n3;
                return (int)f2;
            }
        }
        f2 = -1;
        return (int)f2;
    }

    /*
     * Unable to fully structure code
     */
    private float a(Object[] var1_1) {
        var2_2 = (ItemStack)var1_1[0];
        var3_3 = (Player)var1_1[1];
        var4_4 = (Long)var1_1[2];
        v0 = var4_4 = AutoMace.bb ^ var4_4;
        var6_5 = v0 ^ 70243468529100L;
        var8_6 = v0 ^ 136510559910248L;
        var10_7 = v0 ^ 25098708635143L;
        var12_8 = v0 ^ 34102610276341L;
        var23_9 = var3_3.getEffect(MobEffects.RESISTANCE);
        var22_10 = false;
        v1 = new Object[1];
        v1[0] = var8_6;
        v2 = this.a(v1);
        v3 = new Object[3];
        v3[2] = AutoMace.b("m", (int)22417, (long)(7062989025948922089L ^ var4_4));
        v3[1] = var2_2;
        v3[0] = var6_5;
        v4 = this.c(v3);
        v5 = new Object[3];
        v5[2] = AutoMace.b("m", (int)14691, (long)(4883747168421223958L ^ var4_4));
        v5[1] = var2_2;
        v5[0] = var6_5;
        v6 = this.c(v5);
        v7 = ((Double)this.strength.a()).intValue();
        v8 = BaseModule.a.player.getAttackStrengthScale(0.5f);
        v9 = new Object[1];
        v9[0] = var12_8;
        v10 = this.r(v9);
        v11 = var3_3.getArmorValue();
        v12 = (float)var3_3.getAttributeValue(Attributes.ARMOR_TOUGHNESS);
        v13 = ((Double)this.targetProtection.a()).intValue();
        v14 = var23_9;
        if (var22_10) ** GOTO lbl44
        if (v14 == null) {
            v15 = 0;
        } else {
            v14 = var23_9;
lbl44:
            // 2 sources

            v15 = v14.getAmplifier() + 1;
        }
        var14_11 = v15;
        var15_12 = v13;
        var16_13 = v12;
        var17_14 = v11;
        var18_15 = v10;
        var19_16 = v8;
        var20_17 = v7;
        var21_18 = v6;
        v16 = new Object[11];
        v16[10] = var14_11;
        v16[9] = var15_12;
        v16[8] = Float.valueOf(var16_13);
        v16[7] = Float.valueOf(var17_14);
        v16[6] = var18_15;
        v16[5] = Float.valueOf(var19_16);
        v16[4] = var20_17;
        v16[3] = var21_18;
        v16[2] = var10_7;
        v16[1] = v4;
        v16[0] = v2;
        return AutoMace.b(v16);
    }

    static float b(Object[] objectArray) {
        float f2;
        float f3;
        int n2;
        int n3;
        int n4;
        long l2;
        block23: {
            float f4;
            float f5;
            boolean bl;
            block22: {
                double d2;
                CallSite callSite;
                int n5;
                double d3;
                block19: {
                    double d4;
                    double d5;
                    double d6;
                    block20: {
                        block21: {
                            double d7;
                            block17: {
                                block18: {
                                    d3 = (Double)objectArray[0];
                                    n5 = (Integer)objectArray[1];
                                    l2 = (Long)objectArray[2];
                                    n4 = (Integer)objectArray[3];
                                    int n6 = (Integer)objectArray[4];
                                    float f6 = ((Float)objectArray[5]).floatValue();
                                    bl = (Boolean)objectArray[6];
                                    f5 = ((Float)objectArray[7]).floatValue();
                                    f4 = ((Float)objectArray[8]).floatValue();
                                    n3 = (Integer)objectArray[9];
                                    n2 = (Integer)objectArray[10];
                                    l2 = bb ^ l2;
                                    callSite = kuzi.obf.j.c.n.b();
                                    try {
                                        if (d3 <= 1.5) {
                                            return 0.0f;
                                        }
                                    }
                                    catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                                        throw AutoMace.a(indexOutOfBoundsException);
                                    }
                                    f3 = (6.0f + 3.0f * (float)n6) * (0.2f + Mth.square((float)f6) * 0.8f);
                                    try {
                                        try {
                                            double d8 = d3 - 3.0;
                                            d7 = d8 == 0.0 ? 0 : (d8 < 0.0 ? -1 : 1);
                                            if (l2 <= 0L || callSite != false) break block17;
                                            if (d7 > 0) break block18;
                                        }
                                        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                                            throw AutoMace.a(indexOutOfBoundsException);
                                        }
                                        d6 = 4.0 * d3;
                                        break block19;
                                    }
                                    catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                                        throw AutoMace.a(indexOutOfBoundsException);
                                    }
                                }
                                try {
                                    d5 = d3;
                                    d4 = 8.0;
                                    if (callSite != false) break block20;
                                    double d9 = d5 - d4;
                                    d7 = d9 == 0.0 ? 0 : (d9 < 0.0 ? -1 : 1);
                                }
                                catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                                    throw AutoMace.a(indexOutOfBoundsException);
                                }
                            }
                            try {
                                if (d7 > 0) break block21;
                                d6 = 12.0 + 2.0 * (d3 - 3.0);
                                break block19;
                            }
                            catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                                throw AutoMace.a(indexOutOfBoundsException);
                            }
                        }
                        d5 = 22.0;
                        d4 = d3 - 8.0;
                    }
                    d6 = d2 = d5 + d4;
                }
                if (l2 <= 0L) break block22;
                f2 = f3 + (float)(d2 + 0.5 * (double)n5 * d3);
                if (callSite != false) break block23;
                f3 = f2;
            }
            if (bl) {
                f3 *= 1.5f;
            }
            f2 = Mth.clamp((float)(f5 - f3 / (2.0f + f4 / 4.0f)), (float)(f5 * 0.2f), (float)20.0f);
        }
        float f7 = f2;
        float f8 = Mth.clamp((float)(f7 / 25.0f - 0.15f * (float)n4), (float)0.0f, (float)1.0f);
        float f9 = f3 * (1.0f - f8);
        if (n2 > 0) {
            f9 = Math.max(f9 * (float)(AutoMace.c("b", (int)27910, (long)(0xFCD088647F90032L ^ l2)) - Math.min(n2, 5) * 5) / 25.0f, 0.0f);
        }
        return f9 * (1.0f - Mth.clamp((float)(4.0f * (float)n3), (float)0.0f, (float)20.0f) / 25.0f);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean r(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = bb ^ l2;
        boolean bl = false;
        if (!(BaseModule.a.player.getAttackStrengthScale(0.5f) > 0.9f)) return 0 != 0;
        double d2 = BaseModule.a.player.fallDistance - 0.0;
        int n2 = d2 == 0.0 ? 0 : (d2 > 0.0 ? 1 : -1);
        boolean bl2 = bl;
        if (l2 > 0L) {
            if (!bl2) {
                if (n2 <= 0) return 0 != 0;
                n2 = BaseModule.a.player.onGround() ? 1 : 0;
            }
            bl2 = bl;
        }
        if (l2 >= 0L) {
            if (!bl2) {
                if (n2 != 0) return 0 != 0;
                n2 = BaseModule.a.player.onClimbable() ? 1 : 0;
            }
            bl2 = bl;
        }
        if (l2 >= 0L) {
            if (!bl2) {
                if (n2 != 0) return 0 != 0;
                n2 = BaseModule.a.player.isInWater() ? 1 : 0;
            }
            bl2 = bl;
        }
        if (l2 >= 0L) {
            if (!bl2) {
                if (n2 != 0) return 0 != 0;
                n2 = BaseModule.a.player.hasEffect(MobEffects.BLINDNESS) ? 1 : 0;
            }
            bl2 = bl;
        }
        if (l2 > 0L) {
            if (!bl2) {
                if (n2 != 0) return 0 != 0;
                n2 = BaseModule.a.player.isPassenger() ? 1 : 0;
            }
            bl2 = bl;
        }
        if (l2 >= 0L) {
            if (!bl2) {
                if (n2 != 0) return 0 != 0;
                n2 = BaseModule.a.player.isSprinting() ? 1 : 0;
            }
            bl2 = bl;
        }
        if (bl2) return n2 != 0;
        if (n2 != 0) return 0 != 0;
        return 1 != 0;
    }

    /*
     * Exception decompiling
     */
    private int e(Object[] var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * java.lang.UnsupportedOperationException
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.considerAsDoLoopStart(LoopIdentifier.java:383)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.identifyLoops1(LoopIdentifier.java:65)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:681)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private void x(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = bb ^ l2;
        ah.c(this);
        this.target = null;
        this.Q = 0;
        this.ac = false;
        this.ad = false;
        this.ae = false;
        this.switchSlot = -1;
        this.R = -1;
    }

    private boolean s(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = bb ^ l2;
        boolean bl = false;
        if (BaseModule.a.player == null) {
            return false;
        }
        if (((Boolean)this.autoSwitch.a()).booleanValue() && this.switchSlot >= 0 && this.switchSlot <= AutoMace.c("b", (int)19867, (long)(0x252701533C0432C2L ^ l2)) && BaseModule.a.player.getInventory().getSelectedSlot() != this.switchSlot) {
            BaseModule.a.player.getInventory().setSelectedSlot(this.switchSlot);
            if (BaseModule.a.gameMode != null) {
                ((n_0)BaseModule.a.gameMode).syncSlot();
            }
        }
        return true;
    }

    private boolean t(Object[] objectArray) {
        Entity mc12972 = (Entity)objectArray[0];
        long l2 = (Long)objectArray[1];
        double d2 = (Double)objectArray[2];
        l2 = bb ^ l2;
        boolean bl = false;
        if (BaseModule.a.player == null || mc12972 == null) {
            return false;
        }
        Vec3 eyePos = BaseModule.a.player.getEyePosition();
        AABB targetBox = mc12972.getBoundingBox();
        double d3 = Mth.clamp((double)eyePos.x, (double)targetBox.minX, (double)targetBox.maxX);
        double d4 = Mth.clamp((double)eyePos.y, (double)targetBox.minY, (double)targetBox.maxY);
        double d5 = Mth.clamp((double)eyePos.z, (double)targetBox.minZ, (double)targetBox.maxZ);
        double d6 = Math.max(0.0, d2);
        return eyePos.distanceToSqr(d3, d4, d5) <= d6 * d6;
    }

    /*
     * Unable to fully structure code
     */
    private void b(Object[] var1_1) {
        block13: {
            block14: {
                block16: {
                    block15: {
                        block12: {
                            block9: {
                                block10: {
                                    block11: {
                                        block8: {
                                            var2_2 = (Long)var1_1[0];
                                            var4_3 = (l_0)var1_1[1];
                                            v0 = var2_2 = AutoMace.bb ^ var2_2;
                                            var5_4 = v0 ^ 80121159889151L;
                                            var7_5 = v0 ^ 41749906050741L;
                                            var9_6 = v0 ^ 97883273706749L;
                                            var11_7 = v0 ^ 34619170071221L;
                                            var13_8 = v0 ^ 9329476197076L;
                                            var15_9 = v0 ^ 86961914616184L;
                                            var17_10 = 66;
                                            if (BaseModule.a.player == null) {
                                                return;
                                            }
                                            if (this.target == null) ** GOTO lbl-1000
                                            v1 = new Object[1];
                                            v1[0] = var5_4;
                                            if ((double)BaseModule.a.player.distanceTo((Entity)this.target) <= this.c(v1)) {
                                                v2 = true;
                                            } else lbl-1000:
                                            // 2 sources

                                            {
                                                v2 = false;
                                            }
                                            var18_11 = v2;
                                            v3 = (Boolean)this.snapOnSmash.a();
                                            if (var2_2 <= 0L) break block8;
                                            if (!v3) ** GOTO lbl-1000
                                            v3 = var18_11;
                                        }
                                        if (v3) {
                                            v4 = kuzi.obf.p.m.INSTANT;
                                        } else lbl-1000:
                                        // 2 sources

                                        {
                                            v4 = kuzi.obf.p.m.SMOOTH;
                                        }
                                        var19_12 = v4;
                                        v5 = this;
                                        v6 = var17_10;
                                        if (var2_2 <= 0L) break block9;
                                        if (v6 == 0) break block10;
                                        if (v5.target == null) break block11;
                                        v7 = new Object[1];
                                        v7[0] = var5_4;
                                        v8 = new Object[3];
                                        v8[2] = this.c(v7);
                                        v8[1] = this.target;
                                        v8[0] = var7_5;
                                        v9 = (int)this.u(v8);
                                        if (var2_2 < 0L) break block12;
                                        if (v9 == 0) break block11;
                                        v10 = new Object[2];
                                        v10[1] = var11_7;
                                        v10[0] = this;
                                        ah.b(v10);
                                        break block13;
                                    }
                                    v5 = this;
                                }
                                v6 = var17_10;
                            }
                            if (v6 == 0) break block14;
                            v11 = new Object[1];
                            v11[0] = var15_9;
                            v9 = v5.m(v11);
                        }
                        if (var2_2 <= 0L) break block15;
                        if (v9 == 0) break block16;
                        ah.a(this, var4_3, (Supplier<Vec3>)LambdaMetafactory.metafactory(null, null, null, ()Ljava/lang/Object;, lambda$applyAimRotation$1(long ), ()Lnet/minecraft/Vec3;)((AutoMace)this, (long)var13_8), (Double)this.aimSpeed.a(), var19_12, 0.0, false, true);
                        v9 = var17_10;
                    }
                    if (v9 != 0) break block13;
                }
                v5 = this;
            }
            ah.a(v5, var4_3, (Supplier<Vec3>)LambdaMetafactory.metafactory(null, null, null, ()Ljava/lang/Object;, lambda$applyAimRotation$2(long ), ()Lnet/minecraft/Vec3;)((AutoMace)this, (long)var9_6), (Double)this.aimSpeed.a(), var19_12, 0.0, false, false);
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean u(Object[] objectArray) {
        AutoMace autoMace;
        long l2;
        Entity mc12972;
        long l3;
        block24: {
            block25: {
                CallSite callSite;
                long l4;
                block26: {
                    Object object;
                    CallSite callSite2;
                    long l5;
                    long l6;
                    block22: {
                        block23: {
                            LocalPlayer mc7462;
                            double d2;
                            block21: {
                                l3 = (Long)objectArray[0];
                                mc12972 = (Entity)objectArray[1];
                                d2 = (Double)objectArray[2];
                                long l7 = l3 = bb ^ l3;
                                l2 = l7 ^ 0x5B3847AA3788L;
                                l4 = l7 ^ 0x3ECEAF622116L;
                                l6 = l7 ^ 0x59C6E265ADDFL;
                                l5 = l7 ^ 0x3EDAE67A53B2L;
                                callSite2 = kuzi.obf.j.c.n.b();
                                try {
                                    mc7462 = ((Minecraft)BaseModule.a).player;
                                    if (callSite2 != false) break block21;
                                    if (mc7462 == null) return false;
                                }
                                catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                                    throw AutoMace.a(indexOutOfBoundsException);
                                }
                                mc7462 = mc12972;
                            }
                            try {
                                if (mc7462 == null) {
                                    return false;
                                }
                            }
                            catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                                throw AutoMace.a(indexOutOfBoundsException);
                            }
                            try {
                                try {
                                    object = ((Minecraft)BaseModule.a).player;
                                    if (l3 <= 0L || callSite2 != false) break block22;
                                    if (!((double)object.distanceTo(mc12972) > d2)) break block23;
                                    return false;
                                }
                                catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                                    throw AutoMace.a(indexOutOfBoundsException);
                                }
                            }
                            catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                                throw AutoMace.a(indexOutOfBoundsException);
                            }
                        }
                        try {
                            object = this;
                            if (l3 < 0L) break block22;
                            if (callSite2 != false) break block24;
                            object = object.stopAim.a();
                        }
                        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                            throw AutoMace.a(indexOutOfBoundsException);
                        }
                    }
                    try {
                        try {
                            try {
                                try {
                                    try {
                                        if (object != kuzi.obf.j.c.f.EXACT_CENTER) break block25;
                                        Object[] objectArray2 = new Object[1];
                                        objectArray2[0] = l5;
                                        callSite = this.m(objectArray2);
                                        if (callSite2 != false) return (boolean)callSite;
                                    }
                                    catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                                        throw AutoMace.a(indexOutOfBoundsException);
                                    }
                                    if (callSite == false) break block26;
                                }
                                catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                                    throw AutoMace.a(indexOutOfBoundsException);
                                }
                                Object[] objectArray3 = new Object[2];
                                objectArray3[1] = l6;
                                objectArray3[0] = mc12972;
                                callSite = this.v(objectArray3);
                                if (callSite2 != false) return (boolean)callSite;
                            }
                            catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                                throw AutoMace.a(indexOutOfBoundsException);
                            }
                            if (callSite != false) break block26;
                            return false;
                        }
                        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                            throw AutoMace.a(indexOutOfBoundsException);
                        }
                    }
                    catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                        throw AutoMace.a(indexOutOfBoundsException);
                    }
                }
                Object[] objectArray4 = new Object[2];
                objectArray4[1] = l4;
                objectArray4[0] = mc12972;
                callSite = this.w(objectArray4);
                return (boolean)callSite;
            }
            autoMace = this;
        }
        Object[] objectArray5 = new Object[2];
        objectArray5[1] = l2;
        objectArray5[0] = mc12972;
        return (boolean)autoMace.x(objectArray5);
    }

    private boolean v(Object[] objectArray) {
        boolean bl;
        block2: {
            block3: {
                EntityHitResult mc39662;
                Entity mc12972;
                block4: {
                    EntityHitResult mc39663;
                    mc12972 = (Entity)objectArray[0];
                    long l2 = (Long)objectArray[1];
                    l2 = bb ^ l2;
                    HitResult ItemParticleOption = BaseModule.a.hitResult;
                    int n2 = 66;
                    bl = ItemParticleOption instanceof EntityHitResult;
                    if (n2 == 0) break block2;
                    if (!bl) break block3;
                    mc39662 = mc39663 = (EntityHitResult)ItemParticleOption;
                    if (l2 <= 0L || n2 == 0) break block4;
                    if (mc39662.getType() != HitResult.mc240.ENTITY) break block3;
                    mc39662 = mc39663;
                }
                return mc39662.getEntity() == mc12972;
            }
            bl = false;
        }
        return bl;
    }

    private double a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = bb ^ l2;
        boolean bl = false;
        if (BaseModule.a.player == null) {
            return 0.0;
        }
        if (BaseModule.a.player.isFallFlying()) {
            return 0.0;
        }
        double d2 = BaseModule.a.player.getDeltaMovement().y;
        double d3 = BaseModule.a.player.fallDistance;
        double d4 = d2 - 0.0;
        double d5 = d4 == 0.0 ? 0 : (d4 > 0.0 ? 1 : -1);
        if (l2 >= 0L) {
            if (d5 > 0) {
                return 0.0;
            }
            double d6 = d2 - -0.5;
            d5 = d6 == 0.0 ? 0 : (d6 > 0.0 ? 1 : -1);
        }
        if (d5 > 0 && d3 > 1.0) {
            return 1.0;
        }
        return d3;
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    public boolean y(Object[] var1_1) {
        block17: {
            block19: {
                block18: {
                    block15: {
                        block16: {
                            block13: {
                                block14: {
                                    var2_2 = (Long)var1_1[0];
                                    var2_2 = AutoMace.bb ^ var2_2;
                                    var4_3 = kuzi.obf.j.c.n.b();
                                    try {
                                        try {
                                            try {
                                                v0 /* !! */  = this.d();
                                                if (var4_3 != false) break block13;
                                                if (v0 /* !! */  == false) break block14;
                                            }
                                            catch (IndexOutOfBoundsException v1) {
                                                throw AutoMace.a(v1);
                                            }
                                            v2 = ((Boolean)this.stunSlam.a()).booleanValue();
                                            v3 = var4_3;
                                            if (var2_2 > 0L) {
                                                if (v3 != false) break block15;
                                            }
                                            ** GOTO lbl37
                                        }
                                        catch (IndexOutOfBoundsException v4) {
                                            throw AutoMace.a(v4);
                                        }
                                        if (v2 != false) break block16;
                                    }
                                    catch (IndexOutOfBoundsException v5) {
                                        throw AutoMace.a(v5);
                                    }
                                }
                                v0 /* !! */  = (CallSite)false;
                            }
                            return (boolean)v0 /* !! */ ;
                        }
                        v2 = this.aa;
                    }
                    try {
                        try {
                            try {
                                v3 = var4_3;
lbl37:
                                // 2 sources

                                if (v3 != false) break block17;
                                if (v2 != false) break block18;
                            }
                            catch (IndexOutOfBoundsException v6) {
                                throw AutoMace.a(v6);
                            }
                            v2 = this.Q;
                            if (var4_3 != false) break block17;
                        }
                        catch (IndexOutOfBoundsException v7) {
                            throw AutoMace.a(v7);
                        }
                        if (v2 <= 0) break block19;
                    }
                    catch (IndexOutOfBoundsException v8) {
                        throw AutoMace.a(v8);
                    }
                }
                v2 = true;
                break block17;
            }
            v2 = 0;
        }
        return (boolean)v2;
    }

    private double b(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = bb ^ l2;
        boolean bl = false;
        return (Double)this.aimRange.a() > 0.0 ? (Double)this.aimRange.a() : (Double)this.swingRange.a();
    }

    private double c(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = bb ^ l2;
        return Math.min((Double)this.swingRange.a(), 2.95);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean z(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = bb ^ l2;
        int n2 = 66;
        if (BaseModule.a.player == null) return 0 != 0;
        int n3 = BaseModule.a.player.onGround();
        int n4 = n2;
        if (l2 >= 0L) {
            if (n4 != 0) {
                if (n3 != 0) return 0 != 0;
                double d2 = BaseModule.a.player.fallDistance - 0.0;
                n3 = d2 == 0.0 ? 0 : (d2 > 0.0 ? 1 : -1);
            }
            n4 = n2;
        }
        if (n4 == 0) return n3 != 0;
        if (n3 <= 0) return 0 != 0;
        return 1 != 0;
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private List b(Object[] var1_1) {
        var2_2 = (Long)var1_1[0];
        var2_2 = AutoMace.bb ^ var2_2;
        var5_3 = new ArrayList<Player>();
        var4_4 = 66;
        v0 = BaseModule.a.level;
        if (var4_4 != 0) {
            if (v0 == null) {
                return var5_3;
            }
            v0 = BaseModule.a.level;
        }
        var6_5 = v0.players();
        var7_6 = 0;
        var8_7 = var6_5.size();
        while (var7_6 < var8_7) {
            try {
                v1 /* !! */  = var6_5.get(var7_6);
lbl17:
                // 2 sources

                while (true) {
                    var9_8 = (Player)v1 /* !! */ ;
                    break;
                }
            }
            catch (IndexOutOfBoundsException var10_9) {
                break;
            }
            if (var2_2 >= 0L) {
                if (var9_8 != null) {
                    var5_3.add(var9_8);
                }
                ++var7_6;
            }
            if (var4_4 != 0) continue;
        }
        v1 /* !! */  = var5_3;
        ** while (var2_2 <= 0L)
lbl30:
        // 1 sources

        return v1 /* !! */ ;
    }

    private Player b(Object[] objectArray) {
        Player mc16572;
        block17: {
            Player mc16573;
            block18: {
                long l2 = (Long)objectArray[0];
                long l3 = l2 = bb ^ l2;
                long l4 = l3 ^ 0x7902B3901ACAL;
                long l5 = l3 ^ 0x794A4C2A9EEFL;
                long l6 = l3 ^ 0xF655F0DCBCEL;
                int n2 = 66;
                if (BaseModule.a.level == null || BaseModule.a.player == null) {
                    return null;
                }
                Object[] objectArray2 = new Object[1];
                objectArray2[0] = l5;
                double d2 = this.b(objectArray2);
                if (((Boolean)this.targetLock.a()).booleanValue()) {
                    Object[] objectArray3 = new Object[3];
                    objectArray3[2] = l4;
                    objectArray3[1] = d2;
                    objectArray3[0] = this.lockedTarget;
                    if (this.A(objectArray3)) {
                        return this.lockedTarget;
                    }
                }
                mc16573 = null;
                double d3 = Double.MAX_VALUE;
                Object[] objectArray4 = new Object[1];
                objectArray4[0] = l6;
                Iterator iterator = this.b(objectArray4).iterator();
                while (iterator.hasNext()) {
                    double d4;
                    Player mc16574;
                    block20: {
                        boolean bl;
                        block19: {
                            Player mc16575;
                            mc16572 = mc16574 = (Player)iterator.next();
                            if (l2 <= 0L) break block17;
                            int n3 = n2;
                            if (l2 > 0L) {
                                if (n3 == 0) break block17;
                                n3 = n2;
                            }
                            if (l2 > 0L) {
                                if (n3 != 0) {
                                    if (mc16572 == BaseModule.a.player) continue;
                                    mc16575 = mc16574;
                                }
                                n3 = n2;
                            }
                            if (n3 != 0) {
                                if (!mc16575.isAlive()) continue;
                                mc16575 = mc16574;
                            }
                            String string = mc16575.getName().getString();
                            bl = kuzi.obf.p.F.c(string);
                            int n4 = n2;
                            if (l2 >= 0L) {
                                if (n4 != 0) {
                                    if (bl && l2 >= 0L) continue;
                                    bl = (Boolean)this.ignoreFriends.a();
                                }
                                n4 = n2;
                            }
                            if (n4 == 0) break block19;
                            if (!bl) break block20;
                            bl = kuzi.obf.p.F.a(string);
                        }
                        if (bl) continue;
                    }
                    if ((d4 = BaseModule.a.player.distanceToSqr((Entity)mc16574)) > d2 * d2) continue;
                    if (l2 >= 0L) {
                        if (d4 >= d3) continue;
                        d3 = d4;
                        mc16573 = mc16574;
                    }
                    if (l2 > 0L) {
                        continue;
                    }
                    break block18;
                }
                this.lockedTarget = mc16573;
            }
            mc16572 = mc16573;
        }
        return mc16572;
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private boolean A(Object[] var1_1) {
        block15: {
            block13: {
                block14: {
                    block12: {
                        block10: {
                            block11: {
                                var6_2 = (Player)var1_1[0];
                                var2_3 = (Double)var1_1[1];
                                var4_4 = (Long)var1_1[2];
                                var4_4 = AutoMace.bb ^ var4_4;
                                var7_5 = 66;
                                if (var6_2 == null) break block10;
                                v0 = var6_2;
                                if (var4_4 <= 0L) break block11;
                                if (v0 == BaseModule.a.player) break block10;
                                v0 = var6_2;
                            }
                            if (v0.isAlive() && !var6_2.isRemoved()) break block12;
                        }
                        return false;
                    }
                    var8_6 = var6_2.getName().getString();
                    v1 = kuzi.obf.p.F.c(var8_6);
                    v2 = var7_5;
                    if (var4_4 >= 0L) {
                        if (v2 != 0) {
                            if (v1) {
                                return false;
                            }
                            v1 = (Boolean)this.ignoreFriends.a();
                        }
                        v2 = var7_5;
                    }
                    if (v2 == 0) break block13;
                    if (!v1) break block14;
                    v1 = kuzi.obf.p.F.a(var8_6);
                    v3 = var7_5;
                    if (var4_4 <= 0L) break block15;
                    if (v3 != 0) {
                        if (v1) {
                            return false;
                        } else {
                            ** GOTO lbl35
                        }
                    }
                    break block13;
                }
                v1 = (cfr_temp_0 = BaseModule.a.player.distanceToSqr((Entity)var6_2) - var2_3 * var2_3) == 0.0 ? 0 : (cfr_temp_0 < 0.0 ? -1 : 1);
            }
            v3 = var7_5;
        }
        if (v3 != 0) {
            v1 = v1 <= false;
        }
        return v1;
    }

    private Vec3 lambda$applyAimRotation$2(long l2) {
        CallSite callSite;
        block6: {
            block5: {
                AutoMace autoMace;
                long l3;
                block4: {
                    l3 = (l2 = bb ^ l2) ^ 0x6E152B9B1E69L;
                    CallSite callSite2 = kuzi.obf.j.c.n.c();
                    try {
                        try {
                            autoMace = this;
                            if (callSite2 == false) break block4;
                            if (autoMace.target == null) break block5;
                        }
                        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                            throw AutoMace.a(indexOutOfBoundsException);
                        }
                        autoMace = this;
                    }
                    catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                        throw AutoMace.a(indexOutOfBoundsException);
                    }
                }
                Object[] objectArray = new Object[2];
                objectArray[1] = l3;
                objectArray[0] = this.target;
                callSite = autoMace.a(objectArray);
                break block6;
            }
            callSite = null;
        }
        return callSite;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private Vec3 lambda$applyAimRotation$1(long l2) {
        AutoMace autoMace;
        long l3;
        block10: {
            Object object;
            block9: {
                l3 = (l2 = bb ^ l2) ^ 0x3F6F22447840L;
                CallSite callSite = kuzi.obf.j.c.n.c();
                try {
                    try {
                        try {
                            object = ((Minecraft)BaseModule.a).player;
                            if (callSite == false) break block9;
                            if (object == null) return null;
                        }
                        catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                            throw AutoMace.a(indexOutOfBoundsException);
                        }
                        autoMace = this;
                        if (callSite == false) break block10;
                    }
                    catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                        throw AutoMace.a(indexOutOfBoundsException);
                    }
                    object = autoMace.target;
                }
                catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                    throw AutoMace.a(indexOutOfBoundsException);
                }
            }
            try {
                if (object == null) {
                    return null;
                }
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                throw AutoMace.a(indexOutOfBoundsException);
            }
            autoMace = this;
        }
        Object[] objectArray = new Object[2];
        objectArray[1] = l3;
        objectArray[0] = this.target;
        CallSite callSite = autoMace.a(objectArray);
        return new Vec3(((Vec3)callSite).x, ((Minecraft)BaseModule.a).player.getEyeY(), ((Vec3)callSite).z);
    }

    private void lambda$new$0(long l2, Boolean bl, Boolean bl2) {
        long l3 = (l2 = bb ^ l2) ^ 0x2B44FF534F7L;
        Object[] objectArray = new Object[2];
        objectArray[1] = l3;
        objectArray[0] = (boolean)bl2;
        this.a(objectArray);
    }

    /*
     * Unable to fully structure code
     */
    static {
        block24: {
            block23: {
                block22: {
                    block21: {
                        block20: {
                            AutoMace.bb = kuzi.obf.h.b.v.a(5295287384272289727L, 9091106489072210872L, MethodHandles.lookup().lookupClass()).a(152424077458615L);
                            AutoMace.ib = new HashMap<K, V>(13);
                            var16 = AutoMace.bb ^ 99915632517450L;
                            var18_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                            v0 = SecretKeyFactory.getInstance("DES");
                            v1 = new byte[8];
                            v2 = v1;
                            v1[0] = (byte)(var16 >>> 56);
                            for (var19_2 = 1; var19_2 < 8; ++var19_2) {
                                v2 = v2;
                                v2[var19_2] = (byte)(var16 << var19_2 * 8 >>> 56);
                            }
                            var18_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                            var25_3 = new String[31];
                            var23_4 = 0;
                            var22_5 = "\u0098\u00cc\u00ad\u00a1%\u00d9a\u00a5#0\u00dd\u0003\u00b5\u00c0\u00f7\u0083\u00a6\u009e\u00ad\u00a8\u0017\b\u0099\u00f6V\u00b1;V\u009bN\u00b3\u00a5\u0018@YL\u0013*P\u00d1\u00a8\u00c5\u00dbL\u00a2\u00da\u00dbi\u009b\u00b1H\u0005\u008d\u00b8o\u00aa\u0089(\u009bh\u0098\u00d1\u00dboRv%\u00ea\u000fB\u0006\u00ae\t\u00af4r\u00d1\u00a8\u00a5\u00ce\u00c80\\8\u009a4-\u000e\u00ef\u0097\u0082\u00c7\u008b]\u00b9\b\u000e\u0083 \u0083\u008f\u00af\u00e3tqYQk\u0016\u0010?\u00db\u00ad\u00d1R6\u00a4m?\u00a3\u009b\u00a5\u0099\u00bf\u00c0\u00e2\u00d31\u0084\u00d1\u00dc kl\u00baz\u00c6\u00d1\u00ca\u0098\u001c\u008a^h\u001f\fzeod\u008e\u00e9EP\u0091; P7\u00e1\u00fe3\u00fd\u0011\u0018\u001a\u00c4**\u00b0\u00b0\u00cas\u00c4\u0087\u008d}7\u00a2\u0098lu\u00aa\u00e6F\u00dd\u00f71]\u0010\u0001\u007fi\u0014\u00d6\u00ebj:\u0001c\u009f(\u0018\u00e9\u00cd\u00b9 \u001b\u0096\u0001\u009b\u00c8\u00c1\\\u00cc\u00fb\u0089\u0099\u00ec\u00c4\u000f /\u00f1\u000b\u00a8H_\u00b3\u009ec\u00cb\u0000\u000b$;\u00b2\u00c4x\u0010\u00f2\u0005S$\u001e\u0094\u00d7\u00ac\u00c3\u0087Q\u00eb\u0016\u00a8\u00e0609\u00a9e\u00c6If\u00d6\u00a1\u0086\u00a7\u00de\u008aCP\u00f3\u00d2.>\u00d0s\u00d3~\u001e `'\u00c0\u008f\u00afn\u00b6\u00ad\u00e5\u009a\u0093\u00a6\u000bZu\u00ac\u00c2\u00f3\u00ebSV\u00fd\u00a5\u0011\u0010\u0019\u00f2\u009a&\u008bTcSG\u00fe7\u00df1\u0093\u00070 ,M\u00b6Q\u00e0@:D\u0015\u00dd\u0095g\u0017\"\u0097\u0011\u0097\u00be\u00fa\u0003%+\u00b1\u00f3\u00a7m\u00bd\u00fe^Ib\u009d d\u00f5:?\u00f7\u000b?\u0006\u00ff\u008f\u0014\u0095sB\u00d35Q\u00f8\u00c1o1\u00d0\u0015\u0018\u00f4s\u00a9S\u0099e\u00a8\u00fc \u009a\u00f6V\u00adv\u00ad*\u00d7\u0019\u00c6-\u00e2\u00e8\u00ecR\u00f8Kc]R\u0004l6\u0090\u001d\n\u0000#\u00b4n\u0010\u00a1\u0018\u001d\u00c2\u0015P\u0099\u00b4\u0001\u00ff\u001bR\u0084\u0097\u008a\u00a7?\u00fc}\u00f5n\u0012\u0091P\u00d2\u00db\u0018s\u0085^B\u00b7\u001dzr\u008c\u00ec\u00053C\u0093n\r4\u00ebF5\u009a\u0016\u0007\u00c3(>\u000b\u00e0\u00c6UsY\u00ba\u009b\u00b42\u00d7\u00fc\u00e2\f\u00c2x\u00d5\u0094\u00b2\u00ceN\u0094X\u00b3$\"\u00f85\u00d3#\u00b1\u00ee\u00ba\u00c8q\u00ed\u00b7\u00c1w\u0018\u00a5\u00d2\u0016t\u00e2\u0094\u00e7U\u00b8Y\u00dcn\u0084\u0014\u0088\u00d6\u00f1\u00c7|\u0084)\u0006\u00b9\u0097 T\u00ac\u0001\u00fcU\u00b1\u00f4\u00d0\u00c4^\u00fc\u00acl,\u0006b\u00a5\u00e1f\u00ca\\\u00c9\u00d2\u00a0\u0094\u0084\u008cQH\u00ad\u00f1q(x\u0018\n+\u0082\u00ddj\u00c2\u00fd7&O\u00b5.\u00e2\\)\u0088\u008a\u0019\u008ed\u00d4\u00e9n\u0080J\u00be\u00b0\u0006\u008eW\u00f0+\u00cf\u00e8 \u009d\u00003\u0018\u0096r\u00fb6\u00a1\u001cB\u0097\u00e7\u0091\u00e16y\u00e1\u00b4Lcs\u00aa\u00fd\u0005\u001a\u00e5\u00dc\u00106w\u0019\u00ca`\u00b9\u00ef\u00bcL\u00fd\u00a7F\u00c0\u00d1_\u0098 ?l\u0095\u0094\u0003\u000f\u000b\u00eaS\u00e4P@'\u00bb\u00b4(\u00a5o#YA\u008dw{zv\u0099\u0092\u00a4\u00b3\u00dcy K\u00ac\u00e5\u0092D\u00f8\u00d0F\u00bel\u00a5\u00f4!3\u007fS\u008eq0\u00804q&\u00b2$j?\u008a\u00ce\u00e5\u008e\u00fe\u0010\u00f7\u0000\"7\u00a9T\u0082\u00e8\u00a7\u001a\u0093\u0089\u00bdSo\\(\u009d\u00ae\u00f6\u009c\u0084\u0001\u00bc\b\u0098\u00bf\u009e}\u00a9\"\u00ef\u00b0\u00fbC\u0094\u00fcg\u0006|\u0097\f\u00ae\u00d7\u00ed\u0018\u000b\u00d1\u00ae\u00bc\u0081P\u00de\u00b2\u00f9\u00d9\u0004\u0018$\u00b5V\u00d1\u0087\u00fd\u008d\u0002\u001f\u00d7\u00ac\u00a9\u00d3 !\u0088\u00d7\u00ab\u0089\u0093~\u0085\u0098\u00a3 k\u00b0\u00f3\u00e6\u00ec>\u0012\u0018\u0099z\u001e\u00d3\u0081\u000f+\u00c5\u00f3[?@\u00cd\u00c9R-wFy\u0013\u008cC\u00e9\u00fd\u0018\u00bc\u0019\u00d2\u009e\u008e\u00be/\u009fD@\u0091VJx\b\u00f2M\u00bc\u00c8,j\u001f\u00d4\u0096";
                            var24_6 = "\u0098\u00cc\u00ad\u00a1%\u00d9a\u00a5#0\u00dd\u0003\u00b5\u00c0\u00f7\u0083\u00a6\u009e\u00ad\u00a8\u0017\b\u0099\u00f6V\u00b1;V\u009bN\u00b3\u00a5\u0018@YL\u0013*P\u00d1\u00a8\u00c5\u00dbL\u00a2\u00da\u00dbi\u009b\u00b1H\u0005\u008d\u00b8o\u00aa\u0089(\u009bh\u0098\u00d1\u00dboRv%\u00ea\u000fB\u0006\u00ae\t\u00af4r\u00d1\u00a8\u00a5\u00ce\u00c80\\8\u009a4-\u000e\u00ef\u0097\u0082\u00c7\u008b]\u00b9\b\u000e\u0083 \u0083\u008f\u00af\u00e3tqYQk\u0016\u0010?\u00db\u00ad\u00d1R6\u00a4m?\u00a3\u009b\u00a5\u0099\u00bf\u00c0\u00e2\u00d31\u0084\u00d1\u00dc kl\u00baz\u00c6\u00d1\u00ca\u0098\u001c\u008a^h\u001f\fzeod\u008e\u00e9EP\u0091; P7\u00e1\u00fe3\u00fd\u0011\u0018\u001a\u00c4**\u00b0\u00b0\u00cas\u00c4\u0087\u008d}7\u00a2\u0098lu\u00aa\u00e6F\u00dd\u00f71]\u0010\u0001\u007fi\u0014\u00d6\u00ebj:\u0001c\u009f(\u0018\u00e9\u00cd\u00b9 \u001b\u0096\u0001\u009b\u00c8\u00c1\\\u00cc\u00fb\u0089\u0099\u00ec\u00c4\u000f /\u00f1\u000b\u00a8H_\u00b3\u009ec\u00cb\u0000\u000b$;\u00b2\u00c4x\u0010\u00f2\u0005S$\u001e\u0094\u00d7\u00ac\u00c3\u0087Q\u00eb\u0016\u00a8\u00e0609\u00a9e\u00c6If\u00d6\u00a1\u0086\u00a7\u00de\u008aCP\u00f3\u00d2.>\u00d0s\u00d3~\u001e `'\u00c0\u008f\u00afn\u00b6\u00ad\u00e5\u009a\u0093\u00a6\u000bZu\u00ac\u00c2\u00f3\u00ebSV\u00fd\u00a5\u0011\u0010\u0019\u00f2\u009a&\u008bTcSG\u00fe7\u00df1\u0093\u00070 ,M\u00b6Q\u00e0@:D\u0015\u00dd\u0095g\u0017\"\u0097\u0011\u0097\u00be\u00fa\u0003%+\u00b1\u00f3\u00a7m\u00bd\u00fe^Ib\u009d d\u00f5:?\u00f7\u000b?\u0006\u00ff\u008f\u0014\u0095sB\u00d35Q\u00f8\u00c1o1\u00d0\u0015\u0018\u00f4s\u00a9S\u0099e\u00a8\u00fc \u009a\u00f6V\u00adv\u00ad*\u00d7\u0019\u00c6-\u00e2\u00e8\u00ecR\u00f8Kc]R\u0004l6\u0090\u001d\n\u0000#\u00b4n\u0010\u00a1\u0018\u001d\u00c2\u0015P\u0099\u00b4\u0001\u00ff\u001bR\u0084\u0097\u008a\u00a7?\u00fc}\u00f5n\u0012\u0091P\u00d2\u00db\u0018s\u0085^B\u00b7\u001dzr\u008c\u00ec\u00053C\u0093n\r4\u00ebF5\u009a\u0016\u0007\u00c3(>\u000b\u00e0\u00c6UsY\u00ba\u009b\u00b42\u00d7\u00fc\u00e2\f\u00c2x\u00d5\u0094\u00b2\u00ceN\u0094X\u00b3$\"\u00f85\u00d3#\u00b1\u00ee\u00ba\u00c8q\u00ed\u00b7\u00c1w\u0018\u00a5\u00d2\u0016t\u00e2\u0094\u00e7U\u00b8Y\u00dcn\u0084\u0014\u0088\u00d6\u00f1\u00c7|\u0084)\u0006\u00b9\u0097 T\u00ac\u0001\u00fcU\u00b1\u00f4\u00d0\u00c4^\u00fc\u00acl,\u0006b\u00a5\u00e1f\u00ca\\\u00c9\u00d2\u00a0\u0094\u0084\u008cQH\u00ad\u00f1q(x\u0018\n+\u0082\u00ddj\u00c2\u00fd7&O\u00b5.\u00e2\\)\u0088\u008a\u0019\u008ed\u00d4\u00e9n\u0080J\u00be\u00b0\u0006\u008eW\u00f0+\u00cf\u00e8 \u009d\u00003\u0018\u0096r\u00fb6\u00a1\u001cB\u0097\u00e7\u0091\u00e16y\u00e1\u00b4Lcs\u00aa\u00fd\u0005\u001a\u00e5\u00dc\u00106w\u0019\u00ca`\u00b9\u00ef\u00bcL\u00fd\u00a7F\u00c0\u00d1_\u0098 ?l\u0095\u0094\u0003\u000f\u000b\u00eaS\u00e4P@'\u00bb\u00b4(\u00a5o#YA\u008dw{zv\u0099\u0092\u00a4\u00b3\u00dcy K\u00ac\u00e5\u0092D\u00f8\u00d0F\u00bel\u00a5\u00f4!3\u007fS\u008eq0\u00804q&\u00b2$j?\u008a\u00ce\u00e5\u008e\u00fe\u0010\u00f7\u0000\"7\u00a9T\u0082\u00e8\u00a7\u001a\u0093\u0089\u00bdSo\\(\u009d\u00ae\u00f6\u009c\u0084\u0001\u00bc\b\u0098\u00bf\u009e}\u00a9\"\u00ef\u00b0\u00fbC\u0094\u00fcg\u0006|\u0097\f\u00ae\u00d7\u00ed\u0018\u000b\u00d1\u00ae\u00bc\u0081P\u00de\u00b2\u00f9\u00d9\u0004\u0018$\u00b5V\u00d1\u0087\u00fd\u008d\u0002\u001f\u00d7\u00ac\u00a9\u00d3 !\u0088\u00d7\u00ab\u0089\u0093~\u0085\u0098\u00a3 k\u00b0\u00f3\u00e6\u00ec>\u0012\u0018\u0099z\u001e\u00d3\u0081\u000f+\u00c5\u00f3[?@\u00cd\u00c9R-wFy\u0013\u008cC\u00e9\u00fd\u0018\u00bc\u0019\u00d2\u009e\u008e\u00be/\u009fD@\u0091VJx\b\u00f2M\u00bc\u00c8,j\u001f\u00d4\u0096".length();
                            var21_7 = 32;
                            var20_8 = -1;
lbl23:
                            // 2 sources

                            while (true) {
                                v3 = ++var20_8;
                                v4 = var22_5.substring(v3, v3 + var21_7);
                                v5 = -1;
                                break block20;
                                break;
                            }
lbl28:
                            // 1 sources

                            while (true) {
                                var25_3[var23_4++] = AutoMace.b(var26_9).intern();
                                if ((var20_8 += var21_7) < var24_6) {
                                    var21_7 = var22_5.charAt(var20_8);
                                    ** continue;
                                }
                                var22_5 = "1\u00e1qi\u00eb\u00c9\u00bc\u00e2\u00c2x\u0012\u00b3\u00e7\u0083\u00c7\u0017~\u00bc9\u0006\u00c8\u00d9\u00a3c\u0018d#\u00c6\fY ~ZHn\u00c4/\u00af\u00f0\u0010J\u0093w\u00a6\u00eai'3\u0096";
                                var24_6 = "1\u00e1qi\u00eb\u00c9\u00bc\u00e2\u00c2x\u0012\u00b3\u00e7\u0083\u00c7\u0017~\u00bc9\u0006\u00c8\u00d9\u00a3c\u0018d#\u00c6\fY ~ZHn\u00c4/\u00af\u00f0\u0010J\u0093w\u00a6\u00eai'3\u0096".length();
                                var21_7 = 24;
                                var20_8 = -1;
lbl37:
                                // 2 sources

                                while (true) {
                                    v6 = ++var20_8;
                                    v4 = var22_5.substring(v6, v6 + var21_7);
                                    v5 = 0;
                                    break block20;
                                    break;
                                }
                                break;
                            }
lbl42:
                            // 1 sources

                            while (true) {
                                var25_3[var23_4++] = AutoMace.b(var26_9).intern();
                                if ((var20_8 += var21_7) < var24_6) {
                                    var21_7 = var22_5.charAt(var20_8);
                                    ** continue;
                                }
                                break block21;
                                break;
                            }
                        }
                        var26_9 = var18_1.doFinal(v4.getBytes("ISO-8859-1"));
                        switch (v5) {
                            default: {
                                ** continue;
                            }
                            ** case 0:
lbl54:
                            // 1 sources

                            ** continue;
                        }
                    }
                    AutoMace.db = var25_3;
                    AutoMace.hb = new String[31];
                    AutoMace.lb = new HashMap<K, V>(13);
                    var5_10 = Cipher.getInstance("DES/CBC/NoPadding");
                    v7 = SecretKeyFactory.getInstance("DES");
                    v8 = new byte[8];
                    v9 = v8;
                    v8[0] = (byte)(var16 >>> 56);
                    for (var6_11 = 1; var6_11 < 8; ++var6_11) {
                        v9 = v9;
                        v9[var6_11] = (byte)(var16 << var6_11 * 8 >>> 56);
                    }
                    var5_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                    var11_12 = new long[25];
                    var8_13 = 0;
                    var9_14 = "\u0082\u00ae\u00ca|\u00a8J\u00a5\u0099\u0013\u00d0#\u0093U\u00b5\u00dcw/\u00fe\u00d3=Z\u00e9\u00f379xS\u0012\u00ae-\u00ad\u00d0\u0007\u00b1*U\u00acg\u00a5L\u0086\u00b7}s\u0011\u00f2\rE\u00e3\u00dcO)\u008e\u00b9\u0017\u0096\u009d\u00b5\u00db\u00a0\u0087\u0001\u00fe\u00bb\u00bb\u00b3<\u00a3\u0087\r\u00af\u00a3\u00e5\u0006\u008b\u00a3/\u0001q&\u00b4\u008b\u008f\b\u0085\u00ce\u009b$\u0080\u00c3\u00a8E\u00f1\u00f5\u0098M\u008c\u0016rW\u00e9\u00b0S\u0018\u009b\u00d6\u00de\u00174\u001fy\u000f\u00e0\u00c6}l@~X\u00dc\u0012\u00ba\u00db\u00e6\u0007-\u00f3D\u0005\u0011\u0000\u00b1\u00b1\u0096\u0012\u00c8\u00eb8\u00c96\u00e5=Fc\u00c9\u00f1\u0083\u00c5\u0005\u008e@8P\u00d6\t\u001d\u00d2\u0087\u00a9\u00d5\u0083\u0084\u0016\u000f\u00b7U\u00fc\u00b9\u00ac$0\u008au\u00b6\u00bc\u00bds\u00d5\u00c8\u001c+$\u000b\u00dc";
                    var10_15 = "\u0082\u00ae\u00ca|\u00a8J\u00a5\u0099\u0013\u00d0#\u0093U\u00b5\u00dcw/\u00fe\u00d3=Z\u00e9\u00f379xS\u0012\u00ae-\u00ad\u00d0\u0007\u00b1*U\u00acg\u00a5L\u0086\u00b7}s\u0011\u00f2\rE\u00e3\u00dcO)\u008e\u00b9\u0017\u0096\u009d\u00b5\u00db\u00a0\u0087\u0001\u00fe\u00bb\u00bb\u00b3<\u00a3\u0087\r\u00af\u00a3\u00e5\u0006\u008b\u00a3/\u0001q&\u00b4\u008b\u008f\b\u0085\u00ce\u009b$\u0080\u00c3\u00a8E\u00f1\u00f5\u0098M\u008c\u0016rW\u00e9\u00b0S\u0018\u009b\u00d6\u00de\u00174\u001fy\u000f\u00e0\u00c6}l@~X\u00dc\u0012\u00ba\u00db\u00e6\u0007-\u00f3D\u0005\u0011\u0000\u00b1\u00b1\u0096\u0012\u00c8\u00eb8\u00c96\u00e5=Fc\u00c9\u00f1\u0083\u00c5\u0005\u008e@8P\u00d6\t\u001d\u00d2\u0087\u00a9\u00d5\u0083\u0084\u0016\u000f\u00b7U\u00fc\u00b9\u00ac$0\u008au\u00b6\u00bc\u00bds\u00d5\u00c8\u001c+$\u000b\u00dc".length();
                    var7_16 = 0;
                    while (true) {
                        var12_17 = var9_14.substring(var7_16, var7_16 += 8).getBytes("ISO-8859-1");
                        v10 = var11_12;
                        v11 = var8_13++;
                        v12 = ((long)var12_17[0] & 255L) << 56 | ((long)var12_17[1] & 255L) << 48 | ((long)var12_17[2] & 255L) << 40 | ((long)var12_17[3] & 255L) << 32 | ((long)var12_17[4] & 255L) << 24 | ((long)var12_17[5] & 255L) << 16 | ((long)var12_17[6] & 255L) << 8 | (long)var12_17[7] & 255L;
                        v13 = -1;
                        break block22;
                        break;
                    }
lbl81:
                    // 1 sources

                    while (true) {
                        v10[v11] = v14;
                        if (var7_16 < var10_15) ** continue;
                        var9_14 = "\u00f4g<\u00feyfSiAC\u00de\u00fbC\u008b\u00d8N";
                        var10_15 = "\u00f4g<\u00feyfSiAC\u00de\u00fbC\u008b\u00d8N".length();
                        var7_16 = 0;
                        while (true) {
                            var12_17 = var9_14.substring(var7_16, var7_16 += 8).getBytes("ISO-8859-1");
                            v10 = var11_12;
                            v11 = var8_13++;
                            v12 = ((long)var12_17[0] & 255L) << 56 | ((long)var12_17[1] & 255L) << 48 | ((long)var12_17[2] & 255L) << 40 | ((long)var12_17[3] & 255L) << 32 | ((long)var12_17[4] & 255L) << 24 | ((long)var12_17[5] & 255L) << 16 | ((long)var12_17[6] & 255L) << 8 | (long)var12_17[7] & 255L;
                            v13 = 0;
                            break block22;
                            break;
                        }
                        break;
                    }
lbl94:
                    // 1 sources

                    while (true) {
                        v10[v11] = v14;
                        if (var7_16 < var10_15) ** continue;
                        break block23;
                        break;
                    }
                }
                var13_18 = v12;
                var15_19 = var5_10.doFinal(new byte[]{(byte)(var13_18 >>> 56), (byte)(var13_18 >>> 48), (byte)(var13_18 >>> 40), (byte)(var13_18 >>> 32), (byte)(var13_18 >>> 24), (byte)(var13_18 >>> 16), (byte)(var13_18 >>> 8), (byte)var13_18});
                v14 = ((long)var15_19[0] & 255L) << 56 | ((long)var15_19[1] & 255L) << 48 | ((long)var15_19[2] & 255L) << 40 | ((long)var15_19[3] & 255L) << 32 | ((long)var15_19[4] & 255L) << 24 | ((long)var15_19[5] & 255L) << 16 | ((long)var15_19[6] & 255L) << 8 | (long)var15_19[7] & 255L;
                switch (v13) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl107:
                    // 1 sources

                    ** continue;
                }
            }
            AutoMace.jb = var11_12;
            AutoMace.kb = new Integer[25];
            var0_20 = Cipher.getInstance("DES/CBC/NoPadding");
            v15 = SecretKeyFactory.getInstance("DES");
            v16 = new byte[8];
            v17 = v16;
            v16[0] = (byte)(var16 >>> 56);
            for (var1_21 = 1; var1_21 < 8; ++var1_21) {
                v17 = v17;
                v17[var1_21] = (byte)(var16 << var1_21 * 8 >>> 56);
            }
            break block24;
lbl121:
            // 1 sources

            while (true) {
                continue;
                break;
            }
        }
        var0_20.init(2, (Key)v15.generateSecret(new DESKeySpec(v17)), new IvParameterSpec(new byte[8]));
        var2_22 = -5956278946228410208L;
        var4_23 = var0_20.doFinal(new byte[]{(byte)(var2_22 >>> 56), (byte)(var2_22 >>> 48), (byte)(var2_22 >>> 40), (byte)(var2_22 >>> 32), (byte)(var2_22 >>> 24), (byte)(var2_22 >>> 16), (byte)(var2_22 >>> 8), (byte)var2_22});
        ** while (true)
        AutoMace.mb = ((long)var4_23[0] & 255L) << 56 | ((long)var4_23[1] & 255L) << 48 | ((long)var4_23[2] & 255L) << 40 | ((long)var4_23[3] & 255L) << 32 | ((long)var4_23[4] & 255L) << 24 | ((long)var4_23[5] & 255L) << 16 | ((long)var4_23[6] & 255L) << 8 | (long)var4_23[7] & 255L;
    }

    private static IndexOutOfBoundsException a(IndexOutOfBoundsException indexOutOfBoundsException) {
        return indexOutOfBoundsException;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static String b(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x4186;
        if (hb[n3] == null) {
            Object[] objectArray;
            try {
                Long l3 = Thread.currentThread().threadId();
                objectArray = (Object[])ib.get(l3);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    ib.put(l3, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/c/A", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l2 >>> 56);
            for (int i2 = 1; i2 < 8; ++i2) {
                byArray[i2] = (byte)(l2 << i2 * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = db[n3].getBytes("ISO-8859-1");
            AutoMace.hb[n3] = AutoMace.b(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return hb[n3];
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        String string2 = AutoMace.b(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static CallSite b(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/c/A" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x41B0;
        if (kb[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = jb[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])lb.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    lb.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/c/A", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            AutoMace.kb[n3] = n4;
        }
        return kb[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = AutoMace.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/c/A" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(AutoMace.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(AutoMace.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

