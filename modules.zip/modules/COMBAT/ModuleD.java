// === Kuzi module: ModuleD ===
// Category   : COMBAT
// Description: 
// Payload    : a.a.a.j.c.D (verified: False)

package kuzi.modules.combat;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.Map;
import kn.bb542ffe4b746c218.L;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.b.k;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.Player;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Duplicate member names - consider using --renamedupmembers true
 */
public class ModuleD
extends BaseModule {
    public static boolean m;
    private static final float n = 0.5f;
    private final k o;
    private final k p;
    private final k q;
    private final k r;
    private final k s;
    private final k t;
    private final k u;
    private final k v;
    private final k w;
    private final SliderSetting x;
    private final SliderSetting y;
    private final BoolSetting z;
    private final BoolSetting A;
    private final BoolSetting B;
    private final BoolSetting C;
    private final BoolSetting D;
    private final BoolSetting E;
    private final SliderSetting F;
    private final BoolSetting G;
    private long H;
    private long I;
    private long J;
    private long K;
    private long L;
    private long M;
    private long N;
    private long O;
    private int P;
    private int Q;
    private long R;
    private long S;
    private long T;
    private long U;
    private long V;
    private long W;
    private double X;
    private static final long Y;
    private static final String[] Z;
    private static final String[] ab;
    private static final Map bb;

    public ModuleD() {
        long l2 = Y ^ 0x52166F231D8DL;
        long l3 = l2 ^ 0x4AAFAE0266D0L;
        super((String)((Object)ModuleD.b("h", (int)12276, (long)(0x7072B5604EA7C634L ^ l2))), (String)((Object)ModuleD.b("h", (int)7024, (long)(0x1EEF045B551172A6L ^ l2))), Category.COMBAT);
        this.o = new k((String)((Object)ModuleD.b("h", (int)30293, (long)(0x1C0AEB47E3B49F88L ^ l2))), 1.0, 20.0, 1.0, 9.0, 13.0);
        this.p = new k((String)((Object)ModuleD.b("h", (int)8734, (long)(0x5C18560231204BC0L ^ l2))), 0.0, 250.0, 1.0, 90.0, 170.0);
        this.q = new k((String)((Object)ModuleD.b("h", (int)16296, (long)(0x16798BF97AADD66AL ^ l2))), 0.0, 500.0, 1.0, 40.0, 90.0);
        this.r = new k((String)((Object)ModuleD.b("h", (int)11301, (long)(0xE312D5FB58D45FAL ^ l2))), 0.0, 500.0, 1.0, 45.0, 95.0);
        this.s = new k((String)((Object)ModuleD.b("h", (int)10741, (long)(0x333FC72CC1B84036L ^ l2))), 0.0, 300.0, 1.0, 45.0, 110.0);
        this.t = new k((String)((Object)ModuleD.b("h", (int)662, (long)(0x3D854F1283A06B42L ^ l2))), 0.0, 500.0, 1.0, 90.0, 190.0);
        this.u = new k((String)((Object)ModuleD.b("h", (int)10770, (long)(0x5F4F5C321B6243C7L ^ l2))), 0.0, 3.0, 0.05, 2.7, 3.0);
        this.v = new k((String)((Object)ModuleD.b("h", (int)29630, (long)(0x479C1EF60E491A6DL ^ l2))), 0.0, 1000.0, 10.0, 120.0, 260.0);
        this.w = new k((String)((Object)ModuleD.b("h", (int)8868, (long)(0x7FA7A2D6CE14CB7DL ^ l2))), 0.0, 1000.0, 10.0, 90.0, 220.0);
        this.x = new SliderSetting((String)((Object)ModuleD.b("h", (int)11128, (long)(0x228006D3C87F42A0L ^ l2))), 5.0, 0.0, 100.0, 1.0);
        this.y = new SliderSetting((String)((Object)ModuleD.b("h", (int)24652, (long)(0x60E8DDF46295899DL ^ l2))), 0.0, 0.0, 100.0, 1.0);
        this.z = new BoolSetting((String)((Object)ModuleD.b("h", (int)19224, (long)(0x4DF067AACE5622C3L ^ l2))), true);
        this.A = new BoolSetting((String)((Object)ModuleD.b("h", (int)27877, (long)(0x703D883018430535L ^ l2))), true);
        this.B = new BoolSetting((String)((Object)ModuleD.b("h", (int)18299, (long)(0x5C0A2B23F26C2EA7L ^ l2))), true);
        this.C = new BoolSetting((String)((Object)ModuleD.b("h", (int)31205, (long)(0x221C2AD52259021L ^ l2))), true);
        this.D = new BoolSetting((String)((Object)ModuleD.b("h", (int)20973, (long)(0xA6C5DD2CDFB83FL ^ l2))), true);
        this.E = new BoolSetting((String)((Object)ModuleD.b("h", (int)11181, (long)(0x2C60F564FA67C277L ^ l2))), true);
        this.F = new SliderSetting((String)((Object)ModuleD.b("h", (int)12350, (long)(0x734EEADDFD25D9FFL ^ l2))), 0.0, 0.0, 1.0, 0.05);
        this.G = new BoolSetting((String)((Object)ModuleD.b("h", (int)15998, (long)(0x5CD741F60197D7A9L ^ l2))), true);
        this.P = -1;
        this.Q = -1;
        this.R = 80L;
        this.X = 3.0;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.o, this.p, this.q, this.r, this.s, this.t, this.u, this.v, this.w, this.x, this.y, this.z, this.A, this.B, this.C, this.D, this.E, this.F, this.G};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public native void d();

    private native boolean a();

    @Override
    public native void i();

    @Override
    public native void e();

    private static native long a(k var0);

    private native long a();

    private native boolean f();

    private native void a(Player var1, long var2);

    private native boolean a(long var1);

    private native Player a();

    private native boolean a(Player var1);

    private native int a();

    private native boolean b(Player var1);

    static {
        kn.bb542ffe4b746c218.L.init(ModuleD.class, 9);
        ModuleD.6137e061307bf089();
    }

    private static native String b(byte[] var0);

    private static native String b(int var0, long var1);

    private static native Object b(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native CallSite b(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native /* synthetic */ void 6137e061307bf089();
}

