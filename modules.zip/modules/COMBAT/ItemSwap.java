// === Kuzi module: ItemSwap ===
// Category   : COMBAT
// Description: Switches to specified slot when hitting
// Payload    : a.a.a.j.c.N (verified: True)

package kuzi.modules.combat;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.g.a.b;
import kuzi.obf.g.a.n;
import kuzi.obf.h.b.l;
import kuzi.obf.h.b.v;
import kuzi.obf.m.r;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.Inventory;

public class ItemSwap
extends BaseModule
implements n {
    private final SliderSetting switchToSlot;
    private final BoolSetting switchBack;
    private final l switchBackMode;
    private final SliderSetting switchBackSlot;
    private final SliderSetting switchBackDelay;
    private final BoolSetting ignoreEndCrystals;
    private final BoolSetting ignoreShieldBreak;
    private int previousSlot;
    private int switchBackTimer;
    private static final long v;
    private static final String[] w;
    private static final String[] x;
    private static final Map y;
    private static final long[] z;
    private static final Integer[] A;
    private static final Map B;
    private static final Object[] C;
    private static final String[] D;

    public ItemSwap() {
        long l2 = v ^ 0x75840B04A8DL;
        long l3 = l2 ^ 0x314A467D0CFAL;
        super("ItemSwap", "Switches to specified slot when hitting", Category.COMBAT);
        this.switchToSlot = new SliderSetting("Switch To Slot", 1.0, 1.0, 9.0, 1.0);
        this.switchBack = new BoolSetting("Switch Back", true);
        this.switchBackMode = new l("Switch Back Mode", (Enum)a.a.a.j.c.l.PREVIOUS, a.a.a.j.c.l.class);
        this.switchBackSlot = new SliderSetting("Switch Back Slot", 1.0, 1.0, 9.0, 1.0);
        this.switchBackDelay = new SliderSetting("Switch Back Delay", 1.0, 0.0, 20.0, 1.0);
        this.ignoreEndCrystals = new BoolSetting("Ignore End Crystals", false);
        this.ignoreShieldBreak = new BoolSetting("Ignore Shield Break", true);
        this.previousSlot = -1;
        this.switchBackTimer = 0;
        Setting[] settingArray = new Setting[]{this.switchToSlot, this.switchBack, this.switchBackMode, this.switchBackSlot, this.switchBackDelay, this.ignoreEndCrystals, this.ignoreShieldBreak};
        Object[] objectArray = new Object[2];
        objectArray[1] = settingArray;
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        Client.c.a(n.class, this);
        super.d();
        this.previousSlot = -1;
        this.switchBackTimer = 0;
    }

    @Override
    public void e() {
        Client.c.b(n.class, this);
        super.e();
    }

    @Override
    public void a(b b2) {
    }

    @Override
    public void i() {
        long l2 = v ^ 0x6467E552BD83L;
        long l3 = l2 ^ 0x64C4285661AFL;
        if (BaseModule.a.player == null || BaseModule.a.level == null) {
            return;
        }
        if (this.switchBackTimer > 0) {
            --this.switchBackTimer;
            if (this.switchBackTimer == 0 && this.previousSlot != -1) {
                Object[] objectArray = new Object[2];
                objectArray[1] = this.previousSlot;
                objectArray[0] = l3;
                this.selectSlot(objectArray);
                this.previousSlot = -1;
            }
        }
    }

    private void selectSlot(Object[] objectArray) {
        block11: {
            int slotToSelect;
            Inventory inventory;
            block9: {
                int targetSlot;
                block10: {
                    Object value;
                    int currentSlot;
                    block7: {
                        int guard;
                        long l2;
                        block8: {
                            block4: {
                                block5: {
                                    block6: {
                                        l2 = (Long)objectArray[0];
                                        targetSlot = (Integer)objectArray[1];
                                        l2 = v ^ l2;
                                        guard = 66;
                                        if (BaseModule.a.player == null) break block4;
                                        currentSlot = targetSlot;
                                        value = guard;
                                        if (l2 <= 0L) break block5;
                                        if (value == 0) break block6;
                                        if (currentSlot < 0) break block4;
                                        currentSlot = targetSlot;
                                    }
                                    value = ItemSwap.c("b", (int)5889, (long)(0x32C4C3F11BA4D3BBL ^ l2));
                                }
                                if (l2 <= 0L) break block7;
                                if (currentSlot <= value) break block8;
                            }
                            return;
                        }
                        inventory = BaseModule.a.player.getInventory();
                        slotToSelect = guard;
                        if (l2 < 0L) break block9;
                        if (slotToSelect == 0) break block10;
                        currentSlot = inventory.getSelectedSlot();
                        value = targetSlot;
                    }
                    if (currentSlot == value) break block11;
                    inventory = BaseModule.a.player.getInventory();
                }
                slotToSelect = targetSlot;
            }
            inventory.setSelectedSlot(slotToSelect);
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block16: {
            block15: {
                block14: {
                    block13: {
                        ItemSwap.v = kuzi.obf.h.b.v.a(-9168540036587084539L, 7227030201527698143L, MethodHandles.lookup().lookupClass()).a(203657632777286L);
                        ItemSwap.C = new Object[40];
                        ItemSwap.D = new String[40];
                        ItemSwap.c();
                        ItemSwap.y = new HashMap<K, V>(13);
                        var11 = ItemSwap.v ^ 31841680862214L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[9];
                        var18_4 = 0;
                        var17_5 = "z\u00c6GXJ\u00fe\u000f\u00a9\u009f\u00a6\u00a2\u00ab5\u0000_\u001a\u00a2\u00f9\u00c9\u00b2SQ\u00c3\u0082j\u00d6\u0012\u00cc!\u00f1!\u0014\u00f1\u00e9\u00afa\u00f5\u0014\u00b4r(3\u00b5\u00f0\u0086\u00a0\u00c5\u0093U\u008c\u0090\u0095\u00fb\u001a\u0006\u00cdtQ\u00c2^\u0016\t\u009d\u0083f9\u008a\r\u0017g9\u0087\u00a9\u00cd\u001e\u00a97!\u00e9\u0001v(\u0096\u00a0j#\u0005\u00f1\u00ac\u00de\u0092O\u00fc\u00a3\u008fJ%\u001d\u00d85k\u00e2\u00ec\u00f1\u001c\u0011\u00f9\u00fd\u00f7\u0001'[\u00b0\u00d1t\u0091nP\u00b2\u00d3\u0000\u0017@\u00db\u0019\u00ca\u0016\u00da\u0085*\u0092\u00c2\u000e['\u00a6<\u0080\u0001t\u0097\u00c9\u00f9\u0005-\u009b\u0017-\n\u0096k\u00b35\u00e9\u00a7\u0017\u000f\u00e1\u00b5ia\u00f6P\u00cc\u0018P\u008d\u00fe\u009d\u00db\u0099\u00afU\u00c7m\u00f8\u00b5\u00eb*\u00cc\u0012L\u00f1\u00f7\u00b1\u00e1\u00b2(x\u001f\u00cf;*\u00b8\u00ae\u008b0\\\u00act\u0012\u008fa\\e\u0010\u00b7\u00c2\u0011zj{{\u0092(\u00a7\u00bf\u008e\u009e\u00ae\u0004\u00d9z!\u00c6\u00b8\u00cc\u0018\u0018\u009dW\u00ca$\u008b,\u00fa\u0005\u00e3Z%\u00f0p\u0019~\u0003\u00e5\u00f8\u0080\u008b&3\u00c3\u007f\u0018\u0003\u0086\u00c4%\u00fbu\u0090\u00d7\u0001k\u00de\u00ee\u001dX\u0081j\u00f2N\u0091\u00e5\u0094m/L";
                        var19_6 = "z\u00c6GXJ\u00fe\u000f\u00a9\u009f\u00a6\u00a2\u00ab5\u0000_\u001a\u00a2\u00f9\u00c9\u00b2SQ\u00c3\u0082j\u00d6\u0012\u00cc!\u00f1!\u0014\u00f1\u00e9\u00afa\u00f5\u0014\u00b4r(3\u00b5\u00f0\u0086\u00a0\u00c5\u0093U\u008c\u0090\u0095\u00fb\u001a\u0006\u00cdtQ\u00c2^\u0016\t\u009d\u0083f9\u008a\r\u0017g9\u0087\u00a9\u00cd\u001e\u00a97!\u00e9\u0001v(\u0096\u00a0j#\u0005\u00f1\u00ac\u00de\u0092O\u00fc\u00a3\u008fJ%\u001d\u00d85k\u00e2\u00ec\u00f1\u001c\u0011\u00f9\u00fd\u00f7\u0001'[\u00b0\u00d1t\u0091nP\u00b2\u00d3\u0000\u0017@\u00db\u0019\u00ca\u0016\u00da\u0085*\u0092\u00c2\u000e['\u00a6<\u0080\u0001t\u0097\u00c9\u00f9\u0005-\u009b\u0017-\n\u0096k\u00b35\u00e9\u00a7\u0017\u000f\u00e1\u00b5ia\u00f6P\u00cc\u0018P\u008d\u00fe\u009d\u00db\u0099\u00afU\u00c7m\u00f8\u00b5\u00eb*\u00cc\u0012L\u00f1\u00f7\u00b1\u00e1\u00b2(x\u001f\u00cf;*\u00b8\u00ae\u008b0\\\u00act\u0012\u008fa\\e\u0010\u00b7\u00c2\u0011zj{{\u0092(\u00a7\u00bf\u008e\u009e\u00ae\u0004\u00d9z!\u00c6\u00b8\u00cc\u0018\u0018\u009dW\u00ca$\u008b,\u00fa\u0005\u00e3Z%\u00f0p\u0019~\u0003\u00e5\u00f8\u0080\u008b&3\u00c3\u007f\u0018\u0003\u0086\u00c4%\u00fbu\u0090\u00d7\u0001k\u00de\u00ee\u001dX\u0081j\u00f2N\u0091\u00e5\u0094m/L".length();
                        var16_7 = 40;
                        var15_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block13;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = ItemSwap.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "\u0084\u009b\u009b\u0013\u0088\u009cK\u00c3\u00e8\u0015-\u00ab\"\u00a7\u00e5\u00f2>\u00e7\u00ce\u00dfQ\u008c\u00fe\bS\u009d\u00f9b\u008d\u000f\u0097\u00f8+s\u00fexH\u00ce6\u009c \u00bb\u00abv\u00f5\u00ee\u00cb\u00b8\u0093#P^g\u0098\u008d_\u00dc\u00c4\u00c7{\u0014\u00c1'\u0007\u0087P\u0090\u00c5\u00db\u00d0\u00b6`\u001f";
                            var19_6 = "\u0084\u009b\u009b\u0013\u0088\u009cK\u00c3\u00e8\u0015-\u00ab\"\u00a7\u00e5\u00f2>\u00e7\u00ce\u00dfQ\u008c\u00fe\bS\u009d\u00f9b\u008d\u000f\u0097\u00f8+s\u00fexH\u00ce6\u009c \u00bb\u00abv\u00f5\u00ee\u00cb\u00b8\u0093#P^g\u0098\u008d_\u00dc\u00c4\u00c7{\u0014\u00c1'\u0007\u0087P\u0090\u00c5\u00db\u00d0\u00b6`\u001f".length();
                            var16_7 = 40;
                            var15_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block13;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = ItemSwap.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block14;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                ItemSwap.w = var20_3;
                ItemSwap.x = new String[9];
                ItemSwap.B = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[3];
                var3_13 = 0;
                var4_14 = ";\u009e\u0010\u00998\u00b8u\u0096\n\u00b8\u008d\u0010\u00b7+\u00ac\u0092\u008e`I\u008b\u00ad\u00b4\u00c8k";
                var5_15 = ";\u009e\u0010\u00998\u00b8u\u0096\n\u00b8\u008d\u0010\u00b7+\u00ac\u0092\u008e`I\u008b\u00ad\u00b4\u00c8k".length();
                var2_16 = 0;
                while (true) {
                    break block15;
                    break;
                }
lbl76:
                // 1 sources

                while (true) {
                    var6_12[v10] = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
                    if (var2_16 < var5_15) ** continue;
                    break block16;
                    break;
                }
            }
            var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
            v10 = var3_13++;
            var8_18 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            ** while (true)
        }
        ItemSwap.z = var6_12;
        ItemSwap.A = new Integer[3];
    }

    private static r a(r value) {
        return value;
    }

    private static String b(byte[] bytes) {
        int outputIndex = 0;
        int inputLength = bytes.length;
        char[] charBuffer = new char[inputLength];
        for (int index = 0; index < inputLength; ++index) {
            char decodedChar;
            int byteValue = 0xFF & bytes[index];
            if (byteValue < 192) {
                charBuffer[outputIndex++] = (char)byteValue;
                continue;
            }
            if (byteValue < 224) {
                decodedChar = (char)((char)(byteValue & 0x1F) << 6);
                byteValue = bytes[++index];
                decodedChar = (char)(decodedChar | (char)(byteValue & 0x3F));
                charBuffer[outputIndex++] = decodedChar;
                continue;
            }
            if (index >= inputLength - 2) continue;
            decodedChar = (char)((char)(byteValue & 0xF) << 12);
            byteValue = bytes[++index];
            decodedChar = (char)(decodedChar | (char)(byteValue & 0x3F) << 6);
            byteValue = bytes[++index];
            decodedChar = (char)(decodedChar | (char)(byteValue & 0x3F));
            charBuffer[outputIndex++] = decodedChar;
        }
        return new String(charBuffer, 0, outputIndex);
    }

    private static int c(int tableIndex, long decodeKey) {
        int slot = tableIndex ^ (int)(decodeKey & 0x7FFFL) ^ 0x1894;
        if (A[slot] == null) {
            byte[] plainText;
            byte[] keyBytes = new byte[]{(byte)(decodeKey >>> 56), (byte)(decodeKey >>> 48), (byte)(decodeKey >>> 40), (byte)(decodeKey >>> 32), (byte)(decodeKey >>> 24), (byte)(decodeKey >>> 16), (byte)(decodeKey >>> 8), (byte)decodeKey};
            long keyLong = z[slot];
            byte[] cipherText = new byte[]{(byte)(keyLong >>> 56), (byte)(keyLong >>> 48), (byte)(keyLong >>> 40), (byte)(keyLong >>> 32), (byte)(keyLong >>> 24), (byte)(keyLong >>> 16), (byte)(keyLong >>> 8), (byte)keyLong};
            Long threadId = Thread.currentThread().threadId();
            Object[] cipherContext = (Object[])B.get(threadId);
            try {
                if (cipherContext == null) {
                    cipherContext = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    B.put(threadId, cipherContext);
                }
                DESKeySpec desKeySpec = new DESKeySpec(keyBytes);
                SecretKey secretKey = ((SecretKeyFactory)cipherContext[1]).generateSecret(desKeySpec);
                Cipher cipher = (Cipher)cipherContext[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)cipherContext[2]);
                plainText = cipher.doFinal(cipherText);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/c/N", exception);
            }
            int decodedValue = (plainText[4] & 0xFF) << 24 | (plainText[5] & 0xFF) << 16 | (plainText[6] & 0xFF) << 8 | plainText[7] & 0xFF;
            ItemSwap.A[slot] = decodedValue;
        }
        return A[slot];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int tableIndex = (Integer)objectArray[0];
        long decodeKey = (Long)objectArray[1];
        int decodedValue = ItemSwap.c(tableIndex, decodeKey);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, decodedValue);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return decodedValue;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/c/N" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static void c() {
        Object[] objectArray = C;
        C[0] = "\u0010vVV@*\u001bvTVo";
        objectArray[1] = "\u0013n%)_N\u001fn6";
        objectArray[2] = "6#4!PI=#?";
        objectArray[3] = "oa \u001dP\u0001oa7A\\\u000eu*7_\\\u001br[g\u0002\r";
        objectArray[4] = Integer.TYPE;
        ItemSwap.D[4] = "java/lang/Integer";
        objectArray[5] = "\u0017kG&\u0003D\u001ckE&\f";
        objectArray[6] = ")!t\u0012@\u001e\\\u0001\u007f\u001dQQ=\u000ft\u0016U\u000bI";
        objectArray[7] = Void.TYPE;
        ItemSwap.D[7] = "java/lang/Void";
        objectArray[8] = "n\u000eL/ttg\u000eO/y";
        objectArray[9] = "uV(X\u0019\u0012~V*X\u0014";
        objectArray[10] = "N\u0019-gy\u001cE\u0019/g\\";
        objectArray[11] = Boolean.TYPE;
        ItemSwap.D[11] = "java/lang/Boolean";
        objectArray[12] = "\n\fX<R9\u0003\f[<^";
        objectArray[13] = "2\u0017lf)C;\u0017of+";
        objectArray[14] = "wtz4j\u001d~ty4j";
        objectArray[15] = "[fp\u000feXPia@\u0004V[be\u001a";
        objectArray[16] = "\u001c\f\"A]\u001ci,)NLS\b\"\"EH\t|";
        objectArray[17] = "\u00009~&;-\u000b9v";
        objectArray[18] = "a|<\"r=\u0014\\7-cruR<&g(\u0001";
        objectArray[19] = " f/\tY>~fok\u000eR#z2S\u00079lej[";
        objectArray[20] = "G\u0015rd6;DS1>F\u001a# S\u0014\u0001\u001f\"m3-9s\t\u00140kz)";
        objectArray[21] = "\u0006ABo]\u0010XA\u0002\r\u0004|\u0001\n\u0000h\tM\b@\u0001tmE\b\u0001^i\\LB\u0000B\r";
        objectArray[22] = "jt#AM+ll/E&xS)1\u0016\u001c-+-iDZ";
        objectArray[23] = "\u000f-ddu\u007fQ-$\u00069\u0013\u000b)$;$~S4&o";
        objectArray[24] = "~\u000bgp\u001cx*\u001d>sxfAZbm\u0003?.\u0019jgE";
        objectArray[25] = "%x\u0001\tDk{xAk\u0011\u0007+{\u0003\u0005Mh&{\u0003\u0005";
        objectArray[26] = ".\t2[\u001b-p\tr9RA \n0W\u0012.-\n0W";
        objectArray[27] = "561 ,om0'$\\5\u000ec?#a>c;\"!5_";
        objectArray[28] = "_>{6\u000b^\u0001>;TR2\n<?oK\f\u001f4r8;\u000e\u0013x;*E\\Q|3T";
        objectArray[29] = ".\u0000,SWgp\u0000l1\u001d\u000b!\u0010(\b\u0019z,\u0007(I";
        objectArray[30] = "7|\fP$P4:O\nTrQI8 \u001ahDHs_,V8t\n\\j\u0015b";
        objectArray[31] = "\b0\u001a=y\n\\8\u0014)I!$\u001e0\u0004\u0015j\b0\u001a=y\n\\8\u0014)";
        objectArray[32] = "T\u0018d\u0012g>\n\u0018$p,R[\b`I)#V\u001f`\b";
        objectArray[33] = "h\u001d\u001dT`J6\u001d]6(&f\u001e\u001fXiIk\u001e\u001fX";
        objectArray[34] = "xe\u0019\u007fm\u0001#j\b+\u0017\u0007Ir\u0019(}\r.yV(in";
        objectArray[35] = "\u001c|\u0002|\u0015WDz\u0014xe\f')\f\u007fX\u0006Jq\u0011}\fg";
        objectArray[36] = "2(]2\nM40Q6a\u0013\u000b$V1Z\u000751^|\rw7=\u00125\u001f\te\u007f\u0016=a";
        objectArray[37] = "\u000bog&/SUo'Db?\u000fk'y~RWv%-";
        objectArray[38] = "\u0004\rhr\u001a#K\u00120zt\"9\u0001uwO8\u0007\u0014}:\u0018H\u0006\u000fj1H'E\u0007`wt";
        Object[] objectArray2 = objectArray;
        objectArray[39] = "\u0005f\u0007n\u0016t[fG\f@\u0018\nv\u00035Xi\u0007a\u0003t";
    }

    private static Field c(Class targetClass, String fieldName, Class fieldType) {
        for (Field field : targetClass.getDeclaredFields()) {
            if (!field.getName().equals(fieldName) || field.getType() != fieldType) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class targetClass, String fieldName, Class fieldType) {
        Field field = ItemSwap.c(targetClass, fieldName, fieldType);
        if (field != null) {
            return field;
        }
        Class<?>[] interfaces = targetClass.getInterfaces();
        if (interfaces != null) {
            for (int index = 0; index < interfaces.length; ++index) {
                field = ItemSwap.d(interfaces[index], fieldName, fieldType);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class targetClass, String methodName, Class returnType, int parameterCount, Class[] parameterTypes) {
        block0: for (Method method : targetClass.getDeclaredMethods()) {
            Class<?>[] declaredParameterTypes;
            if (!method.getName().equals(methodName) || method.getReturnType() != returnType || (declaredParameterTypes = method.getParameterTypes()).length != parameterCount) continue;
            for (int index = 0; index < parameterCount; ++index) {
                if (declaredParameterTypes[index] != parameterTypes[index]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class targetClass, String methodName, Class returnType, int parameterCount, Class[] parameterTypes) {
        Method method = ItemSwap.c(targetClass, methodName, returnType, parameterCount, parameterTypes);
        if (method != null) {
            return method;
        }
        Class<?>[] interfaces = targetClass.getInterfaces();
        if (interfaces != null) {
            for (int index = 0; index < interfaces.length; ++index) {
                method = ItemSwap.d(interfaces[index], methodName, returnType, parameterCount, parameterTypes);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(ItemSwap.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

