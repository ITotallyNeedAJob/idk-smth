// === Kuzi module: AutoLava ===
// Category   : COMBAT
// Description: Places (and picks up) lava at an enemy's feet when you look at the block under them.
// Payload    : a.a.a.j.c.y (verified: True)

package kuzi.modules.combat;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Iterator;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.module.Module;
import kuzi.obf.i.k_0;
import kuzi.obf.m.r;
import kuzi.obf.p.F;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.Entity;
import net.minecraft.Player;
import net.minecraft.Items;
import net.minecraft.BlockPos;
import net.minecraft.HitResult;
import net.minecraft.BlockHitResult;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class AutoLava
extends BaseModule
implements Module {
    private final SliderSetting range;
    private final BoolSetting autoPickup;
    private final SliderSetting pickupDelay;
    private final BoolSetting switchBack;
    private final BoolSetting ignoreFriends;
    private int savedSlot;
    private int pickupPhase;
    private int pickupTicks;
    private int cooldownTicks;
    private static final long v = 136420000463214L;
    private static final long z;
    private static final Object[] A;
    private static final String[] B;

    public AutoLava() {
        long l2 = v ^ 0x64BD134EBDFEL;
        long l3 = l2 ^ 0x394CD999DF85L;
        super("AutoLava", "Places (and picks up) lava at an enemy's feet when you look at the block under them.", Category.COMBAT);
        this.range = new SliderSetting("Range", 5.0, 1.0, 8.0, 0.5);
        this.autoPickup = new BoolSetting("Auto Pickup", true);
        this.pickupDelay = new SliderSetting("Pickup Delay", 3.0, 1.0, 20.0, 1.0);
        this.switchBack = new BoolSetting("Switch Back", true);
        this.ignoreFriends = new BoolSetting("Ignore Friends", true);
        this.savedSlot = -1;
        this.pickupPhase = 0;
        this.pickupTicks = 0;
        this.cooldownTicks = 0;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.range, this.autoPickup, this.pickupDelay, this.switchBack, this.ignoreFriends};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        Client.a().a(Module.class, this);
        super.d();
        this.savedSlot = -1;
        this.pickupPhase = 0;
        this.pickupTicks = 0;
        this.cooldownTicks = 0;
    }

    @Override
    public void e() {
        long l2 = v ^ 0x2E3643D3E8DL;
        long l3 = l2 ^ 0x70F6BC4EB507L;
        Client.a().b(Module.class, this);
        super.e();
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.f(objectArray);
        this.pickupPhase = 0;
        this.pickupTicks = 0;
        this.cooldownTicks = 0;
    }

    @Override
    public void b() {
        BlockHitResult hitResult;
        long l2;
        long l3 = l2 = v ^ 0x647C264721AAL;
        long l4 = l3 ^ 0x3DBBE0CE16CEL;
        long l5 = l3 ^ 0x207BAE9BDB09L;
        long l6 = l3 ^ 0x7D7F8B9076B1L;
        long l7 = l3 ^ 0x3F8460B2095CL;
        if (BaseModule.a.player == null || BaseModule.a.level == null || BaseModule.a.gameMode == null) {
            return;
        }
        if (BaseModule.a.screen != null) {
            return;
        }
        if (this.pickupPhase == 1) {
            --this.pickupTicks;
            if (this.pickupTicks <= 0) {
                Object[] objectArray = new Object[1];
                objectArray[0] = l7;
                this.a(objectArray);
            }
            return;
        }
        if (this.cooldownTicks > 0) {
            --this.cooldownTicks;
            return;
        }
        HitResult hit = BaseModule.a.hitResult;
        if (!(hit instanceof BlockHitResult) || (hitResult = (BlockHitResult)hit).getType() != HitResult.mc240.BLOCK) {
            return;
        }
        Object[] objectArray = new Object[1];
        objectArray[0] = l5;
        hit = this.a(objectArray);
        if (hit == null) {
            return;
        }
        BlockPos targetPos = hit.blockPosition();
        BlockPos placePos = hitResult.getBlockPos().relative(hitResult.getDirection());
        if (!placePos.equals((Object)targetPos) && !placePos.equals((Object)targetPos.above())) {
            return;
        }
        if (!BaseModule.a.level.getBlockState(placePos).canBeReplaced()) {
            return;
        }
        Object[] objectArray2 = new Object[2];
        objectArray2[1] = l4;
        objectArray2[0] = Items.LAVA_BUCKET;
        int slot = this.a(objectArray2);
        if (slot == -1) {
            return;
        }
        if (((Boolean)this.switchBack.a()).booleanValue()) {
            this.savedSlot = BaseModule.a.player.getInventory().getSelectedSlot();
        }
        BaseModule.a.player.getInventory().setSelectedSlot(slot);
        ((k_0)BaseModule.a).invokeDoItemUse();
        if (((Boolean)this.autoPickup.a()).booleanValue()) {
            this.pickupPhase = 1;
            this.pickupTicks = Math.max(1, ((Double)this.pickupDelay.a()).intValue());
        } else {
            Object[] objectArray3 = new Object[1];
            objectArray3[0] = l6;
            this.c(objectArray3);
        }
    }

    private void a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = l2 = v ^ l2;
        long l4 = l3 ^ 0x7E2D41D6E6FCL;
        long l5 = l3 ^ 0x3EE92A888683L;
        Object[] objectArray2 = new Object[2];
        objectArray2[1] = l4;
        objectArray2[0] = Items.BUCKET;
        int slot = this.a(objectArray2);
        boolean bl = false;
        if (!bl) {
            if (slot != -1) {
                BaseModule.a.player.getInventory().setSelectedSlot(slot);
                ((k_0)BaseModule.a).invokeDoItemUse();
            }
            Object[] objectArray3 = new Object[1];
            objectArray3[0] = l5;
            this.c(objectArray3);
        }
    }

    private void c(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = (l2 = v ^ l2) ^ 0x1704B40E25FFL;
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l3;
        this.f(objectArray2);
        this.pickupPhase = 0;
        this.cooldownTicks = Math.max(2, ((Double)this.pickupDelay.a()).intValue() + 2);
    }

    private Player a(Object[] objectArray) {
        Player mc16572;
        block14: {
            long l2 = (Long)objectArray[0];
            l2 = v ^ l2;
            double maxRange = (Double)this.range.a();
            double bestDistSq = maxRange * maxRange;
            Player best = null;
            Iterator iterator = BaseModule.a.level.players().iterator();
            int n2 = 0;
            block0: while (true) {
                int n3 = iterator.hasNext();
                while (n3 != 0) {
                    block20: {
                        block21: {
                            Player mc16574;
                            block18: {
                                double d4;
                                block19: {
                                    Player mc16575;
                                    block17: {
                                        block16: {
                                            boolean bl;
                                            block15: {
                                                Player mc16576;
                                                mc16572 = mc16574 = (Player)iterator.next();
                                                if (l2 <= 0L) break block14;
                                                int n4 = n2;
                                                if (l2 >= 0L) {
                                                    if (n4 != 0) break block14;
                                                    n4 = n2;
                                                }
                                                if (n4 == 0) {
                                                    if (mc16572 == BaseModule.a.player) continue block0;
                                                    mc16576 = mc16574;
                                                }
                                                bl = mc16576.isDeadOrDying();
                                                int n5 = n2;
                                                if (l2 > 0L) {
                                                    if (n5 == 0) {
                                                        if (bl) continue block0;
                                                        bl = mc16574.isSpectator();
                                                    }
                                                    n5 = n2;
                                                }
                                                if (l2 >= 0L) {
                                                    if (n5 == 0) {
                                                        if (bl && l2 >= 0L) continue block0;
                                                        bl = (Boolean)this.ignoreFriends.a();
                                                    }
                                                    n5 = n2;
                                                }
                                                if (n5 != 0) break block15;
                                                if (!bl) break block16;
                                                mc16575 = mc16574;
                                                if (n2 != 0) break block17;
                                                bl = F.a(mc16575.getName().getString());
                                            }
                                            if (bl) continue block0;
                                        }
                                        mc16575 = mc16574;
                                    }
                                    double d5 = mc16575.distanceToSqr((Entity)BaseModule.a.player);
                                    if (l2 < 0L) break block18;
                                    d4 = d5;
                                    if (n2 != 0) break block19;
                                    double d6 = d4 - bestDistSq;
                                    n3 = d6 == 0.0 ? 0 : (d6 < 0.0 ? -1 : 1);
                                    if (l2 <= 0L) break block20;
                                    if (n3 > 0) break block21;
                                    d4 = d5;
                                }
                                bestDistSq = d4;
                            }
                            best = mc16574;
                        }
                        n3 = n2;
                    }
                    if (l2 <= 0L) continue;
                    if (n3 != 0) break block0;
                    continue block0;
                }
                break;
            }
            mc16572 = best;
        }
        return mc16572;
    }

    /*
     * Exception decompiling
     */
    private int a(Object[] var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * java.lang.UnsupportedOperationException
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.considerAsDoLoopStart(LoopIdentifier.java:383)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.identifyLoops1(LoopIdentifier.java:65)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:681)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private void f(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = v ^ l2;
        if (((Boolean)this.switchBack.a()).booleanValue() && this.savedSlot != -1 && BaseModule.a.player != null) {
            BaseModule.a.player.getInventory().setSelectedSlot(this.savedSlot);
            this.savedSlot = -1;
        }
    }

    static {
        A = new Object[]{"I5Z,lNB5X,t", Integer.TYPE, "\u001d\u000f2zX\t\u0016\u000f9", "\u0006~(_+8\u0006~?\u0003'7\u001c5?\u001d'\"\u001bDo@v", "\u001cK-xP\u001b\u0010K>", "IhgT5\u0005@hdT7", "CC4#\u0018$JC7#\u0018", "B\"\u00010j)I-\u0010\u007f\u000b'B&\u0014%", "WJB\u0016\u0019F\\J@\u0016\u0016", "O*r1S{F*q1_", "\"B\r\u0004s\u007f)B\u0005", "\u0011Vhh\nvdvcg\u001b9\u0005xhl\u001fcq", Void.TYPE, "\u001bg79\u001b\u0013nG<6\n\\\u000fI7=\u000e\u0006{", "clm=u}\u0016Lf2d2wBm9`h\u0003", "\u001bSu,\u0017Tns~#\u0006\u001b\u000f}u(\u0002A{", "Ki{Rpi>Ip]a&_G{Ve|+", "\u0004\u007f#Q\u000eN\u0004\u007f4\r\u0002A\u001e44\u0013\u0002T\u0019EfIV\u0010", "\u0013'nGUnf\u0007eHD!\u0007\tnC@{s", "O\u0004Mqec^\u0004j", "\u0015$5eB|\u001e+$*?d\r,-c", Boolean.TYPE, "[<**\u0002UZ6zMCdR86uU\tZ>-#", "\b(Gg:U\t\"\u0017\u0000}d\u0001,[8m\t\t*@n", "\u0006\u001c6\u001c{*\u0007\u0016f{!\u001b\b\u000f<\u001c<%XL3\u0010", "\u001aB`wW\bZXys*\b#\t4tGYQPrgJ", "*\u0018`W\u0006\b+\u001200F9#\u001c|\bQT+\u001ag^", "k@(]:\u0005jJx:~4`L=\nnL&\u0017|\n", ".q-\u0010I=/{}w\u001d\f%w=\u0019Doau)\u001ct7w`-G\u0017sut(w", "25\u0019\u0012u,i0\u000b@\u0010/\f7\u0019\t(/a?\u001f\u0012~E", "o\u0002\u000e9$+n\b^^p\u001a4\u001fZ,&tf\u0015\u001d5\u0019qdV\r7~g&\b\u000f^", "\nk\u0007PE\u0015^6@W<@f8\u001bPSS\r-H\u0013R)\bn\u0015\b\u0003P]1\u0018U<", "BADn`4CK\u0014\t4\u0005\u0019\\\u0010{bkKVWb]<\u0019\\\u0012c04\u001fGD\t", "Z=S\u0005|F\f}\u001eU\u00063\"Bh}ZxZ=S\u0005|F\f}\u001eU", "s\t.FXrr\u0003~!\u001eCz\r2\u0019\u000f.r\u000b)O", "\b#A\u0017\bV\t)\u0011pSg\u0003/T@\\\u001fEt\u0015@", "^CQ/;o_I\u0001H~^UODxo&\u0013\u0014\u0005x", "\u0014\u0006>\u000fgo\u0015\fnh3^O\u001bj\u001ae0\u001d\u0011-\u0003Zn[YlVk ]\u0017ah", "\u0001B\u000e7AdR\u0019\u0010{{6=\u001fS7\u0011g^@\u001ez\u0018_", "\u001ci[\u0010\u0019;GlIB|9\"k[\u000bD8Oc]\u0010\u0012R", "\f\u000bQ\"dW\r\u0001\u0001E7fW\u0016\u00057f\b\u0005\u001cB.YVCT\u0003{h\u0018E\u001a\u000eE", "/,{7qo.&+P)^!?q76`q|~;", "\u000b}${b Kg=\u007f\u001f-2g=(mv\\57otI\u0002s\u007f.!xLu1#\u001f", "\\/{L\u00072]%++Q\u0003\u00072/Y\u0005mU8h@:3\u0013p)\u0015\u000b}\u0015>$+"};
        B = new String[]{null, "java/lang/Integer", null, null, null, null, null, null, null, null, null, null, "java/lang/Void", null, null, null, null, null, null, null, null, "java/lang/Boolean", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null};
        z = 8346921988022861833L;
    }

    private static r a(r r2) {
        return r2;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = AutoLava.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = AutoLava.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = AutoLava.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = AutoLava.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }
}

