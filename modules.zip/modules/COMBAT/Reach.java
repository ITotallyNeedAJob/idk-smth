// === Kuzi module: Reach ===
// Category   : COMBAT
// Description: 
// Payload    : a.a.a.j.c.J (verified: False)

package kuzi.modules.combat;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import kn.bb542ffe4b746c218.L;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.module.Module;
import kuzi.obf.g.a.d;
import kuzi.obf.g.a.r;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.Entity;
import net.minecraft.Block;
import net.minecraft.BlockPos;
import net.minecraft.BlockHitResult;
import net.minecraft.EntityHitResult;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Duplicate member names - consider using --renamedupmembers true
 */
public class Reach
extends BaseModule
implements Module,
r {
    private final SliderSetting m;
    private final SliderSetting n;
    private final SliderSetting o;
    private final SliderSetting p;
    private final BoolSetting q;
    private final BoolSetting r;
    private final SliderSetting s;
    private final SliderSetting t;
    private final BoolSetting u;
    private final SliderSetting v;
    private final SliderSetting w;
    private final BoolSetting x;
    private volatile long y;
    private final Random z;
    private int A;
    private int B;
    private int C;
    private int D;
    private boolean E;
    private BlockHitResult F;
    private boolean G;
    private int H;
    private double I;
    private final Map J;
    private final Map K;
    private static final long L;
    private static final String[] M;
    private static final String[] N;
    private static final Map O;

    public Reach() {
        long l2 = L ^ 0x1ADB7B9BF704L;
        long l3 = l2 ^ 0x12E5CD040F31L;
        super((String)((Object)Reach.b("h", (int)16131, (long)(0x49E47AF75A86D57L ^ l2))), (String)((Object)Reach.b("h", (int)23055, (long)(0x41F6357987CB885AL ^ l2))), Category.COMBAT);
        this.m = new SliderSetting((String)((Object)Reach.b("h", (int)6136, (long)(0x2FF081A4D229C5AFL ^ l2))), 0.0, 0.0, 20.0, 1.0);
        this.n = new SliderSetting((String)((Object)Reach.b("h", (int)23765, (long)(0x32FE2A8E30658E83L ^ l2))), 8.0, 1.0, 20.0, 0.1);
        this.o = new SliderSetting((String)((Object)Reach.b("h", (int)16050, (long)(0x43CFBF6FB34A6CEBL ^ l2))), 12.0, 1.0, 20.0, 0.1);
        this.p = new SliderSetting((String)((Object)Reach.b("h", (int)12672, (long)(0x4D90956FB7B663DAL ^ l2))), 1.0, 1.0, 5.0, 1.0);
        this.q = new BoolSetting((String)((Object)Reach.b("h", (int)3221, (long)(0x1855BA6BB79FDECEL ^ l2))), false);
        this.r = new BoolSetting((String)((Object)Reach.b("h", (int)27536, (long)(0x32FCA37CB56D39C8L ^ l2))), false);
        this.s = new SliderSetting((String)((Object)Reach.b("h", (int)13087, (long)(0x536C9D1E2E8D6140L ^ l2))), 0.0, 0.0, 20.0, 1.0);
        this.t = new SliderSetting((String)((Object)Reach.b("h", (int)32077, (long)(0x4A1EC6B9CA7AF13L ^ l2))), 1.0, 0.0, 10.0, 0.1);
        this.u = new BoolSetting((String)((Object)Reach.b("h", (int)8418, (long)(0x5A6202187B1372B1L ^ l2))), true);
        this.v = new SliderSetting((String)((Object)Reach.b("h", (int)23878, (long)(0x4A8CAD7483000F14L ^ l2))), 3.0, 0.0, 15.0, 0.5);
        this.w = new SliderSetting((String)((Object)Reach.b("h", (int)5673, (long)(0x72D79797A8204474L ^ l2))), 18.0, 4.0, 48.0, 1.0);
        this.x = new BoolSetting((String)((Object)Reach.b("h", (int)3689, (long)(0x153BC6D5848DDC35L ^ l2))), true);
        this.y = 0L;
        this.z = new Random();
        this.G = false;
        this.H = -1;
        this.J = new HashMap();
        this.K = new HashMap();
        Setting[] settingArray = new Setting[]{this.m, this.n, this.o, this.p, this.q, this.r, this.s, this.t, this.u, this.v, this.w, this.x};
        Object[] objectArray = new Object[2];
        objectArray[1] = settingArray;
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public native void d();

    @Override
    public native void e();

    public native void a(Entity var1);

    @Override
    public native void a(d var1);

    private native void a();

    private native int a();

    private native int c();

    @Override
    public native void b();

    private native void c();

    private native void f();

    private native void l();

    private native boolean a(BlockPos var1);

    private native void m();

    private native void a(BlockHitResult var1);

    private native boolean a(BlockHitResult var1);

    private native void n();

    private native void a(EntityHitResult var1);

    private native boolean b(BlockPos var1);

    private native boolean c(BlockPos var1);

    private native boolean a(BlockPos var1, Block var2);

    private native boolean a(BlockHitResult var1, boolean var2);

    private static native boolean lambda$prunePending$1(int var0, Integer var1);

    private native boolean lambda$prunePending$0(int var1, Map.Entry var2);

    static {
        kn.bb542ffe4b746c218.L.init(Reach.class, 3);
        Reach.6137e0612924ab5c();
    }

    private static native String b(byte[] var0);

    private static native String b(int var0, long var1);

    private static native Object b(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native CallSite b(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native /* synthetic */ void 6137e0612924ab5c();
}

