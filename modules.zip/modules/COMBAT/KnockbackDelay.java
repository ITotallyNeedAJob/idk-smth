// === Kuzi module: KnockbackDelay ===
// Category   : COMBAT
// Description: Delays incoming knockback packets to confuse the server.
// Payload    : a.a.a.j.c.O (verified: False)

package kuzi.modules.combat;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.module.Module;
import kuzi.obf.g.a.h;
import kuzi.obf.g.a.v;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.HitResult;
import net.minecraft.PacketListener;
import net.minecraft.Packet;
import net.minecraft.ClientboundDisconnectPacket;
import net.minecraft.ClientboundExplodePacket;
import net.minecraft.ClientboundPlayerPositionPacket;
import net.minecraft.ClientboundRemoveEntitiesPacket;
import net.minecraft.ClientboundSetEntityMotionPacket;
import net.minecraft.ClientboundSetHealthPacket;
import net.minecraft.EntityHitResult;
import net.minecraft.ClientPacketListener;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class KnockbackDelay
extends BaseModule
implements v,
Module {
    private final SliderSetting chance;
    private final SliderSetting airMinDelayMs;
    private final SliderSetting airMaxDelayMs;
    private final SliderSetting groundMinDelayMs;
    private final SliderSetting groundMaxDelayMs;
    private final Queue queuedPackets;
    private volatile boolean delayActive;
    private volatile long releaseTime;
    private volatile boolean flushRequested;
    private int targetEntityId;
    private static final long w = 109549734758262L;
    private static final Object[] A = new Object[]{"\u0016`~\u0012)!\u001d`u", "3\u0013d\"\"\u00183\u0013s~.\u0017)Xs`.\u0002.)#=\u007f", "EH\u0016g5tNH\u0014g\u001b", Boolean.TYPE, "\r\nv. .x*}!1a\u0019$v*5;m", Void.TYPE, Long.TYPE, "\bw6\rP.\u0003x'B**\u0010y7\r\u001c.\u0007", "'h(3Y\u000e,h*3V", Integer.TYPE, "\u007f\u0017\bg)*a\u001f\u0012(V*p\u0003\u001b", ">\u001a]eX 7\u001a^eT", "S\u0007jv%\u001aX\u0007b", "C\u0012.R\u0016562%]\u0007zW<.V\u0003 #", "&d0\u0004U\tSD;\u000bDF2J0\u0000@\u001cF", "{U%B\u0007`rU&B\u0007", "\u0005.&\u0007\bL\u000e!7HiB\u0005*3\u0012", "f\u0003=/U\u0017\u0013#6 DXr-=+@\u0002\u0006", "YVMC\u0001C,vFL\u0010\fMxMG\u0014V9", "4}FP[8A]M_Jw SFTN-T", "1^XOu\u007fD~S@d0%pXK`jQ", "1\u000e=qKM3X/\rF5h\u0003;p@RlXgl", "\u000f\n\u001bH9\u0007Y\u0007\u001cKS\u00126YFS2[J\u0006\u0015F4", "O(x\u0007S1\u0019%\u007f\u00049&vqv\u0018G8Jrf\nT", "P\tR\f\u0015~\u0006\u0004U\u000f\u007fyi\u0007VN\u001an\u0003\u000fJ\b\u0007\u0012R\bT\u0013@u\u0013Z\u000eI\u007f", "H6G}c\u0006\u001e;@~\t\u0012qe\u001afhZ\r:Isn", "\u0012I!o$iDD&lNy+\u0016\"z\u007ftRM<t#", "#\u0015.z\u0015Eu\u0018)y\u007f@\u001aK&f\u0016Jj\u0010sd\u0004)'\u001a)l\u001cY|O+~\u007f", "\u001bZQnl\u001cMWVm\u0006\u0015\"\t\fug@^V_`a", "\tNj*\u0019:_Cm)s00\u001d71\u0012fLBd$\u0014", "3\t%.>le\u0004\"-Tl\n\u0007!l1|`\u000f=*,\u00000\u0000!/1<3\u00103<T", "\u000e\u0010\t\u007fKS_\u0016Ra;T3V\u0003o\u0002N]\u0007SyG>", "51veWFc<qf=M\fb+~\\\u001ap=xkZ", "A\u00193L}\u0001\u0017\u00144O\u0017\u0003x\u00177\u000er\u0011\u0012\u001f+HomB\u00107MrQA\u0000%^\u0017", "Qk}>4\u001b\u0010659J.&H\u0007\u000f\u0016eQk}>4\u001b\u0010659", "|\u001c-\u0007+\r*\u0011*\u0004A\bE\u0012)E$\u001d/\u001a5\u00039a~\u001d+\u0018~\u0006?OqBA", "[}\u001d\bL-\rp\u001a\u000b&+bs\u0019JC=\b{\u0005\f^AY|\u001b\u0017\u0019&\u0018.AM&", "h\u001fEk~.1\nI{\u0012,\u0001\u000fOy./h\u001a\u0011+)E", "\u007f(H\u0005q\u0003..\u0013\u001b\u0001\u0005BnB\u00158\u001e,?\u0012\u0003}n", "\u001f`b]4nIme^^|&=oKgrHl?]\"", "Z\u000bL\u007f\u0013b\f\u0006K|yscRB`\u0007k_QRr\u0014", "V~`y-\u0007T(r\u0005-\u007f[\"7`5\u0015S>q}IDT j:.\u0005\u0006z0\u0005", "j\u001aKJvC<\u0017LI\u001cFS\u0014O\byS9\u001cSNd/i\u0013OKy\u0013j\u0003]X\u001c", "\u001aVjJ\u0015YL[mI\u007fO#\n4L\u000e\u0004YI`S\u001e"};
    private static final String[] B = new String[]{null, null, null, "java/lang/Boolean", null, "java/lang/Void", "java/lang/Long", null, null, "java/lang/Integer", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null};

    public KnockbackDelay() {
        long l2 = w ^ 0x180921B54824L;
        long l3 = l2 ^ 0x5A48A3CE5447L;
        super("KnockbackDelay", "Delays incoming knockback packets to confuse the server.", Category.COMBAT);
        this.chance = new SliderSetting("Chance %", 100.0, 0.0, 100.0, 1.0);
        this.airMinDelayMs = new SliderSetting("Air Min Delay (ms)", 100.0, 0.0, 5000.0, 5.0);
        this.airMaxDelayMs = new SliderSetting("Air Max Delay (ms)", 250.0, 0.0, 5000.0, 5.0);
        this.groundMinDelayMs = new SliderSetting("Ground Min Delay (ms)", 50.0, 0.0, 5000.0, 5.0);
        this.groundMaxDelayMs = new SliderSetting("Ground Max Delay (ms)", 150.0, 0.0, 5000.0, 5.0);
        this.queuedPackets = new ConcurrentLinkedQueue();
        this.delayActive = false;
        this.releaseTime = 0L;
        this.flushRequested = false;
        this.targetEntityId = -1;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.chance, this.airMinDelayMs, this.airMaxDelayMs, this.groundMinDelayMs, this.groundMaxDelayMs};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        this.queuedPackets.clear();
        this.delayActive = false;
        this.flushRequested = false;
        this.targetEntityId = -1;
        Client.a().a(v.class, this);
        Client.a().a(Module.class, this);
    }

    @Override
    public void e() {
        long l2 = w ^ 0x1D532C914095L;
        long l3 = l2 ^ 0x54757CEB41D1L;
        Client.a().b(v.class, this);
        Client.a().b(Module.class, this);
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.c(objectArray);
    }

    @Override
    public void b() {
        EntityHitResult hitEntity;
        long l2 = w ^ 0x7BCC6EEB5FB2L;
        long l3 = l2 ^ 0x32EA3E915EF6L;
        if (BaseModule.a.player == null || BaseModule.a.level == null || BaseModule.a.getConnection() == null) {
            this.queuedPackets.clear();
            this.delayActive = false;
            this.flushRequested = false;
            return;
        }
        HitResult lookedAt = BaseModule.a.hitResult;
        if (lookedAt instanceof EntityHitResult) {
            hitEntity = (EntityHitResult)lookedAt;
            this.targetEntityId = hitEntity.getEntity().getId();
        }
        if (this.flushRequested) {
            this.flushRequested = false;
            Object[] objectArray = new Object[1];
            objectArray[0] = l3;
            this.c(objectArray);
            return;
        }
        if (this.delayActive && System.currentTimeMillis() >= this.releaseTime) {
            this.delayActive = false;
            Object[] objectArray = new Object[1];
            objectArray[0] = l3;
            this.c(objectArray);
            return;
        }
        if (this.delayActive) {
            if (!BaseModule.a.player.isAlive()) {
                this.delayActive = false;
                Object[] objectArray = new Object[1];
                objectArray[0] = l3;
                this.c(objectArray);
                return;
            }
            if (!(this.targetEntityId == -1 || (hitEntity = BaseModule.a.level.getEntity(this.targetEntityId)) != null && hitEntity.isAlive())) {
                this.delayActive = false;
                Object[] objectArray = new Object[1];
                objectArray[0] = l3;
                this.c(objectArray);
            }
        }
    }

    @Override
    public void a(h event) {
        long l2;
        long l3 = l2 = w ^ 0x4EFCCD1F0562L;
        long l4 = l3 ^ 0x6EB54096EDAAL;
        long l5 = l3 ^ 0x23247F53E55CL;
        long l6 = l3 ^ 0x1C5331D6FD1AL;
        long l7 = l3 ^ 0x3250904F3ED4L;
        if (BaseModule.a.player == null || BaseModule.a.level == null || BaseModule.a.getConnection() == null) {
            return;
        }
        if (BaseModule.a.isLocalServer()) {
            return;
        }
        Packet packet = event.c;
        if (packet == null) {
            return;
        }
        if (this.delayActive) {
            Object[] objectArray = new Object[2];
            objectArray[1] = packet;
            objectArray[0] = l6;
            if (this.d(objectArray)) {
                this.flushRequested = true;
                return;
            }
            this.queuedPackets.add(packet);
            event.a();
            return;
        }
        Object[] objectArray = new Object[2];
        objectArray[1] = l7;
        objectArray[0] = packet;
        if (this.a(objectArray)) {
            Object[] objectArray2 = new Object[1];
            objectArray2[0] = l4;
            if (this.f(objectArray2)) {
                Object[] objectArray3 = new Object[1];
                objectArray3[0] = l5;
                this.a(objectArray3);
                this.queuedPackets.add(packet);
                event.a();
            }
        }
    }

    private boolean a(Object[] objectArray) {
        int n2;
        boolean bl;
        Packet packet;
        block6: {
            int n3;
            block7: {
                block8: {
                    int n4;
                    block10: {
                        int n5;
                        block9: {
                            packet = (Packet)objectArray[0];
                            long l2 = (Long)objectArray[1];
                            l2 = w ^ l2;
                            n3 = 66;
                            if (BaseModule.a.player == null) {
                                return false;
                            }
                            bl = packet instanceof ClientboundSetEntityMotionPacket;
                            n2 = n3;
                            if (l2 <= 0L) break block6;
                            if (n2 == 0) break block7;
                            if (!bl) break block8;
                            ClientboundSetEntityMotionPacket motionPacket = (ClientboundSetEntityMotionPacket)packet;
                            n4 = motionPacket.getId();
                            n5 = n3;
                            if (l2 < 0L) break block9;
                            if (n5 == 0) break block10;
                            n5 = BaseModule.a.player.getId();
                        }
                        n4 = n4 == n5 ? 1 : 0;
                    }
                    return n4 != 0;
                }
                bl = packet instanceof ClientboundExplodePacket;
            }
            n2 = n3;
        }
        if (n2 != 0) {
            if (bl) {
                ClientboundExplodePacket explodePacket = (ClientboundExplodePacket)packet;
                return explodePacket.comp_2884().isPresent();
            }
            bl = false;
        }
        return bl;
    }

    private boolean f(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = w ^ l2;
        return Math.random() * 100.0 < (Double)this.chance.a();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean d(Object[] objectArray) {
        ClientboundRemoveEntitiesPacket removePacket;
        long l2 = (Long)objectArray[0];
        Packet packet = (Packet)objectArray[1];
        l2 = w ^ l2;
        int n2 = 66;
        if (packet instanceof ClientboundPlayerPositionPacket) {
            return true;
        }
        boolean bl = packet instanceof ClientboundDisconnectPacket;
        int n3 = n2;
        if (l2 >= 0L) {
            if (n3 != 0) {
                if (bl) {
                    return true;
                }
                bl = packet instanceof ClientboundSetHealthPacket;
            }
            n3 = n2;
        }
        if (n3 != 0) {
            if (bl && (removePacket = (ClientboundSetHealthPacket)packet).getHealth() <= 0.0f) {
                return true;
            }
            bl = packet instanceof ClientboundRemoveEntitiesPacket;
        }
        if (!bl) return 0 != 0;
        removePacket = (ClientboundRemoveEntitiesPacket)packet;
        int n4 = this.targetEntityId;
        int n5 = n2;
        if (l2 >= 0L) {
            if (n5 != 0) {
                if (n4 == -1) return 0 != 0;
                n4 = removePacket.getEntityIds().contains(this.targetEntityId) ? 1 : 0;
            }
            n5 = n2;
        }
        if (n5 == 0) return n4 != 0;
        if (n4 == 0) return 0 != 0;
        return 1 != 0;
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private void a(Object[] var1_1) {
        block7: {
            block5: {
                block6: {
                    var2_2 = (Long)var1_1[0];
                    var2_2 = KnockbackDelay.w ^ var2_2;
                    this.delayActive = true;
                    this.flushRequested = false;
                    var4_3 = false;
                    v0 /* !! */  = BaseModule.a.player;
                    if (var4_3) break block5;
                    if (!v0 /* !! */ .onGround()) break block6;
                    var5_4 = (Double)this.groundMinDelayMs.a();
                    var7_5 = (Double)this.groundMaxDelayMs.a();
                    if (var2_2 < 0L || !var4_3) break block7;
                }
                v0 /* !! */  = this.airMinDelayMs.a();
            }
            var5_4 = (Double)v0 /* !! */ ;
            var7_5 = (Double)this.airMaxDelayMs.a();
        }
        v1 = var5_4;
        if (var2_2 <= 0L) ** GOTO lbl29
        v2 = var7_5;
        if (var4_3) ** GOTO lbl28
        if (v1 >= v2) {
            v3 = (long)var5_4;
        } else {
            v4 = var5_4;
            v2 = Math.random() * (var7_5 - var5_4);
lbl28:
            // 2 sources

            v1 = v4 + v2;
lbl29:
            // 2 sources

            v3 = (long)v1;
        }
        var9_6 = v3;
        this.releaseTime = System.currentTimeMillis() + var9_6;
    }

    /*
     * Exception decompiling
     */
    private void c(Object[] var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[WHILELOOP]], but top level block is 1[WHILELOOP]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:435)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:484)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private void b(Object[] objectArray) {
        List packets = (List)objectArray[0];
        long l2 = (Long)objectArray[1];
        l2 = w ^ l2;
        ClientPacketListener connection = BaseModule.a.getConnection();
        boolean bl = false;
        if (connection == null) {
            return;
        }
        for (Packet packet : packets) {
            try {
                packet.handle((PacketListener)connection);
            }
            catch (Throwable throwable) {
                // empty catch block
            }
            if (!bl) continue;
        }
    }

    private void lambda$flushAll$0(List packets, long l2) {
        long l3 = (l2 = w ^ l2) ^ 0x4E380E88DF40L;
        Object[] objectArray = new Object[2];
        objectArray[1] = l3;
        objectArray[0] = packets;
        KnockbackDelay.c("\u00f0", (Object)this, (Object)objectArray, (long)-6161992022958776464L, (long)l2);
    }

    private static Throwable a(Throwable throwable) {
        return throwable;
    }

    private static int decodeIndex(long l2, long l3) {
        int n2;
        int n3;
        int tableIndex = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (B[tableIndex] != null) {
            return tableIndex;
        }
        Object entry = A[tableIndex];
        if (!(entry instanceof String)) {
            return tableIndex;
        }
        int decodeOffset = 0;
        decodeOffset = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 39;
            case 1 -> 15;
            case 2 -> 26;
            case 3 -> 40;
            case 4 -> 63;
            case 5 -> 46;
            case 6 -> 60;
            case 7 -> 32;
            case 8 -> 52;
            case 9 -> 45;
            case 10 -> 6;
            case 11 -> 9;
            case 12 -> 42;
            case 13 -> 23;
            case 14 -> 59;
            case 15 -> 5;
            case 16 -> 24;
            case 17 -> 4;
            case 18 -> 8;
            case 19 -> 25;
            case 20 -> 30;
            case 21 -> 27;
            case 22 -> 48;
            case 23 -> 21;
            case 24 -> 13;
            case 25 -> 41;
            case 26 -> 35;
            case 27 -> 22;
            case 28 -> 28;
            case 29 -> 49;
            case 30 -> 37;
            case 31 -> 34;
            case 32 -> 43;
            case 33 -> 57;
            case 34 -> 16;
            case 35 -> 31;
            case 36 -> 3;
            case 37 -> 7;
            case 38 -> 29;
            case 39 -> 17;
            case 40 -> 58;
            case 41 -> 0;
            case 42 -> 19;
            case 43 -> 14;
            case 44 -> 56;
            case 45 -> 62;
            case 46 -> 20;
            case 47 -> 11;
            case 48 -> 1;
            case 49 -> 33;
            case 50 -> 55;
            case 51 -> 18;
            case 52 -> 61;
            case 53 -> 44;
            case 54 -> 53;
            case 55 -> 51;
            case 56 -> 36;
            case 57 -> 2;
            case 58 -> 10;
            case 59 -> 38;
            case 60 -> 50;
            case 61 -> 12;
            case 62 -> 54;
            default -> 47;
        };
        int[] keyBytes = new int[6];
        int keyIndex = 0;
        while (keyIndex < 6) {
            n3 = 7 * (5 - keyIndex);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= decodeOffset) < 0) {
                n2 += 128;
            }
            keyBytes[keyIndex] = n2;
            ++keyIndex;
        }
        char[] chars = ((String)entry).toCharArray();
        n3 = 0;
        while (n3 < chars.length) {
            n2 = keyBytes[n3 % keyBytes.length];
            if (n2 == 0) break;
            chars[n3] = (char)(chars[n3] ^ n2);
            ++n3;
        }
        KnockbackDelay.B[tableIndex] = new String(chars);
        return tableIndex;
    }

    private static Class resolveClass(long l2, long l3) {
        Object entry;
        Class<?> clazz;
        block2: {
            clazz = null;
            int tableIndex = KnockbackDelay.decodeIndex(l2, l3);
            entry = A[tableIndex];
            try {
                if (!(entry instanceof String)) break block2;
                KnockbackDelay.A[tableIndex] = clazz = Class.forName(B[tableIndex]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)entry;
        return clazz;
    }

    private static Field findDeclaredField(Class ownerClass, String memberName, Class memberType) {
        for (Field field : ownerClass.getDeclaredFields()) {
            if (!field.getName().equals(memberName) || field.getType() != memberType) continue;
            return field;
        }
        return null;
    }

    private static Field findField(Class ownerClass, String memberName, Class memberType) {
        Field field = KnockbackDelay.findDeclaredField(ownerClass, memberName, memberType);
        if (field != null) {
            return field;
        }
        Class<?>[] interfaces = ownerClass.getInterfaces();
        if (interfaces != null) {
            for (int index = 0; index < interfaces.length; ++index) {
                field = KnockbackDelay.findField(interfaces[index], memberName, memberType);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field resolveField(long l2, long l3) {
        int tableIndex = KnockbackDelay.decodeIndex(l2, l3);
        Object entry = A[tableIndex];
        if (entry instanceof String) {
            String descriptor = B[tableIndex];
            int separatorIndex = descriptor.indexOf(8);
            Class clazz = KnockbackDelay.resolveClass(Long.parseLong(descriptor.substring(0, separatorIndex), 36), 0L);
            int nextSeparatorIndex = descriptor.indexOf(8, ++separatorIndex);
            String memberName = descriptor.substring(separatorIndex, nextSeparatorIndex);
            Class clazz2 = KnockbackDelay.resolveClass(Long.parseLong(descriptor.substring(++nextSeparatorIndex), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = KnockbackDelay.findDeclaredField(clazz3, memberName, clazz2)) != null) {
                    KnockbackDelay.A[tableIndex] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = KnockbackDelay.findField(classArray[i2], memberName, clazz2);
                        if (field == null) continue;
                        KnockbackDelay.A[tableIndex] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = KnockbackDelay.resolveClass(1183308268396215L, 0L);
            }
            StringBuffer errorMessage = new StringBuffer();
            errorMessage.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(memberName);
            throw new RuntimeException(errorMessage.toString());
        }
        return (Field)entry;
    }

    private static Method findDeclaredMethod(Class ownerClass, String memberName, Class returnType, int parameterCount, Class[] expectedParameterTypes) {
        block0: for (Method method : ownerClass.getDeclaredMethods()) {
            Class<?>[] parameterTypes;
            if (!method.getName().equals(memberName) || method.getReturnType() != returnType || (parameterTypes = method.getParameterTypes()).length != parameterCount) continue;
            for (int index = 0; index < parameterCount; ++index) {
                if (parameterTypes[index] != expectedParameterTypes[index]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method findMethod(Class ownerClass, String memberName, Class returnType, int parameterCount, Class[] expectedParameterTypes) {
        Method method = KnockbackDelay.findDeclaredMethod(ownerClass, memberName, returnType, parameterCount, expectedParameterTypes);
        if (method != null) {
            return method;
        }
        Class<?>[] interfaces = ownerClass.getInterfaces();
        if (interfaces != null) {
            for (int index = 0; index < interfaces.length; ++index) {
                method = KnockbackDelay.findMethod(interfaces[index], memberName, returnType, parameterCount, expectedParameterTypes);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method resolveMethod(long l2, long l3) {
        int tableIndex = KnockbackDelay.decodeIndex(l2, l3);
        Object entry = A[tableIndex];
        if (entry instanceof String) {
            Class<?>[] interfaces;
            Class clazz;
            Class clazz2;
            Class[] parameterTypes;
            int parameterCount;
            String methodName;
            Class clazz3;
            block10: {
                String descriptor = B[tableIndex];
                int firstSeparatorIndex = descriptor.indexOf(8);
                clazz3 = KnockbackDelay.resolveClass(Long.parseLong(descriptor.substring(0, firstSeparatorIndex), 36), 0L);
                int secondSeparatorIndex = descriptor.indexOf(8, ++firstSeparatorIndex);
                methodName = descriptor.substring(firstSeparatorIndex, secondSeparatorIndex);
                int separatorCount = -1;
                int scanIndex = secondSeparatorIndex;
                do {
                    ++separatorCount;
                    ++scanIndex;
                } while ((scanIndex = descriptor.indexOf(8, scanIndex)) > -1);
                parameterCount = separatorCount - 1;
                parameterTypes = new Class[parameterCount];
                clazz2 = null;
                scanIndex = secondSeparatorIndex + 1;
                for (int i2 = 0; i2 < separatorCount; ++i2) {
                    int nextSeparatorIndex = descriptor.indexOf(8, scanIndex);
                    clazz2 = KnockbackDelay.resolveClass(Long.parseLong(descriptor.substring(scanIndex, nextSeparatorIndex), 36), 0L);
                    if (i2 < parameterCount) {
                        parameterTypes[i2] = clazz2;
                    }
                    scanIndex = nextSeparatorIndex + 1;
                }
                clazz = clazz3;
                do {
                    if ((interfaces = KnockbackDelay.findDeclaredMethod(clazz, methodName, clazz2, parameterCount, parameterTypes)) != null) {
                        KnockbackDelay.A[tableIndex] = interfaces;
                        return interfaces;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = KnockbackDelay.resolveClass(1183308268396215L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((interfaces = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < interfaces.length; ++i3) {
                        Method method = KnockbackDelay.findMethod(interfaces[i3], methodName, clazz2, parameterCount, parameterTypes);
                        if (method == null) continue;
                        KnockbackDelay.A[tableIndex] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = KnockbackDelay.resolveClass(1183308268396215L, 0L);
            }
            StringBuffer errorMessage = new StringBuffer();
            errorMessage.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(methodName).append('(');
            int parameterIndex = 0;
            while (parameterIndex < parameterCount) {
                errorMessage.append(parameterTypes[parameterIndex].getName());
                if (++parameterIndex >= parameterCount) continue;
                errorMessage.append(", ");
            }
            errorMessage.append(')');
            throw new RuntimeException(errorMessage.toString());
        }
        return (Method)entry;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == '\u00fa' || c2 == 'K' || c2 == 'E' || c2 == '\u00d2') {
                field = KnockbackDelay.resolveField(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == '\u00fa' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == 'K' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == 'E' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = KnockbackDelay.resolveMethod(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == '\u00f0' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == '\u00fc' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = KnockbackDelay.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/c/O" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(KnockbackDelay.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

