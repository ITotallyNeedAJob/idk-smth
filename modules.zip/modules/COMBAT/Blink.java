// === Kuzi module: Blink ===
// Category   : COMBAT
// Description: Suspends movement packets and sends them all at once
// Payload    : a.a.a.j.c.G (verified: True)

package kuzi.modules.combat;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.g.a.i;
import kuzi.obf.g.a.w;
import kuzi.obf.m.r;
import net.minecraft.Packet;
import net.minecraft.ServerboundMovePlayerPacket;

public class Blink
extends BaseModule
implements w {
    private final List pendingPackets = new ArrayList();
    private static final long o = 9903505636925L;
    private static final Object[] v = new Object[]{"7ZxH/\n<Zp", "\u0011s)NS\u0019\u001as\"", "@`\u000fGR\u0011@`\u0018\u001b^\u001eZ+\u0018\u0005^\u000b]ZHX\u000f", "Z`\u007f\\\u0015rQ`}\\3", "\u0004]&k31\u001aU<$Q-\u001dH", "!\u000bV1e*-\u000bE", "ru\u001b<V-yu\u0019<Y", Integer.TYPE, Void.TYPE, Boolean.TYPE, "\u0003\u0004]IHQ\b\u000bL\u0006)_\u0003\u0000H\\", "[<]yV'F\"\u0006\u0012&\u0011q\f~Nm9N,\\)\u001c$Pw", "tCL\fS^7G\u0016nD,4_@\u001e@\u0014u^\u0002\t", "U-CD\u0010jQ8\u0018Bieo|\u0005Y\u001bq\u0017}\u0002TU", ";CI\u000b5.xG\u0013i)\\\u007f^C\u001b489\u001b\u0018\u0005K", "dU\u001c\u0000?k`@G\u0006Fh^\u0005Z@)9aUE\u0007<\u0001eB\u001f\u0016~>5]X\u0003F", "OEQ3\u00111\u0003\u001c\\\u007fp8sF\u0000r\n\"N\u0010Y2\u0000S", "\"V\u0016\u001bEqn\u000f\u001bW$y\u001eUGZ^b#\u0003\u001e\u001aT\u0013", "\u0013\f\u001e%\u0015\u0010P\bDG\u0007bT\n^|[\u0018S\u001fE9k"};
    private static final String[] w = new String[]{null, null, null, null, null, null, null, "java/lang/Integer", "java/lang/Void", "java/lang/Boolean", null, null, null, null, null, null, null, null, null};

    public Blink() {
        super("Blink", "Suspends movement packets and sends them all at once", Category.COMBAT);
    }

    @Override
    public void d() {
        Client.a().a(w.class, this);
        super.d();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public void e() {
        block7: {
            Client.a().b(w.class, this);
            boolean bl = false;
            if (bl) return;
            if (BaseModule.a.player != null && BaseModule.a.getConnection() != null) {
                List list = this.pendingPackets;
                // MONITORENTER : list
                for (Packet packet : this.pendingPackets) {
                    try {
                        BaseModule.a.getConnection().send(packet);
                        if (!bl) {
                            if (!bl) continue;
                            break;
                        }
                        break block7;
                    }
                    catch (r r2) {
                        throw Blink.a(r2);
                    }
                }
                this.pendingPackets.clear();
                // MONITOREXIT : list
            }
        }
        super.e();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void a(i event) {
        block4: {
            int pendingCount;
            long l2 = o ^ 0x76A18F44D12EL;
            long l3 = l2 ^ 0x5FC6E3DAF5DFL;
            int n3 = (int)(l3 >>> 32);
            int n4 = (int)(l3 << 32 >>> 48);
            int n5 = (int)(l3 << 48 >>> 48);
            if (!(event.c instanceof ServerboundMovePlayerPacket)) break block4;
            event.a();
            List list = this.pendingPackets;
            synchronized (list) {
                this.pendingPackets.add(event.c);
                pendingCount = this.pendingPackets.size();
            }
            if (pendingCount >= 6000) {
                BaseModule.a.execute(() -> this.lambda$onPacketSend$0(n3, (short)n4, n5));
            }
        }
    }

    private void lambda$onPacketSend$0(int n2, short s2, int n3) {
        long l2 = ((long)n2 << 32 | (long)s2 << 48 >>> 32 | (long)n3 << 48 >>> 48) ^ o;
        boolean bl = false;
        if (this.d()) {
            this.j();
        }
    }

    private static r a(r r2) {
        return r2;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = Blink.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = Blink.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = Blink.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = Blink.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }
}

