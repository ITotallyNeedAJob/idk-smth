// === Kuzi module: SpearReach ===
// Category   : COMBAT
// Description: Swaps to a spear for extra reach on a hit, then swaps back.
// Payload    : a.a.a.j.c.W (verified: True)

package kuzi.modules.combat;

import a.a.a.p.J;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.module.Module;
import kuzi.obf.g.a.q;
import kuzi.obf.h.b.v;
import kuzi.obf.m.r;
import kuzi.obf.p.F;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.Entity;
import net.minecraft.LivingEntity;
import net.minecraft.Player;
import net.minecraft.ProjectileUtil;
import net.minecraft.ItemStack;
import net.minecraft.EnchantmentHelper;
import net.minecraft.Enchantments;
import net.minecraft.AABB;
import net.minecraft.Vec3;
import net.minecraft.EntityHitResult;
import net.minecraft.Holder;
import net.minecraft.BuiltInRegistries;
import net.minecraft.Registries;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class SpearReach
extends BaseModule
implements q,
Module {
    private final SliderSetting reach;
    private final SliderSetting switchBackDelay;
    private final BoolSetting noLungeSpear;
    private boolean swapped;
    private int previousSlot;
    private int ticksSinceSwap;
    private static final long s;
    private static final String[] t;
    private static final String[] u;
    private static final Map v;
    private static final long[] w;
    private static final Integer[] x;
    private static final Map y;
    private static final Object[] z;
    private static final String[] A;

    public SpearReach() {
        long l2 = s ^ 0x175EDF7CA4B4L;
        long l3 = l2 ^ 0x24ADEAAEB449L;
        super("SpearReach", "Swaps to a spear for extra reach on a hit, then swaps back.", Category.COMBAT);
        this.reach = new SliderSetting("Reach", 5.0, 3.0, 6.0, 0.1);
        this.switchBackDelay = new SliderSetting("Switch Back Delay", 1.0, 1.0, 10.0, 1.0);
        this.noLungeSpear = new BoolSetting("No Lunge Spear", true);
        this.previousSlot = -1;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.reach, this.switchBackDelay, this.noLungeSpear};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        Client.a().a(q.class, this);
        Client.a().a(Module.class, this);
    }

    @Override
    public void e() {
        long l2 = s ^ 0x6CE19B384C0BL;
        long l3 = l2 ^ 0x553588DC7E4FL;
        Client.a().b(q.class, this);
        Client.a().b(Module.class, this);
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.c(objectArray);
    }

    @Override
    public void h() {
        this.swapped = false;
        this.previousSlot = -1;
    }

    @Override
    public void a() {
        long l2;
        long l3 = l2 = s ^ 0x5A530106E63EL;
        long l4 = l3 ^ 0x4F18EA780D89L;
        long l5 = l3 ^ 0xB4082AE9DB8L;
        long l6 = l3 ^ 0x77617C8B658BL;
        boolean bl = false;
        if (BaseModule.a.player == null || BaseModule.a.level == null || BaseModule.a.screen != null) {
            return;
        }
        if (this.swapped) {
            return;
        }
        if (!BaseModule.a.options.keyAttack.isDown()) {
            return;
        }
        if (BaseModule.a.player.getAttackStrengthScale(0.0f) < 1.0f) {
            return;
        }
        if (BaseModule.a.player.isUsingItem()) {
            return;
        }
        if (BaseModule.a.hitResult instanceof EntityHitResult) {
            return;
        }
        Object[] objectArray = new Object[2];
        objectArray[1] = BaseModule.a.player.getMainHandItem();
        objectArray[0] = l6;
        if (this.a(objectArray)) {
            return;
        }
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l5;
        int n2 = this.a(objectArray2);
        if (n2 == -1) {
            return;
        }
        Object[] objectArray3 = new Object[2];
        objectArray3[1] = (double)((Double)this.reach.a());
        objectArray3[0] = l4;
        LivingEntity target = this.a(objectArray3);
        if (target == null) {
            return;
        }
        this.previousSlot = BaseModule.a.player.getInventory().getSelectedSlot();
        if (this.previousSlot == n2) {
            return;
        }
        J.a((int)n2);
        BaseModule.a.hitResult = new EntityHitResult((Entity)target);
        BaseModule.a.crosshairPickEntity = target;
        this.swapped = true;
        this.ticksSinceSwap = 0;
    }

    @Override
    public void b() {
        long l2 = s ^ 0xA7ED942532CL;
        long l3 = l2 ^ 0x33AACAA66168L;
        if (!this.swapped) {
            return;
        }
        ++this.ticksSinceSwap;
        if (this.ticksSinceSwap >= (int)((Double)this.switchBackDelay.a()).doubleValue()) {
            Object[] objectArray = new Object[1];
            objectArray[0] = l3;
            this.c(objectArray);
        }
    }

    private void c(Object[] objectArray) {
        int n2;
        block7: {
            block8: {
                SpearReach spearReach;
                block6: {
                    SpearReach spearReach2;
                    block5: {
                        long l2 = (Long)objectArray[0];
                        l2 = s ^ l2;
                        int n3 = 66;
                        if (!this.swapped) {
                            return;
                        }
                        this.swapped = false;
                        if (BaseModule.a.player == null) break block5;
                        spearReach2 = this;
                        if (l2 <= 0L) break block6;
                        if (spearReach2.previousSlot < 0) break block5;
                        spearReach = this;
                        n2 = n3;
                        if (l2 <= 0L) break block7;
                        if (n2 == 0) break block8;
                        if (l2 < 0L) break block6;
                        if (spearReach.previousSlot <= SpearReach.c("g", (int)24801, (long)(0x21C5308F5BB42FC2L ^ l2))) {
                            J.a((int)this.previousSlot);
                        }
                    }
                    spearReach2 = this;
                }
                spearReach2.previousSlot = -1;
                spearReach = this;
            }
            n2 = 0;
        }
        spearReach.ticksSinceSwap = n2;
    }

    private LivingEntity a(Object[] objectArray) {
        boolean bl;
        LivingEntity target;
        block5: {
            long l2;
            block6: {
                block3: {
                    Entity entity;
                    boolean bl2;
                    long l3;
                    block4: {
                        Entity entity2;
                        EntityHitResult hitResult;
                        block2: {
                            EntityHitResult hitResult2;
                            l3 = (Long)objectArray[0];
                            double d2 = (Double)objectArray[1];
                            long l4 = l3 = s ^ l3;
                            l2 = l4 ^ 0x44DC98CACB1AL;
                            long l5 = l4 ^ 0x467E15603667L;
                            int n2 = (int)(l5 >>> 32);
                            long l6 = l5 << 32 >>> 32;
                            Vec3 eyePos = BaseModule.a.player.getEyePosition();
                            Vec3 lookVec = BaseModule.a.player.getViewVector(1.0f);
                            Vec3 endPos = eyePos.add(lookVec.scale(d2));
                            bl2 = false;
                            AABB searchBox = BaseModule.a.player.getBoundingBox().expandTowards(lookVec.scale(d2)).inflate(1.0, 1.0, 1.0);
                            hitResult = hitResult2 = ProjectileUtil.getEntityHitResult((Entity)BaseModule.a.player, (Vec3)eyePos, (Vec3)endPos, (AABB)searchBox, arg_0 -> SpearReach.lambda$findSpearTarget$0(n2, l6, arg_0), (double)(d2 * d2));
                            if (bl2) break block2;
                            if (hitResult == null) break block3;
                            hitResult = hitResult2;
                        }
                        entity = entity2 = hitResult.getEntity();
                        if (bl2) break block4;
                        if (!(entity instanceof LivingEntity)) break block3;
                        entity = entity2;
                    }
                    target = (LivingEntity)entity;
                    bl = bl2;
                    if (l3 < 0L) break block5;
                    if (!bl) break block6;
                }
                return null;
            }
            Object[] objectArray2 = new Object[2];
            objectArray2[1] = target;
            objectArray2[0] = l2;
            bl = this.d(objectArray2);
        }
        return bl ? target : null;
    }

    private int a(Object[] objectArray) {
        int n2;
        block3: {
            long l2 = (Long)objectArray[0];
            long l3 = l2 = s ^ l2;
            long l4 = l3 ^ 0x62F84E462E2DL;
            long l5 = l3 ^ 0x6E31C08A73DBL;
            int n3 = 0;
            boolean bl = false;
            while (n3 <= SpearReach.c("g", (int)29706, (long)(0x112D57D4B5F172EAL ^ l2))) {
                boolean bl2;
                block4: {
                    block5: {
                        block6: {
                            int n4;
                            block7: {
                                block8: {
                                    ItemStack stack = BaseModule.a.player.getInventory().getItem(n3);
                                    bl2 = bl;
                                    if (l2 < 0L) break block4;
                                    if (bl2) break block5;
                                    Object[] objectArray2 = new Object[2];
                                    objectArray2[1] = stack;
                                    objectArray2[0] = l5;
                                    n2 = this.a(objectArray2) ? 1 : 0;
                                    if (bl) break block3;
                                    if (n2 == 0) break block6;
                                    n4 = ((Boolean)this.noLungeSpear.a()).booleanValue();
                                    if (bl) break block7;
                                    if (n4 == 0) break block8;
                                    Object[] objectArray3 = new Object[2];
                                    objectArray3[1] = stack;
                                    objectArray3[0] = l4;
                                    n4 = this.c(objectArray3);
                                    if (bl) break block7;
                                    if (n4 != 0) break block6;
                                }
                                n4 = n3;
                            }
                            return n4;
                        }
                        ++n3;
                    }
                    bl2 = bl;
                }
                if (!bl2) continue;
            }
            n2 = -1;
        }
        return n2;
    }

    private boolean a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        ItemStack stack = (ItemStack)objectArray[1];
        l2 = s ^ l2;
        if (stack == null || stack.isEmpty()) {
            return false;
        }
        return BuiltInRegistries.ITEM.getKey((Object)stack.getItem()).getPath().contains((CharSequence)((Object)SpearReach.b("g", (int)20930, (long)(0xE4C44C116C1AD74L ^ l2))));
    }

    private int c(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        ItemStack stack = (ItemStack)objectArray[1];
        l2 = s ^ l2;
        if (stack.isEmpty()) {
            return 0;
        }
        try {
            Optional optional;
            block5: {
                optional = BaseModule.a.level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).get(Enchantments.LUNGE.identifier());
                try {
                    if (!optional.isEmpty()) break block5;
                }
                catch (Throwable throwable) {
                    throw SpearReach.a(throwable);
                }
                return 0;
            }
            return EnchantmentHelper.getItemEnchantmentLevel((Holder)((Holder)optional.get()), (ItemStack)stack);
        }
        catch (Throwable throwable) {
            return 0;
        }
    }

    private boolean d(Object[] objectArray) {
        boolean bl;
        float f2;
        LivingEntity target;
        block6: {
            boolean bl2;
            block7: {
                block8: {
                    block5: {
                        long l2 = (Long)objectArray[0];
                        target = (LivingEntity)objectArray[1];
                        l2 = s ^ l2;
                        bl2 = false;
                        if (target == BaseModule.a.player || !target.isAlive()) break block5;
                        float f3 = target.getHealth() - 0.0f;
                        f2 = f3 == 0.0f ? 0 : (f3 < 0.0f ? -1 : 1);
                        bl = bl2;
                        if (l2 <= 0L) break block6;
                        if (bl) break block7;
                        if (f2 > 0) break block8;
                    }
                    return false;
                }
                f2 = (float)(target instanceof Player);
            }
            bl = bl2;
        }
        if (!bl) {
            if (f2 != false) {
                Player player = (Player)target;
                return !F.c(player.getName().getString());
            }
            f2 = 1.0f;
        }
        return (boolean)f2;
    }

    /*
     * Unable to fully structure code
     */
    private static boolean lambda$findSpearTarget$0(int var0, long var1_1, Entity var3_2) {
        block19: {
            block16: {
                block18: {
                    block17: {
                        block15: {
                            var4_3 = ((long)var0 << 32 | var1_1 << 32 >>> 32) ^ SpearReach.s;
                            var6_4 = SpearReach.d("H", (long)6211091621939250225L, (long)var4_3);
                            try {
                                try {
                                    v0 = var3_2;
                                    if (var6_4 == false) break block15;
                                    if (!(v0 instanceof LivingEntity)) break block16;
                                }
                                catch (r v1) {
                                    throw SpearReach.d("H", (Object)v1, (long)6211267378104048688L, (long)var4_3);
                                }
                                v0 = var3_2;
                            }
                            catch (r v2) {
                                throw SpearReach.d("H", (Object)v2, (long)6211267378104048688L, (long)var4_3);
                            }
                        }
                        try {
                            try {
                                if (var0 <= 0 || var6_4 == false) break block17;
                                if (v0 == SpearReach.d("R", (long)6214423469580188295L, (long)var4_3).player) break block16;
                            }
                            catch (r v3) {
                                throw SpearReach.d("H", (Object)v3, (long)6211267378104048688L, (long)var4_3);
                            }
                            v0 = var3_2;
                        }
                        catch (r v4) {
                            throw SpearReach.d("H", (Object)v4, (long)6211267378104048688L, (long)var4_3);
                        }
                    }
                    try {
                        try {
                            v5 = v0.isAlive();
                            v6 = var6_4;
                            if (var1_1 >= 0L) {
                                if (v6 == false) break block18;
                                if (!v5) break block16;
                            }
                            ** GOTO lbl46
                        }
                        catch (r v7) {
                            throw SpearReach.d("H", (Object)v7, (long)6211267378104048688L, (long)var4_3);
                        }
                        v5 = var3_2.isSpectator();
                    }
                    catch (r v8) {
                        throw SpearReach.d("H", (Object)v8, (long)6211267378104048688L, (long)var4_3);
                    }
                }
                try {
                    v6 = var6_4;
lbl46:
                    // 2 sources

                    if (v6 == false) break block19;
                    if (v5) break block16;
                }
                catch (r v9) {
                    throw SpearReach.d("H", (Object)v9, (long)6211267378104048688L, (long)var4_3);
                }
                v5 = true;
                break block19;
            }
            v5 = false;
        }
        return v5;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block16: {
            block15: {
                block14: {
                    block13: {
                        SpearReach.s = kuzi.obf.h.b.v.a(4169871349072713527L, -3759685991799286909L, MethodHandles.lookup().lookupClass()).a(246138641776495L);
                        SpearReach.z = new Object[45];
                        SpearReach.A = new String[45];
                        SpearReach.c();
                        SpearReach.v = new HashMap<K, V>(13);
                        var11 = SpearReach.s ^ 107415654214885L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[6];
                        var18_4 = 0;
                        var17_5 = "\u0002\u0084/\u008c\u00b1\u00b8\u0002\u0095X\u00d2\u009a\u00e4\u00e0\u00c2\u00b0R\u00be\u00e5\u00fc\u0011\u001a\u0001\u0081\u00e2hJE7\u00b0]\u00dd\u00cc\u0018G\u00b0\u00e9\u00b2N\u00ad\u00c7a\u0090\u00ae\u0000\u00eez\u00ca:\u00ed\u00b6\u000b\u00c8\u0089\u0017~\u00d8L\u00e6\u00c5YJ\u00b4\u008bi\u0012\u009b\u00a8>\u00a4\u001c\u00a3\u00a2\u00c8\u00eb\u008d\u0012\u008e\u001f\u00a6\u00b50\u00f8e\u0097c\u00c23cG\u0099\u00b9\u00f2\u008e\u0089ry\u00c72\u00e16\u00e9\u0018(F\u0098\u00fc.5\u00bf\u00ca\u00bd+\u0094\u00f5\u00ec\u0097\u00a2\u00e6\u0012\u00be<\u0004\u00bf\u00ed)\u00ac\u00c2,\u000b c\u001c\u00f9\u00c4e\u00aelW\u00f4\u00ecjc[\u00cf\u00f7@\u00c0\u00db((\n\u0016\u00ack\u000b\u00ad\u00f1\u00125BJd\u0010\u00d3e)\u001f\u00eb\u001f\u0006\n\u000b\u00e6a\u00b1m\u00cb\u001f\u009b";
                        var19_6 = "\u0002\u0084/\u008c\u00b1\u00b8\u0002\u0095X\u00d2\u009a\u00e4\u00e0\u00c2\u00b0R\u00be\u00e5\u00fc\u0011\u001a\u0001\u0081\u00e2hJE7\u00b0]\u00dd\u00cc\u0018G\u00b0\u00e9\u00b2N\u00ad\u00c7a\u0090\u00ae\u0000\u00eez\u00ca:\u00ed\u00b6\u000b\u00c8\u0089\u0017~\u00d8L\u00e6\u00c5YJ\u00b4\u008bi\u0012\u009b\u00a8>\u00a4\u001c\u00a3\u00a2\u00c8\u00eb\u008d\u0012\u008e\u001f\u00a6\u00b50\u00f8e\u0097c\u00c23cG\u0099\u00b9\u00f2\u008e\u0089ry\u00c72\u00e16\u00e9\u0018(F\u0098\u00fc.5\u00bf\u00ca\u00bd+\u0094\u00f5\u00ec\u0097\u00a2\u00e6\u0012\u00be<\u0004\u00bf\u00ed)\u00ac\u00c2,\u000b c\u001c\u00f9\u00c4e\u00aelW\u00f4\u00ecjc[\u00cf\u00f7@\u00c0\u00db((\n\u0016\u00ack\u000b\u00ad\u00f1\u00125BJd\u0010\u00d3e)\u001f\u00eb\u001f\u0006\n\u000b\u00e6a\u00b1m\u00cb\u001f\u009b".length();
                        var16_7 = 24;
                        var15_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block13;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = SpearReach.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "\u0003\u001e~F\u00ec\u008fG\u00e0\u00cc\u00da\u001a\u0099\u00dd\u00f3\u00b2\u0091(\u00bf\u0089\u00cd?\u00faD\u001eS\u00e0o\u00ccU\u00d5\u00e4\u00c8\u00b3\u001ct<\n\u00a3\u00d9|\u00b5o\\\u00a9H\u00cd\u00e6\u00f7\u009b\u0087\u0006\u00f5\u009dj3\u00b3\u008a";
                            var19_6 = "\u0003\u001e~F\u00ec\u008fG\u00e0\u00cc\u00da\u001a\u0099\u00dd\u00f3\u00b2\u0091(\u00bf\u0089\u00cd?\u00faD\u001eS\u00e0o\u00ccU\u00d5\u00e4\u00c8\u00b3\u001ct<\n\u00a3\u00d9|\u00b5o\\\u00a9H\u00cd\u00e6\u00f7\u009b\u0087\u0006\u00f5\u009dj3\u00b3\u008a".length();
                            var16_7 = 16;
                            var15_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block13;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = SpearReach.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block14;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                SpearReach.t = var20_3;
                SpearReach.u = new String[6];
                SpearReach.y = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[2];
                var3_13 = 0;
                var4_14 = "swj6\u0094\u001f]\u00d8\n\u009f\u00a3\u00bc\u00c2\u0092O\u00b9";
                var5_15 = "swj6\u0094\u001f]\u00d8\n\u009f\u00a3\u00bc\u00c2\u0092O\u00b9".length();
                var2_16 = 0;
                while (true) {
                    break block15;
                    break;
                }
lbl76:
                // 1 sources

                while (true) {
                    var6_12[v10] = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
                    if (var2_16 < var5_15) ** continue;
                    break block16;
                    break;
                }
            }
            var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
            v10 = var3_13++;
            var8_18 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            ** while (true)
        }
        SpearReach.w = var6_12;
        SpearReach.x = new Integer[2];
    }

    private static Throwable a(Throwable throwable) {
        return throwable;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static String b(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x7F07;
        if (u[n3] == null) {
            Object[] objectArray;
            try {
                Long l3 = Thread.currentThread().threadId();
                objectArray = (Object[])v.get(l3);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    v.put(l3, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/c/W", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l2 >>> 56);
            for (int i2 = 1; i2 < 8; ++i2) {
                byArray[i2] = (byte)(l2 << i2 * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = t[n3].getBytes("ISO-8859-1");
            SpearReach.u[n3] = SpearReach.b(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return u[n3];
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        String string2 = SpearReach.b(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static CallSite b(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/c/W" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x7D67;
        if (x[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = w[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])y.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    y.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/c/W", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            SpearReach.x[n3] = n4;
        }
        return x[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = SpearReach.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/c/W" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (A[n4] != null) {
            return n4;
        }
        Object object = z[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 23;
            case 1 -> 30;
            case 2 -> 4;
            case 3 -> 22;
            case 4 -> 18;
            case 5 -> 41;
            case 6 -> 56;
            case 7 -> 14;
            case 8 -> 50;
            case 9 -> 57;
            case 10 -> 5;
            case 11 -> 60;
            case 12 -> 2;
            case 13 -> 47;
            case 14 -> 48;
            case 15 -> 61;
            case 16 -> 62;
            case 17 -> 15;
            case 18 -> 49;
            case 19 -> 59;
            case 20 -> 38;
            case 21 -> 29;
            case 22 -> 53;
            case 23 -> 9;
            case 24 -> 0;
            case 25 -> 1;
            case 26 -> 24;
            case 27 -> 10;
            case 28 -> 27;
            case 29 -> 43;
            case 30 -> 6;
            case 31 -> 37;
            case 32 -> 20;
            case 33 -> 45;
            case 34 -> 13;
            case 35 -> 33;
            case 36 -> 39;
            case 37 -> 44;
            case 38 -> 21;
            case 39 -> 46;
            case 40 -> 26;
            case 41 -> 19;
            case 42 -> 32;
            case 43 -> 17;
            case 44 -> 34;
            case 45 -> 40;
            case 46 -> 16;
            case 47 -> 58;
            case 48 -> 8;
            case 49 -> 36;
            case 50 -> 42;
            case 51 -> 52;
            case 52 -> 7;
            case 53 -> 25;
            case 54 -> 11;
            case 55 -> 28;
            case 56 -> 55;
            case 57 -> 31;
            case 58 -> 35;
            case 59 -> 12;
            case 60 -> 3;
            case 61 -> 63;
            case 62 -> 54;
            default -> 51;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        SpearReach.A[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = z;
        z[0] = ">QS6\u0004\u00075QX";
        objectArray[1] = "0^j\u0006\u0010\u007f0^}Z\u001cp*\u0015}D\u001ce-d-\u0019M";
        objectArray[2] = "AU1S\u001bYJU3S-";
        objectArray[3] = "EV#=0C0v(2!\fQx#9%V%";
        objectArray[4] = Integer.TYPE;
        SpearReach.A[4] = "java/lang/Integer";
        objectArray[5] = "lz$\u0006F\ngz&\u0006I";
        objectArray[6] = "\u0011deL\u0010j\u0018dfL\u0012";
        objectArray[7] = "?p3\b \u001aJP8\u00071U+^3\f5\u000f_";
        objectArray[8] = Boolean.TYPE;
        SpearReach.A[8] = "java/lang/Boolean";
        objectArray[9] = "\u0001t#Nf#\bt Nf";
        objectArray[10] = "\u0002_K\u001c]\u0000\tPZS<\u000e\u0002[^\t";
        objectArray[11] = "}.0i<9v!!&F=e 1ip9r";
        objectArray[12] = "\u000e\"e*Sw\u0007\"f*_";
        objectArray[13] = "K!9[4&@!1";
        objectArray[14] = "\u0003?x\r23v\u001fs\u0002#|\u0017\u0011x\t'&c";
        objectArray[15] = Void.TYPE;
        SpearReach.A[15] = "java/lang/Void";
        objectArray[16] = "+A\u0014\u000e\u0012p^a\u001f\u0001\u0003??o\u0014\n\u0007eK";
        objectArray[17] = "l@*<{\u001cl@=`w\u0013v\u000b=~w\u0006qzo!&L";
        objectArray[18] = "-8y6n.X\u0018r9\u007fa9\u0016y2{;M";
        objectArray[19] = "\u0018nFS.Y\tnm";
        objectArray[20] = "-\u0000#b^hX (mO'9.#fK}M";
        objectArray[21] = "%\";D\u0018PP\u00020K\t\u001f1\f;@\rEE";
        objectArray[22] = "\u000b\n\n'Y>\u001a\n-";
        objectArray[23] = "w\u0004=\u001e4F|\u000b,QI^o\f%\u0018";
        objectArray[24] = "woq\u0017\u0005.2f{Zo9N'kI\b'\u007fvtI\u0015";
        objectArray[25] = ">\u000bNrUsnKDBR\u0011.\n\u000b0_t2]\\";
        objectArray[26] = "]lQ\u0006/,\u0018e[KE6dyY\\,<]w@\u00009]^kU@%fXoV\\E";
        objectArray[27] = "[E\u0016}\"P_X\u001bl\u001dK`\u0002\u0019nfA[\u0004\u001dmz!";
        objectArray[28] = "wr\u0017u/o2{\u001d8EdN0\u00126>~u6\u00165\"";
        objectArray[29] = "Y> (d \u001c7*e\u000e8`+(rg0Y%1.rQ\n7 nj!\u0000(9o\u000e";
        objectArray[30] = "#JO\u0006u\u0003fCEK\u001f\n\u001a\u000fPFfKh\u000b\u0005D&";
        objectArray[31] = "\u0019zQ\u0007%K\\s[JO_ 2KY(B\u0011cTY5";
        objectArray[32] = "\bct&\u0000uMj~kjc1'gqTjXuck\u0006";
        objectArray[33] = "C6d^\u0011dIj=]/\u001e5\u0012\u0017isUC6d^\u0011dIj=]";
        objectArray[34] = "<\u001d<O]\u001by\u00146\u00027\u0003\u0005\b4\u0015^\u000b<\u0006-IKj?\u001a8\tWQ9\u001e;\u00157";
        objectArray[35] = "5\u001b\u007f$f\u0006p\u0012ui\f\u001c\f\u000ew~e\u00165\u0000n\"pwe\u001f>fe\u0010jR{z\f";
        objectArray[36] = "m(#NN}cvd\t$k\u0003(<SFa8\u007feW\u0018\u0000>\"\"H\u001dr:w \b$";
        objectArray[37] = "I\"Jei\b\f+@(\u0003\u0000p`O&x\u0019KfK%d";
        objectArray[38] = "\u0005\u000b\t\u001ctE@\u0002\u0003Q\u001e]<\u001e\u0001FwU\u0005\u0010\u0018\u001ab4\u0001\u0016\u000eX'F\u0005C\f\u0018\u001e";
        objectArray[39] = "-aa:Hk\"d}95fAfoxNoz`k{R\u000f( +y\\h'mne5";
        objectArray[40] = "b\u007f]tMllhU~}\u007f\\9Nw\u0011/ljQ}\u0002\u0016";
        objectArray[41] = "@m\u007fz)zDprk\u0016`{*pimk@,tjq\u000b";
        objectArray[42] = "V\u001f<)\u001d\n\u0013\u00166dw\u0012oX#n\u0014\u001e\u0017\f4-F{P\u0002<w\u0012\u0003\u0004\u0015\u007f%w";
        objectArray[43] = "\n\u0016\n(h\u007fZV\u0000\u0018b\u001d\fT\u0015qg$\u0002MId\u0006t\u001d\u001d\rqa{PX\u0011\u0018";
        Object[] objectArray2 = objectArray;
        objectArray[44] = "\u0016t\u0000h\u0018jS}\n%rw/a\b2\u001bz\u0016o\u0011n\u000e\u001b\u0012i\u0007,Ki\u0016<\u0005lr";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = SpearReach.e(l2, l3);
            object = z[n2];
            try {
                if (!(object instanceof String)) break block2;
                SpearReach.z[n2] = clazz = Class.forName(A[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = SpearReach.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = SpearReach.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = SpearReach.e(l2, l3);
        Object object = z[n2];
        if (object instanceof String) {
            String string = A[n2];
            int n3 = string.indexOf(8);
            Class clazz = SpearReach.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = SpearReach.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = SpearReach.c(clazz3, string2, clazz2)) != null) {
                    SpearReach.z[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = SpearReach.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        SpearReach.z[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = SpearReach.f(707970231190400L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = SpearReach.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = SpearReach.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = SpearReach.e(l2, l3);
        Object object = z[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = A[n2];
                int n4 = string2.indexOf(8);
                clazz3 = SpearReach.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = SpearReach.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = SpearReach.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        SpearReach.z[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = SpearReach.f(707970231190400L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = SpearReach.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        SpearReach.z[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = SpearReach.f(707970231190400L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == '\u00e7' || c2 == 'w' || c2 == 'R' || c2 == '\u00f8') {
                field = SpearReach.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == '\u00e7' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == 'w' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == 'R' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = SpearReach.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == '\u00eb' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == 'H' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = SpearReach.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_2().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/c/W" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(SpearReach.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(SpearReach.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_2() {
        try {
            return MethodHandles.lookup().findStatic(SpearReach.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

