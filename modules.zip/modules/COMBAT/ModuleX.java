// === Kuzi module: ModuleX ===
// Category   : COMBAT
// Description: 
// Payload    : a.a.a.j.c.X (verified: False)

package kuzi.modules.combat;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.Map;
import java.util.Random;
import kn.bb542ffe4b746c218.L;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.g.a.q;
import kuzi.obf.h.b.k;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.LivingEntity;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class ModuleX
extends BaseModule
implements q {
    private final k m;
    private final BoolSetting n;
    private final BoolSetting o;
    private final BoolSetting p;
    private final BoolSetting q;
    private final BoolSetting r;
    private final BoolSetting s;
    private final SliderSetting t;
    private final SliderSetting u;
    private final SliderSetting v;
    private final k w;
    private final BoolSetting x;
    private final k y;
    private final k z;
    private final BoolSetting A;
    private final BoolSetting B;
    private final BoolSetting C;
    private final Random D;
    private boolean E;
    private boolean F;
    private int G;
    private long H;
    private long I;
    private long J;
    private LivingEntity K;
    private boolean L;
    private double M;
    private long N;
    private static final long O;
    private static final String[] P;
    private static final String[] Q;
    private static final Map R;

    public ModuleX() {
        long l2 = O ^ 0x461DC25491CCL;
        long l3 = l2 ^ 0x74C7CD276867L;
        super((String)((Object)ModuleX.b("x", (int)32435, (long)(0x2C3E803E395DBA3AL ^ l2))), (String)((Object)ModuleX.b("x", (int)31070, (long)(0x5E940A526A483DDAL ^ l2))), Category.COMBAT);
        this.m = new k((String)((Object)ModuleX.b("x", (int)16723, (long)(0x41D943F73C3485DCL ^ l2))), 0.0, 3.0, 0.05, 2.6, 3.0);
        this.n = new BoolSetting((String)((Object)ModuleX.b("x", (int)14968, (long)(0x53EE85BFCE88FEF8L ^ l2))), true);
        this.o = new BoolSetting((String)((Object)ModuleX.b("x", (int)28278, (long)(0x550BA834CD1A2AFCL ^ l2))), false);
        this.p = new BoolSetting((String)((Object)ModuleX.b("x", (int)29448, (long)(0x48EAE62FD848B78EL ^ l2))), false);
        this.q = new BoolSetting((String)((Object)ModuleX.b("x", (int)14439, (long)(0x24B7F755FF58FCE6L ^ l2))), false);
        this.r = new BoolSetting((String)((Object)ModuleX.b("x", (int)391, (long)(0x3DD334FF14CA451FL ^ l2))), false);
        this.s = new BoolSetting((String)((Object)ModuleX.b("x", (int)12711, (long)(0x22E09A84D0CB753CL ^ l2))), false);
        this.t = new SliderSetting((String)((Object)ModuleX.b("x", (int)32184, (long)(0x76F8CF7354DCB934L ^ l2))), 1.0, 1.0, 9.0, 1.0);
        this.u = new SliderSetting((String)((Object)ModuleX.b("x", (int)6074, (long)(0x1A9C521EC833D331L ^ l2))), 100.0, 0.0, 100.0, 1.0);
        this.v = new SliderSetting((String)((Object)ModuleX.b("x", (int)16288, (long)(0x3E2D7EA8AF127B2DL ^ l2))), 0.0, 0.0, 100.0, 1.0);
        this.w = new k((String)((Object)ModuleX.b("x", (int)25657, (long)(0x77C3974F3AC5A0BCL ^ l2))), 0.0, 1000.0, 10.0, 90.0, 220.0);
        this.x = new BoolSetting((String)((Object)ModuleX.b("x", (int)29461, (long)(0x6D0E0DD1C56E379DL ^ l2))), false);
        this.y = new k((String)((Object)ModuleX.b("x", (int)29506, (long)(0x7B36F7872586B7CCL ^ l2))), 0.0, 200.0, 1.0, 10.0, 45.0);
        this.z = new k((String)((Object)ModuleX.b("x", (int)14714, (long)(0x504487D5F7C17DFDL ^ l2))), 0.0, 1000.0, 10.0, 120.0, 260.0);
        this.A = new BoolSetting((String)((Object)ModuleX.b("x", (int)7435, (long)(0x6923E354C551D991L ^ l2))), true);
        this.B = new BoolSetting((String)((Object)ModuleX.b("x", (int)30882, (long)(0x61210FBDBE59BC20L ^ l2))), false);
        this.C = new BoolSetting((String)((Object)ModuleX.b("x", (int)3297, (long)(0x2869FD96F77BC862L ^ l2))), true);
        this.D = new Random();
        this.E = false;
        this.F = false;
        this.G = -1;
        this.H = 0L;
        this.I = 0L;
        this.J = 0L;
        this.K = null;
        this.L = false;
        this.M = 3.0;
        this.N = 0L;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.m, this.n, this.o, this.p, this.q, this.r, this.s, this.t, this.u, this.v, this.w, this.x, this.y, this.z, this.A, this.B, this.C};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public native void d();

    @Override
    public native void e();

    @Override
    public native void a();

    private native void a(LivingEntity var1);

    private native boolean a();

    private native void b();

    private native boolean f();

    private native boolean g();

    private native boolean h();

    private native void c();

    private native boolean i();

    static {
        kn.bb542ffe4b746c218.L.init(ModuleX.class, 7);
        ModuleX.6137e06164c65df8();
    }

    private static native String b(byte[] var0);

    private static native String b(int var0, long var1);

    private static native Object b(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native CallSite b(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native /* synthetic */ void 6137e06164c65df8();
}

