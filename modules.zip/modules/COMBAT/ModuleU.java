// === Kuzi module: ModuleU ===
// Category   : COMBAT
// Description: 
// Payload    : a.a.a.j.c.u (verified: False)

package kuzi.modules.combat;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.util.Map;
import kn.bb542ffe4b746c218.L;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.module.Module;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.Entity;
import net.minecraft.Player;
import net.minecraft.ItemStack;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Duplicate member names - consider using --renamedupmembers true
 */
public class ModuleU
extends BaseModule
implements Module {
    private final SliderSetting m;
    private final BoolSetting n;
    private final SliderSetting o;
    private final BoolSetting p;
    private final BoolSetting q;
    private int r;
    private int s;
    private int t;
    private boolean u;
    private boolean v;
    private static final long w;
    private static final String[] x;
    private static final String[] y;
    private static final Map z;

    public ModuleU() {
        long l2 = w ^ 0x675A3210C2DBL;
        long l3 = l2 ^ 0x767F599782DFL;
        super((String)((Object)ModuleU.b("m", (int)29936, (long)(0x4455AA6EC15FAE42L ^ l2))), (String)((Object)ModuleU.b("m", (int)28991, (long)(0x71FE681933732B89L ^ l2))), Category.COMBAT);
        this.m = new SliderSetting((String)((Object)ModuleU.b("m", (int)26874, (long)(0x360E191D50383240L ^ l2))), 3.0, 2.0, 3.0, 0.1);
        this.n = new BoolSetting((String)((Object)ModuleU.b("m", (int)22431, (long)(0xB33B54B315B8D2EL ^ l2))), true);
        this.o = new SliderSetting((String)((Object)ModuleU.b("m", (int)10522, (long)(0x122986373CB973A7L ^ l2))), 1.0, 1.0, 10.0, 1.0);
        this.p = new BoolSetting((String)((Object)ModuleU.b("m", (int)1429, (long)(0x46ABCB21B1BDF20L ^ l2))), true);
        this.q = new BoolSetting((String)((Object)ModuleU.b("m", (int)30921, (long)(0x3F25D9E184BD2276L ^ l2))), true);
        this.r = -1;
        this.s = 0;
        this.t = -1;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.m, this.n, this.o, this.p, this.q};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public native void d();

    @Override
    public native void e();

    @Override
    public native void h();

    @Override
    public native void b();

    private native Player a();

    private native int a();

    private static native boolean a(ItemStack var0);

    private static native int a(ItemStack var0);

    private native void a();

    private native void c();

    private native void f();

    private static native boolean lambda$lookedAtPlayer$0(Entity var0);

    static {
        L.init(ModuleU.class, 6);
        ModuleU.6137e062e0513de1();
    }

    private static native String b(byte[] var0);

    private static native String b(int var0, long var1);

    private static native Object b(MethodHandles.Lookup var0, MutableCallSite var1, String var2, Object[] var3);

    private static native CallSite b(MethodHandles.Lookup var0, String var1, MethodType var2);

    private static native /* synthetic */ void 6137e062e0513de1();
}

