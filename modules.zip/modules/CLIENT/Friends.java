// === Kuzi module: Friends ===
// Category   : CLIENT
// Description: Manage your friends list
// Payload    : a.a.a.j.b.k (verified: True)

package kuzi.modules.client;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.modules.client.Kuzi;
import kuzi.obf.e.i;
import kuzi.obf.h.b.r;
import kuzi.obf.h.b.v;
import kuzi.obf.j.b.a;
import kuzi.obf.p.au;
import kuzi.obf.p.n;
import kuzi.settings.BoolSetting;
import net.minecraft.ClientPacketListener;
import net.minecraft.PlayerInfo;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class Friends
extends BaseModule {
    public final BoolSetting m = new BoolSetting("Notify On Join", true);
    public final BoolSetting n = new BoolSetting("Notify On Leave", true);
    public final BoolSetting o = new BoolSetting("Protect Friends", true);
    private final r friendsList = new r("Friends");
    private final Set onlineFriends = new HashSet();
    private final Set previousFriends = new HashSet();
    private static final long s;
    private static final String[] t;
    private static final String[] u;
    private static final Map v;
    private static final Object[] w;
    private static final String[] x;

    public Friends() {
        super("Friends", "Manage your friends list", Category.CLIENT);
        this.g.add(this.friendsList);
        this.g.add(this.o);
        this.g.add(this.m);
        this.g.add(this.n);
    }

    public List b(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = (l2 = s ^ l2) ^ 0x5E77F3C9D316L;
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l3;
        return this.friendsList.a(objectArray2);
    }

    public boolean a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = s ^ l2;
        return (Boolean)this.o.a();
    }

    public boolean d(Object[] objectArray) {
        List friends;
        long l2;
        String name;
        block11: {
            boolean listEmpty;
            block10: {
                block9: {
                    List resolvedFriends;
                    String[] stringArray;
                    block8: {
                        long l3;
                        long l4;
                        block7: {
                            boolean blank;
                            block6: {
                                block5: {
                                    String trimmed;
                                    block4: {
                                        l4 = (Long)objectArray[0];
                                        name = (String)objectArray[1];
                                        long l5 = l4 = s ^ l4;
                                        l2 = l5 ^ 0x5E1ADB9F3476L;
                                        l3 = l5 ^ 0x2A7378933B8L;
                                        stringArray = kuzi.obf.j.b.a.b();
                                        trimmed = name;
                                        if (stringArray == null) break block4;
                                        if (trimmed == null) break block5;
                                        trimmed = name.trim();
                                    }
                                    blank = trimmed.isEmpty();
                                    if (stringArray == null) break block6;
                                    if (!blank) break block7;
                                }
                                blank = false;
                            }
                            return blank;
                        }
                        Object[] objectArray2 = new Object[1];
                        objectArray2[0] = l3;
                        resolvedFriends = friends = this.b(objectArray2);
                        if (l4 <= 0L || stringArray == null) break block8;
                        if (resolvedFriends == null) break block9;
                        resolvedFriends = friends;
                    }
                    listEmpty = resolvedFriends.isEmpty();
                    if (stringArray == null) break block10;
                    if (!listEmpty) break block11;
                }
                listEmpty = false;
            }
            return listEmpty;
        }
        String lowerName = name.trim().toLowerCase();
        return friends.stream().map(arg_0 -> Friends.lambda$isFriend$0(l2, arg_0)).anyMatch(arg_0 -> Friends.lambda$isFriend$1(lowerName, arg_0));
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    @Override
    public void i() {
        block28: {
            block40: {
                block35: {
                    block27: {
                        block36: {
                            block26: {
                                block34: {
                                    block32: {
                                        block33: {
                                            block30: {
                                                block31: {
                                                    block29: {
                                                        v0 = var1_1 = Friends.s ^ 115484828746286L;
                                                        var3_2 = v0 ^ 17219103709536L;
                                                        var5_3 = v0 ^ 20672667028286L;
                                                        var7_4 = v0 ^ 2924687292689L;
                                                        var9_5 = kuzi.obf.j.b.a.b();
                                                        v1 = BaseModule.a;
                                                        if (var9_5 == null) break block29;
                                                        if (v1.player == null) break block30;
                                                        v1 = BaseModule.a;
                                                    }
                                                    if (var9_5 == null) break block31;
                                                    if (v1.level == null) break block30;
                                                    v1 = BaseModule.a;
                                                }
                                                v2 /* !! */  = v1.getConnection();
                                                if (var9_5 == null) break block32;
                                                if (v2 /* !! */  != null) break block33;
                                            }
                                            return;
                                        }
                                        v3 = this;
                                        if (var9_5 == null) break block34;
                                        v2 /* !! */  = v3.m.a();
                                    }
                                    if (!((Boolean)v2 /* !! */ ).booleanValue()) {
                                        v3 = this;
                                        if (var9_5 != null) {
                                            if (!((Boolean)v3.n.a()).booleanValue()) {
                                                return;
                                            } else {
                                                ** GOTO lbl-1000
                                            }
                                        }
                                    } else lbl-1000:
                                    // 3 sources

                                    {
                                        v3 = this;
                                    }
                                }
                                v3.onlineFriends.clear();
                                var10_6 = BaseModule.a.getConnection().getOnlinePlayers();
                                for (Object var12_8 : var10_6) {
                                    var13_9 = var12_8.getProfile().name();
                                    v4 = new Object[2];
                                    v4[1] = var13_9;
                                    v4[0] = var3_2;
                                    v5 = this.d(v4);
                                    if (var9_5 != null) {
                                        if (var9_5 != null && v5) {
                                            this.onlineFriends.add(var13_9);
                                        }
                                        if (var9_5 != null) continue;
                                    }
                                    break block26;
                                }
                                v5 = (Boolean)this.m.a();
                            }
                            if (var9_5 == null) break block35;
                            if (!v5) break block36;
                            v5 = this.previousFriends.isEmpty();
                            if (var9_5 == null) break block35;
                            if (v5) break block36;
                            var11_7 = new HashSet<E>(this.onlineFriends);
                            var11_7.removeAll(this.previousFriends);
                            for (String var13_9 : var11_7) {
                                block38: {
                                    block39: {
                                        block37: {
                                            v6 = Client.a();
                                            if (var9_5 == null) break block27;
                                            if (var9_5 == null) break block37;
                                            if (v6 == null) break block38;
                                            v7 = Client.a();
                                        }
                                        var14_10 = (Kuzi)v7.a(Kuzi.class);
                                        v8 = var14_10;
                                        if (var9_5 == null) break block39;
                                        if (v8 == null) break block38;
                                        v8 = var14_10.p.a();
                                    }
                                    if (((Boolean)v8).booleanValue()) {
                                        v9 = new Object[1];
                                        v9[0] = var5_3;
                                        v10 = new Object[4];
                                        v10[3] = kuzi.obf.p.n.FRIEND_JOIN;
                                        v10[2] = var13_9 + " joined the server";
                                        v10[1] = "Friend Joined";
                                        v10[0] = var7_4;
                                        au.a(v9).b(v10);
                                    }
                                }
                                if (var9_5 != null) continue;
                            }
                        }
                        v6 = this.n.a();
                    }
                    v5 = (Boolean)v6;
                }
                if (var9_5 == null) break block28;
                if (!v5) break block40;
                v5 = this.previousFriends.isEmpty();
                if (var9_5 == null) break block28;
                if (v5) break block40;
                var11_7 = new HashSet<E>(this.previousFriends);
                var11_7.removeAll(this.onlineFriends);
                for (String var13_9 : var11_7) {
                    block42: {
                        block43: {
                            block41: {
                                if (var9_5 == null) break block28;
                                v11 = Client.a();
                                if (var9_5 == null) break block41;
                                if (v11 == null) break block42;
                                v11 = Client.a();
                            }
                            var14_10 = (Kuzi)v11.a(Kuzi.class);
                            v12 = var14_10;
                            if (var9_5 == null) break block43;
                            if (v12 == null) break block42;
                            v12 = var14_10.p.a();
                        }
                        if (((Boolean)v12).booleanValue()) {
                            v13 = new Object[1];
                            v13[0] = var5_3;
                            v14 = new Object[4];
                            v14[3] = kuzi.obf.p.n.FRIEND_LEAVE;
                            v14[2] = var13_9 + " left the server";
                            v14[1] = "Friend Left";
                            v14[0] = var7_4;
                            au.a(v13).b(v14);
                        }
                    }
                    if (var9_5 != null) continue;
                }
            }
            this.previousFriends.clear();
            v5 = this.previousFriends.addAll(this.onlineFriends);
        }
    }

    @Override
    public void d() {
        block6: {
            ClientPacketListener connection;
            String[] stringArray;
            long l2;
            block5: {
                long l3 = s ^ 0x71133CA50502L;
                l2 = l3 ^ 0x17B2761B9E4CL;
                String[] stringArray2 = kuzi.obf.j.b.a.b();
                super.d();
                this.onlineFriends.clear();
                this.previousFriends.clear();
                stringArray = stringArray2;
                connection = BaseModule.a.getConnection();
                if (stringArray == null) break block5;
                if (connection == null) break block6;
                connection = BaseModule.a.getConnection();
            }
            Collection onlinePlayers = connection.getOnlinePlayers();
            for (PlayerInfo playerInfo : onlinePlayers) {
                String playerName = playerInfo.getProfile().name();
                Object[] objectArray = new Object[2];
                objectArray[1] = playerName;
                objectArray[0] = l2;
                boolean bl = this.d(objectArray);
                if (stringArray != null && bl) {
                    bl = this.previousFriends.add(playerName);
                }
                if (stringArray != null) continue;
            }
        }
    }

    @Override
    public void e() {
        super.e();
        this.onlineFriends.clear();
        this.previousFriends.clear();
    }

    public void a(Object[] objectArray) {
        block18: {
            Object object;
            String string;
            long l2;
            long l3;
            long l4;
            block22: {
                BaseModule baseModule;
                CallSite callSite;
                block20: {
                    i i2;
                    block21: {
                        String string2;
                        long l5;
                        long l6;
                        block19: {
                            String string3;
                            block17: {
                                string3 = (String)objectArray[0];
                                l4 = (Long)objectArray[1];
                                long l7 = l4 = s ^ l4;
                                l6 = l7 ^ 0x182AFB273022L;
                                l3 = l7 ^ 0x79DD4D4E12BCL;
                                l2 = l7 ^ 0x69B88345E093L;
                                l5 = l7 ^ 0x5E21CE428938L;
                                callSite = Friends.c("w", (long)-476010919312211657L, (long)l4);
                                try {
                                    try {
                                        string2 = string3;
                                        if (callSite == null) break block17;
                                        if (string2 == null) break block18;
                                    }
                                    catch (kuzi.obf.m.r r2) {
                                        throw Friends.c("w", (Object)r2, (long)-474190461490136630L, (long)l4);
                                    }
                                    string2 = string3.trim();
                                }
                                catch (kuzi.obf.m.r r3) {
                                    throw Friends.c("w", (Object)r3, (long)-474190461490136630L, (long)l4);
                                }
                            }
                            try {
                                try {
                                    if (callSite == null) break block19;
                                    if (string2.isEmpty()) break block18;
                                }
                                catch (kuzi.obf.m.r r4) {
                                    throw Friends.c("w", (Object)r4, (long)-474190461490136630L, (long)l4);
                                }
                                string2 = string3.trim();
                            }
                            catch (kuzi.obf.m.r r5) {
                                throw Friends.c("w", (Object)r5, (long)-474190461490136630L, (long)l4);
                            }
                        }
                        string = string2;
                        try {
                            baseModule = this;
                            if (l4 < 0L) break block20;
                            Object[] objectArray2 = new Object[2];
                            objectArray2[1] = l6;
                            objectArray2[0] = string;
                            Friends.c("V", (Object)Friends.c("L", (Object)baseModule, (long)-473063245034140085L, (long)l4), (Object)objectArray2, (long)-474642088889699773L, (long)l4);
                            Object[] objectArray3 = new Object[1];
                            objectArray3[0] = l5;
                            Friends.c("w", (Object)objectArray3, (long)-476102877373436508L, (long)l4);
                            i2 = Client.a();
                            if (callSite == null) break block21;
                            if (i2 == null) break block18;
                        }
                        catch (kuzi.obf.m.r r6) {
                            throw Friends.c("w", (Object)r6, (long)-474190461490136630L, (long)l4);
                        }
                        i2 = Client.a();
                    }
                    baseModule = i2.a(Kuzi.class);
                }
                Kuzi kuzi = (Kuzi)baseModule;
                try {
                    try {
                        object = kuzi;
                        if (l4 <= 0L || callSite == null) break block22;
                        if (object == null) break block18;
                    }
                    catch (kuzi.obf.m.r r7) {
                        throw Friends.c("w", (Object)r7, (long)-474190461490136630L, (long)l4);
                    }
                    object = Friends.c("V", (Object)Friends.c("L", (Object)kuzi, (long)-474740963446657804L, (long)l4), (long)-475033247523890073L, (long)l4);
                }
                catch (kuzi.obf.m.r r8) {
                    throw Friends.c("w", (Object)r8, (long)-474190461490136630L, (long)l4);
                }
            }
            try {
                if (((Boolean)object).booleanValue()) {
                    Object[] objectArray4 = new Object[1];
                    objectArray4[0] = l3;
                    Object[] objectArray5 = new Object[4];
                    objectArray5[3] = Friends.c("\u00c5", (long)-474614246031455999L, (long)l4);
                    objectArray5[2] = string + (String)((Object)Friends.b("i", (int)22708, (long)(0xC78CD7131677229L ^ l4)));
                    objectArray5[1] = Friends.b("i", (int)2665, (long)(0xF33ACC0161320FCL ^ l4));
                    objectArray5[0] = l2;
                    Friends.c("V", (Object)Friends.c("w", (Object)objectArray4, (long)-475061874956340757L, (long)l4), (Object)objectArray5, (long)-474088570920528239L, (long)l4);
                }
            }
            catch (kuzi.obf.m.r r9) {
                throw Friends.c("w", (Object)r9, (long)-474190461490136630L, (long)l4);
            }
        }
    }

    public void b(Object[] objectArray) {
        block14: {
            Object object;
            String string;
            long l2;
            long l3;
            long l4;
            block17: {
                BaseModule baseModule;
                CallSite callSite;
                block15: {
                    i i2;
                    block16: {
                        String string2;
                        long l5;
                        long l6;
                        block13: {
                            String string3 = (String)objectArray[0];
                            l4 = (Long)objectArray[1];
                            long l7 = l4 = s ^ l4;
                            l3 = l7 ^ 0x7695B2E00EAEL;
                            l6 = l7 ^ 0x4E30F363AEEBL;
                            l2 = l7 ^ 0x66F07CEBFC81L;
                            l5 = l7 ^ 0x516931EC952AL;
                            callSite = Friends.c("w", (long)-1912110232933343963L, (long)l4);
                            try {
                                try {
                                    string2 = string3;
                                    if (callSite == null) break block13;
                                    if (string2 == null) break block14;
                                }
                                catch (kuzi.obf.m.r r2) {
                                    throw Friends.c("w", (Object)r2, (long)-1911398704457292328L, (long)l4);
                                }
                                string2 = string3.trim();
                            }
                            catch (kuzi.obf.m.r r3) {
                                throw Friends.c("w", (Object)r3, (long)-1911398704457292328L, (long)l4);
                            }
                        }
                        string = string2;
                        try {
                            baseModule = this;
                            if (l4 <= 0L) break block15;
                            Object[] objectArray2 = new Object[2];
                            objectArray2[1] = string;
                            objectArray2[0] = l6;
                            Friends.c("V", (Object)Friends.c("L", (Object)baseModule, (long)-1910273683002469799L, (long)l4), (Object)objectArray2, (long)-1911536557192479284L, (long)l4);
                            Object[] objectArray3 = new Object[1];
                            objectArray3[0] = l5;
                            Friends.c("w", (Object)objectArray3, (long)-1912193947624312394L, (long)l4);
                            i2 = Client.a();
                            if (callSite == null) break block16;
                            if (i2 == null) break block14;
                        }
                        catch (kuzi.obf.m.r r4) {
                            throw Friends.c("w", (Object)r4, (long)-1911398704457292328L, (long)l4);
                        }
                        i2 = Client.a();
                    }
                    baseModule = i2.a(Kuzi.class);
                }
                Kuzi kuzi = (Kuzi)baseModule;
                try {
                    try {
                        object = kuzi;
                        if (l4 <= 0L || callSite == null) break block17;
                        if (object == null) break block14;
                    }
                    catch (kuzi.obf.m.r r5) {
                        throw Friends.c("w", (Object)r5, (long)-1911398704457292328L, (long)l4);
                    }
                    object = Friends.c("V", (Object)Friends.c("L", (Object)kuzi, (long)-1910811763989712666L, (long)l4), (long)-1911117717315223435L, (long)l4);
                }
                catch (kuzi.obf.m.r r6) {
                    throw Friends.c("w", (Object)r6, (long)-1911398704457292328L, (long)l4);
                }
            }
            try {
                if (((Boolean)object).booleanValue()) {
                    Object[] objectArray4 = new Object[1];
                    objectArray4[0] = l3;
                    Object[] objectArray5 = new Object[4];
                    objectArray5[3] = Friends.c("\u00c5", (long)-1911637014872094759L, (long)l4);
                    objectArray5[2] = string + (String)((Object)Friends.b("i", (int)3225, (long)(0xCE58FD3F55A3A19L ^ l4)));
                    objectArray5[1] = Friends.b("i", (int)3959, (long)(0x6DA77ED6CC8BB9F3L ^ l4));
                    objectArray5[0] = l2;
                    Friends.c("V", (Object)Friends.c("w", (Object)objectArray4, (long)-1911159063491940871L, (long)l4), (Object)objectArray5, (long)-1911287951193830781L, (long)l4);
                }
            }
            catch (kuzi.obf.m.r r7) {
                throw Friends.c("w", (Object)r7, (long)-1911398704457292328L, (long)l4);
            }
        }
    }

    private static boolean lambda$isFriend$1(String string, String string2) {
        return string2.equals(string);
    }

    private static String lambda$isFriend$0(long l2, String string) {
        String string2;
        block4: {
            block5: {
                l2 = s ^ l2;
                CallSite callSite = Friends.c("w", (long)1004553632308770211L, (long)l2);
                try {
                    try {
                        string2 = string;
                        if (callSite == null) break block4;
                        if (string2 == null) break block5;
                    }
                    catch (kuzi.obf.m.r r2) {
                        throw Friends.c("w", (Object)r2, (long)1008644594598382942L, (long)l2);
                    }
                    string2 = string.trim().toLowerCase();
                    break block4;
                }
                catch (kuzi.obf.m.r r3) {
                    throw Friends.c("w", (Object)r3, (long)1008644594598382942L, (long)l2);
                }
            }
            string2 = "";
        }
        return string2;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block11: {
            block10: {
                Friends.s = kuzi.obf.h.b.v.a(982926977453819667L, -140058778039322121L, MethodHandles.lookup().lookupClass()).a(15724509033974L);
                Friends.w = new Object[50];
                Friends.x = new String[50];
                Friends.c();
                Friends.v = new HashMap<K, V>(13);
                var0 = Friends.s ^ 114352922393859L;
                var2_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                v0 = SecretKeyFactory.getInstance("DES");
                v1 = new byte[8];
                v2 = v1;
                v1[0] = (byte)(var0 >>> 56);
                for (var3_2 = 1; var3_2 < 8; ++var3_2) {
                    v2 = v2;
                    v2[var3_2] = (byte)(var0 << var3_2 * 8 >>> 56);
                }
                var2_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                var9_3 = new String[14];
                var7_4 = 0;
                var6_5 = "\u008c\u00d6>^x%7\u0082B\u00d0\u0005#k\t\u00d6\u00e8 \u00cf\u00ae\u00a9\u00dc\u00fcl\u008c\u00cd\f\u0002\\\u00bd\u00b3J\u00de\n\u00cfA\u0001\u0004\u00be\u00ff\u00ec\u00b0 \u00a5\u0088\u00fe\u00e1\u0085\u0096t\u0018X\u00ab\u00b6\u00c6\u00d9H\u00c4z\u00de\u00f6\u008cI<\u00b6\u00aa\u00f94e\u00c7\u00a8\u0006\u00e0\u00db\u00c9(\u00cey\u0007\u00f6\u00dc\u0086#\u00f3\u0092\u00e3\u00c0B\u00d03\u0087\u0004\u0010\u0004\u00d4\u00a52\u0002'r\u00e0\u008f\u0090\u00ec\b \u0017\u0093\u0085\u00eb/E6q\u0015, \u00eb\u00cd\u0081J\u00f4\u008c\u000e\u00c7\u00d5L\u00ee\u00d8\u00f8\u00c5\u00f3\u0083\u009d\u009e\r\u00fdi\u007f\u008f\u0002\u001f\u008a\u0093\u00c1\u00a0\u0096\u00b5\u00c90rR\u00a2p\u0099\u00a9\u00f7\u00d6N\u00bd\u000f\u00b4\u00ea\u0018z6[\u00e7\u00dcG\r\u00df\u00de\u0007\u000f\u000f\u00c0\u009dF\u001e\u00ebv\u008b\u00f7\u00b7\u00aa\u00a3\u008c$\u00cc\u00abR\u0087B\u007fn\u00ec$(6d\u00b6\u00af\u00c1\u0011Kx]\u0012']9\u0096\u00a5u'%\u001f\u00beo\u00baK\u0012\b\u0094\u00ee\u0081\u000f\u00af9iP2t\u00c2\u000e\u00c3\u00db;\u0018)UCP\u00b6\u00e2\u00f9[\u0004\u00e2-\u00f4\u00f4\u00ac_C\u00b2\u00fb\u009d9\u001d\u0082\u00eb\u0083 \tm\u00d4\u00ef\u00f9A\u00d7\u0082=5\u0014\u00e2\u0017\u00ca8W\u00ac;\u00f8kG\u00ee\u0012\u00f05`\u0099\u00bb\u009e/\u008e@\u0018y\u00f6\u00edeX\u00f1\u001ft\u00acJt\u00b3\u00c0\u00a6\u00af\u00f5R)=\u00bb\u001d\u00ea\u00be'(P\u0096'\u0016\u0084\u00e9\u00db\t\u00ab\u00e3\u000e4+\u008a'\\\\)b{\u00b2\u00ca\u0095\u00c0 \u009b\u00d8\u00d43\u0083!\u008e\u00b2\u00e0S\u00b6m\u0084\u00e3N\u00187\u0090\u00f8\u0010TQi\u00bc\u00f1\u009a?\u00c8\u0084B\u00f2\u00f86E\u00dbD\"#\u0006\u00f0";
                var8_6 = "\u008c\u00d6>^x%7\u0082B\u00d0\u0005#k\t\u00d6\u00e8 \u00cf\u00ae\u00a9\u00dc\u00fcl\u008c\u00cd\f\u0002\\\u00bd\u00b3J\u00de\n\u00cfA\u0001\u0004\u00be\u00ff\u00ec\u00b0 \u00a5\u0088\u00fe\u00e1\u0085\u0096t\u0018X\u00ab\u00b6\u00c6\u00d9H\u00c4z\u00de\u00f6\u008cI<\u00b6\u00aa\u00f94e\u00c7\u00a8\u0006\u00e0\u00db\u00c9(\u00cey\u0007\u00f6\u00dc\u0086#\u00f3\u0092\u00e3\u00c0B\u00d03\u0087\u0004\u0010\u0004\u00d4\u00a52\u0002'r\u00e0\u008f\u0090\u00ec\b \u0017\u0093\u0085\u00eb/E6q\u0015, \u00eb\u00cd\u0081J\u00f4\u008c\u000e\u00c7\u00d5L\u00ee\u00d8\u00f8\u00c5\u00f3\u0083\u009d\u009e\r\u00fdi\u007f\u008f\u0002\u001f\u008a\u0093\u00c1\u00a0\u0096\u00b5\u00c90rR\u00a2p\u0099\u00a9\u00f7\u00d6N\u00bd\u000f\u00b4\u00ea\u0018z6[\u00e7\u00dcG\r\u00df\u00de\u0007\u000f\u000f\u00c0\u009dF\u001e\u00ebv\u008b\u00f7\u00b7\u00aa\u00a3\u008c$\u00cc\u00abR\u0087B\u007fn\u00ec$(6d\u00b6\u00af\u00c1\u0011Kx]\u0012']9\u0096\u00a5u'%\u001f\u00beo\u00baK\u0012\b\u0094\u00ee\u0081\u000f\u00af9iP2t\u00c2\u000e\u00c3\u00db;\u0018)UCP\u00b6\u00e2\u00f9[\u0004\u00e2-\u00f4\u00f4\u00ac_C\u00b2\u00fb\u009d9\u001d\u0082\u00eb\u0083 \tm\u00d4\u00ef\u00f9A\u00d7\u0082=5\u0014\u00e2\u0017\u00ca8W\u00ac;\u00f8kG\u00ee\u0012\u00f05`\u0099\u00bb\u009e/\u008e@\u0018y\u00f6\u00edeX\u00f1\u001ft\u00acJt\u00b3\u00c0\u00a6\u00af\u00f5R)=\u00bb\u001d\u00ea\u00be'(P\u0096'\u0016\u0084\u00e9\u00db\t\u00ab\u00e3\u000e4+\u008a'\\\\)b{\u00b2\u00ca\u0095\u00c0 \u009b\u00d8\u00d43\u0083!\u008e\u00b2\u00e0S\u00b6m\u0084\u00e3N\u00187\u0090\u00f8\u0010TQi\u00bc\u00f1\u009a?\u00c8\u0084B\u00f2\u00f86E\u00dbD\"#\u0006\u00f0".length();
                var5_7 = 16;
                var4_8 = -1;
lbl23:
                // 2 sources

                while (true) {
                    v3 = ++var4_8;
                    v4 = var6_5.substring(v3, v3 + var5_7);
                    v5 = -1;
                    break block10;
                    break;
                }
lbl28:
                // 1 sources

                while (true) {
                    var9_3[var7_4++] = Friends.b(var10_9).intern();
                    if ((var4_8 += var5_7) < var8_6) {
                        var5_7 = var6_5.charAt(var4_8);
                        ** continue;
                    }
                    var6_5 = "\u001c!M\u00b5\u0017\u00d0\",\u00b8\u0082\u00b0\u00f5\u00ad\u001a\u0015\u00ca\u00f43m`7L\u00ee\u00b8]\u00fe\u00f7P\u001a\u0017\u0007Z\u00beP\u00db%\u0014\u008bX\"\u0010\u0017\u00e8L\u00e3)\u00ffg\u00fe\u009eDW]\u00cfc\u00a1\u00fc";
                    var8_6 = "\u001c!M\u00b5\u0017\u00d0\",\u00b8\u0082\u00b0\u00f5\u00ad\u001a\u0015\u00ca\u00f43m`7L\u00ee\u00b8]\u00fe\u00f7P\u001a\u0017\u0007Z\u00beP\u00db%\u0014\u008bX\"\u0010\u0017\u00e8L\u00e3)\u00ffg\u00fe\u009eDW]\u00cfc\u00a1\u00fc".length();
                    var5_7 = 40;
                    var4_8 = -1;
lbl37:
                    // 2 sources

                    while (true) {
                        v6 = ++var4_8;
                        v4 = var6_5.substring(v6, v6 + var5_7);
                        v5 = 0;
                        break block10;
                        break;
                    }
                    break;
                }
lbl42:
                // 1 sources

                while (true) {
                    var9_3[var7_4++] = Friends.b(var10_9).intern();
                    if ((var4_8 += var5_7) < var8_6) {
                        var5_7 = var6_5.charAt(var4_8);
                        ** continue;
                    }
                    break block11;
                    break;
                }
            }
            var10_9 = var2_1.doFinal(v4.getBytes("ISO-8859-1"));
            switch (v5) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl54:
                // 1 sources

                ** continue;
            }
        }
        Friends.t = var9_3;
        Friends.u = new String[14];
    }

    private static kuzi.obf.m.r a(kuzi.obf.m.r r2) {
        return r2;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static String b(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x53FD;
        if (u[n3] == null) {
            Object[] objectArray;
            try {
                Long l3 = Thread.currentThread().threadId();
                objectArray = (Object[])v.get(l3);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    v.put(l3, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/b/k", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l2 >>> 56);
            for (int i2 = 1; i2 < 8; ++i2) {
                byArray[i2] = (byte)(l2 << i2 * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = t[n3].getBytes("ISO-8859-1");
            Friends.u[n3] = Friends.b(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return u[n3];
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        String string2 = Friends.b(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static CallSite b(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/b/k" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (x[n4] != null) {
            return n4;
        }
        Object object = w[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 33;
            case 1 -> 52;
            case 2 -> 2;
            case 3 -> 41;
            case 4 -> 40;
            case 5 -> 47;
            case 6 -> 54;
            case 7 -> 42;
            case 8 -> 21;
            case 9 -> 23;
            case 10 -> 46;
            case 11 -> 24;
            case 12 -> 20;
            case 13 -> 62;
            case 14 -> 31;
            case 15 -> 4;
            case 16 -> 5;
            case 17 -> 36;
            case 18 -> 57;
            case 19 -> 39;
            case 20 -> 55;
            case 21 -> 50;
            case 22 -> 18;
            case 23 -> 60;
            case 24 -> 28;
            case 25 -> 26;
            case 26 -> 0;
            case 27 -> 7;
            case 28 -> 63;
            case 29 -> 25;
            case 30 -> 53;
            case 31 -> 3;
            case 32 -> 35;
            case 33 -> 22;
            case 34 -> 13;
            case 35 -> 61;
            case 36 -> 9;
            case 37 -> 48;
            case 38 -> 27;
            case 39 -> 19;
            case 40 -> 1;
            case 41 -> 29;
            case 42 -> 6;
            case 43 -> 44;
            case 44 -> 8;
            case 45 -> 14;
            case 46 -> 43;
            case 47 -> 59;
            case 48 -> 10;
            case 49 -> 12;
            case 50 -> 56;
            case 51 -> 34;
            case 52 -> 45;
            case 53 -> 16;
            case 54 -> 37;
            case 55 -> 38;
            case 56 -> 17;
            case 57 -> 51;
            case 58 -> 15;
            case 59 -> 58;
            case 60 -> 30;
            case 61 -> 32;
            case 62 -> 11;
            default -> 49;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        Friends.x[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = w;
        w[0] = "reS}5_{eP}&";
        objectArray[1] = "\u001c/CPd(i\u000fH_ug\b\u0001CTq=|";
        objectArray[2] = "Fm\u001fS\u0015\u000eXe\u0005\u001cw\u0012_x";
        objectArray[3] = ";*1io\r0*2ie";
        objectArray[4] = "\u001f[B90\u0000\u000e[e";
        objectArray[5] = "_B&\u0000kD*b-\u000fz\u000bKl&\u0004~Q?";
        objectArray[6] = Void.TYPE;
        Friends.x[6] = "java/lang/Void";
        objectArray[7] = "sMAC3\u0004xMBC3";
        objectArray[8] = "eGi+6!\u0010gb$'nm\u007fq#.'\u0005";
        objectArray[9] = "UH\t\ne}YH\u001a";
        objectArray[10] = "#H-\u0016$v2H-M";
        objectArray[11] = "\u007fKe\u007fy_\nknph\u0010kee{lJ\u001f";
        objectArray[12] = "\u000b\u001dQ{pM\u0000\u001dR{v";
        objectArray[13] = "\u0013F\u000f<x@\u001aF\f<z";
        objectArray[14] = "qQ6$9\u001f\u0004q=+(Pe\u007f6 ,\n\u0011";
        objectArray[15] = "}a\u0005f\u00103la\n";
        objectArray[16] = "%8\u0015/,\u0014P\u0018\u001e =[1\u0016\u0015+9\u0001E";
        objectArray[17] = "F\r9\u0007\u0012|O\r:\u0007\u0012";
        objectArray[18] = "YWJk6\u0013RX[$W\u001dYS_~";
        objectArray[19] = "w\u0007[!`H\u0002'P.q\u0007c)[%u]\u0017";
        objectArray[20] = "m}3T79f}8";
        objectArray[21] = "A-\r\u0000qtA-\u001a\\}{[f\u001aB}n\\\u0017J\u001f,";
        objectArray[22] = "*\u0016=\u000elq4\u001e'A\u0011a4";
        objectArray[23] = "\u001dA9\u0011n#ha2\u001e\u007fl\to9\u0015{6}";
        objectArray[24] = Boolean.TYPE;
        Friends.x[24] = "java/lang/Boolean";
        objectArray[25] = "\u001a5iX7>\u00115a";
        objectArray[26] = "j(\b\u0015\u001fA\u001f\b\u0003\u001a\u000e\u000e~\u0006\b\u0011\nT\n";
        objectArray[27] = "vK9\u001e\u0013)!C7\u0010ux\u001bC/\u0015HkwDk\\H";
        objectArray[28] = "8.\"\u0015P2m&2\u001a99\u0002#e\u0017H1l|'MUS;?`HE?<{)H9";
        objectArray[29] = "\u001e'e3\u000b$I/k=mss{~<\tcCfo`\\";
        objectArray[30] = "v#e!HOtg>.(_M~;sYT#!y)D6q}4-IIp~u+(";
        objectArray[31] = "\u0003x39\u0006!\u0000}4xl*>'p{\b;@~!3\u0003@";
        objectArray[32] = "`\u00019{+55\t)tB.Z\u0003#|$4%\u0012$f,";
        objectArray[33] = "\u0000(JG;kU ZHRc:zP].sA?RK(\n\u0004'I[+qA%_]R";
        objectArray[34] = "\u007fE\u0012\r*\u000e0H\u0004\u0016Q\u000e@HS\u0011 \u0006.\u0017\u0011K=d|K\\O0\u001b}H\u001dIQ";
        objectArray[35] = "!A5rU)tI%}<.\u001b\u001cuk\u0002#&V|qN";
        objectArray[36] = "(z2c\u001c8)zn7r\u000e\fW\u001d\u001a.E(z2c\u001c8)zn7";
        objectArray[37] = "7J\u0014,C\u000bbB\u0004#*\u0006\rGS.[\bc\u0018\u0011tFjm\u001eT0\u0012\u0004d^\u0001<*";
        objectArray[38] = " L\u001eI{\u001b%A\u0010@\u001d>\u0013i:oQ'\re>wPp L\u001eI{\u001b%A\u0010@";
        objectArray[39] = "^29\u0006wa\u00006n|k\u0013\u0002ba\re}] ;\u0010\u0007/\u0001m?\u001dx.\u0002,9|";
        objectArray[40] = "=sSe$Yh{CjMA\u0007qIb+Xx`Nx#";
        objectArray[41] = "VT\u0017X\u0015\u0018\u001eO\tC~\u0012f\u001bMD@\u0001[QD^\f";
        objectArray[42] = "U\u0003E:me\u000b\u0007\u0012@v\u0017\tS\u001d1\u007fyV\u0011G,\u001d+\n\\C!b*\t\u001dE@";
        objectArray[43] = "\bBb\u000bP#\rOl\u00026\u0006;gF-z\u001f#aJ-6!\u0005Ok\r]$\bAb";
        objectArray[44] = "'D\u0011]\t\u0013hI\u0007Fr\u0010\u0018IPA\u0003\u001bv\u0016\u0012\u001b\u001ey'D\u0011]\t\u0013hI\u0007Fr";
        objectArray[45] = "\"FvU\u0016) \u0002lP+<I\u0017'WW</\u0007eWSU";
        objectArray[46] = "Z`<g*1\u000fh,hC5`=|~};]wud1";
        objectArray[47] = " \t\u007f*b<~\r(P{N|Y'!p #\u001b}<\u0012w`\\x,~p$\u0015xP";
        objectArray[48] = ">6\\\u0014t.k>L\u001b\u001d(\u0004k\u001c\r#$9!\u0015\u0017o";
        Object[] objectArray2 = objectArray;
        objectArray[49] = "j`\u000b\u001f&h?h\u001b\u0010OqP1\u001cE5y\"o\u0018\u0012";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = Friends.e(l2, l3);
            object = w[n2];
            try {
                if (!(object instanceof String)) break block2;
                Friends.w[n2] = clazz = Class.forName(x[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = Friends.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = Friends.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = Friends.e(l2, l3);
        Object object = w[n2];
        if (object instanceof String) {
            String string = x[n2];
            int n3 = string.indexOf(8);
            Class clazz = Friends.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = Friends.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = Friends.c(clazz3, string2, clazz2)) != null) {
                    Friends.w[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = Friends.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        Friends.w[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = Friends.f(1326063792034573L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = Friends.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = Friends.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = Friends.e(l2, l3);
        Object object = w[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = x[n2];
                int n4 = string2.indexOf(8);
                clazz3 = Friends.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = Friends.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = Friends.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        Friends.w[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = Friends.f(1326063792034573L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = Friends.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        Friends.w[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = Friends.f(1326063792034573L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == 'L' || c2 == '\u00ed' || c2 == '\u00c5' || c2 == 'N') {
                field = Friends.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == 'L' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == '\u00ed' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == '\u00c5' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = Friends.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == 'V' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == 'w' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = Friends.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/b/k" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Friends.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(Friends.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

