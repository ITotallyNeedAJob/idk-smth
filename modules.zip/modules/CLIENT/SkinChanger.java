// === Kuzi module: SkinChanger ===
// Category   : CLIENT
// Description: Changes your skin client-side to another player's skin
// Payload    : a.a.a.j.e.ad (verified: True)

package kuzi.modules.client;

import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.mixin.MixinExposed;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.b.v;
import kuzi.obf.j.e.am;
import kuzi.settings.Setting;
import kuzi.settings.StringSetting;
import net.minecraft.Identifier;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class SkinChanger
extends BaseModule {
    private final StringSetting targetUsername;
    private Identifier skinIdentifier;
    private String lastUsername;
    private final AtomicBoolean fetching;
    private volatile String lastRequestedName;
    private volatile long lastRequestTime;
    private static final long s;
    private static final long t;
    private static final String[] u;
    private static final String[] v;
    private static final Map w;
    private static final long[] x;
    private static final Integer[] y;
    private static final Map z;
    private static final long[] A;
    private static final Long[] B;
    private static final Map C;
    private static final Object[] D;
    private static final String[] E;

    public SkinChanger() {
        long l2 = t ^ 0x5F779AB7CE27L;
        long l3 = l2 ^ 0x54673DBB0920L;
        super("SkinChanger", "Changes your skin client-side to another player's skin", Category.CLIENT);
        this.targetUsername = new StringSetting("Target Username", "DrDonutt");
        this.skinIdentifier = null;
        this.lastUsername = "";
        this.fetching = new AtomicBoolean();
        this.lastRequestedName = "";
        this.lastRequestTime = 0L;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.targetUsername};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        long l2 = t ^ 0x417E1007FBDFL;
        long l3 = l2 ^ 0xA6BC849770L;
        super.d();
        this.skinIdentifier = null;
        this.lastUsername = "";
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.a(objectArray);
    }

    @Override
    public void e() {
        super.e();
        this.skinIdentifier = null;
        this.lastUsername = "";
    }

    @MixinExposed
    public String c() {
        return (String)this.targetUsername.a();
    }

    @MixinExposed
    public boolean a() {
        return this.d();
    }

    @MixinExposed
    public Identifier a() {
        SkinChanger module;
        block4: {
            block5: {
                SkinChanger moduleRef;
                long l2;
                block2: {
                    block3: {
                        long l3 = t ^ 0x409F507E621FL;
                        l2 = l3 ^ 0x147FCFD0EB0L;
                        String targetName = (String)this.targetUsername.a();
                        String stringTable = am.b();
                        moduleRef = this;
                        if (stringTable == null) break block2;
                        if (moduleRef.skinIdentifier == null) break block3;
                        module = this;
                        if (stringTable == null) break block4;
                        if (module.lastUsername.equals(targetName)) break block5;
                    }
                    moduleRef = this;
                }
                Object[] objectArray = new Object[1];
                objectArray[0] = l2;
                moduleRef.a(objectArray);
            }
            module = this;
        }
        return module.skinIdentifier;
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private void a(Object[] var1_1) {
        block16: {
            block17: {
                block14: {
                    block15: {
                        block13: {
                            block12: {
                                block11: {
                                    var2_2 = (Long)var1_1[0];
                                    var4_3 = (var2_2 = SkinChanger.t ^ var2_2) ^ 40680561191815L;
                                    username = (String)this.targetUsername.a();
                                    stringTable = am.b();
                                    usernameCopy = username;
                                    if (stringTable == null) break block11;
                                    if (usernameCopy == null) break block12;
                                    usernameCopy = username;
                                }
                                if (!usernameCopy.isEmpty()) break block13;
                            }
                            return;
                        }
                        now = System.currentTimeMillis();
                        v1 = sameUsername = username.equals(this.lastRequestedName);
                        if (stringTable == null) break block14;
                        if (v1 == 0) break block15;
                        cfr_temp_0 = now - this.lastRequestTime - SkinChanger.d("i", (int)24976, (long)(5811028308642996535L ^ var2_2));
                        v1 = cfr_temp_0 == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1);
                        if (stringTable != null) {
                            if (v1 < 0) {
                                return;
                            } else {
                                ** GOTO lbl26
                            }
                        }
                        break block14;
                    }
                    if (var2_2 <= 0L) break block16;
                    v2 = this;
                    if (stringTable == null) break block17;
                    v1 = v2.fetching.compareAndSet(false, true);
                }
                if (v1 == 0) {
                    return;
                }
                this.lastRequestedName = username;
                this.lastRequestTime = now;
                v2 = this;
            }
            CompletableFuture.runAsync((Runnable)LambdaMetafactory.metafactory(null, null, null, ()V, lambda$fetchAndCacheSkin$0(long java.lang.String ), ()V)((SkinChanger)v2, (long)var4_3, (String)username));
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void lambda$fetchAndCacheSkin$0(long l2, String username) {
        block13: {
            long l3 = l2 = t ^ l2;
            long l4 = l3 ^ 0x6B1E818C9708L;
            long l5 = l3 ^ 0x791AD566417CL;
            long l6 = l3 ^ 0x274C0127C091L;
            CallSite callSite = SkinChanger.f("\u00c3", (long)1963303715325688228L, (long)l2);
            try {
                CallSite callSite2;
                block14: {
                    CallSite callSite3;
                    block12: {
                        block11: {
                            Object[] objectArray = new Object[2];
                            objectArray[1] = l4;
                            objectArray[0] = username;
                            callSite3 = SkinChanger.f("\u00f6", (Object)this, (Object)objectArray, (long)1959663391321340996L, (long)l2);
                            try {
                                if (callSite == null) break block11;
                                if (callSite3 != null) break block12;
                            }
                            catch (Exception exception) {
                                throw SkinChanger.f("\u00c3", (Object)exception, (long)1962792781878146290L, (long)l2);
                            }
                        }
                        return;
                    }
                    Object[] objectArray = new Object[2];
                    objectArray[1] = callSite3;
                    objectArray[0] = l5;
                    callSite2 = SkinChanger.f("\u00f6", (Object)this, (Object)objectArray, (long)1963473016117066987L, (long)l2);
                    try {
                        CallSite callSite4 = callSite;
                        if (l2 > 0L) {
                            if (callSite4 == null) break block13;
                            callSite4 = callSite2;
                        }
                        if (callSite4 != null) break block14;
                    }
                    catch (Exception exception) {
                        throw SkinChanger.f("\u00c3", (Object)exception, (long)1962792781878146290L, (long)l2);
                    }
                    return;
                }
                Object[] objectArray = new Object[3];
                objectArray[2] = username;
                objectArray[1] = l6;
                objectArray[0] = callSite2;
                SkinChanger.f("\u00f6", (Object)this, (Object)objectArray, (long)1962537126988624776L, (long)l2);
            }
            catch (Exception exception) {
            }
            finally {
                ((AtomicBoolean)((Object)SkinChanger.f("\u00db", (Object)this, (long)1962820462441580241L, (long)l2))).set(false);
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block26: {
            block25: {
                block24: {
                    block23: {
                        block22: {
                            block21: {
                                SkinChanger.t = kuzi.obf.h.b.v.a(-104708591982965103L, 2259809830452983580L, MethodHandles.lookup().lookupClass()).a(212634244144252L);
                                SkinChanger.D = new Object[38];
                                SkinChanger.E = new String[38];
                                SkinChanger.f();
                                SkinChanger.w = new HashMap<K, V>(13);
                                var22 = SkinChanger.t ^ 98693605960659L;
                                var24_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                                v0 = SecretKeyFactory.getInstance("DES");
                                v1 = new byte[8];
                                v2 = v1;
                                v1[0] = (byte)(var22 >>> 56);
                                for (var25_2 = 1; var25_2 < 8; ++var25_2) {
                                    v2 = v2;
                                    v2[var25_2] = (byte)(var22 << var25_2 * 8 >>> 56);
                                }
                                var24_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                                var31_3 = new String[20];
                                var29_4 = 0;
                                var28_5 = "vUW\u00d7\b\u00ac\u00a2\u00f2p\u00d1\u00bb\u00f3\u008b\u00ce\u00d8$l\u0098\u0095\u00cd\u00a4V\u00a8\u00d3\u0018W\u00bb\u000b\u0089\u00d9W\u00b9#o\u00d7\u00ce\u00ad\u0005\u00f0\u009baH3\u00cf\u00c4\u0084\u0005\u00a4\u0014\u0010\u0094y\u00b3\u008b\u00a6F\b\u0011\u00c5\u00d4\u00af\u001aTW\u00c4\u00ed wr\u0001]\u00fd\u00d2%\u00adJV\u00d1\u00cf\u00db\u008aQ\u00ac-\u00d4Jf\u00f6\u00e0V\u0004\u00bc\u00ec\u00ae[V\u00ef\u0007OP\u001e\u00c03\u0010z\u00beU\u0007S\u00f6\u00ba\u00df\u00f0=\u00b5\u009e\u00a0\u00d5g\u0098H\u000e\u00d4\u00da\u00f6\u00e7\u00a1mC\u00bdl\u001d'\u0000\u0013\u00eb\u00e0D\u000b\u00a7\u00a4s\u00c6\u00ba!\u001e\u0011\u00ac\u00cc\u0093r\u00e6\u00b5x\u00cf\u001f8\u00b1\u00862\u00002\u009bg\u00fb\u00819\u00c9\u0014y=\u00c6b\u00feY\u00ce\u00bf\u0092\u0093?\u0010\u00b1*\u0013\u00bb{\u00cf\u0018+\u00ea\u0085\u008f\u0087\u00df\u0011\u00d9\u0088\u0010b\u00c3\u0092\u00d1\u0094\u001e\u00ba\u00db\u00062\u0013L\u00d8\u00f53f\u0010T\u00b1\u00f4G\u00e6GG\u00c0\u0082\u00c2N|\u00f5\u00ca1J\u0018\u00faL\u00c8\u00d3>\u008c\u00feh[<|\u00d0\u00830\u00c8\u0016\u008dhJwg\u0081 8\u0010i3\u000f%\u00a5n\u00c4\u0081\u007f:\u00aa/5\u00f3\u00d8B\u0010e\u00f5\u00e7\u00fet4\u00de\u00ed\u00e5\u00f6?>\u00ecV\u00ce\u008fX4\u0005\u00beC\u001er\u00f1\u00ffq\u00e2\u00e9L\u00a6\u001c\u001a\u0081\u000fI?w\u0083v\u0098\u00e2\u00f8\u00db\u001d4\u00a6\u00bd\u0015q\u00b4@\u00bf\u00e5Da\u00fa:<\u0087T\u00f9\u009e\u00aa\u0094\u00dc\u00d7&\u0012[t\u001d:\u00efPH\u0012`\u00af%\u0094\u00a0O<b\u00d6\u00f4\u00c4\bY\u00c1\u00d3\u0014\u00a2g3rEZcDAN\u00ef\u00c2\u008f\u0018?\u008a,\u008ar\u00c1\u0086\u00e3\u00b3\u00da\u00a75\u00c1\u00a6K\u00ba\u00a3,\u00fe\u00a7\u009f_\u00f0j +\u000be\u008b\u00cf0c\u001dl\u0081\u00d7\u00efBs\u00af\u00ef\u00b59\\\u0080B{\f\u00a62\u008eg\u00cc\u00fb\u00ce\u00fb\u0005`\u00df\u0080}\u00b3[1\u00f8\u0097X\u00bb\u00d2\u00b3X\u00b4\u00c3\u00a3=\u000b\u00b2\u00aa<\u00e6Xpl\u0003\u0007\u009f\u0018D\u0007\u00c2\u008cU\u00841\u0098<\u00b0\"\u00ddnq\u0082\u0007\u00e9\u00a0\u009b\u00cd\u0001\u008b\u00ba\u00a6\\\u00cff}\u00c6v\u00dfM>&cYdz\u008f\u0088\u0011\u00ad;\u00eb\u0010b\u00d6K\u00c8(fd@y\u00e4b/\u0092q{\u00b7\u00cbP\u00f1d/\u0011@i\u00d0\u00edKq\u0088O&I\u0098\u009b0\u00ed\u00cb\u0005\u0016\u00ca\u0096\u0017.\u00ab\u0017\u0012\u00e3:\u0094\u00e6\u00d0\u0013]\t\u00b6\u00ff\u0007\u008b\u00b7\u00fb\u0011\u00a8+\u001f?\u00af0jy\u001d\u0081S\u00d2\u009e\u00c2\u00b6B\u0098J\u0015J\u008fb\u00c1a.H\u0018%\u001a\u0000\u00fe\u007fC;v\u00d5\u00e2\u0089\u00c4\\\u00ce\u00de\u00e9\u00b7\u00b6\u00b5\u00fe3m\u00e1\u00fb \u00d7\u00db6V)R\u00d2Z\u00b6\u00b5\u00e9\u00a7\u0017\u000b\u00a4~\u00ca;\u00a3~\u00e6\u00f0\u0006\u0096\u00fbk)$\u00d4E`h";
                                var30_6 = "vUW\u00d7\b\u00ac\u00a2\u00f2p\u00d1\u00bb\u00f3\u008b\u00ce\u00d8$l\u0098\u0095\u00cd\u00a4V\u00a8\u00d3\u0018W\u00bb\u000b\u0089\u00d9W\u00b9#o\u00d7\u00ce\u00ad\u0005\u00f0\u009baH3\u00cf\u00c4\u0084\u0005\u00a4\u0014\u0010\u0094y\u00b3\u008b\u00a6F\b\u0011\u00c5\u00d4\u00af\u001aTW\u00c4\u00ed wr\u0001]\u00fd\u00d2%\u00adJV\u00d1\u00cf\u00db\u008aQ\u00ac-\u00d4Jf\u00f6\u00e0V\u0004\u00bc\u00ec\u00ae[V\u00ef\u0007OP\u001e\u00c03\u0010z\u00beU\u0007S\u00f6\u00ba\u00df\u00f0=\u00b5\u009e\u00a0\u00d5g\u0098H\u000e\u00d4\u00da\u00f6\u00e7\u00a1mC\u00bdl\u001d'\u0000\u0013\u00eb\u00e0D\u000b\u00a7\u00a4s\u00c6\u00ba!\u001e\u0011\u00ac\u00cc\u0093r\u00e6\u00b5x\u00cf\u001f8\u00b1\u00862\u00002\u009bg\u00fb\u00819\u00c9\u0014y=\u00c6b\u00feY\u00ce\u00bf\u0092\u0093?\u0010\u00b1*\u0013\u00bb{\u00cf\u0018+\u00ea\u0085\u008f\u0087\u00df\u0011\u00d9\u0088\u0010b\u00c3\u0092\u00d1\u0094\u001e\u00ba\u00db\u00062\u0013L\u00d8\u00f53f\u0010T\u00b1\u00f4G\u00e6GG\u00c0\u0082\u00c2N|\u00f5\u00ca1J\u0018\u00faL\u00c8\u00d3>\u008c\u00feh[<|\u00d0\u00830\u00c8\u0016\u008dhJwg\u0081 8\u0010i3\u000f%\u00a5n\u00c4\u0081\u007f:\u00aa/5\u00f3\u00d8B\u0010e\u00f5\u00e7\u00fet4\u00de\u00ed\u00e5\u00f6?>\u00ecV\u00ce\u008fX4\u0005\u00beC\u001er\u00f1\u00ffq\u00e2\u00e9L\u00a6\u001c\u001a\u0081\u000fI?w\u0083v\u0098\u00e2\u00f8\u00db\u001d4\u00a6\u00bd\u0015q\u00b4@\u00bf\u00e5Da\u00fa:<\u0087T\u00f9\u009e\u00aa\u0094\u00dc\u00d7&\u0012[t\u001d:\u00efPH\u0012`\u00af%\u0094\u00a0O<b\u00d6\u00f4\u00c4\bY\u00c1\u00d3\u0014\u00a2g3rEZcDAN\u00ef\u00c2\u008f\u0018?\u008a,\u008ar\u00c1\u0086\u00e3\u00b3\u00da\u00a75\u00c1\u00a6K\u00ba\u00a3,\u00fe\u00a7\u009f_\u00f0j +\u000be\u008b\u00cf0c\u001dl\u0081\u00d7\u00efBs\u00af\u00ef\u00b59\\\u0080B{\f\u00a62\u008eg\u00cc\u00fb\u00ce\u00fb\u0005`\u00df\u0080}\u00b3[1\u00f8\u0097X\u00bb\u00d2\u00b3X\u00b4\u00c3\u00a3=\u000b\u00b2\u00aa<\u00e6Xpl\u0003\u0007\u009f\u0018D\u0007\u00c2\u008cU\u00841\u0098<\u00b0\"\u00ddnq\u0082\u0007\u00e9\u00a0\u009b\u00cd\u0001\u008b\u00ba\u00a6\\\u00cff}\u00c6v\u00dfM>&cYdz\u008f\u0088\u0011\u00ad;\u00eb\u0010b\u00d6K\u00c8(fd@y\u00e4b/\u0092q{\u00b7\u00cbP\u00f1d/\u0011@i\u00d0\u00edKq\u0088O&I\u0098\u009b0\u00ed\u00cb\u0005\u0016\u00ca\u0096\u0017.\u00ab\u0017\u0012\u00e3:\u0094\u00e6\u00d0\u0013]\t\u00b6\u00ff\u0007\u008b\u00b7\u00fb\u0011\u00a8+\u001f?\u00af0jy\u001d\u0081S\u00d2\u009e\u00c2\u00b6B\u0098J\u0015J\u008fb\u00c1a.H\u0018%\u001a\u0000\u00fe\u007fC;v\u00d5\u00e2\u0089\u00c4\\\u00ce\u00de\u00e9\u00b7\u00b6\u00b5\u00fe3m\u00e1\u00fb \u00d7\u00db6V)R\u00d2Z\u00b6\u00b5\u00e9\u00a7\u0017\u000b\u00a4~\u00ca;\u00a3~\u00e6\u00f0\u0006\u0096\u00fbk)$\u00d4E`h".length();
                                var27_7 = 24;
                                var26_8 = -1;
lbl23:
                                // 2 sources

                                while (true) {
                                    v3 = ++var26_8;
                                    v4 = var28_5.substring(v3, v3 + var27_7);
                                    v5 = -1;
                                    break block21;
                                    break;
                                }
lbl28:
                                // 1 sources

                                while (true) {
                                    var31_3[var29_4++] = SkinChanger.b(var32_9).intern();
                                    if ((var26_8 += var27_7) < var30_6) {
                                        var27_7 = var28_5.charAt(var26_8);
                                        ** continue;
                                    }
                                    var28_5 = "\u0099\u00f3\u00f0\u00d0An\u0096\u00e3\u00f7AxW\u00df\u0011\u00b5\u009f\u0010SV\u0011\u008e\u00f9Q\u008b2\u00a1\u00c4\u00ab\u007f\u0019p\u00b4\u008d";
                                    var30_6 = "\u0099\u00f3\u00f0\u00d0An\u0096\u00e3\u00f7AxW\u00df\u0011\u00b5\u009f\u0010SV\u0011\u008e\u00f9Q\u008b2\u00a1\u00c4\u00ab\u007f\u0019p\u00b4\u008d".length();
                                    var27_7 = 16;
                                    var26_8 = -1;
lbl37:
                                    // 2 sources

                                    while (true) {
                                        v6 = ++var26_8;
                                        v4 = var28_5.substring(v6, v6 + var27_7);
                                        v5 = 0;
                                        break block21;
                                        break;
                                    }
                                    break;
                                }
lbl42:
                                // 1 sources

                                while (true) {
                                    var31_3[var29_4++] = SkinChanger.b(var32_9).intern();
                                    if ((var26_8 += var27_7) < var30_6) {
                                        var27_7 = var28_5.charAt(var26_8);
                                        ** continue;
                                    }
                                    break block22;
                                    break;
                                }
                            }
                            var32_9 = var24_1.doFinal(v4.getBytes("ISO-8859-1"));
                            switch (v5) {
                                default: {
                                    ** continue;
                                }
                                ** case 0:
lbl54:
                                // 1 sources

                                ** continue;
                            }
                        }
                        SkinChanger.u = var31_3;
                        SkinChanger.v = new String[20];
                        SkinChanger.z = new HashMap<K, V>(13);
                        var11_10 = Cipher.getInstance("DES/CBC/NoPadding");
                        v7 = SecretKeyFactory.getInstance("DES");
                        v8 = new byte[8];
                        v9 = v8;
                        v8[0] = (byte)(var22 >>> 56);
                        for (var12_11 = 1; var12_11 < 8; ++var12_11) {
                            v9 = v9;
                            v9[var12_11] = (byte)(var22 << var12_11 * 8 >>> 56);
                        }
                        var11_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                        var17_12 = new long[4];
                        var14_13 = 0;
                        var15_14 = "\u00ba?\u00eaC\u001dS\u00a0\u0085p\u00bc\u0015W'\u00a2\u00a3Q";
                        var16_15 = "\u00ba?\u00eaC\u001dS\u00a0\u0085p\u00bc\u0015W'\u00a2\u00a3Q".length();
                        var13_16 = 0;
                        while (true) {
                            var18_17 = var15_14.substring(var13_16, var13_16 += 8).getBytes("ISO-8859-1");
                            v10 = var17_12;
                            v11 = var14_13++;
                            v12 = ((long)var18_17[0] & 255L) << 56 | ((long)var18_17[1] & 255L) << 48 | ((long)var18_17[2] & 255L) << 40 | ((long)var18_17[3] & 255L) << 32 | ((long)var18_17[4] & 255L) << 24 | ((long)var18_17[5] & 255L) << 16 | ((long)var18_17[6] & 255L) << 8 | (long)var18_17[7] & 255L;
                            v13 = -1;
                            break block23;
                            break;
                        }
lbl81:
                        // 1 sources

                        while (true) {
                            v10[v11] = v14;
                            if (var13_16 < var16_15) ** continue;
                            var15_14 = "i`B\u0005\u008d\u00f2\u0085\u00e5\b\u009e\u0091\u0096\u00f1\u0004`<";
                            var16_15 = "i`B\u0005\u008d\u00f2\u0085\u00e5\b\u009e\u0091\u0096\u00f1\u0004`<".length();
                            var13_16 = 0;
                            while (true) {
                                var18_17 = var15_14.substring(var13_16, var13_16 += 8).getBytes("ISO-8859-1");
                                v10 = var17_12;
                                v11 = var14_13++;
                                v12 = ((long)var18_17[0] & 255L) << 56 | ((long)var18_17[1] & 255L) << 48 | ((long)var18_17[2] & 255L) << 40 | ((long)var18_17[3] & 255L) << 32 | ((long)var18_17[4] & 255L) << 24 | ((long)var18_17[5] & 255L) << 16 | ((long)var18_17[6] & 255L) << 8 | (long)var18_17[7] & 255L;
                                v13 = 0;
                                break block23;
                                break;
                            }
                            break;
                        }
lbl94:
                        // 1 sources

                        while (true) {
                            v10[v11] = v14;
                            if (var13_16 < var16_15) ** continue;
                            break block24;
                            break;
                        }
                    }
                    var19_18 = v12;
                    var21_19 = var11_10.doFinal(new byte[]{(byte)(var19_18 >>> 56), (byte)(var19_18 >>> 48), (byte)(var19_18 >>> 40), (byte)(var19_18 >>> 32), (byte)(var19_18 >>> 24), (byte)(var19_18 >>> 16), (byte)(var19_18 >>> 8), (byte)var19_18});
                    v14 = ((long)var21_19[0] & 255L) << 56 | ((long)var21_19[1] & 255L) << 48 | ((long)var21_19[2] & 255L) << 40 | ((long)var21_19[3] & 255L) << 32 | ((long)var21_19[4] & 255L) << 24 | ((long)var21_19[5] & 255L) << 16 | ((long)var21_19[6] & 255L) << 8 | (long)var21_19[7] & 255L;
                    switch (v13) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl107:
                        // 1 sources

                        ** continue;
                    }
                }
                SkinChanger.x = var17_12;
                SkinChanger.y = new Integer[4];
                SkinChanger.C = new HashMap<K, V>(13);
                var0_20 = Cipher.getInstance("DES/CBC/NoPadding");
                v15 = SecretKeyFactory.getInstance("DES");
                v16 = new byte[8];
                v17 = v16;
                v16[0] = (byte)(var22 >>> 56);
                for (var1_21 = 1; var1_21 < 8; ++var1_21) {
                    v17 = v17;
                    v17[var1_21] = (byte)(var22 << var1_21 * 8 >>> 56);
                }
                var0_20.init(2, (Key)v15.generateSecret(new DESKeySpec(v17)), new IvParameterSpec(new byte[8]));
                var6_22 = new long[2];
                var3_23 = 0;
                var4_24 = "\u008e2\u00d7\u00adT\u00b0\u0097\u00de\u00ea\u00a6Em\b\u000f\u00d5\u009a";
                var5_25 = "\u008e2\u00d7\u00adT\u00b0\u0097\u00de\u00ea\u00a6Em\b\u000f\u00d5\u009a".length();
                var2_26 = 0;
                while (true) {
                    break block25;
                    break;
                }
lbl129:
                // 1 sources

                while (true) {
                    var6_22[v18] = ((long)var10_29[0] & 255L) << 56 | ((long)var10_29[1] & 255L) << 48 | ((long)var10_29[2] & 255L) << 40 | ((long)var10_29[3] & 255L) << 32 | ((long)var10_29[4] & 255L) << 24 | ((long)var10_29[5] & 255L) << 16 | ((long)var10_29[6] & 255L) << 8 | (long)var10_29[7] & 255L;
                    if (var2_26 < var5_25) ** continue;
                    break block26;
                    break;
                }
            }
            var7_27 = var4_24.substring(var2_26, var2_26 += 8).getBytes("ISO-8859-1");
            v18 = var3_23++;
            var8_28 = ((long)var7_27[0] & 255L) << 56 | ((long)var7_27[1] & 255L) << 48 | ((long)var7_27[2] & 255L) << 40 | ((long)var7_27[3] & 255L) << 32 | ((long)var7_27[4] & 255L) << 24 | ((long)var7_27[5] & 255L) << 16 | ((long)var7_27[6] & 255L) << 8 | (long)var7_27[7] & 255L;
            var10_29 = var0_20.doFinal(new byte[]{(byte)(var8_28 >>> 56), (byte)(var8_28 >>> 48), (byte)(var8_28 >>> 40), (byte)(var8_28 >>> 32), (byte)(var8_28 >>> 24), (byte)(var8_28 >>> 16), (byte)(var8_28 >>> 8), (byte)var8_28});
            ** while (true)
        }
        SkinChanger.A = var6_22;
        SkinChanger.B = new Long[2];
        SkinChanger.s = 30000L;
    }

    private static Exception a(Exception exception) {
        return exception;
    }

    private static String b(byte[] byArray) {
        int charCount = 0;
        int length = byArray.length;
        char[] chars = new char[length];
        for (int index = 0; index < length; ++index) {
            char character;
            int byteValue = 0xFF & byArray[index];
            if (byteValue < 192) {
                chars[charCount++] = (char)byteValue;
                continue;
            }
            if (byteValue < 224) {
                character = (char)((char)(byteValue & 0x1F) << 6);
                byteValue = byArray[++index];
                character = (char)(character | (char)(byteValue & 0x3F));
                chars[charCount++] = character;
                continue;
            }
            if (index >= length - 2) continue;
            character = (char)((char)(byteValue & 0xF) << 12);
            byteValue = byArray[++index];
            character = (char)(character | (char)(byteValue & 0x3F) << 6);
            byteValue = byArray[++index];
            character = (char)(character | (char)(byteValue & 0x3F));
            chars[charCount++] = character;
        }
        return new String(chars, 0, charCount);
    }

    private static long d(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x2C08;
        if (B[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = A[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])C.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    C.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/e/ad", exception);
            }
            long l5 = ((long)byArray[0] & 0xFFL) << 56 | ((long)byArray[1] & 0xFFL) << 48 | ((long)byArray[2] & 0xFFL) << 40 | ((long)byArray[3] & 0xFFL) << 32 | ((long)byArray[4] & 0xFFL) << 24 | ((long)byArray[5] & 0xFFL) << 16 | ((long)byArray[6] & 0xFFL) << 8 | (long)byArray[7] & 0xFFL;
            SkinChanger.B[n3] = l5;
        }
        return B[n3];
    }

    private static long d(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        long l3 = SkinChanger.d(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Long.TYPE, l3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return l3;
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/e/ad" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (E[n4] != null) {
            return n4;
        }
        Object object = D[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 27;
            case 1 -> 39;
            case 2 -> 32;
            case 3 -> 34;
            case 4 -> 9;
            case 5 -> 49;
            case 6 -> 11;
            case 7 -> 36;
            case 8 -> 23;
            case 9 -> 17;
            case 10 -> 5;
            case 11 -> 58;
            case 12 -> 60;
            case 13 -> 21;
            case 14 -> 61;
            case 15 -> 14;
            case 16 -> 10;
            case 17 -> 40;
            case 18 -> 56;
            case 19 -> 28;
            case 20 -> 50;
            case 21 -> 54;
            case 22 -> 20;
            case 23 -> 38;
            case 24 -> 53;
            case 25 -> 33;
            case 26 -> 24;
            case 27 -> 8;
            case 28 -> 55;
            case 29 -> 31;
            case 30 -> 30;
            case 31 -> 6;
            case 32 -> 46;
            case 33 -> 52;
            case 34 -> 51;
            case 35 -> 37;
            case 36 -> 47;
            case 37 -> 62;
            case 38 -> 7;
            case 39 -> 26;
            case 40 -> 44;
            case 41 -> 63;
            case 42 -> 22;
            case 43 -> 42;
            case 44 -> 35;
            case 45 -> 29;
            case 46 -> 41;
            case 47 -> 48;
            case 48 -> 0;
            case 49 -> 1;
            case 50 -> 16;
            case 51 -> 59;
            case 52 -> 43;
            case 53 -> 4;
            case 54 -> 57;
            case 55 -> 25;
            case 56 -> 45;
            case 57 -> 18;
            case 58 -> 2;
            case 59 -> 15;
            case 60 -> 3;
            case 61 -> 13;
            case 62 -> 19;
            default -> 12;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        SkinChanger.E[n4] = new String(cArray);
        return n4;
    }

    private static void f() {
        Object[] objectArray = D;
        D[0] = " 9o3~\f+9k3~O";
        objectArray[1] = "=\u0016\u001f\u0005^:6\u0019\u000eJ#\"%\u001e\u0007\u0003";
        objectArray[2] = "[\u0015?lVCP\u0015;lV\t";
        objectArray[3] = "k\u0010\u0014^\u0006?\u001e0\u001fQ\u0017p\u007f>\u0014Z\u0013*\u000b";
        objectArray[4] = "=\u0006\u0006 \u000fiH&\r/\u001e&)(\u0006$\u001a|]";
        objectArray[5] = Void.TYPE;
        SkinChanger.E[5] = "java/lang/Void";
        objectArray[6] = "\u00005=RKH\u001e='\u001d\u0006R\u00047>A\u0017X\u0004 eR\u0011R\u0007=(\u001d$I\u00059\"P'R\u00058.R\u000b";
        objectArray[7] = "\u001a75>Fy\u00118$q-m\u001333+\u0001z\u001e";
        objectArray[8] = "YCbj>E,cie/\nMmbn+P9";
        objectArray[9] = "I7P~1>W?J1J\u001ej\u0012";
        objectArray[10] = "q\u0007^h8Fz\u0007U";
        objectArray[11] = "\u0003G|V C\u0003Gk\n,L\u0019\fk\u0014,Y\u001e};I}";
        objectArray[12] = "\u0011@M${2\u0011@Zxw=\u000b\u000bZfw(\fz\u000b3 k";
        objectArray[13] = "G\u001dzu vN\u001dyu ";
        objectArray[14] = "\u0004\u0012n<\u007fz\u000f\u001d\u007fs\u001et\u0004\u0016{)";
        objectArray[15] = "^Pi;C>WPj;Q";
        objectArray[16] = Long.TYPE;
        SkinChanger.E[16] = "java/lang/Long";
        objectArray[17] = "q\r:B\u0017}z\r2";
        objectArray[18] = "<g~\\#QIGuS2\u001e(I~X6D\\";
        objectArray[19] = Boolean.TYPE;
        SkinChanger.E[19] = "java/lang/Boolean";
        objectArray[20] = " ;\u0003\u000e\u0005\u001bU\u001b\b\u0001\u0014T4\u0015\u0003\n\u0010\u000e@";
        objectArray[21] = "O\tpiU{_\u0016p\u0002Y\u001c\u0017\u0003s:BcB\u0000,}3";
        objectArray[22] = "DO\tlN>\u0017\u001c\u0004zp<{\u0011\n'\t3\u001dL\u0002z\u001d";
        objectArray[23] = "Pb2HH\u000bUr!\u00115^is?EKT\n&&\u0015\n7Pr?\u0011DH\u0005q`V5";
        objectArray[24] = "\u007fVC<3\u0013zFPeNEFGN10L%\u0012Waq/}KH?<R9W\u0011>N";
        objectArray[25] = "HVyd)HMFj=T\u000eq@pzkMHE/w.";
        objectArray[26] = "\u007f97\u0005\u0006\\,j:\u00138[@;4\u0000B]9%5\u0005\u00057";
        objectArray[27] = "\u007ft[\u0018V\u0000.6\u0002PgqQG-n;:\u007ft[\u0018V\u0000.6\u0002P";
        objectArray[28] = ")Q+yET,A8 8\u0010\u0010\u0011:t\u0003Y~Q>d\t";
        objectArray[29] = "&[T@]%#KG\u0019 p\u001f\u001aUK\u001e\u007frMR\u0018\u0018\u0019\"KS\u001fFtuL\u0000\u0019 ";
        objectArray[30] = "[X>bs]^H-;\u000e\u0018b\u001d?c6\u0010\u001dH<<q";
        objectArray[31] = "@1I8p\t\n$C8\u001c\rq<\u001dz%\u0019\b$J=`d";
        objectArray[32] = "|\n\u00147M\u007fy\u001a\u0007n0*E\u001b\u0019:N &N\u0000j\u000fC~\u0017\u001f4B>:\u000bF50";
        objectArray[33] = "R{?%ixWk,|\u0014-kj2(j'\b?+x+DU`.{i4\u0006m+.\u0014";
        objectArray[34] = "O\u0014\u0016UnPJ\u0004\u0005\f\u0013\u000bvQ\u0017T+\u001d\t\u0004\u0014\u000bl";
        objectArray[35] = "Z#Z{:b_3I\"G;c6Tp\"1X4U&-";
        objectArray[36] = "\u001d=,h7DNn!~\tK\">%\u007fwLAk</6/\u00192#q{R].zp\t";
        Object[] objectArray2 = objectArray;
        objectArray[37] = "'_\u0016{@\u001a\"O\u0005\"=@\u001e\u0013\u000be\u0005Z}\u001eJk\u0005";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = SkinChanger.e(l2, l3);
            object = D[n2];
            try {
                if (!(object instanceof String)) break block2;
                SkinChanger.D[n2] = clazz = Class.forName(E[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = SkinChanger.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = SkinChanger.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = SkinChanger.e(l2, l3);
        Object object = D[n2];
        if (object instanceof String) {
            String string = E[n2];
            int n3 = string.indexOf(8);
            Class clazz = SkinChanger.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = SkinChanger.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = SkinChanger.c(clazz3, string2, clazz2)) != null) {
                    SkinChanger.D[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = SkinChanger.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        SkinChanger.D[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = SkinChanger.f(1015603602730013L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = SkinChanger.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = SkinChanger.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = SkinChanger.e(l2, l3);
        Object object = D[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = E[n2];
                int n4 = string2.indexOf(8);
                clazz3 = SkinChanger.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = SkinChanger.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = SkinChanger.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        SkinChanger.D[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = SkinChanger.f(1015603602730013L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = SkinChanger.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        SkinChanger.D[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = SkinChanger.f(1015603602730013L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == '\u00db' || c2 == 'B' || c2 == '\u00ca' || c2 == 'u') {
                field = SkinChanger.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == '\u00db' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == 'B' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == '\u00ca' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = SkinChanger.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == '\u00f6' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == '\u00c3' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = SkinChanger.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite f(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/e/ad" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(SkinChanger.class, "d", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(SkinChanger.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

