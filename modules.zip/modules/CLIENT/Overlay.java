// === Kuzi module: Overlay ===
// Category   : CLIENT
// Description: Show a custom image / GIF on your screen
// Payload    : a.a.a.j.b.n (verified: True)

package kuzi.modules.client;

import java.io.File;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.b.v;
import kuzi.obf.h.z_0;
import kuzi.obf.j.b.a;
import kuzi.obf.l.c.c;
import kuzi.settings.ButtonSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import kuzi.settings.StringSetting;
import net.minecraft.Screen;
import org.lwjgl.PointerBuffer;
import org.lwjgl.system.CustomBuffer;
import org.lwjgl.system.MemoryUtil;
import org.lwjgl.util.tinyfd.TinyFileDialogs;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class Overlay
extends BaseModule {
    private static final int m;
    private static final int n;
    private static final int o;
    public final StringSetting imagePath;
    public final SliderSetting width;
    public final SliderSetting opacity;
    public final SliderSetting x2;
    public final SliderSetting y2;
    private volatile List u;
    private volatile int v;
    private volatile int w;
    private volatile long[] x;
    private volatile boolean y;
    private String z;
    private int[] textureIds;
    private long[] B;
    private long C;
    private int imageHeight;
    private int imageWidth;
    private long F;
    private static final long G;
    private static final String[] H;
    private static final String[] I;
    private static final Map J;
    private static final long[] K;
    private static final Integer[] L;
    private static final Map M;
    private static final long[] N;
    private static final Long[] O;
    private static final Map P;
    private static final Object[] Q;
    private static final String[] R;

    public Overlay() {
        long l2;
        long l3 = l2 = G ^ 0x585E3317185CL;
        long l4 = l3 ^ 0x2595A882C694L;
        long l5 = l3 ^ 0x517D675761E6L;
        long l6 = l3 ^ 0x623A8C8A8FA7L;
        super("Overlay", "Show a custom image / GIF on your screen", Category.CLIENT);
        this.imagePath = new StringSetting("Image Path", "");
        this.width = new SliderSetting("Width", 200.0, 20.0, 1400.0, 5.0);
        this.opacity = new SliderSetting("Opacity", 100.0, 0.0, 100.0, 1.0);
        this.x2 = new SliderSetting("X", 40.0, -4000.0, 4000.0, 1.0);
        this.y2 = new SliderSetting("Y", 40.0, -4000.0, 4000.0, 1.0);
        this.z = null;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{new ButtonSetting("Choose Image", () -> this.a(l4)), this.imagePath, this.width, this.opacity, new ButtonSetting("Move", Overlay::lambda$new$1)};
        objectArray[0] = l6;
        this.l(objectArray);
        Object[] objectArray2 = new Object[2];
        objectArray2[1] = l5;
        objectArray2[0] = true;
        this.x2.b(objectArray2);
        Object[] objectArray3 = new Object[2];
        objectArray3[1] = l5;
        objectArray3[0] = true;
        this.y2.b(objectArray3);
    }

    private void a(long l2) {
        long l3 = (l2 = G ^ l2) ^ 0x587EDB45892AL;
        new Thread(() -> this.lambda$chooseFile$2(l3), (String)((Object)Overlay.b("s", (int)22933, (long)(0x58CA69154735403FL ^ l2)))).start();
    }

    @Override
    public void d() {
        long l2 = G ^ 0x700A0896AB23L;
        long l3 = l2 ^ 0x1CB747CDB900L;
        String string = (String)this.imagePath.a();
        String[] stringArray = kuzi.obf.j.b.a.b();
        if (stringArray != null) {
            if (string != null && !string.isBlank()) {
                Object[] objectArray = new Object[2];
                objectArray[1] = string;
                objectArray[0] = l3;
                this.a(objectArray);
            }
            super.d();
        }
    }

    @Override
    public void e() {
    }

    private void a(Object[] objectArray) {
        int n2;
        int n3;
        int n4;
        String string;
        long l2;
        block4: {
            block3: {
                String string2;
                block2: {
                    l2 = (Long)objectArray[0];
                    string = (String)objectArray[1];
                    long l3 = (l2 = G ^ l2) ^ 0x358B8FE67CA8L;
                    n4 = (int)(l3 >>> 32);
                    n3 = (int)(l3 << 32 >>> 48);
                    n2 = (int)(l3 << 48 >>> 48);
                    this.z = string;
                    String[] stringArray = kuzi.obf.j.b.a.b();
                    this.u = null;
                    this.y = false;
                    string2 = string;
                    if (stringArray == null) break block2;
                    if (string2 == null) break block3;
                    string2 = string;
                }
                if (!string2.isBlank()) break block4;
            }
            return;
        }
        new Thread(() -> this.lambda$load$3(string, n4, (char)n3, (char)n2), (String)((Object)Overlay.b("s", (int)8896, (long)(0x41B4418DE2F9F780L ^ l2)))).start();
    }

    /*
     * Exception decompiling
     */
    public void d(Object[] var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[WHILELOOP]], but top level block is 1[WHILELOOP]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:435)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:484)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    public float[] a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = G ^ l2;
        float f2 = (float)((Double)this.width.a()).doubleValue();
        float f3 = this.imageHeight > 0 ? f2 * (float)this.imageWidth / (float)this.imageHeight : f2;
        return new float[]{((Double)this.x2.a()).floatValue(), ((Double)this.y2.a()).floatValue(), f2, f3};
    }

    public void e(Object[] objectArray) {
        float f2 = ((Float)objectArray[0]).floatValue();
        float f3 = ((Float)objectArray[1]).floatValue();
        long l2 = (Long)objectArray[2];
        l2 = G ^ l2;
        this.x2.a(Double.valueOf(Math.round(f2)));
        this.y2.a(Double.valueOf(Math.round(f3)));
    }

    private void f(Object[] objectArray) {
        block5: {
            long l2 = (Long)objectArray[0];
            long l3 = (l2 = G ^ l2) ^ 0x2CA9CABCBCF4L;
            String[] stringArray = kuzi.obf.j.b.a.b();
            Overlay overlay = this;
            if (stringArray != null) {
                if (overlay.textureIds != null) {
                    int[] nArray = this.textureIds;
                    int n2 = nArray.length;
                    int n3 = 0;
                    block0: while (n3 < n2) {
                        int n4 = nArray[n3];
                        kuzi.obf.l.c.c.c(n4, l3);
                        ++n3;
                        do {
                            String[] stringArray2 = stringArray;
                            if (l2 > 0L) {
                                if (stringArray2 == null) break block5;
                                stringArray2 = stringArray;
                            }
                            if (stringArray2 != null) continue block0;
                        } while (l2 <= 0L);
                    }
                }
                overlay = this;
            }
            overlay.textureIds = null;
        }
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private void lambda$load$3(String var1_1, int var2_2, char var3_3, char var4_4) {
        block22: {
            v0 = var5_5 = ((long)var2_2 << 32 | (long)var3_3 << 48 >>> 32 | (long)var4_4 << 48 >>> 48) ^ Overlay.G;
            var7_6 = v0 ^ 85342394758052L;
            var9_7 = v0 ^ 49191678618555L;
            var11_8 = Overlay.f("B", (long)7093067320783916103L, (long)var5_5);
            try {
                block20: {
                    block21: {
                        block19: {
                            block18: {
                                var12_9 = new File(var1_1);
                                if (!var12_9.exists()) {
                                    return;
                                }
                                var13_11 = new ArrayList<E>();
                                var14_12 = new ArrayList<E>();
                                var15_13 = new int[2];
                                v1 = var11_8;
                                if (var3_3 <= '\u0000') ** GOTO lbl38
                                if (v1 == null) break block18;
                                try {
                                    block23: {
                                        if (!var1_1.toLowerCase().endsWith((String)Overlay.b("s", (int)13075, (long)(6497858311411865112L ^ var5_5)))) ** GOTO lbl39
                                        break block23;
                                        catch (Throwable v2) {
                                            throw Overlay.f("B", (Object)v2, (long)7092032487817603234L, (long)var5_5);
                                        }
                                    }
                                    v3 = new Object[5];
                                    v3[4] = var9_7;
                                    v3[3] = var15_13;
                                    v3[2] = var14_12;
                                    v3[1] = var13_11;
                                    v3[0] = var12_9;
                                    Overlay.f("B", (Object)v3, (long)7094696556873152309L, (long)var5_5);
                                }
                                catch (Throwable v4) {
                                    throw Overlay.f("B", (Object)v4, (long)7092032487817603234L, (long)var5_5);
                                }
                            }
                            try {
                                if (var4_4 <= '\u0000') break block19;
                                v1 = var11_8;
lbl38:
                                // 2 sources

                                if (v1 != null) break block19;
lbl39:
                                // 2 sources

                                v5 = new Object[5];
                                v5[4] = var15_13;
                                v5[3] = var14_12;
                                v5[2] = var13_11;
                                v5[1] = var12_9;
                                v5[0] = var7_6;
                                Overlay.f("B", (Object)v5, (long)7092044166404665149L, (long)var5_5);
                            }
                            catch (Throwable v6) {
                                throw Overlay.f("B", (Object)v6, (long)7092032487817603234L, (long)var5_5);
                            }
                        }
                        try {
                            v7 = var13_11.isEmpty();
                            if (var11_8 == null) break block20;
                            if (v7 == 0) break block21;
                        }
                        catch (Throwable v8) {
                            throw Overlay.f("B", (Object)v8, (long)7092032487817603234L, (long)var5_5);
                        }
                        return;
                    }
                    v7 = var14_12.size();
                }
                var16_14 = new long[v7];
                var17_15 = 0;
                block12: while (var17_15 < var16_14.length) {
                    try {
                        var16_14[var17_15] = (Long)var14_12.get(var17_15);
                        ++var17_15;
                        do {
                            v9 = var11_8;
                            if (var3_3 > '\u0000') {
                                if (v9 == null) break block22;
                                v9 = var11_8;
                            }
                            if (v9 != null) continue block12;
                        } while (var4_4 < '\u0000');
                        break;
                    }
                    catch (Throwable v10) {
                        throw Overlay.f("B", (Object)v10, (long)7092032487817603234L, (long)var5_5);
                    }
                }
                Overlay.f("M", (Object)this, (int)var15_13[0], (long)7091757021281029030L, (long)var5_5);
                Overlay.f("M", (Object)this, (int)var15_13[1], (long)7091915178451886702L, (long)var5_5);
                Overlay.f("M", (Object)this, (long[])var16_14, (long)7094307042772351140L, (long)var5_5);
                Overlay.f("M", (Object)this, var13_11, (long)7094380069040157474L, (long)var5_5);
                Overlay.f("M", (Object)this, (boolean)true, (long)7092510884878605335L, (long)var5_5);
            }
            catch (Throwable var12_10) {
                // empty catch block
            }
        }
    }

    private void lambda$chooseFile$2(long l2) {
        block8: {
            long l3 = (l2 = G ^ l2) ^ 0x49080F8B45C1L;
            CallSite callSite = Overlay.f("B", (long)6559175812563399982L, (long)l2);
            try {
                String string;
                String string2;
                block7: {
                    PointerBuffer pointerBuffer = MemoryUtil.memAllocPointer((int)4);
                    pointerBuffer.put(MemoryUtil.memUTF8((CharSequence)((Object)Overlay.b("s", (int)1430, (long)(0x19B63069725399F5L ^ l2)))));
                    pointerBuffer.put(MemoryUtil.memUTF8((CharSequence)((Object)Overlay.b("s", (int)21588, (long)(0x48301C8F25E3C835L ^ l2)))));
                    pointerBuffer.put(MemoryUtil.memUTF8((CharSequence)((Object)Overlay.b("s", (int)958, (long)(0x1ECE74C535E91FC7L ^ l2)))));
                    pointerBuffer.put(MemoryUtil.memUTF8((CharSequence)((Object)Overlay.b("s", (int)5857, (long)(0x66501C7813C0A8DL ^ l2)))));
                    pointerBuffer.flip();
                    string2 = TinyFileDialogs.tinyfd_openFileDialog((CharSequence)((Object)Overlay.b("s", (int)20105, (long)(0x759E3CBF4E9D2E1L ^ l2))), (CharSequence)"", (PointerBuffer)pointerBuffer, (CharSequence)((Object)Overlay.b("s", (int)12833, (long)(0x72831A7F33872E48L ^ l2))), (boolean)false);
                    try {
                        MemoryUtil.memFree((CustomBuffer)pointerBuffer);
                        string = string2;
                        if (callSite == null) break block7;
                        if (string == null) break block8;
                    }
                    catch (Throwable throwable) {
                        throw Overlay.f("B", (Object)throwable, (long)6557955170717192651L, (long)l2);
                    }
                    string = string2;
                }
                try {
                    if (!string.isBlank()) {
                        Overlay.f("\u00dc", (Object)Overlay.f("U", (Object)this, (long)6559349999006319406L, (long)l2), (Object)string2.trim(), (long)6565374123973578182L, (long)l2);
                        Object[] objectArray = new Object[2];
                        objectArray[1] = string2.trim();
                        objectArray[0] = l3;
                        Overlay.f("\u00dc", (Object)this, (Object)objectArray, (long)6565322978155723702L, (long)l2);
                    }
                }
                catch (Throwable throwable) {
                    throw Overlay.f("B", (Object)throwable, (long)6557955170717192651L, (long)l2);
                }
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
    }

    private static void lambda$new$1() {
        Client.e.execute(Overlay::lambda$new$0);
    }

    private static void lambda$new$0() {
        Client.e.setScreen((Screen)new z_0());
    }

    /*
     * Unable to fully structure code
     */
    static {
        block31: {
            block30: {
                block29: {
                    block28: {
                        block27: {
                            block26: {
                                Overlay.G = kuzi.obf.h.b.v.a(-6329935639282317087L, -6348561286958615121L, MethodHandles.lookup().lookupClass()).a(52583528485038L);
                                Overlay.Q = new Object[73];
                                Overlay.R = new String[73];
                                Overlay.c();
                                Overlay.J = new HashMap<K, V>(13);
                                var22 = Overlay.G ^ 21267369676193L;
                                var24_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                                v0 = SecretKeyFactory.getInstance("DES");
                                v1 = new byte[8];
                                v2 = v1;
                                v1[0] = (byte)(var22 >>> 56);
                                for (var25_2 = 1; var25_2 < 8; ++var25_2) {
                                    v2 = v2;
                                    v2[var25_2] = (byte)(var22 << var25_2 * 8 >>> 56);
                                }
                                var24_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                                var31_3 = new String[19];
                                var29_4 = 0;
                                var28_5 = "D\u00e7\u00f3{\u0010\u0014\u00aaw\u00fb\u00f6(\u0081\"H$\u00d5~\u0095@\u0083u\u00c8PFV\u0010N\u00de\u00af+\u00der\u00b3,\u00c31\u0083\u0086\u009b)(P\u00c7\u00d8\u00a9#-d\u00fb\u00fb'\u001b\u00bf\u00e6Fv\u00c1l\u00d4\u0015a\u00d7\u00daQ\u00fd\u00c3\u00ca\u0014`)m\u00fb\u00a1v\u00e2\u0084V_\u00d9\u00f2\u00de \u00aeX\u009e\u0088*Q\u00cf\u00c6&\u00e6\u00ba^\u0099\u00e3\u00de\u00feB\u00af\\\u00a2\t3\u00df+\u00b1\u0015Qy.\u00b4\u00f3\u0087(\u00939\u000e\u00d6\u0097\u001e\u00be\u00cc\u0099\u0089\u001d\u000bo/\u000e\u00dc\u000e\u0000\u0095\u001d\u0090g\u00c4\u00f4\u0089)\u00fa\u009a\u008a\u00bd\u00d86\u0007\u0016'\u0090`\u0089\u00fc\u0018\u0010 \u00f0^\u00cck\u0015HQ\u0011[\u00ae\u008b\u00f4\u00bf\u00c5\u0099\u0010IQ\u0017\u001dp\u00eb \u001c+\u00e7Q\u00a9\u00de\u0014\\\u00f7(\u00a0b\u00b3\u00fd`c\u0000\u00be\u00e6\u0097T\u0001^\u000bx(&3\u00fav\u00d8\u0015P^\u00dfs\u0019\u0010\u00ad>\u00a2\u00f2Kf\u00ed\u00cd\u00b6\u00949\u0080(\u00f0-\u00e4F\u00d2\u00c40\u00ed\u00ea\u0081\t\u00bf\u00ea\u00f3\u0016s\u00a2\u00056\u0004m\u0002\u00bbi?\u00db\u001fko\u0002\u0087\u0086\u009b\u00f77\u009d\u007fY\u00e0\u009a\u0010]\u00e0J\u00a8\u00d6\u00dc\u009cwj\u00c6b\u00a8\u00f5\u009f\u0015\u00f3\u0010\u00afSd\u00f2\u00de\"\u00d8Z\u00d6\u00d3\u0092\u0090\u007f\u00fb\u0000l\u0010\u00ae\u000b\u00c7\u0099\u00df\u00e6\\\u0006\u00ee\u00cd\u00bfOz\u00b57n\u0010\u0019c\u0014\\W;-I\u0019\u0014\u00fc\u00ec1e\u0081O \u00dct@X\u0003X\u00de_\u00b0\u0004\u00be\u00b7\u00ec6\u00cb\u00bd\u00e2b\u009b\u00bb\u00ae_\u009c\u008d5\u00fa\u0018C1]\u0017\u00faPOR\u0096yk\u00e4\u00a1|\u00b9Rd5k\u0088\u0016x\u00a4k\u00c0U\u009dx\u00b7\u00e8,g\u00d1^\u00da\u001d\u00b9\u0011\u0015\u00ed,\u00c9c\u00b3\u0083\u00a9\u0017\u00a3c\u0083\u001e\u00can\u0084\u0094\u0018\u00e0\t\u0085\u00fd\u0093Dp\u009b\u00fa\u00cecj\u00af\u0083\u00cc\u00e4\"\u00e53\u0091yX\u00af\u008a\u00de\u00ac\u00c1\u00d5V\u00c7\u0010o\n\u00a6\u00a7\u00f7\u007fJFB\u0013\u00cb\u00ac\u00c6\u00aaAV0\u00b6\u00b8)\u00ec\u00b9f\u00a5\u00dad\u00f8\u00eb@ieV\u0082\u0086\u00c3x\u00e0\u0098Z\u00dc\u00a0h\\\u00b3\u00b90\u00dd\u009d\u0091\u00af\u009b\u0087\u0087\u0095\u00ae\u00be\u00ab=3P_\u00fb}\u0016\u00ef\u0010\u00ae\u0012\u0011\u0096\u00a2\u00c8!Jl\u0000\u00ce\u008fM\u0002\f\u00d9";
                                var30_6 = "D\u00e7\u00f3{\u0010\u0014\u00aaw\u00fb\u00f6(\u0081\"H$\u00d5~\u0095@\u0083u\u00c8PFV\u0010N\u00de\u00af+\u00der\u00b3,\u00c31\u0083\u0086\u009b)(P\u00c7\u00d8\u00a9#-d\u00fb\u00fb'\u001b\u00bf\u00e6Fv\u00c1l\u00d4\u0015a\u00d7\u00daQ\u00fd\u00c3\u00ca\u0014`)m\u00fb\u00a1v\u00e2\u0084V_\u00d9\u00f2\u00de \u00aeX\u009e\u0088*Q\u00cf\u00c6&\u00e6\u00ba^\u0099\u00e3\u00de\u00feB\u00af\\\u00a2\t3\u00df+\u00b1\u0015Qy.\u00b4\u00f3\u0087(\u00939\u000e\u00d6\u0097\u001e\u00be\u00cc\u0099\u0089\u001d\u000bo/\u000e\u00dc\u000e\u0000\u0095\u001d\u0090g\u00c4\u00f4\u0089)\u00fa\u009a\u008a\u00bd\u00d86\u0007\u0016'\u0090`\u0089\u00fc\u0018\u0010 \u00f0^\u00cck\u0015HQ\u0011[\u00ae\u008b\u00f4\u00bf\u00c5\u0099\u0010IQ\u0017\u001dp\u00eb \u001c+\u00e7Q\u00a9\u00de\u0014\\\u00f7(\u00a0b\u00b3\u00fd`c\u0000\u00be\u00e6\u0097T\u0001^\u000bx(&3\u00fav\u00d8\u0015P^\u00dfs\u0019\u0010\u00ad>\u00a2\u00f2Kf\u00ed\u00cd\u00b6\u00949\u0080(\u00f0-\u00e4F\u00d2\u00c40\u00ed\u00ea\u0081\t\u00bf\u00ea\u00f3\u0016s\u00a2\u00056\u0004m\u0002\u00bbi?\u00db\u001fko\u0002\u0087\u0086\u009b\u00f77\u009d\u007fY\u00e0\u009a\u0010]\u00e0J\u00a8\u00d6\u00dc\u009cwj\u00c6b\u00a8\u00f5\u009f\u0015\u00f3\u0010\u00afSd\u00f2\u00de\"\u00d8Z\u00d6\u00d3\u0092\u0090\u007f\u00fb\u0000l\u0010\u00ae\u000b\u00c7\u0099\u00df\u00e6\\\u0006\u00ee\u00cd\u00bfOz\u00b57n\u0010\u0019c\u0014\\W;-I\u0019\u0014\u00fc\u00ec1e\u0081O \u00dct@X\u0003X\u00de_\u00b0\u0004\u00be\u00b7\u00ec6\u00cb\u00bd\u00e2b\u009b\u00bb\u00ae_\u009c\u008d5\u00fa\u0018C1]\u0017\u00faPOR\u0096yk\u00e4\u00a1|\u00b9Rd5k\u0088\u0016x\u00a4k\u00c0U\u009dx\u00b7\u00e8,g\u00d1^\u00da\u001d\u00b9\u0011\u0015\u00ed,\u00c9c\u00b3\u0083\u00a9\u0017\u00a3c\u0083\u001e\u00can\u0084\u0094\u0018\u00e0\t\u0085\u00fd\u0093Dp\u009b\u00fa\u00cecj\u00af\u0083\u00cc\u00e4\"\u00e53\u0091yX\u00af\u008a\u00de\u00ac\u00c1\u00d5V\u00c7\u0010o\n\u00a6\u00a7\u00f7\u007fJFB\u0013\u00cb\u00ac\u00c6\u00aaAV0\u00b6\u00b8)\u00ec\u00b9f\u00a5\u00dad\u00f8\u00eb@ieV\u0082\u0086\u00c3x\u00e0\u0098Z\u00dc\u00a0h\\\u00b3\u00b90\u00dd\u009d\u0091\u00af\u009b\u0087\u0087\u0095\u00ae\u00be\u00ab=3P_\u00fb}\u0016\u00ef\u0010\u00ae\u0012\u0011\u0096\u00a2\u00c8!Jl\u0000\u00ce\u008fM\u0002\f\u00d9".length();
                                var27_7 = 40;
                                var26_8 = -1;
lbl23:
                                // 2 sources

                                while (true) {
                                    v3 = ++var26_8;
                                    v4 = var28_5.substring(v3, v3 + var27_7);
                                    v5 = -1;
                                    break block26;
                                    break;
                                }
lbl28:
                                // 1 sources

                                while (true) {
                                    var31_3[var29_4++] = Overlay.b(var32_9).intern();
                                    if ((var26_8 += var27_7) < var30_6) {
                                        var27_7 = var28_5.charAt(var26_8);
                                        ** continue;
                                    }
                                    var28_5 = "\u00c7\u00e9\u0098\u00a6\u00b3 '\u00dc{\u00d4\u00e4\u00dd<zd\u0003\u00186\u001f\u00e5<s\u00a8\u008cc2\u0007\u00b6\r\u00c6\u0085C\u00f1@-\u00f8\u001a\u00ddr\u00c21";
                                    var30_6 = "\u00c7\u00e9\u0098\u00a6\u00b3 '\u00dc{\u00d4\u00e4\u00dd<zd\u0003\u00186\u001f\u00e5<s\u00a8\u008cc2\u0007\u00b6\r\u00c6\u0085C\u00f1@-\u00f8\u001a\u00ddr\u00c21".length();
                                    var27_7 = 16;
                                    var26_8 = -1;
lbl37:
                                    // 2 sources

                                    while (true) {
                                        v6 = ++var26_8;
                                        v4 = var28_5.substring(v6, v6 + var27_7);
                                        v5 = 0;
                                        break block26;
                                        break;
                                    }
                                    break;
                                }
lbl42:
                                // 1 sources

                                while (true) {
                                    var31_3[var29_4++] = Overlay.b(var32_9).intern();
                                    if ((var26_8 += var27_7) < var30_6) {
                                        var27_7 = var28_5.charAt(var26_8);
                                        ** continue;
                                    }
                                    break block27;
                                    break;
                                }
                            }
                            var32_9 = var24_1.doFinal(v4.getBytes("ISO-8859-1"));
                            switch (v5) {
                                default: {
                                    ** continue;
                                }
                                ** case 0:
lbl54:
                                // 1 sources

                                ** continue;
                            }
                        }
                        Overlay.H = var31_3;
                        Overlay.I = new String[19];
                        Overlay.M = new HashMap<K, V>(13);
                        var11_10 = Cipher.getInstance("DES/CBC/NoPadding");
                        v7 = SecretKeyFactory.getInstance("DES");
                        v8 = new byte[8];
                        v9 = v8;
                        v8[0] = (byte)(var22 >>> 56);
                        for (var12_11 = 1; var12_11 < 8; ++var12_11) {
                            v9 = v9;
                            v9[var12_11] = (byte)(var22 << var12_11 * 8 >>> 56);
                        }
                        var11_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                        var17_12 = new long[6];
                        var14_13 = 0;
                        var15_14 = "&\u0005\u00d4K\u00f5O\u0018\u00e0\u0096\u00f6\u00f3\u0019\rkY$\u0093\b\u0003\u00d4\u00c5\u00e4T\u00b4\u0087\u0005\u00f3\u0092\u00e2\u0013S}";
                        var16_15 = "&\u0005\u00d4K\u00f5O\u0018\u00e0\u0096\u00f6\u00f3\u0019\rkY$\u0093\b\u0003\u00d4\u00c5\u00e4T\u00b4\u0087\u0005\u00f3\u0092\u00e2\u0013S}".length();
                        var13_16 = 0;
                        while (true) {
                            var18_17 = var15_14.substring(var13_16, var13_16 += 8).getBytes("ISO-8859-1");
                            v10 = var17_12;
                            v11 = var14_13++;
                            v12 = ((long)var18_17[0] & 255L) << 56 | ((long)var18_17[1] & 255L) << 48 | ((long)var18_17[2] & 255L) << 40 | ((long)var18_17[3] & 255L) << 32 | ((long)var18_17[4] & 255L) << 24 | ((long)var18_17[5] & 255L) << 16 | ((long)var18_17[6] & 255L) << 8 | (long)var18_17[7] & 255L;
                            v13 = -1;
                            break block28;
                            break;
                        }
lbl81:
                        // 1 sources

                        while (true) {
                            v10[v11] = v14;
                            if (var13_16 < var16_15) ** continue;
                            var15_14 = "\u0013\u00013>\u000f\u00d6\u00dd\u0003[\u00dcof\u00fev\u00f8E";
                            var16_15 = "\u0013\u00013>\u000f\u00d6\u00dd\u0003[\u00dcof\u00fev\u00f8E".length();
                            var13_16 = 0;
                            while (true) {
                                var18_17 = var15_14.substring(var13_16, var13_16 += 8).getBytes("ISO-8859-1");
                                v10 = var17_12;
                                v11 = var14_13++;
                                v12 = ((long)var18_17[0] & 255L) << 56 | ((long)var18_17[1] & 255L) << 48 | ((long)var18_17[2] & 255L) << 40 | ((long)var18_17[3] & 255L) << 32 | ((long)var18_17[4] & 255L) << 24 | ((long)var18_17[5] & 255L) << 16 | ((long)var18_17[6] & 255L) << 8 | (long)var18_17[7] & 255L;
                                v13 = 0;
                                break block28;
                                break;
                            }
                            break;
                        }
lbl94:
                        // 1 sources

                        while (true) {
                            v10[v11] = v14;
                            if (var13_16 < var16_15) ** continue;
                            break block29;
                            break;
                        }
                    }
                    var19_18 = v12;
                    var21_19 = var11_10.doFinal(new byte[]{(byte)(var19_18 >>> 56), (byte)(var19_18 >>> 48), (byte)(var19_18 >>> 40), (byte)(var19_18 >>> 32), (byte)(var19_18 >>> 24), (byte)(var19_18 >>> 16), (byte)(var19_18 >>> 8), (byte)var19_18});
                    v14 = ((long)var21_19[0] & 255L) << 56 | ((long)var21_19[1] & 255L) << 48 | ((long)var21_19[2] & 255L) << 40 | ((long)var21_19[3] & 255L) << 32 | ((long)var21_19[4] & 255L) << 24 | ((long)var21_19[5] & 255L) << 16 | ((long)var21_19[6] & 255L) << 8 | (long)var21_19[7] & 255L;
                    switch (v13) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl107:
                        // 1 sources

                        ** continue;
                    }
                }
                Overlay.K = var17_12;
                Overlay.L = new Integer[6];
                Overlay.o = 60;
                Overlay.n = 512;
                Overlay.m = 1024;
                Overlay.P = new HashMap<K, V>(13);
                var0_20 = Cipher.getInstance("DES/CBC/NoPadding");
                v15 = SecretKeyFactory.getInstance("DES");
                v16 = new byte[8];
                v17 = v16;
                v16[0] = (byte)(var22 >>> 56);
                for (var1_21 = 1; var1_21 < 8; ++var1_21) {
                    v17 = v17;
                    v17[var1_21] = (byte)(var22 << var1_21 * 8 >>> 56);
                }
                var0_20.init(2, (Key)v15.generateSecret(new DESKeySpec(v17)), new IvParameterSpec(new byte[8]));
                var6_22 = new long[4];
                var3_23 = 0;
                var4_24 = "J\u00c5\u0093\u0081\u008c\u00cc\u001e\u009b\u00c5t\u0003\u00b5/\u0099\u0001\u00c0";
                var5_25 = "J\u00c5\u0093\u0081\u008c\u00cc\u001e\u009b\u00c5t\u0003\u00b5/\u0099\u0001\u00c0".length();
                var2_26 = 0;
                while (true) {
                    var7_27 = var4_24.substring(var2_26, var2_26 += 8).getBytes("ISO-8859-1");
                    v18 = var6_22;
                    v19 = var3_23++;
                    v20 = ((long)var7_27[0] & 255L) << 56 | ((long)var7_27[1] & 255L) << 48 | ((long)var7_27[2] & 255L) << 40 | ((long)var7_27[3] & 255L) << 32 | ((long)var7_27[4] & 255L) << 24 | ((long)var7_27[5] & 255L) << 16 | ((long)var7_27[6] & 255L) << 8 | (long)var7_27[7] & 255L;
                    v21 = -1;
                    break block30;
                    break;
                }
lbl137:
                // 1 sources

                while (true) {
                    v18[v19] = v22;
                    if (var2_26 < var5_25) ** continue;
                    var4_24 = "2*\u00e3>\u00f9\u0007\u00afk \u00ba\u00dc3&\u00d1Fx";
                    var5_25 = "2*\u00e3>\u00f9\u0007\u00afk \u00ba\u00dc3&\u00d1Fx".length();
                    var2_26 = 0;
                    while (true) {
                        var7_27 = var4_24.substring(var2_26, var2_26 += 8).getBytes("ISO-8859-1");
                        v18 = var6_22;
                        v19 = var3_23++;
                        v20 = ((long)var7_27[0] & 255L) << 56 | ((long)var7_27[1] & 255L) << 48 | ((long)var7_27[2] & 255L) << 40 | ((long)var7_27[3] & 255L) << 32 | ((long)var7_27[4] & 255L) << 24 | ((long)var7_27[5] & 255L) << 16 | ((long)var7_27[6] & 255L) << 8 | (long)var7_27[7] & 255L;
                        v21 = 0;
                        break block30;
                        break;
                    }
                    break;
                }
lbl150:
                // 1 sources

                while (true) {
                    v18[v19] = v22;
                    if (var2_26 < var5_25) ** continue;
                    break block31;
                    break;
                }
            }
            var8_28 = v20;
            var10_29 = var0_20.doFinal(new byte[]{(byte)(var8_28 >>> 56), (byte)(var8_28 >>> 48), (byte)(var8_28 >>> 40), (byte)(var8_28 >>> 32), (byte)(var8_28 >>> 24), (byte)(var8_28 >>> 16), (byte)(var8_28 >>> 8), (byte)var8_28});
            v22 = ((long)var10_29[0] & 255L) << 56 | ((long)var10_29[1] & 255L) << 48 | ((long)var10_29[2] & 255L) << 40 | ((long)var10_29[3] & 255L) << 32 | ((long)var10_29[4] & 255L) << 24 | ((long)var10_29[5] & 255L) << 16 | ((long)var10_29[6] & 255L) << 8 | (long)var10_29[7] & 255L;
            switch (v21) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl163:
                // 1 sources

                ** continue;
            }
        }
        Overlay.N = var6_22;
        Overlay.O = new Long[4];
    }

    private static Throwable a(Throwable throwable) {
        return throwable;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static String b(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x4765;
        if (I[n3] == null) {
            Object[] objectArray;
            try {
                Long l3 = Thread.currentThread().threadId();
                objectArray = (Object[])J.get(l3);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    J.put(l3, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/b/n", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l2 >>> 56);
            for (int i2 = 1; i2 < 8; ++i2) {
                byArray[i2] = (byte)(l2 << i2 * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = H[n3].getBytes("ISO-8859-1");
            Overlay.I[n3] = Overlay.b(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return I[n3];
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        String string2 = Overlay.b(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static CallSite b(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/b/n" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static long d(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x22EB;
        if (O[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = N[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])P.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    P.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/b/n", exception);
            }
            long l5 = ((long)byArray[0] & 0xFFL) << 56 | ((long)byArray[1] & 0xFFL) << 48 | ((long)byArray[2] & 0xFFL) << 40 | ((long)byArray[3] & 0xFFL) << 32 | ((long)byArray[4] & 0xFFL) << 24 | ((long)byArray[5] & 0xFFL) << 16 | ((long)byArray[6] & 0xFFL) << 8 | (long)byArray[7] & 0xFFL;
            Overlay.O[n3] = l5;
        }
        return O[n3];
    }

    private static long d(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        long l3 = Overlay.d(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Long.TYPE, l3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return l3;
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/b/n" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (R[n4] != null) {
            return n4;
        }
        Object object = Q[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 60;
            case 1 -> 31;
            case 2 -> 35;
            case 3 -> 6;
            case 4 -> 37;
            case 5 -> 32;
            case 6 -> 56;
            case 7 -> 51;
            case 8 -> 4;
            case 9 -> 39;
            case 10 -> 2;
            case 11 -> 0;
            case 12 -> 59;
            case 13 -> 43;
            case 14 -> 23;
            case 15 -> 20;
            case 16 -> 61;
            case 17 -> 38;
            case 18 -> 34;
            case 19 -> 33;
            case 20 -> 48;
            case 21 -> 30;
            case 22 -> 42;
            case 23 -> 45;
            case 24 -> 7;
            case 25 -> 18;
            case 26 -> 29;
            case 27 -> 21;
            case 28 -> 5;
            case 29 -> 63;
            case 30 -> 62;
            case 31 -> 40;
            case 32 -> 24;
            case 33 -> 58;
            case 34 -> 3;
            case 35 -> 49;
            case 36 -> 12;
            case 37 -> 22;
            case 38 -> 44;
            case 39 -> 10;
            case 40 -> 41;
            case 41 -> 1;
            case 42 -> 52;
            case 43 -> 55;
            case 44 -> 26;
            case 45 -> 13;
            case 46 -> 19;
            case 47 -> 47;
            case 48 -> 36;
            case 49 -> 16;
            case 50 -> 14;
            case 51 -> 15;
            case 52 -> 8;
            case 53 -> 27;
            case 54 -> 46;
            case 55 -> 50;
            case 56 -> 9;
            case 57 -> 28;
            case 58 -> 17;
            case 59 -> 54;
            case 60 -> 53;
            case 61 -> 25;
            case 62 -> 11;
            default -> 57;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        Overlay.R[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = Q;
        Q[0] = "d\u001b\u001au(So\u001b\u0019u'";
        objectArray[1] = "f\"1l|Vm- #\u0006R~,0l0Vi";
        objectArray[2] = "GFs\u0006^qLFp\u0006^";
        objectArray[3] = "-\u001e\u0018AT\rX>\u0013NEB%&\u0000IL\u000bM";
        objectArray[4] = "\u0010w";
        objectArray[5] = "\u001ep\u00025\u0004v\u0013p\u00005\u0006";
        objectArray[6] = Integer.TYPE;
        Overlay.R[6] = "java/lang/Integer";
        objectArray[7] = Long.TYPE;
        Overlay.R[7] = "java/lang/Long";
        objectArray[8] = Void.TYPE;
        Overlay.R[8] = "java/lang/Void";
        objectArray[9] = "I\u001ba8#?<;j72p]5a<6*)";
        objectArray[10] = "Ri";
        objectArray[11] = "#%,~m\u001eV\u0005'q|Q7\u000b,zx\u000bC";
        objectArray[12] = "3UN[Cd.@\u0016S\u0000d>Q\u0016x\u0018c?QJ_\tL4U__";
        objectArray[13] = "\u000eNi-S6\u0007Nj-A";
        objectArray[14] = "\u0003r\\+qovRW$` \u0017\\\\/dzc";
        objectArray[15] = "?\u0014ss\u001fl6\u0014ps\u001f";
        objectArray[16] = "f\f\u000fkC#m\u0003\u001e$\"-f\b\u001a~";
        objectArray[17] = Boolean.TYPE;
        Overlay.R[17] = "java/lang/Boolean";
        objectArray[18] = Float.TYPE;
        Overlay.R[18] = "java/lang/Float";
        objectArray[19] = "6&XYEI?&[YI";
        objectArray[20] = Short.TYPE;
        Overlay.R[20] = "java/lang/Short";
        objectArray[21] = "B\u0016Y\u0014N]76R\u001b_\u0012V8Y\u0010[H\"";
        objectArray[22] = "\u0005%";
        objectArray[23] = "c\"";
        objectArray[24] = "\u0016y(3RD\bq2|0X\u000fl";
        objectArray[25] = "/x";
        objectArray[26] = "\\KK\t\r\rWDZFp\u0015DCS\u000f";
        objectArray[27] = "\u0018D\tsS8\u0013K\u0018<9;\u0007G\u0013w";
        objectArray[28] = "&zo\u0019k\u0017SZd\u0016zX2To\u001d~\u0002F";
        objectArray[29] = "QUO\u001d3\b$uD\u0012\"GE{O\u0019&\u001d1";
        objectArray[30] = "R\u0016#IwI'6(Ff\u0006F8#Mb\\2";
        objectArray[31] = "?6_&w\u000b46W";
        objectArray[32] = "d8>698o85";
        objectArray[33] = "4Z\n+\u0003wAz\u0001$\u00128 t\n/\u0016bT";
        objectArray[34] = "@!H\u001e\u001155\u0001C\u0011\u0000zT\u000fH\u001a\u0004  ";
        objectArray[35] = "\ro\u0011l\u0001Y\u0019i\u0016Q\u0012i\u0001l\u001a5\r\u0018QlQ`";
        objectArray[36] = "\"M%4\"x#\u0007)kLk\u0019\u00037=32pG\":q\u0002%\u000f/0)s$F! LibRz*/l!]'Z'yt\u000059\":{]E17o&O&4t`{?.!!=i\\+b.`\u0019T>7srzQ}8.\u0002rD(e<aw\u0007'8L?cNy&|8uU!Z";
        objectArray[37] = "f)b:7#r/e\u0007?\u0013f4?e5t`kanU.z d{e)l;<\u0007";
        objectArray[38] = "A.6;g>U(1\u0006|\u000eK2`=y2J46l";
        objectArray[39] = "ENyL\fOD\u0004u\u0013bZ~\u0000)H\bP\u000f\u0001`F\u00185\u0013\u0006u\u0013[TF\u0004~HbXDP(\u001b\u0003\rF[s\"_O\u000f\u0000e\u0012XY\u0014X\u0019";
        objectArray[40] = "\u0001?\u001d6xO\u00159\u001a\u000bt\u007f\u0001\"@iz\u0018\u0007}\u001eb\u001aB\u001d6\u001bw*E\u000b-C\u000b";
        objectArray[41] = "4Rc+>\u0003 Td\u0016\u00113n\u001a3|9BoS=l";
        objectArray[42] = "M&%oR\u0001Y \"RY1M;x0PVKd&;0\rY9`bYIL>\"R";
        objectArray[43] = "\u0018:k\u0001>kZ*v\u0011[{!pgZ2q\u00113i\u001e<\u0011";
        objectArray[44] = "q\u0004N75ue\u0002I\n>Eq\u0019\u0013h7\"wFMcW*v\r\u001bm)%*\u0007\t\n";
        objectArray[45] = ")?\u0011E\u0019]=9\u0016x\u0003m~|O\u0012\u0004\n2>NB";
        objectArray[46] = "\u001c&\u001a*5!\b \u001d\u0017\u001c\u0011F,Ghgx\u00029@*";
        objectArray[47] = " abV:i4gek1Y |?\t8>&#a\u0002Xi:zg\t6a6g k";
        objectArray[48] = "\u0011rkdn\t\u000eem(Pr1B\u0019\u001f\f9\u0011rkdn\t\u000eem(";
        objectArray[49] = "\u001c\u0015C\u0004p-\b\u0013D9^\u001dF]\u0013SwlG\u0014\u001dC";
        objectArray[50] = "@/WI6vT)Pt\u001dFI6\u001c\u001b38Fj\u0016\t";
        objectArray[51] = "R\u0004oQ\u00157F\u0002hl9\u0007\b\u000e2\u0013GnL\u001b5Q";
        objectArray[52] = "\u001arw\u0000&o\u001b8{_H|!kl\u0003weBn/\f*\u0015\u001drp\u0011x|YgwSH([q+\u0012x/Mjsn";
        objectArray[53] = "N\nC\u0010\u0001\u007fO@OOonuD\u0013\u0014\u0005`\u0004EZ\u001a\u0015\u0005I\nD\u0001_l\r\u001fCCo8\u000f\t\u001f\u0002_?\u0019\u0012G~";
        objectArray[54] = "\u0014\u000b\t(:uM@Y4\u0005v}\u0011W5l!\u0005@\nh?\u001f";
        objectArray[55] = "i{\u0001MZ`}}\u0006prPo|[\u0015X/sq\u0007I";
        objectArray[56] = "?L+\u0019i\u0016>J}H\u0015CSI7\u001d~Q.E,\u001e~*nR6\u001ei\u001aiD-F\u0015";
        objectArray[57] = ";KP\b0l:\u0001\\W^\u007f\u0000\u0005\u0000\f4sq\u0004I\u0002$\u0016<KW\u0019n\u007fx^P[^*0SZ\u0003/+y]Jf1wqVW\u0018>+{D0\f%'dWA\\%l19\fV4|eH\r\u001f:l\u0000";
        objectArray[58] = "2{\u0002`b\u0002&}\u0005]i2m;[bf\u0003?bH/\u0000\u000bl`\u0007;1Y5sJ]";
        objectArray[59] = "^.\u0004\u001f\u0018EJ(\u0003\"\u0005u\u0004fTH\u001f\u0004\u0005/ZX";
        objectArray[60] = "b$\u0000\u001b6~v\"\u0007&.Nh8V\u001d(ri>\u0000L";
        objectArray[61] = "\u0001|&\b\"\u000f\u00006*WL\u001b:24\u00013ESv!\u0006qu\u0007t7Z0E\u0000b,\u0002L";
        objectArray[62] = "F&3)*\bR 4\u001468\u001cnc~-I\u001d'mn";
        objectArray[63] = "Xcw0\u0013\u0013Lep\r\n#R\u007f!6\r\u001fSywg";
        objectArray[64] = "%:|1@h1<{\fIX%'!nB?#x\u007fe\"e93zp\u0012b/(\"\f";
        objectArray[65] = "w\u001f\u001d!\u000b9.TM=49\u001e\tC<V3y\u000f\u001cb]Sw\u001f\u001d!\u000b9.TM=4";
        objectArray[66] = "k0s@T\u000f\u007f6t}_?k-.\u001fVXmrp\u00146\u0002w9u\u0001\u0006\u0005a\"-}";
        objectArray[67] = "J\b+wH~\u0013C{kw}#\u0012uj\u001e*[C(7M\u0014\u001e\u0002a1\u000b$\u0019\u0014ziw";
        objectArray[68] = "\u00005s1vy\u00143t\fiI\t7\"jpsZu'v";
        objectArray[69] = "\u000fuiSy'\u001bsnnk\u0017\tr3\u000b{h\u0015\u007foW";
        objectArray[70] = "64\"}\u0018p\"2%@\b@1rx{K?,)q)";
        objectArray[71] = "dm2pPWpin,aH\u0001p;'\u0003Lfvdy\b,<l/|\u001d\u001c;z4$a";
        Object[] objectArray2 = objectArray;
        objectArray[72] = "w\b\u001fN\r\nc\u000e\u0018s\u0013:}\u0014IH\u0013\u0006|\u0012\u001f\u0019";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = Overlay.e(l2, l3);
            object = Q[n2];
            try {
                if (!(object instanceof String)) break block2;
                Overlay.Q[n2] = clazz = Class.forName(R[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = Overlay.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = Overlay.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = Overlay.e(l2, l3);
        Object object = Q[n2];
        if (object instanceof String) {
            String string = R[n2];
            int n3 = string.indexOf(8);
            Class clazz = Overlay.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = Overlay.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = Overlay.c(clazz3, string2, clazz2)) != null) {
                    Overlay.Q[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = Overlay.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        Overlay.Q[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = Overlay.f(1181126854005770L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = Overlay.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = Overlay.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = Overlay.e(l2, l3);
        Object object = Q[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = R[n2];
                int n4 = string2.indexOf(8);
                clazz3 = Overlay.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = Overlay.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = Overlay.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        Overlay.Q[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = Overlay.f(1181126854005770L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = Overlay.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        Overlay.Q[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = Overlay.f(1181126854005770L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == 'U' || c2 == 'M' || c2 == 'I' || c2 == 't') {
                field = Overlay.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == 'U' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == 'M' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == 'I' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = Overlay.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == '\u00dc' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == 'B' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = Overlay.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite f(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_2().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/b/n" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Overlay.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(Overlay.class, "d", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_2() {
        try {
            return MethodHandles.lookup().findStatic(Overlay.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

