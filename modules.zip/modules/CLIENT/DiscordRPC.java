// === Kuzi module: DiscordRPC ===
// Category   : CLIENT
// Description: Shows your Minecraft activity on Discord
// Payload    : a.a.a.j.b.j (verified: True)

package kuzi.modules.client;

import com.jagrosh.discordipc.IPCClient;
import com.jagrosh.discordipc.IPCListener;
import com.jagrosh.discordipc.entities.DiscordBuild;
import com.jagrosh.discordipc.entities.RichPresence;
import com.jagrosh.discordipc.exceptions.NoDiscordClientException;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.time.OffsetDateTime;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.b.v;
import kuzi.obf.j.b.a;
import kuzi.obf.j.b.p;
import kuzi.obf.m.r;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class DiscordRPC
extends BaseModule {
    private static final int m;
    private static final String n;
    private static final int o;
    private final BoolSetting showServerIp;
    private final BoolSetting showElapsedTime;
    private final Object lock;
    private IPCClient ipcClient;
    private long sessionStartMs;
    private volatile boolean connected;
    private volatile boolean connecting;
    private int retryCooldown;
    private int tickCounter;
    private static final int y;
    private int presenceTicks;
    private static final long A;
    private static final String[] B;
    private static final String[] C;
    private static final Map D;
    private static final long[] E;
    private static final Integer[] F;
    private static final Map G;
    private static final long H;
    private static final Object[] I;
    private static final String[] J;

    public DiscordRPC() {
        long l2 = A ^ 0x2BD06BF7E816L;
        long l3 = l2 ^ 0x3011B6EDD0D9L;
        super("DiscordRPC", "Shows your Minecraft activity on Discord", Category.CLIENT);
        this.showServerIp = new BoolSetting("Show Server IP", true);
        this.showElapsedTime = new BoolSetting("Show Elapsed Time", true);
        this.lock = new Object();
        this.connected = false;
        this.connecting = false;
        this.retryCooldown = 0;
        this.tickCounter = 0;
        this.presenceTicks = 0;
        Setting[] settingArray = new Setting[]{this.showServerIp, this.showElapsedTime};
        Object[] objectArray = new Object[2];
        objectArray[1] = settingArray;
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        long l2 = A ^ 0x51AF6A110417L;
        long l3 = l2 ^ 0x3921E484E2BDL;
        super.d();
        this.sessionStartMs = System.currentTimeMillis();
        this.tickCounter = 0;
        this.retryCooldown = 0;
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.connect(objectArray);
    }

    @Override
    public void e() {
        long l2 = A ^ 0x44D373F06439L;
        long l3 = l2 ^ 0x3D5A4E3C2E7CL;
        super.e();
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.disconnect(objectArray);
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public void i() {
        block14: {
            block13: {
                v0 = var1_1 = DiscordRPC.A ^ 81038491894587L;
                var3_2 = v0 ^ 36535945667985L;
                var5_3 = v0 ^ 91800689628177L;
                var7_4 = kuzi.obf.j.b.a.b();
                v1 = this.retryCooldown--;
                if (var7_4 != null) {
                    if (v1 > 0) {
                        return;
                    }
                    v1 = (int)this.connected;
                }
                if (var7_4 != null) {
                    if (v1 == 0) {
                        v1 = (int)this.connecting;
                        if (var7_4 != null) {
                            if (v1 == 0) {
                                v2 = new Object[1];
                                v2[0] = var3_2;
                                this.connect(v2);
                                this.retryCooldown = 100;
                                return;
                            } else {
                                ** GOTO lbl-1000
                            }
                        }
                    } else lbl-1000:
                    // 3 sources

                    {
                        v1 = ++this.tickCounter;
                    }
                }
                v3 = 100;
                if (var7_4 == null) break block13;
                if (v1 >= v3) {
                    this.tickCounter = 0;
                }
                v4 = this;
                v5 = v4;
                v6 = v4.presenceTicks;
                if (var7_4 == null) break block14;
                v1 = v6;
                v5.presenceTicks = v6 + 1;
                v3 = 20;
            }
            if (v1 < v3) {
                return;
            }
            v5 = this;
            v6 = 0;
        }
        v5.presenceTicks = v6;
        v7 = new Object[1];
        v7[0] = var5_3;
        this.updatePresence(v7);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Loose catch block
     */
    private void connect(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = l2 = A ^ l2;
        long l4 = l3 ^ 0x6A4330D7634BL;
        long l5 = l3 ^ 0x6A3951FC8ED8L;
        Object object = this.lock;
        synchronized (object) {
            block22: {
                block23: {
                    Object object2;
                    block24: {
                        block20: {
                            block19: {
                                Object object3;
                                block21: {
                                    String[] stringArray;
                                    block27: {
                                        block26: {
                                            block25: {
                                                stringArray = kuzi.obf.j.b.a.b();
                                                object3 = this;
                                                if (stringArray == null) break block19;
                                                if (((DiscordRPC)object3).connected) break block21;
                                                break block25;
                                                catch (NoDiscordClientException noDiscordClientException) {
                                                    throw DiscordRPC.a((Exception)((Object)noDiscordClientException));
                                                }
                                            }
                                            if (l2 < 0L) break block20;
                                            object3 = this;
                                            if (stringArray == null) break block19;
                                            break block26;
                                            catch (NoDiscordClientException noDiscordClientException) {
                                                throw DiscordRPC.a((Exception)((Object)noDiscordClientException));
                                            }
                                        }
                                        if (((DiscordRPC)object3).connecting) break block21;
                                        break block27;
                                        catch (NoDiscordClientException noDiscordClientException) {
                                            throw DiscordRPC.a((Exception)((Object)noDiscordClientException));
                                        }
                                    }
                                    try {
                                        block28: {
                                            if (l2 < 0L) break block22;
                                            object2 = this.ipcClient;
                                            if (stringArray == null) break block23;
                                            break block28;
                                            catch (NoDiscordClientException noDiscordClientException) {
                                                throw DiscordRPC.a((Exception)((Object)noDiscordClientException));
                                            }
                                        }
                                        if (object2 == null) break block24;
                                    }
                                    catch (NoDiscordClientException noDiscordClientException) {
                                        throw DiscordRPC.a((Exception)((Object)noDiscordClientException));
                                    }
                                }
                                object3 = object;
                            }
                            // ** MonitorExit[v1] (shouldn't be in output)
                        }
                        return;
                    }
                    this.connecting = true;
                    object2 = object;
                }
                // ** MonitorExit[v5 /* !! */ ] (shouldn't be in output)
            }
            try {
                Object[] objectArray2 = new Object[1];
                objectArray2[0] = l5;
                this.m(objectArray2);
                object = new IPCClient(Long.parseLong((String)((Object)DiscordRPC.b("j", (int)24275, (long)(0x650A39970135969L ^ l2)))));
                object.setListener((IPCListener)new p(this));
                Object object4 = this.lock;
                synchronized (object4) {
                    this.ipcClient = object;
                }
                object.connect(new DiscordBuild[0]);
            }
            catch (NoDiscordClientException noDiscordClientException) {
                this.connected = false;
                this.connecting = false;
                Object[] objectArray3 = new Object[2];
                objectArray3[1] = l4;
                objectArray3[0] = null;
                this.closeClient(objectArray3);
            }
            catch (Exception exception) {
                this.connected = false;
                this.connecting = false;
                Object[] objectArray4 = new Object[2];
                objectArray4[1] = l4;
                objectArray4[0] = null;
                this.closeClient(objectArray4);
            }
            return;
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Unable to fully structure code
     */
    private void disconnect(Object[] var1_1) {
        block7: {
            var2_2 = (Long)var1_1[0];
            var2_2 = DiscordRPC.A ^ var2_2;
            var6_3 = this.lock;
            synchronized (var6_3) {
                var4_5 = kuzi.obf.j.b.a.b();
                var5_6 = this.ipcClient;
                this.ipcClient = null;
                this.connected = false;
                this.connecting = false;
            }
            if (var2_2 <= 0L) break block7;
            v0 = var5_6;
            if (var4_5 == null) ** GOTO lbl21
            if (v0 == null) break block7;
            try {
                v0 = var5_6;
lbl21:
                // 2 sources

                v0.close();
            }
            catch (Exception var6_4) {
                // empty catch block
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private void closeClient(Object[] var1_1) {
        var2_2 = (IPCClient)var1_1[0];
        var3_3 = (Long)var1_1[1];
        var3_3 = DiscordRPC.A ^ var3_3;
        var6_4 = this.lock;
        synchronized (var6_4) {
            block12: {
                block13: {
                    block11: {
                        var5_5 = kuzi.obf.j.b.a.b();
                        v0 /* !! */  = var2_2;
                        if (var5_5 == null) break block11;
                        try {
                            block14: {
                                if (v0 /* !! */  == null) ** GOTO lbl30
                                break block14;
                                catch (r v1) {
                                    throw DiscordRPC.a(v1);
                                }
                            }
                            v0 /* !! */  = this.ipcClient;
                        }
                        catch (r v2) {
                            throw DiscordRPC.a(v2);
                        }
                    }
                    if (var5_5 == null) break block12;
                    try {
                        block15: {
                            if (v0 /* !! */  != var2_2) break block13;
                            break block15;
                            catch (r v3) {
                                throw DiscordRPC.a(v3);
                            }
                        }
                        this.ipcClient = null;
                    }
                    catch (r v4) {
                        throw DiscordRPC.a(v4);
                    }
                }
                v0 /* !! */  = var6_4;
            }
            // ** MonitorExit[v0 /* !! */ ] (shouldn't be in output)
            return;
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Unable to fully structure code
     */
    private void updatePresence(Object[] var1_1) {
        var2_2 = (Long)var1_1[0];
        var4_3 = (var2_2 = DiscordRPC.A ^ var2_2) ^ 26420553814731L;
        lockRef = this.lock;
        synchronized (lockRef) {
            var6_6 = kuzi.obf.j.b.a.b();
            client = this.ipcClient;
        }
        if (!this.connected || client == null) {
            return;
        }
        try {
            block67: {
                block68: {
                    block52: {
                        block61: {
                            block53: {
                                block65: {
                                    block66: {
                                        block62: {
                                            block63: {
                                                block64: {
                                                    block75: {
                                                        block56: {
                                                            block57: {
                                                                block74: {
                                                                    block60: {
                                                                        block58: {
                                                                            block59: {
                                                                                block72: {
                                                                                    block54: {
                                                                                        block55: {
                                                                                            block70: {
                                                                                                block69: {
                                                                                                    builder = new RichPresence.Builder();
                                                                                                    details = DiscordRPC.b("j", (int)18912, (long)(6977403393628880839L ^ var2_2));
                                                                                                    state = "";
                                                                                                    v0 = (Boolean)this.showServerIp.a();
                                                                                                    v1 = var6_6;
                                                                                                    if (var2_2 < 0L) ** GOTO lbl169
                                                                                                    if (v1 == null) break block52;
                                                                                                    if (!v0) break block53;
                                                                                                    break block69;
                                                                                                    catch (Exception v2) {
                                                                                                        throw DiscordRPC.a(v2);
                                                                                                    }
                                                                                                }
                                                                                                v3 = this.tickCounter;
                                                                                                if (var6_6 == null) break block54;
                                                                                                break block70;
                                                                                                catch (Exception v4) {
                                                                                                    throw DiscordRPC.a(v4);
                                                                                                }
                                                                                            }
                                                                                            try {
                                                                                                block71: {
                                                                                                    if (v3 >= DiscordRPC.c("s", (int)18446, (long)(3003069494731601290L ^ var2_2))) break block55;
                                                                                                    break block71;
                                                                                                    catch (Exception v5) {
                                                                                                        throw DiscordRPC.a(v5);
                                                                                                    }
                                                                                                }
                                                                                                v3 = 1;
                                                                                                break block54;
                                                                                            }
                                                                                            catch (Exception v6) {
                                                                                                throw DiscordRPC.a(v6);
                                                                                            }
                                                                                        }
                                                                                        v3 = 0;
                                                                                    }
                                                                                    inServer = v3;
                                                                                    v7 = BaseModule.a.player;
                                                                                    if (var2_2 <= 0L || var6_6 == null) break block56;
                                                                                    if (v7 == null) ** GOTO lbl96
                                                                                    break block72;
                                                                                    catch (Exception v8) {
                                                                                        throw DiscordRPC.a(v8);
                                                                                    }
                                                                                }
                                                                                try {
                                                                                    block73: {
                                                                                        v9 = BaseModule.a;
                                                                                        v10 = var6_6;
                                                                                        if (var2_2 < 0L) ** GOTO lbl103
                                                                                        if (v10 == null) break block57;
                                                                                        break block73;
                                                                                        catch (Exception v11) {
                                                                                            throw DiscordRPC.a(v11);
                                                                                        }
                                                                                    }
                                                                                    if (v9.getCurrentServer() != null) {
                                                                                    }
                                                                                    ** GOTO lbl96
                                                                                }
                                                                                catch (Exception v12) {
                                                                                    throw DiscordRPC.a(v12);
                                                                                }
                                                                                var12_13 = BaseModule.a.getCurrentServer();
                                                                                try {
                                                                                    v13 = var6_6;
                                                                                    if (var2_2 <= 0L) break block58;
                                                                                    if (v13 == null) break block59;
                                                                                    if (inServer == 0) break block60;
                                                                                }
                                                                                catch (Exception v14) {
                                                                                    throw DiscordRPC.a(v14);
                                                                                }
                                                                                details = DiscordRPC.b("j", (int)31346, (long)(1791211477159480415L ^ var2_2));
                                                                            }
                                                                            v13 = var6_6;
                                                                        }
                                                                        if (var2_2 <= 0L) ** GOTO lbl95
                                                                        if (v13 != null) break block74;
                                                                    }
                                                                    details = (String)DiscordRPC.b("j", (int)10413, (long)(4737832638623178388L ^ var2_2)) + var12_13.ip;
                                                                }
                                                                try {
                                                                    if (var2_2 <= 0L) break block61;
                                                                    v13 = var6_6;
lbl95:
                                                                    // 2 sources

                                                                    if (v13 != null) break block53;
lbl96:
                                                                    // 3 sources

                                                                    v9 = BaseModule.a;
                                                                }
                                                                catch (Exception v15) {
                                                                    throw DiscordRPC.a(v15);
                                                                }
                                                            }
                                                            try {
                                                                v10 = var6_6;
lbl103:
                                                                // 2 sources

                                                                if (v10 == null) break block62;
                                                                v7 = v9.player;
                                                            }
                                                            catch (Exception v16) {
                                                                throw DiscordRPC.a(v16);
                                                            }
                                                        }
                                                        if (v7 == null) ** GOTO lbl141
                                                        v9 = BaseModule.a;
                                                        if (var2_2 <= 0L || var6_6 == null) break block62;
                                                        break block75;
                                                        catch (Exception v17) {
                                                            throw DiscordRPC.a(v17);
                                                        }
                                                    }
                                                    try {
                                                        block76: {
                                                            if (var2_2 <= 0L) break block62;
                                                            if (!v9.isLocalServer()) ** GOTO lbl141
                                                            break block76;
                                                            catch (Exception v18) {
                                                                throw DiscordRPC.a(v18);
                                                            }
                                                        }
                                                        v19 = inServer;
                                                        if (var2_2 < 0L) break block63;
                                                        if (v19 == 0) break block64;
                                                    }
                                                    catch (Exception v20) {
                                                        throw DiscordRPC.a(v20);
                                                    }
                                                    details = DiscordRPC.b("j", (int)31346, (long)(1791211477159480415L ^ var2_2));
                                                    if (var2_2 <= 0L) break block61;
                                                    if (var6_6 != null) break block53;
                                                }
                                                v19 = 5023;
                                            }
                                            details = DiscordRPC.b("j", (int)v19, (long)(5235149606047868324L ^ var2_2));
                                            try {
                                                if (var2_2 <= 0L) break block61;
                                                if (var6_6 != null) break block53;
lbl141:
                                                // 3 sources

                                                v9 = BaseModule.a;
                                            }
                                            catch (Exception v21) {
                                                throw DiscordRPC.a(v21);
                                            }
                                        }
                                        try {
                                            if (v9.screen == null) break block53;
                                            v22 = inServer;
                                            if (var2_2 < 0L) break block65;
                                            if (v22 == 0) break block66;
                                        }
                                        catch (Exception v23) {
                                            throw DiscordRPC.a(v23);
                                        }
                                        details = DiscordRPC.b("j", (int)31346, (long)(1791211477159480415L ^ var2_2));
                                        if (var2_2 <= 0L) break block61;
                                        if (var6_6 != null) break block53;
                                    }
                                    v22 = 18042;
                                }
                                details = DiscordRPC.b("j", (int)v22, (long)(2875461292664827972L ^ var2_2));
                            }
                            builder.setDetails((String)details);
                        }
                        v0 = state.isEmpty();
                    }
                    v1 = var6_6;
lbl169:
                    // 2 sources

                    if (v1 == null) break block67;
                    try {
                        block77: {
                            if (v0) break block68;
                            break block77;
                            catch (Exception v24) {
                                throw DiscordRPC.a(v24);
                            }
                        }
                        builder.setState(state);
                    }
                    catch (Exception v25) {
                        throw DiscordRPC.a(v25);
                    }
                }
                v0 = (Boolean)this.showElapsedTime.a();
            }
            if (v0) {
                elapsedSeconds = (System.currentTimeMillis() - this.sessionStartMs) / DiscordRPC.H;
                builder.setStartTimestamp(OffsetDateTime.now().minusSeconds(elapsedSeconds));
            }
            builder.setLargeImage((String)DiscordRPC.b("j", (int)5110, (long)(5523193862686893532L ^ var2_2)), (String)DiscordRPC.b("j", (int)3986, (long)(8545257260037929391L ^ var2_2)));
            client.sendRichPresence(builder.build());
        }
        catch (Exception var8_5) {
            this.connected = false;
            v26 = new Object[2];
            v26[1] = var4_3;
            v26[0] = client;
            this.c(v26);
        }
    }

    /*
     * Exception decompiling
     */
    private void m(Object[] var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * java.lang.UnsupportedOperationException
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.considerAsDoLoopStart(LoopIdentifier.java:383)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.identifyLoops1(LoopIdentifier.java:65)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:681)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private boolean a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = A ^ l2;
        String string = System.getProperty((String)((Object)DiscordRPC.b("j", (int)29057, (long)(0x38722A555BCE7931L ^ l2))), "").toLowerCase();
        return string.contains((CharSequence)((Object)DiscordRPC.b("j", (int)30266, (long)(0x2BBC42CE6D907E81L ^ l2))));
    }

    /*
     * Unable to fully structure code
     */
    private String a(Object[] var1_1) {
        block11: {
            block10: {
                block9: {
                    block7: {
                        block8: {
                            var4_2 = (String)var1_1[0];
                            var2_3 = (Long)var1_1[1];
                            var2_3 = DiscordRPC.A ^ var2_3;
                            var6_4 = System.getenv((String)DiscordRPC.b("j", (int)25570, (long)(2938452393097802362L ^ var2_3)));
                            var5_5 = kuzi.obf.j.b.a.b();
                            v0 = var6_4;
                            if (var5_5 == null) break block7;
                            if (v0 == null) break block8;
                            v0 = var6_4;
                            v1 = var5_5;
                            if (var2_3 <= 0L) break block9;
                            if (v1 != null) {
                                if (!v0.isEmpty()) {
                                    return var6_4;
                                } else {
                                    ** GOTO lbl17
                                }
                            }
                            break block7;
                        }
                        v0 = var4_2;
                    }
                    v1 = var5_5;
                }
                if (v1 == null) break block10;
                if (v0 == null) break block11;
                v0 = DiscordRPC.b("j", (int)26399, (long)(3873401994710955660L ^ var2_3));
            }
            if ((var8_7 = var4_2.indexOf(var7_6 = v0)) >= 0) {
                var9_8 = var4_2.substring(var8_7 + var7_6.length());
                var10_9 = var9_8.indexOf((int)DiscordRPC.c("s", (int)23591, (long)(6380159468945688086L ^ var2_3)));
                return var10_9 >= 0 ? var9_8.substring(0, var10_9) : var9_8;
            }
        }
        return null;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block24: {
            block23: {
                block22: {
                    block21: {
                        block20: {
                            DiscordRPC.A = kuzi.obf.h.b.v.a(-833230326766470385L, 8988402413226154887L, MethodHandles.lookup().lookupClass()).a(106719634260772L);
                            DiscordRPC.I = new Object[47];
                            DiscordRPC.J = new String[47];
                            DiscordRPC.c();
                            DiscordRPC.D = new HashMap<K, V>(13);
                            var16 = DiscordRPC.A ^ 56525318709548L;
                            var18_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                            v0 = SecretKeyFactory.getInstance("DES");
                            v1 = new byte[8];
                            v2 = v1;
                            v1[0] = (byte)(var16 >>> 56);
                            for (var19_2 = 1; var19_2 < 8; ++var19_2) {
                                v2 = v2;
                                v2[var19_2] = (byte)(var16 << var19_2 * 8 >>> 56);
                            }
                            var18_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                            var25_3 = new String[26];
                            var23_4 = 0;
                            var22_5 = "+\u0097\u000f\u00c0\u00ba\u00e9\u00beE\u00f7V\u008e66`\\\u00ce\u00bc\u0083\u00e4\u009a\u00b6D\u00ab_!\u00e7gJ\u0004\u00c1+\u007f\u0015\u0090z\u00a6\u00a8\u00ed\u00d3\u00acHy\u0099vjT!\u0003)\b\u0017,#z;\u0099\u00923\u0007\u00bb\u00fdw8\u0001\u00c6\u009a\u00bdH\u00f6c\u00d1\u00a3/?L\u00edJ\u00f4\u0092H\u00cf\u00cdJ=\u0096\u00e9\u00cfe\u00cep\u00cd\u00a9d\u009e\u008dshR\u00c6S\u00d2\u0097a\nh\u007f\u00e0\u00ce\u001a;exl\u0010\u00b7}\u00e8\b\u009a\u0083L\u00f5Ufw\u00be\u00017\u00acS \u00d3\u008a\u00b8\u00ee\u00cc\u00cd\u00cb\u000fmk\u00946\u0089\u007fq\u00f1 \u0003\u00a7\\\u00b4^g\u00d0\u00baJ\u008e\u00e6k\u0096A?\u0010\u00afE\u00baG\u00eb3\u00a5\u00df\u0080\u00d4\f;U9P\u0011 @\u0001JY#\u00fa\u00bf\u0081\u000f;R\u00d6>\u0089\u0087\u00fa\u00b2_\u009e\u00cd\u00c0\u00ba\u00c7\u0097\u00fa\u00b5\u00bf\u0084eX\u00aa\r(\\&\u00b4\u00f7\u00acm\u001c\u0090F.\u00df\u00bf\u00b4\u00d1\u00b0\u0089+\u009c\u008f\u001025q\u0085C~\u00e8\u0006:\u00a1J\u0017\u00c7\u00b6K\u00fcJ\u007f\u008e\u00f7 6\b\u00cb4\u00c3\u00aa\u00e3\u0095\u0004+\u0003*\u00b3\u00fd\u00ec2\u00c32\u0088U\u00c6\u00d6x\u0000\u00e0\u00d5\t\bz\u00a3`b\u0018\u00deV\u00d2tWe\u009e\u00ca\u00e1~\u00dd\u00b1\u00c52.D\u00aaV\u00dejl\u0086%\u0012 \u0098\u00cb\u007f\u00b0B\u008f\u0004Q&V\u00fd\u00c5=\u00df\u00c6g\u00a1 \u00e3\u00bc\u0089\u00ecd:,\u00ee:D\u00a9\u00ac5t0\u00b0\u00ae\u00e0\u00d1\u00db\u00d8\u00ea\u00b7V\u00a4'\u00ebi\u00a8\u00e95\u00a4\u00f5o\u00eaK\u00f5\u00cb\u00e6\u00e5\u00f5\u00d42\u0097'\u00f6B!\u009bf\u00ffH\u00e3\u00eb\u0011\u0016\u00b5\u00d19\n\u00f1\u00b2b\u0018\u00c3\u008d\u001f\u00e1\u0016u\u0004\u00bf\u00ad\u0007-Re\u00c0c\u00f0Ir#\u0086\u0099}\u00f0\u009c \u00deug\u001d\u00cf\u0015\f\u00c2\u00f4\u00de\u0013\u00e0\u00c7\u0088\u00ed\u00f1\u00ca3\u00f4\u00fd\u008aiY\u00ad\u00b9\u0017\u001b]\u00f1\u0096g\u00e8(].k\u00de\u00bc\u00fb,2.=\u00c1i\u00ef\u0018VXu\u0017zk'U)\u00b6!P\u00ed\u00c3\u00c5\u00c0d\u00e6'\u0093\u0014ab\u00be\u00e4\u00b28\u0007\u009f\u00f3$\u00f2&|\u0019\u00a0\u00f7\u00a0L`\u009d\u00f2\u00f5\u00d1\u00deF\u001f\u0097\u0007\u0087\u00cd\u00ee\fGW\u00a4\n\u001ck\u0084\u00f0w\u00b4\u0082\u00ca[\u00a3\u00ecK\u00cb\u00bfb\u00d9\u00a1m\u008b\u00e6\u00ca \u00b0A\u0014\u00da\u0010bt\u00e4\u0084\u0000X\u00f0\u00a8\u0088\u00d0\f\u00bf\u00d4\u00eaVz *0jf\u00b9\u00dd\u00act\u00b8SW\u009dj\u00fe~\u00ed\u008eES\u00de\u00dch%\u000fQ\u00aa0+q\u00f9\u0000\u00ea\u0018\u00a6^\u0089\u00deaz\u00e0\u00faa\u00acA\u00fbF\b\u0002\u0098\u00daL\u0010y\u00d2Y\b\u00a5\u0018\u00a8~\u0090\u00ecG~& [?\f\u00ac\u00a8\u009c\u0005\u00ee\u008fE\u0003(\u00e6\u001f\u00c3< \u0015sV\u00c3\u0014K\u00f2`\u0003A -R\u00a0\u00e46\n=\u00e9DpU\u00a4ts?\u0095i\u00dcM\u000f\u00f3 \n\u0083S\u0017>\u0087\u00ad\u00d5(\u00c4\u008a\u00c0\u0013{\u00fc\u008bd\u00ea\u00ed\u00b3\u00f5\u0094\u00e04\u00e1\u0016OQ\u001a\u00f8\u0012\u0091 \u00a1\u0088\u00e7\u00e7\u00e5\u00a0\u00d3\u00eb=U\u00d2*\u00cc.J\u00cb\u0005\u00139\u00ab\u00b4X\u0011,o\u000e\u00dc\u008e\u00e4B\u0094\u00b4(\u00f1&\u0019\u00d4\u00b4\u0088\u00b9^~3cL\u00ec\u0006\u001f\u00d2\u0011ue\u008d\u00a1\u00a4\u00fb\u00efP\u008bd\u0086*w\t\u00c9@\u001b\u00f8.\u00e7:\u0006\u0098(\\eW\u00efp\u00bfa\u00b0]\u0007\u00a2\u008a\u00ce\u0002d\u009f\u00ae\u00ccXw\u00e9}\u001a\u0010\u009b\u0014\u00f4\u008d\u00da\u00da\u0090\u001d[\u00cd\u0015\u00a8\u00c5X\u00cf\u0097";
                            var24_6 = "+\u0097\u000f\u00c0\u00ba\u00e9\u00beE\u00f7V\u008e66`\\\u00ce\u00bc\u0083\u00e4\u009a\u00b6D\u00ab_!\u00e7gJ\u0004\u00c1+\u007f\u0015\u0090z\u00a6\u00a8\u00ed\u00d3\u00acHy\u0099vjT!\u0003)\b\u0017,#z;\u0099\u00923\u0007\u00bb\u00fdw8\u0001\u00c6\u009a\u00bdH\u00f6c\u00d1\u00a3/?L\u00edJ\u00f4\u0092H\u00cf\u00cdJ=\u0096\u00e9\u00cfe\u00cep\u00cd\u00a9d\u009e\u008dshR\u00c6S\u00d2\u0097a\nh\u007f\u00e0\u00ce\u001a;exl\u0010\u00b7}\u00e8\b\u009a\u0083L\u00f5Ufw\u00be\u00017\u00acS \u00d3\u008a\u00b8\u00ee\u00cc\u00cd\u00cb\u000fmk\u00946\u0089\u007fq\u00f1 \u0003\u00a7\\\u00b4^g\u00d0\u00baJ\u008e\u00e6k\u0096A?\u0010\u00afE\u00baG\u00eb3\u00a5\u00df\u0080\u00d4\f;U9P\u0011 @\u0001JY#\u00fa\u00bf\u0081\u000f;R\u00d6>\u0089\u0087\u00fa\u00b2_\u009e\u00cd\u00c0\u00ba\u00c7\u0097\u00fa\u00b5\u00bf\u0084eX\u00aa\r(\\&\u00b4\u00f7\u00acm\u001c\u0090F.\u00df\u00bf\u00b4\u00d1\u00b0\u0089+\u009c\u008f\u001025q\u0085C~\u00e8\u0006:\u00a1J\u0017\u00c7\u00b6K\u00fcJ\u007f\u008e\u00f7 6\b\u00cb4\u00c3\u00aa\u00e3\u0095\u0004+\u0003*\u00b3\u00fd\u00ec2\u00c32\u0088U\u00c6\u00d6x\u0000\u00e0\u00d5\t\bz\u00a3`b\u0018\u00deV\u00d2tWe\u009e\u00ca\u00e1~\u00dd\u00b1\u00c52.D\u00aaV\u00dejl\u0086%\u0012 \u0098\u00cb\u007f\u00b0B\u008f\u0004Q&V\u00fd\u00c5=\u00df\u00c6g\u00a1 \u00e3\u00bc\u0089\u00ecd:,\u00ee:D\u00a9\u00ac5t0\u00b0\u00ae\u00e0\u00d1\u00db\u00d8\u00ea\u00b7V\u00a4'\u00ebi\u00a8\u00e95\u00a4\u00f5o\u00eaK\u00f5\u00cb\u00e6\u00e5\u00f5\u00d42\u0097'\u00f6B!\u009bf\u00ffH\u00e3\u00eb\u0011\u0016\u00b5\u00d19\n\u00f1\u00b2b\u0018\u00c3\u008d\u001f\u00e1\u0016u\u0004\u00bf\u00ad\u0007-Re\u00c0c\u00f0Ir#\u0086\u0099}\u00f0\u009c \u00deug\u001d\u00cf\u0015\f\u00c2\u00f4\u00de\u0013\u00e0\u00c7\u0088\u00ed\u00f1\u00ca3\u00f4\u00fd\u008aiY\u00ad\u00b9\u0017\u001b]\u00f1\u0096g\u00e8(].k\u00de\u00bc\u00fb,2.=\u00c1i\u00ef\u0018VXu\u0017zk'U)\u00b6!P\u00ed\u00c3\u00c5\u00c0d\u00e6'\u0093\u0014ab\u00be\u00e4\u00b28\u0007\u009f\u00f3$\u00f2&|\u0019\u00a0\u00f7\u00a0L`\u009d\u00f2\u00f5\u00d1\u00deF\u001f\u0097\u0007\u0087\u00cd\u00ee\fGW\u00a4\n\u001ck\u0084\u00f0w\u00b4\u0082\u00ca[\u00a3\u00ecK\u00cb\u00bfb\u00d9\u00a1m\u008b\u00e6\u00ca \u00b0A\u0014\u00da\u0010bt\u00e4\u0084\u0000X\u00f0\u00a8\u0088\u00d0\f\u00bf\u00d4\u00eaVz *0jf\u00b9\u00dd\u00act\u00b8SW\u009dj\u00fe~\u00ed\u008eES\u00de\u00dch%\u000fQ\u00aa0+q\u00f9\u0000\u00ea\u0018\u00a6^\u0089\u00deaz\u00e0\u00faa\u00acA\u00fbF\b\u0002\u0098\u00daL\u0010y\u00d2Y\b\u00a5\u0018\u00a8~\u0090\u00ecG~& [?\f\u00ac\u00a8\u009c\u0005\u00ee\u008fE\u0003(\u00e6\u001f\u00c3< \u0015sV\u00c3\u0014K\u00f2`\u0003A -R\u00a0\u00e46\n=\u00e9DpU\u00a4ts?\u0095i\u00dcM\u000f\u00f3 \n\u0083S\u0017>\u0087\u00ad\u00d5(\u00c4\u008a\u00c0\u0013{\u00fc\u008bd\u00ea\u00ed\u00b3\u00f5\u0094\u00e04\u00e1\u0016OQ\u001a\u00f8\u0012\u0091 \u00a1\u0088\u00e7\u00e7\u00e5\u00a0\u00d3\u00eb=U\u00d2*\u00cc.J\u00cb\u0005\u00139\u00ab\u00b4X\u0011,o\u000e\u00dc\u008e\u00e4B\u0094\u00b4(\u00f1&\u0019\u00d4\u00b4\u0088\u00b9^~3cL\u00ec\u0006\u001f\u00d2\u0011ue\u008d\u00a1\u00a4\u00fb\u00efP\u008bd\u0086*w\t\u00c9@\u001b\u00f8.\u00e7:\u0006\u0098(\\eW\u00efp\u00bfa\u00b0]\u0007\u00a2\u008a\u00ce\u0002d\u009f\u00ae\u00ccXw\u00e9}\u001a\u0010\u009b\u0014\u00f4\u008d\u00da\u00da\u0090\u001d[\u00cd\u0015\u00a8\u00c5X\u00cf\u0097".length();
                            var21_7 = 40;
                            var20_8 = -1;
lbl23:
                            // 2 sources

                            while (true) {
                                v3 = ++var20_8;
                                v4 = var22_5.substring(v3, v3 + var21_7);
                                v5 = -1;
                                break block20;
                                break;
                            }
lbl28:
                            // 1 sources

                            while (true) {
                                var25_3[var23_4++] = DiscordRPC.b(var26_9).intern();
                                if ((var20_8 += var21_7) < var24_6) {
                                    var21_7 = var22_5.charAt(var20_8);
                                    ** continue;
                                }
                                var22_5 = ":R\u00d2\u00f2\u00a7\u0013\u0002\u00d0\u00f3t\b\u00fbMq`\u0002(\u009d\u00cc\u001d\b\u00b3\u0093 \u00dd\u00d4\u0011\u00daD\u00a3\u00a8W\u00aa\u00cd\u009e>\f,\u00be\u00eed+\u00bb\u0080|\u00c0\u00b0Js?\u00f1;\u00faR=Q[\u00bc\u0097\u0087\u00b5\u0002K\u00e80\u00a4\u0099\u00d4\u00ddg\u0003\u00045`\u0004\u0087}\b\u00bbh\u00c9\u0001oO6\u00dc>\u0018\u00cf\u0090o\u00fe\u00b0+!\u00b1\u00b7\u00a92\u00b6\u0088\u00e78RG\u00e5\u00a0!;\u00d2\u00ee\u008f\u00ef";
                                var24_6 = ":R\u00d2\u00f2\u00a7\u0013\u0002\u00d0\u00f3t\b\u00fbMq`\u0002(\u009d\u00cc\u001d\b\u00b3\u0093 \u00dd\u00d4\u0011\u00daD\u00a3\u00a8W\u00aa\u00cd\u009e>\f,\u00be\u00eed+\u00bb\u0080|\u00c0\u00b0Js?\u00f1;\u00faR=Q[\u00bc\u0097\u0087\u00b5\u0002K\u00e80\u00a4\u0099\u00d4\u00ddg\u0003\u00045`\u0004\u0087}\b\u00bbh\u00c9\u0001oO6\u00dc>\u0018\u00cf\u0090o\u00fe\u00b0+!\u00b1\u00b7\u00a92\u00b6\u0088\u00e78RG\u00e5\u00a0!;\u00d2\u00ee\u008f\u00ef".length();
                                var21_7 = 64;
                                var20_8 = -1;
lbl37:
                                // 2 sources

                                while (true) {
                                    v6 = ++var20_8;
                                    v4 = var22_5.substring(v6, v6 + var21_7);
                                    v5 = 0;
                                    break block20;
                                    break;
                                }
                                break;
                            }
lbl42:
                            // 1 sources

                            while (true) {
                                var25_3[var23_4++] = DiscordRPC.b(var26_9).intern();
                                if ((var20_8 += var21_7) < var24_6) {
                                    var21_7 = var22_5.charAt(var20_8);
                                    ** continue;
                                }
                                break block21;
                                break;
                            }
                        }
                        var26_9 = var18_1.doFinal(v4.getBytes("ISO-8859-1"));
                        switch (v5) {
                            default: {
                                ** continue;
                            }
                            ** case 0:
lbl54:
                            // 1 sources

                            ** continue;
                        }
                    }
                    DiscordRPC.B = var25_3;
                    DiscordRPC.C = new String[26];
                    DiscordRPC.n = "1465665166313000981";
                    DiscordRPC.G = new HashMap<K, V>(13);
                    var5_10 = Cipher.getInstance("DES/CBC/NoPadding");
                    v7 = SecretKeyFactory.getInstance("DES");
                    v8 = new byte[8];
                    v9 = v8;
                    v8[0] = (byte)(var16 >>> 56);
                    for (var6_11 = 1; var6_11 < 8; ++var6_11) {
                        v9 = v9;
                        v9[var6_11] = (byte)(var16 << var6_11 * 8 >>> 56);
                    }
                    var5_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                    var11_12 = new long[9];
                    var8_13 = 0;
                    var9_14 = "\u0010M\u00d3\u00b8;\u00e8`\u00bc\u0004\u00b8\u00b5\u00c7\u008c\u000f\u008b\u00d5\u00dc\u00bd=\u0003f\u00c3\u00d5\u000eS\u0012\u0096\u00df\u0019\u0099\u00ab]?N&\u009dKq\u00ed\u00e5\u00c0\u00f2\u00b4\u008eqZ4\u00c8\u0080,a\u0094\u00f8\u0091\u0000y";
                    var10_15 = "\u0010M\u00d3\u00b8;\u00e8`\u00bc\u0004\u00b8\u00b5\u00c7\u008c\u000f\u008b\u00d5\u00dc\u00bd=\u0003f\u00c3\u00d5\u000eS\u0012\u0096\u00df\u0019\u0099\u00ab]?N&\u009dKq\u00ed\u00e5\u00c0\u00f2\u00b4\u008eqZ4\u00c8\u0080,a\u0094\u00f8\u0091\u0000y".length();
                    var7_16 = 0;
                    while (true) {
                        var12_17 = var9_14.substring(var7_16, var7_16 += 8).getBytes("ISO-8859-1");
                        v10 = var11_12;
                        v11 = var8_13++;
                        v12 = ((long)var12_17[0] & 255L) << 56 | ((long)var12_17[1] & 255L) << 48 | ((long)var12_17[2] & 255L) << 40 | ((long)var12_17[3] & 255L) << 32 | ((long)var12_17[4] & 255L) << 24 | ((long)var12_17[5] & 255L) << 16 | ((long)var12_17[6] & 255L) << 8 | (long)var12_17[7] & 255L;
                        v13 = -1;
                        break block22;
                        break;
                    }
lbl82:
                    // 1 sources

                    while (true) {
                        v10[v11] = v14;
                        if (var7_16 < var10_15) ** continue;
                        var9_14 = "=\u009f1d4\u00f3\u00e0\u00f6\u009b\u00f2\u00b3\u00c2v@e\u00b0";
                        var10_15 = "=\u009f1d4\u00f3\u00e0\u00f6\u009b\u00f2\u00b3\u00c2v@e\u00b0".length();
                        var7_16 = 0;
                        while (true) {
                            var12_17 = var9_14.substring(var7_16, var7_16 += 8).getBytes("ISO-8859-1");
                            v10 = var11_12;
                            v11 = var8_13++;
                            v12 = ((long)var12_17[0] & 255L) << 56 | ((long)var12_17[1] & 255L) << 48 | ((long)var12_17[2] & 255L) << 40 | ((long)var12_17[3] & 255L) << 32 | ((long)var12_17[4] & 255L) << 24 | ((long)var12_17[5] & 255L) << 16 | ((long)var12_17[6] & 255L) << 8 | (long)var12_17[7] & 255L;
                            v13 = 0;
                            break block22;
                            break;
                        }
                        break;
                    }
lbl95:
                    // 1 sources

                    while (true) {
                        v10[v11] = v14;
                        if (var7_16 < var10_15) ** continue;
                        break block23;
                        break;
                    }
                }
                var13_18 = v12;
                var15_19 = var5_10.doFinal(new byte[]{(byte)(var13_18 >>> 56), (byte)(var13_18 >>> 48), (byte)(var13_18 >>> 40), (byte)(var13_18 >>> 32), (byte)(var13_18 >>> 24), (byte)(var13_18 >>> 16), (byte)(var13_18 >>> 8), (byte)var13_18});
                v14 = ((long)var15_19[0] & 255L) << 56 | ((long)var15_19[1] & 255L) << 48 | ((long)var15_19[2] & 255L) << 40 | ((long)var15_19[3] & 255L) << 32 | ((long)var15_19[4] & 255L) << 24 | ((long)var15_19[5] & 255L) << 16 | ((long)var15_19[6] & 255L) << 8 | (long)var15_19[7] & 255L;
                switch (v13) {
                    default: {
                        ** continue;
                    }
                    ** case 0:
lbl108:
                    // 1 sources

                    ** continue;
                }
            }
            DiscordRPC.E = var11_12;
            DiscordRPC.F = new Integer[9];
            DiscordRPC.y = 20;
            DiscordRPC.o = 100;
            DiscordRPC.m = 100;
            var0_20 = Cipher.getInstance("DES/CBC/NoPadding");
            v15 = SecretKeyFactory.getInstance("DES");
            v16 = new byte[8];
            v17 = v16;
            v16[0] = (byte)(var16 >>> 56);
            for (var1_21 = 1; var1_21 < 8; ++var1_21) {
                v17 = v17;
                v17[var1_21] = (byte)(var16 << var1_21 * 8 >>> 56);
            }
            break block24;
lbl125:
            // 1 sources

            while (true) {
                continue;
                break;
            }
        }
        var0_20.init(2, (Key)v15.generateSecret(new DESKeySpec(v17)), new IvParameterSpec(new byte[8]));
        var2_22 = 3941861043940119338L;
        var4_23 = var0_20.doFinal(new byte[]{(byte)(var2_22 >>> 56), (byte)(var2_22 >>> 48), (byte)(var2_22 >>> 40), (byte)(var2_22 >>> 32), (byte)(var2_22 >>> 24), (byte)(var2_22 >>> 16), (byte)(var2_22 >>> 8), (byte)var2_22});
        ** while (true)
        DiscordRPC.H = ((long)var4_23[0] & 255L) << 56 | ((long)var4_23[1] & 255L) << 48 | ((long)var4_23[2] & 255L) << 40 | ((long)var4_23[3] & 255L) << 32 | ((long)var4_23[4] & 255L) << 24 | ((long)var4_23[5] & 255L) << 16 | ((long)var4_23[6] & 255L) << 8 | (long)var4_23[7] & 255L;
    }

    private static Exception a(Exception exception) {
        return exception;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static String b(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x6107;
        if (C[n3] == null) {
            Object[] objectArray;
            try {
                Long l3 = Thread.currentThread().threadId();
                objectArray = (Object[])D.get(l3);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    D.put(l3, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/b/j", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l2 >>> 56);
            for (int i2 = 1; i2 < 8; ++i2) {
                byArray[i2] = (byte)(l2 << i2 * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = B[n3].getBytes("ISO-8859-1");
            DiscordRPC.C[n3] = DiscordRPC.b(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return C[n3];
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        String string2 = DiscordRPC.b(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static CallSite b(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/b/j" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x2AAE;
        if (F[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = E[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])G.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    G.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/b/j", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            DiscordRPC.F[n3] = n4;
        }
        return F[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = DiscordRPC.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/b/j" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static void c() {
        Object[] objectArray = I;
        I[0] = "U(W\u001a{\u007f^(T\u001ap";
        objectArray[1] = Integer.TYPE;
        DiscordRPC.J[1] = "java/lang/Integer";
        objectArray[2] = "\n/z4\u000fH\u0001/q";
        objectArray[3] = "v\u0016L\u000ey{v\u0016[Rutl][Luak,\u000b\u0011$";
        objectArray[4] = "|DutgwxYw)e8{Bk9bd{Bh9#_Oh[6dsq_";
        objectArray[5] = "o\u0003\u0017dnXd\u0003\u0014dn";
        objectArray[6] = "7{x\u00179\u0011B[s\u0018(^?C`\u001f!\u0017W";
        objectArray[7] = "8YS`6h1YP`4";
        objectArray[8] = Long.TYPE;
        DiscordRPC.J[8] = "java/lang/Long";
        objectArray[9] = "dy]0!\u0007ovL\u007fJ\u0013m}[%f\u0004`";
        objectArray[10] = "\u001c\u0007\u0006zx^i'\rui\u0011\b)\u0006~mK|";
        objectArray[11] = Void.TYPE;
        DiscordRPC.J[11] = "java/lang/Void";
        objectArray[12] = "\u0002ndZJ\u0004\tau\u0015+\n\u0002jqO";
        objectArray[13] = "V+qf\\P_+rf\\";
        objectArray[14] = Boolean.TYPE;
        DiscordRPC.J[14] = "java/lang/Boolean";
        objectArray[15] = "kqw-V^\u001eQ|\"G\u0011\u007f_w)CK\u000b";
        objectArray[16] = "x1\u0015Q-6s>\u0004\u001eP.`9\rW";
        objectArray[17] = "\nU\u0010\u0010(`\u007fu\u001b\u001f9/\u001e{\u0010\u0014=uj";
        objectArray[18] = "XgvbX_-G}mI\u0010LIvfMJ8";
        objectArray[19] = "l[wfI/\u0019{|iX`xuwb\\:\f";
        objectArray[20] = "zC\u00030\u00069\u000fc\b?\u0017vnm\u00034\u0013,\u001a";
        objectArray[21] = "&\u0016@/@.S6K Qa28@+U;F";
        objectArray[22] = "\u0018y@gYc\u0013yH";
        objectArray[23] = "k\u000bf\u001d\u0004l\u001e+m\u0012\u0015#\u007f%f\u0019\u0011y\u000b";
        objectArray[24] = "\u0007'I\u000bM\u001b\u0006wF0OqYsFZQA\u0011/\u001eT";
        objectArray[25] = "h\u000ehb3w \u0011}`WsQDbm8#2Nss(";
        objectArray[26] = "{OuQN.z\u001fzjVDsH\u007f\u0006R;u\u001ab\t<{m\u001bw\u0006U$!Oxj";
        objectArray[27] = "U/=\u0012}=T\u007f2)pW\u000b{2CagC'jM";
        objectArray[28] = "k\u001c'k\u0006UjL(P\u001d?c\u001b-<\u001a@eI03t\u0000}H%<\u001d_1\u001c*P";
        objectArray[29] = "\u000bOB]cg\n\u001fMfj\rW\u001eA_/o\u0006VL\u001d";
        objectArray[30] = "k5\u0010r\r\u000f--\u001a2s\\Pu\u0016zJN+,\u0016?\u000e6";
        objectArray[31] = "\u0011E\u000f\u0000 :\u0010\u0015\u0000;+PKN\u000f\u00076/\u0019T\rT";
        objectArray[32] = "~;sU\u0007'+>iO=\tT\u001d^xaB~;sU\u0007'+>iO";
        objectArray[33] = "\u0012]`gE5\u0013\ro\\E_L\to6Yo\u0004U78";
        objectArray[34] = "+yNg\u0000,*)A\\\u000eFr*^<\u0002))kBc";
        objectArray[35] = "\u001d\ro=Nu\u001c]`\u0006Y\u001f\u0015\nejR`\u0013Xxe< \u000bYmjU\u007fG\rb\u0006";
        objectArray[36] = "Hla\u000e\u0018SI<n5\u00049@kkY\u0004FF9vVj\u0006^8cY\u0003Y\u0012ll5";
        objectArray[37] = "dg\"\u001eK_e7-%P5=`pD\u0000Thgu^9\u000bm1.\u001cX^j44%";
        objectArray[38] = "j\u0014@N(]kDOu17b\u0013J\u00194HdAW\u0016Z\b|@B\u00193W0\u0014Mu";
        objectArray[39] = "w\tQhr\u0014vY^Si~\u007f\u000e[?n\u0001y\\F0\u0000\u0014h\u0003Co\u007f\u0006pPPS";
        objectArray[40] = "bG\u0007kP\u0000c\u0017\bPKjj@\r<L\u0015l\u0012\u00103\"[u_V.I\tw\\\u000bP";
        objectArray[41] = "`\u0007\u000b/%!aW\u0004\u0014-K7\u0005\u0000u7sv\u0004\u0016l";
        objectArray[42] = "8?M\tUH04\u0016_o@\tnM\u0002\u000eI1/L\u0014\u0017)";
        objectArray[43] = "I{(\u0015\u001d\u001cH+'.\u0012v\u001fb4\u0012\u0011\u001dM`7O";
        objectArray[44] = "81s\u001d0ip.f\u001fT`\u0001.o\u00148j~(=\t7\u0004>0<\u001c8ma|h\u0013T";
        objectArray[45] = "B\r\u000b'R/C]\u0004\u001cXE\u0018\u0006\u000b D:J\u001c\ts";
        Object[] objectArray2 = objectArray;
        objectArray[46] = "}\rBY~\u001c|]Mbrv+\u0014^^r\u001dy\u0016]\u0003";
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = DiscordRPC.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = DiscordRPC.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = DiscordRPC.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = DiscordRPC.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(DiscordRPC.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(DiscordRPC.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

