// === Kuzi module: Kuzi ===
// Category   : CLIENT
// Description: The Gui
// Payload    : a.a.a.j.b.g (verified: True)

package kuzi.modules.client;

import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.X;
import kuzi.obf.h.b.e;
import kuzi.obf.h.b.l;
import kuzi.obf.h.b.v;
import kuzi.obf.h.o;
import kuzi.obf.h.q_0;
import kuzi.obf.h.r_0;
import kuzi.obf.j.b.a;
import kuzi.obf.j.b.b;
import kuzi.obf.l.a.c;
import kuzi.obf.m.r;
import kuzi.settings.BoolSetting;
import kuzi.settings.ButtonSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.Minecraft;
import net.minecraft.Screen;
import net.minecraft.TitleScreen;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class Kuzi
extends BaseModule {
    public final l m;
    public final BoolSetting icons;
    public final BoolSetting o;
    public final BoolSetting notifier;
    public final BoolSetting detectionWarning;
    public final l r;
    public final SliderSetting notifSize;
    public final SliderSetting gUIOpacity;
    public final SliderSetting gUISize;
    public final BoolSetting backgroundBlur;
    public final SliderSetting blurStrength;
    public final BoolSetting liquidGlass;
    private final e primaryColor;
    private final e secondaryColor;
    private final e backgroundColor;
    private final e textColor;
    public Screen C;
    private static final long D;
    private static final String[] E;
    private static final String[] F;
    private static final Map G;
    private static final long[] H;
    private static final Integer[] I;
    private static final Map J;
    private static final Object[] K;
    private static final String[] L;

    public Kuzi() {
        long l2;
        long l3 = l2 = D ^ 0x10E0D3257618L;
        long l4 = l3 ^ 0xC54EC83581BL;
        int n2 = (int)(l4 >>> 48);
        int n3 = (int)(l4 << 16 >>> 32);
        int n4 = (int)(l4 << 48 >>> 48);
        long l5 = l3 ^ 0x118A751F82D2L;
        long l6 = l3 ^ 0x6DF3872DEA0FL;
        long l7 = l3 ^ 0x3B73134B3C53L;
        long l8 = l3 ^ 0x45646450B82AL;
        super("Kuzi", "The Gui", Category.CLIENT);
        this.m = new l("GUI Style", kuzi.obf.j.b.a.DROPDOWN, a.class);
        this.icons = new BoolSetting("Icons", false);
        this.o = new BoolSetting("Animations", true);
        this.notifier = new BoolSetting("Notifier", true);
        this.detectionWarning = new BoolSetting("Detection Warning", true);
        this.r = new l("Notif Position", kuzi.obf.j.b.b.TOP, b.class);
        this.notifSize = new SliderSetting("Notif Size", 1.0, 0.5, 2.0, 0.05);
        this.gUIOpacity = new SliderSetting("GUI Opacity", 35.0, 0.0, 100.0, 5.0);
        this.gUISize = new SliderSetting("GUI Size", 1.0, 0.6, 1.4, 0.05);
        this.backgroundBlur = new BoolSetting("Background Blur", true);
        this.blurStrength = new SliderSetting("Blur Strength", 2.0, 1.0, 4.0, 0.25);
        this.liquidGlass = new BoolSetting("Liquid Glass", false);
        this.primaryColor = new e("Primary Color", new Color(255, 255, 255));
        this.secondaryColor = new e("Secondary Color", new Color(83, 83, 83));
        this.backgroundColor = new e("Background Color", new Color(11, 11, 11));
        this.textColor = new e("Text Color", new Color(255, 255, 255));
        Object[] objectArray = new Object[2];
        objectArray[1] = 344;
        objectArray[0] = l7;
        this.i(objectArray);
        Object[] objectArray2 = new Object[2];
        objectArray2[1] = new Setting[]{this.m, new ButtonSetting("Themes", Kuzi::lambda$new$1), this.primaryColor, this.secondaryColor, this.backgroundColor, this.textColor, this.icons, this.o, this.notifier, this.detectionWarning, this.r, this.notifSize, this.gUIOpacity, this.gUISize, this.backgroundBlur, this.blurStrength, this.liquidGlass};
        objectArray2[0] = l8;
        this.l(objectArray2);
        Object[] objectArray3 = new Object[2];
        objectArray3[1] = () -> this.lambda$new$2((short)n2, n3, n4);
        objectArray3[0] = l6;
        this.blurStrength.a(objectArray3);
        kuzi.obf.l.a.c.a(new o(), l5);
        Client.a();
    }

    public void a(Object[] objectArray) {
        block3: {
            Color value;
            e setting;
            block2: {
                long l2 = (Long)objectArray[0];
                Color newPrimary = (Color)objectArray[1];
                Color newSecondary = (Color)objectArray[2];
                Color newBackground = (Color)objectArray[3];
                l2 = D ^ l2;
                String[] stringArray = kuzi.obf.j.b.a.b();
                this.primaryColor.a(newPrimary);
                String[] stringArray2 = stringArray;
                setting = this.secondaryColor;
                value = newSecondary;
                if (stringArray2 == null) break block2;
                setting.a(value);
                if (newBackground == null) break block3;
                setting = this.backgroundColor;
                value = newBackground;
            }
            setting.a(value);
        }
    }

    public Color a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = D ^ l2;
        return this.primaryColor.a();
    }

    public Color b(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = D ^ l2;
        return this.secondaryColor.a();
    }

    public Color c(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = D ^ l2;
        return this.backgroundColor.a();
    }

    public Color d(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = D ^ l2;
        return Kuzi.d("\u00ff", (Object)Kuzi.d("\u00f3", (Object)this, (long)6279413912260831525L, (long)l2), (long)6279673184820301077L, (long)l2);
    }

    public int a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = D ^ l2;
        CallSite callSite = Kuzi.d("\u00ff", (Object)Kuzi.d("\u00f3", (Object)this, (long)8338073587538316727L, (long)l2), (long)8338376309905860999L, (long)l2);
        return Kuzi.c("u", (int)16357, (long)(0x253F23D98AE66590L ^ l2)) | ((Color)((Object)callSite)).getRGB() & Kuzi.c("u", (int)1237, (long)(0x76CC2E50F8C0DEB3L ^ l2));
    }

    public int c(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = D ^ l2;
        CallSite callSite = Kuzi.d("\u00ff", (Object)Kuzi.d("\u00f3", (Object)this, (long)-8401131018001048919L, (long)l2), (long)-8400754558596001446L, (long)l2);
        return Kuzi.c("u", (int)1652, (long)(0x4D47C1A0C39524DFL ^ l2)) | ((Color)((Object)callSite)).getRed() << Kuzi.c("u", (int)4134, (long)(0x54EDEC0ECB21328AL ^ l2)) | ((Color)((Object)callSite)).getGreen() << Kuzi.c("u", (int)27878, (long)(0x3520FA67B8504E52L ^ l2)) | ((Color)((Object)callSite)).getBlue();
    }

    public int d(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = D ^ l2;
        CallSite callSite = Kuzi.d("\u00ff", (Object)Kuzi.d("\u00f3", (Object)this, (long)-2423113999487704869L, (long)l2), (long)-2423341934514666386L, (long)l2);
        return ((Color)((Object)callSite)).getAlpha() << Kuzi.c("u", (int)17056, (long)(0x6FDA1A41E445B526L ^ l2)) | ((Color)((Object)callSite)).getRed() << Kuzi.c("u", (int)4134, (long)(0x54EDE56BAD7767BEL ^ l2)) | ((Color)((Object)callSite)).getGreen() << Kuzi.c("u", (int)27878, (long)(0x3520F302DE061B66L ^ l2)) | ((Color)((Object)callSite)).getBlue();
    }

    public int e(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = D ^ l2;
        CallSite callSite = Kuzi.d("\u00ff", (Object)Kuzi.d("\u00f3", (Object)this, (long)5117720999722447868L, (long)l2), (long)5116812591282232626L, (long)l2);
        return ((Color)((Object)callSite)).getAlpha() << Kuzi.c("u", (int)28490, (long)(0x42D1CA3D7856819FL ^ l2)) | ((Color)((Object)callSite)).getRed() << Kuzi.c("u", (int)21514, (long)(0x2230F0DA97F73AD1L ^ l2)) | ((Color)((Object)callSite)).getGreen() << Kuzi.c("u", (int)24703, (long)(0x12446A0E2E778EA8L ^ l2)) | ((Color)((Object)callSite)).getBlue();
    }

    public int f(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        double d2 = (Double)objectArray[1];
        long l3 = (l2 = D ^ l2) ^ 0x36466A0CA09DL;
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l3;
        return (int)Kuzi.d("\u00ff", (Object)this, (Object)objectArray2, (long)3165913414883043395L, (long)l2);
    }

    public boolean a(Object[] objectArray) {
        return true;
    }

    public boolean f(Object[] objectArray) {
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static boolean d(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        Screen mc4372 = (Screen)objectArray[1];
        l2 = D ^ l2;
        String[] stringArray = kuzi.obf.j.b.a.b();
        boolean bl = mc4372 instanceof r_0;
        if (stringArray == null) return bl;
        if (bl) return true;
        bl = mc4372 instanceof q_0;
        if (stringArray == null) return bl;
        if (!bl) return false;
        return true;
    }

    @Override
    public void d() {
        block6: {
            Minecraft mc;
            Minecraft mcSnapshot;
            long l2;
            block7: {
                String[] stringArray;
                long l3;
                block5: {
                    long l4;
                    long l5 = l4 = D ^ 0x1FEA007EF2EAL;
                    long l6 = l5 ^ 0x8E6938D9C27L;
                    long l7 = l5 ^ 0x63096385FEE3L;
                    long l8 = l5 ^ 0x325F19DA4631L;
                    l3 = l5 ^ 0x1CBA454A3563L;
                    l2 = l5 ^ 0x6FA30B94E176L;
                    String[] stringArray2 = kuzi.obf.j.b.a.b();
                    Client.a();
                    stringArray = stringArray2;
                    Kuzi kuzi = this;
                    if (stringArray != null) {
                        Object[] objectArray = new Object[1];
                        objectArray[0] = l8;
                        if (!kuzi.g(objectArray)) {
                            return;
                        }
                        Object[] objectArray2 = new Object[1];
                        objectArray2[0] = l7;
                        this.b(objectArray2);
                        kuzi = this;
                    }
                    Object[] objectArray = new Object[1];
                    objectArray[0] = l6;
                    mc = mcSnapshot = kuzi.a(objectArray);
                    if (stringArray == null) break block5;
                    if (mc == null) break block6;
                    mc = mcSnapshot;
                }
                if (stringArray == null) break block7;
                Object[] objectArray = new Object[2];
                objectArray[1] = mc.screen;
                objectArray[0] = l3;
                if (Kuzi.d(objectArray)) break block6;
                mc = mcSnapshot;
            }
            mc.execute(() -> this.lambda$onEnable$3(l2, mcSnapshot));
        }
    }

    @Override
    public void e() {
        long l2;
        long l3 = l2 = D ^ 0xA96199F92C4L;
        long l4 = l3 ^ 0x1D9A8A6CFC09L;
        long l5 = l3 ^ 0x6C026B416DEEL;
        Object[] objectArray = new Object[1];
        objectArray[0] = l4;
        Minecraft mc = this.a(objectArray);
        String[] stringArray = kuzi.obf.j.b.a.b();
        Minecraft mcSnapshot = mc;
        if (stringArray != null) {
            if (mcSnapshot == null) {
                return;
            }
            mcSnapshot = mc;
        }
        mcSnapshot.execute(() -> Kuzi.lambda$onDisable$4(mc, l5));
    }

    public void b(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = D ^ l2;
        this.C = this.m.a() == kuzi.obf.j.b.a.BOX ? new r_0() : new r_0();
    }

    public boolean g(Object[] objectArray) {
        Screen screen;
        long l2 = (Long)objectArray[0];
        long l3 = l2 = D ^ l2;
        long l4 = l3 ^ 0x4EDE365F8F31L;
        long l5 = l3 ^ 0x5A82E0982675L;
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l4;
        Minecraft mc = this.a(objectArray2);
        String[] stringArray = kuzi.obf.j.b.a.b();
        Minecraft mcSnapshot = mc;
        if (stringArray != null) {
            if (mcSnapshot == null) {
                return false;
            }
            mcSnapshot = mc;
        }
        Screen currentScreen = screen = mcSnapshot.screen;
        if (l2 >= 0L && stringArray != null) {
            if (currentScreen == null) {
                return true;
            }
            currentScreen = screen;
        }
        boolean isTitleOrGui = currentScreen instanceof TitleScreen;
        if (stringArray != null) {
            if (isTitleOrGui) {
                return true;
            }
            Object[] objectArray3 = new Object[2];
            objectArray3[1] = screen;
            objectArray3[0] = l5;
            isTitleOrGui = Kuzi.d(objectArray3);
        }
        return isTitleOrGui;
    }

    public void c(Object[] objectArray) {
        block15: {
            CallSite callSite;
            CallSite callSite2;
            long l2;
            block16: {
                Object[] objectArray2;
                Kuzi kuzi;
                Object[] objectArray3;
                long l3;
                block13: {
                    long l4;
                    block14: {
                        block10: {
                            Kuzi kuzi2;
                            long l5;
                            long l6;
                            Object[] objectArray4;
                            block11: {
                                long l7;
                                block12: {
                                    l3 = (Long)objectArray[0];
                                    long l8 = l3 = D ^ l3;
                                    l4 = l8 ^ 0x3C6ABD8FEDDEL;
                                    l2 = l8 ^ 0x6CBADBDD683L;
                                    l7 = l8 ^ 0x57854D878F1AL;
                                    long l9 = l8 ^ 0x6D337D837C8L;
                                    objectArray3 = Kuzi.d("\u00e1", (long)-3009473602875264395L, (long)l3);
                                    try {
                                        try {
                                            kuzi = this;
                                            if (objectArray3 == null) break block10;
                                            Object[] objectArray5 = new Object[1];
                                            objectArray4 = objectArray5;
                                            objectArray5[0] = l9;
                                            l6 = -3009379470609308711L;
                                            l5 = l3;
                                            if (l3 <= 0L) break block11;
                                            if (Kuzi.d("\u00ff", (Object)kuzi, (Object)objectArray4, (long)l6, (long)l5) != false) break block12;
                                        }
                                        catch (r r2) {
                                            throw Kuzi.d("\u00e1", (Object)r2, (long)-3009269510559968681L, (long)l3);
                                        }
                                        return;
                                    }
                                    catch (r r3) {
                                        throw Kuzi.d("\u00e1", (Object)r3, (long)-3009269510559968681L, (long)l3);
                                    }
                                }
                                kuzi2 = this;
                                Object[] objectArray6 = new Object[1];
                                objectArray4 = objectArray6;
                                objectArray6[0] = l7;
                                l6 = -3010544808615565282L;
                                l5 = l3;
                            }
                            Kuzi.d("\u00ff", (Object)kuzi2, (Object)objectArray4, (long)l6, (long)l5);
                            kuzi = this;
                        }
                        try {
                            try {
                                objectArray2 = objectArray3;
                                if (l3 <= 0L) break block13;
                                if (objectArray2 == null) break block14;
                                if (Kuzi.d("\u00f3", (Object)kuzi, (long)-3008682569141866891L, (long)l3) == null) break block15;
                            }
                            catch (r r4) {
                                throw Kuzi.d("\u00e1", (Object)r4, (long)-3009269510559968681L, (long)l3);
                            }
                            kuzi = this;
                        }
                        catch (r r5) {
                            throw Kuzi.d("\u00e1", (Object)r5, (long)-3009269510559968681L, (long)l3);
                        }
                    }
                    Object[] objectArray7 = new Object[1];
                    objectArray2 = objectArray7;
                    objectArray7[0] = l4;
                }
                callSite2 = Kuzi.d("\u00ff", (Object)kuzi, (Object)objectArray2, (long)-3008590920919032654L, (long)l3);
                try {
                    callSite = callSite2;
                    if (objectArray3 == null) break block16;
                    if (callSite == null) break block15;
                }
                catch (r r6) {
                    throw Kuzi.d("\u00e1", (Object)r6, (long)-3009269510559968681L, (long)l3);
                }
                callSite = callSite2;
            }
            callSite.execute(() -> this.lambda$openGUI$5(l2, (Minecraft)callSite2));
        }
    }

    private Minecraft a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = D ^ l2;
        String[] stringArray = kuzi.obf.j.b.a.b();
        Minecraft mc = Client.e;
        if (stringArray != null) {
            mc = mc != null ? Client.e : Minecraft.getInstance();
        }
        return mc;
    }

    private void lambda$openGUI$5(long l2, Minecraft mc) {
        l2 = D ^ l2;
        mc.setScreen((Screen)Kuzi.d("\u00f3", (Object)this, (long)6168648947600862673L, (long)l2));
    }

    private static void lambda$onDisable$4(Minecraft mc, long l2) {
        block3: {
            Screen currentScreen;
            block2: {
                l2 = D ^ l2;
                Screen screen = mc.screen;
                String[] stringArray = kuzi.obf.j.b.a.b();
                currentScreen = screen;
                if (stringArray == null) break block2;
                if (currentScreen == null) break block3;
                currentScreen = screen;
            }
            currentScreen.onClose();
        }
    }

    private void lambda$onEnable$3(long l2, Minecraft mc) {
        l2 = D ^ l2;
        mc.setScreen(this.C);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean lambda$new$2(short s2, int n2, int n3) {
        long l2 = ((long)s2 << 48 | (long)n2 << 32 >>> 16 | (long)n3 << 48 >>> 48) ^ D;
        String[] stringArray = kuzi.obf.j.b.a.b();
        boolean enabled = (Boolean)this.backgroundBlur.a();
        if (stringArray == null) return enabled;
        if (enabled) return true;
        enabled = (Boolean)this.liquidGlass.a();
        if (stringArray == null) return enabled;
        if (!enabled) return false;
        return true;
    }

    private static void lambda$new$1() {
        Client.e.execute(Kuzi::lambda$new$0);
    }

    private static void lambda$new$0() {
        Client.e.setScreen((Screen)new X(true));
    }

    /*
     * Unable to fully structure code
     */
    static {
        block21: {
            block20: {
                block19: {
                    block18: {
                        Kuzi.D = kuzi.obf.h.b.v.a(-6209653569506355691L, 4784834606912280776L, MethodHandles.lookup().lookupClass()).a(204689584286890L);
                        Kuzi.K = new Object[65];
                        Kuzi.L = new String[65];
                        Kuzi.c();
                        Kuzi.G = new HashMap<K, V>(13);
                        var11 = Kuzi.D ^ 125727143451418L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[19];
                        var18_4 = 0;
                        var17_5 = "\u0013\u009e\u00bfY\u00ea\u00fcvm\u0010\u00d9rj,\u00f2\u00b3/\u0092\u000e\u00dd\u008d\u00c6\u00d3D\u00fc;\u00ff\u008a\u001bR\u00ea\u00ea\u00ae\u0010\u00d2\u0080W\u0088\u00a4~\u00ceUH!\u00ce\u0017\u00f4\u00d8V\u00e5\u0010\u00ac&\u00c5F\u00f2\u007f\u00e9;7\u00ab\u00e7\u0016\u0082\u00f3|\u00ef(\u00ab\u009f*}\u0004\u00df\u00f8N\u0081(i\u00d8\u00e9\u0081\u00da\u00a6\u00d4\u008a\u00f2\u0018\u00a5E\u00c2\u00da\u00c1v\u00b8KB\u00efQ\u00f3\u009d/\u00bb'|\u0086\u0092r =$z\u00a8\u001ax\u00ee\b\u00cc\u00d0\u001e\u0085Pn\u000eLj\u0095;\u0081\u00ed\u00fe\u00d65l\u009f\u00ad\u00c0\u00d6\u00a8+E\u0018{x\u00e1\u0007`\u00bfr\u00e9U\u001fu;\u00f5\u00a4\u00dc8\f-\u009e\u00c40\u0098tL \u000f\u00bd\u00da\u00bf\u00b2F]\u00fbb\u009eK?\u00ae\u0016\u00a5\u0013\u0004\u00f5\"\u0081\f\u00b3\u0003s}\u0093\u0006\u00e8\u0089h\u00dcH l\b\"\u00a5\u00f5%\u0003\u00bf\u00f86B\u00e0U\u00e3w\u00c7\u00ce\u00a8\u009a\u0095\u00c9P\u00d8\u0006\u0007\u00a2\u00a6i\n\u0087\u007f'\u0010\u0097\u00ce\u0011\u0013\u00f1:aA\u00f1\u00cdh\u00ca>QO\u00a3\u0018W\bdl\u008c)N\u00fd\u00a0TH\u007fx\u00cfk\u00c8\u00c9<F\u001c*\u0000\u00d6z m\t\u00c1\u00fcX\u0004\u00c4\u0010\u00b85\u0099G\u00b3\u00ceV\u00fcMy\u0019\u00d9C\u0002\u00a8\u00d6\u001c\u00cb}\u00e4aK\u00ec\u00b5(QT\u0082\u00f6\u00e35\u0013\u008d\u00d3\u00e7+\u0097p\u0005\u00d1\u0094\u0011\u00ec+\u0099\u0016\u00a1\u00fdS\u00e8\u00b3\u001f\u00d5[\u0016\u00f1\u009cQ\u00c5\u00f6\u0082a\u00b3d\u00d1 })M,]\u00d0\u00be\u008bEslL\u00977\u0084\u0091@\u001e\u00c9(l(\u00a3\u000b\u00f0\fS\u0098\u0012\u0016\u0098\t\u0018(\u00aa#1dt\u0014 e\u0011&\u00c2(\u00e9\u00b4\u0083{\u00f4\u0019mi\u00bc2e\u0018\u00a0\u00fb\u0086F\u00f6\u00df)\u00f5\u0092\u0084y\u0090\u001e\b\u00b5U\u00a6*p\u00d1\u0010\u00c9x\u00e2 HJ[\u00a5\\-\f\u00b1)\u00df6\u0011\u00a8ph\u0084\u00a0\u00fa\u001dS\u00ee\u00c0Z\u001e\u0080m\u0007\u00fdu\u0007Y%\u0018\u00c0j\f\\L\u0085\u00a7|\u00c5Yr\u0098\u00ee\u0014SVP\"\u00adk\u00e0\u00f2S\u00a6";
                        var19_6 = "\u0013\u009e\u00bfY\u00ea\u00fcvm\u0010\u00d9rj,\u00f2\u00b3/\u0092\u000e\u00dd\u008d\u00c6\u00d3D\u00fc;\u00ff\u008a\u001bR\u00ea\u00ea\u00ae\u0010\u00d2\u0080W\u0088\u00a4~\u00ceUH!\u00ce\u0017\u00f4\u00d8V\u00e5\u0010\u00ac&\u00c5F\u00f2\u007f\u00e9;7\u00ab\u00e7\u0016\u0082\u00f3|\u00ef(\u00ab\u009f*}\u0004\u00df\u00f8N\u0081(i\u00d8\u00e9\u0081\u00da\u00a6\u00d4\u008a\u00f2\u0018\u00a5E\u00c2\u00da\u00c1v\u00b8KB\u00efQ\u00f3\u009d/\u00bb'|\u0086\u0092r =$z\u00a8\u001ax\u00ee\b\u00cc\u00d0\u001e\u0085Pn\u000eLj\u0095;\u0081\u00ed\u00fe\u00d65l\u009f\u00ad\u00c0\u00d6\u00a8+E\u0018{x\u00e1\u0007`\u00bfr\u00e9U\u001fu;\u00f5\u00a4\u00dc8\f-\u009e\u00c40\u0098tL \u000f\u00bd\u00da\u00bf\u00b2F]\u00fbb\u009eK?\u00ae\u0016\u00a5\u0013\u0004\u00f5\"\u0081\f\u00b3\u0003s}\u0093\u0006\u00e8\u0089h\u00dcH l\b\"\u00a5\u00f5%\u0003\u00bf\u00f86B\u00e0U\u00e3w\u00c7\u00ce\u00a8\u009a\u0095\u00c9P\u00d8\u0006\u0007\u00a2\u00a6i\n\u0087\u007f'\u0010\u0097\u00ce\u0011\u0013\u00f1:aA\u00f1\u00cdh\u00ca>QO\u00a3\u0018W\bdl\u008c)N\u00fd\u00a0TH\u007fx\u00cfk\u00c8\u00c9<F\u001c*\u0000\u00d6z m\t\u00c1\u00fcX\u0004\u00c4\u0010\u00b85\u0099G\u00b3\u00ceV\u00fcMy\u0019\u00d9C\u0002\u00a8\u00d6\u001c\u00cb}\u00e4aK\u00ec\u00b5(QT\u0082\u00f6\u00e35\u0013\u008d\u00d3\u00e7+\u0097p\u0005\u00d1\u0094\u0011\u00ec+\u0099\u0016\u00a1\u00fdS\u00e8\u00b3\u001f\u00d5[\u0016\u00f1\u009cQ\u00c5\u00f6\u0082a\u00b3d\u00d1 })M,]\u00d0\u00be\u008bEslL\u00977\u0084\u0091@\u001e\u00c9(l(\u00a3\u000b\u00f0\fS\u0098\u0012\u0016\u0098\t\u0018(\u00aa#1dt\u0014 e\u0011&\u00c2(\u00e9\u00b4\u0083{\u00f4\u0019mi\u00bc2e\u0018\u00a0\u00fb\u0086F\u00f6\u00df)\u00f5\u0092\u0084y\u0090\u001e\b\u00b5U\u00a6*p\u00d1\u0010\u00c9x\u00e2 HJ[\u00a5\\-\f\u00b1)\u00df6\u0011\u00a8ph\u0084\u00a0\u00fa\u001dS\u00ee\u00c0Z\u001e\u0080m\u0007\u00fdu\u0007Y%\u0018\u00c0j\f\\L\u0085\u00a7|\u00c5Yr\u0098\u00ee\u0014SVP\"\u00adk\u00e0\u00f2S\u00a6".length();
                        var16_7 = 32;
                        var15_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block18;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = Kuzi.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "\u00a2xG\u00ae\u0083\u00d7\u009fuJq\u00bd\u00d9\\\t\u009f\by\u0005\u0098\u00a3\u0003P-\u00fa:\u00a77~b\u0003n\u00dc\u0010\f?\u0015\u00a5I\u0087B\u0091\u00dd\u0004\u00cfN\u00e77\u0005?";
                            var19_6 = "\u00a2xG\u00ae\u0083\u00d7\u009fuJq\u00bd\u00d9\\\t\u009f\by\u0005\u0098\u00a3\u0003P-\u00fa:\u00a77~b\u0003n\u00dc\u0010\f?\u0015\u00a5I\u0087B\u0091\u00dd\u0004\u00cfN\u00e77\u0005?".length();
                            var16_7 = 32;
                            var15_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block18;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = Kuzi.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block19;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                Kuzi.E = var20_3;
                Kuzi.F = new String[19];
                Kuzi.J = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[25];
                var3_13 = 0;
                var4_14 = "a\"E:\u0082\u00b0=\u00f1x\u00b8\u00d0\u0000\u001ful*\u00cd\u00fd\u00d3\u00a3\u00e3\u00d3a\u00e0\u0017\u00abi\u00ec\u00fa6\u00db\u00f1\u00b8\u00c3\u00beX\u00cc\u0004*\u00f35;(\u00f8F\u00eb\u0090\u00a6\u001bF9\u0087q\u00bfGy\u00c2FWvbw\b\u0000\u00f7\u00a5\u0012\u00b2}\u008c&\u00b3\u00e2\u00b5j\u0015\u00cdc\u0004gd\u00b64\u00c5\u007f82}\\V\u00f8e|\u0085\u00b5p\u00f5\u00b7\u0090\u00b8\u00ea\u00df\u00cc#u\u00b0\u00ac}Q\u0095\u00dc\u00be#\u00ab\f\u00c3C\u00db(:&:\u00ab\u00a8\u00b4\u00a7\u00bd\u00ac\u00f1\u00d0wz\u00fd9\u0084\u00c9\u00bb\t\u0091\u0015\u000fN\u0086\u0010qjr\u00c9(\u0012\u00a4\u007f=[n\u00a5N\u008a\u00ed+\u00ad\u008d\u008b\u00fdc\u00c4P\u001b\u0085\u0087\u00fd\u0018b.n\u0016\u0006\u00ce\u0092\u009b\u00d5\u0018\u00f0;";
                var5_15 = "a\"E:\u0082\u00b0=\u00f1x\u00b8\u00d0\u0000\u001ful*\u00cd\u00fd\u00d3\u00a3\u00e3\u00d3a\u00e0\u0017\u00abi\u00ec\u00fa6\u00db\u00f1\u00b8\u00c3\u00beX\u00cc\u0004*\u00f35;(\u00f8F\u00eb\u0090\u00a6\u001bF9\u0087q\u00bfGy\u00c2FWvbw\b\u0000\u00f7\u00a5\u0012\u00b2}\u008c&\u00b3\u00e2\u00b5j\u0015\u00cdc\u0004gd\u00b64\u00c5\u007f82}\\V\u00f8e|\u0085\u00b5p\u00f5\u00b7\u0090\u00b8\u00ea\u00df\u00cc#u\u00b0\u00ac}Q\u0095\u00dc\u00be#\u00ab\f\u00c3C\u00db(:&:\u00ab\u00a8\u00b4\u00a7\u00bd\u00ac\u00f1\u00d0wz\u00fd9\u0084\u00c9\u00bb\t\u0091\u0015\u000fN\u0086\u0010qjr\u00c9(\u0012\u00a4\u007f=[n\u00a5N\u008a\u00ed+\u00ad\u008d\u008b\u00fdc\u00c4P\u001b\u0085\u0087\u00fd\u0018b.n\u0016\u0006\u00ce\u0092\u009b\u00d5\u0018\u00f0;".length();
                var2_16 = 0;
                while (true) {
                    var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                    v10 = var6_12;
                    v11 = var3_13++;
                    v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                    v13 = -1;
                    break block20;
                    break;
                }
lbl81:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    var4_14 = "\t\u009f<\u00f7y-yl\u00c2\u00e1k\u00ec\u00d9\u00d91/";
                    var5_15 = "\t\u009f<\u00f7y-yl\u00c2\u00e1k\u00ec\u00d9\u00d91/".length();
                    var2_16 = 0;
                    while (true) {
                        var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                        v10 = var6_12;
                        v11 = var3_13++;
                        v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                        v13 = 0;
                        break block20;
                        break;
                    }
                    break;
                }
lbl94:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    break block21;
                    break;
                }
            }
            var8_18 = v12;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            v14 = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
            switch (v13) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl107:
                // 1 sources

                ** continue;
            }
        }
        Kuzi.H = var6_12;
        Kuzi.I = new Integer[25];
    }

    private static r a(r r2) {
        return r2;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x29DA;
        if (I[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = H[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])J.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    J.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/b/g", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Kuzi.I[n3] = n4;
        }
        return I[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = Kuzi.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/b/g" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (L[n4] != null) {
            return n4;
        }
        Object object = K[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 51;
            case 1 -> 62;
            case 2 -> 42;
            case 3 -> 32;
            case 4 -> 63;
            case 5 -> 60;
            case 6 -> 25;
            case 7 -> 27;
            case 8 -> 47;
            case 9 -> 31;
            case 10 -> 33;
            case 11 -> 0;
            case 12 -> 9;
            case 13 -> 10;
            case 14 -> 20;
            case 15 -> 56;
            case 16 -> 59;
            case 17 -> 44;
            case 18 -> 24;
            case 19 -> 61;
            case 20 -> 34;
            case 21 -> 18;
            case 22 -> 6;
            case 23 -> 50;
            case 24 -> 23;
            case 25 -> 40;
            case 26 -> 28;
            case 27 -> 48;
            case 28 -> 21;
            case 29 -> 11;
            case 30 -> 12;
            case 31 -> 13;
            case 32 -> 55;
            case 33 -> 57;
            case 34 -> 52;
            case 35 -> 1;
            case 36 -> 36;
            case 37 -> 29;
            case 38 -> 39;
            case 39 -> 43;
            case 40 -> 58;
            case 41 -> 8;
            case 42 -> 37;
            case 43 -> 35;
            case 44 -> 17;
            case 45 -> 16;
            case 46 -> 4;
            case 47 -> 54;
            case 48 -> 19;
            case 49 -> 46;
            case 50 -> 14;
            case 51 -> 49;
            case 52 -> 38;
            case 53 -> 5;
            case 54 -> 45;
            case 55 -> 41;
            case 56 -> 2;
            case 57 -> 15;
            case 58 -> 26;
            case 59 -> 7;
            case 60 -> 53;
            case 61 -> 30;
            case 62 -> 3;
            default -> 22;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        Kuzi.L[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = K;
        K[0] = ")$2L@3\"$1LF";
        objectArray[1] = "j\u000b5Bt$\u001f+>Mek~%5Fa1\n";
        objectArray[2] = "fZ\u001e4V\u0004fZ\thZ\u000b|\u0011\tvZ\u001e{`Y+\u000b";
        objectArray[3] = "V+{zyrV+l&u}L`l8uhK\u0011;g#";
        objectArray[4] = "`gIq\"*\u0015GB~3etIIu7?\u0000";
        objectArray[5] = Void.TYPE;
        Kuzi.L[5] = "java/lang/Void";
        objectArray[6] = "V\u0001\u001eH\u0011W]\u0001\u001dH\u0011";
        objectArray[7] = "\u000e\t5*BE{)>%S\n\u00061-\"ZCn";
        objectArray[8] = "V \u0019SePZ \n";
        objectArray[9] = "\u0010E\u0004d\u0010\u001bee\u000fk\u0001T\u0004k\u0004`\u0005\u000ep";
        objectArray[10] = Boolean.TYPE;
        Kuzi.L[10] = "java/lang/Boolean";
        objectArray[11] = "UT`UEr\\TcUA";
        objectArray[12] = "\u0018TyAKO\u0005A!c\nB\u001dG";
        objectArray[13] = "I\u001d\fYM\"<=\u0007V\\m]3\f]X7)";
        objectArray[14] = "=\u001b#-\u000f<4\u001b -\u0002";
        objectArray[15] = "T\u0002H\u0014\u007fa]\u0002K\u0014\u007f";
        objectArray[16] = "m}a$\u00000frpka>myt1";
        objectArray[17] = "Rtl\u0001D\u0001'Tg\u000eUNFZl\u0005Q\u00142";
        objectArray[18] = Integer.TYPE;
        Kuzi.L[18] = "java/lang/Integer";
        objectArray[19] = "vov\u0018>M\u007fou\u0018<";
        objectArray[20] = "ONX\u000fDGBNX\u000fF";
        objectArray[21] = "\u0007\u0019Km5\u0011\n\u0019Km0";
        objectArray[22] = Long.TYPE;
        Kuzi.L[22] = "java/lang/Long";
        objectArray[23] = "^8\u00073\u001ehU8\u000f";
        objectArray[24] = "!X{19-*Xx1:";
        objectArray[25] = "lCZ}KcgCQ";
        objectArray[26] = "t@4#=\\\u0001`?,,\u0013`n4'(I\u0014";
        objectArray[27] = "f\\;*_So\\8*S";
        objectArray[28] = "\u001d\u0018gO\u0000dh8l@\u0011+\t6gK\u0015q}";
        objectArray[29] = "&*ZwPvS\nQxA92\u0004ZsEcF";
        objectArray[30] = "{ECO\rg5ZK>\u0000\u0000'Z\u0016U\u001e8|QFTlk4DXX\u000ee9R\u001e>";
        objectArray[31] = "E[+*/Y\u000bD#[+>\u0013\u001a !%\u0003\u001aGre";
        objectArray[32] = "W,\u0013\u0011\u0013\u0003\u00193\u001b`\bd\u0001m\u0018\u001a\u0019Y\b0J^";
        objectArray[33] = "R\u0011(`iy\u0007\u0017\u007f=\u0010snCt3ny\u0010Fm$m\u0019";
        objectArray[34] = "\u000eS\u0001&\u001e=@L\tW\u0016Z\f_\u0000.\u001b<HW^7\u007fg@K\u001c3\u0019#H\u0015\u0005W";
        objectArray[35] = "rz+M\u000f\u0007<e#<\u0001`.e~W\u001cXun.Vn_}>+_^\u0007$:?<";
        objectArray[36] = "p~;\u0004.H>a3u#/,an\u001e=\u0017wj>\u001fO\u0010\u007f:;\u0016\u007fH&>/u";
        objectArray[37] = "K}2\u0017-;\u0019!<\tB\u0001`\\\u0003!\u001eJK}2\u0017-;\u0019!<\t";
        objectArray[38] = "t5(j}ex>wq\u0017S\\\u0016Hxlof$\"tg0}";
        objectArray[39] = ".&i7B ;x?>}3G&1t\u0016(\u007f}:$\u0017Z.&i7B ;x?>}";
        objectArray[40] = "i] .*M'B(_2*:Ex?tF$]u'";
        objectArray[41] = "yrqb`vl,'k_e\u0010{{!`imw)zg\f";
        objectArray[42] = "#+\u0019Pgkm4\u0011!z\f~m\u0007S8b#$\u001cB";
        objectArray[43] = "M\u00060`-\"\u0003\u00198\u0011*E\u001e\u001ehqs)\u0000\u0006ei";
        objectArray[44] = "20d[\u00023|/l*\nTn/1A\u0011l5$a@cm\u007f3=QZ$u#=*";
        objectArray[45] = "eP2RW`+O:#}\u0007`G:@\u000bb WfL";
        objectArray[46] = "\u0007hk\u001e-\"Iwco>E\u0007iw\u00161)Q-f\u0016";
        objectArray[47] = "\u001d3Rw\tVS,Z\u0006\u000f1N+\nfW]P3\u0007~";
        objectArray[48] = "\r_c|\u0001yC@k\r\n\u001eQ@6f\u0012&\nKfg`%]\\`|]{W\u001dy\r";
        objectArray[49] = "\u0007\fvX4IR\n!\u0005Mea$\u0010.\nv}ct\rs\u0013B\u0003!\u000b$N";
        objectArray[50] = "^\u0006,k$S\u0010\u0019$\u001a;4\r\u001etzzX\u0013\u0006yb";
        objectArray[51] = "f#R\u0010cz0gC\u0010\u001e\u007fYoF\t!jf \u0014Ra\u0016";
        objectArray[52] = "\u0006\u0007bf7\u0005H\u0018j\u0017'b\u0006\u0006~n+\u000ePBon";
        objectArray[53] = "MES\u0015A}\u0018C\u0004H8W6zm\u0013W#KS\rFQt\u0016";
        objectArray[54] = "\u0004\u0011\f!GD\u0010^Z& \u0015iB\u000f=Y\u0003\u0007P[gB|\u0007R\u0006f\u0018\u0002\u000eHSb G\u0006Q\f(\u001d\u0019\f\u0010\u0015Y";
        objectArray[55] = "D5{A\u0013e\n*s08\u0002D4gI\u000fn\u0012pvI";
        objectArray[56] = "KM^\u0019`G\u001d\tO\u0019\u001dBt\u0001J\u0000\"WKN\u0018[b+O^X\u0007l\u0016\u0011T\u0019\u001e\u001d";
        objectArray[57] = "r~\n\r\u000e\u0007<a\u0002|\u001f`!fR\u001cP\f?~_\u0004";
        objectArray[58] = "FC/5up\u0019Di+\u001ao&Np~q|\u001e\u0015{.p\u000e\u001dBl(k3CH-1\u001a";
        objectArray[59] = "{g\u000b0\u0006g5x\u0003A\u001c\u0000&!\u00153Yn{h\u000e\"";
        objectArray[60] = "_X*\u0011M6\u0011G\"`TQ\f@r\u0000\u0013=\u0012X\u007f\u0018";
        objectArray[61] = "\u0016\u001b;e\u0018rX\u00043\u00140\u0015\u0016\u001a'm\u0004y@^6m";
        objectArray[62] = "_\u0014KLO6\u0011\u000bC=SQ\u0002RUO\u0010?_\u001bN^";
        objectArray[63] = "\u0005wj;K\u0001Zp,%$\u001bez5pO\r]!> N\u007f^v)&UB\u0000|h?$";
        Object[] objectArray2 = objectArray;
        objectArray[64] = "f1Rl\u0003i(.Z\u001d\u001d\u000e;wLo\\`f>W~";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = Kuzi.e(l2, l3);
            object = K[n2];
            try {
                if (!(object instanceof String)) break block2;
                Kuzi.K[n2] = clazz = Class.forName(L[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = Kuzi.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = Kuzi.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = Kuzi.e(l2, l3);
        Object object = K[n2];
        if (object instanceof String) {
            String string = L[n2];
            int n3 = string.indexOf(8);
            Class clazz = Kuzi.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = Kuzi.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = Kuzi.c(clazz3, string2, clazz2)) != null) {
                    Kuzi.K[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = Kuzi.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        Kuzi.K[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = Kuzi.f(1140450299307900L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = Kuzi.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = Kuzi.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = Kuzi.e(l2, l3);
        Object object = K[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = L[n2];
                int n4 = string2.indexOf(8);
                clazz3 = Kuzi.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = Kuzi.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = Kuzi.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        Kuzi.K[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = Kuzi.f(1140450299307900L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = Kuzi.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        Kuzi.K[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = Kuzi.f(1140450299307900L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == '\u00f3' || c2 == 'V' || c2 == '\u00d1' || c2 == '\u00f8') {
                field = Kuzi.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == '\u00f3' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == 'V' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == '\u00d1' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = Kuzi.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == '\u00ff' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == '\u00e1' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = Kuzi.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/b/g" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Kuzi.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(Kuzi.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

