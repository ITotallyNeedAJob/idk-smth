// === Kuzi module: Configs ===
// Category   : CLIENT
// Description: Save, load and delete local configs
// Payload    : a.a.a.j.b.i (verified: True)

package kuzi.modules.client;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.e.e;
import kuzi.obf.h.S;
import kuzi.obf.h.b.v;
import kuzi.obf.h.t_0;
import kuzi.obf.m.r;
import kuzi.settings.ButtonSetting;
import kuzi.settings.Setting;
import kuzi.settings.StringSetting;
import net.minecraft.Minecraft;
import net.minecraft.Screen;

public class Configs
extends BaseModule {
    private final StringSetting name;
    private static final long n;
    private static final String[] o;
    private static final String[] p;
    private static final Map q;
    private static final Object[] r;
    private static final String[] s;

    public Configs() {
        long l2 = n ^ 0x4BAD01AD804AL;
        long l3 = l2 ^ 0x2CE2B716EBE5L;
        int n2 = (int)(l3 >>> 32);
        int n3 = (int)(l3 << 32 >>> 48);
        int n4 = (int)(l3 << 48 >>> 48);
        super("Configs", "Save, load and delete local configs", Category.CLIENT);
        this.name = new StringSetting("Name", "my-config");
        this.a(n2, (char)n3, n4);
    }

    public void a(int n2, char c2, int n3) {
        CallSite callSite;
        CallSite callSite2;
        CallSite callSite3;
        long l2;
        long l3;
        long l4;
        long l5;
        block3: {
            block4: {
                long l6 = l5 = ((long)n2 << 32 | (long)c2 << 48 >>> 32 | (long)n3 << 48 >>> 48) ^ n;
                long l7 = l6 ^ 0x15E9C76D4919L;
                l4 = l6 ^ 0x1095A3784C11L;
                l3 = l6 ^ 0x15F7EDF035ECL;
                long l8 = l6 ^ 0x54237947359FL;
                int n4 = (int)(l8 >>> 32);
                int n5 = (int)(l8 << 32 >>> 48);
                int n6 = (int)(l8 << 48 >>> 48);
                l2 = l6 ^ 0x46ACBDC6F0BAL;
                CallSite callSite4 = Configs.c("X", (long)7757769869521498112L, (long)l5);
                Configs.c("\u00d8", (Object)this, (long)7758037655350636006L, (long)l5).clear();
                Object[] objectArray = new Object[2];
                objectArray[1] = new Setting[]{Configs.c("\u00d8", (Object)this, (long)7757459119685032682L, (long)l5), new ButtonSetting((String)((Object)Configs.b("n", (int)17442, (long)(0xF39EF89D4B7EB36L ^ l5))), () -> this.b(l7)), new ButtonSetting((String)((Object)Configs.b("n", (int)10630, (long)(0x3C388B5553D9869CL ^ l5))), Configs::lambda$rebuild$1), new ButtonSetting((String)((Object)Configs.b("n", (int)18821, (long)(0x4BD04AA18BE3E693L ^ l5))), () -> this.a(n4, (char)n5, n6)), new ButtonSetting((String)((Object)Configs.b("n", (int)28537, (long)(0x2FF5D10B6A6BC062L ^ l5))), Configs::lambda$rebuild$3)};
                objectArray[0] = l2;
                Configs.c("\u00ce", (Object)this, (Object)objectArray, (long)7757180592985204632L, (long)l5);
                callSite3 = callSite4;
                callSite2 = Configs.c("\u00ce", (Object)this, (Object)new Object[0], (long)7758201914227498155L, (long)l5);
                try {
                    callSite = callSite2;
                    if (callSite3 == null) break block3;
                    if (callSite != null) break block4;
                }
                catch (r r2) {
                    throw Configs.c("X", (Object)r2, (long)7757590792682669681L, (long)l5);
                }
                return;
            }
            callSite = callSite2;
        }
        Iterator iterator = ((e)((Object)callSite)).a().iterator();
        while (iterator.hasNext()) {
            String string;
            String string2 = string = (String)iterator.next();
            Object[] objectArray = new Object[2];
            objectArray[1] = new Setting[]{new ButtonSetting((String)((Object)Configs.b("n", (int)2053, (long)(0x55C3EA6EBF5AA71BL ^ l5))) + string2, () -> this.lambda$rebuild$4((e)((Object)callSite2), l3, string2))};
            objectArray[0] = l2;
            Configs.c("\u00ce", (Object)this, (Object)objectArray, (long)7757180592985204632L, (long)l5);
            Object[] objectArray2 = new Object[2];
            objectArray2[1] = new Setting[]{new ButtonSetting((String)((Object)Configs.b("n", (int)23957, (long)(0xC0BEFD4F6CB728DL ^ l5))) + string2, () -> this.lambda$rebuild$5((e)((Object)callSite2), l4, string2))};
            objectArray2[0] = l2;
            Configs.c("\u00ce", (Object)this, (Object)objectArray2, (long)7757180592985204632L, (long)l5);
            if (callSite3 != null) continue;
        }
    }

    private void b(long l2) {
        CallSite callSite;
        int n2;
        int n3;
        int n4;
        long l3;
        block5: {
            CallSite callSite2;
            block6: {
                long l4 = l2 = n ^ l2;
                l3 = l4 ^ 0x735804F7A510L;
                long l5 = l4 ^ 0x15E9C76D4919L;
                n4 = (int)(l5 >>> 32);
                n3 = (int)(l5 << 32 >>> 48);
                n2 = (int)(l5 << 48 >>> 48);
                callSite2 = Configs.c("\u00ce", (Object)this, (Object)new Object[0], (long)1669967139481804845L, (long)l2);
                CallSite callSite3 = Configs.c("X", (long)1670663193638521990L, (long)l2);
                try {
                    callSite = callSite2;
                    if (callSite3 == null) break block5;
                    if (callSite != null) break block6;
                }
                catch (r r2) {
                    throw Configs.c("X", (Object)r2, (long)1670341178808826615L, (long)l2);
                }
                return;
            }
            callSite = callSite2;
        }
        try {
            if (((e)((Object)callSite)).a((String)((Object)Configs.c("\u00ce", (Object)Configs.c("\u00d8", (Object)this, (long)1670349740855436908L, (long)l2), (long)1670419488904296299L, (long)l2)))) {
                Object[] objectArray = new Object[3];
                objectArray[2] = l3;
                objectArray[1] = (String)((Object)Configs.c("\u00ce", (Object)Configs.c("\u00d8", (Object)this, (long)1670349740855436908L, (long)l2), (long)1670419488904296299L, (long)l2));
                objectArray[0] = Configs.b("n", (int)11089, (long)(0x14AFCF80B9CF78C2L ^ l2));
                Configs.c("\u00ce", (Object)this, (Object)objectArray, (long)1670611778348331760L, (long)l2);
                Configs.c("\u00ce", (Object)this, (int)n4, (char)((char)n3), (int)n2, (long)1669872347958087165L, (long)l2);
            }
        }
        catch (r r3) {
            throw Configs.c("X", (Object)r3, (long)1670341178808826615L, (long)l2);
        }
    }

    private void lambda$rebuild$5(e e2, long l2, String string) {
        long l3 = (l2 = n ^ l2) ^ 0x1095A3784C11L;
        int n2 = (int)(l3 >>> 32);
        int n3 = (int)(l3 << 32 >>> 48);
        int n4 = (int)(l3 << 48 >>> 48);
        e2.c(string);
        Configs.c("\u00ce", (Object)this, (int)n2, (char)((char)n3), (int)n4, (long)1307329710595705077L, (long)l2);
    }

    private void lambda$rebuild$4(e e2, long l2, String string) {
        long l3 = (l2 = n ^ l2) ^ 0x73462E6AD9E5L;
        try {
            if (e2.b(string)) {
                Object[] objectArray = new Object[3];
                objectArray[2] = l3;
                objectArray[1] = string;
                objectArray[0] = Configs.b("n", (int)25227, (long)(0x214BB645E3104DE5L ^ l2));
                Configs.c("\u00ce", (Object)this, (Object)objectArray, (long)7771581906714643973L, (long)l2);
            }
        }
        catch (r r2) {
            throw Configs.c("X", (Object)r2, (long)7771874223622325762L, (long)l2);
        }
    }

    private static void lambda$rebuild$3() {
        Minecraft.getInstance().execute(Configs::lambda$rebuild$2);
    }

    private static void lambda$rebuild$2() {
        Minecraft.getInstance().setScreen((Screen)new S());
    }

    private static void lambda$rebuild$1() {
        Minecraft.getInstance().execute(Configs::lambda$rebuild$0);
    }

    private static void lambda$rebuild$0() {
        Minecraft.getInstance().setScreen((Screen)new t_0());
    }

    /*
     * Unable to fully structure code
     */
    static {
        block11: {
            block10: {
                Configs.n = v.a(-6592719283199342258L, 6050956562431146246L, MethodHandles.lookup().lookupClass()).a(251672266656454L);
                Configs.r = new Object[34];
                Configs.s = new String[34];
                Configs.c();
                Configs.q = new HashMap<K, V>(13);
                var0 = Configs.n ^ 54019799708034L;
                var2_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                v0 = SecretKeyFactory.getInstance("DES");
                v1 = new byte[8];
                v2 = v1;
                v1[0] = (byte)(var0 >>> 56);
                for (var3_2 = 1; var3_2 < 8; ++var3_2) {
                    v2 = v2;
                    v2[var3_2] = (byte)(var0 << var3_2 * 8 >>> 56);
                }
                var2_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                var9_3 = new String[12];
                var7_4 = 0;
                var6_5 = "5\u00e3\u0000\u00bd9\u0010/\u00b1\u00dd`\f\u00c3\u00bb\u00cc?\u00b1\u0010+\u00a5\u0091\u00886&;\u0005\u00d8[\u00a3\u00a0X\u00e2B\b agjS}\u00ef\u00e9\u00d7f\u00e9@\u00b2\u00a0Y\u00a6\u009d\u00af\u00ca+\u00da6D\u00d0 (\u0001\u008b\u00fc +\u00d9e@\u0007\u00c2\u0081O\u0005/`\u00d2\u00c69\u00fc7}K\u00fb\u00d8~\u00a0\u0010\u0094\u00e3\u00a3+\u0005\u00c8\u00e4\t[\u00e4$\u00dc\u00c7\u001f]\u00c3\u0017\u0003e;B5\u00e9\u00a1r\u00e5S\u00b1\u0004n\u008fK\u00d8\u0011\u0096`\"\u00e0\u00e4?\u00d3\u00b7\u00d60y \u0091\f\u009b\u00b2\u00ef\u00ff\u0013\u00ce\u0014}\u008a\u00fa\u0080\u00ef\"p\u00e2;\u00dc\u00d7\u0093\u00c9yZ\u007f\u0094\u00b3\u00a9^]Wt \u000b\u00b4kz\u00b3\u0083b\u0010\u00c0b\u0014\u001473\u00b1(\u00a3o\u00bd\u00b0\u00a9\u00a1\u00b1&\"\n<\u000e\u00bb\u0014D\u0088\u0018\u0086B:\u0019|\u00e6/1\u009f\u000b\u00b4\u000f\u00e4e:?\u0007\u00a9Kh3\u00dc\u00ee\u00b5 9>\u00e6\u00e8\\=\u00a2\u00c3\u000b\u00a1M\u00d6)\u0098>l\u001b\u0011\u00c9\u00a9\u00bc\u00c7\u0015\u00f6z(\u0099\u0019f\u00cc\u0097\u00f2\u0010\u0019\u000fZ\u009a\u0086HH\u0081\u00a1F|{D\u00a6*\u00fc G\u0007\u001eM\u00a4\u00d7\u0091x\u0001\u00d7\u00d1\r\u001b\u00d38\u00b9\u00eaSL*\u008c\u00e871\u00a2\u00aeiF\u0088Y\u00ab\u00ec";
                var8_6 = "5\u00e3\u0000\u00bd9\u0010/\u00b1\u00dd`\f\u00c3\u00bb\u00cc?\u00b1\u0010+\u00a5\u0091\u00886&;\u0005\u00d8[\u00a3\u00a0X\u00e2B\b agjS}\u00ef\u00e9\u00d7f\u00e9@\u00b2\u00a0Y\u00a6\u009d\u00af\u00ca+\u00da6D\u00d0 (\u0001\u008b\u00fc +\u00d9e@\u0007\u00c2\u0081O\u0005/`\u00d2\u00c69\u00fc7}K\u00fb\u00d8~\u00a0\u0010\u0094\u00e3\u00a3+\u0005\u00c8\u00e4\t[\u00e4$\u00dc\u00c7\u001f]\u00c3\u0017\u0003e;B5\u00e9\u00a1r\u00e5S\u00b1\u0004n\u008fK\u00d8\u0011\u0096`\"\u00e0\u00e4?\u00d3\u00b7\u00d60y \u0091\f\u009b\u00b2\u00ef\u00ff\u0013\u00ce\u0014}\u008a\u00fa\u0080\u00ef\"p\u00e2;\u00dc\u00d7\u0093\u00c9yZ\u007f\u0094\u00b3\u00a9^]Wt \u000b\u00b4kz\u00b3\u0083b\u0010\u00c0b\u0014\u001473\u00b1(\u00a3o\u00bd\u00b0\u00a9\u00a1\u00b1&\"\n<\u000e\u00bb\u0014D\u0088\u0018\u0086B:\u0019|\u00e6/1\u009f\u000b\u00b4\u000f\u00e4e:?\u0007\u00a9Kh3\u00dc\u00ee\u00b5 9>\u00e6\u00e8\\=\u00a2\u00c3\u000b\u00a1M\u00d6)\u0098>l\u001b\u0011\u00c9\u00a9\u00bc\u00c7\u0015\u00f6z(\u0099\u0019f\u00cc\u0097\u00f2\u0010\u0019\u000fZ\u009a\u0086HH\u0081\u00a1F|{D\u00a6*\u00fc G\u0007\u001eM\u00a4\u00d7\u0091x\u0001\u00d7\u00d1\r\u001b\u00d38\u00b9\u00eaSL*\u008c\u00e871\u00a2\u00aeiF\u0088Y\u00ab\u00ec".length();
                var5_7 = 16;
                var4_8 = -1;
lbl23:
                // 2 sources

                while (true) {
                    v3 = ++var4_8;
                    v4 = var6_5.substring(v3, v3 + var5_7);
                    v5 = -1;
                    break block10;
                    break;
                }
lbl28:
                // 1 sources

                while (true) {
                    var9_3[var7_4++] = Configs.b(var10_9).intern();
                    if ((var4_8 += var5_7) < var8_6) {
                        var5_7 = var6_5.charAt(var4_8);
                        ** continue;
                    }
                    var6_5 = "\u00da\u0006\u00b3'q\u00aayM\u001cl\u0002n=\u001d\u00ea\u00a2z\u00d6\u00ee\u00c9\u00da\u009c=gi\u00a1\bs\u0006\u00c3:\u001e \u001d\b\u009b\u000f\u00b0\u00db\u00c6\u0017\u00a8\u00cad\u00d9:3L\u00ec\u00fc\u00c8\u00c5\u00ecH\u008d\u00b7\\\u00a2\u00ca^qI8\u00d4\u00e5";
                    var8_6 = "\u00da\u0006\u00b3'q\u00aayM\u001cl\u0002n=\u001d\u00ea\u00a2z\u00d6\u00ee\u00c9\u00da\u009c=gi\u00a1\bs\u0006\u00c3:\u001e \u001d\b\u009b\u000f\u00b0\u00db\u00c6\u0017\u00a8\u00cad\u00d9:3L\u00ec\u00fc\u00c8\u00c5\u00ecH\u008d\u00b7\\\u00a2\u00ca^qI8\u00d4\u00e5".length();
                    var5_7 = 32;
                    var4_8 = -1;
lbl37:
                    // 2 sources

                    while (true) {
                        v6 = ++var4_8;
                        v4 = var6_5.substring(v6, v6 + var5_7);
                        v5 = 0;
                        break block10;
                        break;
                    }
                    break;
                }
lbl42:
                // 1 sources

                while (true) {
                    var9_3[var7_4++] = Configs.b(var10_9).intern();
                    if ((var4_8 += var5_7) < var8_6) {
                        var5_7 = var6_5.charAt(var4_8);
                        ** continue;
                    }
                    break block11;
                    break;
                }
            }
            var10_9 = var2_1.doFinal(v4.getBytes("ISO-8859-1"));
            switch (v5) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl54:
                // 1 sources

                ** continue;
            }
        }
        Configs.o = var9_3;
        Configs.p = new String[12];
    }

    private static String b(byte[] byArray) {
        int outIndex = 0;
        int length = byArray.length;
        char[] cArray = new char[length];
        for (int i2 = 0; i2 < length; ++i2) {
            char decodedChar;
            int currentByte = 0xFF & byArray[i2];
            if (currentByte < 192) {
                cArray[outIndex++] = (char)currentByte;
                continue;
            }
            if (currentByte < 224) {
                decodedChar = (char)((char)(currentByte & 0x1F) << 6);
                currentByte = byArray[++i2];
                decodedChar = (char)(decodedChar | (char)(currentByte & 0x3F));
                cArray[outIndex++] = decodedChar;
                continue;
            }
            if (i2 >= length - 2) continue;
            decodedChar = (char)((char)(currentByte & 0xF) << 12);
            currentByte = byArray[++i2];
            decodedChar = (char)(decodedChar | (char)(currentByte & 0x3F) << 6);
            currentByte = byArray[++i2];
            decodedChar = (char)(decodedChar | (char)(currentByte & 0x3F));
            cArray[outIndex++] = decodedChar;
        }
        return new String(cArray, 0, outIndex);
    }

    private static String b(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x44B0;
        if (p[n3] == null) {
            Object[] objectArray;
            try {
                Long l3 = Thread.currentThread().threadId();
                objectArray = (Object[])q.get(l3);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    q.put(l3, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/b/i", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l2 >>> 56);
            for (int i2 = 1; i2 < 8; ++i2) {
                byArray[i2] = (byte)(l2 << i2 * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = o[n3].getBytes("ISO-8859-1");
            Configs.p[n3] = Configs.b(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return p[n3];
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        String string2 = Configs.b(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static CallSite b(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/b/i" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (s[n4] != null) {
            return n4;
        }
        Object object = r[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 38;
            case 1 -> 63;
            case 2 -> 18;
            case 3 -> 40;
            case 4 -> 48;
            case 5 -> 30;
            case 6 -> 47;
            case 7 -> 29;
            case 8 -> 41;
            case 9 -> 8;
            case 10 -> 34;
            case 11 -> 50;
            case 12 -> 32;
            case 13 -> 53;
            case 14 -> 5;
            case 15 -> 20;
            case 16 -> 10;
            case 17 -> 31;
            case 18 -> 12;
            case 19 -> 3;
            case 20 -> 37;
            case 21 -> 28;
            case 22 -> 4;
            case 23 -> 26;
            case 24 -> 59;
            case 25 -> 39;
            case 26 -> 36;
            case 27 -> 44;
            case 28 -> 7;
            case 29 -> 55;
            case 30 -> 35;
            case 31 -> 24;
            case 32 -> 56;
            case 33 -> 52;
            case 34 -> 13;
            case 35 -> 6;
            case 36 -> 25;
            case 37 -> 43;
            case 38 -> 54;
            case 39 -> 16;
            case 40 -> 62;
            case 41 -> 2;
            case 42 -> 9;
            case 43 -> 57;
            case 44 -> 27;
            case 45 -> 19;
            case 46 -> 14;
            case 47 -> 21;
            case 48 -> 23;
            case 49 -> 33;
            case 50 -> 42;
            case 51 -> 17;
            case 52 -> 49;
            case 53 -> 1;
            case 54 -> 58;
            case 55 -> 45;
            case 56 -> 61;
            case 57 -> 22;
            case 58 -> 0;
            case 59 -> 15;
            case 60 -> 11;
            case 61 -> 60;
            case 62 -> 51;
            default -> 46;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        Configs.s[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = r;
        r[0] = "eVD \u0016BnVG \u001e";
        objectArray[1] = Integer.TYPE;
        Configs.s[1] = "java/lang/Integer";
        objectArray[2] = Character.TYPE;
        Configs.s[2] = "java/lang/Character";
        objectArray[3] = Void.TYPE;
        Configs.s[3] = "java/lang/Void";
        objectArray[4] = "na\u0003@K\u0013\u001bA\bOZ\\zO\u0003D^\u0006\u000e";
        objectArray[5] = "+&8\u001e\u0003\u0016/&<";
        objectArray[6] = "\u001f\u001a01@Zj:;>Q\u0015\u000b405UO\u007f";
        objectArray[7] = "e1NJZ\rn1MJZ";
        objectArray[8] = "z\u0015Sw$k\u000f5Xx5$r-K\u007f<m\u001a";
        objectArray[9] = "\u0013,\u001fk\u001e\u0015\u001f,\f";
        objectArray[10] = "#ay$!\f*az$3";
        objectArray[11] = "iVV3g@`VU3g";
        objectArray[12] = "0\f|6\u0002d;\u0003mycj0\bi#";
        objectArray[13] = "c'W`\t$h'_";
        objectArray[14] = "i\u0006\u001e]U3b\u0006\u0015";
        objectArray[15] = "+jGX\u0010\u00115b]\u0017r\r2\u007f";
        objectArray[16] = "8ssj\u000e\u0010MSxe\u001f_,]sn\u001b\u0005X";
        objectArray[17] = "\u0014\u0001\b\u001cpK\u0005\u0001\bG";
        objectArray[18] = ".|\t1mo[\\\u0002>| :R\t5xzN";
        objectArray[19] = "F<^|'\u001e3\u001cUs6QR\u0012^x2\u000b&";
        objectArray[20] = "5\fV+8Z$\fY";
        objectArray[21] = "G\u0002\u0012\u0004`,SCO\u001f\r%.Q\u000f\b6w\u0013J\u0019]6";
        objectArray[22] = "Q_\u00117i\bO\b\u0002Y{1\u0007\\\f?~\tQ\u0001\u0002 \u0012\bS\u001d\u001fc|\rB\\\u001fY+\u000bQ\u0000\u000fa}V_\u001fccqPG\u0005\u0012i|T\u0001f";
        objectArray[23] = "`o\u0014^.B~8\u00070<{c-\u001f\\8\u0004t&\u001a]U@h<XYo\u001bn(\u00160";
        objectArray[24] = "vK>Vh\u0018h\u001c-8z!u\t5T~^b\u00020U\u0013\u001bz\u00135[b\u0011w\u0017s8";
        objectArray[25] = ".=~O)sal-R\u0010r\u0013i7Jl%,(?Aq\u0018";
        objectArray[26] = "V}bOp#\u0006{bY\u001e8=.iDr?B9bAsR\u0007!sD}#\r,w\u0002\u001e";
        objectArray[27] = "\u0002{?cOeX}*l/\u001ew\\\u0003WsU\u0002{?cOeX}*l";
        objectArray[28] = "\b\f+\u001c_\u001e\u0016[8rM'YW;\u0003F\u001f\u001dL'\n$\u0019\u0005W(\u0010\u001c]\u001eK!r";
        objectArray[29] = ";x!\u0015T;%/2{J\u0002k*:\u0004S|;q9\u001c";
        objectArray[30] = "\u001fi^}33E(@i\ne/fPnmvFl\u0003rg\f";
        objectArray[31] = "6Y6E,Vf_6SBN]\n=N.J\"\u001d6K/'6Y6E,Vf_6SB";
        objectArray[32] = "\n\u0003\"3l\u000eW\u001a:k\u0012? %\u0017\u001b]#<*\u0007\u0017\u0012\u0019\u0007\u00180$hD\u001e\u0000h";
        Object[] objectArray2 = objectArray;
        objectArray[33] = "pC\bK\ted\u0002UPdg\u0019\u0015\u0011W\bnf\u0002\u001aR\t\u0003#\u001a\u000bW\u0007r)\u0017\u000f\u0011d";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = Configs.e(l2, l3);
            object = r[n2];
            try {
                if (!(object instanceof String)) break block2;
                Configs.r[n2] = clazz = Class.forName(s[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = Configs.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = Configs.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = Configs.e(l2, l3);
        Object object = r[n2];
        if (object instanceof String) {
            String string = s[n2];
            int n3 = string.indexOf(8);
            Class clazz = Configs.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = Configs.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = Configs.c(clazz3, string2, clazz2)) != null) {
                    Configs.r[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = Configs.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        Configs.r[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = Configs.f(856966026649370L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = Configs.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = Configs.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = Configs.e(l2, l3);
        Object object = r[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = s[n2];
                int n4 = string2.indexOf(8);
                clazz3 = Configs.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = Configs.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = Configs.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        Configs.r[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = Configs.f(856966026649370L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = Configs.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        Configs.r[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = Configs.f(856966026649370L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == '\u00d8' || c2 == 'A' || c2 == 'J' || c2 == '\u00fd') {
                field = Configs.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == '\u00d8' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == 'A' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == 'J' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = Configs.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == '\u00ce' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == 'X' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = Configs.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/b/i" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Configs.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(Configs.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

