// === Kuzi module: CloudConfig ===
// Category   : CLIENT
// Description: Opens the cloud config browser
// Payload    : a.a.a.j.b.h (verified: True)

package kuzi.modules.client;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.S;
import kuzi.obf.h.q_0;
import kuzi.obf.j.b.a;
import kuzi.obf.m.r;
import net.minecraft.Minecraft;
import net.minecraft.Screen;

public class CloudConfig
extends BaseModule {
    private static final long m = 60145484803728L;
    private static final Object[] q = new Object[]{"\u000bf-<CA\u0000f&", "Y\u001fg6)0Y\u001fpj%?CTpt%*D% )t", "y\\:f}\u0000r\\9f}", ".y:},l[Y1r=#&A\"u4jN", "-/\u0017`zb&/\u0014`s", "\u0000qw:Ws\fqd", "&gA*&gSGJ%7(2IA.3rF", "\u0015n4\u0001\t\u000e\u001cn\u0004", "@e\u001b\u0018 I5E\u0010\u00171\u0006TK\u001b\u001c5\\ ", "\u0014I5O)4\u001fI6O/", "LG[SHDEGXSE", "o=\b'(|f=\u000b'(", "m!BXt4f.S\u0017\u0015:m%WM", "u\u001d\u0011911~\u001d\u0019", "y|n\u001a@a(ladJ\u001a:ri]S|>wb", "v\u000f\t\u0017Pa3\u001f\bL4iK]\u0002V\u000ens\u001f\n\u0011N\u0002v\u000f\t\u0017Pa3\u001f\bL4", "x73\u001b+H'0hE\u0012@Fl:IuU$,2N/", "\f/Ku8ZJ2\u0010o\u0002A7}Fw8D\u000f?N0x(J!M7rNN$F\u000e", "bQl\u0017E\u0011*\u0012h_4\u001b[\u0013c\u0001JM)\u00142\tPq", "1ZSt^\ng\u0001U6d\u001b\u000e\f\u0002w\u0003\tm\u0006U1\u0003r", "\u0003\u0019\fA.\u000eKZ\b\t_$}1m\u0001'\u000fC\u0010\rId\u000b\u000b", "`SKY-^&N\u0010C\u0017E[\u0007]@yS+S\u001a@j,`ABLh\\4\u0006B_\u0017", "&b\u0011dR(oa\u001a.*\u001fSL'\u0019vT&b\u0011dR(oa\u001a."};

    public CloudConfig() {
        super("CloudConfig", "Opens the cloud config browser", Category.CLIENT);
    }

    @Override
    public void d() {
        long l2;
        long l3 = l2 = m ^ 0x5D3E0A37095DL;
        long l4 = l3 ^ 0x44B75E0F9360L;
        long l5 = l3 ^ 0x2E9F465F6D58L;
        Object[] objectArray = new Object[1];
        objectArray[0] = l5;
        Minecraft mc = this.a(objectArray);
        String[] stringTable = kuzi.obf.j.b.a.b();
        Minecraft mcRef = mc;
        if (stringTable != null) {
            if (mcRef == null) {
                return;
            }
            mcRef = mc;
        }
        mcRef.execute(() -> CloudConfig.lambda$onEnable$0(mc, l4));
    }

    @Override
    public void e() {
        long l2;
        long l3 = l2 = m ^ 0x484213D66973L;
        long l4 = l3 ^ 0x75A60F76B5D9L;
        long l5 = l3 ^ 0x3BE35FBE0D76L;
        Object[] objectArray = new Object[1];
        objectArray[0] = l5;
        Minecraft mc = this.a(objectArray);
        String[] stringTable = kuzi.obf.j.b.a.b();
        Minecraft mcRef = mc;
        if (stringTable != null) {
            if (mcRef == null) {
                return;
            }
            mcRef = mc;
        }
        mcRef.execute(() -> CloudConfig.lambda$onDisable$1(mc, l4));
    }

    private Minecraft a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = m ^ l2;
        String[] stringTable = kuzi.obf.j.b.a.b();
        Minecraft mc = BaseModule.a;
        if (stringTable != null) {
            mc = mc != null ? BaseModule.a : Minecraft.getInstance();
        }
        return mc;
    }

    private static void lambda$onDisable$1(Minecraft mc, long l2) {
        block3: {
            Screen screen;
            block2: {
                l2 = m ^ l2;
                String[] stringTable = kuzi.obf.j.b.a.b();
                screen = mc.screen;
                if (stringTable == null) break block2;
                if (!(screen instanceof S)) break block3;
                screen = mc.screen;
            }
            screen.onClose();
        }
    }

    /*
     * Unable to fully structure code
     */
    private static void lambda$onEnable$0(Minecraft var0, long var1_1) {
        block4: {
            block5: {
                var3_2 = (var1_1 = CloudConfig.m ^ var1_1) ^ 56182723674013L;
                var5_3 = kuzi.obf.j.b.a.b();
                if (var0.screen instanceof S) break block4;
                var6_4 = Client.a();
                v0 = var6_4;
                if (var1_1 < 0L || var5_3 == null) break block5;
                if (v0 == null) ** GOTO lbl-1000
                v0 = var6_4.m.a();
            }
            if (v0 == kuzi.obf.j.b.a.BOX) {
                v1 = true;
            } else lbl-1000:
            // 2 sources

            {
                v1 = var7_5 = false;
            }
            if (var7_5) {
                v2 = new Object[1];
                v2[0] = var3_2;
                v3 = q_0.c(v2);
            } else {
                v3 = new S();
            }
            var0.setScreen(v3);
        }
    }

    private static r a(r value) {
        return value;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = CloudConfig.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int index = 0; index < classArray.length; ++index) {
                field = CloudConfig.d(classArray[index], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int parameterCount, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != parameterCount) continue;
            for (int index = 0; index < parameterCount; ++index) {
                if (classArray2[index] != classArray[index]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int parameterCount, Class[] classArray) {
        Method method = CloudConfig.c(clazz, string, clazz2, parameterCount, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int index = 0; index < classArray2.length; ++index) {
                method = CloudConfig.d(classArray2[index], string, clazz2, parameterCount, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }
}

