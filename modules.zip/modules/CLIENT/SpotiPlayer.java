// === Kuzi module: SpotiPlayer ===
// Category   : CLIENT
// Description: Shows the song currently playing on Spotify
// Payload    : a.a.a.j.b.o (verified: True)

package kuzi.modules.client;

import de.labystudio.spotifyapi.SpotifyAPI;
import de.labystudio.spotifyapi.SpotifyAPIFactory;
import de.labystudio.spotifyapi.SpotifyListener;
import de.labystudio.spotifyapi.model.MediaKey;
import de.labystudio.spotifyapi.model.Track;
import java.awt.image.BufferedImage;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.mixin.MixinExposed;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.b.v;
import kuzi.obf.h.o_0;
import kuzi.obf.j.b.a;
import kuzi.obf.j.b.q;
import kuzi.obf.l.c.c;
import kuzi.obf.m.r;
import kuzi.obf.p.L;
import kuzi.settings.BoolSetting;
import kuzi.settings.KeyBinding;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.Minecraft;
import net.minecraft.Screen;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class SpotiPlayer
extends BaseModule {
    public static SpotiPlayer m;
    public final BoolSetting n;
    public final BoolSetting o;
    public final BoolSetting p;
    public final BoolSetting q;
    public final SliderSetting r;
    public final KeyBinding previousTrackKey;
    public final KeyBinding playPauseKey;
    public final KeyBinding nextTrackKey;
    public final BoolSetting editPosition;
    public final SliderSetting width;
    public final SliderSetting scale;
    public final SliderSetting x2;
    public final SliderSetting y2;
    private final Object stateLock;
    private SpotifyAPI spotifyApi;
    private Track currentTrack;
    private int positionMs;
    private boolean playing;
    private long playStateSinceMs;
    private boolean initStarted;
    private volatile boolean pendingAlbumArtReady;
    private volatile BufferedImage pendingAlbumArt;
    private boolean hasAlbumArt;
    private int albumArtTextureId;
    private float fadeAlpha;
    private long lastFrameNanos;
    private float marqueeOffset;
    private long lastMarqueeNanos;
    private String lastTrackName;
    private static final int Q;
    private final float[] eqBarHeights;
    private final float[] eqPhases;
    private final float[] eqSpeeds;
    private long eqTickNanos;
    private final Random random;
    private static final int W;
    private static final int X;
    private static final int Y;
    private static final int Z;
    private static final int aa;
    private static final int ab;
    private boolean prevTrackKeyHeld;
    private boolean playPauseKeyHeld;
    private boolean nextTrackKeyHeld;
    private static final int af;
    private static final int ag;
    private static final int ah;
    private static final int ai;
    private static final int aj;
    private static final int ak;
    private static final float al = 11.0f;
    private static final float am = 24.0f;
    private static final int an;
    private static final int ao;
    private static final int ap;
    private static final int aq;
    private static final int ar;
    private static final int as;
    private static final int at;
    private static final int au;
    private static final int av = -1;
    private static final long bb;
    private static final String[] db;
    private static final String[] hb;
    private static final Map ib;
    private static final long[] jb;
    private static final Integer[] kb;
    private static final Map lb;
    private static final long[] mb;
    private static final Long[] nb;
    private static final Map ob;
    private static final Object[] pb;
    private static final String[] sb;

    public SpotiPlayer() {
        block1: {
            long l2 = bb ^ 0x6DA2E2A1638BL;
            long l3 = l2 ^ 0x22EA4FF8FDDAL;
            super("SpotiPlayer", "Shows the song currently playing on Spotify", Category.CLIENT);
            this.n = new BoolSetting("Show Album Art", true);
            this.o = new BoolSetting("Show Progress Bar", true);
            this.p = new BoolSetting("Show Controls", true);
            this.q = new BoolSetting("Show Equalizer", false);
            this.r = new SliderSetting("Equalizer Sensitivity", 0.5, 0.0, 1.0, 0.05);
            this.previousTrackKey = new KeyBinding("Previous Track Key", -1);
            this.playPauseKey = new KeyBinding("Play/Pause Key", -1);
            this.nextTrackKey = new KeyBinding("Next Track Key", -1);
            this.editPosition = new BoolSetting("Edit Position", false);
            this.width = new SliderSetting("Width", 280.0, 200.0, 500.0, 1.0);
            this.scale = new SliderSetting("Scale", 1.0, 0.5, 2.5, 0.05);
            this.x2 = new SliderSetting("X", 10.0, 0.0, 4000.0, 1.0);
            this.y2 = new SliderSetting("Y", 10.0, 0.0, 2000.0, 1.0);
            this.stateLock = new Object();
            this.positionMs = 0;
            this.playing = false;
            String[] stringArray = kuzi.obf.j.b.a.b();
            this.playStateSinceMs = 0L;
            this.initStarted = false;
            this.pendingAlbumArtReady = false;
            this.pendingAlbumArt = null;
            this.hasAlbumArt = false;
            this.albumArtTextureId = 0;
            this.fadeAlpha = 0.0f;
            this.lastFrameNanos = 0L;
            this.marqueeOffset = 0.0f;
            this.lastMarqueeNanos = 0L;
            this.lastTrackName = "";
            this.eqBarHeights = new float[128];
            this.eqPhases = new float[128];
            this.eqSpeeds = new float[128];
            this.eqTickNanos = 0L;
            this.random = new Random();
            Object[] objectArray = new Object[2];
            objectArray[1] = new Setting[]{this.n, this.o, this.p, this.q, this.r, this.previousTrackKey, this.playPauseKey, this.nextTrackKey, this.editPosition, this.width, this.scale, this.x2, this.y2};
            objectArray[0] = l3;
            this.l(objectArray);
            m = this;
            for (int i2 = 0; i2 < 128; ++i2) {
                this.eqBarHeights[i2] = 2.0f;
                this.eqPhases[i2] = this.random.nextFloat() * ((float)Math.PI * 2);
                this.eqSpeeds[i2] = 0.7f + this.random.nextFloat() * 0.6f;
                if (stringArray != null) continue;
            }
            if (BaseModule.b() != null) break block1;
            kuzi.obf.j.b.a.b(new String[4]);
        }
    }

    @MixinExposed
    public SliderSetting a() {
        return this.x2;
    }

    @MixinExposed
    public SliderSetting b() {
        return this.y2;
    }

    @MixinExposed
    public int a() {
        return Math.round((float)((Double)this.width.a()).intValue() * ((Double)this.scale.a()).floatValue());
    }

    @MixinExposed
    public int c() {
        long l2 = bb ^ 0x429A24641F6BL;
        long l3 = l2 ^ 0x2383C7879F5CL;
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        return Math.round((float)this.d(objectArray) * ((Double)this.scale.a()).floatValue());
    }

    private void a(Object[] objectArray) {
        block20: {
            boolean nextPressed;
            block21: {
                SpotiPlayer self;
                boolean playPausePressed;
                boolean prevPressed;
                block19: {
                    boolean wasHeld;
                    long l2;
                    block18: {
                        String[] stringArray;
                        String[] stringArray2;
                        long l3;
                        block17: {
                            block15: {
                                block16: {
                                    String[] stringArray3;
                                    block14: {
                                        block12: {
                                            block13: {
                                                l3 = (Long)objectArray[0];
                                                long l4 = l3 = bb ^ l3;
                                                long l5 = l4 ^ 0x4C5FE59A6AC2L;
                                                l2 = l4 ^ 0x3B3D54F51ED6L;
                                                Object[] objectArray2 = new Object[2];
                                                objectArray2[1] = l5;
                                                objectArray2[0] = this.previousTrackKey;
                                                prevPressed = SpotiPlayer.a(objectArray2);
                                                Object[] objectArray3 = new Object[2];
                                                objectArray3[1] = l5;
                                                objectArray3[0] = this.playPauseKey;
                                                playPausePressed = SpotiPlayer.a(objectArray3);
                                                stringArray2 = kuzi.obf.j.b.a.b();
                                                Object[] objectArray4 = new Object[2];
                                                objectArray4[1] = l5;
                                                objectArray4[0] = this.nextTrackKey;
                                                nextPressed = SpotiPlayer.a(objectArray4);
                                                wasHeld = prevPressed;
                                                if (stringArray2 == null) break block12;
                                                if (!wasHeld) break block13;
                                                wasHeld = this.prevTrackKeyHeld;
                                                stringArray3 = stringArray2;
                                                if (l3 < 0L) break block14;
                                                if (stringArray3 == null) break block12;
                                                if (!wasHeld) {
                                                    Object[] objectArray5 = new Object[2];
                                                    objectArray5[1] = MediaKey.PREV;
                                                    objectArray5[0] = l2;
                                                    this.b(objectArray5);
                                                }
                                            }
                                            wasHeld = playPausePressed;
                                        }
                                        stringArray3 = stringArray2;
                                    }
                                    if (stringArray3 == null) break block15;
                                    if (!wasHeld) break block16;
                                    wasHeld = this.playPauseKeyHeld;
                                    stringArray = stringArray2;
                                    if (l3 < 0L) break block17;
                                    if (stringArray == null) break block15;
                                    if (!wasHeld) {
                                        Object[] objectArray6 = new Object[2];
                                        objectArray6[1] = MediaKey.PLAY_PAUSE;
                                        objectArray6[0] = l2;
                                        this.b(objectArray6);
                                    }
                                }
                                wasHeld = nextPressed;
                            }
                            if (l3 <= 0L) break block18;
                            stringArray = stringArray2;
                        }
                        if (stringArray == null) break block18;
                        if (!wasHeld) break block19;
                        if (l3 <= 0L) break block20;
                        self = this;
                        if (stringArray2 == null) break block21;
                        wasHeld = self.nextTrackKeyHeld;
                    }
                    if (!wasHeld) {
                        Object[] objectArray7 = new Object[2];
                        objectArray7[1] = MediaKey.NEXT;
                        objectArray7[0] = l2;
                        this.b(objectArray7);
                    }
                }
                this.prevTrackKeyHeld = prevPressed;
                this.playPauseKeyHeld = playPausePressed;
                self = this;
            }
            self.nextTrackKeyHeld = nextPressed;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static boolean a(Object[] objectArray) {
        KeyBinding keyBinding = (KeyBinding)objectArray[0];
        long l2 = (Long)objectArray[1];
        long l3 = (l2 = bb ^ l2) ^ 0x249B943F81EL;
        Integer boundKey = (Integer)keyBinding.a();
        String[] stringArray = kuzi.obf.j.b.a.b();
        Integer keyCode = boundKey;
        if (stringArray != null) {
            if (keyCode == null) return 0 != 0;
            keyCode = boundKey;
        }
        int keyHeld = keyCode;
        String[] stringArray2 = stringArray;
        if (l2 >= 0L) {
            if (stringArray2 != null) {
                if (keyHeld <= 0) return 0 != 0;
                Object[] objectArray2 = new Object[2];
                objectArray2[1] = l3;
                objectArray2[0] = (int)boundKey;
                keyHeld = kuzi.obf.p.L.a(objectArray2) ? 1 : 0;
            }
            stringArray2 = stringArray;
        }
        if (stringArray2 == null) return keyHeld != 0;
        if (keyHeld == 0) return 0 != 0;
        return 1 != 0;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private void b(Object[] var1_1) {
        var3_2 = (Long)var1_1[0];
        var2_3 = (MediaKey)var1_1[1];
        var3_2 = SpotiPlayer.bb ^ var3_2;
        var5_4 = kuzi.obf.j.b.a.b();
        v0 = this.spotifyApi;
        if (var5_4 == null) ** GOTO lbl13
        if (v0 == null) {
            return;
        }
        try {
            block11: {
                v0 = this.spotifyApi;
lbl13:
                // 3 sources

                v0.pressMediaKey(var2_3);
                v1 /* !! */  = var2_3;
                v2 /* !! */  = MediaKey.PLAY_PAUSE;
                if (var5_4 == null) break block11;
                try {
                    block13: {
                        if (v1 /* !! */  != v2 /* !! */ ) ** break block12
                        break block13;
                        catch (Throwable v3) {
                            throw SpotiPlayer.a(v3);
                        }
                    }
                    v4 = this.stateLock;
                    v2 /* !! */  = v4;
                    v1 /* !! */  = v4;
                }
                catch (Throwable v5) {
                    throw SpotiPlayer.a(v5);
                }
            }
            var6_5 = v2 /* !! */ ;
            synchronized (v1 /* !! */ ) {
                v6 = this.playing;
                if (var5_4 != null) {
                    v6 = v6 == false;
                }
                this.playing = v6;
                this.playStateSinceMs = System.currentTimeMillis();
                // ** MonitorExit[var6_5] (shouldn't be in output)
            }
        }
        catch (Throwable var6_6) {
            // empty catch block
        }
        {
            return;
        }
    }

    @Override
    public void i() {
        block6: {
            Minecraft minecraft;
            int keyBitsHigh;
            int keyBitsMid;
            int keyBitsLow;
            block7: {
                BoolSetting editPositionSetting;
                String[] stringArray;
                block5: {
                    Object object;
                    block4: {
                        long l2;
                        long l3 = l2 = bb ^ 0x1D3D4EC665A5L;
                        long l4 = l3 ^ 0xEBFE5CFC15BL;
                        keyBitsLow = (int)(l4 >>> 32);
                        keyBitsMid = (int)(l4 << 32 >>> 48);
                        keyBitsHigh = (int)(l4 << 48 >>> 48);
                        long l5 = l3 ^ 0x553221C10CE7L;
                        stringArray = kuzi.obf.j.b.a.b();
                        object = BaseModule.a.screen;
                        if (stringArray == null) break block4;
                        if (object == null) {
                            Object[] objectArray = new Object[1];
                            objectArray[0] = l5;
                            this.a(objectArray);
                        }
                        editPositionSetting = this.editPosition;
                        if (stringArray == null) break block5;
                        object = editPositionSetting.a();
                    }
                    if (!((Boolean)object).booleanValue()) break block6;
                    editPositionSetting = this.editPosition;
                }
                editPositionSetting.a(false);
                minecraft = BaseModule.a;
                if (stringArray == null) break block7;
                if (minecraft == null) break block6;
                minecraft = BaseModule.a;
            }
            minecraft.execute(() -> SpotiPlayer.lambda$onTick$0(keyBitsLow, keyBitsMid, (short)keyBitsHigh));
        }
    }

    @Override
    public void d() {
        block3: {
            int n2;
            int n3;
            block2: {
                long l2 = bb ^ 0x5261A52A289L;
                long l3 = l2 ^ 0x9C4E00B0F55L;
                n3 = (int)(l3 >>> 32);
                n2 = (int)(l3 << 32 >>> 32);
                String[] stringArray = kuzi.obf.j.b.a.b();
                SpotiPlayer self = this;
                if (stringArray == null) break block2;
                if (self.initStarted) break block3;
                self = this;
            }
            self.initStarted = true;
            Thread thread = new Thread(() -> this.b(n3, n2), "kuzi-spotify-init");
            thread.setDaemon(true);
            thread.start();
        }
    }

    @Override
    public void e() {
        this.fadeAlpha = 0.0f;
        this.marqueeOffset = 0.0f;
    }

    private void b(int n2, int n3) {
        long l2 = ((long)n2 << 32 | (long)n3 << 32 >>> 32) ^ bb;
        try {
            this.spotifyApi = SpotifyAPIFactory.create();
            this.spotifyApi.registerListener((SpotifyListener)new q(this));
            this.spotifyApi.initialize();
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private int d(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = bb ^ l2;
        return (int)SpotiPlayer.c("y", (int)29942, (long)(0x49DE94540B8362F3L ^ l2));
    }

    private float[] a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = bb ^ l2;
        int n2 = ((Double)((Object)SpotiPlayer.f("X", (Object)SpotiPlayer.f("\u00e5", (Object)this, (long)4898667556624089499L, (long)l2), (long)4895432584623221011L, (long)l2))).intValue();
        CallSite callSite = SpotiPlayer.c("y", (int)12875, (long)(0x5704E3F4A53D678AL ^ l2));
        float f2 = (float)callSite + (float)(n2 - callSite - SpotiPlayer.c("y", (int)10015, (long)(0x298B65F81B2C72E3L ^ l2))) / 2.0f;
        return new float[]{f2 - 24.0f, f2, f2 + 24.0f};
    }

    private float a(Object[] objectArray) {
        return 70.0f;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @MixinExposed
    public static boolean a(double d2, double d3) {
        long l2 = bb ^ 0x3EE0D4844590L;
        long l3 = l2 ^ 0x674B5738E3A3L;
        SpotiPlayer spotiPlayer = m;
        String[] stringArray = kuzi.obf.j.b.a.b();
        SpotiPlayer spotiPlayer2 = spotiPlayer;
        if (stringArray != null) {
            if (spotiPlayer2 == null) return false;
            spotiPlayer2 = spotiPlayer;
        }
        boolean bl = spotiPlayer2.d();
        if (stringArray != null) {
            if (!bl) return false;
            Object[] objectArray = new Object[3];
            objectArray[2] = l3;
            objectArray[1] = d3;
            objectArray[0] = d2;
            bl = spotiPlayer.d(objectArray);
        }
        if (stringArray == null) return bl;
        if (!bl) return false;
        return true;
    }

    /*
     * Unable to fully structure code
     */
    private boolean d(Object[] var1_1) {
        block24: {
            block21: {
                block22: {
                    block23: {
                        block20: {
                            block19: {
                                block18: {
                                    block16: {
                                        block17: {
                                            block15: {
                                                block14: {
                                                    var2_2 = (Double)var1_1[0];
                                                    var4_3 = (Double)var1_1[1];
                                                    var6_4 = (Long)var1_1[2];
                                                    v0 = var6_4 = SpotiPlayer.bb ^ var6_4;
                                                    var8_5 = v0 ^ 21178217586835L;
                                                    var10_6 = v0 ^ 46839710536103L;
                                                    var12_7 = v0 ^ 94668704129856L;
                                                    var14_8 = kuzi.obf.j.b.a.b();
                                                    v1 = (Boolean)this.p.a();
                                                    if (var14_8 == null) break block14;
                                                    if (v1 && this.spotifyApi != null) break block15;
                                                    v1 = false;
                                                }
                                                return v1;
                                            }
                                            uiScale = Math.max(0.05f, ((Double)this.scale.a()).floatValue());
                                            localX = (mouseX - (double)((Double)this.x2.a()).intValue()) / (double)uiScale;
                                            localY = (mouseY - (double)((Double)this.y2.a()).intValue()) / (double)uiScale;
                                            cfr_temp_0 = localX - 0.0;
                                            v2 = cfr_temp_0 == 0.0 ? 0 : (cfr_temp_0 < 0.0 ? -1 : 1);
                                            if (var14_8 == null) break block16;
                                            if (v2 < 0) break block17;
                                            cfr_temp_1 = localY - 0.0;
                                            v2 = cfr_temp_1 == 0.0 ? 0 : (cfr_temp_1 < 0.0 ? -1 : 1);
                                            if (var14_8 == null) break block16;
                                            if (v2 < 0) break block17;
                                            cfr_temp_2 = localX - (double)((Double)this.width.a()).intValue();
                                            v2 = cfr_temp_2 == 0.0 ? 0 : (cfr_temp_2 > 0.0 ? 1 : -1);
                                            if (var14_8 == null) break block16;
                                            if (v2 > 0) break block17;
                                            v3 = new Object[1];
                                            v3[0] = var12_7;
                                            cfr_temp_3 = localY - (double)this.d(v3);
                                            v2 = cfr_temp_3 == 0.0 ? 0 : (cfr_temp_3 > 0.0 ? 1 : -1);
                                            if (var14_8 == null) break block16;
                                            if (v2 <= 0) break block18;
                                        }
                                        v2 = (double)false;
                                    }
                                    return (boolean)v2;
                                }
                                controlsY = this.a(new Object[0]);
                                cfr_temp_4 = Math.abs(localY - (double)controlsY) - 11.0;
                                v4 = cfr_temp_4 == 0.0 ? 0 : (cfr_temp_4 > 0.0 ? 1 : -1);
                                if (var14_8 == null) break block19;
                                if (v4 <= 0) break block20;
                                v4 = (double)false;
                            }
                            return (boolean)v4;
                        }
                        v5 = new Object[1];
                        v5[0] = var8_5;
                        controlCenterXs = this.a(v5);
                        mediaKeyToPress = null;
                        cfr_temp_5 = Math.abs(localX - (double)controlCenterXs[0]) - 11.0;
                        v6 = cfr_temp_5 == 0.0 ? 0 : (cfr_temp_5 < 0.0 ? -1 : 1);
                        v7 = var14_8;
                        if (var6_4 < 0L) break block21;
                        if (v7 == null) break block22;
                        if (v6 > 0) break block23;
                        mediaKeyToPress = MediaKey.PREV;
                        break block24;
                    }
                    cfr_temp_6 = Math.abs(localX - (double)controlCenterXs[1]) - 11.0;
                    v6 = cfr_temp_6 == 0.0 ? 0 : (cfr_temp_6 < 0.0 ? -1 : 1);
                }
                v7 = var14_8;
            }
            if (v7 == null) ** GOTO lbl79
            if (v6 <= 0) {
                mediaKeyToPress = MediaKey.PLAY_PAUSE;
            } else {
                cfr_temp_7 = Math.abs(localX - (double)controlCenterXs[2]) - 11.0;
                v6 = cfr_temp_7 == 0.0 ? 0 : (cfr_temp_7 < 0.0 ? -1 : 1);
lbl79:
                // 2 sources

                if (v6 <= 0) {
                    mediaKeyToPress = MediaKey.NEXT;
                }
            }
        }
        if (var6_4 > 0L) {
            if (mediaKeyToPress == null) {
                return false;
            }
            v8 = new Object[2];
            v8[1] = mediaKeyToPress;
            v8[0] = var10_6;
            this.b(v8);
        }
        return true;
    }

    private static int e(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = l2 = bb ^ l2;
        long l4 = l3 ^ 0x26622FBD742AL;
        long l5 = l3 ^ 0x7A66DF274C8AL;
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l4;
        Object[] objectArray3 = new Object[3];
        objectArray3[2] = Float.valueOf(1.6f);
        objectArray3[1] = l5;
        objectArray3[0] = (int)SpotiPlayer.f("\u00c6", (Object)objectArray2, (long)1021169058730090271L, (long)l2);
        return SpotiPlayer.c("y", (int)9301, (long)(0x4C49EA62FAC4BC59L ^ l2)) | SpotiPlayer.f("\u00c6", (Object)objectArray3, (long)1026112645530181360L, (long)l2) & SpotiPlayer.c("y", (int)32076, (long)(0x302CA280DBA7656BL ^ l2));
    }

    private static int f(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = l2 = bb ^ l2;
        long l4 = l3 ^ 0x13EF28CDE730L;
        long l5 = l3 ^ 0x4FEBD857DF90L;
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l4;
        Object[] objectArray3 = new Object[3];
        objectArray3[2] = Float.valueOf(0.72f);
        objectArray3[1] = l5;
        objectArray3[0] = (int)SpotiPlayer.f("\u00c6", (Object)objectArray2, (long)-7119665082492351483L, (long)l2);
        return SpotiPlayer.c("y", (int)29655, (long)(0x56CD7D7A185478CEL ^ l2)) | SpotiPlayer.f("\u00c6", (Object)objectArray3, (long)-7122643408221614614L, (long)l2) & SpotiPlayer.c("y", (int)32076, (long)(0x302C970DDCD7F671L ^ l2));
    }

    public void c(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        Minecraft minecraft = (Minecraft)objectArray[1];
        long l3 = (l2 = bb ^ l2) ^ 0xFE22CF8DCDAL;
        try {
            Object[] objectArray2 = new Object[2];
            objectArray2[1] = minecraft;
            objectArray2[0] = l3;
            this.e(objectArray2);
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    /*
     * Loose catch block
     */
    private void d(Object[] objectArray) {
        block13: {
            BufferedImage bufferedImage = (BufferedImage)objectArray[0];
            long l2 = (Long)objectArray[1];
            long l3 = l2 = bb ^ l2;
            long l4 = l3 ^ 0x955B34CBBDFL;
            long l5 = l3 ^ 0x5C0727E4F8E8L;
            String[] stringArray = kuzi.obf.j.b.a.b();
            try {
                block14: {
                    SpotiPlayer self;
                    int newTextureId;
                    block15: {
                        int oldTextureId;
                        block12: {
                            block16: {
                                int imageWidth = bufferedImage.getWidth();
                                int imageHeight = bufferedImage.getHeight();
                                int[] pixels = bufferedImage.getRGB(0, 0, imageWidth, imageHeight, null, 0, imageWidth);
                                newTextureId = kuzi.obf.l.c.c.a(imageWidth, l5, imageHeight, pixels, false);
                                oldTextureId = newTextureId;
                                if (stringArray == null) break block12;
                                if (oldTextureId <= 0) break block13;
                                break block16;
                                catch (Throwable throwable) {
                                    throw SpotiPlayer.a(throwable);
                                }
                            }
                            try {
                                block17: {
                                    self = this;
                                    if (stringArray == null) break block14;
                                    break block17;
                                    catch (Throwable throwable) {
                                        throw SpotiPlayer.a(throwable);
                                    }
                                }
                                oldTextureId = self.albumArtTextureId;
                            }
                            catch (Throwable throwable) {
                                throw SpotiPlayer.a(throwable);
                            }
                        }
                        try {
                            if (l2 > 0L) {
                                if (oldTextureId <= 0) break block15;
                                oldTextureId = this.albumArtTextureId;
                            }
                            kuzi.obf.l.c.c.c(oldTextureId, l4);
                        }
                        catch (Throwable throwable) {
                            throw SpotiPlayer.a(throwable);
                        }
                    }
                    this.albumArtTextureId = newTextureId;
                    self = this;
                }
                self.hasAlbumArt = true;
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private void e(Object[] var1_1) {
        block129: {
            block130: {
                block127: {
                    block128: {
                        var3_2 = (Long)var1_1[0];
                        var2_3 = (Minecraft)var1_1[1];
                        v0 = var3_2 = SpotiPlayer.bb ^ var3_2;
                        var5_4 = v0 ^ 108470711810915L;
                        var7_5 = v0 ^ 9936453039606L;
                        var9_6 = v0 ^ 110184037013166L;
                        var11_7 = v0 ^ 50303184349154L;
                        var13_8 = v0 ^ 95845801923301L;
                        var15_9 = v0 ^ 66154482641458L;
                        var17_10 = v0 ^ 76728730388833L;
                        var19_11 = v0 ^ 27814342603176L;
                        var21_12 = v0 ^ 71722461944993L;
                        var23_13 = v0 ^ 85958698564630L;
                        var25_14 = v0 ^ 99767738232449L;
                        var27_15 = v0 ^ 101254900183675L;
                        var29_16 = v0 ^ 116546173581740L;
                        var31_17 = v0 ^ 46303135726718L;
                        var33_18 = v0 ^ 81212304551940L;
                        var35_19 = v0 ^ 107737807145995L;
                        var37_20 = v0 ^ 34711095504740L;
                        var39_21 = v0 ^ 72403053177685L;
                        v1 = v0 ^ 115262391661593L;
                        var41_22 = (int)(v1 >>> 48);
                        var42_23 = (int)(v1 << 16 >>> 48);
                        var43_24 = (int)(v1 << 32 >>> 32);
                        v2 = v0 ^ 77808193525635L;
                        var44_25 = (int)(v2 >>> 48);
                        var45_26 = (int)(v2 << 16 >>> 32);
                        var46_27 = (int)(v2 << 48 >>> 48);
                        var47_28 = v0 ^ 80262067085830L;
                        var49_29 = v0 ^ 51715273638463L;
                        v3 = v0 ^ 107860775448447L;
                        var51_30 = (int)(v3 >>> 32);
                        var52_31 = (int)(v3 << 32 >>> 40);
                        var53_32 = (int)(v3 << 56 >>> 56);
                        var54_33 = v0 ^ 60922319433376L;
                        var56_34 = v0 ^ 9563409811584L;
                        v4 = v0 ^ 97115519802268L;
                        var58_35 = (int)(v4 >>> 32);
                        var59_36 = (int)(v4 << 32 >>> 48);
                        var60_37 = (int)(v4 << 48 >>> 48);
                        var61_38 = v0 ^ 136085011427411L;
                        var63_39 = v0 ^ 80524172314701L;
                        var65_40 = v0 ^ 123455465248026L;
                        var71_41 = kuzi.obf.j.b.a.b();
                        if (!this.d() || var2_3.player == null) {
                            return;
                        }
                        v5 = this;
                        v6 = var71_41;
                        if (var3_2 < 0L) break block127;
                        if (v6 == null) break block128;
                        if (!v5.H) break block129;
                        v5 = this;
                    }
                    v6 = var71_41;
                }
                if (v6 == null) break block130;
                if (v5.pendingAlbumArt == null) break block129;
                v7 = new Object[2];
                v7[1] = var49_29;
                v7[0] = this.pendingAlbumArt;
                this.d(v7);
                this.pendingAlbumArtReady = false;
                v5 = this;
            }
            v5.pendingAlbumArt = null;
        }
        var72_42 = System.nanoTime();
        var74_43 = this.lastFrameNanos == 0L ? 0.016f : Math.min(0.1f, (float)(var72_42 - this.lastFrameNanos) / 1.0E9f);
        this.lastFrameNanos = var72_42;
        this.fadeAlpha += (1.0f - this.fadeAlpha) * (1.0f - (float)Math.exp(-12.0f * var74_43));
        var75_44 = this.fadeAlpha;
        if (var75_44 < 0.01f) {
            return;
        }
        var83_45 = this.stateLock;
        synchronized (this.stateLock) {
            block118: {
                block135: {
                    block134: {
                        block132: {
                            block133: {
                                block100: {
                                    block102: {
                                        block101: {
                                            v8 = this.currentTrack;
                                            if (var71_41 != null) {
                                                try {
                                                    if (v8 == null) break block100;
                                                    v8 = this.currentTrack;
                                                }
                                                catch (r v9) {
                                                    throw SpotiPlayer.a(v9);
                                                }
                                            }
                                            var76_47 = v8.getName();
                                            var77_48 = this.currentTrack.getArtist();
                                            var78_49 = this.currentTrack.getLength() / SpotiPlayer.c("y", (int)5627, (long)(4510415056378983625L ^ var3_2));
                                            var79_50 = this.positionMs / SpotiPlayer.c("y", (int)1471, (long)(6565632560443843733L ^ var3_2));
                                            var82_51 = this.playing;
                                            try {
                                                v10 = var82_51 != 0 ? System.currentTimeMillis() - this.playStateSinceMs : 0L;
                                            }
                                            catch (r v11) {
                                                throw SpotiPlayer.a(v11);
                                            }
                                            var84_52 = v10;
                                            var80_54 = (long)this.positionMs + var84_52;
                                            v12 = var82_51;
                                            if (var71_41 == null) break block101;
                                            try {
                                                block131: {
                                                    if (v12 == 0) break block102;
                                                    break block131;
                                                    catch (r v13) {
                                                        throw SpotiPlayer.a(v13);
                                                    }
                                                }
                                                v12 = Math.min(var79_50 + (int)(var84_52 / SpotiPlayer.d("i", (int)14095, (long)(6099098391666480710L ^ var3_2))), var78_49);
                                            }
                                            catch (r v14) {
                                                throw SpotiPlayer.a(v14);
                                            }
                                        }
                                        var79_50 = v12;
                                    }
                                    v15 = var71_41;
                                    if (var3_2 <= 0L) break block132;
                                    if (v15 != null) break block133;
                                }
                                var76_47 = SpotiPlayer.b("w", (int)1045, (long)(3054130166123584087L ^ var3_2));
                                var77_48 = SpotiPlayer.b("w", (int)16554, (long)(4090552419310771942L ^ var3_2));
                                var78_49 = 0;
                                var79_50 = 0;
                                var80_54 = 0L;
                                var82_51 = 0;
                            }
                            v15 = var83_45;
                        }
                        // ** MonitorExit[v15] (shouldn't be in output)
                        v16 = var76_47;
                        v17 = var71_41;
                        if (var3_2 <= 0L) break block134;
                        if (v17 != null) {
                            if (v16 == null) {
                                var76_47 = "";
                            }
                            v16 = var77_48;
                        }
                        if (var3_2 <= 0L) break block135;
                        v17 = var71_41;
                    }
                    if (v17 != null) {
                        if (v16 == null) {
                            var77_48 = "";
                        }
                        v16 = var76_47;
                    }
                }
                v18 = v16.equals(this.lastTrackName);
                if (var71_41 != null) {
                    if (v18 == 0) {
                        this.lastTrackName = var76_47;
                        this.marqueeOffset = 0.0f;
                    }
                    v18 = ((Double)this.width.a()).intValue();
                }
                var83_46 = v18;
                v19 = new Object[1];
                v19[0] = var27_15;
                var84_53 = this.d(v19);
                var85_57 = ((Double)this.x2.a()).intValue();
                var86_56 = ((Double)this.y2.a()).intValue();
                var87_58 = SpotiPlayer.c("y", (int)3078, (long)(6713400885719624988L ^ var3_2));
                var88_59 = SpotiPlayer.c("y", (int)16793, (long)(6075385045149130989L ^ var3_2));
                var89_60 = ((Double)this.scale.a()).floatValue();
                kuzi.obf.l.c.c.f(var15_9);
                kuzi.obf.l.c.c.c(var85_57, var65_40, var86_56);
                kuzi.obf.l.c.c.a(var89_60, var33_18);
                try {
                    block148: {
                        block126: {
                            block125: {
                                block123: {
                                    block124: {
                                        block146: {
                                            block122: {
                                                block120: {
                                                    block121: {
                                                        block119: {
                                                            block117: {
                                                                block115: {
                                                                    block116: {
                                                                        block113: {
                                                                            block114: {
                                                                                block143: {
                                                                                    block112: {
                                                                                        block111: {
                                                                                            block106: {
                                                                                                block107: {
                                                                                                    block108: {
                                                                                                        block109: {
                                                                                                            block110: {
                                                                                                                block104: {
                                                                                                                    block105: {
                                                                                                                        block103: {
                                                                                                                            block140: {
                                                                                                                                block139: {
                                                                                                                                    block138: {
                                                                                                                                        block137: {
                                                                                                                                            block136: {
                                                                                                                                                v20 = new Object[1];
                                                                                                                                                v20[0] = var31_17;
                                                                                                                                                v21 = new Object[3];
                                                                                                                                                v21[2] = Float.valueOf(var75_44);
                                                                                                                                                v21[1] = var5_4;
                                                                                                                                                v21[0] = SpotiPlayer.e(v20);
                                                                                                                                                v22 = new Object[1];
                                                                                                                                                v22[0] = var37_20;
                                                                                                                                                v23 = new Object[3];
                                                                                                                                                v23[2] = Float.valueOf(var75_44);
                                                                                                                                                v23[1] = var5_4;
                                                                                                                                                v23[0] = SpotiPlayer.f(v22);
                                                                                                                                                kuzi.obf.l.c.c.a(var51_30, 0.0f, var52_31, (byte)var53_32, 0.0f, (float)var83_46, (float)var84_53, 18.0f, SpotiPlayer.c(v21), SpotiPlayer.c(v23));
                                                                                                                                                v24 = new Object[3];
                                                                                                                                                v24[2] = Float.valueOf(var75_44);
                                                                                                                                                v24[1] = var5_4;
                                                                                                                                                v24[0] = (int)SpotiPlayer.c("y", (int)3892, (long)(202534931038203431L ^ var3_2));
                                                                                                                                                kuzi.obf.l.c.c.a(0.0f, (short)var41_22, 0.0f, var83_46, (char)var42_23, var43_24, (float)var84_53, 18.0f, 1.0f, SpotiPlayer.c(v24));
                                                                                                                                                v25 = new Object[3];
                                                                                                                                                v25[2] = Float.valueOf(var75_44);
                                                                                                                                                v25[1] = var5_4;
                                                                                                                                                v25[0] = (int)SpotiPlayer.c("y", (int)23946, (long)(2085775401828957439L ^ var3_2));
                                                                                                                                                kuzi.obf.l.c.c.a(18.0f, 1.0f, (float)(var83_46 - SpotiPlayer.c("y", (int)6614, (long)(7158539129510230241L ^ var3_2))), 1.0f, 0.0f, SpotiPlayer.c(v25), var7_5);
                                                                                                                                                var90_61 = var87_58;
                                                                                                                                                var91_62 = var87_58;
                                                                                                                                                v26 = new Object[3];
                                                                                                                                                v26[2] = Float.valueOf(var75_44);
                                                                                                                                                v26[1] = var5_4;
                                                                                                                                                v26[0] = (int)SpotiPlayer.c("y", (int)31024, (long)(1460555329864538140L ^ var3_2));
                                                                                                                                                kuzi.obf.l.c.c.a((float)var90_61, (float)var91_62, (float)var88_59, (float)var88_59, 12.0f, SpotiPlayer.c(v26), var7_5);
                                                                                                                                                v27 = this.hasAlbumArt;
                                                                                                                                                if (var71_41 == null) break block103;
                                                                                                                                                if (v27 == false) ** GOTO lbl263
                                                                                                                                                break block136;
                                                                                                                                                catch (r v28) {
                                                                                                                                                    throw SpotiPlayer.a(v28);
                                                                                                                                                }
                                                                                                                                            }
                                                                                                                                            v27 = this.albumArtTextureId;
                                                                                                                                            if (var71_41 == null) break block103;
                                                                                                                                            break block137;
                                                                                                                                            catch (r v29) {
                                                                                                                                                throw SpotiPlayer.a(v29);
                                                                                                                                            }
                                                                                                                                        }
                                                                                                                                        if (var3_2 < 0L) break block103;
                                                                                                                                        if (v27 <= 0) ** GOTO lbl263
                                                                                                                                        break block138;
                                                                                                                                        catch (r v30) {
                                                                                                                                            throw SpotiPlayer.a(v30);
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                    v27 = (int)((Boolean)this.n.a()).booleanValue();
                                                                                                                                    if (var71_41 == null) break block103;
                                                                                                                                    break block139;
                                                                                                                                    catch (r v31) {
                                                                                                                                        throw SpotiPlayer.a(v31);
                                                                                                                                    }
                                                                                                                                }
                                                                                                                                if (var3_2 <= 0L) break block103;
                                                                                                                                if (v27 == 0) ** GOTO lbl263
                                                                                                                                break block140;
                                                                                                                                catch (r v32) {
                                                                                                                                    throw SpotiPlayer.a(v32);
                                                                                                                                }
                                                                                                                            }
                                                                                                                            try {
                                                                                                                                block141: {
                                                                                                                                    kuzi.obf.l.c.c.a(var56_34, this.albumArtTextureId, (float)var90_61, (float)var91_62, (float)var88_59, (float)var88_59, 12.0f, var75_44);
                                                                                                                                    v33 = var90_61;
                                                                                                                                    if (var3_2 <= 0L) break block104;
                                                                                                                                    v34 = new Object[3];
                                                                                                                                    v34[2] = Float.valueOf(var75_44);
                                                                                                                                    v34[1] = var5_4;
                                                                                                                                    v34[0] = (int)SpotiPlayer.c("y", (int)10411, (long)(2528342919314590130L ^ var3_2));
                                                                                                                                    kuzi.obf.l.c.c.a((float)v33, (short)var41_22, (float)var91_62, (float)var88_59, (char)var42_23, var43_24, (float)var88_59, 12.0f, 1.0f, SpotiPlayer.c(v34));
                                                                                                                                    if (var71_41 != null) break block105;
                                                                                                                                    break block141;
                                                                                                                                    catch (r v35) {
                                                                                                                                        throw SpotiPlayer.a(v35);
                                                                                                                                    }
                                                                                                                                }
                                                                                                                                v27 = var90_61;
                                                                                                                            }
                                                                                                                            catch (r v36) {
                                                                                                                                throw SpotiPlayer.a(v36);
                                                                                                                            }
                                                                                                                        }
                                                                                                                        var92_63 = (float)v27 + (float)var88_59 / 2.0f;
                                                                                                                        var93_65 = (float)var91_62 + (float)var88_59 / 2.0f;
                                                                                                                        v37 = new Object[3];
                                                                                                                        v37[2] = Float.valueOf(var75_44);
                                                                                                                        v37[1] = var5_4;
                                                                                                                        v37[0] = (int)SpotiPlayer.c("y", (int)11402, (long)(7040783224042835373L ^ var3_2));
                                                                                                                        kuzi.obf.l.c.c.b(var92_63 - 7.0f, var93_65 - 10.0f, var92_63 - 7.0f, var93_65 + 10.0f, var92_63 + 10.0f, var93_65, SpotiPlayer.c(v37), var29_16);
                                                                                                                    }
                                                                                                                    v33 = var90_61 + var88_59 + SpotiPlayer.c("y", (int)24334, (long)(7377496508544106037L ^ var3_2));
                                                                                                                }
                                                                                                                var92_64 = v33;
                                                                                                                var93_66 = var83_46 - var87_58 - var92_64;
                                                                                                                v38 = new Object[3];
                                                                                                                v38[2] = Float.valueOf(var75_44);
                                                                                                                v38[1] = var5_4;
                                                                                                                v38[0] = (int)SpotiPlayer.c("y", (int)32007, (long)(6606836279782513704L ^ var3_2));
                                                                                                                v39 = new Object[5];
                                                                                                                v39[4] = SpotiPlayer.c(v38);
                                                                                                                v39[3] = Float.valueOf(7.0f);
                                                                                                                v39[2] = var17_10;
                                                                                                                v39[1] = Float.valueOf((float)(var87_58 + 4));
                                                                                                                v39[0] = Float.valueOf(var83_46 - var87_58 - SpotiPlayer.c("y", (int)8375, (long)(8427202326888825289L ^ var3_2)));
                                                                                                                SpotiPlayer.q(v39);
                                                                                                                v40 = new Object[6];
                                                                                                                v40[5] = var80_54;
                                                                                                                v40[4] = (boolean)var82_51;
                                                                                                                v40[3] = Float.valueOf(var75_44);
                                                                                                                v40[2] = Float.valueOf((float)(var87_58 + SpotiPlayer.c("y", (int)24670, (long)(1697923477130576246L ^ var3_2))));
                                                                                                                v40[1] = var35_19;
                                                                                                                v40[0] = Float.valueOf(var83_46 - var87_58 - SpotiPlayer.c("y", (int)13611, (long)(945266231775613978L ^ var3_2)));
                                                                                                                this.p(v40);
                                                                                                                var94_67 = (float)(var87_58 + SpotiPlayer.c("y", (int)20988, (long)(4685676670252691700L ^ var3_2)));
                                                                                                                var95_68 = (float)(var87_58 + SpotiPlayer.c("y", (int)22314, (long)(163222286632728068L ^ var3_2)));
                                                                                                                var96_69 = Math.max((int)SpotiPlayer.c("y", (int)4788, (long)(8318384510403113877L ^ var3_2)), var93_66 - SpotiPlayer.c("y", (int)16183, (long)(6760199631536545355L ^ var3_2)));
                                                                                                                try {
                                                                                                                    v41 = var76_47.isEmpty();
                                                                                                                    if (var3_2 < 0L || var71_41 == null) break block106;
                                                                                                                    if (v41) break block107;
                                                                                                                }
                                                                                                                catch (r v42) {
                                                                                                                    throw SpotiPlayer.a(v42);
                                                                                                                }
                                                                                                                var97_70 = kuzi.obf.l.c.c.a((String)var76_47, 14.0f, var23_13);
                                                                                                                try {
                                                                                                                    if (var71_41 == null) break block108;
                                                                                                                    if (var97_70 > (float)var96_69) {
                                                                                                                    }
                                                                                                                    ** GOTO lbl368
                                                                                                                }
                                                                                                                catch (r v43) {
                                                                                                                    throw SpotiPlayer.a(v43);
                                                                                                                }
                                                                                                                var98_73 = System.nanoTime();
                                                                                                                try {
                                                                                                                    v44 = this.lastMarqueeNanos == 0L ? 0.0f : Math.min(0.1f, (float)(var98_73 - this.lastMarqueeNanos) / 1.0E9f);
                                                                                                                }
                                                                                                                catch (r v45) {
                                                                                                                    throw SpotiPlayer.a(v45);
                                                                                                                }
                                                                                                                var100_77 = v44;
                                                                                                                this.lastMarqueeNanos = var98_73;
                                                                                                                this.marqueeOffset += 28.0f * var100_77;
                                                                                                                cfr_temp_0 = this.marqueeOffset - (var97_70 + 24.0f);
                                                                                                                v46 /* !! */  = cfr_temp_0 == 0.0f ? 0 : (cfr_temp_0 > 0.0f ? 1 : -1);
                                                                                                                if (var3_2 <= 0L || var71_41 == null) break block109;
                                                                                                                try {
                                                                                                                    block142: {
                                                                                                                        if (v46 /* !! */  <= 0) break block110;
                                                                                                                        break block142;
                                                                                                                        catch (r v47) {
                                                                                                                            throw SpotiPlayer.a(v47);
                                                                                                                        }
                                                                                                                    }
                                                                                                                    this.marqueeOffset = 0.0f;
                                                                                                                }
                                                                                                                catch (r v48) {
                                                                                                                    throw SpotiPlayer.a(v48);
                                                                                                                }
                                                                                                            }
                                                                                                            v46 /* !! */  = (float)var92_64;
                                                                                                        }
                                                                                                        try {
                                                                                                            kuzi.obf.l.c.c.a(v46 /* !! */ , var94_67 - 9.0f, var9_6, (float)var96_69, 18.0f);
                                                                                                            v49 = new Object[3];
                                                                                                            v49[2] = Float.valueOf(var75_44);
                                                                                                            v49[1] = var5_4;
                                                                                                            v49[0] = (int)SpotiPlayer.c("y", (int)16539, (long)(6099906831228969391L ^ var3_2));
                                                                                                            kuzi.obf.l.c.c.b((String)var76_47, var47_28, (float)var92_64 - this.marqueeOffset, var94_67, 14.0f, SpotiPlayer.c(v49));
                                                                                                            v50 = new Object[3];
                                                                                                            v50[2] = Float.valueOf(var75_44);
                                                                                                            v50[1] = var5_4;
                                                                                                            v50[0] = (int)SpotiPlayer.c("y", (int)29270, (long)(1759177740247995246L ^ var3_2));
                                                                                                            kuzi.obf.l.c.c.b((String)var76_47, var47_28, (float)var92_64 - this.marqueeOffset + var97_70 + 24.0f, var94_67, 14.0f, SpotiPlayer.c(v50));
                                                                                                            kuzi.obf.l.c.c.e(var63_39);
                                                                                                            if (var3_2 < 0L || var71_41 != null) break block107;
lbl368:
                                                                                                            // 2 sources

                                                                                                            this.marqueeOffset = 0.0f;
                                                                                                        }
                                                                                                        catch (r v51) {
                                                                                                            throw SpotiPlayer.a(v51);
                                                                                                        }
                                                                                                    }
                                                                                                    v52 = new Object[3];
                                                                                                    v52[2] = Float.valueOf(var75_44);
                                                                                                    v52[1] = var5_4;
                                                                                                    v52[0] = (int)SpotiPlayer.c("y", (int)29270, (long)(1759177740247995246L ^ var3_2));
                                                                                                    kuzi.obf.l.c.c.b((String)var76_47, var47_28, (float)var92_64, var94_67, 14.0f, SpotiPlayer.c(v52));
                                                                                                }
                                                                                                try {
                                                                                                    v53 = var77_48;
                                                                                                    if (var71_41 == null) break block111;
                                                                                                    v41 = v53.isEmpty();
                                                                                                }
                                                                                                catch (r v54) {
                                                                                                    throw SpotiPlayer.a(v54);
                                                                                                }
                                                                                            }
                                                                                            try {
                                                                                                if (v41) break block112;
                                                                                                v55 = new Object[4];
                                                                                                v55[3] = Float.valueOf(10.5f);
                                                                                                v55[2] = var39_21;
                                                                                                v55[1] = Float.valueOf(var93_66);
                                                                                                v55[0] = var77_48;
                                                                                                v53 = SpotiPlayer.a(v55);
                                                                                            }
                                                                                            catch (r v56) {
                                                                                                throw SpotiPlayer.a(v56);
                                                                                            }
                                                                                        }
                                                                                        var97_71 = v53;
                                                                                        v57 = new Object[3];
                                                                                        v57[2] = Float.valueOf(var75_44);
                                                                                        v57[1] = var5_4;
                                                                                        v57[0] = (int)SpotiPlayer.c("y", (int)14101, (long)(7243665298722706962L ^ var3_2));
                                                                                        kuzi.obf.l.c.c.b((String)var97_71, var47_28, (float)var92_64, var95_68, 10.5f, SpotiPlayer.c(v57));
                                                                                    }
                                                                                    var97_72 = this.a(new Object[0]);
                                                                                    try {
                                                                                        v58 /* !! */  = (Boolean)this.p.a();
                                                                                        v59 = var71_41;
                                                                                        if (var3_2 <= 0L) ** GOTO lbl522
                                                                                        if (v59 == null) break block113;
                                                                                        if (v58 /* !! */ ) {
                                                                                        }
                                                                                        ** GOTO lbl515
                                                                                    }
                                                                                    catch (r v60) {
                                                                                        throw SpotiPlayer.a(v60);
                                                                                    }
                                                                                    v61 = new Object[1];
                                                                                    v61[0] = var19_11;
                                                                                    var98_74 = this.a(v61);
                                                                                    v62 = var98_74[0];
                                                                                    v63 = var97_72;
                                                                                    v64 = 6.5f;
                                                                                    v65 = new Object[3];
                                                                                    v65[2] = Float.valueOf(var75_44);
                                                                                    v65[1] = var5_4;
                                                                                    v65[0] = (int)SpotiPlayer.c("y", (int)16520, (long)(3868306318674141622L ^ var3_2));
                                                                                    v66 = SpotiPlayer.c(v65);
                                                                                    if (var71_41 == null) break block143;
                                                                                    var67_80 = v66;
                                                                                    var68_81 = v64;
                                                                                    var69_82 = v63;
                                                                                    var70_83 = v62;
                                                                                    v67 = new Object[7];
                                                                                    v67[6] = var67_80;
                                                                                    v67[5] = Float.valueOf(var68_81);
                                                                                    v67[4] = Float.valueOf(var69_82);
                                                                                    v67[3] = var46_27;
                                                                                    v67[2] = Float.valueOf(var70_83);
                                                                                    v67[1] = var45_26;
                                                                                    v67[0] = (int)((short)var44_25);
                                                                                    SpotiPlayer.n(v67);
                                                                                    if (var3_2 < 0L) ** GOTO lbl465
                                                                                    if (var82_51 == 0) ** GOTO lbl471
                                                                                    try {
                                                                                        block144: {
                                                                                            v68 = new Object[3];
                                                                                            v68[2] = Float.valueOf(var75_44);
                                                                                            v68[1] = var5_4;
                                                                                            v68[0] = (int)SpotiPlayer.c("y", (int)31718, (long)(1998570485784386205L ^ var3_2));
                                                                                            v69 = new Object[5];
                                                                                            v69[4] = var54_33;
                                                                                            v69[3] = SpotiPlayer.c(v68);
                                                                                            v69[2] = Float.valueOf(7.5f);
                                                                                            v69[1] = Float.valueOf(var97_72);
                                                                                            v69[0] = Float.valueOf(var98_74[1]);
                                                                                            SpotiPlayer.m(v69);
lbl465:
                                                                                            // 2 sources

                                                                                            v70 = var71_41;
                                                                                            if (var3_2 <= 0L) ** GOTO lbl513
                                                                                            if (v70 != null) break block114;
                                                                                            break block144;
                                                                                            catch (r v71) {
                                                                                                throw SpotiPlayer.a(v71);
                                                                                            }
                                                                                        }
                                                                                        v62 = var98_74[1];
                                                                                        v63 = var97_72;
                                                                                        v64 = 7.5f;
                                                                                        v72 = new Object[3];
                                                                                        v72[2] = Float.valueOf(var75_44);
                                                                                        v72[1] = var5_4;
                                                                                        v72[0] = (int)SpotiPlayer.c("y", (int)31718, (long)(1998570485784386205L ^ var3_2));
                                                                                        v66 = SpotiPlayer.c(v72);
                                                                                    }
                                                                                    catch (r v73) {
                                                                                        throw SpotiPlayer.a(v73);
                                                                                    }
                                                                                }
                                                                                var67_80 = v66;
                                                                                var68_81 = v64;
                                                                                var69_82 = v63;
                                                                                v74 = new Object[5];
                                                                                v74[4] = var67_80;
                                                                                v74[3] = Float.valueOf(var68_81);
                                                                                v74[2] = Float.valueOf(var69_82);
                                                                                v74[1] = var13_8;
                                                                                v74[0] = Float.valueOf(v62);
                                                                                SpotiPlayer.f(v74);
                                                                            }
                                                                            try {
                                                                                v75 = new Object[3];
                                                                                v75[2] = Float.valueOf(var75_44);
                                                                                v75[1] = var5_4;
                                                                                v75[0] = (int)SpotiPlayer.c("y", (int)31718, (long)(1998570485784386205L ^ var3_2));
                                                                                v76 = new Object[5];
                                                                                v76[4] = SpotiPlayer.c(v75);
                                                                                v76[3] = Float.valueOf(6.5f);
                                                                                v76[2] = Float.valueOf(var97_72);
                                                                                v76[1] = Float.valueOf(var98_74[2]);
                                                                                v76[0] = var11_7;
                                                                                SpotiPlayer.o(v76);
                                                                                v70 = var71_41;
lbl513:
                                                                                // 2 sources

                                                                                if (var3_2 < 0L) break block115;
                                                                                if (v70 != null) break block116;
lbl515:
                                                                                // 2 sources

                                                                                v58 /* !! */  = (Boolean)this.q.a();
                                                                            }
                                                                            catch (r v77) {
                                                                                throw SpotiPlayer.a(v77);
                                                                            }
                                                                        }
                                                                        try {
                                                                            v59 = var71_41;
lbl522:
                                                                            // 2 sources

                                                                            if (var3_2 >= 0L) {
                                                                                if (v59 == null) break block117;
                                                                                if (!v58 /* !! */ ) break block116;
                                                                            }
                                                                            ** GOTO lbl574
                                                                        }
                                                                        catch (r v78) {
                                                                            throw SpotiPlayer.a(v78);
                                                                        }
                                                                        var98_75 = SpotiPlayer.c("y", (int)7446, (long)(4932923659450285094L ^ var3_2));
                                                                        var99_84 = (int)var97_72 + var98_75 / 2;
                                                                        var100_78 = 2;
                                                                        var101_86 = 3;
                                                                        var102_88 = var101_86 + var100_78;
                                                                        var103_90 = Math.max(1, Math.min((int)SpotiPlayer.c("y", (int)8145, (long)(6438660761835011803L ^ var3_2)), var93_66 / var102_88));
                                                                        var104_92 = var103_90 * var102_88 - var100_78;
                                                                        var105_94 = var92_64 + (var93_66 - var104_92) / 2;
                                                                        v79 = new Object[5];
                                                                        v79[4] = var61_38;
                                                                        v79[3] = (int)var98_75;
                                                                        v79[2] = var80_54;
                                                                        v79[1] = var103_90;
                                                                        v79[0] = (boolean)var82_51;
                                                                        this.r(v79);
                                                                        var106_96 = 0;
                                                                        block68: while (var106_96 < var103_90) {
                                                                            var107_97 = Math.max(2, Math.min((int)var98_75, (int)this.eqBarHeights[var106_96]));
                                                                            try {
                                                                                v80 = new Object[3];
                                                                                v80[2] = Float.valueOf(var75_44);
                                                                                v80[1] = var5_4;
                                                                                v80[0] = (int)SpotiPlayer.c("y", (int)27643, (long)(2607455072423480025L ^ var3_2));
                                                                                kuzi.obf.l.c.c.a((float)(var105_94 + var106_96 * var102_88), (float)(var99_84 - var107_97), (float)var101_86, (float)var107_97, 1.0f, SpotiPlayer.c(v80), var7_5);
                                                                                ++var106_96;
                                                                                do {
                                                                                    v81 = var71_41;
                                                                                    if (var3_2 > 0L) {
                                                                                        if (v81 == null) break block118;
                                                                                        v81 = var71_41;
                                                                                    }
                                                                                    if (v81 != null) continue block68;
                                                                                } while (var3_2 < 0L);
                                                                                break;
                                                                            }
                                                                            catch (r v82) {
                                                                                throw SpotiPlayer.a(v82);
                                                                            }
                                                                        }
                                                                    }
                                                                    v70 = this.o.a();
                                                                }
                                                                v58 /* !! */  = (Boolean)v70;
                                                            }
                                                            try {
                                                                v59 = var71_41;
lbl574:
                                                                // 2 sources

                                                                if (v59 == null) break block119;
                                                                if (!v58 /* !! */ ) break block118;
                                                            }
                                                            catch (r v83) {
                                                                throw SpotiPlayer.a(v83);
                                                            }
                                                            v58 /* !! */  = var87_58;
                                                        }
                                                        var98_76 = (float)v58 /* !! */ ;
                                                        var99_85 = (float)var83_46 - 2.0f * (float)var87_58;
                                                        var100_79 = (float)(var87_58 + var88_59 + SpotiPlayer.c("y", (int)29644, (long)(4608533625059578604L ^ var3_2)));
                                                        v84 = var98_76;
                                                        v85 = var100_79;
                                                        v86 = var99_85;
                                                        if (var3_2 < 0L) break block120;
                                                        v87 = 3.0f;
                                                        if (var71_41 == null) break block121;
                                                        try {
                                                            block145: {
                                                                v88 = new Object[3];
                                                                v88[2] = Float.valueOf(var75_44);
                                                                v88[1] = var5_4;
                                                                v88[0] = (int)SpotiPlayer.c("y", (int)5680, (long)(2107696644964513589L ^ var3_2));
                                                                kuzi.obf.l.c.c.a(v84, v85, v86, v87, 1.5f, SpotiPlayer.c(v88), var7_5);
                                                                if (var78_49 <= 0) break block122;
                                                                break block145;
                                                                catch (r v89) {
                                                                    throw SpotiPlayer.a(v89);
                                                                }
                                                            }
                                                            v84 = 0.0f;
                                                            v85 = 1.0f;
                                                            v90 = var79_50;
                                                            v87 = var78_49;
                                                        }
                                                        catch (r v91) {
                                                            throw SpotiPlayer.a(v91);
                                                        }
                                                    }
                                                    v86 = v90 / v87;
                                                }
                                                v92 = Math.max(v84, Math.min(v85, v86));
                                                break block146;
                                            }
                                            v92 = 0.0f;
                                        }
                                        var101_87 = v92;
                                        cfr_temp_1 = var101_87 - 0.0f;
                                        v93 = cfr_temp_1 == 0.0f ? 0 : (cfr_temp_1 > 0.0f ? 1 : -1);
                                        if (var71_41 == null) break block123;
                                        try {
                                            block147: {
                                                if (v93 <= 0) break block124;
                                                break block147;
                                                catch (r v94) {
                                                    throw SpotiPlayer.a(v94);
                                                }
                                            }
                                            v95 = new Object[3];
                                            v95[2] = Float.valueOf(var75_44);
                                            v95[1] = var5_4;
                                            v95[0] = -1;
                                            kuzi.obf.l.c.c.a(var98_76, var100_79, Math.max(3.0f, var99_85 * var101_87), 3.0f, 1.5f, SpotiPlayer.c(v95), var7_5);
                                        }
                                        catch (r v96) {
                                            throw SpotiPlayer.a(v96);
                                        }
                                    }
                                    v97 = new Object[3];
                                    v97[2] = Float.valueOf(var75_44);
                                    v97[1] = var5_4;
                                    v97[0] = -1;
                                    kuzi.obf.l.c.c.a(var98_76 + var99_85 * var101_87, var100_79 + 1.5f, 4.5f, SpotiPlayer.c(v97), var25_14);
                                    v93 = var79_50;
                                }
                                v98 = new Object[2];
                                v98[1] = (int)v93;
                                v98[0] = var21_12;
                                var102_89 = SpotiPlayer.c(v98);
                                try {
                                    v99 = var78_49;
                                    if (var71_41 == null) break block125;
                                    if (v99 <= 0) break block126;
                                }
                                catch (r v100) {
                                    throw SpotiPlayer.a(v100);
                                }
                                v99 = var78_49;
                            }
                            v101 = new Object[2];
                            v101[1] = v99;
                            v101[0] = var21_12;
                            v102 = SpotiPlayer.c(v101);
                            break block148;
                        }
                        v102 = SpotiPlayer.b("w", (int)6181, (long)(44268538174916202L ^ var3_2));
                    }
                    var103_91 = v102;
                    var104_93 = var100_79 + 3.0f + 11.0f;
                    v103 = new Object[3];
                    v103[2] = Float.valueOf(var75_44);
                    v103[1] = var5_4;
                    v103[0] = (int)SpotiPlayer.c("y", (int)16230, (long)(173628057198321268L ^ var3_2));
                    kuzi.obf.l.c.c.b(var102_89, var47_28, var98_76, var104_93, 9.5f, SpotiPlayer.c(v103));
                    var105_95 = kuzi.obf.l.c.c.a((String)var103_91, 9.5f, var23_13);
                    v104 = new Object[3];
                    v104[2] = Float.valueOf(var75_44);
                    v104[1] = var5_4;
                    v104[0] = (int)SpotiPlayer.c("y", (int)16230, (long)(173628057198321268L ^ var3_2));
                    kuzi.obf.l.c.c.b((String)var103_91, var47_28, var98_76 + var99_85 - var105_95, var104_93, 9.5f, SpotiPlayer.c(v104));
                }
                finally {
                    kuzi.obf.l.c.c.g(var58_35, (short)var59_36, (short)var60_37);
                }
            }
            return;
        }
    }

    private static void f(Object[] objectArray) {
        float f2 = ((Float)objectArray[0]).floatValue();
        long l2 = (Long)objectArray[1];
        float f3 = ((Float)objectArray[2]).floatValue();
        float f4 = ((Float)objectArray[3]).floatValue();
        int n2 = (Integer)objectArray[4];
        long l3 = (l2 = bb ^ l2) ^ 0x507FF598AE0DL;
        SpotiPlayer.f("\u00c6", (float)(f2 - f4 * 0.5f), (float)(f3 - f4), (float)(f2 - f4 * 0.5f), (float)(f3 + f4), (float)(f2 + f4 * 0.95f), (float)f3, (int)n2, (long)l3, (long)-2267066005047518710L, (long)l2);
    }

    private static void m(Object[] objectArray) {
        float f2 = ((Float)objectArray[0]).floatValue();
        float f3 = ((Float)objectArray[1]).floatValue();
        float f4 = ((Float)objectArray[2]).floatValue();
        int n2 = (Integer)objectArray[3];
        long l2 = (Long)objectArray[4];
        long l3 = (l2 = bb ^ l2) ^ 0x50CAB1D19E12L;
        float f5 = f4 * 0.36f;
        float f6 = f4 * 1.9f;
        kuzi.obf.l.c.c.a(f2 - f4 * 0.62f, f3 - f6 / 2.0f, f5, f6, f5 * 0.35f, n2, l3);
        kuzi.obf.l.c.c.a(f2 + f4 * 0.26f, f3 - f6 / 2.0f, f5, f6, f5 * 0.35f, n2, l3);
    }

    private static void n(Object[] objectArray) {
        long l2;
        int n2 = (Integer)objectArray[0];
        int n3 = (Integer)objectArray[1];
        float f2 = ((Float)objectArray[2]).floatValue();
        int n4 = (Integer)objectArray[3];
        float f3 = ((Float)objectArray[4]).floatValue();
        float f4 = ((Float)objectArray[5]).floatValue();
        int n5 = (Integer)objectArray[6];
        long l3 = l2 = ((long)n2 << 48 | (long)n3 << 32 >>> 16 | (long)n4 << 48 >>> 48) ^ bb;
        long l4 = l3 ^ 0x419002DEEB6BL;
        long l5 = l3 ^ 0x21660558A731L;
        float f5 = f4 * 0.3f;
        float f6 = f4 * 1.7f;
        SpotiPlayer.f("\u00c6", (float)(f2 - f4 * 0.95f), (float)(f3 - f6 / 2.0f), (float)f5, (float)f6, (float)(f5 * 0.35f), (int)n5, (long)l5, (long)-6491037535715092096L, (long)l2);
        SpotiPlayer.f("\u00c6", (float)(f2 + f4 * 0.85f), (float)(f3 - f4 * 0.85f), (float)(f2 + f4 * 0.85f), (float)(f3 + f4 * 0.85f), (float)(f2 - f4 * 0.5f), (float)f3, (int)n5, (long)l4, (long)-6489737000063525012L, (long)l2);
    }

    private static void o(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        float f2 = ((Float)objectArray[1]).floatValue();
        float f3 = ((Float)objectArray[2]).floatValue();
        float f4 = ((Float)objectArray[3]).floatValue();
        int n2 = (Integer)objectArray[4];
        long l3 = l2 = bb ^ l2;
        long l4 = l3 ^ 0x2A943C0D9B0AL;
        long l5 = l3 ^ 0x4A623B8BD750L;
        float f5 = f4 * 0.3f;
        float f6 = f4 * 1.7f;
        SpotiPlayer.f("\u00c6", (float)(f2 + f4 * 0.65f), (float)(f3 - f6 / 2.0f), (float)f5, (float)f6, (float)(f5 * 0.35f), (int)n2, (long)l5, (long)-3059535395102725663L, (long)l2);
        SpotiPlayer.f("\u00c6", (float)(f2 - f4 * 0.85f), (float)(f3 - f4 * 0.85f), (float)(f2 - f4 * 0.85f), (float)(f3 + f4 * 0.85f), (float)(f2 + f4 * 0.5f), (float)f3, (int)n2, (long)l4, (long)-3058303063991095539L, (long)l2);
    }

    /*
     * Exception decompiling
     */
    private void p(Object[] var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * java.lang.UnsupportedOperationException
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.considerAsDoLoopStart(LoopIdentifier.java:383)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.identifyLoops1(LoopIdentifier.java:65)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:681)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private static void q(Object[] objectArray) {
        float f2 = ((Float)objectArray[0]).floatValue();
        float f3 = ((Float)objectArray[1]).floatValue();
        long l2 = (Long)objectArray[2];
        float f4 = ((Float)objectArray[3]).floatValue();
        int n2 = (Integer)objectArray[4];
        long l3 = l2 = bb ^ l2;
        long l4 = l3 ^ 0x226AE85CF9D3L;
        long l5 = l3 ^ 0x71DF9604E2A4L;
        SpotiPlayer.f("\u00c6", (float)f2, (float)(f3 + f4 * 1.05f), (float)(f4 * 0.42f), (int)n2, (long)l5, (long)-356847994004087305L, (long)l2);
        SpotiPlayer.f("\u00c6", (float)(f2 + f4 * 0.26f), (float)(f3 - f4 * 0.35f), (float)(f4 * 0.16f), (float)(f4 * 1.45f), (float)(f4 * 0.08f), (int)n2, (long)l4, (long)-357701040537221278L, (long)l2);
        SpotiPlayer.f("\u00c6", (float)(f2 + f4 * 0.26f), (float)(f3 - f4 * 0.4f), (float)(f4 * 0.62f), (float)(f4 * 0.17f), (float)(f4 * 0.085f), (int)n2, (long)l4, (long)-357701040537221278L, (long)l2);
    }

    private static int c(Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        float f2 = ((Float)objectArray[2]).floatValue();
        l2 = bb ^ l2;
        int n3 = (int)((float)(n2 >>> SpotiPlayer.c("y", (int)22978, (long)(0x38D0EDF35B2D46C3L ^ l2)) & SpotiPlayer.c("y", (int)15052, (long)(0x62550AC9CAF1A5EFL ^ l2))) * Math.max(0.0f, Math.min(1.0f, f2)));
        return n2 & SpotiPlayer.c("y", (int)12255, (long)(0x3603DC3D46C230C4L ^ l2)) | n3 << SpotiPlayer.c("y", (int)27881, (long)(0x187C0E52426273E5L ^ l2));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static String a(Object[] objectArray) {
        String string;
        CallSite callSite;
        String string2;
        String string3;
        CallSite callSite2;
        long l2;
        float f2;
        long l3;
        float f3;
        block13: {
            String string4;
            String string5 = (String)objectArray[0];
            f3 = ((Float)objectArray[1]).floatValue();
            l3 = (Long)objectArray[2];
            f2 = ((Float)objectArray[3]).floatValue();
            l2 = (l3 = bb ^ l3) ^ 0x615FD1D69207L;
            callSite2 = SpotiPlayer.f("\u00c6", (long)1802439378010609278L, (long)l3);
            try {
                try {
                    string4 = string5;
                    if (callSite2 == null) break block13;
                    if (SpotiPlayer.f("\u00c6", string4, (float)f2, (long)l2, (long)1817465595082357181L, (long)l3) <= f3) {
                        return string5;
                    }
                }
                catch (r r2) {
                    throw SpotiPlayer.f("\u00c6", (Object)r2, (long)1802935861549224578L, (long)l3);
                }
            }
            catch (r r3) {
                throw SpotiPlayer.f("\u00c6", (Object)r3, (long)1802935861549224578L, (long)l3);
            }
            string4 = string3 = string5;
        }
        block8: while (string3.length() > 0) {
            try {
                try {
                    string2 = string3;
                    callSite = SpotiPlayer.b("w", (int)21483, (long)(0x319BCA2C2A37E3B2L ^ l3));
                }
                catch (r r4) {
                    throw SpotiPlayer.f("\u00c6", (Object)r4, (long)1802935861549224578L, (long)l3);
                }
            }
            catch (r r5) {
                throw SpotiPlayer.f("\u00c6", (Object)r5, (long)1802935861549224578L, (long)l3);
            }
            do {
                string = string2 + (String)((Object)callSite);
                CallSite callSite3 = callSite2;
                if (l3 >= 0L) {
                    if (callSite3 == null) return string;
                    callSite3 = callSite2;
                }
                if (callSite3 == null) return string;
                if (SpotiPlayer.f("\u00c6", string, (float)f2, (long)l2, (long)1817465595082357181L, (long)l3) > f3) {
                    string3 = string3.substring(0, string3.length() - 1);
                    if (callSite2 != null) continue block8;
                }
                string2 = string3;
                callSite = SpotiPlayer.b("w", (int)8476, (long)(0x78529AA21039143L ^ l3));
            } while (l3 <= 0L);
        }
        string = string2 + (String)((Object)callSite);
        return string;
    }

    private static String c(Object[] objectArray) {
        int n2;
        long l2;
        block3: {
            int n3;
            block2: {
                l2 = (Long)objectArray[0];
                n2 = (Integer)objectArray[1];
                l2 = bb ^ l2;
                CallSite callSite = SpotiPlayer.f("\u00c6", (long)3384329715763487114L, (long)l2);
                try {
                    n3 = n2;
                    if (callSite == null) break block2;
                    if (n3 >= 0) break block3;
                }
                catch (r r2) {
                    throw SpotiPlayer.f("\u00c6", (Object)r2, (long)3382573304038188406L, (long)l2);
                }
                n3 = 0;
            }
            n2 = n3;
        }
        return String.format((String)((Object)SpotiPlayer.b("w", (int)8383, (long)(0xAE70BAB4B3DA702L ^ l2))), n2 / SpotiPlayer.c("y", (int)26383, (long)(0x6DA82D6913ACDFFDL ^ l2)), n2 % SpotiPlayer.c("y", (int)14085, (long)(0x32F89326DC098FECL ^ l2)));
    }

    /*
     * Unable to fully structure code
     */
    private void r(Object[] var1_1) {
        block4: {
            block3: {
                var7_2 = ((Boolean)var1_1[0]).booleanValue();
                var8_3 = (Integer)var1_1[1];
                var5_4 = (Long)var1_1[2];
                var2_5 = (Integer)var1_1[3];
                var3_6 = (Long)var1_1[4];
                var3_6 = SpotiPlayer.bb ^ var3_6;
                this.eqTickNanos = System.nanoTime();
                var9_7 = kuzi.obf.j.b.a.b();
                v0 = var7_2;
                if (var9_7 == null) break block3;
                if (v0 != 0) break block4;
                v0 = var10_8 = 0;
            }
            while (var10_8 < var8_3) {
                v1 = var10_8;
                this.eqBarHeights[v1] = this.eqBarHeights[v1] + (2.0f - this.eqBarHeights[var10_8]) * 0.2f;
                ++var10_8;
lbl19:
                // 2 sources

                ** while (var9_7 == null)
lbl20:
                // 1 sources

            }
lbl21:
            // 2 sources

            if (var3_6 <= 0L) ** GOTO lbl19
            return;
        }
        var10_9 = 125.0;
        var12_10 = 480.0;
        var14_11 = (double)(var5_4 % SpotiPlayer.d("i", (int)1854, (long)(7515634771956863841L ^ var3_6))) / 480.0;
        var16_12 = 240.0;
        var18_13 = (double)(var5_4 % (long)var16_12) / var16_12;
        var20_14 = (float)Math.exp(-3.4 * var14_11);
        var21_15 = (float)(Math.exp(-6.0 * var18_13) * 0.55);
        var22_16 = (float)var5_4 / 1000.0f;
        var23_17 = Math.max(1, var8_3 - 1);
        var24_18 = ((Double)this.r.a()).floatValue();
        for (var25_19 = 0; var25_19 < var8_3; ++var25_19) {
            var26_20 = 1.0f - Math.abs((float)var25_19 / (float)var23_17 * 2.0f - 1.0f);
            var27_21 = (6.0f + (1.0f - var26_20) * 16.0f) * this.eqSpeeds[var25_19];
            var28_22 = (float)(Math.sin(var22_16 * var27_21 + this.eqPhases[var25_19]) * 0.5 + 0.5);
            var29_23 = var26_20 * var20_14 + (1.0f - var26_20) * var21_15 + var28_22 * (0.3f + 0.45f * (1.0f - var26_20));
            var30_24 = Math.min(1.4f, var29_23) * var24_18;
            var31_25 = 2.0f + var30_24 * (float)(var2_5 - 2);
            v2 = var25_19;
            this.eqBarHeights[v2] = this.eqBarHeights[v2] + (var31_25 - this.eqBarHeights[var25_19]) * 0.35f;
            if (var9_7 != null) continue;
        }
    }

    private static void lambda$onTick$0(int n2, int n3, short s2) {
        long l2 = ((long)n2 << 32 | (long)n3 << 48 >>> 32 | (long)s2 << 48 >>> 48) ^ bb;
        BaseModule.a.setScreen((Screen)new o_0());
    }

    /*
     * Unable to fully structure code
     */
    static {
        block26: {
            block25: {
                block24: {
                    block23: {
                        block22: {
                            block21: {
                                SpotiPlayer.bb = kuzi.obf.h.b.v.a(-1494254222507897901L, 8575087150567479487L, MethodHandles.lookup().lookupClass()).a(280342030736139L);
                                SpotiPlayer.pb = new Object[150];
                                SpotiPlayer.sb = new String[150];
                                SpotiPlayer.f();
                                SpotiPlayer.ib = new HashMap<K, V>(13);
                                var22 = SpotiPlayer.bb ^ 25396424962827L;
                                var24_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                                v0 = SecretKeyFactory.getInstance("DES");
                                v1 = new byte[8];
                                v2 = v1;
                                v1[0] = (byte)(var22 >>> 56);
                                for (var25_2 = 1; var25_2 < 8; ++var25_2) {
                                    v2 = v2;
                                    v2[var25_2] = (byte)(var22 << var25_2 * 8 >>> 56);
                                }
                                var24_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                                var31_3 = new String[20];
                                var29_4 = 0;
                                var28_5 = "\u00c4\u00e4g\u0007\u00b1a\u00dd\u00db)pj\u00f4\u0016H\u00e0\u00ef\u00a9\u00a0\u0080\u00ff\u0017R\u00a3Z\u009c\u00cca\"\u008e\u00cbG\u00ae\u0010\u00c5@\u00bd\u0010\u0094\u00e6H\u0006={zi\u00a3\u0014\u00b6c \u00ace\u00e6o\u00cc\u00f2\u0004\u0013\u00e1`\u00c1/\u0083\u00d2\u009b\u00d2\u00dfm\u00a9\u0017L\u0097\u00ae\u00bf!\u00f6\u000f\u0091\u009a\u00c5&\u009c \u0011=\u0015\u00a3\u007f\u00a5D^\u00ed\u0081\u0091\u0010\u00ff,P\u009b\u0090\u00f0\u00bb\u007f\u00cb\u00f6B\u000fj\"X\u008e\u00fd\u00c2\u00b7lP|pf6,M\u00a5P\u00c4\u00efv\u008a\u00ee\u00c6\u00859\u0011 v{\u00de1\t\u00c3\u0006\u001eG\u00a4|\f_\u00f0\u00b0)\u00c7\u001c_\u00d8\u00d9\u00e3_\u00efz\u00c6TK\u00c9\u00a7\u00b4n-\u00e9\u00d3Fa\u0099\u00be\u00c7{\u00ac\u009a\u00aa\u0085\u008bw\f\u00d9\u000f\u001d\u00bbDd\nP\u00ea\u00f1O\u00a1\u00ec6 \u00bc\u00canx\u0003\u00c95\u00e1\u00e6\u00af%(\u001b_\u00ae\u00ec\u00b5\u00f3\u00f3\u00c7\u00ecm\u0088\u0002\u00c5\u00a3\u00de\u00daG\u00f5\u00eb\u00d7\u0010Q\u00a7J\u0084\u0005\u00c1\u00de\u0091\u00a4T\u0002wAG\u00b1=\u0010\u00af\u000e4e\u0083\u001f\u001f\u00aa\u00ce\"\u00b34\u0098|\u00df\u00b2\u0018\u00dd-d\u001c|\u00c5\u0092\u0005r\u00dd9^U\u00d5l\u0010^v\u00cf6\u00fd\u00f3l\u0000(\u00f4\u00d2\u0013\u00a6\u00d3\u00aa\u0098\u00fa\u00f0\u00c8\u00b824p\u00e8\u009d\u0095\u00a7\u00fc\u00ea\u00d1\u00a7\u0001R\u00e9\u0098P%\u0084P\u00ed\u00d8}?@l\u00c1#\u0014\u001a\u00104Q\u00fcx\u0090F\u00dd\u00d7\u00a1\u00b1\u00c0c\b6\\\u00e7 \u0003\u00ad\u009e\u0003\u00a3\b-\u00d2\u008a\u00f9\u00e4\rH\u008aJ\u00c3\u00b5`\u00fb\u00bb\u0017\u00d2\u00cd\u001c3\u00f2\u00db:\u00af\u00ca\u00fd!(\u001f\u0017\u0017m\u00ab\u00a9\u0087kO'l\u00a8`,d\u00f1vI\u00c8\u00ba{\u0080:\u00c5]\u00f5\u00a0\u008a\u009d\u00ec3\u0087ptIz\u00df\u0089\u00e4{\u0018U\u000b\u00c4R\u00e2\u00d9jT\\ag\u00a7sa\u00a6.\u00e6\u0004\u0011\u00b4dZ\u0014\u00e8 \u001f\u00f2O\u008a\u00a8\u0091\u0016\u00e2\u00e4\u00e2\u0085\u009b\u00f5\u00db\u00a7\u00af\u00b5\u0093e\u0007\u00cbJ\u0099\u00f0\u00b2t\u00e2\u0094\u00e4M]\u00a9(J\u001a5\u00b5\u0099\u008d/\u00e0\u0002\u008e\u000e\u00bc\"7n+\u00fal\u00b5S\u00aa\u00d7\u00c9h\u001f\u00ea\u00d8s\u0084ek\u00daF\u00f6\u00f6\u00ef&ru\u00a5(\u00b3\u00ee\u00c6\u00b1\u0087lG\u009eu\u00fd\u0095\u00e1em\u00d87\u0098\u00b9F\u00bf\u00b7\u00a5a\u00e9\u00e2~5^\u00f7\u0000\"\u0083J\u008b\u0006T\u0095\u00a36G\u0010\u00a8^P\u001d2\u007f\u009e,a~\u0085\u0005%\"\u00c5-";
                                var30_6 = "\u00c4\u00e4g\u0007\u00b1a\u00dd\u00db)pj\u00f4\u0016H\u00e0\u00ef\u00a9\u00a0\u0080\u00ff\u0017R\u00a3Z\u009c\u00cca\"\u008e\u00cbG\u00ae\u0010\u00c5@\u00bd\u0010\u0094\u00e6H\u0006={zi\u00a3\u0014\u00b6c \u00ace\u00e6o\u00cc\u00f2\u0004\u0013\u00e1`\u00c1/\u0083\u00d2\u009b\u00d2\u00dfm\u00a9\u0017L\u0097\u00ae\u00bf!\u00f6\u000f\u0091\u009a\u00c5&\u009c \u0011=\u0015\u00a3\u007f\u00a5D^\u00ed\u0081\u0091\u0010\u00ff,P\u009b\u0090\u00f0\u00bb\u007f\u00cb\u00f6B\u000fj\"X\u008e\u00fd\u00c2\u00b7lP|pf6,M\u00a5P\u00c4\u00efv\u008a\u00ee\u00c6\u00859\u0011 v{\u00de1\t\u00c3\u0006\u001eG\u00a4|\f_\u00f0\u00b0)\u00c7\u001c_\u00d8\u00d9\u00e3_\u00efz\u00c6TK\u00c9\u00a7\u00b4n-\u00e9\u00d3Fa\u0099\u00be\u00c7{\u00ac\u009a\u00aa\u0085\u008bw\f\u00d9\u000f\u001d\u00bbDd\nP\u00ea\u00f1O\u00a1\u00ec6 \u00bc\u00canx\u0003\u00c95\u00e1\u00e6\u00af%(\u001b_\u00ae\u00ec\u00b5\u00f3\u00f3\u00c7\u00ecm\u0088\u0002\u00c5\u00a3\u00de\u00daG\u00f5\u00eb\u00d7\u0010Q\u00a7J\u0084\u0005\u00c1\u00de\u0091\u00a4T\u0002wAG\u00b1=\u0010\u00af\u000e4e\u0083\u001f\u001f\u00aa\u00ce\"\u00b34\u0098|\u00df\u00b2\u0018\u00dd-d\u001c|\u00c5\u0092\u0005r\u00dd9^U\u00d5l\u0010^v\u00cf6\u00fd\u00f3l\u0000(\u00f4\u00d2\u0013\u00a6\u00d3\u00aa\u0098\u00fa\u00f0\u00c8\u00b824p\u00e8\u009d\u0095\u00a7\u00fc\u00ea\u00d1\u00a7\u0001R\u00e9\u0098P%\u0084P\u00ed\u00d8}?@l\u00c1#\u0014\u001a\u00104Q\u00fcx\u0090F\u00dd\u00d7\u00a1\u00b1\u00c0c\b6\\\u00e7 \u0003\u00ad\u009e\u0003\u00a3\b-\u00d2\u008a\u00f9\u00e4\rH\u008aJ\u00c3\u00b5`\u00fb\u00bb\u0017\u00d2\u00cd\u001c3\u00f2\u00db:\u00af\u00ca\u00fd!(\u001f\u0017\u0017m\u00ab\u00a9\u0087kO'l\u00a8`,d\u00f1vI\u00c8\u00ba{\u0080:\u00c5]\u00f5\u00a0\u008a\u009d\u00ec3\u0087ptIz\u00df\u0089\u00e4{\u0018U\u000b\u00c4R\u00e2\u00d9jT\\ag\u00a7sa\u00a6.\u00e6\u0004\u0011\u00b4dZ\u0014\u00e8 \u001f\u00f2O\u008a\u00a8\u0091\u0016\u00e2\u00e4\u00e2\u0085\u009b\u00f5\u00db\u00a7\u00af\u00b5\u0093e\u0007\u00cbJ\u0099\u00f0\u00b2t\u00e2\u0094\u00e4M]\u00a9(J\u001a5\u00b5\u0099\u008d/\u00e0\u0002\u008e\u000e\u00bc\"7n+\u00fal\u00b5S\u00aa\u00d7\u00c9h\u001f\u00ea\u00d8s\u0084ek\u00daF\u00f6\u00f6\u00ef&ru\u00a5(\u00b3\u00ee\u00c6\u00b1\u0087lG\u009eu\u00fd\u0095\u00e1em\u00d87\u0098\u00b9F\u00bf\u00b7\u00a5a\u00e9\u00e2~5^\u00f7\u0000\"\u0083J\u008b\u0006T\u0095\u00a36G\u0010\u00a8^P\u001d2\u007f\u009e,a~\u0085\u0005%\"\u00c5-".length();
                                var27_7 = 32;
                                var26_8 = -1;
lbl23:
                                // 2 sources

                                while (true) {
                                    v3 = ++var26_8;
                                    v4 = var28_5.substring(v3, v3 + var27_7);
                                    v5 = -1;
                                    break block21;
                                    break;
                                }
lbl28:
                                // 1 sources

                                while (true) {
                                    var31_3[var29_4++] = SpotiPlayer.b(var32_9).intern();
                                    if ((var26_8 += var27_7) < var30_6) {
                                        var27_7 = var28_5.charAt(var26_8);
                                        ** continue;
                                    }
                                    var28_5 = "\u00fdQ\u00dc\u00e4\u00da\u00c9\u00e1\u00f7U\u00ff\u00ba\u00dde]\u00e0\u00fd\u0012\u00ef6*\u00cdb\u00d9\u0012A\u009f7\u00aer\u00ccb\u001b\u0010\u00cc\u00cc\u0087\u0006~\u001a%\u0080}Szd3U\u0014\u009b";
                                    var30_6 = "\u00fdQ\u00dc\u00e4\u00da\u00c9\u00e1\u00f7U\u00ff\u00ba\u00dde]\u00e0\u00fd\u0012\u00ef6*\u00cdb\u00d9\u0012A\u009f7\u00aer\u00ccb\u001b\u0010\u00cc\u00cc\u0087\u0006~\u001a%\u0080}Szd3U\u0014\u009b".length();
                                    var27_7 = 32;
                                    var26_8 = -1;
lbl37:
                                    // 2 sources

                                    while (true) {
                                        v6 = ++var26_8;
                                        v4 = var28_5.substring(v6, v6 + var27_7);
                                        v5 = 0;
                                        break block21;
                                        break;
                                    }
                                    break;
                                }
lbl42:
                                // 1 sources

                                while (true) {
                                    var31_3[var29_4++] = SpotiPlayer.b(var32_9).intern();
                                    if ((var26_8 += var27_7) < var30_6) {
                                        var27_7 = var28_5.charAt(var26_8);
                                        ** continue;
                                    }
                                    break block22;
                                    break;
                                }
                            }
                            var32_9 = var24_1.doFinal(v4.getBytes("ISO-8859-1"));
                            switch (v5) {
                                default: {
                                    ** continue;
                                }
                                ** case 0:
lbl54:
                                // 1 sources

                                ** continue;
                            }
                        }
                        SpotiPlayer.db = var31_3;
                        SpotiPlayer.hb = new String[20];
                        SpotiPlayer.lb = new HashMap<K, V>(13);
                        var11_10 = Cipher.getInstance("DES/CBC/NoPadding");
                        v7 = SecretKeyFactory.getInstance("DES");
                        v8 = new byte[8];
                        v9 = v8;
                        v8[0] = (byte)(var22 >>> 56);
                        for (var12_11 = 1; var12_11 < 8; ++var12_11) {
                            v9 = v9;
                            v9[var12_11] = (byte)(var22 << var12_11 * 8 >>> 56);
                        }
                        var11_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                        var17_12 = new long[74];
                        var14_13 = 0;
                        var15_14 = "\u00ae\u00ba\u00d1\u00ae\u0098c\u00d3\u0088\u0089\u00f1\u009c]\u0091\u0080\u0093Af\u00a6\u00f9\u001c\"R\u009d-c\u0095\u00de\u001f\u0007\u0098\u00be\u00fcr\u00e8a\u00ddn\u0087\u00b4\u001a.\u00d1\u00af4s6cz\u0096\u00fc\u009e\u00d8\u0018\u00912\u00cdL^0\u00db\u0080\u00a3\u00c7$\u00d95\u00e9ToMn\u00c5\u0081i\\\u0092\u00b3\u00e2\u00b5\u009a'\u009c\u0014\u00db!N\u00c4AE\u0018\u00b7!0\\\u00e8\u00f6\u0098\u0083\u0017t\u00b7\u00b6HX\u009d\u00d9\u0014\u008e7\u009b\u00c2\"\u0098\u0013\u0099\u0011\u00c9\u00a2\u00f7\u00bcF\u00a7\u00bf\u0002%\u008a\u0085C\u00e8Gb\u00d1L\u001dG3\u0002\u00e6\u0010\u00a6P\u00a6\u009e\fz\u00f7\u0097jr\u008f\u0016K\u00e14\u00d4oy{\u007f=\u000fa\u00f7.\u00d8\u008b\u009c1\u0091\u00c4\u00bcr\u00e2\u0095WeTx\u00c4\u0099,\u0017\u00fc{\u001c\u00dc\u00953\u00e4\u0088_\u0097\u009fi\u0007\u0000.\u0093]\u00ff\u00f1\u00b6\u00f8\u008c\u00a3\u00a0\u00ef\u00bc\u00a9\u008a\u001a\u00d8\u00e1\u008f\u0098\u0004\u0003\u00bf\u0018\u0093\u00c1k\u00e5\u00ef\u00c2u\u00d4-\u0092\u0080\u0012\r]\u00bcx\u00fc\u0090\u001c\u00d7\u000f\u001d\u0016\u0004\u00f7J\u00c8x\u00f3\u00daI&\u0006\u00c9\u0097\"=e\u00fa\u00b8\u00ad\u0016\u00d27\u00a8\u00f6/\u00c1\u0085\u00f3\u00e4\u00c3\u0088\u00a8\u00d4\u0080\u00a3pm}\u00bd\u00ff\u0093j\u00cb\u00f2\u00af\u00b3$\u001e\u00d0E\u008e#!\u001em\u00e4Q\u00d4\u0006\u00bct\u00db\u00ee\u0081\u00e1,\u00d6\u00efS\u00b1\u00f7\u00d0:s\u00da\u00ee+)\u0099t\u00a7w)\u0011\u00b7\u00fa\u00db\u00e2\u0097\u0010\u00a9r\u00f9!\u0099i\u00e2\u001c:p\u00b7p\u00cb\u00d2Yr,?Q\u00e9\u00c5\u00d7\u00cfG\u00e8S\u0092|\u000ej~\u00abG\u00b1hbP^\u000e\u0010\u00aa\u00d4\u0002\u00cb\u0005l\u00be\u00f2\u000eO\u00da\u00b7\u00008\u00e9(\u0085kCRUH\u00c4w\u00a5\u00b6\u00b1\u00f0\u0083*;\u00f3\u00be\u00a5\u0011DG\u00a8\u009a\u0086\u00ef \u00c4T\u00f5\u0006\u00b8^ZA\u00de\u00a3/^2[:c^@t\r\u009bI\u007f\u001ey\u00f0\u00e9\u00eeb\u0003\u00d1\u00af\u00d7;\u00f3$~xO\u00bc\u0018(\u00de\u0091\u00ea\u00cd}RB1\u00b0\u00f9\u00be?\u00f1\u001d\u009e9iv\u0092\u00e1r\u0006\u00dd\u001e\u00fd\u00e4\u00d2\u008e\u00a7/:$=\u00eb\u00faP\u0013\u001a\fgM\u00c1\u008d\u00a4\u0011\u00c2\u001f\u00eda\u0016\u00cd\u00911D\u009d4\u00be\u00fc\u0003\u00d2\u00bb\u00b0\u007f~\u009aP\u0004\u00d5\u00a2\u0093\u00afU\u00a0\u008d%\u00da\"\b\u00ce\u00af\u00b0\u00a8\u00c6)\u00c6\u00d2\u007f\u00caA\u0012\u007f8\u00e2b\u008bPb\u0093\u00a5\u00e3Z\u00adX\u009a\u00e9RG\u009a&/\u00f5\u008cf\u0003\u00c5)\u0089`\u0099\u0099\u00d1";
                        var16_15 = "\u00ae\u00ba\u00d1\u00ae\u0098c\u00d3\u0088\u0089\u00f1\u009c]\u0091\u0080\u0093Af\u00a6\u00f9\u001c\"R\u009d-c\u0095\u00de\u001f\u0007\u0098\u00be\u00fcr\u00e8a\u00ddn\u0087\u00b4\u001a.\u00d1\u00af4s6cz\u0096\u00fc\u009e\u00d8\u0018\u00912\u00cdL^0\u00db\u0080\u00a3\u00c7$\u00d95\u00e9ToMn\u00c5\u0081i\\\u0092\u00b3\u00e2\u00b5\u009a'\u009c\u0014\u00db!N\u00c4AE\u0018\u00b7!0\\\u00e8\u00f6\u0098\u0083\u0017t\u00b7\u00b6HX\u009d\u00d9\u0014\u008e7\u009b\u00c2\"\u0098\u0013\u0099\u0011\u00c9\u00a2\u00f7\u00bcF\u00a7\u00bf\u0002%\u008a\u0085C\u00e8Gb\u00d1L\u001dG3\u0002\u00e6\u0010\u00a6P\u00a6\u009e\fz\u00f7\u0097jr\u008f\u0016K\u00e14\u00d4oy{\u007f=\u000fa\u00f7.\u00d8\u008b\u009c1\u0091\u00c4\u00bcr\u00e2\u0095WeTx\u00c4\u0099,\u0017\u00fc{\u001c\u00dc\u00953\u00e4\u0088_\u0097\u009fi\u0007\u0000.\u0093]\u00ff\u00f1\u00b6\u00f8\u008c\u00a3\u00a0\u00ef\u00bc\u00a9\u008a\u001a\u00d8\u00e1\u008f\u0098\u0004\u0003\u00bf\u0018\u0093\u00c1k\u00e5\u00ef\u00c2u\u00d4-\u0092\u0080\u0012\r]\u00bcx\u00fc\u0090\u001c\u00d7\u000f\u001d\u0016\u0004\u00f7J\u00c8x\u00f3\u00daI&\u0006\u00c9\u0097\"=e\u00fa\u00b8\u00ad\u0016\u00d27\u00a8\u00f6/\u00c1\u0085\u00f3\u00e4\u00c3\u0088\u00a8\u00d4\u0080\u00a3pm}\u00bd\u00ff\u0093j\u00cb\u00f2\u00af\u00b3$\u001e\u00d0E\u008e#!\u001em\u00e4Q\u00d4\u0006\u00bct\u00db\u00ee\u0081\u00e1,\u00d6\u00efS\u00b1\u00f7\u00d0:s\u00da\u00ee+)\u0099t\u00a7w)\u0011\u00b7\u00fa\u00db\u00e2\u0097\u0010\u00a9r\u00f9!\u0099i\u00e2\u001c:p\u00b7p\u00cb\u00d2Yr,?Q\u00e9\u00c5\u00d7\u00cfG\u00e8S\u0092|\u000ej~\u00abG\u00b1hbP^\u000e\u0010\u00aa\u00d4\u0002\u00cb\u0005l\u00be\u00f2\u000eO\u00da\u00b7\u00008\u00e9(\u0085kCRUH\u00c4w\u00a5\u00b6\u00b1\u00f0\u0083*;\u00f3\u00be\u00a5\u0011DG\u00a8\u009a\u0086\u00ef \u00c4T\u00f5\u0006\u00b8^ZA\u00de\u00a3/^2[:c^@t\r\u009bI\u007f\u001ey\u00f0\u00e9\u00eeb\u0003\u00d1\u00af\u00d7;\u00f3$~xO\u00bc\u0018(\u00de\u0091\u00ea\u00cd}RB1\u00b0\u00f9\u00be?\u00f1\u001d\u009e9iv\u0092\u00e1r\u0006\u00dd\u001e\u00fd\u00e4\u00d2\u008e\u00a7/:$=\u00eb\u00faP\u0013\u001a\fgM\u00c1\u008d\u00a4\u0011\u00c2\u001f\u00eda\u0016\u00cd\u00911D\u009d4\u00be\u00fc\u0003\u00d2\u00bb\u00b0\u007f~\u009aP\u0004\u00d5\u00a2\u0093\u00afU\u00a0\u008d%\u00da\"\b\u00ce\u00af\u00b0\u00a8\u00c6)\u00c6\u00d2\u007f\u00caA\u0012\u007f8\u00e2b\u008bPb\u0093\u00a5\u00e3Z\u00adX\u009a\u00e9RG\u009a&/\u00f5\u008cf\u0003\u00c5)\u0089`\u0099\u0099\u00d1".length();
                        var13_16 = 0;
                        while (true) {
                            var18_17 = var15_14.substring(var13_16, var13_16 += 8).getBytes("ISO-8859-1");
                            v10 = var17_12;
                            v11 = var14_13++;
                            v12 = ((long)var18_17[0] & 255L) << 56 | ((long)var18_17[1] & 255L) << 48 | ((long)var18_17[2] & 255L) << 40 | ((long)var18_17[3] & 255L) << 32 | ((long)var18_17[4] & 255L) << 24 | ((long)var18_17[5] & 255L) << 16 | ((long)var18_17[6] & 255L) << 8 | (long)var18_17[7] & 255L;
                            v13 = -1;
                            break block23;
                            break;
                        }
lbl81:
                        // 1 sources

                        while (true) {
                            v10[v11] = v14;
                            if (var13_16 < var16_15) ** continue;
                            var15_14 = "\u00df\u008d\u00c5\u00194\u00b23\u00bf&-\u00a8X\u00ac\u00aa\u00a0\u0003";
                            var16_15 = "\u00df\u008d\u00c5\u00194\u00b23\u00bf&-\u00a8X\u00ac\u00aa\u00a0\u0003".length();
                            var13_16 = 0;
                            while (true) {
                                var18_17 = var15_14.substring(var13_16, var13_16 += 8).getBytes("ISO-8859-1");
                                v10 = var17_12;
                                v11 = var14_13++;
                                v12 = ((long)var18_17[0] & 255L) << 56 | ((long)var18_17[1] & 255L) << 48 | ((long)var18_17[2] & 255L) << 40 | ((long)var18_17[3] & 255L) << 32 | ((long)var18_17[4] & 255L) << 24 | ((long)var18_17[5] & 255L) << 16 | ((long)var18_17[6] & 255L) << 8 | (long)var18_17[7] & 255L;
                                v13 = 0;
                                break block23;
                                break;
                            }
                            break;
                        }
lbl94:
                        // 1 sources

                        while (true) {
                            v10[v11] = v14;
                            if (var13_16 < var16_15) ** continue;
                            break block24;
                            break;
                        }
                    }
                    var19_18 = v12;
                    var21_19 = var11_10.doFinal(new byte[]{(byte)(var19_18 >>> 56), (byte)(var19_18 >>> 48), (byte)(var19_18 >>> 40), (byte)(var19_18 >>> 32), (byte)(var19_18 >>> 24), (byte)(var19_18 >>> 16), (byte)(var19_18 >>> 8), (byte)var19_18});
                    v14 = ((long)var21_19[0] & 255L) << 56 | ((long)var21_19[1] & 255L) << 48 | ((long)var21_19[2] & 255L) << 40 | ((long)var21_19[3] & 255L) << 32 | ((long)var21_19[4] & 255L) << 24 | ((long)var21_19[5] & 255L) << 16 | ((long)var21_19[6] & 255L) << 8 | (long)var21_19[7] & 255L;
                    switch (v13) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl107:
                        // 1 sources

                        ** continue;
                    }
                }
                SpotiPlayer.jb = var17_12;
                SpotiPlayer.kb = new Integer[74];
                SpotiPlayer.X = 0x121212;
                SpotiPlayer.Z = 0xA0A0A0;
                SpotiPlayer.ak = 9;
                SpotiPlayer.ag = 72;
                SpotiPlayer.at = -5590078;
                SpotiPlayer.ap = -14756000;
                SpotiPlayer.ab = 0xA0A0A0;
                SpotiPlayer.ah = 14;
                SpotiPlayer.W = 1947988;
                SpotiPlayer.aj = 11;
                SpotiPlayer.as = -1183499;
                SpotiPlayer.Y = 0xFFFFFF;
                SpotiPlayer.au = 0x2EFFFFFF;
                SpotiPlayer.ai = 3;
                SpotiPlayer.Q = 128;
                SpotiPlayer.an = 0x1FFFFFFF;
                SpotiPlayer.af = 12;
                SpotiPlayer.aq = -854792;
                SpotiPlayer.aa = 0x404040;
                SpotiPlayer.ar = -6774352;
                SpotiPlayer.ao = 0x14FFFFFF;
                SpotiPlayer.ob = new HashMap<K, V>(13);
                var0_20 = Cipher.getInstance("DES/CBC/NoPadding");
                v15 = SecretKeyFactory.getInstance("DES");
                v16 = new byte[8];
                v17 = v16;
                v16[0] = (byte)(var22 >>> 56);
                for (var1_21 = 1; var1_21 < 8; ++var1_21) {
                    v17 = v17;
                    v17[var1_21] = (byte)(var22 << var1_21 * 8 >>> 56);
                }
                var0_20.init(2, (Key)v15.generateSecret(new DESKeySpec(v17)), new IvParameterSpec(new byte[8]));
                var6_22 = new long[2];
                var3_23 = 0;
                var4_24 = "\u0006\u00c7\u00db[\u009a\u00a3\u00dd\u00a8e\u00f7\u001f\u0093\u00b6n~\u00da";
                var5_25 = "\u0006\u00c7\u00db[\u009a\u00a3\u00dd\u00a8e\u00f7\u001f\u0093\u00b6n~\u00da".length();
                var2_26 = 0;
                while (true) {
                    break block25;
                    break;
                }
lbl150:
                // 1 sources

                while (true) {
                    var6_22[v18] = ((long)var10_29[0] & 255L) << 56 | ((long)var10_29[1] & 255L) << 48 | ((long)var10_29[2] & 255L) << 40 | ((long)var10_29[3] & 255L) << 32 | ((long)var10_29[4] & 255L) << 24 | ((long)var10_29[5] & 255L) << 16 | ((long)var10_29[6] & 255L) << 8 | (long)var10_29[7] & 255L;
                    if (var2_26 < var5_25) ** continue;
                    break block26;
                    break;
                }
            }
            var7_27 = var4_24.substring(var2_26, var2_26 += 8).getBytes("ISO-8859-1");
            v18 = var3_23++;
            var8_28 = ((long)var7_27[0] & 255L) << 56 | ((long)var7_27[1] & 255L) << 48 | ((long)var7_27[2] & 255L) << 40 | ((long)var7_27[3] & 255L) << 32 | ((long)var7_27[4] & 255L) << 24 | ((long)var7_27[5] & 255L) << 16 | ((long)var7_27[6] & 255L) << 8 | (long)var7_27[7] & 255L;
            var10_29 = var0_20.doFinal(new byte[]{(byte)(var8_28 >>> 56), (byte)(var8_28 >>> 48), (byte)(var8_28 >>> 40), (byte)(var8_28 >>> 32), (byte)(var8_28 >>> 24), (byte)(var8_28 >>> 16), (byte)(var8_28 >>> 8), (byte)var8_28});
            ** while (true)
        }
        SpotiPlayer.mb = var6_22;
        SpotiPlayer.nb = new Long[2];
    }

    private static Throwable a(Throwable throwable) {
        return throwable;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static String b(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x2941;
        if (hb[n3] == null) {
            Object[] objectArray;
            try {
                Long l3 = Thread.currentThread().threadId();
                objectArray = (Object[])ib.get(l3);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    ib.put(l3, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/b/o", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l2 >>> 56);
            for (int i2 = 1; i2 < 8; ++i2) {
                byArray[i2] = (byte)(l2 << i2 * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = db[n3].getBytes("ISO-8859-1");
            SpotiPlayer.hb[n3] = SpotiPlayer.b(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return hb[n3];
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        String string2 = SpotiPlayer.b(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static CallSite b(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/b/o" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x1635;
        if (kb[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = jb[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])lb.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    lb.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/b/o", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            SpotiPlayer.kb[n3] = n4;
        }
        return kb[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = SpotiPlayer.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/b/o" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static long d(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x1640;
        if (nb[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = mb[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])ob.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    ob.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/b/o", exception);
            }
            long l5 = ((long)byArray[0] & 0xFFL) << 56 | ((long)byArray[1] & 0xFFL) << 48 | ((long)byArray[2] & 0xFFL) << 40 | ((long)byArray[3] & 0xFFL) << 32 | ((long)byArray[4] & 0xFFL) << 24 | ((long)byArray[5] & 0xFFL) << 16 | ((long)byArray[6] & 0xFFL) << 8 | (long)byArray[7] & 0xFFL;
            SpotiPlayer.nb[n3] = l5;
        }
        return nb[n3];
    }

    private static long d(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        long l3 = SpotiPlayer.d(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Long.TYPE, l3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return l3;
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_2().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/b/o" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (sb[n4] != null) {
            return n4;
        }
        Object object = pb[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 0;
            case 1 -> 48;
            case 2 -> 3;
            case 3 -> 44;
            case 4 -> 21;
            case 5 -> 28;
            case 6 -> 57;
            case 7 -> 60;
            case 8 -> 27;
            case 9 -> 30;
            case 10 -> 9;
            case 11 -> 8;
            case 12 -> 35;
            case 13 -> 34;
            case 14 -> 54;
            case 15 -> 32;
            case 16 -> 18;
            case 17 -> 45;
            case 18 -> 17;
            case 19 -> 42;
            case 20 -> 10;
            case 21 -> 47;
            case 22 -> 63;
            case 23 -> 16;
            case 24 -> 39;
            case 25 -> 29;
            case 26 -> 37;
            case 27 -> 55;
            case 28 -> 25;
            case 29 -> 2;
            case 30 -> 26;
            case 31 -> 36;
            case 32 -> 46;
            case 33 -> 51;
            case 34 -> 62;
            case 35 -> 49;
            case 36 -> 11;
            case 37 -> 23;
            case 38 -> 38;
            case 39 -> 50;
            case 40 -> 12;
            case 41 -> 52;
            case 42 -> 15;
            case 43 -> 4;
            case 44 -> 19;
            case 45 -> 33;
            case 46 -> 13;
            case 47 -> 6;
            case 48 -> 14;
            case 49 -> 7;
            case 50 -> 53;
            case 51 -> 61;
            case 52 -> 40;
            case 53 -> 43;
            case 54 -> 31;
            case 55 -> 59;
            case 56 -> 41;
            case 57 -> 58;
            case 58 -> 1;
            case 59 -> 22;
            case 60 -> 24;
            case 61 -> 5;
            case 62 -> 56;
            default -> 20;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        SpotiPlayer.sb[n4] = new String(cArray);
        return n4;
    }

    private static void f() {
        Object[] objectArray = pb;
        pb[0] = "0Pye1*;Pze1";
        objectArray[1] = "\u001c\u00048\u001a\u0016`i$3\u0015\u0007/\u0014< \u0012\u000ef|";
        objectArray[2] = "g\u0003;&7]l\u00038&9";
        objectArray[3] = "=%\\}d?6*M2\u001e;%+]}(?2";
        objectArray[4] = "\u0015K";
        objectArray[5] = "Yn\u0019V\u00030Pn\u001aV\u000f";
        objectArray[6] = "\u0012!";
        objectArray[7] = "U/";
        objectArray[8] = "~\u0015\fL\u0011qw\u0015\u000fL\u0011";
        objectArray[9] = "\u0005D1\u0001pE\u000eK N\u0011K\u0005@$\u0014";
        objectArray[10] = Long.TYPE;
        SpotiPlayer.sb[10] = "java/lang/Long";
        objectArray[11] = "OK4\u0007,>BK6\u0007.";
        objectArray[12] = Integer.TYPE;
        SpotiPlayer.sb[12] = "java/lang/Integer";
        objectArray[13] = "F\r";
        objectArray[14] = Boolean.TYPE;
        SpotiPlayer.sb[14] = "java/lang/Boolean";
        objectArray[15] = Void.TYPE;
        SpotiPlayer.sb[15] = "java/lang/Void";
        objectArray[16] = Float.TYPE;
        SpotiPlayer.sb[16] = "java/lang/Float";
        objectArray[17] = "/Hho}a$Hko{";
        objectArray[18] = "\u001e\u0014',f/k4,#w`\n:'(s:~";
        objectArray[19] = "32\u0002\u001b\"\u001cF\u0012\t\u00143S'\u001c\u0002\u001f7\tS";
        objectArray[20] = "j-\u001e\u0006C\u0016\u001f\r\u0015\tRY~\u0003\u001e\u0002V\u0003\n";
        objectArray[21] = "q:Tyzrl,\u000e`\u007fyzq\tetd|9\u0003tky;\f\nzoys&;ER";
        objectArray[22] = "4MF\u001a\u0002rAmM\u0015\u0013= cF\u001e\u0017gT";
        objectArray[23] = "Gfmc\u001e8Nfnc\u001c";
        objectArray[24] = "57:M#\u000b@\u00171B2D!\u0019:I6\u001eU";
        objectArray[25] = "&J%\u0016\"JSj.\u00193\u00052d%\u00127_F";
        objectArray[26] = "C\u0014";
        objectArray[27] = "\u0019\r5\"?\u0013l->-.\\\u00115-*'\u0015y";
        objectArray[28] = "zN/bI\u0019qN'";
        objectArray[29] = "&xpD;a-wa\u000bFy>phB";
        objectArray[30] = "_0I`\t5V0J`\u0002";
        objectArray[31] = "M\u001a$4}lS\u0012>{\u0001xI\u001f=8";
        objectArray[32] = "\u001a\u001do0F1\u0011\u001dd";
        objectArray[33] = "G{";
        objectArray[34] = "\u0012\u0002\u0001\u0002$r\u000f\u0017Y\ngr\u001f\u0006Y!\u007fu\u001e\u0006\u0005\u0006nZ\u0015\u0002\u0010\u0006";
        objectArray[35] = "\u0011\u0018QQ7Vd8Z^&\u0019\u00056QU\"Cq";
        objectArray[36] = "\u0018a,`?c\u0018a;<3l\u0002*;\"3y\u0005[k\u007fb";
        objectArray[37] = "Q\b)J\u0001?$(\"E\u0010pE&)N\u0014*1";
        objectArray[38] = "\u007f#5=L\u001b\n\u0003>2]Tk\r59Y\u000e\u001f";
        objectArray[39] = "H0^{.\u000f=\u0010Ut?@\\\u001e^\u007f;\u001a(";
        objectArray[40] = "^B\u007f\b{LOBR";
        objectArray[41] = "\u0012kc\u0013I\u0011gKh\u001cX^\u0006Ec\u0017\\\u0004r";
        objectArray[42] = "r\u000e%\u0005wI\u0007..\nf\u0006f %\u0001b\\\u0012";
        objectArray[43] = "\u0007O\u0014t5\u0005ro\u001f{$J\u0013a\u0014p \u0010g";
        objectArray[44] = Short.TYPE;
        SpotiPlayer.sb[44] = "java/lang/Short";
        objectArray[45] = "<OA\"'D!Y\u001b;\"O7\u0004\u001c>)R1L\u0016/6OvG\u0000*#Jv~\u001d/%M";
        objectArray[46] = "P\u0003hRa4%#c]p{D-hVt!0";
        objectArray[47] = "j#BA\u00190\u001f\u0003IN\b\u007f~\rBE\f%\n";
        objectArray[48] = "\u0001MY\u000f$\u0017tmR\u00005X\u0015cY\u000b1\u0002a";
        objectArray[49] = "\u0010ep\u0000*leE{\u000f;#\u0004Kp\u0004?yp";
        objectArray[50] = "d4tIW \u0011\u0014\u007fFFop\u001atMB5\u0004";
        objectArray[51] = "dy4xB\u007f\u0011Y?wS0pW4|Wj\u0004";
        objectArray[52] = "k[\u00145c\u0019\u001e{\u001f:rV\u007fu\u00141v\f\u000b";
        objectArray[53] = Byte.TYPE;
        SpotiPlayer.sb[53] = "java/lang/Byte";
        objectArray[54] = ";\u000bx=G\rN+s2VB/%x9R\u0018[";
        objectArray[55] = Character.TYPE;
        SpotiPlayer.sb[55] = "java/lang/Character";
        objectArray[56] = "\u001aIgw\n9oilx\u001bv\u000eggs\u001f,z";
        objectArray[57] = "\u0019\b9P*|l(2_;3\r&9T?iy";
        objectArray[58] = "=,=\b \u0016H\f6\u00071Y)\u0002=\f5\u0003]";
        objectArray[59] = "s\u0003\rsOU\u0006#\u0006|^\u001ag-\rwZ@\u0013";
        objectArray[60] = "k` \t*\u001d\u001e@+\u0006;R\u007fN \r?\b\u000b";
        objectArray[61] = "\f\fVi\u000by\\LSit|5D\u000ei\tiJ\u001cJu\u0014v5MKq\u0015\u007fN\u0001Id\u001e\u0015";
        objectArray[62] = "_/EXAJY-\u0002I<W`v\u0013P\rZ\u001d(BDQ:\t1\u001eLA@Z4\u0003H<";
        objectArray[63] = "Yx\u0014w9Z_zSfDCf!B\u007fuJ\u001b\u007f\u0013k)*VfOz.Q\u001adZqD@\rqY+t\u0012\u000f.Y\u001b.A\to\u0018+|CVo(q/E\u0017.\u0018#-\u001a\u0017\u001eBp+[V.\u0010rt[ftCt5\u001aV&A+5*\fuGjt\u001a^w\u0018jDC\u001eyPf>\u0010\u001bdT\u001b";
        objectArray[64] = "gNY\"r\u0011aL\u001e3\u000f\u000eX\u0018\u001d)n\u000b#T\u001f<ea%P\u001e)2\u001f3B\bv\u000f\u001c S\u0002sq\n2E]Nf\u0019?P\u001845\u001c\"Te";
        objectArray[65] = "@d`vQ#\u0010$ev.\u0004ykcr_.\u001bdto\u0017";
        objectArray[66] = ".\u0004WW`z(\u0006\u0010F\u001d`\u0011\u0001\u0010\u0007wlp]\u0014\u0005e\n.\b\u000f\n}wpY\u001bV\u001d`z\r\u001a\u000b-2xR\u001a;wa~\u0013[\u000b%c!\u0013kQve`R[\u0003t:`b[Czk{\u0019\u0017Ao`\u0011\u000b\u0013\\ewkX\u0016Aa\n";
        objectArray[67] = "D3)|\u001fLA-q\f\t#B8-~\u001f\u0018\u0013w+lcJ[.1q\u0019\u0019^35\f";
        objectArray[68] = "M:8\u001f.7\u001dz=\u001fQ1tr`\u001f,'\u000b*$\u000318t\"%\u0007)&\u000eq \u001a-[";
        objectArray[69] = "#\u0010H\u0013nIsPM\u0013\u0011k\u001a^G\b Eg\u0000\u0016\u001c|";
        objectArray[70] = "c\u0019\u0019\u0019^i3Y\u001c\u0019!uZS\u0001\r\\d$\u0014\u0016[Q";
        objectArray[71] = "\u0011\u00059=PuAE<=/p(Ma=ReW\u0015%!Oz(\u001d$%WdRN!8S\u0019";
        objectArray[72] = "\u00174_2Z'GtZ2% .|\u00072X7Q$C.E(.&AqO-OzEs]K";
        objectArray[73] = "\u001d3X'\nJMs]'u|$#Q7\u001e\u0017H)\r`\u001c";
        objectArray[74] = "\u0004N\u000f\u0002aVT\u000e\n\u0002\u001eA=[P\u0003o\u0004PA\u000fEn";
        objectArray[75] = "t\u0019\n%Qh$Y\u000f%.hMQR%Sx2\t\u00169NgM\u0001^dOu(U\r;M\u0004";
        objectArray[76] = "%kt8~^u+q8\u0001[q\u001axv?Sm\u007f,%`Q";
        objectArray[77] = "2q;z;@b1>zDh\u000bj5j5\u001c;8755";
        objectArray[78] = "Cj3Z%-\u0013*6ZZ\u001fz\u007f6Z6-\u000be6Fe";
        objectArray[79] = ":2\u000bj\u0007\u0013jr\u000ejx$\u0003\"\u0002z\u0013No(^-\u0011";
        objectArray[80] = " D\u000bs\u0002:gS\n$;4\u001d\u0003\u0018%\u0003&s\u0004\u0005iY]";
        objectArray[81] = "\u0003gjUG5S'oU8%:r5TIgWhj\u0012H";
        objectArray[82] = ">$23s\u0002nd73\f\u0007lU>}2\u000fv0j.m\r";
        objectArray[83] = "Cb17'\u007f\u0013\"47XSzzev9b\u001f.6);";
        objectArray[84] = "`{S|z=0;V|\u00058Y3\u000b|x-&kO`e2YkZln`5a\u0006;lQ";
        objectArray[85] = "bTah\u00143~\u001eehp \u0019U?}\r5f\r{a\u0010*\u0019\u00053<\u00118|Q`c\u0013I";
        objectArray[86] = "^[d-\u001d\u0018\u000e\u001ba-b6gC0l\u0003\u0005\u0002\u0017c3\u0001";
        objectArray[87] = "oV\\e\u0015\u000b0WK;u\u0001\nW\u001ci\u001e\u0018kS\u001c~\u001f";
        objectArray[88] = "Z;[q<,\n{^qC\fczFi\"*\u00186D|)";
        objectArray[89] = "H*_Vwf\u0017+H\b\u0017o-5IS-`]6\u001aXe\u0005";
        objectArray[90] = "\u0007lW\u0007)FW,R\u0007VD>$\u000f\u0007+VA|K\u001b6I>-J\u001f7@EaH\n<*";
        objectArray[91] = "\u0001\u001dQL($Q]TLW58\b\u000eM&vU\u0012Q\u000b'";
        objectArray[92] = "2Of\u001eyN5M0\u001f\u0018LYI7\u0003e[&\u0011s\u001fxDY@r\u001byM\"\fp\u000er'";
        objectArray[93] = "\u000eM\t|?T^\r\f|@I7\u0007\u0011h=YI@\u0006>0";
        objectArray[94] = ",\u0003f~g*|Cc~\u0018\u0000\u0015\u0018hniv%Jj1i";
        objectArray[95] = "MZf}mM\u001d\u001ac}\u0012Gt\u0012>}o]\u000bJzarBtB{ej\\\u000e\u0011~xn!";
        objectArray[96] = "X\u001d\u0004}v\u000e\b]\u0001}\t'aS\u000bf8\u0002\u001c\rZrd";
        objectArray[97] = "TXConx\u0004\u0018Fo\u0011Wm\u0019^wp~\u0016U\\b{";
        objectArray[98] = "'0#E{+!2dT\u00062\u0018<tFwk(nv\u0019w[r=pX6k ?/X\u0006dr2.I{:#&r)l0w'/\u0019>2('\u001fCm4if/\u0011okiVvQa#e,%T|'\u0018";
        objectArray[99] = "y neV\u001f)`ke)\t@h6eT\u000f?0ryI\u0010@8s}Q\u000e:kv`Us";
        objectArray[100] = "\b+3]\u001cZXk6]cw1</N\\\n_*7L\u0012";
        objectArray[101] = "\t \u00049B[Y`\u00019=[0h\\9@KO0\u0018%]T08\u0019!EJJk\u001c<A7";
        objectArray[102] = "j3,@\u001c`:s)@ciS{8Z\u001cs?+x_\u001c";
        objectArray[103] = "4g:3y}d'?3\u0006~\r/b3{mrw&/fr\r&'+g{vj%>l\u0011";
        objectArray[104] = "G\u0004\bSMC\u0017D\rS2J~LPSOS\u0001\u0014\u0014ORL~\u001c\u0015KJR\u0004O\u0010VN/";
        objectArray[105] = "2\u0019F\"T64\u001b\u00013)-\r\u0015\u0011!Xv=G\u0013~XF2\u0015\u001e\u007fI;lD\n#),f\u0010\u000b~\u0019~dO\u000bN@>j\u0007\u00074\u0013;w\u0003z";
        objectArray[106] = "JsK;\u0012w\u001a3N;mps;\u0013;\u0010g\fcW'\rxs2V#\fq\b~T6\u0007\u001b";
        objectArray[107] = "O\u0015$\u0002r(J\u000b|rdGI\u001e \u0000r|\u0018Q&\u0012\u000e";
        objectArray[108] = "r7\u000e6&\u0002\"w\u000b6Y\tK)R9&\u0016)8\u0004r'";
        objectArray[109] = "\u007fiZ\n7Eyk\u001d\u001bJ\\@?\u001e\u0001+_;s\u001c\u0014 5*d\t\u0017z\u0005xfV\u0017J\u00058h\u0007\f1I:}\ffs\fyd\u0017[$\fpj\nf ^/~VVr\\p~f\f!Z1?V^#\u00051\u000f\f\r%Dp?^\u000fzD@e\r\t;\u0005p7\u000fV;5pw\u0001\u0007 N<u\u0014\fJ\u00058h\u0007\f1I:}\ff#M'w\u001b\u001cpH:sf";
        objectArray[110] = "M\u0013\u0014s)\u0006\u0010\u0011\u0010p\u00131k\"'KOzM\u0013\u0014s)\u0006\u0010\u0011\u0010p";
        objectArray[111] = "'-y^1\u0001wm|^N \u001e5-\u001f/\u001c{a~@-";
        objectArray[112] = "0gYBxw`'\\B\u0007r\t,PX~p9v\u0004_9\u001b3zYDl+i.^\u0003\u0007";
        objectArray[113] = "\u000f\u001f?Vy\n__:V\u0006\u001e6\u0001cYy\u001eT\u00105\u0012x";
        objectArray[114] = "\n\u0018|q\u0003SZXyq|g3\nb2\u0016YRVf0\u0004";
        objectArray[115] = "\u000eK=AQ$^\u000b8A.%7\u0003eAS4H[!]N+7S YV5M\u0000%DRH";
        objectArray[116] = "YBn(Lb\t\u0002k(3t`\bv<No\u001eOajC";
        objectArray[117] = "pcIB\u0014# #LBk\u0013Is@R\u0000~%y\u001c\u0005\u0002";
        objectArray[118] = "horn6(8/wnI\u0003Q!}ux$,\u007f,a$";
        objectArray[119] = "W^\rAt$\u0007\u001e\bA\u000b$n\u0016UAv4\u0011N\u0011]k+n\u001f\u0010Yj\"\u0015S\u0012LaH";
        objectArray[120] = "\u0001@>/6,\u0007By>K5>Li,:l\u000e\u001eks:\\\u0001Lfr+!_\u001dr.K5FAz>1fC\\~C";
        objectArray[121] = "\u0001,Rh^KQlWh!@8d\nh\\[G<NtAD84OpYZBgJm]'";
        objectArray[122] = "R h\u0018$+T\"/\tY0mv,\u001381\u0016:.\u00063[R,0E9&\f}$\u0019Y2\u0015!,\t#a\u0010<(t";
        objectArray[123] = ">&w0\u007f\u0013nfr0\u0000\r\u0007lo$}\u001ey+xrp";
        objectArray[124] = "Vcy\u0004.$\u0006#|\u0004Q!o+!\u0004,4\u0010se\u00181+o{-E09\n/~\u001a2H";
        objectArray[125] = "0&`\u001dLR6$'\f1K\u000f*7\u001e@\u0012?x5A@\"r8'\u0016\f\\d*1I1Hd/-A\u0001\u001afp-q[I`1lA\tK?1\\H\u000bA6|e\u000f\u000fB`q\\AIEn*'\rKPe@6\u001a^S?pd\u0018\u0001S\u000f*7\u001e@\u0012?x5A@\"e+3\u0000\u0001\u00127)l\u00001\u0012w'=\u001bJ^u26qXZh8!\u000b\u000b_u<\\";
        objectArray[126] = "\\qkD\u0014:\f1nDk)e;sP\u00167\u001b|d\u0006\u001b";
        objectArray[127] = "\fYRN!\b\\\u0019WN^\n5\u0011\nN#\u0018JINR>\u00075AOV&\u0019O\u0012JK\"d";
        objectArray[128] = "cYjF$[3\u0019oF[jZ\u0017e]jW'I4I6";
        objectArray[129] = "W\u0015\u007f]vw\u0007Uz]\tbn]']tg\u0011\u0005cAixn\rbEqf\u0014^gXu\u001b";
        objectArray[130] = "+\u0000ic\u0013l-\u0002.rnv\u0014\f>`\u001f,$^<?\u001f\u001c~\r:~^,,\u000fe~nv\u007f\t$?^$}V$\u000f\u0004w{\u0017e?Vu$\u0017Ue\u0005seVe7\u0007,ef?d\u0001m$Vmf^m\u0014V-h\u000fvo\u001a/}\u0004\u001c+\f1>\u000eau]%bnul\u0001-r\u0014&i\u001c)\u000f";
        objectArray[131] = "-Yb\u0011o*}\u0019g\u0011\u0010/x(n_.'eM:\fq%";
        objectArray[132] = "\u0017Ts1[\u000f\u0011V4 &\u0016(\u00027:G\u0015SN5/L\u007f\u0017X+lF\u0002I\t?0&OPU.7]\u0003R@%]@\u0015J\b*-CFA@O4\u0017AIC*`D\u001eK2\u007f%A\u001eBI3'T\u0015(";
        objectArray[133] = "M$^XN0K&\u0019I3)r(\t[BpBz\u000b\u0004B@\u0018)\rE\u0003pJ+RE3*\u0019-\u0013\u0004\u0003x\u001br\u00134\u00038\u0015#\bOO:\u0000(b\u000bY$C\"\u001fU\b0\u001fB\u000bLT8\u000f8XII<r";
        objectArray[134] = "RIu\u0007CaTK2\u0016>xmL2WTw\f\u00106UF\u0011\u0007D&\u001a\u000e!UFy\u001a>.\u0007Kx\u000bCpV_$kTz\u0002^y[\u0006x]^I";
        objectArray[135] = "Jfes\u001e\u0014\u001a&`sa\u0001sx9|\u001e\u0000\u0011io7\u001f";
        objectArray[136] = "V\r;\u001e>:P\u000f|\u000fC$iTm\u0016r*\u0014\n<\u0002.J\u0000\u0013`\n>0S\u0016}\u000eC";
        objectArray[137] = "{\u0006\u001fA\u0019\u0018+F\u001aAf\u0019BNGA\u001b\b=\u0016\u0003]\u0006\u0017BG\u0002Y\u0007\u001e9\u000b\u0000L\ft";
        objectArray[138] = "\u0012A\tIP\bB\u0001\fI/-+\u000e\u0011\u000b\u0017\u001fE\t\fGM";
        objectArray[139] = "K\u000e=\u001cp\u001c\u001bN8\u001c\u000f\u0019rFe\u001cr\f\r\u001e!\u0000o\u0013r\u001c#_e\u0016\u0013@']wp";
        objectArray[140] = "|u`d\f\u0019,5eds\u001cE=8d\u000e\t:e|x\u0013\u0016Ennt\u0002Eu<l+\u0002u";
        objectArray[141] = "ua\n5/u%!\u000f5PSL}\u0017{=i/\u007f\u0010:5";
        objectArray[142] = "W\u0010Yj\u0017#\u0007P\\jh7nX\u0001j\u00153\u0011\u0000Ev\b,n\bDr\u00102\u0014[Ao\u0014O";
        objectArray[143] = "!\fN\rj\u0015qLK\r\u00156\u0018\u0014\u001aLt\b}@I\u0013v";
        objectArray[144] = "B>\u0011Ecq\u001d?\u0006\u001b\u0003~'.\\\u001cbcBz\u000fC`\u0012";
        objectArray[145] = "G{Z\u0007\u0012FAy\u001d\u0016o_xw\r\u0004\u001e\u0006H%\u000f[\u001e6\u0012v\t\u001a_\u0006@tV\u001ao\\\u0013r\u0017[_\u000e\u0011-\u0017k\u0005]\u0017lV[W_Hlf\u0001\u0004Y\t-VS\u0006\u0006\t\u001dV\u0013\bW\u0012f\u001a\u0011\u001d\\x\"\f\u000f^V\u0005|]\u001b\u00026\u0011e\u0001\u0013\u0012LB`\u001c\u0017o";
        objectArray[146] = "(\u001fyx\u0000<o\bx/92\u0015Xj.\u0001 {_wb[[|\u001epkD!/\u001bmo9";
        objectArray[147] = "kXM\u000f9\u00024YZQY\u0005\u000e\u0018\f\u0017$\u001dq@H\u000b9\u0002\u000eHI\u000f!\u001ct\u001bL\u0012%a";
        objectArray[148] = "b\rTSM62MQS2$[\u0013\b\\M\"9\u0002^\u0017L";
        Object[] objectArray2 = objectArray;
        objectArray[149] = "\u0011A*\u0001H`A\u0001/\u00017j(_v\u000eHtJN EI";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = SpotiPlayer.e(l2, l3);
            object = pb[n2];
            try {
                if (!(object instanceof String)) break block2;
                SpotiPlayer.pb[n2] = clazz = Class.forName(sb[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = SpotiPlayer.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = SpotiPlayer.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = SpotiPlayer.e(l2, l3);
        Object object = pb[n2];
        if (object instanceof String) {
            String string = sb[n2];
            int n3 = string.indexOf(8);
            Class clazz = SpotiPlayer.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = SpotiPlayer.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = SpotiPlayer.c(clazz3, string2, clazz2)) != null) {
                    SpotiPlayer.pb[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = SpotiPlayer.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        SpotiPlayer.pb[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = SpotiPlayer.f(694386576371755L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = SpotiPlayer.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = SpotiPlayer.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = SpotiPlayer.e(l2, l3);
        Object object = pb[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = sb[n2];
                int n4 = string2.indexOf(8);
                clazz3 = SpotiPlayer.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = SpotiPlayer.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = SpotiPlayer.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        SpotiPlayer.pb[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = SpotiPlayer.f(694386576371755L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = SpotiPlayer.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        SpotiPlayer.pb[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = SpotiPlayer.f(694386576371755L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == '\u00e5' || c2 == '\u00dd' || c2 == '\u00ec' || c2 == '\u00d4') {
                field = SpotiPlayer.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == '\u00e5' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == '\u00dd' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == '\u00ec' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = SpotiPlayer.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == 'X' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == '\u00c6' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = SpotiPlayer.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite f(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_3().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/b/o" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(SpotiPlayer.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(SpotiPlayer.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_2() {
        try {
            return MethodHandles.lookup().findStatic(SpotiPlayer.class, "d", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_3() {
        try {
            return MethodHandles.lookup().findStatic(SpotiPlayer.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

