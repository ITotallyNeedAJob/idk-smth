// === Kuzi module: SelfDestruct ===
// Category   : CLIENT
// Description: Wipes the client from memory, cleans the log and swaps the jar for a decoy.
// Payload    : a.a.a.j.e.ac (verified: True)

package kuzi.modules.client;

import java.io.BufferedInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributeView;
import java.nio.file.attribute.BasicFileAttributes;
import java.security.Key;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.core.Client;
import kuzi.mixin.MixinExposed;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.b.v;
import kuzi.obf.j.e.am;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.StringSetting;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.Minecraft;

public class SelfDestruct
extends BaseModule {
    private final BoolSetting scrambleMemory;
    private final BoolSetting cleanLogs;
    private final BoolSetting replaceJar;
    private final StringSetting uRL;
    private static final long q;
    private static final String[] r;
    private static final String[] s;
    private static final Map t;
    private static final long[] u;
    private static final Integer[] v;
    private static final Map w;
    private static final long x;
    private static final Object[] y;
    private static final String[] z;

    public SelfDestruct() {
        long l2 = q ^ 0x3BB39BFCCBF0L;
        long l3 = l2 ^ 0x73EFE2160B2AL;
        super("SelfDestruct", "Wipes the client from memory, cleans the log and swaps the jar for a decoy.", Category.CLIENT);
        this.scrambleMemory = new BoolSetting("Scramble Memory", true);
        this.cleanLogs = new BoolSetting("Clean Logs", true);
        this.replaceJar = new BoolSetting("Replace Jar", true);
        this.uRL = new StringSetting("URL", "https://cdn.modrinth.com/data/lIQY64qr/versions/vMOQpnf6/tiptapshow-1.6.7%2B1.21.11.jar");
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.scrambleMemory, this.cleanLogs, this.replaceJar, this.uRL};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        long l2 = q ^ 0x232CEE1FC02L;
        long l3 = l2 ^ 0x76B62CBC0F21L;
        int n2 = (int)(l3 >>> 32);
        int n3 = (int)(l3 << 32 >>> 48);
        int n4 = (int)(l3 << 48 >>> 48);
        BaseModule.a.execute(() -> SelfDestruct.lambda$onEnable$0(n2, (short)n3, n4));
        Thread thread = new Thread(this::a, "Kuzi-SelfDestruct");
        thread.setDaemon(true);
        thread.start();
        this.i(false);
    }

    @MixinExposed
    public void a() {
        block6: {
            SelfDestruct selfDestruct;
            long l2;
            block5: {
                boolean settingEnabled;
                block4: {
                    long l3;
                    long l4 = l3 = q ^ 0x3C953577B01DL;
                    long l5 = l4 ^ 0x78B9648723EBL;
                    long l6 = l4 ^ 0x362B9AAD28B6L;
                    l2 = l4 ^ 0x4C1276F69DF5L;
                    String string = am.b();
                    Object[] objectArray = new Object[1];
                    objectArray[0] = l6;
                    this.disableOtherModules(objectArray);
                    String string2 = string;
                    settingEnabled = (Boolean)this.cleanLogs.a();
                    if (string2 == null) break block4;
                    if (settingEnabled) {
                        Object[] objectArray2 = new Object[1];
                        objectArray2[0] = l5;
                        this.cleanLogFile(objectArray2);
                    }
                    selfDestruct = this;
                    if (string2 == null) break block5;
                    settingEnabled = (Boolean)selfDestruct.o.a();
                }
                if (!settingEnabled) break block6;
                selfDestruct = this;
            }
            Object[] objectArray = new Object[1];
            objectArray[0] = l2;
            selfDestruct.replaceJarFromUrl(objectArray);
        }
    }

    /*
     * Unable to fully structure code
     */
    private void disableOtherModules(Object[] var1_1) {
        block18: {
            block17: {
                block13: {
                    var2_2 = (Long)var1_1[0];
                    var4_3 = (var2_2 = SelfDestruct.q ^ var2_2) ^ 90093195011275L;
                    var6_4 = am.b();
                    if (Client.a() == null) {
                        return;
                    }
                    modules = new ArrayList<E>(Client.a().a());
                    for (BaseModule otherModule : modules) {
                        block16: {
                            v0 = otherModule;
                            if (var2_2 <= 0L || var2_2 < 0L || var6_4 == null) break block13;
                            if (var6_4 == null) ** GOTO lbl26
                            if (var2_2 <= 0L) ** GOTO lbl18
                            if (v0 == this) continue;
                            try {
                                block15: {
                                    block14: {
                                        try {
                                            v1 = otherModule;
lbl18:
                                            // 2 sources

                                            v1.i(false);
                                            v2 = this;
                                            if (var2_2 < 0L) break block14;
                                            if (var6_4 == null) break block15;
                                            v2 = v2.m.a();
                                        }
                                        catch (Throwable v3) {
                                            throw SelfDestruct.a(v3);
                                        }
                                    }
                                    try {
                                        if (!((Boolean)v2).booleanValue()) break block16;
                                        v4 = otherModule;
                                    }
                                    catch (Throwable v5) {
                                        throw SelfDestruct.a(v5);
                                    }
                                }
                                v6 = new Object[1];
                                v6[0] = var4_3;
                                v4.k(v6);
                            }
                            catch (Throwable var10_10) {
                                // empty catch block
                            }
                        }
                        if (var6_4 != null) continue;
                    }
                    v0 = this.scrambleMemory.a();
                }
                v7 = ((Boolean)v0).booleanValue();
                if (var6_4 == null) break block17;
                if (v7 == 0) break block18;
                v7 = gcPass = 0;
            }
            block9: while (gcPass < 3) {
                System.gc();
                try {
                    Thread.sleep(SelfDestruct.x);
                }
                catch (InterruptedException var9_9) {
                    Thread.currentThread().interrupt();
                    v8 = var6_4;
                    if (var2_2 >= 0L) {
                        if (v8 != null) break;
                    }
                    ** GOTO lbl64
                }
                do {
                    ++gcPass;
                    v8 = var6_4;
lbl64:
                    // 2 sources

                    if (v8 != null) continue block9;
                } while (var2_2 < 0L);
                break;
            }
        }
    }

    /*
     * Unable to fully structure code
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private void cleanLogFile(Object[] var1_1) {
        var2_2 = (Long)var1_1[0];
        var2_2 = SelfDestruct.q ^ var2_2;
        var4_3 = am.b();
        try {
            block18: {
                block19: {
                    logPath = FabricLoader.getInstance().getGameDir().resolve((String)SelfDestruct.b("k", (int)7648, (long)(2855801123379779913L ^ var2_2))).resolve((String)SelfDestruct.b("k", (int)28397, (long)(1079087756724824641L ^ var2_2)));
                    try {
                        v0 = Files.isRegularFile(logPath, new LinkOption[0]);
                        if (var4_3 == null) break block18;
                        if (v0 != 0) break block19;
                        return;
                    }
                    catch (Throwable v1) {
                        throw SelfDestruct.a(v1);
                    }
                }
                v0 = 2;
            }
            v2 = new String[v0];
            v2[0] = SelfDestruct.b("k", (int)4769, (long)(1164107393163105807L ^ var2_2));
            v2[1] = SelfDestruct.b("k", (int)8978, (long)(5737198065342162877L ^ var2_2));
            filterKeywords = v2;
            keptLines = new ArrayList<String>();
            for (String line : Files.readAllLines(logPath)) {
                block23: {
                    block22: {
                        lowerLine = line.toLowerCase();
                        matchedKeyword = false;
                        keywords = filterKeywords;
                        keywordCount = keywords.length;
                        if (var4_3 == null) return;
                        keywordIndex = 0;
                        while (keywordIndex < keywordCount) {
                            block20: {
                                block21: {
                                    keyword = keywords[keywordIndex];
                                    v3 = var4_3;
                                    if (var2_2 <= 0L) break block20;
                                    if (v3 == null) break block21;
                                    try {
                                        block24: {
                                            v4 = lowerLine.contains(keyword);
                                            v5 = var4_3;
                                            if (var2_2 <= 0L) ** GOTO lbl67
                                            if (v5 == null) break block22;
                                            break block24;
                                            catch (Throwable v6) {
                                                throw SelfDestruct.a(v6);
                                            }
                                        }
                                        if (v4) {
                                        }
                                        ** GOTO lbl54
                                    }
                                    catch (Throwable v7) {
                                        throw SelfDestruct.a(v7);
                                    }
                                    matchedKeyword = true;
                                    try {
                                        if (var2_2 > 0L) {
                                            if (var4_3 != null) break;
                                        }
                                        break block21;
lbl54:
                                        // 2 sources

                                        ++keywordIndex;
                                    }
                                    catch (Throwable v8) {
                                        throw SelfDestruct.a(v8);
                                    }
                                }
                                v3 = var4_3;
                            }
                            if (v3 != null) continue;
                        }
                        if (var2_2 <= 0L) break block23;
                        v4 = matchedKeyword;
                    }
                    v5 = var4_3;
lbl67:
                    // 2 sources

                    if (v5 == null) break block23;
                    try {
                        block25: {
                            if (v4) break block23;
                            break block25;
                            catch (Throwable v9) {
                                throw SelfDestruct.a(v9);
                            }
                        }
                        v4 = keptLines.add(line);
                    }
                    catch (Throwable v10) {
                        throw SelfDestruct.a(v10);
                    }
                }
                if (var4_3 != null) continue;
            }
            Files.write(logPath, keptLines, new OpenOption[0]);
            if (var2_2 < 0L) return;
        }
        catch (Throwable var5_5) {
            // empty catch block
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Loose catch block
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private void replaceJarFromUrl(Object[] objectArray) {
        String url;
        String downloadUrl;
        CallSite flowCheck;
        CallSite jarPath;
        long l2;
        block28: {
            CallSite urlResult;
            block26: {
                block27: {
                    l2 = (Long)objectArray[0];
                    long l3 = (l2 = q ^ l2) ^ 0x6C3B0D19728CL;
                    Object[] objectArray2 = new Object[1];
                    objectArray2[0] = l3;
                    jarPath = SelfDestruct.d("s", (Object)this, (Object)objectArray2, (long)3305682701986259118L, (long)l2);
                    flowCheck = SelfDestruct.d("\u00f8", (long)3309364998901963486L, (long)l2);
                    try {
                        urlResult = jarPath;
                        if (flowCheck == null) break block26;
                        if (urlResult != null) break block27;
                        return;
                    }
                    catch (Throwable throwable) {
                        throw SelfDestruct.d("\u00f8", (Object)throwable, (long)3309552825046772977L, (long)l2);
                    }
                }
                urlResult = SelfDestruct.d("s", (Object)SelfDestruct.d("Y", (Object)this, (long)3309452948358638572L, (long)l2), (long)3310103271134844524L, (long)l2);
            }
            downloadUrl = (String)((Object)urlResult);
            try {
                url = downloadUrl;
                if (l2 <= 0L || flowCheck == null) break block28;
                if (url == null) return;
            }
            catch (Throwable throwable) {
                throw SelfDestruct.d("\u00f8", (Object)throwable, (long)3309552825046772977L, (long)l2);
            }
            url = downloadUrl;
        }
        try {
            if (url.isBlank()) {
                return;
            }
        }
        catch (Throwable throwable) {
            throw SelfDestruct.d("\u00f8", (Object)throwable, (long)3309552825046772977L, (long)l2);
        }
        try {
            HttpURLConnection httpURLConnection;
            BasicFileAttributes basicFileAttributes;
            block29: {
                HttpURLConnection httpURLConnection2;
                block31: {
                    basicFileAttributes = Files.readAttributes((Path)((Object)jarPath), BasicFileAttributes.class, new LinkOption[0]);
                    httpURLConnection = (HttpURLConnection)URI.create(downloadUrl).toURL().openConnection();
                    httpURLConnection.setRequestMethod((String)((Object)SelfDestruct.b("k", (int)20088, (long)(0x7ABD8C36D54A74D1L ^ l2))));
                    httpURLConnection.setInstanceFollowRedirects(true);
                    httpURLConnection.setConnectTimeout((int)SelfDestruct.c("k", (int)30982, (long)(0x59BA39B1A8B79D6AL ^ l2)));
                    httpURLConnection.setReadTimeout((int)SelfDestruct.c("k", (int)25952, (long)(0x79E6A2691CCF010DL ^ l2)));
                    httpURLConnection.setRequestProperty((String)((Object)SelfDestruct.b("k", (int)27404, (long)(0x2101A078BA7051BFL ^ l2))), (String)((Object)SelfDestruct.b("k", (int)276, (long)(0xAC3FE15C1653BA8L ^ l2))));
                    if (l2 < 0L) return;
                    httpURLConnection2 = httpURLConnection;
                    if (flowCheck == null) break block31;
                    try {
                        block32: {
                            if (httpURLConnection2.getResponseCode() == SelfDestruct.c("k", (int)1573, (long)(0x84F3B31559DE24BL ^ l2))) break block29;
                            break block32;
                            catch (Throwable throwable) {
                                throw SelfDestruct.d("\u00f8", (Object)throwable, (long)3309552825046772977L, (long)l2);
                            }
                        }
                        httpURLConnection2 = httpURLConnection;
                    }
                    catch (Throwable throwable) {
                        throw SelfDestruct.d("\u00f8", (Object)throwable, (long)3309552825046772977L, (long)l2);
                    }
                }
                httpURLConnection2.disconnect();
                return;
            }
            try (BufferedInputStream bufferedInputStream = new BufferedInputStream(httpURLConnection.getInputStream());
                 FileOutputStream fileOutputStream = new FileOutputStream(jarPath.toFile());){
                ((InputStream)bufferedInputStream).transferTo(fileOutputStream);
            }
            finally {
                httpURLConnection.disconnect();
            }
            Files.getFileAttributeView((Path)((Object)jarPath), BasicFileAttributeView.class, new LinkOption[0]).setTimes(basicFileAttributes.lastModifiedTime(), basicFileAttributes.lastAccessTime(), basicFileAttributes.creationTime());
            return;
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private static void lambda$onEnable$0(int n2, short s2, int n3) {
        block3: {
            Minecraft minecraft;
            block2: {
                long l2 = ((long)n2 << 32 | (long)s2 << 48 >>> 32 | (long)n3 << 48 >>> 48) ^ q;
                String string = am.b();
                minecraft = BaseModule.a;
                if (string == null) break block2;
                if (minecraft.screen == null) break block3;
                minecraft = BaseModule.a;
            }
            minecraft.setScreen(null);
        }
    }

    /*
     * Unable to fully structure code
     */
    static {
        block19: {
            block18: {
                block17: {
                    block16: {
                        block15: {
                            SelfDestruct.q = kuzi.obf.h.b.v.a(-5860253686552988808L, -2645890438286131123L, MethodHandles.lookup().lookupClass()).a(250869807796933L);
                            SelfDestruct.y = new Object[36];
                            SelfDestruct.z = new String[36];
                            SelfDestruct.c();
                            SelfDestruct.t = new HashMap<K, V>(13);
                            var16 = SelfDestruct.q ^ 71256145712669L;
                            var18_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                            v0 = SecretKeyFactory.getInstance("DES");
                            v1 = new byte[8];
                            v2 = v1;
                            v1[0] = (byte)(var16 >>> 56);
                            for (var19_2 = 1; var19_2 < 8; ++var19_2) {
                                v2 = v2;
                                v2[var19_2] = (byte)(var16 << var19_2 * 8 >>> 56);
                            }
                            var18_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                            var25_3 = new String[17];
                            var23_4 = 0;
                            var22_5 = "u]RHE\u0004\u00d5\u00fb\u00c4\u00b27\u0091\u0018p\u00c7O\u0018\u0093\u0095Z\u0006,\u007f\u00f3\u0019\u0005\u00fe\u0082Iv\u00e4\u001b}\u00af\u00b4$\u0006}\u00a5\u00a1\u00c5 \u001f\u0092{\u00efx<\u0094\u00d5'\u0094L\u00a0\u0094\u0000\u00b4\u00fay\u00b8x\u001d\u00b4\u00ce\u00c0\u00b6\u0015'j\u00f0<\u00ab\u00a4B\u0010\u00b1\u00af\u0015\u00e8\u00f7\u009e%:\u00e3\u00c7\u00f6e\u00c6\u0004\u009e\u00af \u00db\u00b2\u00fbl\u0096\u00b9~\u009dj#\u00d5\u00a7\u00e1\b\r\u009dFsO\u00e4\u00c8\u00dd\u0019*\u00a0[-\u00b4\u0080\u00a4\u001d\u00e9 \u00a7\u00ecu\u0014\u00ba\u00efu\u0094\u00db\u00e4e\u00f3~\u0004\u00c0*\u00a4\u00f8\u00b7\u00cd\u00fbc\u0091\u009e\u0000b?\u00cc+\"\u0099\u00bf\u0090\n\u00f1\u00fc]\u00d6\\\u0010\u0088\u00d9v\u009fg\u0098\u0083\u00e0\u00f4\u00bcI\u00e3+\u00c9\u00f0~\u009f#;8\u0010U\u00ef\u0015\u008eS\u00ba\u009c\u00eb\u00bbQ\u00fa\u0014\u0099\u00b7\u0097H\u0082g\u00b5\u00f2q\u00da\u00d5h\u00c2dh\u000e\u00b2)\u000f\u00c2\u00c3\u00f6\u0017EH\u00e9\u00e1\u00e6\u00b11\n\u0098\u00c5\u00e3\u0017I\u00b8\u00bb\u00cd\u0091\u009eJ^\u0083J\b\u0089~\u00ca\u00e9\u000b'4\u00f9jP\u00a3L\u00a9\u00dc\u00be\u00aa\u00d9\u0015\u008f\u0012\u00f7\u00eb\fp\u009bnN\u00be}[h\u0084KJ\u000b\u00c1TSD\u001b=ZP*N\u00e9\u0091\u00f8\u00cd\u00e6\u00b8\u00f1\u00c1\u00b4V\u00da\u001b\u00de {\u00f1\u00a9\u00dei\u0091\u00f5\u00d2\u00b9\u00c5\u00f9\u00e3\u0006o\u00ca\u00e8E}\u00d2@3\u00b7\u00a2gI?\u0014\u00ba\u00db\u0094\u0087\u00b3\u0010\u008f\u008c\u00a8\t\u00e8p\u00e7t\u001a\u00c9p1\u0017\u00b7G\u00fd\u0010s\n\u00c0l>A]\u0006\u009ap]\u00e9\u00dex\u0096\u00e1\u0018\u00c3\u009ePw+[~\u00d3\u00e2\n\u00b0^\u0010!,bB\u00cd\u00c9\u0005<P\\\u00de \u009b\t\u00d1\u00fa+\u0017\u00d0\u000fJ\u0019\u00a9P\u00ec\u009d\u00d4\u000f\u00ac\u009b6A3\u000b<d\u00e9\u00d5Q~\u00f5_\u001d\u00a8\u00103n\u000f@\u0016\u0086\u009c\u001a\u0011\u0012_\u00a7:Vt:x\u0013\u00fd\u00c0\nM\u008d\u00ef\u00a9R\u001d\u00da\u0004\r\u00e9\u00ac\u00a2\u00a4\u008f\u009bfE>\u00e8\u00dcIt\u00a1\u008d\u00d8\u00d9\u00cf\u00b39\u00ef&B<\u00f4\u000b\u00c1\u008b\u00a5\u000f!\u00d1+\u00919\u00a5T`\u001f4\u00fb\u0012\u00d3$\u009d+h)\u00d0\u009c\u00dd2\u0081\u00a3%\u009bb\u00f9<\u0010\u00d1\u0098g\u0099\u0017\u00d8\u00c0j,\u00e8\u00189&\u0012\u00b6#n\u0086\u00a5\u0005\u00c8d\u0013\u00a3\u001a(\u0097^\u00ec\u00de\u0006\u0095\u0098\u00c3\u00d4\u008d\u00f6\u00aco\u00985\u00df6[\u00e0\u0005\u00e5\u0010\u0004\u00b5j\u00ab\u008e\u00a4P\u0096\u00b7\u00f4\u00ae\u00d4\u0005=\u00faZ";
                            var24_6 = "u]RHE\u0004\u00d5\u00fb\u00c4\u00b27\u0091\u0018p\u00c7O\u0018\u0093\u0095Z\u0006,\u007f\u00f3\u0019\u0005\u00fe\u0082Iv\u00e4\u001b}\u00af\u00b4$\u0006}\u00a5\u00a1\u00c5 \u001f\u0092{\u00efx<\u0094\u00d5'\u0094L\u00a0\u0094\u0000\u00b4\u00fay\u00b8x\u001d\u00b4\u00ce\u00c0\u00b6\u0015'j\u00f0<\u00ab\u00a4B\u0010\u00b1\u00af\u0015\u00e8\u00f7\u009e%:\u00e3\u00c7\u00f6e\u00c6\u0004\u009e\u00af \u00db\u00b2\u00fbl\u0096\u00b9~\u009dj#\u00d5\u00a7\u00e1\b\r\u009dFsO\u00e4\u00c8\u00dd\u0019*\u00a0[-\u00b4\u0080\u00a4\u001d\u00e9 \u00a7\u00ecu\u0014\u00ba\u00efu\u0094\u00db\u00e4e\u00f3~\u0004\u00c0*\u00a4\u00f8\u00b7\u00cd\u00fbc\u0091\u009e\u0000b?\u00cc+\"\u0099\u00bf\u0090\n\u00f1\u00fc]\u00d6\\\u0010\u0088\u00d9v\u009fg\u0098\u0083\u00e0\u00f4\u00bcI\u00e3+\u00c9\u00f0~\u009f#;8\u0010U\u00ef\u0015\u008eS\u00ba\u009c\u00eb\u00bbQ\u00fa\u0014\u0099\u00b7\u0097H\u0082g\u00b5\u00f2q\u00da\u00d5h\u00c2dh\u000e\u00b2)\u000f\u00c2\u00c3\u00f6\u0017EH\u00e9\u00e1\u00e6\u00b11\n\u0098\u00c5\u00e3\u0017I\u00b8\u00bb\u00cd\u0091\u009eJ^\u0083J\b\u0089~\u00ca\u00e9\u000b'4\u00f9jP\u00a3L\u00a9\u00dc\u00be\u00aa\u00d9\u0015\u008f\u0012\u00f7\u00eb\fp\u009bnN\u00be}[h\u0084KJ\u000b\u00c1TSD\u001b=ZP*N\u00e9\u0091\u00f8\u00cd\u00e6\u00b8\u00f1\u00c1\u00b4V\u00da\u001b\u00de {\u00f1\u00a9\u00dei\u0091\u00f5\u00d2\u00b9\u00c5\u00f9\u00e3\u0006o\u00ca\u00e8E}\u00d2@3\u00b7\u00a2gI?\u0014\u00ba\u00db\u0094\u0087\u00b3\u0010\u008f\u008c\u00a8\t\u00e8p\u00e7t\u001a\u00c9p1\u0017\u00b7G\u00fd\u0010s\n\u00c0l>A]\u0006\u009ap]\u00e9\u00dex\u0096\u00e1\u0018\u00c3\u009ePw+[~\u00d3\u00e2\n\u00b0^\u0010!,bB\u00cd\u00c9\u0005<P\\\u00de \u009b\t\u00d1\u00fa+\u0017\u00d0\u000fJ\u0019\u00a9P\u00ec\u009d\u00d4\u000f\u00ac\u009b6A3\u000b<d\u00e9\u00d5Q~\u00f5_\u001d\u00a8\u00103n\u000f@\u0016\u0086\u009c\u001a\u0011\u0012_\u00a7:Vt:x\u0013\u00fd\u00c0\nM\u008d\u00ef\u00a9R\u001d\u00da\u0004\r\u00e9\u00ac\u00a2\u00a4\u008f\u009bfE>\u00e8\u00dcIt\u00a1\u008d\u00d8\u00d9\u00cf\u00b39\u00ef&B<\u00f4\u000b\u00c1\u008b\u00a5\u000f!\u00d1+\u00919\u00a5T`\u001f4\u00fb\u0012\u00d3$\u009d+h)\u00d0\u009c\u00dd2\u0081\u00a3%\u009bb\u00f9<\u0010\u00d1\u0098g\u0099\u0017\u00d8\u00c0j,\u00e8\u00189&\u0012\u00b6#n\u0086\u00a5\u0005\u00c8d\u0013\u00a3\u001a(\u0097^\u00ec\u00de\u0006\u0095\u0098\u00c3\u00d4\u008d\u00f6\u00aco\u00985\u00df6[\u00e0\u0005\u00e5\u0010\u0004\u00b5j\u00ab\u008e\u00a4P\u0096\u00b7\u00f4\u00ae\u00d4\u0005=\u00faZ".length();
                            var21_7 = 16;
                            var20_8 = -1;
lbl23:
                            // 2 sources

                            while (true) {
                                v3 = ++var20_8;
                                v4 = var22_5.substring(v3, v3 + var21_7);
                                v5 = -1;
                                break block15;
                                break;
                            }
lbl28:
                            // 1 sources

                            while (true) {
                                var25_3[var23_4++] = SelfDestruct.b(var26_9).intern();
                                if ((var20_8 += var21_7) < var24_6) {
                                    var21_7 = var22_5.charAt(var20_8);
                                    ** continue;
                                }
                                var22_5 = "k~y\u00b1J\u0014\u00ab\u00c0\u001c\u0005u\u00d9\u00065\u00196\r\u00ced\u008dQ\u00fa\u0099\u00ea\u009fq~\u00b4~$6V5rS\u00a6\u00fe\"\u00ae]\u0010\u0001Q\u0090\u0013vP\u009f\u001a\u00cd\u00dc\u00ech0\u0096\u001a\u0083";
                                var24_6 = "k~y\u00b1J\u0014\u00ab\u00c0\u001c\u0005u\u00d9\u00065\u00196\r\u00ced\u008dQ\u00fa\u0099\u00ea\u009fq~\u00b4~$6V5rS\u00a6\u00fe\"\u00ae]\u0010\u0001Q\u0090\u0013vP\u009f\u001a\u00cd\u00dc\u00ech0\u0096\u001a\u0083".length();
                                var21_7 = 40;
                                var20_8 = -1;
lbl37:
                                // 2 sources

                                while (true) {
                                    v6 = ++var20_8;
                                    v4 = var22_5.substring(v6, v6 + var21_7);
                                    v5 = 0;
                                    break block15;
                                    break;
                                }
                                break;
                            }
lbl42:
                            // 1 sources

                            while (true) {
                                var25_3[var23_4++] = SelfDestruct.b(var26_9).intern();
                                if ((var20_8 += var21_7) < var24_6) {
                                    var21_7 = var22_5.charAt(var20_8);
                                    ** continue;
                                }
                                break block16;
                                break;
                            }
                        }
                        var26_9 = var18_1.doFinal(v4.getBytes("ISO-8859-1"));
                        switch (v5) {
                            default: {
                                ** continue;
                            }
                            ** case 0:
lbl54:
                            // 1 sources

                            ** continue;
                        }
                    }
                    SelfDestruct.r = var25_3;
                    SelfDestruct.s = new String[17];
                    SelfDestruct.w = new HashMap<K, V>(13);
                    var5_10 = Cipher.getInstance("DES/CBC/NoPadding");
                    v7 = SecretKeyFactory.getInstance("DES");
                    v8 = new byte[8];
                    v9 = v8;
                    v8[0] = (byte)(var16 >>> 56);
                    for (var6_11 = 1; var6_11 < 8; ++var6_11) {
                        v9 = v9;
                        v9[var6_11] = (byte)(var16 << var6_11 * 8 >>> 56);
                    }
                    var5_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                    var11_12 = new long[3];
                    var8_13 = 0;
                    var9_14 = "n\u00a6\u0015!\u00ebQ\u0094\u0000\u00a8z\u00e6\u00ef\u00b4\u0091\u00e4\u0087.\u008eT\u0093C\u0080\u001b\u00bc";
                    var10_15 = "n\u00a6\u0015!\u00ebQ\u0094\u0000\u00a8z\u00e6\u00ef\u00b4\u0091\u00e4\u0087.\u008eT\u0093C\u0080\u001b\u00bc".length();
                    var7_16 = 0;
                    while (true) {
                        break block17;
                        break;
                    }
lbl76:
                    // 1 sources

                    while (true) {
                        var11_12[v10] = ((long)var15_19[0] & 255L) << 56 | ((long)var15_19[1] & 255L) << 48 | ((long)var15_19[2] & 255L) << 40 | ((long)var15_19[3] & 255L) << 32 | ((long)var15_19[4] & 255L) << 24 | ((long)var15_19[5] & 255L) << 16 | ((long)var15_19[6] & 255L) << 8 | (long)var15_19[7] & 255L;
                        if (var7_16 < var10_15) ** continue;
                        break block18;
                        break;
                    }
                }
                var12_17 = var9_14.substring(var7_16, var7_16 += 8).getBytes("ISO-8859-1");
                v10 = var8_13++;
                var13_18 = ((long)var12_17[0] & 255L) << 56 | ((long)var12_17[1] & 255L) << 48 | ((long)var12_17[2] & 255L) << 40 | ((long)var12_17[3] & 255L) << 32 | ((long)var12_17[4] & 255L) << 24 | ((long)var12_17[5] & 255L) << 16 | ((long)var12_17[6] & 255L) << 8 | (long)var12_17[7] & 255L;
                var15_19 = var5_10.doFinal(new byte[]{(byte)(var13_18 >>> 56), (byte)(var13_18 >>> 48), (byte)(var13_18 >>> 40), (byte)(var13_18 >>> 32), (byte)(var13_18 >>> 24), (byte)(var13_18 >>> 16), (byte)(var13_18 >>> 8), (byte)var13_18});
                ** while (true)
            }
            SelfDestruct.u = var11_12;
            SelfDestruct.v = new Integer[3];
            var0_20 = Cipher.getInstance("DES/CBC/NoPadding");
            v11 = SecretKeyFactory.getInstance("DES");
            v12 = new byte[8];
            v13 = v12;
            v12[0] = (byte)(var16 >>> 56);
            for (var1_21 = 1; var1_21 < 8; ++var1_21) {
                v13 = v13;
                v13[var1_21] = (byte)(var16 << var1_21 * 8 >>> 56);
            }
            break block19;
lbl102:
            // 1 sources

            while (true) {
                continue;
                break;
            }
        }
        var0_20.init(2, (Key)v11.generateSecret(new DESKeySpec(v13)), new IvParameterSpec(new byte[8]));
        var2_22 = -5476440159420606449L;
        var4_23 = var0_20.doFinal(new byte[]{(byte)(var2_22 >>> 56), (byte)(var2_22 >>> 48), (byte)(var2_22 >>> 40), (byte)(var2_22 >>> 32), (byte)(var2_22 >>> 24), (byte)(var2_22 >>> 16), (byte)(var2_22 >>> 8), (byte)var2_22});
        ** while (true)
        SelfDestruct.x = ((long)var4_23[0] & 255L) << 56 | ((long)var4_23[1] & 255L) << 48 | ((long)var4_23[2] & 255L) << 40 | ((long)var4_23[3] & 255L) << 32 | ((long)var4_23[4] & 255L) << 24 | ((long)var4_23[5] & 255L) << 16 | ((long)var4_23[6] & 255L) << 8 | (long)var4_23[7] & 255L;
    }

    private static Throwable a(Throwable throwable) {
        return throwable;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static String b(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x1751;
        if (s[n3] == null) {
            Object[] objectArray;
            try {
                Long l3 = Thread.currentThread().threadId();
                objectArray = (Object[])t.get(l3);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    t.put(l3, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/e/ac", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l2 >>> 56);
            for (int i2 = 1; i2 < 8; ++i2) {
                byArray[i2] = (byte)(l2 << i2 * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = r[n3].getBytes("ISO-8859-1");
            SelfDestruct.s[n3] = SelfDestruct.b(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return s[n3];
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        String string2 = SelfDestruct.b(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static CallSite b(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/e/ac" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x4984;
        if (v[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = u[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])w.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    w.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/e/ac", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            SelfDestruct.v[n3] = n4;
        }
        return v[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = SelfDestruct.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/e/ac" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (z[n4] != null) {
            return n4;
        }
        Object object = y[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 5;
            case 1 -> 41;
            case 2 -> 12;
            case 3 -> 2;
            case 4 -> 59;
            case 5 -> 63;
            case 6 -> 56;
            case 7 -> 62;
            case 8 -> 23;
            case 9 -> 39;
            case 10 -> 29;
            case 11 -> 9;
            case 12 -> 13;
            case 13 -> 22;
            case 14 -> 10;
            case 15 -> 60;
            case 16 -> 50;
            case 17 -> 45;
            case 18 -> 42;
            case 19 -> 18;
            case 20 -> 58;
            case 21 -> 28;
            case 22 -> 24;
            case 23 -> 44;
            case 24 -> 52;
            case 25 -> 27;
            case 26 -> 8;
            case 27 -> 47;
            case 28 -> 54;
            case 29 -> 49;
            case 30 -> 37;
            case 31 -> 46;
            case 32 -> 36;
            case 33 -> 25;
            case 34 -> 35;
            case 35 -> 26;
            case 36 -> 15;
            case 37 -> 11;
            case 38 -> 19;
            case 39 -> 17;
            case 40 -> 43;
            case 41 -> 40;
            case 42 -> 3;
            case 43 -> 0;
            case 44 -> 1;
            case 45 -> 55;
            case 46 -> 6;
            case 47 -> 30;
            case 48 -> 38;
            case 49 -> 4;
            case 50 -> 57;
            case 51 -> 16;
            case 52 -> 14;
            case 53 -> 51;
            case 54 -> 31;
            case 55 -> 21;
            case 56 -> 34;
            case 57 -> 61;
            case 58 -> 32;
            case 59 -> 33;
            case 60 -> 53;
            case 61 -> 48;
            case 62 -> 7;
            default -> 20;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        SelfDestruct.z[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = y;
        y[0] = "6[8\u0013\u0000F=[3";
        objectArray[1] = "Q?\u0000\u0012bmQ?\u0017NnbKt\u0017PnwL\u0005G\r?";
        objectArray[2] = Boolean.TYPE;
        SelfDestruct.z[2] = "java/lang/Boolean";
        objectArray[3] = Void.TYPE;
        SelfDestruct.z[3] = "java/lang/Void";
        objectArray[4] = "x\u0000\u0003\u0018l^s\u0000\u0007\u0018l\u001d";
        objectArray[5] = "<\u0013\f\u0011\u0012L7\u001c\u001d^oT$\u001b\u0014\u0017";
        objectArray[6] = "\u001d\u001eI\u0014'\u001a\u0016\u001eM\u0014'W";
        objectArray[7] = "b\f\rS-Si\u0003\u001c\u001cWWz\u0002\fSaSm";
        objectArray[8] = "j\u001aJA.\u000ec\u001aIA<";
        objectArray[9] = "c\u0004R\u0017P\u0003j\u0004Q\u0017P";
        objectArray[10] = "\u001a<\u0019\u0015\u0011V\u00113\bZpX\u001a8\f\u0000";
        objectArray[11] = "<^Uh|]I~^gm\u0012(pUliH\\";
        objectArray[12] = "35kr2\u00020;3uu\u0000<zMrh\u0004";
        objectArray[13] = "\u0014M(j\u0006)\u001dM+j\u0004";
        objectArray[14] = "_OQ4gOTOY";
        objectArray[15] = "CKE\u000fw\u00146kN\u0000f[WeE\u000bb\u0001#";
        objectArray[16] = "v\u000eKz`\"\u0003.@uqmb K~u7\u0016";
        objectArray[17] = "i<\ro7\u0012\u001c\u001c\u0006`&]}\u0012\rk\"\u0007\t";
        objectArray[18] = "e*}A\u001c\u0012\u0010\nvN\r]q\u0004}E\t\u0007\u0005";
        objectArray[19] = "\u0004\u0018l/\u0011bq8g \u0000-\u00106l+\u0004wd";
        objectArray[20] = ".t>R3} *2,7\u0017a(4\u00117l!35";
        objectArray[21] = "0Z\u0002M(?3V\u001f\u0002Ln\u000b]\u0005\u001648f\u0005\u0012\u0010|\u0004";
        objectArray[22] = "I'AW\u0005g\t{\u0016@\u007fou}DJ\u001f{\u001a)ELA\u0006H/NO\u0002i\u001c.H\u0011\u007f";
        objectArray[23] = "\u0012AYiw\u0014R\u001d\u000e~\r\r.\u001bT|5\bABB!|";
        objectArray[24] = "-bK\u0014q7m>\u001c\u0003\u000b1\u00114L\r57qu\u0011]v";
        objectArray[25] = "E}q>_{\u0005!&)%pyvf?\u001fc\u0007+`z\u001a\u001aC!p%Ky\u001a`a/%";
        objectArray[26] = "Y^\u000b+gxW\u0000\u0007Uk\u0012P\u001c\u00192dh\u0011Y]3\n(R\u000f\u0006;iq\u0013\u001e\fU";
        objectArray[27] = "r?.I)\u00192cy^S\u001eNi)Pm\u0019.(t\u0000.";
        objectArray[28] = "e-.fR\u001fb$i:o?H\\\u001b\u00193te-.fR\u001fb$i:";
        objectArray[29] = "\u0014\u0006K%/'TZ\u001c2U-(\r\\$o?VPZajF\u0012ZJ>;%K\u001b[4U";
        objectArray[30] = "\u000f\"\u0002\u0012\u00056U,\u001f\r|`1t\u0006V\u001c`N:\u0016\u000bE\t";
        objectArray[31] = "zp\u000b\u001b\u001e9:,\\\fd6F{\u001c\u001a^!8&\u001a_[X|,\n\u0000\n;%m\u001b\nd";
        objectArray[32] = ")H\b\u0010/{'\u0016\u0004n!\u0011u\u000f\u001fT;o(\tZQB+\"\u0019\u0005\u0000!rc\b\u000fn";
        objectArray[33] = "D\u0004\"}\fC\u0004XujvKx\u000f5|L[\u0006R39I\"H\u0003t:\rY\u0015\u0002u|v";
        objectArray[34] = "\u0015\u001a<\\M|UFkK7x)L;E\t|I\rf\u0015J";
        Object[] objectArray2 = objectArray;
        objectArray[35] = "\u001c\\\r\tU}\u0012\u0002\u0001w\\\u0017@\u001b\u001aMAi\u001d\u001d_H8-\u0017\r\u0000\u0019[tV\u001c\nw";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = SelfDestruct.e(l2, l3);
            object = y[n2];
            try {
                if (!(object instanceof String)) break block2;
                SelfDestruct.y[n2] = clazz = Class.forName(z[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = SelfDestruct.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = SelfDestruct.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = SelfDestruct.e(l2, l3);
        Object object = y[n2];
        if (object instanceof String) {
            String string = z[n2];
            int n3 = string.indexOf(8);
            Class clazz = SelfDestruct.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = SelfDestruct.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = SelfDestruct.c(clazz3, string2, clazz2)) != null) {
                    SelfDestruct.y[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = SelfDestruct.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        SelfDestruct.y[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = SelfDestruct.f(762207525337969L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = SelfDestruct.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = SelfDestruct.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = SelfDestruct.e(l2, l3);
        Object object = y[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = z[n2];
                int n4 = string2.indexOf(8);
                clazz3 = SelfDestruct.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = SelfDestruct.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = SelfDestruct.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        SelfDestruct.y[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = SelfDestruct.f(762207525337969L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = SelfDestruct.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        SelfDestruct.y[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = SelfDestruct.f(762207525337969L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == 'Y' || c2 == 'X' || c2 == '\u00d6' || c2 == '\u00de') {
                field = SelfDestruct.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == 'Y' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == 'X' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == '\u00d6' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = SelfDestruct.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == 's' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == '\u00f8' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = SelfDestruct.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_2().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/e/ac" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(SelfDestruct.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(SelfDestruct.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_2() {
        try {
            return MethodHandles.lookup().findStatic(SelfDestruct.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

