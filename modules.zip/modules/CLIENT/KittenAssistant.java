// === Kuzi module: KittenAssistant ===
// Category   : CLIENT
// Description: The oneko cat that follows your cursor and says random things
// Payload    : a.a.a.j.b.m (verified: True)

package kuzi.modules.client;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.b.r;
import kuzi.obf.h.b.v;
import kuzi.obf.j.b.a;
import kuzi.obf.l.c.b;
import kuzi.obf.l.c.c;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.Minecraft;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class KittenAssistant
extends BaseModule {
    private static final int[][] m;
    private static final int[][] n;
    private static final int[][] o;
    private static final int[][] p;
    private static final int[][] q;
    private static final int[][] r;
    private static final int[][] s;
    private static final int[][] t;
    private static final int[][] u;
    private static final int[][] v;
    private static final int[][] w;
    private static final int x;
    private static final int y;
    private static final int z;
    private static final long A;
    private static final int B;
    private final r C;
    private final SliderSetting size2;
    private final SliderSetting speed;
    private final Random F;
    private float G;
    private float H;
    private boolean I;
    private long J;
    private long K;
    private long L;
    private long M;
    private int N;
    private int[][] O;
    private String P;
    private static final long Q;
    private static final String[] R;
    private static final String[] S;
    private static final Map T;
    private static final long[] U;
    private static final Integer[] V;
    private static final Map W;
    private static final long[] X;
    private static final Long[] Y;
    private static final Map Z;
    private static final Object[] ab;
    private static final String[] bb;

    public KittenAssistant() {
        long l2 = Q ^ 0x444E9A7B2603L;
        long l3 = l2 ^ 0x24DBDBC97626L;
        super("KittenAssistant", "The oneko cat that follows your cursor and says random things", Category.CLIENT);
        this.C = new r("Lines", Arrays.asList("want a coffie?", "meow~", "you got this!", "take a break?"));
        this.size2 = new SliderSetting("Size", 1.6, 0.5, 4.0, 0.1);
        this.speed = new SliderSetting("Speed", 10.0, 2.0, 30.0, 1.0);
        this.F = new Random();
        this.O = m;
        this.P = "";
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.C, this.size2, this.speed};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        long l2 = Q ^ 0x2AFBF6B96CFDL;
        this.I = false;
        this.J = 0L;
        this.M = 0L;
        this.N = 0;
        this.K = System.currentTimeMillis() + KittenAssistant.d("a", (int)20004, (long)(0x10DBE4512013FCDL ^ l2));
        this.L = 0L;
        super.d();
    }

    public void a(Object[] objectArray) {
        Object[] objectArray2;
        KittenAssistant kittenAssistant;
        float f2;
        float f3;
        int n2;
        long l2;
        long l3;
        block39: {
            long l4;
            block38: {
                block28: {
                    long l5;
                    float f4;
                    long l6;
                    String[] stringArray;
                    long l7;
                    Minecraft mc3102;
                    block37: {
                        String[] stringArray2;
                        long l8;
                        block27: {
                            block26: {
                                long l9;
                                long l10;
                                float f5;
                                float f6;
                                float f7;
                                long l11;
                                block36: {
                                    block35: {
                                        int n3;
                                        long l12;
                                        block34: {
                                            int n4;
                                            float f8;
                                            block31: {
                                                float f9;
                                                float f10;
                                                block32: {
                                                    block33: {
                                                        block30: {
                                                            float f11;
                                                            block29: {
                                                                l3 = (Long)objectArray[0];
                                                                mc3102 = (Minecraft)objectArray[1];
                                                                long l13 = l3 = Q ^ l3;
                                                                l7 = l13 ^ 0x28DED60D57CEL;
                                                                l12 = l13 ^ 0x4A671A3DED04L;
                                                                long l14 = l13 ^ 0x7AA714F60D43L;
                                                                long l15 = l13 ^ 0x6B92B0142CA5L;
                                                                l11 = l13 ^ 0x3875ED70E1FBL;
                                                                l2 = l13 ^ 0x51D10022C5D8L;
                                                                l4 = l13 ^ 0x73A040F3B548L;
                                                                long l16 = l13 ^ 0x436A21818129L;
                                                                l8 = l13 ^ 0x265FF9E152C9L;
                                                                n2 = kuzi.obf.l.c.b.a(l14, (String)((Object)KittenAssistant.b("f", (int)14847, (long)(0x5C4714EC8F2E101L ^ l3))), (String)((Object)KittenAssistant.b("f", (int)1453, (long)(0xFC9AC14C7BC5D59L ^ l3))), true);
                                                                stringArray = kuzi.obf.j.b.a.b();
                                                                l6 = System.currentTimeMillis();
                                                                f4 = kuzi.obf.l.c.c.a(l15);
                                                                f7 = kuzi.obf.l.c.c.b(l16);
                                                                float f12 = f4 - 0.0f;
                                                                f11 = f12 == 0.0f ? 0 : (f12 < 0.0f ? -1 : 1);
                                                                if (stringArray == null) break block29;
                                                                if (f11 <= 0) break block30;
                                                                f8 = f7;
                                                                if (l3 <= 0L) break block31;
                                                                f10 = 0.0f;
                                                                if (stringArray == null) break block32;
                                                                float f13 = f8 - f10;
                                                                f11 = f13 == 0.0f ? 0 : (f13 < 0.0f ? -1 : 1);
                                                            }
                                                            if (f11 > 0) break block33;
                                                        }
                                                        return;
                                                    }
                                                    f9 = 32.0f;
                                                    f10 = ((Double)this.size2.a()).floatValue();
                                                }
                                                f8 = f9 * f10;
                                            }
                                            f3 = f8;
                                            f2 = f3 / 2.0f;
                                            n3 = n4 = mc3102.screen != null ? 1 : 0;
                                            if (stringArray == null) break block34;
                                            if (n3 == 0) break block35;
                                            n3 = mc3102.getWindow().getGuiScale();
                                        }
                                        double d2 = n3;
                                        Object[] objectArray3 = new Object[4];
                                        objectArray3[3] = l12;
                                        objectArray3[2] = Float.valueOf(f4 - f2);
                                        objectArray3[1] = Float.valueOf(f2);
                                        objectArray3[0] = Float.valueOf((float)(mc3102.mouseHandler.xpos() / d2));
                                        f6 = KittenAssistant.a(objectArray3);
                                        Object[] objectArray4 = new Object[4];
                                        objectArray4[3] = l12;
                                        objectArray4[2] = Float.valueOf(f7 - f2);
                                        objectArray4[1] = Float.valueOf(f2);
                                        objectArray4[0] = Float.valueOf((float)(mc3102.mouseHandler.ypos() / d2));
                                        f5 = KittenAssistant.a(objectArray4);
                                        if (l3 <= 0L || stringArray != null) break block36;
                                    }
                                    f6 = f4 - f2 - 14.0f;
                                    f5 = f7 - f2 - 14.0f;
                                }
                                Object object = this;
                                if (stringArray != null) {
                                    KittenAssistant kittenAssistant2;
                                    long l17 = -8320794285779591156L;
                                    long l18 = l3;
                                    if (l3 > 0L) {
                                        if (!((KittenAssistant)object).I) {
                                            this.G = f4 - f2 - 14.0f;
                                            this.H = f7 - f2 - 14.0f;
                                            this.I = true;
                                        }
                                        kittenAssistant2 = this;
                                        l17 = -8322525271818285555L;
                                        l18 = l3;
                                    }
                                    object = ((Setting)((Object)KittenAssistant.f("\u00c7", (Object)kittenAssistant2, (long)l17, (long)l18))).a();
                                }
                                float f14 = ((Double)object).floatValue();
                                long l19 = this.J - 0L;
                                long l20 = l19 == 0L ? 0 : (l19 < 0L ? -1 : 1);
                                if (stringArray != null) {
                                    if (l20 == false) {
                                        this.J = l6;
                                    }
                                    l20 = l10 = (long)0;
                                }
                                while (l6 - this.J >= KittenAssistant.d("a", (int)2006, (long)(0xECFE0D65F6EDD67L ^ l3))) {
                                    l5 = l10;
                                    stringArray2 = stringArray;
                                    if (l3 >= 0L) {
                                        if (stringArray2 == null) break block26;
                                        stringArray2 = stringArray;
                                    }
                                    if (l3 <= 0L) break block27;
                                    if (stringArray2 == null) break block26;
                                    if (l5 >= KittenAssistant.c("s", (int)195, (long)(0x6B90C180C9DC9D55L ^ l3))) break;
                                    this.J += KittenAssistant.d("a", (int)3530, (long)(0x337B34537593D77EL ^ l3));
                                    Object[] objectArray5 = new Object[7];
                                    objectArray5[6] = Float.valueOf(f7);
                                    objectArray5[5] = Float.valueOf(f4);
                                    objectArray5[4] = Float.valueOf(f2);
                                    objectArray5[3] = Float.valueOf(f14);
                                    objectArray5[2] = Float.valueOf(f5);
                                    objectArray5[1] = Float.valueOf(f6);
                                    objectArray5[0] = l11;
                                    this.b(objectArray5);
                                    ++l10;
                                    if (stringArray != null) continue;
                                    if (l3 <= 0L) break block28;
                                }
                                l5 = (l9 = l6 - this.K) == 0L ? 0 : (l9 < 0L ? -1 : 1);
                            }
                            if (l3 < 0L) break block37;
                            stringArray2 = stringArray;
                        }
                        if (stringArray2 != null) {
                            long l21;
                            if (l5 >= 0) {
                                Object[] objectArray6 = new Object[1];
                                objectArray6[0] = l8;
                                this.P = this.c(objectArray6);
                                this.L = l6 + KittenAssistant.d("a", (int)13209, (long)(0x6F2039CD3105692CL ^ l3));
                                this.K = l6 + KittenAssistant.d("a", (int)16169, (long)(0x3F41F13F2255E599L ^ l3)) + (long)this.F.nextInt((int)KittenAssistant.c("s", (int)3300, (long)(0x502DAAD65B2C116BL ^ l3)));
                            }
                            l5 = (l21 = l6 - this.L) == 0L ? 0 : (l21 < 0L ? -1 : 1);
                        }
                    }
                    if (l5 >= 0) break block28;
                    kittenAssistant = this;
                    if (stringArray == null) break block38;
                    if (kittenAssistant.P == null) break block28;
                    kittenAssistant = this;
                    objectArray2 = stringArray;
                    if (l3 < 0L) break block39;
                    if (objectArray2 == null) break block38;
                    if (!kittenAssistant.P.isEmpty()) {
                        Object[] objectArray7 = new Object[6];
                        objectArray7[5] = Float.valueOf(f4);
                        objectArray7[4] = Float.valueOf(this.H - f2);
                        objectArray7[3] = l7;
                        objectArray7[2] = Float.valueOf(this.G);
                        objectArray7[1] = l6;
                        objectArray7[0] = mc3102;
                        this.c(objectArray7);
                    }
                }
                kittenAssistant = this;
            }
            Object[] objectArray8 = new Object[1];
            objectArray2 = objectArray8;
            objectArray8[0] = l4;
        }
        int[][] nArray = kittenAssistant.a(objectArray2);
        int[] nArray2 = nArray[(int)(this.M % (long)nArray.length)];
        kuzi.obf.l.c.c.a(n2, (int)KittenAssistant.c("s", (int)2733, (long)(0x11AA5EC68F771736L ^ l3)), (int)KittenAssistant.c("s", (int)12723, (long)(0x3C09ADB779CB2C22L ^ l3)), nArray2[0] * KittenAssistant.c("s", (int)12036, (long)(0x281647B0D1A0B299L ^ l3)), nArray2[1] * KittenAssistant.c("s", (int)5654, (long)(0x612DC031200C8B84L ^ l3)), 32.0f, 32.0f, this.G - f2, this.H - f2, l2, f3, f3, 1.0f);
    }

    private void b(Object[] args) {
        block8: {
            float distance;
            reference deltaY;
            reference deltaX;
            long l2;
            long l3;
            float f3;
            float f4;
            float f5;
            float followDistance;
            long l4;
            block9: {
                block6: {
                    l4 = (Long)args[0];
                    float mouseX = ((Float)args[1]).floatValue();
                    float mouseY = ((Float)args[2]).floatValue();
                    followDistance = ((Float)args[3]).floatValue();
                    f5 = ((Float)args[4]).floatValue();
                    f4 = ((Float)args[5]).floatValue();
                    f3 = ((Float)args[6]).floatValue();
                    long l5 = l4 = Q ^ l4;
                    l3 = l5 ^ 0x3364BD82C7CFL;
                    l2 = l5 ^ 0x3F08082546A3L;
                    deltaX = KittenAssistant.f("\u00c7", (Object)this, (long)-6463071239654831411L, (long)l4) - mouseX;
                    deltaY = KittenAssistant.f("\u00c7", (Object)this, (long)-6464500204769345195L, (long)l4) - mouseY;
                    distance = (float)Math.sqrt((double)(deltaX * deltaX + deltaY * deltaY));
                    CallSite callSite = KittenAssistant.f("\u00c9", (long)-6461301304135035716L, (long)l4);
                    try {
                        block7: {
                            try {
                                try {
                                    KittenAssistant kittenAssistant = this;
                                    KittenAssistant.f("\u00fb", (Object)kittenAssistant, (long)(KittenAssistant.f("\u00c7", (Object)kittenAssistant, (long)-6461692581442337493L, (long)l4) + 1L), (long)-6461692581442337493L, (long)l4);
                                    if (callSite == null) break block6;
                                    if (distance < followDistance) break block7;
                                }
                                catch (kuzi.obf.m.r r2) {
                                    throw KittenAssistant.f("\u00c9", (Object)r2, (long)-6464566085685369675L, (long)l4);
                                }
                                if (l4 <= 0L) break block8;
                                if (!(distance < 4.0f)) break block9;
                            }
                            catch (kuzi.obf.m.r r3) {
                                throw KittenAssistant.f("\u00c9", (Object)r3, (long)-6464566085685369675L, (long)l4);
                            }
                        }
                        KittenAssistant kittenAssistant = this;
                        KittenAssistant.f("\u00fb", (Object)kittenAssistant, (int)(KittenAssistant.f("\u00c7", (Object)kittenAssistant, (long)-6461486462645463372L, (long)l4) + true), (long)-6461486462645463372L, (long)l4);
                    }
                    catch (kuzi.obf.m.r r4) {
                        throw KittenAssistant.f("\u00c9", (Object)r4, (long)-6464566085685369675L, (long)l4);
                    }
                }
                return;
            }
            KittenAssistant.f("\u00fb", (Object)this, (int)0, (long)-6461486462645463372L, (long)l4);
            Object[] objectArray2 = new Object[4];
            objectArray2[3] = l3;
            objectArray2[2] = Float.valueOf(f4 - f5);
            objectArray2[1] = Float.valueOf(f5);
            objectArray2[0] = Float.valueOf((float)(KittenAssistant.f("\u00c7", (Object)this, (long)-6463071239654831411L, (long)l4) - deltaX / distance * followDistance));
            KittenAssistant.f("\u00fb", (Object)this, (float)KittenAssistant.f("\u00c9", (Object)objectArray2, (long)-6464738623698803672L, (long)l4), (long)-6463071239654831411L, (long)l4);
            Object[] objectArray3 = new Object[4];
            objectArray3[3] = l3;
            objectArray3[2] = Float.valueOf(f3 - f5);
            objectArray3[1] = Float.valueOf(f5);
            objectArray3[0] = Float.valueOf((float)(KittenAssistant.f("\u00c7", (Object)this, (long)-6464500204769345195L, (long)l4) - var16_12 / f2 * f6));
            KittenAssistant.f("\u00fb", (Object)this, (float)KittenAssistant.f("\u00c9", (Object)objectArray3, (long)-6464738623698803672L, (long)l4), (long)-6464500204769345195L, (long)l4);
            Object[] objectArray4 = new Object[3];
            objectArray4[2] = Float.valueOf((float)(var16_12 / f2));
            objectArray4[1] = Float.valueOf((float)(var15_11 / f2));
            objectArray4[0] = l2;
            KittenAssistant.f("\u00fb", (Object)this, (int[][])KittenAssistant.f("\u00c9", (Object)objectArray4, (long)-6461594617942252054L, (long)l4), (long)-6463876930728104537L, (long)l4);
        }
    }

    private int[][] a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = Q ^ l2;
        String[] stringArray = kuzi.obf.j.b.a.b();
        int frame = this.N;
        if (stringArray != null) {
            if (frame == 0) {
                return this.O;
            }
            frame = this.N;
        }
        CallSite frameCount = KittenAssistant.c("s", (int)17997, (long)(0x118590FC019525AAL ^ l2));
        if (l2 >= 0L && stringArray != null) {
            if (frame < frameCount) {
                return m;
            }
            frame = this.N - KittenAssistant.c("s", (int)22316, (long)(0x6005C9C5DF79B4D9L ^ l2));
            frameCount = KittenAssistant.c("s", (int)19869, (long)(0x611BB72E0A2EAE7BL ^ l2));
        }
        return frame < frameCount ? n : o;
    }

    private String c(Object[] objectArray) {
        List phrase;
        block4: {
            List phrases;
            block5: {
                long l2;
                block3: {
                    String[] stringArray;
                    block2: {
                        l2 = (Long)objectArray[0];
                        long l3 = (l2 = Q ^ l2) ^ 0x2BDB966FCC45L;
                        Object[] objectArray2 = new Object[1];
                        objectArray2[0] = l3;
                        phrases = this.C.a(objectArray2);
                        stringArray = kuzi.obf.j.b.a.b();
                        phrase = phrases;
                        if (stringArray == null) break block2;
                        if (phrase == null) break block3;
                        phrase = phrases;
                    }
                    if (stringArray == null) break block4;
                    if (!phrase.isEmpty()) break block5;
                }
                return KittenAssistant.b("f", (int)24914, (long)(0x1EB9CCD82A2C205BL ^ l2));
            }
            phrase = phrases.get(this.F.nextInt(phrases.size()));
        }
        return (String)((Object)phrase);
    }

    private void c(Object[] objectArray) {
        Minecraft mc3102 = (Minecraft)objectArray[0];
        long l2 = (Long)objectArray[1];
        float centerX = ((Float)objectArray[2]).floatValue();
        long l3 = (Long)objectArray[3];
        float baseY = ((Float)objectArray[4]).floatValue();
        float tipX = ((Float)objectArray[5]).floatValue();
        long l4 = l3 = Q ^ l3;
        long l5 = l4 ^ 0x1EEFBBCD8563L;
        long l6 = l4 ^ 0x3FEF49745EC9L;
        long l7 = l4 ^ 0x23CF86FF71FAL;
        long l8 = l4 ^ 0x5D3AE80A8C57L;
        long l9 = l4 ^ 0x5F194EF21293L;
        long l10 = l4 ^ 0x3EC451DBD37CL;
        int n2 = (int)(l10 >>> 48);
        int n3 = (int)(l10 << 16 >>> 48);
        int n4 = (int)(l10 << 32 >>> 32);
        long l11 = l4 ^ 0x183D1D839B73L;
        long l12 = l4 ^ 0x636E8692D671L;
        int n5 = (int)(l12 >>> 48);
        int n6 = (int)(l12 << 16 >>> 32);
        int n7 = (int)(l12 << 48 >>> 48);
        float textHeight = 11.0f;
        float padding = 8.0f;
        KittenAssistant.f("\u00c9", (short)((short)n5), (int)1, (int)n6, (int)n7, (long)1188765299330969212L, (long)l3);
        reference bubbleWidth = KittenAssistant.f("\u00c9", (Object)KittenAssistant.f("\u00c7", (Object)this, (long)1188021580981873708L, (long)l3), (float)textHeight, (long)l11, (long)1188092658922702602L, (long)l3) + padding * 2.0f;
        float bubbleHeight = textHeight + padding * 2.0f;
        Object[] objectArray2 = new Object[4];
        objectArray2[3] = l7;
        objectArray2[2] = Float.valueOf(tipX - bubbleWidth - 4.0f);
        objectArray2[1] = Float.valueOf(4.0f);
        objectArray2[0] = Float.valueOf(centerX - bubbleWidth / 2.0f);
        CallSite bubbleX = KittenAssistant.f("\u00c9", (Object)objectArray2, (long)1188302491906920989L, (long)l3);
        float bubbleY = baseY - bubbleHeight - 8.0f;
        float alpha = Math.min(1.0f, (float)(KittenAssistant.f("\u00c7", (Object)this, (long)1187145409959249013L, (long)l3) - l2) / 400.0f);
        KittenAssistant.f("\u00c9", (float)alpha, (long)l8, (long)1180150612005706654L, (long)l3);
        KittenAssistant.f("\u00c9", (float)bubbleX, (float)bubbleY, (float)bubbleWidth, (float)bubbleHeight, (float)8.0f, (int)KittenAssistant.c("s", (int)14783, (long)(0x555B5A6D84DB38CFL ^ l3)), (long)l9, (long)1186733884261075727L, (long)l3);
        KittenAssistant.f("\u00c9", (float)bubbleX, (short)((short)n2), (float)bubbleY, (float)bubbleWidth, (char)((char)n3), (int)n4, (float)bubbleHeight, (float)8.0f, (float)1.0f, (int)KittenAssistant.c("s", (int)1367, (long)(0x39E3D96C93EC0439L ^ l3)), (long)1180578380562629493L, (long)l3);
        Object[] objectArray3 = new Object[4];
        objectArray3[3] = l7;
        objectArray3[2] = Float.valueOf((float)(bubbleX + bubbleWidth - 8.0f));
        objectArray3[1] = Float.valueOf((float)(bubbleX + 8.0f));
        objectArray3[0] = Float.valueOf(centerX);
        CallSite textX = KittenAssistant.f("\u00c9", (Object)objectArray3, (long)1188302491906920989L, (long)l3);
        KittenAssistant.f("\u00c9", (float)(textX - 5.0f), (float)(bubbleY + bubbleHeight), (float)(textX + 5.0f), (float)(bubbleY + bubbleHeight), (float)textX, (float)(bubbleY + bubbleHeight + 7.0f), (int)KittenAssistant.c("s", (int)8081, (long)(0x496A691DF41C1EFBL ^ l3)), (long)l6, (long)1188229836110415751L, (long)l3);
        KittenAssistant.f("\u00c9", (Object)KittenAssistant.f("\u00c7", (Object)this, (long)1188021580981873708L, (long)l3), (long)l5, (float)(bubbleX + padding), (float)(bubbleY + bubbleHeight / 2.0f), (float)textHeight, (int)KittenAssistant.c("s", (int)29668, (long)(0x364B09627191F28DL ^ l3)), (long)1180023843620713604L, (long)l3);
        KittenAssistant.f("\u00c9", (float)1.0f, (long)l8, (long)1180150612005706654L, (long)l3);
        KittenAssistant.f("\u00c9", (short)((short)n5), (int)0, (int)n6, (int)n7, (long)1188765299330969212L, (long)l3);
    }

    private static float a(Object[] objectArray) {
        float result;
        block4: {
            float comparison;
            float upperBound;
            float value;
            block2: {
                String[] stringArray;
                block3: {
                    value = ((Float)objectArray[0]).floatValue();
                    float lowerBound = ((Float)objectArray[1]).floatValue();
                    upperBound = ((Float)objectArray[2]).floatValue();
                    long l2 = (Long)objectArray[3];
                    l2 = Q ^ l2;
                    stringArray = kuzi.obf.j.b.a.b();
                    comparison = value == lowerBound ? 0 : (value < lowerBound ? -1 : 1);
                    if (stringArray == null) break block2;
                    if (comparison >= 0) break block3;
                    result = lowerBound;
                    break block4;
                }
                result = value;
                if (stringArray == null) break block4;
                float overUpper = result - upperBound;
                comparison = overUpper == 0.0f ? 0 : (overUpper > 0.0f ? 1 : -1);
            }
            result = comparison > 0 ? upperBound : value;
        }
        return result;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block31: {
            block30: {
                block29: {
                    block28: {
                        block27: {
                            block26: {
                                KittenAssistant.Q = kuzi.obf.h.b.v.a(-6467696244817956277L, -2575183693683781159L, MethodHandles.lookup().lookupClass()).a(210254109733593L);
                                var31 = KittenAssistant.Q ^ 45601924563731L;
                                KittenAssistant.ab = new Object[92];
                                KittenAssistant.bb = new String[92];
                                KittenAssistant.c();
                                KittenAssistant.T = new HashMap<K, V>(13);
                                var22_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                                v0 = SecretKeyFactory.getInstance("DES");
                                v1 = new byte[8];
                                v2 = v1;
                                v1[0] = (byte)(var31 >>> 56);
                                for (var23_2 = 1; var23_2 < 8; ++var23_2) {
                                    v2 = v2;
                                    v2[var23_2] = (byte)(var31 << var23_2 * 8 >>> 56);
                                }
                                var22_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                                var29_3 = new String[16];
                                var27_4 = 0;
                                var26_5 = "3\u00a5\u00ec3\u00a8\u00fd<<\u00cc\u00d1\u00b1Wjs\u00e6\u0012 n@\u009ay\u00a8wV\u00bfX\u0017\u0011x\u00be@z\u00cd\u009c/y\u00a7\u008c-\u00bem\u0098qU\u00d3WE\f~\u0010\u0080\u0082+\u00c48\u00eb\u00a5\u00c8\u00ac_\u00bb\u00f4F\u00f6\u00af\u009eh*\u0099\u00f9\u00c6h\u00d2\u00ea^^UV\u00ab\u0096W#\u00c9\u00d4\u001f-q\u00b5I\u00e8\u00f4\u00f8\u00c6*\u00bf@\u00bdA\u00ea.\"A\u0082q\u00dcC\u00af\u009dU\u00b0`\u00df\u00b3!\u00c8|\u00a6\u00d4\u00ff4\u00aaia\u0091lc\u0081\u0012)\u000f\u001c\u00dd\u0093>\u0081\u009a\u0005\u0093\u00ae\t\u00c2\u00ee/\u00abU\u00d4\u008c\u00c7\u0096\u00ed\u00b1\u0085\t\u0086\u00e18\u00b2\u00e1B\u000b\u0012MX\u00af\u00d0\u00bd\u0003\u0098\u0006\u00a9\u00b2\u0010{7\u00aaY\u008a\u0017\u00fe\u00ab\u00eb=\u001aY\u0092\u00b3\u007f\u009f(&\u008c\u00c1\u00b0\u00c2\u00d5H\u0091?\u00c3euT\u00e1\u00e7,#\u00c1*~\u00c4\u00b7\u0014\u00dbc\u00a7\u0003$lD\u00f5\\\u00c9\u00f5\u007f\u00c4\u00c6a2[\u0010\u0004\u00ed\u0007\u00d3Y\u0093\"\u0085\bhr\u00e5\u0088\u00c11\u00d7 k\u00c3\u008c\u00ca\u0018\u00dag\u008a$z]\rkl\u0013A\u00b2\u00b6\u00b4\u00ae\u00d35w\u00db\u00e9#`,\u00ce9\u00e1\u0083 \u00f5\u009d?Ei\u00f2I\u00e7\f~\u0090\u0086\u00e0\u00ceA\u009d\u000f\u00a4k\u00a76\t\u001e4\u00fa\u009e4\u00d8\u00c3j\u00f5B\u0010\u001e\u00cc%I\u0097\u00b1q\u00862yl\u0089\u007f\u0018\u0015a\u0010\u00a1f]\u0087\u00c3J\u00d4\u0088\u0091\u00a8\u00fc\u000f\u008a\u00c4\u008e\u0090\u0010#\u00d60\u00d4\u00d6\u00c7\u009a\u00e1I,\u00b5\u00cbh\u0097\u00f9n\u0018N \u00e8\u0080P>\u000bK\u00f0\u0095 \u0001\u00b0cE\u0089\u009b4M\u00e7`k\u00c3q\u0010\u00b6$[t\u00a8\u00f8\u00e2\u00bah\u00c7s|\u0004\u001f(\u0099";
                                var28_6 = "3\u00a5\u00ec3\u00a8\u00fd<<\u00cc\u00d1\u00b1Wjs\u00e6\u0012 n@\u009ay\u00a8wV\u00bfX\u0017\u0011x\u00be@z\u00cd\u009c/y\u00a7\u008c-\u00bem\u0098qU\u00d3WE\f~\u0010\u0080\u0082+\u00c48\u00eb\u00a5\u00c8\u00ac_\u00bb\u00f4F\u00f6\u00af\u009eh*\u0099\u00f9\u00c6h\u00d2\u00ea^^UV\u00ab\u0096W#\u00c9\u00d4\u001f-q\u00b5I\u00e8\u00f4\u00f8\u00c6*\u00bf@\u00bdA\u00ea.\"A\u0082q\u00dcC\u00af\u009dU\u00b0`\u00df\u00b3!\u00c8|\u00a6\u00d4\u00ff4\u00aaia\u0091lc\u0081\u0012)\u000f\u001c\u00dd\u0093>\u0081\u009a\u0005\u0093\u00ae\t\u00c2\u00ee/\u00abU\u00d4\u008c\u00c7\u0096\u00ed\u00b1\u0085\t\u0086\u00e18\u00b2\u00e1B\u000b\u0012MX\u00af\u00d0\u00bd\u0003\u0098\u0006\u00a9\u00b2\u0010{7\u00aaY\u008a\u0017\u00fe\u00ab\u00eb=\u001aY\u0092\u00b3\u007f\u009f(&\u008c\u00c1\u00b0\u00c2\u00d5H\u0091?\u00c3euT\u00e1\u00e7,#\u00c1*~\u00c4\u00b7\u0014\u00dbc\u00a7\u0003$lD\u00f5\\\u00c9\u00f5\u007f\u00c4\u00c6a2[\u0010\u0004\u00ed\u0007\u00d3Y\u0093\"\u0085\bhr\u00e5\u0088\u00c11\u00d7 k\u00c3\u008c\u00ca\u0018\u00dag\u008a$z]\rkl\u0013A\u00b2\u00b6\u00b4\u00ae\u00d35w\u00db\u00e9#`,\u00ce9\u00e1\u0083 \u00f5\u009d?Ei\u00f2I\u00e7\f~\u0090\u0086\u00e0\u00ceA\u009d\u000f\u00a4k\u00a76\t\u001e4\u00fa\u009e4\u00d8\u00c3j\u00f5B\u0010\u001e\u00cc%I\u0097\u00b1q\u00862yl\u0089\u007f\u0018\u0015a\u0010\u00a1f]\u0087\u00c3J\u00d4\u0088\u0091\u00a8\u00fc\u000f\u008a\u00c4\u008e\u0090\u0010#\u00d60\u00d4\u00d6\u00c7\u009a\u00e1I,\u00b5\u00cbh\u0097\u00f9n\u0018N \u00e8\u0080P>\u000bK\u00f0\u0095 \u0001\u00b0cE\u0089\u009b4M\u00e7`k\u00c3q\u0010\u00b6$[t\u00a8\u00f8\u00e2\u00bah\u00c7s|\u0004\u001f(\u0099".length();
                                var25_7 = 16;
                                var24_8 = -1;
lbl23:
                                // 2 sources

                                while (true) {
                                    v3 = ++var24_8;
                                    v4 = var26_5.substring(v3, v3 + var25_7);
                                    v5 = -1;
                                    break block26;
                                    break;
                                }
lbl28:
                                // 1 sources

                                while (true) {
                                    var29_3[var27_4++] = KittenAssistant.b(var30_9).intern();
                                    if ((var24_8 += var25_7) < var28_6) {
                                        var25_7 = var26_5.charAt(var24_8);
                                        ** continue;
                                    }
                                    var26_5 = "~\u0006\u00e8\u0006>\u0089\u0081\u00ac\u009d\u0094\u0018\u00f6\f\u00155\u008d\u001b\u00a2\u0090\u000f\u00be\u00ea\u0003\u008dQ\u00d0\u00ffSS\u00d6\u0003\u0005\u0010&\t\"\u00da{\u0089\u00f1H\u0013\u00ddak\u0084\u00a1\u00fa\u00b6";
                                    var28_6 = "~\u0006\u00e8\u0006>\u0089\u0081\u00ac\u009d\u0094\u0018\u00f6\f\u00155\u008d\u001b\u00a2\u0090\u000f\u00be\u00ea\u0003\u008dQ\u00d0\u00ffSS\u00d6\u0003\u0005\u0010&\t\"\u00da{\u0089\u00f1H\u0013\u00ddak\u0084\u00a1\u00fa\u00b6".length();
                                    var25_7 = 32;
                                    var24_8 = -1;
lbl37:
                                    // 2 sources

                                    while (true) {
                                        v6 = ++var24_8;
                                        v4 = var26_5.substring(v6, v6 + var25_7);
                                        v5 = 0;
                                        break block26;
                                        break;
                                    }
                                    break;
                                }
lbl42:
                                // 1 sources

                                while (true) {
                                    var29_3[var27_4++] = KittenAssistant.b(var30_9).intern();
                                    if ((var24_8 += var25_7) < var28_6) {
                                        var25_7 = var26_5.charAt(var24_8);
                                        ** continue;
                                    }
                                    break block27;
                                    break;
                                }
                            }
                            var30_9 = var22_1.doFinal(v4.getBytes("ISO-8859-1"));
                            switch (v5) {
                                default: {
                                    ** continue;
                                }
                                ** case 0:
lbl54:
                                // 1 sources

                                ** continue;
                            }
                        }
                        KittenAssistant.R = var29_3;
                        KittenAssistant.S = new String[16];
                        KittenAssistant.W = new HashMap<K, V>(13);
                        var11_10 = Cipher.getInstance("DES/CBC/NoPadding");
                        v7 = SecretKeyFactory.getInstance("DES");
                        v8 = new byte[8];
                        v9 = v8;
                        v8[0] = (byte)(var31 >>> 56);
                        for (var12_11 = 1; var12_11 < 8; ++var12_11) {
                            v9 = v9;
                            v9[var12_11] = (byte)(var31 << var12_11 * 8 >>> 56);
                        }
                        var11_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                        var17_12 = new long[20];
                        var14_13 = 0;
                        var15_14 = "MPA\u0003\u0017\u00df\u00f8&\u00d8y\u0098^\u00a9\u009f7\u0092\u00cd\u0002\u00db\u00df\fV\u00a4iE\u00d4\u00c4B\u00e2\u00e9\u00f1d\u00f6\u00dcM-%\u00b7,\n\u00b6\u0092\t\u00a8f\u0018\u00d36,\u0084\u0087<\u00fd\u0014w\u00bb\u00a6P\u0080r\u00carBf\u00e5\u001a`\u00ba\u0091K\u00b8\u0017/\u0004kv@\u00ac\u00ce\u00e2b\u00d0\u0014\u008f\u00bb\u00bc\u00fb)\u00cd\u00f6\u00ce\u0087%a@\u008a`\u009c)\u0086\u00ed\u0001\u00e7%]\u0096\u00ef\u00e3n\u0004/\u00af\u00f5\u0001\u0011\u00ff\u00afyM#\u00fe\u00a4W|\f\u00a4\u00ad\u00bcw6u\u000b\u000b\u009bk\u00b0H=\r4\u00b9p\u000fa";
                        var16_15 = "MPA\u0003\u0017\u00df\u00f8&\u00d8y\u0098^\u00a9\u009f7\u0092\u00cd\u0002\u00db\u00df\fV\u00a4iE\u00d4\u00c4B\u00e2\u00e9\u00f1d\u00f6\u00dcM-%\u00b7,\n\u00b6\u0092\t\u00a8f\u0018\u00d36,\u0084\u0087<\u00fd\u0014w\u00bb\u00a6P\u0080r\u00carBf\u00e5\u001a`\u00ba\u0091K\u00b8\u0017/\u0004kv@\u00ac\u00ce\u00e2b\u00d0\u0014\u008f\u00bb\u00bc\u00fb)\u00cd\u00f6\u00ce\u0087%a@\u008a`\u009c)\u0086\u00ed\u0001\u00e7%]\u0096\u00ef\u00e3n\u0004/\u00af\u00f5\u0001\u0011\u00ff\u00afyM#\u00fe\u00a4W|\f\u00a4\u00ad\u00bcw6u\u000b\u000b\u009bk\u00b0H=\r4\u00b9p\u000fa".length();
                        var13_16 = 0;
                        while (true) {
                            var18_17 = var15_14.substring(var13_16, var13_16 += 8).getBytes("ISO-8859-1");
                            v10 = var17_12;
                            v11 = var14_13++;
                            v12 = ((long)var18_17[0] & 255L) << 56 | ((long)var18_17[1] & 255L) << 48 | ((long)var18_17[2] & 255L) << 40 | ((long)var18_17[3] & 255L) << 32 | ((long)var18_17[4] & 255L) << 24 | ((long)var18_17[5] & 255L) << 16 | ((long)var18_17[6] & 255L) << 8 | (long)var18_17[7] & 255L;
                            v13 = -1;
                            break block28;
                            break;
                        }
lbl81:
                        // 1 sources

                        while (true) {
                            v10[v11] = v14;
                            if (var13_16 < var16_15) ** continue;
                            var15_14 = "\u0000\u00b8\u001aB\u00f4r\u00fd\u0013\u00c2r\u00e1i\u00d0E\u00dd\u0094";
                            var16_15 = "\u0000\u00b8\u001aB\u00f4r\u00fd\u0013\u00c2r\u00e1i\u00d0E\u00dd\u0094".length();
                            var13_16 = 0;
                            while (true) {
                                var18_17 = var15_14.substring(var13_16, var13_16 += 8).getBytes("ISO-8859-1");
                                v10 = var17_12;
                                v11 = var14_13++;
                                v12 = ((long)var18_17[0] & 255L) << 56 | ((long)var18_17[1] & 255L) << 48 | ((long)var18_17[2] & 255L) << 40 | ((long)var18_17[3] & 255L) << 32 | ((long)var18_17[4] & 255L) << 24 | ((long)var18_17[5] & 255L) << 16 | ((long)var18_17[6] & 255L) << 8 | (long)var18_17[7] & 255L;
                                v13 = 0;
                                break block28;
                                break;
                            }
                            break;
                        }
lbl94:
                        // 1 sources

                        while (true) {
                            v10[v11] = v14;
                            if (var13_16 < var16_15) ** continue;
                            break block29;
                            break;
                        }
                    }
                    var19_18 = v12;
                    var21_19 = var11_10.doFinal(new byte[]{(byte)(var19_18 >>> 56), (byte)(var19_18 >>> 48), (byte)(var19_18 >>> 40), (byte)(var19_18 >>> 32), (byte)(var19_18 >>> 24), (byte)(var19_18 >>> 16), (byte)(var19_18 >>> 8), (byte)var19_18});
                    v14 = ((long)var21_19[0] & 255L) << 56 | ((long)var21_19[1] & 255L) << 48 | ((long)var21_19[2] & 255L) << 40 | ((long)var21_19[3] & 255L) << 32 | ((long)var21_19[4] & 255L) << 24 | ((long)var21_19[5] & 255L) << 16 | ((long)var21_19[6] & 255L) << 8 | (long)var21_19[7] & 255L;
                    switch (v13) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl107:
                        // 1 sources

                        ** continue;
                    }
                }
                KittenAssistant.U = var17_12;
                KittenAssistant.V = new Integer[20];
                KittenAssistant.B = 24;
                KittenAssistant.x = 256;
                KittenAssistant.y = 128;
                KittenAssistant.z = 32;
                KittenAssistant.Z = new HashMap<K, V>(13);
                var0_20 = Cipher.getInstance("DES/CBC/NoPadding");
                v15 = SecretKeyFactory.getInstance("DES");
                v16 = new byte[8];
                v17 = v16;
                v16[0] = (byte)(var31 >>> 56);
                for (var1_21 = 1; var1_21 < 8; ++var1_21) {
                    v17 = v17;
                    v17[var1_21] = (byte)(var31 << var1_21 * 8 >>> 56);
                }
                var0_20.init(2, (Key)v15.generateSecret(new DESKeySpec(v17)), new IvParameterSpec(new byte[8]));
                var6_22 = new long[6];
                var3_23 = 0;
                var4_24 = "\u00ef\u00d0{`\u0010\u00b8L\u0090&\u00af\u009f\u00b7\u00ce\u00c9tq8*\u00f1s\u00f3;\u00a1o;\u00c1\u00cc,\u0017\u00d6\u0089\u001a";
                var5_25 = "\u00ef\u00d0{`\u0010\u00b8L\u0090&\u00af\u009f\u00b7\u00ce\u00c9tq8*\u00f1s\u00f3;\u00a1o;\u00c1\u00cc,\u0017\u00d6\u0089\u001a".length();
                var2_26 = 0;
                while (true) {
                    var7_27 = var4_24.substring(var2_26, var2_26 += 8).getBytes("ISO-8859-1");
                    v18 = var6_22;
                    v19 = var3_23++;
                    v20 = ((long)var7_27[0] & 255L) << 56 | ((long)var7_27[1] & 255L) << 48 | ((long)var7_27[2] & 255L) << 40 | ((long)var7_27[3] & 255L) << 32 | ((long)var7_27[4] & 255L) << 24 | ((long)var7_27[5] & 255L) << 16 | ((long)var7_27[6] & 255L) << 8 | (long)var7_27[7] & 255L;
                    v21 = -1;
                    break block30;
                    break;
                }
lbl138:
                // 1 sources

                while (true) {
                    v18[v19] = v22;
                    if (var2_26 < var5_25) ** continue;
                    var4_24 = "\u00d2%\u00baT\u00ce\u00ca\u00cb\u00dc\u00fa\u00d6\u00cdZ\u00f9\u00e689";
                    var5_25 = "\u00d2%\u00baT\u00ce\u00ca\u00cb\u00dc\u00fa\u00d6\u00cdZ\u00f9\u00e689".length();
                    var2_26 = 0;
                    while (true) {
                        var7_27 = var4_24.substring(var2_26, var2_26 += 8).getBytes("ISO-8859-1");
                        v18 = var6_22;
                        v19 = var3_23++;
                        v20 = ((long)var7_27[0] & 255L) << 56 | ((long)var7_27[1] & 255L) << 48 | ((long)var7_27[2] & 255L) << 40 | ((long)var7_27[3] & 255L) << 32 | ((long)var7_27[4] & 255L) << 24 | ((long)var7_27[5] & 255L) << 16 | ((long)var7_27[6] & 255L) << 8 | (long)var7_27[7] & 255L;
                        v21 = 0;
                        break block30;
                        break;
                    }
                    break;
                }
lbl151:
                // 1 sources

                while (true) {
                    v18[v19] = v22;
                    if (var2_26 < var5_25) ** continue;
                    break block31;
                    break;
                }
            }
            var8_28 = v20;
            var10_29 = var0_20.doFinal(new byte[]{(byte)(var8_28 >>> 56), (byte)(var8_28 >>> 48), (byte)(var8_28 >>> 40), (byte)(var8_28 >>> 32), (byte)(var8_28 >>> 24), (byte)(var8_28 >>> 16), (byte)(var8_28 >>> 8), (byte)var8_28});
            v22 = ((long)var10_29[0] & 255L) << 56 | ((long)var10_29[1] & 255L) << 48 | ((long)var10_29[2] & 255L) << 40 | ((long)var10_29[3] & 255L) << 32 | ((long)var10_29[4] & 255L) << 24 | ((long)var10_29[5] & 255L) << 16 | ((long)var10_29[6] & 255L) << 8 | (long)var10_29[7] & 255L;
            switch (v21) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl164:
                // 1 sources

                ** continue;
            }
        }
        KittenAssistant.X = var6_22;
        KittenAssistant.Y = new Long[6];
        KittenAssistant.A = 100L;
        KittenAssistant.m = new int[][]{{3, 3}};
        KittenAssistant.n = new int[][]{{3, 2}};
        KittenAssistant.o = new int[][]{{2, 0}, {2, 1}};
        KittenAssistant.p = new int[][]{{1, 2}, {1, 3}};
        KittenAssistant.q = new int[][]{{0, 2}, {0, 3}};
        KittenAssistant.r = new int[][]{{3, 0}, {3, 1}};
        KittenAssistant.s = new int[][]{{5, 1}, {5, 2}};
        KittenAssistant.t = new int[][]{{6, 3}, {7, 2}};
        KittenAssistant.u = new int[][]{{5, 3}, {6, 1}};
        KittenAssistant.v = new int[][]{{4, 2}, {4, 3}};
        KittenAssistant.w = new int[][]{{1, 0}, {1, 1}};
    }

    private static kuzi.obf.m.r a(kuzi.obf.m.r value) {
        return value;
    }

    private static String b(byte[] byArray) {
        int outIndex = 0;
        int inputLength = byArray.length;
        char[] cArray = new char[inputLength];
        for (int index = 0; index < inputLength; ++index) {
            char ch;
            int byteValue = 0xFF & byArray[index];
            if (byteValue < 192) {
                cArray[outIndex++] = (char)byteValue;
                continue;
            }
            if (byteValue < 224) {
                ch = (char)((char)(byteValue & 0x1F) << 6);
                byteValue = byArray[++index];
                ch = (char)(ch | (char)(byteValue & 0x3F));
                cArray[outIndex++] = ch;
                continue;
            }
            if (index >= inputLength - 2) continue;
            ch = (char)((char)(byteValue & 0xF) << 12);
            byteValue = byArray[++index];
            ch = (char)(ch | (char)(byteValue & 0x3F) << 6);
            byteValue = byArray[++index];
            ch = (char)(ch | (char)(byteValue & 0x3F));
            cArray[outIndex++] = ch;
        }
        return new String(cArray, 0, outIndex);
    }

    private static String b(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x5462;
        if (S[n3] == null) {
            Object[] objectArray;
            try {
                Long l3 = Thread.currentThread().threadId();
                objectArray = (Object[])T.get(l3);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    T.put(l3, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/b/m", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l2 >>> 56);
            for (int byteIndex = 1; byteIndex < 8; ++byteIndex) {
                byArray[byteIndex] = (byte)(l2 << byteIndex * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = R[n3].getBytes("ISO-8859-1");
            KittenAssistant.S[n3] = KittenAssistant.b(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return S[n3];
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        String string2 = KittenAssistant.b(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static CallSite b(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/b/m" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x110C;
        if (V[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = U[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])W.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    W.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/b/m", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            KittenAssistant.V[n3] = n4;
        }
        return V[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = KittenAssistant.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/b/m" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static long d(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x5626;
        if (Y[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = X[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])Z.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    Z.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/b/m", exception);
            }
            long l5 = ((long)byArray[0] & 0xFFL) << 56 | ((long)byArray[1] & 0xFFL) << 48 | ((long)byArray[2] & 0xFFL) << 40 | ((long)byArray[3] & 0xFFL) << 32 | ((long)byArray[4] & 0xFFL) << 24 | ((long)byArray[5] & 0xFFL) << 16 | ((long)byArray[6] & 0xFFL) << 8 | (long)byArray[7] & 0xFFL;
            KittenAssistant.Y[n3] = l5;
        }
        return Y[n3];
    }

    private static long d(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        long l3 = KittenAssistant.d(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Long.TYPE, l3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return l3;
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_2().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/b/m" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (bb[n4] != null) {
            return n4;
        }
        Object object = ab[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 10;
            case 1 -> 12;
            case 2 -> 43;
            case 3 -> 20;
            case 4 -> 36;
            case 5 -> 2;
            case 6 -> 17;
            case 7 -> 53;
            case 8 -> 27;
            case 9 -> 25;
            case 10 -> 50;
            case 11 -> 35;
            case 12 -> 1;
            case 13 -> 39;
            case 14 -> 49;
            case 15 -> 47;
            case 16 -> 54;
            case 17 -> 22;
            case 18 -> 7;
            case 19 -> 3;
            case 20 -> 61;
            case 21 -> 62;
            case 22 -> 57;
            case 23 -> 29;
            case 24 -> 41;
            case 25 -> 55;
            case 26 -> 23;
            case 27 -> 15;
            case 28 -> 21;
            case 29 -> 30;
            case 30 -> 26;
            case 31 -> 34;
            case 32 -> 9;
            case 33 -> 32;
            case 34 -> 40;
            case 35 -> 60;
            case 36 -> 44;
            case 37 -> 45;
            case 38 -> 58;
            case 39 -> 38;
            case 40 -> 48;
            case 41 -> 0;
            case 42 -> 31;
            case 43 -> 18;
            case 44 -> 8;
            case 45 -> 28;
            case 46 -> 24;
            case 47 -> 11;
            case 48 -> 51;
            case 49 -> 13;
            case 50 -> 42;
            case 51 -> 16;
            case 52 -> 46;
            case 53 -> 33;
            case 54 -> 52;
            case 55 -> 4;
            case 56 -> 63;
            case 57 -> 6;
            case 58 -> 59;
            case 59 -> 56;
            case 60 -> 14;
            case 61 -> 19;
            case 62 -> 37;
            default -> 5;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        KittenAssistant.bb[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = ab;
        ab[0] = "Uwq6]w^wr6Q";
        objectArray[1] = "1\u001e\u000f(<\u0017=\u001e\u001c";
        objectArray[2] = "|\u0014I~n\u0011w\u0014J~n";
        objectArray[3] = "6so,1\"CSd# m>Kw$)$V";
        objectArray[4] = "\u00106>I)\u0016\u001b9/\u0006T\u000e\b>&O";
        objectArray[5] = "\\@d+\u001ehQ@f+\u001c";
        objectArray[6] = Float.TYPE;
        KittenAssistant.bb[6] = "java/lang/Float";
        objectArray[7] = Long.TYPE;
        KittenAssistant.bb[7] = "java/lang/Long";
        objectArray[8] = Short.TYPE;
        KittenAssistant.bb[8] = "java/lang/Short";
        objectArray[9] = Integer.TYPE;
        KittenAssistant.bb[9] = "java/lang/Integer";
        objectArray[10] = Void.TYPE;
        KittenAssistant.bb[10] = "java/lang/Void";
        objectArray[11] = Character.TYPE;
        KittenAssistant.bb[11] = "java/lang/Character";
        objectArray[12] = ">CqD\u0004'KczK\u0015h*mq@\u00112^";
        objectArray[13] = "\u001aMf*P\u0007omm%AH\u000ecf.E\u0012z";
        objectArray[14] = "\u0018\u0010k";
        objectArray[15] = "wb\"";
        objectArray[16] = Boolean.TYPE;
        KittenAssistant.bb[16] = "java/lang/Boolean";
        objectArray[17] = "c]'";
        objectArray[18] = "d\tK";
        objectArray[19] = "G*X";
        objectArray[20] = "\u0003>C2o]v\u001eH=~\u0012\u0017\u0010C6zHc";
        objectArray[21] = "\u00038R";
        objectArray[22] = "\u000e&\u0013\u001d_N\u0010.\tR#Z\n#\n\u0011";
        objectArray[23] = "\u0018]-aBN\u0011].aN";
        objectArray[24] = "\u0001JD+'BtjO$6\r\u0015dD/2Wa";
        objectArray[25] = "I\u0014\u0005Fy\u0019<4\u000eIhV]:\u0005Bl\f)";
        objectArray[26] = "e\u0019HO!yl\u0019KO!";
        objectArray[27] = "\u001b.[\u0016m1\u0010!JY\f?\u001b*N\u0003";
        objectArray[28] = "!N[\u001cuH,NY\u001cv";
        objectArray[29] = "EH|F$\u00030hwI5LQf|B1\u0016%";
        objectArray[30] = "Mub";
        objectArray[31] = "D\u000ex";
        objectArray[32] = "f`K";
        objectArray[33] = "A\u001e\u0002";
        objectArray[34] = "V\rW";
        objectArray[35] = "^&/";
        objectArray[36] = "a_K";
        objectArray[37] = "\u0015N*";
        objectArray[38] = " \u00015UGK+\u0001=";
        objectArray[39] = ",Z\r]\u001b0%Z\u000e]\b";
        objectArray[40] = "\u001c\u0013==/;\u0017\u00136";
        objectArray[41] = "~\u0007oid2\u000b'dfu}j)omq'\u001e";
        objectArray[42] = "TTd[\u0018`!toT\t/@zd_\ru4";
        objectArray[43] = "\u0014\n\u001b\u001e\u0005\u000e\n\u0002\u0001Qg\u0012\r\u001f";
        objectArray[44] = "^CyZQU\u0013\u0011\"!\u00073\u0012L`C\u0014\u0003\u0014K MnJUUyN\u0013\n\r\u0017g!";
        objectArray[45] = "(v\u007f\r*$e$$vPB%\"x\u0014v;srvL";
        objectArray[46] = "x^\u000byn_5\fP\u0002*91\n\u0016f>DqRTx";
        objectArray[47] = "R2Q\u0006d\u0010\u001f`\n}1v\u001e=H\u001f!F\u0018:\b\u0011[\u000fY$Q\u0012&O\u0001fO}";
        objectArray[48] = ")Y9L\u007f=d\u000bb7\u0006['K7Ly'g\rbK";
        objectArray[49] = "lm!\u0011eh1tu\t\u0001}W42\tz-+tt\\}\u0014iw%\u00188h)1p\u001f\u0001**`4Z}jl53c=r8f?\u0002njg`O_g{;z.\f\u007f$=\ns\u0005nx'k \u001d1~W6)\fmd6e1Sk\u0014kl \u000fqu8t\u007f\t\u0001(1e#\u0013`{):%c</4h,\u001aj\u007f:0O_g{;z.\f\u007f$=\ns\u0005nx'k \u001d1~W6)\fmd6e1Sk\u0014h;\u007fRh$,w.\\\u0001";
        objectArray[50] = "S\u0015QgY\u0014\u000e\f\u0005\u007f=\u0001hO\u0004v_\u000b\u0011\u0019Tx\u0007hT\u0014PyM\t\u0007\f\u000f\u007f=";
        objectArray[51] = "\u0014ZZB%dTS^U]6-\u0002Z\u0000&:CBQY4\\";
        objectArray[52] = "6*vC3Z{x-8k<\u007f~k\\cA?&)B";
        objectArray[53] = "+G\bB*\u0012v^\\ZN\u0004\u0010\u001a\u001cL?\u001caE\u0017A5n-\u001b\u0005R-\u0017{K\u000b\nNRvO\n@/\u0001n\u0010\f0r\b\u007fL\u0016Q!\u0010 Jf\f(\u0001|P\u0007_0^z XM$\u0015)\\\u0018\u000bq\u0012\u0010\u001fW\u0000\u007f\u0007 [\u001bQqn";
        objectArray[54] = ":53\u0017\u0013/g,g\u000fw9\u0001n;\n\u001b#`=#U\u001dS<i>\u0007\u0014*j90_wl0bl\fG(|3be";
        objectArray[55] = "#-OV\u007f{:hIU\u0018V\u001e\u0017gpD\u001d#-OV\u007f{:hIU";
        objectArray[56] = "uY;'4:8\u000b`\\n\\<\r&8d!|Ud&";
        objectArray[57] = "?! \u000fHsrs{t5\u00152u'\u0016\u0014ld%)N";
        objectArray[58] = "4)oAc8y{4:&^}}r^3#=%0@";
        objectArray[59] = "\t)\u0001J]dD{Z1\u001b\u0002@}\u001cU\r\u007f\u0000%^K";
        objectArray[60] = "Ga\b3~r\n3SH+\u0014\u000bn\u0011*;$\riQ$A+F>]!qo\noSH";
        objectArray[61] = "J-2\u001c|v\u00174f\u0004\u0018cqv:\u0001tz\u0010%\"^r\nL72\u001creH+%\u0011\u00186\u0017%0\u001eye\u000fz6n$l\u001e&,\u000fwtA \\Qi`\u001dz%Rtf\u001aJb\u0013rqH6\"U'vqv:\u0001tz\u0010%\"^r\nM,3\u0002hk\u001e4l\u0004\u00186\u0017%0\u001eye\u000fz6n&w\u001b1e\u0012f1N6\\Q):@#l\u0015ekNJ";
        objectArray[62] = "$\u0015\r.\f}*\u0010]qrdE\u0013_yId#MUp\u0013\r";
        objectArray[63] = "\u001dfD\u0006D\u0005\u001b$_\by\u0017\u007f)\u000f\u0017\u001b\u001d\u0006\u007f_\u0019C~EnH\u0005\u000b\u000f\u001aeE\u000fyD\u0005hE\u0006\b\u001b\u000eeOt\u0013\u0013\u0002hX\u0006\u001b\u0004D)4J\u0004\u0014\u0004-H\nBA\u0003\u0014";
        objectArray[64] = "2S\u001c\u001ew\u0004+\b\u0012\u0013\u0015WH\u0014\u0013\fwDx\u0012\u0014Ly>5U\b\u0014pW*\f\u001d\u001c\u0015";
        objectArray[65] = "0\nZ[}8m\u0013\u000eC\u0019.\u000bQRFu4j\u0002J\u0019sD7\u000b[Ei%d\u0013\u0004C\u0019xm\u0002XYx+u]^)%\"d\u0001DHv:;\u00074\u0015\u007f+g\u001dUFgtam\bOv({\f[W).\u000bSICb}w\u0013\u000f\u0016eD6VWKz=`\u0006Y\u0013\u0019{:]\u0005@)?v\f\u000b)";
        objectArray[66] = "h8+$_:%jp_\t\\$72=\u001al\"0r3``>8#/\u00013&g%_";
        objectArray[67] = "J\u0012'9X\u0002\u0007@|B$dGF  \u0004\u001d\u0011\u0016.x";
        objectArray[68] = "%l%MdUh>~623,o8\rbMnd<D[\nyzz\u000f%Hr~36";
        objectArray[69] = "\u00028\u0019.\b\u0010OjBUwv\u000e1\u00129G\u0017])M?";
        objectArray[70] = "x\u0015J\u001fkK5G\u0011d\f-r\u0000R\u0015&\\-\u000b_\u001f";
        objectArray[71] = "\u0005\u0006R4w X\u001f\u0006,\u00135>[F:b.O\u0004M7h\\\u0002\u0007S*c=Q\u001f\f,\u0013a\u0005\u0002^%j7U\f\u0006F/:Q\rL'|\"\u000e\u000b<";
        objectArray[72] = "97oh\f\u001ete4\u0013Lxpcrw\\\u00050;0i";
        objectArray[73] = "7%C<S j<\u0017$75\f\u007fP E6c{L7H\\2?G5\u000e ry\u001227bq(VwK\"7}QN\t!f9\u00142Ig3>-q\u0006l=+\u001d5J=3B";
        objectArray[74] = "\u000b~K]f\u0017F,\u0010&'qB*VB6\f\u0002r\u0014\\";
        objectArray[75] = "9qe\u001e\u00068t#>ew^g|z\u0017R>yydT";
        objectArray[76] = "\u000b<b)g\u0007Fn9R\u0015aT?o09\u001cU(al";
        objectArray[77] = "|i\"~;x1;y\u0005H\u001e#j/gec\"}!;";
        objectArray[78] = "^TJR \u0011\u0013\u0006\u0011)Xw\u0017\u0000WMp\nWX\u0015S";
        objectArray[79] = "rd!`WW?6z\u001b\u00031>k8y\u0012\u00018lxwh\u000b8w4i\u0019T3z>\u001b";
        objectArray[80] = "L:\u0019,k-\u0001hBW\u001fK\u0006n\u001286q\u001f5\u001c5";
        objectArray[81] = "K\u000b:1q\u001e\u0016\u0012n)\u0015\bpQo w\u0001\t\u0007?./bL\n;/e\u0003\u001f\u0012d)\u0015";
        objectArray[82] = "t>'ZK\u00029l|!0dyj C\u0017\u001d/:.\u001b";
        objectArray[83] = "IU_Hyl\u0004\u0007\u00043:\n\u0000\u0001BW)w@Y\u0000I";
        objectArray[84] = ")NP\tq=tW\u0004\u0011\u0015(\u0012\u0015X\u0014y1sF@K\u007fA.OQ\u0017e }W\u000e\u0011\u0015}tFR\u000bt.l\u0019T{)'}EN\u001az?\"C>Gs.~Y_\u0014kqx)\u0000\u0006\u007f:+U@@*=\u0012\u0014\u0005\u0018w\"kBU\u0016/A-\u0018\u000eJ|qiT_D\u0015";
        objectArray[85] = "\u000bF\\DGzF\u0014\u0007?\u0005\u001cB\u0012A[\u0017a\u0002J\u0003E";
        objectArray[86] = "|hv9$\u00161:-Bcp5<k&t\rud)8";
        objectArray[87] = "\u001bA\u001cQqbV\u0013G*\u000f\u0004AC\u0005V\"vITC\u0017";
        objectArray[88] = "\bS^5c;\u0012\u0013\u0001;Xfs\u0013\u00077:xC\u0015\u0000w4\u0002L^W{12\b\u0012\u0006uX";
        objectArray[89] = "7#Ow(jzq\u0014\f|\f{,Vnm<}+\u0016`\u001736|\u001ae'wz-\u0014\f";
        objectArray[90] = "{E\u0016\u0011(56\u0017MjXSwL\u001d\u0006g2$TB\u0000";
        Object[] objectArray2 = objectArray;
        objectArray[91] = "\u0019\u0015\u0019SY;TGB(\u0000]PA\u0004L\t \u0010\u0019FR";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = KittenAssistant.e(l2, l3);
            object = ab[n2];
            try {
                if (!(object instanceof String)) break block2;
                KittenAssistant.ab[n2] = clazz = Class.forName(bb[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = KittenAssistant.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int index = 0; index < classArray.length; ++index) {
                field = KittenAssistant.d(classArray[index], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = KittenAssistant.e(l2, l3);
        Object object = ab[n2];
        if (object instanceof String) {
            String string = bb[n2];
            int n3 = string.indexOf(8);
            Class clazz = KittenAssistant.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = KittenAssistant.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = KittenAssistant.c(clazz3, string2, clazz2)) != null) {
                    KittenAssistant.ab[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int index = 0; index < classArray.length; ++index) {
                        field = KittenAssistant.d(classArray[index], string2, clazz2);
                        if (field == null) continue;
                        KittenAssistant.ab[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = KittenAssistant.f(1970003895067746L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int parameterCount, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != parameterCount) continue;
            for (int index = 0; index < parameterCount; ++index) {
                if (classArray2[index] != classArray[index]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int parameterCount, Class[] classArray) {
        Method method = KittenAssistant.c(clazz, string, clazz2, parameterCount, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int index = 0; index < classArray2.length; ++index) {
                method = KittenAssistant.d(classArray2[index], string, clazz2, parameterCount, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = KittenAssistant.e(l2, l3);
        Object object = ab[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = bb[n2];
                int n4 = string2.indexOf(8);
                clazz3 = KittenAssistant.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int paramIndex = 0; paramIndex < n6; ++paramIndex) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = KittenAssistant.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (paramIndex < n3) {
                        classArray2[paramIndex] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = KittenAssistant.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        KittenAssistant.ab[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = KittenAssistant.f(1970003895067746L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = KittenAssistant.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        KittenAssistant.ab[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = KittenAssistant.f(1970003895067746L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == '\u00c7' || c2 == '\u00fb' || c2 == '\u00fc' || c2 == 'f') {
                field = KittenAssistant.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == '\u00c7' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == '\u00fb' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == '\u00fc' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = KittenAssistant.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == 'r' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == '\u00c9' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = KittenAssistant.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite f(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_3().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/b/m" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(KittenAssistant.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(KittenAssistant.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_2() {
        try {
            return MethodHandles.lookup().findStatic(KittenAssistant.class, "d", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_3() {
        try {
            return MethodHandles.lookup().findStatic(KittenAssistant.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

