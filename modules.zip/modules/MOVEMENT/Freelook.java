// === Kuzi module: Freelook ===
// Category   : MOVEMENT
// Description: Look around without changing movement
// Payload    : a.a.a.j.e.Q (verified: False)

package kuzi.modules.movement;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import kuzi.core.Client;
import kuzi.mixin.MixinExposed;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.module.Module;
import kuzi.modules.movement.Freecam;
import kuzi.obf.j.e.am;
import kuzi.obf.m.r;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import net.minecraft.Minecraft;
import net.minecraft.Mth;
import net.minecraft.CameraType;

public class Freelook
extends BaseModule
implements Module {
    private final BoolSetting showAllChunks;
    private final BoolSetting seeThroughWalls;
    public float o;
    public float p;
    public float q;
    public float r;
    private CameraType previousCameraType;
    private static final long t = 129977014472424L;
    private static final Object[] x = new Object[]{"'M{23;,Mp", Boolean.TYPE, "^P1\u0018G3UP5\u0018w", "/ab!\n\u0016&aa!\b", "1\u001fD{fj:\u001fL", "ac=1\b6\u0014C6>\u0019yuM=5\u001d#\u0001", Void.TYPE, "\u0016XmOq/\u001fXnOq", ".\u000bk\u0016C}%\u0004zY\"s.\u000f~\u0003", Float.TYPE, "qidp\u0018yzi`p\u0018:", "u\u0017Zt*\u0013~\u0018K;W\u000bm\u001fBr", "J\u000efrS\u001fJ\u000eq._\u0010PEq0_\u0005W4!m\u000e", "0.-Gy\u001a0.:\u001bu\u0015*e:\u0005u\u0000-\u0014l]-K", "6#P\nF\u0001:#C", "z\u001cC\u001fCl MN\u000b&eCHD\u001fJ|sL\u0013\u0004\u001a", "\u0019[GqjqC^^}\ng&[_.g2D[Jb6\r", "FO:#o_JG6\u001eobFGj%|\rHZ1y", "\u0018QLX\u0019P\u0014Y@e\u0012m\u0014L\u001f_\u0015UTL\u0013\np", "\u001aI\u00131(?IP\fqWDgh>\u000b\u001aG|6I17~_\b\u001a((>", "\tI)>73S\u0018$*R90\u001d.>>#\u0000\u0019y%n", "3E\n|\u001a~i\u0014\u0007h\u007fj\n\u0015J\u007f\u001eooJIm\u0004", "a?NHePm7Bugm >\u001c\u0007iP1~A", "AZ\f\bo>\u001b\u000b\u0001\u001c\n)x\u0005\b\u0013{m\u001b\u0004\\Id", "5Jj\bP\"9Bf5U\u001ftK8G\\\"e\u000be5", "\u001ejcr-,D;nfH9':#q)=Be c3", "\"M0gp\u000fx\u001c=s\u0015\n\u001bJ3be\u0007cH2'$cr\u001crlq\u001bp\u001d7-\u0015", "i?OH1\u00133nB\\T\u0018Po\u000fK5\u000250\fY/", "C\u0000|x1D\u0004FxlTG\u007fB;tkBF\u0010|z5.", "@\u000bFlJ\u0004L\u0003JQG9K\n\u0010j@\u0004\u0010GHi#\u0005\u001c\u0018M4\u001bE\u001c\u0014\u0018Q", "kGI%\u0010\u00171\u0016D1u\u0001R\u0017\t&\u0014\u00067H\n4\u000e"};
    private static final String[] y = new String[]{null, "java/lang/Boolean", null, null, null, null, "java/lang/Void", null, null, "java/lang/Float", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null};

    public Freelook() {
        long l2 = t ^ 0x51FFEFF7A621L;
        long l3 = l2 ^ 0x62A454CF3DCL;
        super("Freelook", "Look around without changing movement", Category.MOVEMENT);
        this.showAllChunks = new BoolSetting("Show All Chunks", true);
        this.seeThroughWalls = new BoolSetting("See Through Walls", false);
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.showAllChunks, this.seeThroughWalls};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        block13: {
            Freelook self;
            block11: {
                block12: {
                    Object object;
                    String string;
                    block9: {
                        block10: {
                            block7: {
                                block8: {
                                    string = am.b();
                                    if (string == null) break block7;
                                    if (BaseModule.a.player == null) break block8;
                                    object = BaseModule.a.options;
                                    if (string == null) break block9;
                                    if (object != null) break block10;
                                }
                                this.j();
                            }
                            return;
                        }
                        this.o = BaseModule.a.player.getYRot();
                        this.p = BaseModule.a.player.getXRot();
                        this.q = this.o;
                        this.r = this.p;
                        this.previousCameraType = BaseModule.a.options.getCameraType();
                        BaseModule.a.options.setCameraType(CameraType.THIRD_PERSON_BACK);
                        Client.a().a(Module.class, this);
                        self = this;
                        if (string == null) break block11;
                        object = self.m.a();
                    }
                    if (!((Boolean)object).booleanValue()) break block12;
                    BaseModule.a.smartCull = false;
                    if (string == null) break block13;
                    if (BaseModule.a.levelRenderer != null) {
                        BaseModule.a.levelRenderer.needsUpdate();
                    }
                }
                self = this;
            }
            super.d();
        }
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public void e() {
        block16: {
            block14: {
                block15: {
                    block13: {
                        block12: {
                            block10: {
                                block11: {
                                    block9: {
                                        v0 = am.b();
                                        Client.a().b(Module.class, this);
                                        var3_1 = v0;
                                        v1 = BaseModule.a;
                                        if (var3_1 == null) break block9;
                                        if (v1 == null) break block10;
                                        v1 = BaseModule.a;
                                    }
                                    if (v1.options == null) break block10;
                                    if (this.previousCameraType == null) break block11;
                                    BaseModule.a.options.setCameraType(this.previousCameraType);
                                    if (var3_1 != null) break block10;
                                }
                                BaseModule.a.options.setCameraType(CameraType.FIRST_PERSON);
                            }
                            v2 = Client.a();
                            if (var3_1 == null) ** GOTO lbl20
                            if (v2 != null) {
                                v2 = Client.a();
lbl20:
                                // 2 sources

                                v3 = (Freecam)v2.a(Freecam.class);
                            } else {
                                v3 = null;
                            }
                            v4 = var4_2 = v3;
                            if (var3_1 == null) break block12;
                            if (v4 == null) break block13;
                            v4 = var4_2;
                        }
                        if (v4.d()) break block14;
                    }
                    v5 = BaseModule.a;
                    if (var3_1 == null) break block15;
                    if (v5 == null) break block14;
                    BaseModule.a.smartCull = true;
                    if (var3_1 == null) break block16;
                    v5 = BaseModule.a;
                }
                if (v5.levelRenderer != null) {
                    BaseModule.a.levelRenderer.needsUpdate();
                }
            }
            super.e();
        }
    }

    @Override
    public void b() {
        block2: {
            block3: {
                String string = am.b();
                if (!((Boolean)this.showAllChunks.a()).booleanValue()) break block2;
                Minecraft mc = BaseModule.a;
                if (string == null) break block3;
                if (mc == null) break block2;
                mc = BaseModule.a;
            }
            mc.smartCull = false;
        }
    }

    @MixinExposed
    public boolean a() {
        return this.c;
    }

    @MixinExposed
    public boolean f() {
        return (Boolean)this.seeThroughWalls.a();
    }

    @MixinExposed
    public void a(double d2, double d3) {
        this.q = this.o;
        this.r = this.p;
        this.o += (float)d2;
        this.p += (float)d3;
        this.o = Mth.wrapDegrees((float)this.o);
        this.p = Mth.clamp((float)this.p, (float)-90.0f, (float)90.0f);
    }

    @MixinExposed
    public double a(float f2) {
        return this.o;
    }

    @MixinExposed
    public double b(float f2) {
        return this.p;
    }

    private static r a(r r2) {
        return r2;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = Freelook.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = Freelook.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = Freelook.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = Freelook.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }
}

