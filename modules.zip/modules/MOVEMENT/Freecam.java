// === Kuzi module: Freecam ===
// Category   : MOVEMENT
// Description: Move freely
// Payload    : a.a.a.j.e.P (verified: True)

package kuzi.modules.movement;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.core.Client;
import kuzi.mixin.MixinExposed;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.module.Module;
import kuzi.modules.movement.Freelook;
import kuzi.obf.g.a.e;
import kuzi.obf.g.a.j;
import kuzi.obf.g.a.p;
import kuzi.obf.g.a.s;
import kuzi.obf.h.b.v;
import kuzi.obf.j.e.am;
import kuzi.obf.p.L;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.KeyEvent;
import net.minecraft.Vec3;
import net.minecraft.KeyMapping;
import net.minecraft.Minecraft;
import net.minecraft.Options;
import net.minecraft.Mth;
import net.minecraft.InputConstants;
import net.minecraft.CameraType;
import net.minecraft.LocalPlayer;
import org.joml.Vector3d;
import org.joml.Vector3dc;
import org.lwjgl.glfw.GLFW;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class Freecam
extends BaseModule
implements Module,
p,
s {
    public final Vector3d m;
    public final Vector3d n;
    private final SliderSetting speed;
    private final BoolSetting staySneaking;
    private final BoolSetting showSelf;
    private final BoolSetting keepWalking;
    public float s;
    public float t;
    public float u;
    public float v;
    private CameraType previousCameraType;
    private boolean movingForward;
    private boolean movingBackward;
    private boolean movingRight;
    private boolean movingLeft;
    private boolean jumping;
    private boolean sneaking;
    private int D;
    private long lastMoveTimeMs;
    private double fovEffectScale;
    private boolean bobView;
    private boolean sneakKeyDown;
    private boolean forwardKeyDown;
    private boolean backKeyDown;
    private boolean leftKeyDown;
    private boolean rightKeyDown;
    private static final long M;
    private static final String[] N;
    private static final String[] O;
    private static final Map P;
    private static final long[] Q;
    private static final Integer[] R;
    private static final Map S;
    private static final Object[] T;
    private static final String[] U;

    public Freecam() {
        long l2 = M ^ 0x57459008C97CL;
        long l3 = l2 ^ 0x1E03954B8B11L;
        super("Freecam", "Move freely", Category.MOVEMENT);
        this.m = new Vector3d();
        this.n = new Vector3d();
        this.speed = new SliderSetting("Speed", 5.0, 0.05, 20.0, 0.05);
        this.staySneaking = new BoolSetting("Stay Sneaking", true);
        this.showSelf = new BoolSetting("Show Self", true);
        this.keepWalking = new BoolSetting("Keep Walking", false);
        this.fovEffectScale = 1.0;
        this.bobView = true;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.speed, this.staySneaking, this.showSelf, this.keepWalking};
        objectArray[0] = l3;
        this.l(objectArray);
        Client.a();
    }

    /*
     * Exception decompiling
     */
    @Override
    public void d() {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Statement already marked as first in another block
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.markFirstStatementInBlock(Op03SimpleStatement.java:461)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc.markWholeBlock(Misc.java:251)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.considerAsSimpleIf(ConditionalRewriter.java:673)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.identifyNonjumpingConditionals(ConditionalRewriter.java:56)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:722)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public void e() {
        block20: {
            block21: {
                block19: {
                    block18: {
                        block17: {
                            block16: {
                                block15: {
                                    block14: {
                                        block13: {
                                            var1_1 = Freecam.M ^ 24552913051291L;
                                            var3_2 = var1_1 ^ 59321833618673L;
                                            var6_3 = Client.a();
                                            var5_4 = am.b();
                                            var6_3.b(Module.class, this);
                                            var6_3.b(p.class, this);
                                            var6_3.b(s.class, this);
                                            v0 = new Object[1];
                                            v0[0] = var3_2;
                                            this.a(v0);
                                            this.sneakKeyDown = false;
                                            this.rightKeyDown = false;
                                            this.leftKeyDown = false;
                                            this.backKeyDown = false;
                                            this.forwardKeyDown = false;
                                            v1 = BaseModule.a;
                                            if (var5_4 != null) {
                                                if (v1.options != null) {
                                                    BaseModule.a.options.fovEffectScale().set((Object)this.fovEffectScale);
                                                    BaseModule.a.options.bobView().set((Object)this.bobView);
                                                }
                                                v1 = BaseModule.a;
                                            }
                                            v2 = v1.levelRenderer;
                                            if (var5_4 == null) break block13;
                                            if (v2 == null) break block14;
                                            v2 = BaseModule.a.levelRenderer;
                                        }
                                        v2.needsUpdate();
                                    }
                                    v3 = Client.a();
                                    if (var5_4 == null) ** GOTO lbl35
                                    if (v3 != null) {
                                        v3 = Client.a();
lbl35:
                                        // 2 sources

                                        v4 = (Freelook)v3.a(Freelook.class);
                                    } else {
                                        v4 = null;
                                    }
                                    v5 = var7_5 = v4;
                                    if (var5_4 == null) break block15;
                                    if (v5 == null) break block16;
                                    v5 = var7_5;
                                }
                                if (v5.d()) break block17;
                            }
                            BaseModule.a.smartCull = true;
                        }
                        this.n.set((Vector3dc)this.m);
                        this.u = this.s;
                        this.v = this.t;
                        if (this.previousCameraType == null) break block18;
                        v6 = BaseModule.a.options;
                        if (var5_4 == null) break block19;
                        if (v6 == null) break block18;
                        BaseModule.a.options.setCameraType(this.previousCameraType);
                        if (var5_4 != null) break block20;
                    }
                    v6 = BaseModule.a.options;
                }
                if (var5_4 == null) break block21;
                if (v6 == null) break block20;
                v6 = BaseModule.a.options;
            }
            v6.setCameraType(CameraType.FIRST_PERSON);
        }
        super.e();
    }

    private void a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = M ^ l2;
        String string = am.b();
        Options ReplaceBlockFeature = BaseModule.a.options;
        if (string != null) {
            if (ReplaceBlockFeature == null) {
                return;
            }
            BaseModule.a.options.keyUp.setDown(false);
            BaseModule.a.options.keyDown.setDown(false);
            BaseModule.a.options.keyRight.setDown(false);
            BaseModule.a.options.keyLeft.setDown(false);
            BaseModule.a.options.keyJump.setDown(false);
            ReplaceBlockFeature = BaseModule.a.options;
        }
        ReplaceBlockFeature.keyShift.setDown(false);
    }

    /*
     * Exception decompiling
     */
    private void c(Object[] var1_1) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Statement already marked as first in another block
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.markFirstStatementInBlock(Op03SimpleStatement.java:461)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc.markWholeBlock(Misc.java:251)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.considerAsSimpleIf(ConditionalRewriter.java:673)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.identifyNonjumpingConditionals(ConditionalRewriter.java:56)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:722)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Loose catch block
     * Could not resolve type clashes
     */
    private boolean a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        KeyMapping mc3042 = (KeyMapping)objectArray[1];
        l2 = M ^ l2;
        String string = am.b();
        if (mc3042 == null || BaseModule.a.getWindow() == null) {
            return false;
        }
        try {
            boolean bl;
            block24: {
                block25: {
                    long l3;
                    InputConstants.mc306 FunctionCommand;
                    block21: {
                        boolean bl2;
                        block22: {
                            block23: {
                                block26: {
                                    block20: {
                                        boolean bl3;
                                        block19: {
                                            block18: {
                                                InputConstants.mc306 mc3063;
                                                block17: {
                                                    FunctionCommand = InputConstants.getKey((String)mc3042.saveString());
                                                    try {
                                                        mc3063 = FunctionCommand;
                                                        if (l2 <= 0L || string == null) break block17;
                                                        if (mc3063 == null) break block18;
                                                    }
                                                    catch (Throwable throwable) {
                                                        throw Freecam.a(throwable);
                                                    }
                                                    mc3063 = FunctionCommand;
                                                }
                                                try {
                                                    bl3 = mc3063.equals((Object)InputConstants.UNKNOWN);
                                                    if (string == null) break block19;
                                                    if (!bl3) break block20;
                                                }
                                                catch (Throwable throwable) {
                                                    throw Freecam.a(throwable);
                                                }
                                            }
                                            bl3 = false;
                                        }
                                        return bl3;
                                    }
                                    l3 = BaseModule.a.getWindow().handle();
                                    if (l2 <= 0L || FunctionCommand.getType() != InputConstants.mc307.MOUSE) break block21;
                                    bl2 = GLFW.glfwGetMouseButton((long)l3, (int)FunctionCommand.getValue());
                                    if (string == null) break block22;
                                    break block26;
                                    catch (Throwable throwable) {
                                        throw Freecam.a(throwable);
                                    }
                                }
                                try {
                                    block27: {
                                        if (!bl2) break block23;
                                        break block27;
                                        catch (Throwable throwable) {
                                            throw Freecam.a(throwable);
                                        }
                                    }
                                    bl2 = true;
                                    break block22;
                                }
                                catch (Throwable throwable) {
                                    throw Freecam.a(throwable);
                                }
                            }
                            bl2 = false;
                        }
                        return bl2;
                    }
                    bl = GLFW.glfwGetKey((long)l3, (int)FunctionCommand.getValue());
                    if (string == null) break block24;
                    try {
                        block28: {
                            if (!bl) break block25;
                            break block28;
                            catch (Throwable throwable) {
                                throw Freecam.a(throwable);
                            }
                        }
                        bl = true;
                        break block24;
                    }
                    catch (Throwable throwable) {
                        throw Freecam.a(throwable);
                    }
                }
                bl = false;
            }
            return bl;
        }
        catch (Throwable throwable) {
            return false;
        }
    }

    @Override
    public void h() {
        block3: {
            Freecam freecam;
            block2: {
                String string = am.b();
                freecam = this;
                if (string == null) break block2;
                if (!freecam.d()) break block3;
                freecam = this;
            }
            freecam.j();
        }
    }

    @Override
    public void b() {
        block19: {
            Minecraft mc3102;
            Options ReplaceBlockFeature;
            String string;
            block18: {
                block17: {
                    boolean bl;
                    block16: {
                        long l2 = M ^ 0x70CBE9D301BCL;
                        long l3 = l2 ^ 0x536CB2ABE3D6L;
                        string = am.b();
                        LocalPlayer mc7462 = BaseModule.a.player;
                        if (string != null) {
                            if (mc7462 == null) {
                                return;
                            }
                            mc7462 = BaseModule.a.player;
                        }
                        bl = mc7462.isDeadOrDying();
                        if (string != null) {
                            if (bl) {
                                this.j();
                                return;
                            }
                            Object[] objectArray = new Object[1];
                            objectArray[0] = l3;
                            this.a(objectArray);
                            bl = (Boolean)this.staySneaking.a();
                        }
                        if (string == null) break block16;
                        if (!bl) break block17;
                        bl = this.sneakKeyDown;
                    }
                    if (!bl) break block17;
                    ReplaceBlockFeature = BaseModule.a.options;
                    if (string == null) break block18;
                    if (ReplaceBlockFeature != null) {
                        BaseModule.a.options.keyShift.setDown(true);
                    }
                }
                mc3102 = BaseModule.a;
                if (string == null) break block19;
                ReplaceBlockFeature = mc3102.options;
            }
            if (ReplaceBlockFeature != null) {
                boolean bl = this.forwardKeyDown;
                if (string != null) {
                    if (bl) {
                        BaseModule.a.options.keyUp.setDown(true);
                    }
                    bl = this.backKeyDown;
                }
                if (string != null) {
                    if (bl) {
                        BaseModule.a.options.keyDown.setDown(true);
                    }
                    bl = this.leftKeyDown;
                }
                if (string != null) {
                    if (bl) {
                        BaseModule.a.options.keyLeft.setDown(true);
                    }
                    bl = this.rightKeyDown;
                }
                if (bl) {
                    BaseModule.a.options.keyRight.setDown(true);
                }
            }
            mc3102 = BaseModule.a;
        }
        mc3102.smartCull = false;
    }

    @MixinExposed
    public boolean a() {
        return (Boolean)this.showSelf.a();
    }

    @MixinExposed
    public void a(int n2) {
        double d2 = Math.max(0.25, (Double)this.speed.a() * 0.15);
        this.speed.a((Double)this.speed.a() + (double)n2 * d2);
    }

    @Override
    public void a(j j2) {
        double d2;
        float f2;
        block17: {
            Freecam freecam;
            boolean bl;
            double d3;
            double d4;
            double d5;
            block16: {
                long l2;
                long l3 = l2 = M ^ 0x7FF0D4CD704BL;
                long l4 = l3 ^ 0x658AAF23B065L;
                long l5 = l3 ^ 0x28DA48B95CAFL;
                Object[] objectArray = new Object[1];
                objectArray[0] = l4;
                this.c(objectArray);
                this.n.set((Vector3dc)this.m);
                this.u = this.s;
                String string = am.b();
                this.v = this.t;
                long l6 = System.currentTimeMillis();
                f2 = (float)(l6 - this.lastMoveTimeMs) / 1000.0f;
                this.lastMoveTimeMs = l6;
                float f3 = f2 = Math.min(f2, 0.1f);
                float f4 = 0.001f;
                if (string != null) {
                    if (f3 < f4) {
                        f2 = 0.016f;
                    }
                    f3 = 0.0f;
                    f4 = this.s;
                }
                Vec3 VanillaChestLoot = Vec3.directionFromRotation((float)f3, (float)f4);
                Vec3 PlayerWallHeadBlock = Vec3.directionFromRotation((float)0.0f, (float)(this.s + 90.0f));
                d5 = 0.0;
                d4 = 0.0;
                d2 = 0.0;
                double d6 = (Double)this.speed.a();
                double d7 = 2.0;
                if (string != null) {
                    d6 = d6 * d7;
                    Object[] objectArray2 = new Object[2];
                    objectArray2[1] = BaseModule.a.options.keySprint;
                    objectArray2[0] = l5;
                    d7 = this.a(objectArray2) ? 2.0 : 1.0;
                }
                d3 = d6 * d7;
                bl = this.movingForward;
                if (string != null) {
                    if (bl) {
                        d5 += VanillaChestLoot.x * d3;
                        d2 += VanillaChestLoot.z * d3;
                    }
                    bl = this.movingBackward;
                }
                if (string != null) {
                    if (bl) {
                        d5 -= VanillaChestLoot.x * d3;
                        d2 -= VanillaChestLoot.z * d3;
                    }
                    bl = this.movingRight;
                }
                if (string != null) {
                    if (bl) {
                        d5 += PlayerWallHeadBlock.x * d3;
                        d2 += PlayerWallHeadBlock.z * d3;
                    }
                    bl = this.movingLeft;
                }
                if (string != null) {
                    if (bl) {
                        d5 -= PlayerWallHeadBlock.x * d3;
                        d2 -= PlayerWallHeadBlock.z * d3;
                    }
                    bl = this.jumping;
                }
                if (string == null) break block16;
                if (bl) {
                    d4 += d3;
                }
                freecam = this;
                if (string == null) break block17;
                bl = freecam.sneaking;
            }
            if (bl) {
                d4 -= d3;
            }
            this.m.x += d5 * (double)f2 * 5.0;
            this.m.y += d4 * (double)f2 * 5.0;
            freecam = this;
        }
        freecam.m.z += d2 * (double)f2 * 5.0;
    }

    @Override
    public void a(e e2) {
        block23: {
            boolean bl;
            block13: {
                boolean bl2;
                block22: {
                    String string;
                    block20: {
                        block21: {
                            block18: {
                                block19: {
                                    block16: {
                                        block17: {
                                            block14: {
                                                block15: {
                                                    block11: {
                                                        block12: {
                                                            long l2 = M ^ 0x62009738F969L;
                                                            long l3 = l2 ^ 0x62170CFCDECBL;
                                                            string = am.b();
                                                            Object[] objectArray = new Object[2];
                                                            objectArray[1] = l3;
                                                            objectArray[0] = 292;
                                                            if (kuzi.obf.p.L.a(objectArray)) {
                                                                return;
                                                            }
                                                            if (BaseModule.a.options == null) {
                                                                return;
                                                            }
                                                            bl = true;
                                                            bl2 = BaseModule.a.options.keyUp.matches(new KeyEvent(e2.c, 0, 0));
                                                            if (string == null) break block11;
                                                            if (!bl2) break block12;
                                                            int n2 = e2.d;
                                                            if (string != null) {
                                                                n2 = n2 != 0 ? 1 : 0;
                                                            }
                                                            this.movingForward = n2;
                                                            BaseModule.a.options.keyUp.setDown(false);
                                                            if (string != null) break block13;
                                                        }
                                                        bl2 = BaseModule.a.options.keyDown.matches(new KeyEvent(e2.c, 0, 0));
                                                    }
                                                    if (string == null) break block14;
                                                    if (!bl2) break block15;
                                                    int n3 = e2.d;
                                                    if (string != null) {
                                                        n3 = n3 != 0 ? 1 : 0;
                                                    }
                                                    this.movingBackward = n3;
                                                    BaseModule.a.options.keyDown.setDown(false);
                                                    if (string != null) break block13;
                                                }
                                                bl2 = BaseModule.a.options.keyRight.matches(new KeyEvent(e2.c, 0, 0));
                                            }
                                            if (string == null) break block16;
                                            if (!bl2) break block17;
                                            int n4 = e2.d;
                                            if (string != null) {
                                                n4 = n4 != 0 ? 1 : 0;
                                            }
                                            this.movingRight = n4;
                                            BaseModule.a.options.keyRight.setDown(false);
                                            if (string != null) break block13;
                                        }
                                        bl2 = BaseModule.a.options.keyLeft.matches(new KeyEvent(e2.c, 0, 0));
                                    }
                                    if (string == null) break block18;
                                    if (!bl2) break block19;
                                    int n5 = e2.d;
                                    if (string != null) {
                                        n5 = n5 != 0 ? 1 : 0;
                                    }
                                    this.movingLeft = n5;
                                    BaseModule.a.options.keyLeft.setDown(false);
                                    if (string != null) break block13;
                                }
                                bl2 = BaseModule.a.options.keyJump.matches(new KeyEvent(e2.c, 0, 0));
                            }
                            if (string == null) break block20;
                            if (!bl2) break block21;
                            int n6 = e2.d;
                            if (string != null) {
                                n6 = n6 != 0 ? 1 : 0;
                            }
                            this.jumping = n6;
                            BaseModule.a.options.keyJump.setDown(false);
                            if (string != null) break block13;
                        }
                        bl2 = BaseModule.a.options.keyShift.matches(new KeyEvent(e2.c, 0, 0));
                    }
                    if (string == null) break block13;
                    if (!bl2) break block22;
                    int n7 = e2.d;
                    if (string != null) {
                        n7 = n7 != 0 ? 1 : 0;
                    }
                    this.sneaking = n7;
                    BaseModule.a.options.keyShift.setDown(false);
                    if (string != null) break block13;
                }
                bl2 = bl = false;
            }
            if (!bl) break block23;
            e2.a();
        }
    }

    @MixinExposed
    public void a(double d2, double d3) {
        this.s += (float)d2;
        this.t += (float)d3;
        this.s = Mth.wrapDegrees((float)this.s);
        this.t = Mth.clamp((float)this.t, (float)-90.0f, (float)90.0f);
    }

    @MixinExposed
    public double a(float f2) {
        return this.m.x;
    }

    @MixinExposed
    public double b(float f2) {
        return this.m.y;
    }

    @MixinExposed
    public double c(float f2) {
        return this.m.z;
    }

    @MixinExposed
    public double d(float f2) {
        return this.s;
    }

    @MixinExposed
    public double e(float f2) {
        return this.t;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block16: {
            block15: {
                block14: {
                    block13: {
                        Freecam.M = kuzi.obf.h.b.v.a(-2584971314981980176L, 3886519453439053563L, MethodHandles.lookup().lookupClass()).a(55210560556519L);
                        Freecam.T = new Object[63];
                        Freecam.U = new String[63];
                        Freecam.c();
                        Freecam.P = new HashMap<K, V>(13);
                        var11 = Freecam.M ^ 99075979709979L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[6];
                        var18_4 = 0;
                        var17_5 = "2=\u00a3UX\u00fa9\u009a\u009c\u001e\u00cc\u0090wU\u00a3\u00f0 YqO\n\u00fa\t\u001e\u0013\u00db\u00c1\u0005\u00a8B\u00eeY\u0084\u0017\u00c1?\u0097\u00a6`\u008b\u0016\u0000\u00d1\u00d1r3\u0012,\u001b \u00e7\u00fb|\u00fd*\u0016 g\u00b1\u00ee\u00d6\u00d8#\u00d5S\u00ab\u000b\u00cd.\u00e4\u00c0\u00e6\u0000W\u00e3\u00a1\u00f7p\f\\PC\u0018W\u009f0\u00e5A\u00a6\u0092\u0092\u00d8!I]\u00aa\u00ee\u00ba\u00cf}!\u008bJ\u0010\u008c\u00fd\u0093";
                        var19_6 = "2=\u00a3UX\u00fa9\u009a\u009c\u001e\u00cc\u0090wU\u00a3\u00f0 YqO\n\u00fa\t\u001e\u0013\u00db\u00c1\u0005\u00a8B\u00eeY\u0084\u0017\u00c1?\u0097\u00a6`\u008b\u0016\u0000\u00d1\u00d1r3\u0012,\u001b \u00e7\u00fb|\u00fd*\u0016 g\u00b1\u00ee\u00d6\u00d8#\u00d5S\u00ab\u000b\u00cd.\u00e4\u00c0\u00e6\u0000W\u00e3\u00a1\u00f7p\f\\PC\u0018W\u009f0\u00e5A\u00a6\u0092\u0092\u00d8!I]\u00aa\u00ee\u00ba\u00cf}!\u008bJ\u0010\u008c\u00fd\u0093".length();
                        var16_7 = 16;
                        var15_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block13;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = Freecam.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "\u00b7\u00ccQ\u0089U&\u00e1\u00d3\u00da\\\u0089\u00c4f\u008f\u00e9\u00bbUo\u00ef\u00d0\n\u00c4\u00d6w\u00108hk}{\u00c1\u0094\u0084\u00d5\u0018\u00c0$\u00a9\u00fa\u00ef\"";
                            var19_6 = "\u00b7\u00ccQ\u0089U&\u00e1\u00d3\u00da\\\u0089\u00c4f\u008f\u00e9\u00bbUo\u00ef\u00d0\n\u00c4\u00d6w\u00108hk}{\u00c1\u0094\u0084\u00d5\u0018\u00c0$\u00a9\u00fa\u00ef\"".length();
                            var16_7 = 24;
                            var15_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block13;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = Freecam.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block14;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                Freecam.N = var20_3;
                Freecam.O = new String[6];
                Freecam.S = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[2];
                var3_13 = 0;
                var4_14 = "#\u00ac#\u0097B\u00cbg\u00e7\u00beZ+\u00d6\u00f8]\u001bL";
                var5_15 = "#\u00ac#\u0097B\u00cbg\u00e7\u00beZ+\u00d6\u00f8]\u001bL".length();
                var2_16 = 0;
                while (true) {
                    break block15;
                    break;
                }
lbl76:
                // 1 sources

                while (true) {
                    var6_12[v10] = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
                    if (var2_16 < var5_15) ** continue;
                    break block16;
                    break;
                }
            }
            var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
            v10 = var3_13++;
            var8_18 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            ** while (true)
        }
        Freecam.Q = var6_12;
        Freecam.R = new Integer[2];
    }

    private static Throwable a(Throwable throwable) {
        return throwable;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x341B;
        if (R[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = Q[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])S.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    S.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/e/P", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            Freecam.R[n3] = n4;
        }
        return R[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = Freecam.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/e/P" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static void c() {
        Object[] objectArray = T;
        T[0] = "E/0'\ftN/4'=";
        objectArray[1] = Boolean.TYPE;
        Freecam.U[1] = "java/lang/Boolean";
        objectArray[2] = "\u001b~\u0018\u0006={\u0010q\tIG\u007f\u0003p\u0019\u0006q{\u0014";
        objectArray[3] = "\u0007v~Mr\u0005\u0016vS";
        objectArray[4] = "\f{De\u001coy[Oj\r \u0018UDa\tzl";
        objectArray[5] = "Wk\u0010(S>\\k\u0014(S}";
        objectArray[6] = "PBl%a~[M}j\u001cfHJt#";
        objectArray[7] = "tx}G~?\u007fxv";
        objectArray[8] = "TJ#\u000bV^TJ4WZQN\u00014IZDIpd\u0014\u000b";
        objectArray[9] = "\u0019%\u0001D{\bl\u0005\nKjG\r\u000b\u0001@n\u001dy";
        objectArray[10] = Float.TYPE;
        Freecam.U[10] = "java/lang/Float";
        objectArray[11] = Void.TYPE;
        Freecam.U[11] = "java/lang/Void";
        objectArray[12] = "c=ij3Pj=jj1";
        objectArray[13] = "&Zt#bs/Zw#b";
        objectArray[14] = "!uZ\u001fyS*zKP\u0018]!qO\n";
        objectArray[15] = "NMl~\u0011#;mgq\u0000lZclz\u00046.";
        objectArray[16] = " U`CO\u000b\"K);@\u0007;Hu^A";
        objectArray[17] = "\u001bb\\\u0010\u0010lnBW\u001f\u0001#\u000fL\\\u0014\u0005y{";
        objectArray[18] = "\u007f<'g\u001d1v<$g\u0011";
        objectArray[19] = Long.TYPE;
        Freecam.U[19] = "java/lang/Long";
        objectArray[20] = "w&\u001c}P\u000e|&\u0014";
        objectArray[21] = Double.TYPE;
        Freecam.U[21] = "java/lang/Double";
        objectArray[22] = "Rric9u'Rbl(:F\\ig,`2";
        objectArray[23] = "G\u000f}^JmL\u0000l\u0011 nX\fgZ";
        objectArray[24] = "Er3I|QEr$\u0015p^_9$\u000bpKXHrS(\u0000";
        objectArray[25] = "/H\f{\u0018>qXF\u001a\tG/F]b\u0010&h\u0016\u0007 ";
        objectArray[26] = "`\u000fQ\u000e~\u0000>\u001f\u001bo_y$\u000e\u0002\u0010kA3\u0010^";
        objectArray[27] = "5\u0002>a1\u0002k\u0012t\u0000\u0019{q\u0003m\u007f$Cf\u001d1";
        objectArray[28] = "\nr \u001ff\u0007Tbj~O~Nss\u0001sFYm/";
        objectArray[29] = "Vk\u0006La\u0018\b{L-la\u0002xVOh\u0004\u0018~\tU";
        objectArray[30] = ")<(Q2\u001ew,b0%g)2yH:\u0006nb#\n";
        objectArray[31] = "\u000ex_/\u0004JPh\u0015N\u00163\u0001m\u0014rTX\u0000p\u00156";
        objectArray[32] = "|Bk2;{\"R!S!\u00028C8,.:/]d";
        objectArray[33] = "#b]p\u0005\u0004}r\u0017\u0011\u001d}gc\u000en\u0010Ep}R";
        objectArray[34] = "\u0003@7RJr]P}3d\u000bGAdL_3P_8";
        objectArray[35] = "K=pI5'\u000b<|\u0012N/z;0I%v\u0004mq\u0005*F";
        objectArray[36] = "3FW.\fomV\u001dO)\u0016wG\u00040\u0019.`YX";
        objectArray[37] = "tRj\\\u001d\\*B =\u0011%!]:\u0001I\u001f1R<[";
        objectArray[38] = ".\nI\u001d\u0018,p\u001a\u0003|\u001bU\u007f\u001d\u001c\u001eKds\u000e\b\u0010re+T\u0004CL3vX\u0012|";
        objectArray[39] = "\\)\u0017o\u0011v\u00029]\u000e\u0002\u000fS<\\2AdR!]v";
        objectArray[40] = "|\u0015N\u0011!V\"\u0005\u0004p\u0006//\u001f\u001b\u001a$^/\u001bA\n";
        objectArray[41] = "p!\bw\"k.1B\u0016\u0001\u00124 [i7*#>\u0007";
        objectArray[42] = "rW\u001bk#I,GQ\n,0'XK6w\n7WMl";
        objectArray[43] = "=\u0016!\u0002@X'\u0010~\u0018#TV\u0004 \u0010FXk\u0006%\u001dY=fQq\u001d\u001c\u00030\f}\u000b#";
        objectArray[44] = "4[FB\u0000|jK\f#\u0003\u00052R\u000bJ\u0001a;H\u000fSj<lH\u001fH\u000e5vL\u0006#";
        objectArray[45] = "\u0006\u0019!X5zZL?\\Dx<\u001d&_&(\r\u00115K(\u0011G\u001c<E;)P\u0002`:";
        objectArray[46] = "iLcx?BhV?bYVR\b'pgU0\u000e=b`<";
        objectArray[47] = "Xy\\n!=\u001cmYlJ5e)\u0005\u007f#`^yW%,";
        objectArray[48] = "\n{[dmsTk\u0011\u0005v\nNz\bzx2YdT";
        objectArray[49] = "\u0003NX6u6GZ]4\u001e5>\u0010\u0000vch\u0000F]zuW";
        objectArray[50] = "GUBW\\\u0015\u0010LI\u00002>lum\"\u007f=w+L\u0019PKEE\u001b\u0000[\u001c";
        objectArray[51] = "O=`#W@\u0011-*BT9\u001e*5 \u0004\b\u00129!.=B\u001f0/=\u0005U\u0001lP";
        objectArray[52] = "0N_0kgn^\u0015Q@\u001etO\f.~&cQP";
        objectArray[53] = "}:*:>(#*`[?Q,-\u007f9m` >k7Taxdgdj7%hq[";
        objectArray[54] = "{V\n$*\u007f%F@E\u000e\u0006)[\u0006=zo:JX}";
        objectArray[55] = "k\u0002'J`\u0007/\u0016\"H\u000b\nV\u0017*Yt\u0019n\u00004\u0005\u000b";
        objectArray[56] = "\u0013K\u000e\u0006Z\u001dM[DgJd\u001c^E[\n\u000f\u001dCD\u001f";
        objectArray[57] = "F\u0010\u007f\u001aK\u007f\u0018\u00005{a\u0006\u0002\u0011,\u0004^>\u0015\u000fp";
        objectArray[58] = "JFi,>P\u0014V#M\u001e)\u000eG:2+\u0011\u0019Yf";
        objectArray[59] = "-[\u0014$C\u0000sK^EUy-UE=K\u0018j\u0005\u001f\u007f";
        objectArray[60] = "Xtw,e\u0014\u0006d=Mpm\u0007&#7?\u0012\u0007w\"+";
        objectArray[61] = "(\"j,5Rv2 M!+(,;5=Jo|aw";
        Object[] objectArray2 = objectArray;
        objectArray[62] = "\u007fID\\\u0000E;]A^k@BI_I\t\u001dsEL]\u0007$r\u001d\u0016QT\u001a$@\u001aGk";
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = Freecam.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = Freecam.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = Freecam.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = Freecam.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Freecam.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

