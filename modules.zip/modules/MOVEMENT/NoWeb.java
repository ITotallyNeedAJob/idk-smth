// === Kuzi module: NoWeb ===
// Category   : MOVEMENT
// Description: Move through cobwebs with no slowdown.
// Payload    : a.a.a.j.e.X (verified: False)

package kuzi.modules.movement;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import kuzi.core.Client;
import kuzi.mixin.MixinExposed;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.module.Module;
import kuzi.obf.h.b.l;
import kuzi.obf.j.e.am;
import kuzi.obf.j.e.o;
import kuzi.obf.m.r;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import net.minecraft.Blocks;
import net.minecraft.BlockPos;
import net.minecraft.AABB;

public class NoWeb
extends BaseModule
implements Module {
    private final l mode;
    private final SliderSetting speed;
    private static final long o = 49493781820866L;
    private static final Object[] s = new Object[]{"\foCFQG\u0007oGFQ\u0004", "s\u000e\u0004Z\u0000\\x\u0001\u0015\u0015}Dk\u0006\u001c\\", "H|S%\u001dlC|X", "A>\bO&*A>\u001f\u0013*%[u\u001f\r*0\\\u0004OP{", "EK+9mFNK/9T", "7\u007f\u000eDl1;\u007f\u001d", "n_\u000fR#Eg_\fR.", "\u0013`\u0019i,<\u0018`\u0011", "]*\fM\u0002\u001aV*\bM\f", "y\u007f^\brVp\u007f]\b~", "bbn<@&\u0017Be3QivLn8U3\u0002", Void.TYPE, ";Tl2\u0014ENtg=\u0005\n/zl6\u0001P[", Double.TYPE, "q\u001d\u0019Eh\\\u0004=\u0012Jy\u0013e3\u0019A}I\u0011", Boolean.TYPE, "~X3>\u0005)wX0>\u0005", "7\u0011D[PF<\u001eU\u00141H7\u0015QN", "*u\u0006\u001bN\u0013k+\u0001B1J\u0011z\u0001ZSB/{\u000e[T# /\u0002\u0012A\u001bus\u001aM1", "=H0T#l;\u000e;jq\u0012|U<VrnxJ3j", "cRgi+xcA6nZxZ\t2n<)(B<7;", "A\u001f\u0019c*M\u0000A\u001e:U\u0018z\u001dR42A\u001eG\u0003)<", "#E?/D\u0016n\u001b!m$lY!\u0014VioB\u007fd)B\u0015~@)w\\W", "%\r\u0004b\u0004\u0016dS\u0003;{@\u001e\r\u00023B[~]\u0018iC", "(\u0014/H\u0019ZiJ(\u0011f\u0004\u0013\u001b(\t\u0004\u000b-\u001a'\b\u0003jzI4\u0005\t\u0014kO2\u001ff", "/~O\u0002-kn H[R2\u0014{HWh*e$URc[/=P\b#*p U\u0003R", "U4hD\"'Cu1C\u001ar?a%\u001adz\u00047%Ea\u001b", "'\t\u007f\u00156Uj\u000b4\u0001\n @,J\u007f7\u000bj\u00073Ez\t!\u0013", "s\u0001i\u001b\u0015\u000fs\u00128\u001cd\u0002JQ$P\u0006\u0007tP+Q\u0001fu\u001efD\u0007\u00054\u001bfEd", "S6\u0007K?&\u001e4L_\u0003G*\u0015(mDC(RJEsvRh\u0007G8b"};
    private static final String[] t = new String[]{null, null, null, null, null, null, null, null, null, null, null, "java/lang/Void", null, "java/lang/Double", null, "java/lang/Boolean", null, null, null, null, null, null, null, null, null, null, null, null, null, null};

    public NoWeb() {
        long l2 = o ^ 0x13F5457C9A8BL;
        long l3 = l2 ^ 0x1F15E549B45CL;
        super("NoWeb", "Move through cobwebs with no slowdown.", Category.MOVEMENT);
        this.mode = new l("Mode", kuzi.obf.j.e.o.SLOWDOWN, o.class);
        this.speed = new SliderSetting("Speed", 0.35, 0.35, 0.65, 0.05);
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.mode, this.speed};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        Client.a().a(Module.class, this);
    }

    @Override
    public void e() {
        Client.a().b(Module.class, this);
    }

    @MixinExposed
    public boolean a() {
        return ((o)((Object)this.mode.a())).name().equals("SLOWDOWN");
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public void b() {
        block10: {
            block9: {
                block8: {
                    v0 = var1_1 = NoWeb.o ^ 58743553617158L;
                    var3_2 = v0 ^ 79006940809265L;
                    var5_3 = v0 ^ 8642033159979L;
                    stringTable = am.b();
                    if (this.mode.a() != kuzi.obf.j.e.o.GRIM) {
                        return;
                    }
                    mc = BaseModule.a;
                    if (stringTable == null) break block8;
                    if (mc.player == null) break block9;
                    mc = BaseModule.a;
                }
                if (mc.level != null) break block10;
            }
            return;
        }
        v2 = this;
        if (stringTable != null) {
            v3 = new Object[1];
            v3[0] = var3_2;
            if (!v2.f(v3)) {
                return;
            }
            v2 = this.speed.a();
        }
        speedValue = (Double)v2;
        v4 = new Object[1];
        v4[0] = var5_3;
        yawRadians = this.a(v4);
        motionX = -Math.sin(yawRadians) * speedValue;
        motionZ = Math.cos(yawRadians) * speedValue;
        v5 = BaseModule.a.options.keyJump.isDown();
        if (stringTable == null) ** GOTO lbl38
        if (v5) {
            v6 = 0.65;
        } else {
            v5 = BaseModule.a.options.keyShift.isDown();
lbl38:
            // 2 sources

            v6 = v5 != false ? -0.65 : 0.0;
        }
        motionY = v6;
        deltaMovement = BaseModule.a.player.getDeltaMovement();
        BaseModule.a.player.setDeltaMovement(deltaMovement.x + motionX, motionY, deltaMovement.z + motionZ);
    }

    private boolean f(Object[] objectArray) {
        boolean foundCobweb;
        block5: {
            long l2 = (Long)objectArray[0];
            l2 = o ^ l2;
            AABB boundingBox = BaseModule.a.player.getBoundingBox();
            BlockPos minPos = BlockPos.containing((double)boundingBox.minX, (double)boundingBox.minY, (double)boundingBox.minZ);
            String stringTable = am.b();
            BlockPos maxPos = BlockPos.containing((double)boundingBox.maxX, (double)boundingBox.maxY, (double)boundingBox.maxZ);
            for (BlockPos blockPos : BlockPos.betweenClosed((BlockPos)minPos, (BlockPos)maxPos)) {
                block7: {
                    boolean isCobweb;
                    block6: {
                        foundCobweb = BaseModule.a.level.getBlockState(blockPos).is(Blocks.COBWEB);
                        String guard = stringTable;
                        if (l2 > 0L) {
                            if (guard == null) break block5;
                            guard = stringTable;
                        }
                        if (guard == null) break block6;
                        if (!foundCobweb) break block7;
                        isCobweb = true;
                    }
                    return isCobweb;
                }
                if (stringTable != null) continue;
            }
            foundCobweb = false;
        }
        return foundCobweb;
    }

    private double a(Object[] objectArray) {
        String stringTable;
        boolean keyPressed;
        float strafeFactor;
        float yaw;
        block10: {
            String guard;
            block11: {
                block9: {
                    long l2;
                    block7: {
                        block8: {
                            l2 = (Long)objectArray[0];
                            l2 = o ^ l2;
                            yaw = BaseModule.a.player.getYRot();
                            guard = am.b();
                            strafeFactor = 1.0f;
                            keyPressed = BaseModule.a.options.keyDown.isDown();
                            if (guard == null) break block7;
                            if (!keyPressed) break block8;
                            strafeFactor = -0.5f;
                            if (guard != null) break block9;
                        }
                        keyPressed = BaseModule.a.options.keyUp.isDown();
                    }
                    stringTable = guard;
                    if (l2 < 0L) break block10;
                    if (stringTable == null) break block11;
                    if (keyPressed) {
                        strafeFactor = 0.5f;
                    }
                }
                keyPressed = BaseModule.a.options.keyLeft.isDown();
            }
            stringTable = guard;
        }
        if (stringTable != null) {
            if (keyPressed) {
                yaw += 90.0f * strafeFactor;
            }
            keyPressed = BaseModule.a.options.keyRight.isDown();
        }
        if (keyPressed) {
            yaw -= 90.0f * strafeFactor;
        }
        return Math.toRadians(yaw);
    }

    private static r a(r r2) {
        return r2;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = NoWeb.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = NoWeb.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = NoWeb.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = NoWeb.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }
}

