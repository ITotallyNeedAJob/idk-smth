// === Kuzi module: FakeElytra ===
// Category   : MOVEMENT
// Description: Renders your worn chestplate as an elytra (client-side, keeps your armor)
// Payload    : a.a.a.j.e.M (verified: True)

package kuzi.modules.movement;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import kuzi.mixin.MixinExposed;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.b.i;
import kuzi.obf.j.e.am;
import kuzi.obf.m.r;
import kuzi.settings.Setting;
import net.minecraft.ChatFormatting;
import net.minecraft.Item;
import net.minecraft.ItemStack;
import net.minecraft.Items;
import net.minecraft.Enchantments;
import net.minecraft.ItemLike;
import net.minecraft.Registry;
import net.minecraft.Component;
import net.minecraft.Style;
import net.minecraft.MutableComponent;
import net.minecraft.ClientLevel;
import net.minecraft.Holder;
import net.minecraft.Registries;
import net.minecraft.DataComponents;

public class FakeElytra
extends BaseModule {
    private final i swappedItem;
    public volatile boolean n;
    public volatile Item o;
    private static final long p = 65669906886388L;
    private static final Object[] t = new Object[]{";\u0001r\u001fU\u00160\u0001v\u001fUU", "\u0003^\u001c\\\u0007q\bQ\r\u0013zi\u001bV\u0004Z", "V\u0002`\u001ed\u0015]\u0002k", "cHvm\u0012JcHa1\u001eEy\u0003a/\u001eP~r1rO", "`o+wM/ko/wa", "l\"d\u00118\u001de\"g\u00110", "\u0015AU8m\u0004`a^7|K\u0001oU<x\u0011u", "\u0012q\u000e\u0004-M\u0012q\u0019X!B\b:\u0019F!W\u000fKK\u001dy\u0016", Boolean.TYPE, "PD)\u0001\u0011,\\D:", "2*LkcA9*D", "9nrr\u001c}LNy}\r2-@rv\thY", Void.TYPE, "\u0004sv,`k\u0015s\\", "AJ\u001dO -4j\u0016@1bUd\u001dK58!", "[r$(>\tP}5g_\u0007[v1=", ":\rn\u0019[\u0002jC.\u001cd\u0003\u0001\u000eoO\u000e\u0001|W!H\u000f", "m%\u0005v(\n8\"T\r,xmp\bn+@,1\u00136F", "\u0001\u0013\f\u0003j7T\u0010\u0016\u0000\t=8L\u0005J1.T\f\r\u001aw", "<`\u0006P}Yy2\u0003VAaDT)*\fb_\n[\u0005#\u001b?w\u001eW&\u001d", "D\u0001rg\u007fP\u0014O2b@P\u007f\u0003t7;W\u0011Ws5/", "C_\u0019 vP\u0013\u0011Y%ISx[\u0014.4\\G\u0000^\"'", "\u0012m\u0011\u0013A4By\u0018\u001d&\"#bN\u0018DrJd\u001d\u0001KN\u001erM\u0002G JuO\u0016&", ":]G0oZj\u0013\u00075PU\u0001\\Q$\"@|Y_*?<?\u000bG),A:\u0005I4P", "tW\u0019?P{!T\u0003<3|M[D,Q$$]\u00175^\u0018}@B,]&u\u000b@\"3", "6\u000e\tq\u0012:mD\u0005bxl\r\u0015Tm\u001a9d\u0013\u0007t\u0015\u00051\u0002Qf\u001dxhLVgx"};
    private static final String[] u = new String[]{null, null, null, null, null, null, null, null, "java/lang/Boolean", null, null, null, "java/lang/Void", null, null, null, null, null, null, null, null, null, null, null, null, null};

    public FakeElytra() {
        long l2 = p ^ 0x337C735A95EAL;
        long l3 = l2 ^ 0x29268F5FE00BL;
        super("FakeElytra", "Renders your worn chestplate as an elytra (client-side, keeps your armor)", Category.MOVEMENT);
        this.swappedItem = new i("Swapped Item", Items.DIAMOND_CHESTPLATE);
        this.n = false;
        this.o = null;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.swappedItem};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void e() {
        this.n = false;
        this.o = null;
    }

    /*
     * Exception decompiling
     */
    @Override
    public void i() {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Statement already marked as first in another block
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.markFirstStatementInBlock(Op03SimpleStatement.java:461)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc.markWholeBlock(Misc.java:251)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.considerAsSimpleIf(ConditionalRewriter.java:673)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.identifyNonjumpingConditionals(ConditionalRewriter.java:56)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:722)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    @MixinExposed
    public ItemStack a(ItemStack stack) {
        ItemStack outStack;
        block23: {
            ItemStack displayStack;
            block24: {
                ClientLevel level;
                long l2;
                block25: {
                    Item targetItem;
                    String string;
                    block22: {
                        block21: {
                            Item targetItemChecked;
                            block20: {
                                FakeElytra fakeElytra;
                                long l3;
                                block19: {
                                    boolean bl;
                                    block17: {
                                        block18: {
                                            block16: {
                                                ItemStack checkedStack;
                                                block15: {
                                                    long l4;
                                                    long l5 = l4 = p ^ 0x30995C8B0E9CL;
                                                    l3 = l5 ^ 0x701467308967L;
                                                    l2 = l5 ^ 0x317815950E21L;
                                                    string = am.b();
                                                    checkedStack = stack;
                                                    if (string == null) break block15;
                                                    if (checkedStack == null) break block16;
                                                    checkedStack = stack;
                                                }
                                                bl = checkedStack.isEmpty();
                                                if (string == null) break block17;
                                                if (!bl) break block18;
                                            }
                                            return null;
                                        }
                                        fakeElytra = this;
                                        if (string == null) break block19;
                                        bl = fakeElytra.n;
                                    }
                                    if (!bl) {
                                        return null;
                                    }
                                    fakeElytra = this;
                                }
                                Object[] objectArray = new Object[1];
                                objectArray[0] = l3;
                                targetItemChecked = targetItem = fakeElytra.swappedItem.a(objectArray);
                                if (string == null) break block20;
                                if (targetItemChecked == null) break block21;
                                targetItemChecked = targetItem;
                            }
                            if (targetItemChecked != Items.AIR) break block22;
                        }
                        return null;
                    }
                    ItemStack elytraStack = stack;
                    if (string != null) {
                        if (!elytraStack.is(targetItem)) {
                            return null;
                        }
                        elytraStack = new ItemStack((ItemLike)Items.ELYTRA, stack.getCount());
                    }
                    displayStack = elytraStack;
                    MutableComponent customName = Component.literal((String)Items.ELYTRA.getName().getString()).setStyle(Style.EMPTY.withColor(ChatFormatting.AQUA).withItalic(Boolean.valueOf(false)));
                    outStack = displayStack;
                    if (string == null) break block23;
                    outStack.set(DataComponents.CUSTOM_NAME, (Object)customName);
                    if (BaseModule.a == null) break block24;
                    level = BaseModule.a.level;
                    if (string == null) break block25;
                    if (level == null) break block24;
                    level = BaseModule.a.level;
                }
                level.registryAccess().lookup(Registries.ENCHANTMENT).ifPresent(arg_0 -> FakeElytra.lambda$getDisplayStack$0(l2, displayStack, arg_0));
            }
            outStack = displayStack;
        }
        return outStack;
    }

    private static void lambda$getDisplayStack$0(long l2, ItemStack stack, Registry registry) {
        block2: {
            l2 = p ^ l2;
            Holder unbreakingHolder = registry.getOptional(Enchantments.UNBREAKING).map(arg_0 -> ((Registry)registry).wrapAsHolder(arg_0)).orElse(null);
            String string = am.b();
            Holder mendingHolder = registry.getOptional(Enchantments.MENDING).map(arg_0 -> ((Registry)registry).wrapAsHolder(arg_0)).orElse(null);
            Holder holder = unbreakingHolder;
            if (string != null) {
                if (holder != null) {
                    stack.enchant(unbreakingHolder, 3);
                }
                holder = mendingHolder;
            }
            if (holder == null) break block2;
            stack.enchant(mendingHolder, 1);
        }
    }

    private static r a(r r2) {
        return r2;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = FakeElytra.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = FakeElytra.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = FakeElytra.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = FakeElytra.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }
}

