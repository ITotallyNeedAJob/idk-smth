// === Kuzi module: InventoryWalk ===
// Category   : MOVEMENT
// Description: Allows you to move around and jump while you have your inventory or a chest open.
// Payload    : a.a.a.j.e.R (verified: False)

package kuzi.modules.movement;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.i.F;
import kuzi.obf.j.e.am;
import kuzi.obf.m.r;
import net.minecraft.Window;
import net.minecraft.KeyMapping;
import net.minecraft.Minecraft;
import net.minecraft.InputConstants;
import net.minecraft.ChatScreen;
import net.minecraft.Screen;
import net.minecraft.AbstractSignEditScreen;

public class InventoryWalk
extends BaseModule {
    private static final Object[] t = new Object[]{"AjJ\u0019\u0004ZJjB", "h)$\r=)c) \r=j", "R/IS*SY X\u001cWKJ'QU", "ej(s\u0010!nj#", "\u001c/K\u001bgq\u001c/\\Gk~\u0006d\\Ykk\u0001\u0015\f\u0004:", "%^N\r/\u007f.^J\r\u001c", "\u0015tW\u0006n)\u0019tD", "\u0002p5\fYJ\t\u007f$C8D\u0002t \u0019", "J\u00024F\"D\u0016R!\u001a\u001dAsQ+K`WBXaL}+", "%\u00160Vosf\u0013 ]\u0014#\u001f\u0013gV{ !U8L~", "'1]\u001d4\n!w\u0006KO\u001d\u001cwR\u00191\u000bz)AJ*t '\\\u00050\u0012~4\u000f\u001eO", "^M(\u0016a)CH*&^\u0015o?\u0002k]\u000e1\u001dxI+(J\u0000}K"};

    public InventoryWalk() {
        super("InventoryWalk", "Allows you to move around and jump while you have your inventory or a chest open.", Category.MOVEMENT);
    }

    @Override
    public void i() {
        KeyMapping[] movementKeys;
        int keyCount;
        String stringTable;
        block11: {
            block12: {
                block10: {
                    block9: {
                        Screen screen;
                        block7: {
                            block8: {
                                block6: {
                                    Minecraft mc;
                                    block5: {
                                        stringTable = am.b();
                                        mc = BaseModule.a;
                                        if (stringTable == null) break block5;
                                        if (mc.player == null) break block6;
                                        mc = BaseModule.a;
                                    }
                                    screen = mc.screen;
                                    if (stringTable == null) break block7;
                                    if (screen != null) break block8;
                                }
                                return;
                            }
                            screen = BaseModule.a.screen;
                        }
                        keyCount = screen instanceof ChatScreen;
                        if (stringTable == null) break block9;
                        if (keyCount != 0) break block10;
                        keyCount = BaseModule.a.screen instanceof AbstractSignEditScreen;
                    }
                    if (stringTable == null) break block11;
                    if (keyCount == 0) break block12;
                }
                return;
            }
            keyCount = 7;
        }
        KeyMapping[] keys = new KeyMapping[keyCount];
        keys[0] = BaseModule.a.options.keyUp;
        keys[1] = BaseModule.a.options.keyDown;
        keys[2] = BaseModule.a.options.keyLeft;
        keys[3] = BaseModule.a.options.keyRight;
        keys[4] = BaseModule.a.options.keyJump;
        keys[5] = BaseModule.a.options.keySprint;
        keys[6] = BaseModule.a.options.keyShift;
        for (KeyMapping keyMapping : movementKeys = keys) {
            keyMapping.setDown(InputConstants.isKeyDown((Window)BaseModule.a.getWindow(), (int)((F)keyMapping).getBoundKey().getValue()));
            if (stringTable != null) continue;
        }
    }

    private static r a(r value) {
        return value;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = InventoryWalk.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int index = 0; index < classArray.length; ++index) {
                field = InventoryWalk.d(classArray[index], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int parameterCount, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != parameterCount) continue;
            for (int index = 0; index < parameterCount; ++index) {
                if (classArray2[index] != classArray[index]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int parameterCount, Class[] classArray) {
        Method method = InventoryWalk.c(clazz, string, clazz2, parameterCount, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int index = 0; index < classArray2.length; ++index) {
                method = InventoryWalk.d(classArray2[index], string, clazz2, parameterCount, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }
}

