// === Kuzi module: ElytraSwap ===
// Category   : MOVEMENT
// Description: Press the key to equip a hotbar elytra/chestplate and switch back.
// Payload    : a.a.a.j.e.L (verified: True)

package kuzi.modules.movement;

import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.module.Module;
import kuzi.obf.h.b.l;
import kuzi.obf.h.b.v;
import kuzi.obf.i.n_0;
import kuzi.obf.j.e.am;
import kuzi.obf.j.e.k;
import kuzi.obf.m.r;
import kuzi.settings.KeyBinding;
import kuzi.settings.Setting;
import net.minecraft.InteractionHand;
import net.minecraft.EquipmentSlot;
import net.minecraft.Player;
import net.minecraft.ItemStack;
import net.minecraft.Items;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class ElytraSwap
extends BaseModule
implements Module {
    private final KeyBinding activateKey;
    private final l delaySetting;
    private boolean o;
    private int swapStage;
    private int delayTicks;
    private int savedSlot;
    private static final long s;
    private static final String[] t;
    private static final String[] u;
    private static final Map v;
    private static final long[] w;
    private static final Integer[] x;
    private static final Map y;
    private static final Object[] z;
    private static final String[] A;

    public ElytraSwap() {
        long l2 = s ^ 0x58B7B0CEED21L;
        long l3 = l2 ^ 0xFB666B69413L;
        super("ElytraSwap", "Press the key to equip a hotbar elytra/chestplate and switch back.", Category.MOVEMENT);
        this.activateKey = new KeyBinding("Activate Key", -1);
        this.delaySetting = new l("Delay", k.LOW, k.class);
        this.o = false;
        this.swapStage = 0;
        this.delayTicks = 0;
        this.savedSlot = -1;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.activateKey, this.delaySetting};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void d() {
        long l2 = s ^ 0x1D6F617345EAL;
        long l3 = l2 ^ 0x5A5CAB3193DDL;
        Client.a().a(Module.class, this);
        super.d();
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.a(objectArray);
    }

    @Override
    public void e() {
        long l2 = s ^ 0x813789225C4L;
        long l3 = l2 ^ 0x4F20B2D0F3F3L;
        Client.a().b(Module.class, this);
        super.e();
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        this.a(objectArray);
    }

    private void a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = s ^ l2;
        this.o = false;
        this.swapStage = 0;
        this.delayTicks = 0;
        this.savedSlot = -1;
    }

    /*
     * Exception decompiling
     */
    @Override
    public void b() {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Statement already marked as first in another block
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.markFirstStatementInBlock(Op03SimpleStatement.java:461)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Misc.markWholeBlock(Misc.java:251)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.considerAsSimpleIf(ConditionalRewriter.java:673)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.ConditionalRewriter.identifyNonjumpingConditionals(ConditionalRewriter.java:56)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:722)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private void c(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = l2 = s ^ l2;
        long l4 = l3 ^ 0x60B0DB36459L;
        long l5 = l3 ^ 0x71215B2C596EL;
        long l6 = l3 ^ 0x761EE13C6530L;
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l5;
        int n2 = this.a(objectArray2);
        String string = am.b();
        if (string != null) {
            if (n2 < 0) {
                return;
            }
            this.savedSlot = BaseModule.a.player.getInventory().getSelectedSlot();
            Object[] objectArray3 = new Object[2];
            objectArray3[1] = n2;
            objectArray3[0] = l4;
            this.b(objectArray3);
            this.swapStage = 1;
            Object[] objectArray4 = new Object[1];
            objectArray4[0] = l6;
            this.delayTicks = ((k)((Object)this.delaySetting.a())).a(objectArray4);
        }
    }

    /*
     * Unable to fully structure code
     */
    private void f(Object[] var1_1) {
        block9: {
            var2_2 = (Long)var1_1[0];
            v0 = var2_2 = ElytraSwap.s ^ var2_2;
            var4_3 = v0 ^ 35266042572767L;
            var6_4 = v0 ^ 87990718148278L;
            var8_5 = am.b();
            v1 = this.delayTicks--;
            if (var8_5 == null) break block9;
            if (v1 > 0) {
                return;
            }
            v2 = this;
            v3 = var8_5;
            if (var2_2 < 0L) ** GOTO lbl26
            if (v3 == null) ** GOTO lbl25
            v1 = v2.swapStage;
        }
        switch (v1) {
            case 1: {
                BaseModule.a.gameMode.useItem((Player)BaseModule.a.player, InteractionHand.MAIN_HAND);
                BaseModule.a.player.swing(InteractionHand.MAIN_HAND);
                this.swapStage = (int)ElytraSwap.c("n", (int)3963, (long)(3234224528093442424L ^ var2_2));
                v2 = this;
lbl25:
                // 2 sources

                v3 = this.delaySetting.a();
lbl26:
                // 2 sources

                v4 = new Object[1];
                v4[0] = var6_4;
                v2.delayTicks = ((k)v3).a(v4);
                if (var2_2 >= 0L && var8_5 != null) break;
            }
            case 2: {
                v5 = this;
                if (var8_5 == null) ** GOTO lbl49
                if (var2_2 <= 0L) ** GOTO lbl47
                if (v5.savedSlot < 0) ** GOTO lbl46
                v5 = this;
                if (var8_5 == null) ** GOTO lbl49
                if (var2_2 <= 0L) ** GOTO lbl47
                if (v5.savedSlot <= ElytraSwap.c("n", (int)12918, (long)(66368102614715511L ^ var2_2))) {
                    v6 = new Object[2];
                    v6[1] = this.savedSlot;
                    v6[0] = var4_3;
                    this.b(v6);
                }
lbl46:
                // 4 sources

                v7 = this;
lbl47:
                // 3 sources

                v7.swapStage = 0;
                v5 = this;
lbl49:
                // 3 sources

                v5.savedSlot = -1;
            }
        }
    }

    private void b(Object[] objectArray) {
        int n2;
        block4: {
            block3: {
                int n3;
                long l2;
                block2: {
                    l2 = (Long)objectArray[0];
                    n2 = (Integer)objectArray[1];
                    l2 = s ^ l2;
                    String string = am.b();
                    n3 = n2;
                    if (string == null) break block2;
                    if (n3 < 0) break block3;
                    n3 = n2;
                }
                if (n3 <= ElytraSwap.c("n", (int)31010, (long)(0x3C3D1374F9434ADAL ^ l2))) break block4;
            }
            return;
        }
        BaseModule.a.player.getInventory().setSelectedSlot(n2);
        ((n_0)BaseModule.a.gameMode).syncSlot();
    }

    private int a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        long l3 = l2 = s ^ l2;
        long l4 = l3 ^ 0x463FE5E8ABA7L;
        long l5 = l3 ^ 0x5A8528AF4AC8L;
        ItemStack mc17992 = BaseModule.a.player.getItemBySlot(EquipmentSlot.CHEST);
        Object[] objectArray2 = new Object[2];
        objectArray2[1] = l4;
        objectArray2[0] = true;
        int n2 = this.c(objectArray2);
        Object[] objectArray3 = new Object[2];
        objectArray3[1] = l4;
        objectArray3[0] = false;
        int n3 = this.c(objectArray3);
        String string = am.b();
        int n4 = mc17992.is(Items.ELYTRA);
        if (string != null) {
            if (n4 != 0) {
                int n5 = n3;
                if (string != null) {
                    n5 = n5 != -1 ? n3 : n2;
                }
                return n5;
            }
            Object[] objectArray4 = new Object[2];
            objectArray4[1] = l5;
            objectArray4[0] = mc17992;
            n4 = this.a(objectArray4) ? 1 : 0;
        }
        String string2 = string;
        if (l2 > 0L) {
            if (string2 != null) {
                if (n4 != 0) {
                    int n6 = n2;
                    if (string != null) {
                        n6 = n6 != -1 ? n2 : n3;
                    }
                    return n6;
                }
                n4 = n2;
            }
            string2 = string;
        }
        if (string2 != null) {
            n4 = n4 != -1 ? n2 : n3;
        }
        return n4;
    }

    private int c(Object[] objectArray) {
        int n2;
        block5: {
            boolean bl = (Boolean)objectArray[0];
            long l2 = (Long)objectArray[1];
            long l3 = (l2 = s ^ l2) ^ 0x6A5810420348L;
            int n3 = 0;
            String string = am.b();
            while (n3 < ElytraSwap.c("n", (int)17149, (long)(0x43156997160C85B0L ^ l2))) {
                block9: {
                    block10: {
                        int n4;
                        block12: {
                            block11: {
                                String string2;
                                block6: {
                                    block7: {
                                        ItemStack mc17992;
                                        block8: {
                                            mc17992 = BaseModule.a.player.getInventory().getItem(n3);
                                            n2 = bl ? 1 : 0;
                                            string2 = string;
                                            if (l2 > 0L) {
                                                if (string2 == null) break block5;
                                                string2 = string;
                                            }
                                            if (l2 <= 0L) break block6;
                                            if (string2 == null) break block7;
                                            if (n2 == 0) break block8;
                                            if (l2 <= 0L) break block9;
                                            if (!mc17992.is(Items.ELYTRA)) break block10;
                                            break block11;
                                        }
                                        Object[] objectArray2 = new Object[2];
                                        objectArray2[1] = l3;
                                        objectArray2[0] = mc17992;
                                        n4 = this.a(objectArray2) ? 1 : 0;
                                    }
                                    string2 = string;
                                }
                                if (string2 == null) break block12;
                                if (n4 == false) break block10;
                            }
                            n4 = n3;
                        }
                        return n4;
                    }
                    ++n3;
                }
                if (string != null) continue;
            }
            n2 = -1;
        }
        return n2;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean a(Object[] objectArray) {
        ItemStack mc17992 = (ItemStack)objectArray[0];
        long l2 = (Long)objectArray[1];
        l2 = s ^ l2;
        String string = am.b();
        boolean bl = mc17992.isEmpty();
        if (string != null) {
            if (bl) {
                return false;
            }
            bl = mc17992.is(Items.LEATHER_CHESTPLATE);
        }
        if (string == null) return bl;
        if (bl) return true;
        bl = mc17992.is(Items.CHAINMAIL_CHESTPLATE);
        if (string == null) return bl;
        if (bl) return true;
        bl = mc17992.is(Items.IRON_CHESTPLATE);
        if (string == null) return bl;
        if (bl) return true;
        bl = mc17992.is(Items.GOLDEN_CHESTPLATE);
        if (string == null) return bl;
        if (bl) return true;
        bl = mc17992.is(Items.DIAMOND_CHESTPLATE);
        if (string == null) return bl;
        if (bl) return true;
        bl = mc17992.is(Items.NETHERITE_CHESTPLATE);
        if (string == null) return bl;
        if (!bl) return false;
        return true;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block21: {
            block20: {
                block19: {
                    block18: {
                        ElytraSwap.s = kuzi.obf.h.b.v.a(-1492584770045302876L, 3150269719310666993L, MethodHandles.lookup().lookupClass()).a(59787760100452L);
                        ElytraSwap.z = new Object[48];
                        ElytraSwap.A = new String[48];
                        ElytraSwap.c();
                        ElytraSwap.v = new HashMap<K, V>(13);
                        var11 = ElytraSwap.s ^ 14356924840770L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[4];
                        var18_4 = 0;
                        var17_5 = "\u0094>\u00a1(r;\u00a6&\u0097\u00fb\u000epg\rEL\u00d0z\u0086\u00e4\u00ed+\u00d7z\u00d0\u001e\u00f4\u00eb\u0090>\b\u000f\u0018\u00eej\u00d3\u007f\u00eb`r\u00ad\u00d2\u00fb\u00f4xWS\u009c\u008b\u001b'7?.\u00f6\u00cd\u00c6";
                        var19_6 = "\u0094>\u00a1(r;\u00a6&\u0097\u00fb\u000epg\rEL\u00d0z\u0086\u00e4\u00ed+\u00d7z\u00d0\u001e\u00f4\u00eb\u0090>\b\u000f\u0018\u00eej\u00d3\u007f\u00eb`r\u00ad\u00d2\u00fb\u00f4xWS\u009c\u008b\u001b'7?.\u00f6\u00cd\u00c6".length();
                        var16_7 = 32;
                        var15_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block18;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = ElytraSwap.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "I~\u00ebX\u00f7\u007f\u00c2\u0019ph\u00b7&\f\u00c9S\u00eap\u008f: \u00ac\u0006sCR\u00b5\u0092\u00d9\u00d6\u00f6Ms\u0083\u0006\u00cb\u001c\u0087\u008b\u00fc\u00dfR\u00f8\u0086\u00ff\u00a6H:\u0095\u0017\u0090\u00bb\u0013uEZ\u00a6\u00d4\u0092\n\u00c8|\u000eR\u00c7\u00c2\b\u008a8\u0017\u001b\u0082\u00e0%\u00e5E\u0094\u0015\u00da_\u000fn\u0001\u0017y\u00c9\u0094\u00ac\u00ca\u0006\u00ce\u00b3\u00b3\u0085.JQ\u0013r\u00ce\u00ec\u00ff\u00b2\u0091i\u00e6Qp\u00aa\u0090\u009a9\u00cbY|8n\u001b\u00fe\u00d2Z\u000b\u0016J\u00fd\u00f4;\u00dcR6";
                            var19_6 = "I~\u00ebX\u00f7\u007f\u00c2\u0019ph\u00b7&\f\u00c9S\u00eap\u008f: \u00ac\u0006sCR\u00b5\u0092\u00d9\u00d6\u00f6Ms\u0083\u0006\u00cb\u001c\u0087\u008b\u00fc\u00dfR\u00f8\u0086\u00ff\u00a6H:\u0095\u0017\u0090\u00bb\u0013uEZ\u00a6\u00d4\u0092\n\u00c8|\u000eR\u00c7\u00c2\b\u008a8\u0017\u001b\u0082\u00e0%\u00e5E\u0094\u0015\u00da_\u000fn\u0001\u0017y\u00c9\u0094\u00ac\u00ca\u0006\u00ce\u00b3\u00b3\u0085.JQ\u0013r\u00ce\u00ec\u00ff\u00b2\u0091i\u00e6Qp\u00aa\u0090\u009a9\u00cbY|8n\u001b\u00fe\u00d2Z\u000b\u0016J\u00fd\u00f4;\u00dcR6".length();
                            var16_7 = 16;
                            var15_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block18;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = ElytraSwap.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block19;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                ElytraSwap.t = var20_3;
                ElytraSwap.u = new String[4];
                ElytraSwap.y = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[4];
                var3_13 = 0;
                var4_14 = "\u00d8\u00c4QU\\\u00ed\u00b6\u0085\u00b2\u00d1?\u00d2\u0001\u00f2\u009bV";
                var5_15 = "\u00d8\u00c4QU\\\u00ed\u00b6\u0085\u00b2\u00d1?\u00d2\u0001\u00f2\u009bV".length();
                var2_16 = 0;
                while (true) {
                    var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                    v10 = var6_12;
                    v11 = var3_13++;
                    v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                    v13 = -1;
                    break block20;
                    break;
                }
lbl81:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    var4_14 = "\u00ae\u00ff\u008a\u00a2\u008fR{\u00b8\u00cf\u00d5T\u00f6\u0094\u009ai\u00b5";
                    var5_15 = "\u00ae\u00ff\u008a\u00a2\u008fR{\u00b8\u00cf\u00d5T\u00f6\u0094\u009ai\u00b5".length();
                    var2_16 = 0;
                    while (true) {
                        var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
                        v10 = var6_12;
                        v11 = var3_13++;
                        v12 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
                        v13 = 0;
                        break block20;
                        break;
                    }
                    break;
                }
lbl94:
                // 1 sources

                while (true) {
                    v10[v11] = v14;
                    if (var2_16 < var5_15) ** continue;
                    break block21;
                    break;
                }
            }
            var8_18 = v12;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            v14 = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
            switch (v13) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl107:
                // 1 sources

                ** continue;
            }
        }
        ElytraSwap.w = var6_12;
        ElytraSwap.x = new Integer[4];
    }

    private static r a(r r2) {
        return r2;
    }

    private static String b(byte[] byArray) {
        int n2 = 0;
        int n3 = byArray.length;
        char[] cArray = new char[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            char c2;
            int n4 = 0xFF & byArray[i2];
            if (n4 < 192) {
                cArray[n2++] = (char)n4;
                continue;
            }
            if (n4 < 224) {
                c2 = (char)((char)(n4 & 0x1F) << 6);
                n4 = byArray[++i2];
                c2 = (char)(c2 | (char)(n4 & 0x3F));
                cArray[n2++] = c2;
                continue;
            }
            if (i2 >= n3 - 2) continue;
            c2 = (char)((char)(n4 & 0xF) << 12);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F) << 6);
            n4 = byArray[++i2];
            c2 = (char)(c2 | (char)(n4 & 0x3F));
            cArray[n2++] = c2;
        }
        return new String(cArray, 0, n2);
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x31AD;
        if (x[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = w[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])y.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    y.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/e/L", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            ElytraSwap.x[n3] = n4;
        }
        return x[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = ElytraSwap.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/e/L" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static void c() {
        Object[] objectArray = z;
        z[0] = "kUS8t\u0015`UW8Y";
        objectArray[1] = "c\u00078\u007f\u007f#\u0016'3pnlw)8{j6\u0003";
        objectArray[2] = Void.TYPE;
        ElytraSwap.A[2] = "java/lang/Void";
        objectArray[3] = "=&:E<\u001b,&\u0017";
        objectArray[4] = "`*c\u0001r\u0007\u0015\nh\u000ecHt\u0004c\u0005g\u0012\u0000";
        objectArray[5] = Boolean.TYPE;
        ElytraSwap.A[5] = "java/lang/Boolean";
        objectArray[6] = Integer.TYPE;
        ElytraSwap.A[6] = "java/lang/Integer";
        objectArray[7] = "1\u000b\u0015ut}:\u000b\u0011ut>";
        objectArray[8] = "'\u0012\b\u000e6Q,\u001d\u0019AKI?\u001a\u0010\b";
        objectArray[9] = "z\u000f]KH\u0010q\u000fV";
        objectArray[10] = "V\u001e|974V\u001eke;;LUk{;.K$;&j";
        objectArray[11] = "]gA\u0014p?(GJ\u001bapIIA\u0010e*=";
        objectArray[12] = "I\u0013\u0012d6M@\u0013\u0011d=";
        objectArray[13] = "\u0013Y\nW\u0017V\u001fY\u0019";
        objectArray[14] = "\u000e4A\u001d3n{\u0014J\u0012\"!\u001a\u001aA\u0019&{n";
        objectArray[15] = "O\u0003\u0002A{sF\u0003\u0001A{";
        objectArray[16] = "*$g44B!+v{UL* r!";
        objectArray[17] = "'><\u0013C\u0003.>?\u0013N";
        objectArray[18] = "1fH~\tTDFCq\u0018\u001b%HHz\u001cAQ";
        objectArray[19] = "[\u000f4U\u0007^P\u000f0U\r";
        objectArray[20] = "\u0002\u0016&xl\u0014w6-w}[\u00168&|y\u0001b";
        objectArray[21] = "'Ez\b_>Req\u0007Nq3kz\fJ+G";
        objectArray[22] = "c[lva|\u0016{gyp3wulrti\u0003";
        objectArray[23] = "oc7'\u0003|\u001aC<(\u00123{M7#\u0016i\u000f";
        objectArray[24] = "i,Ero}b,M";
        objectArray[25] = "!\u000bn2zET+e=k\n5%n6oPA";
        objectArray[26] = "^\u0013C\fOu\u001c\u0003E\u0019 \u007fd\t]\u0005Qn[X\u001b\u0005\u001e\u0016_\u0016Y\u0013Rz\\\u0016H\u000b ";
        objectArray[27] = "Tu0|p\u0004Va'\u0013k;\u0005`sxt\u0000Vt*+";
        objectArray[28] = ".vrYWthe(L<w\u0013):LUfqi2WZ\u001d";
        objectArray[29] = "9L/)\u0003<uM6qlm\u0007B'0Svn\u001ez4U";
        objectArray[30] = "LU2XJuNA%7BJAB<FQu\u0010\u0004<\t)vX\u0004'P\u0012%L]t7";
        objectArray[31] = "\u00071K,L`\u0005%\\CA_\n&E2W`[`E}/f\tg\t;H3\u00119GC";
        objectArray[32] = "\u0000=\f{5\u000b\u0004?\u00055\u0004p(\u001c8LIs3B\u001av}G^|\u001ett\t";
        objectArray[33] = "\u0006\u001dQ\u0019?n\u0004\tFv9Q[\u0003K\n\"`\u0014\u000fB\r";
        objectArray[34] = "@[U\u001er{BOBqxDML[\u0000i{\u001c\n[O\u0011\u007fRHM\u0003}|RYUq";
        objectArray[35] = ":nw@\u0018F8z`/\u0012y7yy^\u0003Ff?y\u0011{@485W\u001c\u0015,f{/";
        objectArray[36] = "Y\u001bq\f.\u001b[\u000ffc4$\b\u000e2\b*\u001f[\u001ak[";
        objectArray[37] = "M\u0012D\u0003\noO\u0006Sl\u000fPJ\f@\u0015R4N\u0014HQ";
        objectArray[38] = ":us6l\u00198adYh&lfr?}Jofc'";
        objectArray[39] = "\u001d+d\n\u0018v\u0016v(\u001fe\u000b6\u0011\u0014\u000b\u0000?\u001c3-\u0000]s\t";
        objectArray[40] = "\u000b[UUb4\tOB:h\u000bWQMJbl\u001eP[H\u0001:\u0000Q[Yfs\u0001GY:";
        objectArray[41] = "Za\u0005\u007fWzXu\u0012\u0010^EWv\u000baLz\u00060\u000b.4|T7GhS)Li\t\u0010";
        objectArray[42] = "\b0]\t:}\n$Jf2B\u0005'S\u0017!}TaSXY{\u0006f\u001f\u001e>.\u001e8Qf";
        objectArray[43] = "\b4j}t-\b)5|\u0013\u007fa9>t+h\u000fh9cx\u0016";
        objectArray[44] = "*=,\u0018dQ!``\r\u0019\u0001F8'\u0005h\u0010yia\u0005'hz!a\u001e~S)58M\u0019";
        objectArray[45] = "*aMJ5<(uZ%,\u0003{t\u000eN18(`W\u001d";
        objectArray[46] = "\u007f]}kn:3\\d3\u0001fA\fo{pz~]){?\u0002x\u000f.7ye-\u0017py\u0001";
        Object[] objectArray2 = objectArray;
        objectArray[47] = "4)Fs6\u00176=Q\u001c<(9>Hm-\u0017hxH\"U\u0014 xS{nG4!\u0000\u001c";
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = ElytraSwap.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = ElytraSwap.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = ElytraSwap.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = ElytraSwap.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(ElytraSwap.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

