// === Kuzi module: Walker ===
// Category   : MOVEMENT
// Description: (identified by constant match; old tree Walker.java)
// Payload    : a.a.a.j.a.f (verified: constant-match)

package kuzi.modules.movement;

import a.a.a.k.J;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.core.Client;
import kuzi.events.EventListener;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.module.Module;
import kuzi.obf.h.b.v;
import kuzi.obf.j.a.c;
import kuzi.obf.j.f.m;
import kuzi.obf.k.e;
import kuzi.obf.k.i;
import kuzi.obf.k.w;
import kuzi.obf.p.L;
import kuzi.obf.p.x_0;
import kuzi.settings.BoolSetting;
import kuzi.settings.ButtonSetting;
import kuzi.settings.KeyBinding;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;
import kuzi.settings.StringSetting;
import net.minecraft.BlockPos;
import net.minecraft.HitResult;
import net.minecraft.Minecraft;
import net.minecraft.BlockHitResult;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class Walker
extends BaseModule
implements Module,
EventListener {
    private volatile boolean startRequested;
    private final KeyBinding goToCrosshairKey;
    private final StringSetting targetCoords;
    private final ButtonSetting goToTargetButton;
    private final KeyBinding stopKey;
    private final BoolSetting sprint;
    private final BoolSetting sneakNearEdges;
    private final SliderSetting searchBudgetMs;
    private final SliderSetting arriveRadius;
    private boolean crosshairKeyDown;
    private boolean stopKeyDown;
    private static final long x;
    private static final String[] y;
    private static final String[] z;
    private static final Map A;
    private static final long[] B;
    private static final Integer[] C;
    private static final Map D;
    private static final Object[] E;
    private static final String[] F;

    public Walker() {
        block0: {
            long l2;
            long l3 = l2 = x ^ 0x57E718455CDFL;
            long l4 = l3 ^ 0x145D751669AFL;
            long l5 = l3 ^ 0x26753873FD75L;
            super("Walker", "Walks you to a block or to typed coordinates.", Category.MOVEMENT);
            this.goToCrosshairKey = new KeyBinding("Go To Crosshair Key", -1);
            this.targetCoords = new StringSetting("Target (x y z)", "");
            this.goToTargetButton = new ButtonSetting("Go To Target", () -> this.lambda$new$0(l4));
            this.stopKey = new KeyBinding("Stop Key", -1);
            this.sprint = new BoolSetting("Sprint", true);
            this.sneakNearEdges = new BoolSetting("Sneak Near Edges", false);
            String[] stringArray = kuzi.obf.j.a.c.b();
            this.searchBudgetMs = new SliderSetting("Search Budget (ms)", 600.0, 100.0, 3000.0, 50.0);
            this.arriveRadius = new SliderSetting("Arrive Radius", 0.5, 0.2, 3.0, 0.1);
            Object[] objectArray = new Object[2];
            objectArray[1] = new Setting[]{this.goToCrosshairKey, this.targetCoords, this.goToTargetButton, this.stopKey, this.sprint, this.sneakNearEdges, this.searchBudgetMs, this.arriveRadius};
            objectArray[0] = l5;
            this.l(objectArray);
            if (BaseModule.b() != null) break block0;
            kuzi.obf.j.a.c.b(new String[2]);
        }
    }

    @Override
    public void d() {
        long l2 = x ^ 0x3BFC973D9D72L;
        long l3 = l2 ^ 0x15E831D331A1L;
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        kuzi.obf.j.f.m.a(objectArray);
        kuzi.obf.k.w.a(new Object[]{false});
        Client.a().a(Module.class, this);
        super.d();
    }

    @Override
    public void e() {
        Client.a().b(Module.class, this);
        kuzi.obf.k.w.a(new Object[0]).b(new Object[]{this});
        this.startRequested = false;
        this.crosshairKeyDown = false;
        this.stopKeyDown = false;
        super.e();
    }

    @Override
    public void h() {
        kuzi.obf.k.w.a(new Object[0]).b(new Object[]{this});
    }

    @Override
    public void b() {
        block19: {
            Walker walker;
            int n2;
            int n3;
            int n4;
            block18: {
                boolean stopPressed;
                block16: {
                    boolean flag;
                    String[] stringArray;
                    block17: {
                        boolean crosshairPressed;
                        int n5;
                        int n6;
                        int n7;
                        block14: {
                            boolean crosshairKeyState;
                            long l2;
                            block15: {
                                long l3;
                                block13: {
                                    block12: {
                                        Minecraft mc;
                                        block11: {
                                            long l4;
                                            long l5 = l4 = x ^ 0x481FCCA6E27BL;
                                            long l6 = l5 ^ 0x5EF0D0446F0BL;
                                            n7 = (int)(l6 >>> 32);
                                            n6 = (int)(l6 << 32 >>> 48);
                                            n5 = (int)(l6 << 48 >>> 48);
                                            l2 = l5 ^ 0x49C6A2B27354L;
                                            long l7 = l5 ^ 0x233D83D4CB92L;
                                            n4 = (int)(l7 >>> 32);
                                            n3 = (int)(l7 << 32 >>> 48);
                                            n2 = (int)(l7 << 48 >>> 48);
                                            l3 = l5 ^ 0x1F310125B30FL;
                                            stringArray = kuzi.obf.j.a.c.b();
                                            mc = BaseModule.a;
                                            if (stringArray == null) break block11;
                                            if (mc.player == null) break block12;
                                            mc = BaseModule.a;
                                        }
                                        if (mc.level != null) break block13;
                                    }
                                    return;
                                }
                                Object[] objectArray = new Object[2];
                                objectArray[1] = this.goToCrosshairKey;
                                objectArray[0] = l2;
                                crosshairPressed = crosshairKeyState = this.a(objectArray);
                                if (stringArray == null) break block14;
                                if (!crosshairPressed) break block15;
                                crosshairPressed = this.crosshairKeyDown;
                                if (stringArray == null) break block14;
                                if (!crosshairPressed) {
                                    Object[] objectArray2 = new Object[1];
                                    objectArray2[0] = l3;
                                    this.walkToCrosshair(objectArray2);
                                }
                            }
                            this.crosshairKeyDown = crosshairKeyState;
                            Object[] objectArray = new Object[2];
                            objectArray[1] = this.stopKey;
                            objectArray[0] = l2;
                            crosshairPressed = this.a(objectArray);
                        }
                        stopPressed = flag = crosshairPressed;
                        if (stringArray == null) break block16;
                        if (!stopPressed) break block17;
                        stopPressed = this.stopKeyDown;
                        if (stringArray == null) break block16;
                        if (!stopPressed) {
                            Object[] objectArray = new Object[3];
                            objectArray[2] = n5;
                            objectArray[1] = n6;
                            objectArray[0] = n7;
                            this.stopWalking(objectArray);
                        }
                    }
                    this.stopKeyDown = flag;
                    walker = this;
                    if (stringArray == null) break block18;
                    stopPressed = walker.startRequested;
                }
                if (!stopPressed) break block19;
                this.startRequested = false;
                walker = this;
            }
            Object[] objectArray = new Object[3];
            objectArray[2] = (int)((char)n2);
            objectArray[1] = n3;
            objectArray[0] = n4;
            walker.walkToTypedTarget(objectArray);
        }
    }

    @Override
    public void c(Object[] objectArray) {
        long l2 = x ^ 0x6483D678E296L;
        long l3 = l2 ^ 0x418D6219B236L;
        Object[] objectArray2 = new Object[2];
        objectArray2[1] = "Arrived.";
        objectArray2[0] = l3;
        x_0.a(objectArray2);
    }

    @Override
    public void a(Object[] objectArray) {
        String string = (String)objectArray[0];
        long l2 = x ^ 0x68163F793DF5L;
        long l3 = l2 ^ 0x7281B466B77AL;
        Object[] objectArray2 = new Object[2];
        objectArray2[1] = l3;
        objectArray2[0] = "Stopped: " + string + ".";
        x_0.b(objectArray2);
    }

    @Override
    public void b(Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = x ^ 0x577A2FB8BB08L;
        long l3 = l2 ^ 0x72749BD9EBA8L;
        Object[] objectArray2 = new Object[2];
        objectArray2[1] = "Path went stale, replanning (" + n2 + ").";
        objectArray2[0] = l3;
        x_0.a(objectArray2);
    }

    private void walkToCrosshair(Object[] objectArray) {
        block12: {
            BlockPos targetPos;
            long l2;
            block13: {
                block10: {
                    BlockHitResult hitResult;
                    BlockHitResult blockHit;
                    String[] stringArray;
                    long l3;
                    block11: {
                        HitResult hit;
                        block9: {
                            HitResult rawHit;
                            block8: {
                                w pathfinder;
                                int n2;
                                int n3;
                                int n4;
                                block7: {
                                    l3 = (Long)objectArray[0];
                                    long l4 = l3 = x ^ l3;
                                    long l5 = l4 ^ 0x11B0FA2AE6BBL;
                                    n4 = (int)(l5 >>> 32);
                                    n3 = (int)(l5 << 32 >>> 48);
                                    n2 = (int)(l5 << 48 >>> 48);
                                    l2 = l4 ^ 0x4371C283F567L;
                                    w pathfinderInstance = kuzi.obf.k.w.a(new Object[0]);
                                    stringArray = kuzi.obf.j.a.c.b();
                                    pathfinder = pathfinderInstance;
                                    if (stringArray == null) break block7;
                                    if (pathfinder.a(new Object[0]) != this) break block8;
                                    pathfinder = pathfinderInstance;
                                }
                                if (pathfinder.a(new Object[0]) != kuzi.obf.k.e.IDLE) {
                                    Object[] objectArray2 = new Object[3];
                                    objectArray2[2] = n2;
                                    objectArray2[1] = n3;
                                    objectArray2[0] = n4;
                                    this.stopWalking(objectArray2);
                                    return;
                                }
                            }
                            hit = rawHit = BaseModule.a.hitResult;
                            if (stringArray == null) break block9;
                            if (!(hit instanceof BlockHitResult)) break block10;
                            hit = rawHit;
                        }
                        hitResult = blockHit = (BlockHitResult)hit;
                        if (stringArray == null) break block11;
                        if (hitResult.getType() != HitResult.mc240.BLOCK) break block10;
                        hitResult = blockHit;
                    }
                    targetPos = hitResult.getBlockPos().relative(blockHit.getDirection());
                    if (l3 < 0L) break block12;
                    if (stringArray != null) break block13;
                }
                targetPos = BaseModule.a.player.blockPosition();
            }
            Object[] objectArray3 = new Object[2];
            objectArray3[1] = (double)((Double)this.arriveRadius.a());
            objectArray3[0] = targetPos;
            Object[] objectArray4 = new Object[3];
            objectArray4[2] = l2;
            objectArray4[1] = Walker.a(new Object[]{targetPos});
            objectArray4[0] = i.a(objectArray3);
            this.startWalking(objectArray4);
        }
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private void walkToTypedTarget(Object[] var1_1) {
        block26: {
            block23: {
                block24: {
                    block22: {
                        block20: {
                            block21: {
                                var4_2 = (Integer)var1_1[0];
                                var3_3 = (Integer)var1_1[1];
                                var2_4 = (Integer)var1_1[2];
                                v0 = var5_5 = ((long)var4_2 << 32 | (long)var3_3 << 48 >>> 32 | (long)var2_4 << 48 >>> 48) ^ Walker.x;
                                var7_6 = v0 ^ 37129709591001L;
                                var9_7 = v0 ^ 140175928888826L;
                                var11_8 = Walker.d("B", (long)3017549253296744669L, (long)var5_5);
                                v1 = Walker.d("K", (Object)Walker.d("I", (Object)this, (long)3018301394249661854L, (long)var5_5), (long)3018533811064591123L, (long)var5_5);
                                if (var11_8 == null) break block20;
                                try {
                                    block27: {
                                        if (v1 != null) break block21;
                                        break block27;
                                        catch (NumberFormatException v2) {
                                            throw Walker.d("B", (Object)v2, (long)3018810548969935433L, (long)var5_5);
                                        }
                                    }
                                    v3 = "";
                                    break block22;
                                }
                                catch (NumberFormatException v4) {
                                    throw Walker.d("B", (Object)v4, (long)3018810548969935433L, (long)var5_5);
                                }
                            }
                            v1 = Walker.d("K", (Object)Walker.d("I", (Object)this, (long)3018301394249661854L, (long)var5_5), (long)3018533811064591123L, (long)var5_5);
                        }
                        v3 = ((String)v1).trim();
                    }
                    var12_9 = v3;
                    v5 = var12_9;
                    if (var11_8 == null) break block23;
                    try {
                        block28: {
                            if (!v5.isEmpty()) break block24;
                            break block28;
                            catch (NumberFormatException v6) {
                                throw Walker.d("B", (Object)v6, (long)3018810548969935433L, (long)var5_5);
                            }
                        }
                        v7 = new Object[2];
                        v7[1] = var7_6;
                        v7[0] = Walker.b("s", (int)1391, (long)(3778830624253275590L ^ var5_5));
                        Walker.d("B", (Object)v7, (long)3018605287596549952L, (long)var5_5);
                        return;
                    }
                    catch (NumberFormatException v8) {
                        throw Walker.d("B", (Object)v8, (long)3018810548969935433L, (long)var5_5);
                    }
                }
                v5 = var12_9;
            }
            var13_10 = v5.split((String)Walker.b("s", (int)2715, (long)(753024280267383354L ^ var5_5)));
            try {
                block25: {
                    try {
                        v9 = var13_10.length;
                        v10 = 3;
                        if (var11_8 == null) break block25;
                        if (v9 == v10) {
                        }
                        ** GOTO lbl76
                    }
                    catch (NumberFormatException v11) {
                        throw Walker.d("B", (Object)v11, (long)3018810548969935433L, (long)var5_5);
                    }
                    var14_11 = new BlockPos((int)Walker.d("B", (Object)new Object[]{var13_10[0]}, (long)3019626504726941827L, (long)var5_5), (int)Walker.d("B", (Object)new Object[]{var13_10[1]}, (long)3019626504726941827L, (long)var5_5), (int)Walker.d("B", (Object)new Object[]{var13_10[2]}, (long)3019626504726941827L, (long)var5_5));
                    try {
                        block29: {
                            v12 = new Object[2];
                            v12[1] = (double)((Double)Walker.d("K", (Object)Walker.d("I", (Object)this, (long)3019496049400449786L, (long)var5_5), (long)3018533811064591123L, (long)var5_5));
                            v12[0] = var14_11;
                            v13 = new Object[3];
                            v13[2] = var9_7;
                            v13[1] = Walker.d("B", (Object)new Object[]{var14_11}, (long)3024553867097400166L, (long)var5_5);
                            v13[0] = i.a(v12);
                            Walker.d("K", (Object)this, (Object)v13, (long)3018861427810312539L, (long)var5_5);
                            v14 /* !! */  = var11_8;
                            if (var4_2 >= 0) {
                                if (v14 /* !! */  != null) break block26;
                            }
                            break block29;
lbl76:
                            // 2 sources

                            v14 /* !! */  = var13_10;
                        }
                        v9 = v14 /* !! */ .length;
                        v10 = 2;
                    }
                    catch (NumberFormatException v15) {
                        throw Walker.d("B", (Object)v15, (long)3018810548969935433L, (long)var5_5);
                    }
                }
                if (v9 != v10) ** GOTO lbl101
                var14_11 = new BlockPos((int)Walker.d("B", (Object)new Object[]{var13_10[0]}, (long)3019626504726941827L, (long)var5_5), Walker.d("Q", (long)3018121855707655700L, (long)var5_5).player.blockPosition().getY(), (int)Walker.d("B", (Object)new Object[]{var13_10[1]}, (long)3019626504726941827L, (long)var5_5));
                try {
                    block30: {
                        v16 = new Object[2];
                        v16[1] = 2.0;
                        v16[0] = var14_11;
                        v17 = new Object[3];
                        v17[2] = var9_7;
                        v17[1] = Walker.d("B", (Object)new Object[]{var14_11}, (long)3024553867097400166L, (long)var5_5);
                        v17[0] = i.a(v16);
                        Walker.d("K", (Object)this, (Object)v17, (long)3018861427810312539L, (long)var5_5);
                        v18 /* !! */  = var11_8;
                        if (var3_3 > 0) {
                            if (v18 /* !! */  != null) break block26;
                        }
                        break block30;
lbl101:
                        // 2 sources

                        v19 = new Object[2];
                        v19[1] = var7_6;
                        v18 /* !! */  = v19;
                        v19[0] = Walker.b("s", (int)26038, (long)(2497740308736904474L ^ var5_5));
                    }
                    Walker.d("B", (Object)v18 /* !! */ , (long)3018605287596549952L, (long)var5_5);
                }
                catch (NumberFormatException v20) {
                    throw Walker.d("B", (Object)v20, (long)3018810548969935433L, (long)var5_5);
                }
            }
            catch (NumberFormatException var14_12) {
                v21 = new Object[2];
                v21[1] = var7_6;
                v21[0] = (String)Walker.b("s", (int)5370, (long)(2128748148189232222L ^ var5_5)) + var12_9 + (String)Walker.b("s", (int)28626, (long)(8550364520267745137L ^ var5_5));
                Walker.d("B", (Object)v21, (long)3018605287596549952L, (long)var5_5);
            }
        }
    }

    private void startWalking(Object[] objectArray) {
        block4: {
            Object[] objectArray2;
            block3: {
                int n2;
                long l2;
                long l3;
                block1: {
                    block2: {
                        Object[] objectArray3;
                        block0: {
                            i target = (i)objectArray[0];
                            String string = (String)objectArray[1];
                            l3 = (Long)objectArray[2];
                            long l4 = l3 = x ^ l3;
                            l2 = l4 ^ 0xEC8841F2E9CL;
                            long l5 = l4 ^ 0x3151BB61F4B3L;
                            J walkOptions = new J(((Boolean)this.sprint.a()).booleanValue(), ((Boolean)this.sneakNearEdges.a()).booleanValue());
                            objectArray3 = kuzi.obf.j.a.c.b();
                            Object[] objectArray4 = new Object[5];
                            objectArray4[4] = this;
                            objectArray4[3] = ((Double)this.searchBudgetMs.a()).longValue();
                            objectArray4[2] = walkOptions;
                            objectArray4[1] = target;
                            objectArray4[0] = this;
                            int n3 = kuzi.obf.k.w.a(new Object[0]).b(objectArray4);
                            if (objectArray3 == null) break block0;
                            n2 = n3;
                            if (l3 < 0L) break block1;
                            if (n2 == 0) break block2;
                            Object[] objectArray5 = new Object[2];
                            objectArray5[1] = (String)((Object)Walker.b("s", (int)25323, (long)(0x650C3C931563BD03L ^ l3))) + string + ".";
                            objectArray5[0] = l5;
                            x_0.a(objectArray5);
                        }
                        objectArray2 = objectArray3;
                        if (l3 < 0L) break block3;
                        if (objectArray2 != null) break block4;
                    }
                    n2 = 2812;
                }
                Object[] objectArray6 = new Object[2];
                objectArray6[1] = l2;
                objectArray2 = objectArray6;
                objectArray6[0] = Walker.b("s", (int)n2, (long)(0x1D99AB0AB97ED501L ^ l3));
            }
            x_0.b(objectArray2);
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private void stopWalking(Object[] objectArray) {
        Object[] objectArray2;
        w pathfinderRef;
        long l2;
        long l3;
        block9: {
            block10: {
                w pathfinder;
                block11: {
                    Object[] objectArray3;
                    int n2;
                    block8: {
                        int n3 = (Integer)objectArray[0];
                        int n4 = (Integer)objectArray[1];
                        n2 = (Integer)objectArray[2];
                        l3 = ((long)n3 << 32 | (long)n4 << 48 >>> 32 | (long)n2 << 48 >>> 48) ^ x;
                        l2 = l3 ^ 0x639083C8E76FL;
                        pathfinder = kuzi.obf.k.w.a(new Object[0]);
                        objectArray3 = Walker.d("B", (long)-8252564001617097660L, (long)l3);
                        try {
                            try {
                                pathfinderRef = pathfinder;
                                if (objectArray3 == null) break block8;
                                if (pathfinderRef.a(new Object[0]) != this) return;
                            }
                            catch (NumberFormatException numberFormatException) {
                                throw Walker.d("B", (Object)numberFormatException, (long)-8251291614222305584L, (long)l3);
                            }
                            pathfinderRef = pathfinder;
                        }
                        catch (NumberFormatException numberFormatException) {
                            throw Walker.d("B", (Object)numberFormatException, (long)-8251291614222305584L, (long)l3);
                        }
                    }
                    try {
                        try {
                            objectArray2 = objectArray3;
                            if (n2 < 0) break block9;
                            if (objectArray2 == null) break block10;
                            if (pathfinderRef.a(new Object[0]) != kuzi.obf.k.e.IDLE) break block11;
                            return;
                        }
                        catch (NumberFormatException numberFormatException) {
                            throw Walker.d("B", (Object)numberFormatException, (long)-8251291614222305584L, (long)l3);
                        }
                    }
                    catch (NumberFormatException numberFormatException) {
                        throw Walker.d("B", (Object)numberFormatException, (long)-8251291614222305584L, (long)l3);
                    }
                }
                pathfinderRef = pathfinder;
            }
            Object[] objectArray4 = new Object[1];
            objectArray2 = objectArray4;
            objectArray4[0] = this;
        }
        pathfinderRef.b(objectArray2);
        Object[] objectArray5 = new Object[2];
        objectArray5[1] = Walker.b("s", (int)23975, (long)(0x6A001FA495F11195L ^ l3));
        objectArray5[0] = l2;
        Walker.d("B", (Object)objectArray5, (long)-8251913818407393436L, (long)l3);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        KeyBinding keyBinding = (KeyBinding)objectArray[1];
        long l3 = (l2 = x ^ l2) ^ 0x696BFBEE6FF5L;
        int keyCode = (Integer)keyBinding.a();
        String[] stringArray = kuzi.obf.j.a.c.b();
        if (keyCode <= 0) return false;
        if (BaseModule.a.screen != null) return false;
        Object[] objectArray2 = new Object[2];
        objectArray2[1] = l3;
        objectArray2[0] = keyCode;
        boolean pressed = L.a(objectArray2);
        if (stringArray == null) return pressed;
        if (!pressed) return false;
        return true;
    }

    private static String a(Object[] objectArray) {
        BlockPos blockPos = (BlockPos)objectArray[0];
        return blockPos.getX() + " " + blockPos.getY() + " " + blockPos.getZ();
    }

    private void lambda$new$0(long l2) {
        l2 = x ^ l2;
        this.startRequested = true;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block16: {
            block15: {
                block14: {
                    block13: {
                        Walker.x = kuzi.obf.h.b.v.a(-2401301601061880297L, -5826816288090030346L, MethodHandles.lookup().lookupClass()).a(149897874125551L);
                        Walker.E = new Object[65];
                        Walker.F = new String[65];
                        Walker.c();
                        Walker.A = new HashMap<K, V>(13);
                        var11 = Walker.x ^ 131293024357881L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[22];
                        var18_4 = 0;
                        var17_5 = "\u0091$\u0097\u00b9\u0097A\u00d14\u00e3\u00f5\u00feD\u0007\u00cc\u00e6CP\u00a5\u00cd.\u00d7\u00e7\u00ce/`\u00bbJ\u0013\u00ed\u00b84I/\u00a1\u00147\\C\u0081\u0090\u00b8k\u00bboR\u00cf\u00cf\u00fceCQ\u009e\u008fn\u00e4\u00bd\u00c7\u00e8\u00e7g2#u\u0090 \u0019\u00e1\u00bfmb\u00a0T\u00049B\u0011\u00e9P\u008c8;M\u00ef~\u0093\u00ff\u00ae\u001f!\u0092\u00ac\u0086\u0001\u0004\u00d5\u00a3\u00cfP \u0002\u00c5:\u00e8\u00f9~\u00a8\u0089\u00caC\u00cax\u00c1\u00b8\u00a7\u00c4P\u00bf\u00cb\u00bbD\u00fft\u009c\u00b5\"Y\u00d3\u0095P\u0085\u00f1O~\u00d3\u00fdh\u0016#\u00d3\u00f6j\u00feQ\u00e8\u00f8\u0092\u00d8n%\u00f9L\u00f8Ds\u0010\u00c1\u00f3u\u00c7k%Q|a'3'\u0012*8\u001aekd]\u00ae\u00ddJ(w(\u000f9\u00a3\u00eaw\u00c1\u0091\u00fc\u00b6\u00e9\u00cd\u0014\u00d1\u00e0\u00d2\u00f8<\u00e9\u00f9t\u00fb>W\u00ca.o\u00e8\u00c8A\u00f9\u009e\u00c3\u00c99\u0092G\u0089& j\u0019\u00e7\u009c\u00aaf6v~/n\u0013\u00d5\u00a4\u00f5\u000e\u00cbp\u00ee-\u008c\u00ac\u00ae\u00af\u0016\u008a\u00a7\u0011Se\u00ce_8P)^\u0015\u00e3\u00fc\u00bbh\u0007\u0092n\u0085e\u001a@q\u000b\u001a\u0093^^0GA\u00bd\u0014\u00a5\u001b\u00fc\u00bc\u0016\u00d4\u00f7\u00b6\u008bG\u0093}v\u00fb$P>\u0005x\u00a7\u0012\u00f0~(c\u00a4\u00de\u00ac\u00e2\u0017 \u00d5B\u00df\u00c9\"\u00f20\u0012\u00d9\u00f2\u00b4\u00a9Ec\u00f6A\u00bf~#/\u00edg\u0084\u00da\u00ec\u009a|U\u007fM0\u009a\u0018z\u0012\bO\u00bd\u00d9\u00b9E\u008f\u000bD\u008cC\u00bd\u0018\u008d\u0097\u0096\u00d0\u00cdP\u00fc\u00dce(2yU\u0012\u00fc\u001ft\u00e0_\u00c4\u009fG\u00f2\u00d4\u00f8\u009f\u0099\\V\u009e\u009b\u00eb\u00e6C\u00ddhD\u00fd<-\u00a6\u0080\u00b3\u0006\u00ab\u00c7\u007f^\u00c7E f7^\u00ee\u00ad\u00c2\u00f0\u00ce\u0002Z\u00a3\u0085D\u00f9|Q\u00c8[\u00f3\u00c0\u00c4Oy\u00a1S\u00c1\n\u0095_V\u00f4V(2\u000b\u00b9A\u0096\u00f4-,V-\u0014\b\u00ef<\u001f\u00e8\u00a9Y\u008e\u00af\r\u00e0\u00e7\u00e8^\u00a00\u00db\u00e0\b\u00e0\u0091_\u0095\f\u0004_0\u00ba\u00be(U\u008e\u00a0\u00c6&\u00ee8\u00c3\u0003\u0004\u009d\u00a0}\u0099\u00f8\u00f48 \u0083\u001e\u00a8l\u00ae\u0094\u00ad\u00ac|s\u0095\u008a=M\u00da\u0090\u001d\u00a2\u00b3\u0090x\u0096 \u0018\u00d46\u0016\u00b7\u00e0:l\u00d3A\u00bc\u00ef\u0013K\u000e7,\u00b0\u00b1\u00ae\"=\u00a6\u00f4\u00d5\u00a1\u00e42.\u00fb\u00a8\u00c9\u0010,\u000e\u00c3\u0086\u00fb\u00b8j\u00cc\u00c2Z\u0014G\u008d\u009d\"\u00fd +\u000b\u00ce\f\u00a2\u0097\u00be\u0019`\u00c2LI;S\t\u001fCy\u00df\u00e3\u00c2\u0088\u00fe\u00ffr\u00a2A\u0015D1#E(\u000f\u001f\u00e8YX\u0082\u001a&\u0006lZY^\u00faB/\u000e\u00e8\u00e7w\u0091\u00d7V\u00a2\u00f1\u00b9\u00c9\bD\u001c!u\u008e\u00d1\u0001\u00b4\u00d6\u001f\u00ad\u0089\u0018\u00ff\u00f5\u0002\u00f8p*\rE\u000f\u00caEM\u00ea\u00cb\u00f0p\u00cf\u0095\u00e0\u00b8R\u0018`'\u0010\u00b1\u0093m\u00ac\u00e5\u00db{\u00bcl\u00c8\u0004\u00a4\u0088\u001d.\u008f\u0010\u00ec\u00af\u00b7\u0018>\u0000P/\u00f2\u0011\u0081\u00a5\u00c6\u00ab\u0018\u00ea\u0010\u0017p\nFC\u00e29\u00e2\u0089\u00ed8j\u0086!\u00ca\u00f8";
                        var19_6 = "\u0091$\u0097\u00b9\u0097A\u00d14\u00e3\u00f5\u00feD\u0007\u00cc\u00e6CP\u00a5\u00cd.\u00d7\u00e7\u00ce/`\u00bbJ\u0013\u00ed\u00b84I/\u00a1\u00147\\C\u0081\u0090\u00b8k\u00bboR\u00cf\u00cf\u00fceCQ\u009e\u008fn\u00e4\u00bd\u00c7\u00e8\u00e7g2#u\u0090 \u0019\u00e1\u00bfmb\u00a0T\u00049B\u0011\u00e9P\u008c8;M\u00ef~\u0093\u00ff\u00ae\u001f!\u0092\u00ac\u0086\u0001\u0004\u00d5\u00a3\u00cfP \u0002\u00c5:\u00e8\u00f9~\u00a8\u0089\u00caC\u00cax\u00c1\u00b8\u00a7\u00c4P\u00bf\u00cb\u00bbD\u00fft\u009c\u00b5\"Y\u00d3\u0095P\u0085\u00f1O~\u00d3\u00fdh\u0016#\u00d3\u00f6j\u00feQ\u00e8\u00f8\u0092\u00d8n%\u00f9L\u00f8Ds\u0010\u00c1\u00f3u\u00c7k%Q|a'3'\u0012*8\u001aekd]\u00ae\u00ddJ(w(\u000f9\u00a3\u00eaw\u00c1\u0091\u00fc\u00b6\u00e9\u00cd\u0014\u00d1\u00e0\u00d2\u00f8<\u00e9\u00f9t\u00fb>W\u00ca.o\u00e8\u00c8A\u00f9\u009e\u00c3\u00c99\u0092G\u0089& j\u0019\u00e7\u009c\u00aaf6v~/n\u0013\u00d5\u00a4\u00f5\u000e\u00cbp\u00ee-\u008c\u00ac\u00ae\u00af\u0016\u008a\u00a7\u0011Se\u00ce_8P)^\u0015\u00e3\u00fc\u00bbh\u0007\u0092n\u0085e\u001a@q\u000b\u001a\u0093^^0GA\u00bd\u0014\u00a5\u001b\u00fc\u00bc\u0016\u00d4\u00f7\u00b6\u008bG\u0093}v\u00fb$P>\u0005x\u00a7\u0012\u00f0~(c\u00a4\u00de\u00ac\u00e2\u0017 \u00d5B\u00df\u00c9\"\u00f20\u0012\u00d9\u00f2\u00b4\u00a9Ec\u00f6A\u00bf~#/\u00edg\u0084\u00da\u00ec\u009a|U\u007fM0\u009a\u0018z\u0012\bO\u00bd\u00d9\u00b9E\u008f\u000bD\u008cC\u00bd\u0018\u008d\u0097\u0096\u00d0\u00cdP\u00fc\u00dce(2yU\u0012\u00fc\u001ft\u00e0_\u00c4\u009fG\u00f2\u00d4\u00f8\u009f\u0099\\V\u009e\u009b\u00eb\u00e6C\u00ddhD\u00fd<-\u00a6\u0080\u00b3\u0006\u00ab\u00c7\u007f^\u00c7E f7^\u00ee\u00ad\u00c2\u00f0\u00ce\u0002Z\u00a3\u0085D\u00f9|Q\u00c8[\u00f3\u00c0\u00c4Oy\u00a1S\u00c1\n\u0095_V\u00f4V(2\u000b\u00b9A\u0096\u00f4-,V-\u0014\b\u00ef<\u001f\u00e8\u00a9Y\u008e\u00af\r\u00e0\u00e7\u00e8^\u00a00\u00db\u00e0\b\u00e0\u0091_\u0095\f\u0004_0\u00ba\u00be(U\u008e\u00a0\u00c6&\u00ee8\u00c3\u0003\u0004\u009d\u00a0}\u0099\u00f8\u00f48 \u0083\u001e\u00a8l\u00ae\u0094\u00ad\u00ac|s\u0095\u008a=M\u00da\u0090\u001d\u00a2\u00b3\u0090x\u0096 \u0018\u00d46\u0016\u00b7\u00e0:l\u00d3A\u00bc\u00ef\u0013K\u000e7,\u00b0\u00b1\u00ae\"=\u00a6\u00f4\u00d5\u00a1\u00e42.\u00fb\u00a8\u00c9\u0010,\u000e\u00c3\u0086\u00fb\u00b8j\u00cc\u00c2Z\u0014G\u008d\u009d\"\u00fd +\u000b\u00ce\f\u00a2\u0097\u00be\u0019`\u00c2LI;S\t\u001fCy\u00df\u00e3\u00c2\u0088\u00fe\u00ffr\u00a2A\u0015D1#E(\u000f\u001f\u00e8YX\u0082\u001a&\u0006lZY^\u00faB/\u000e\u00e8\u00e7w\u0091\u00d7V\u00a2\u00f1\u00b9\u00c9\bD\u001c!u\u008e\u00d1\u0001\u00b4\u00d6\u001f\u00ad\u0089\u0018\u00ff\u00f5\u0002\u00f8p*\rE\u000f\u00caEM\u00ea\u00cb\u00f0p\u00cf\u0095\u00e0\u00b8R\u0018`'\u0010\u00b1\u0093m\u00ac\u00e5\u00db{\u00bcl\u00c8\u0004\u00a4\u0088\u001d.\u008f\u0010\u00ec\u00af\u00b7\u0018>\u0000P/\u00f2\u0011\u0081\u00a5\u00c6\u00ab\u0018\u00ea\u0010\u0017p\nFC\u00e29\u00e2\u0089\u00ed8j\u0086!\u00ca\u00f8".length();
                        var16_7 = 64;
                        var15_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block13;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = Walker.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "\u00da\u00c9\u00cb\u0004pU$\u008cr6h\u0098/\u00dfF\u008c\u0081\u00e2r\u0099\u008d\u00864\u00b2/\u00c7l\u0016(\u00c0\u0014\u00e8\u00d8G\u00cf\u001b\u00d7\u000f\u00cf\u00f173z\u00c5~zh?\u00acf%*\u00ed}[\u0011\u0000\u0095-\f\u008f\u0092\u0098\u00f40\u00ef\u00e3\b\u00d3Jh\u00b9\u00d9j\u0017w(o2\u0003z9\u00f8\u00ef\u00ed\u00ab\u00d2\u00db\u00be=\u00f66\u00ae\u00e9G\u00b7r+\u00c1FU\u0001\u00ae\u0005]c@M`\u0083_\u000eS";
                            var19_6 = "\u00da\u00c9\u00cb\u0004pU$\u008cr6h\u0098/\u00dfF\u008c\u0081\u00e2r\u0099\u008d\u00864\u00b2/\u00c7l\u0016(\u00c0\u0014\u00e8\u00d8G\u00cf\u001b\u00d7\u000f\u00cf\u00f173z\u00c5~zh?\u00acf%*\u00ed}[\u0011\u0000\u0095-\f\u008f\u0092\u0098\u00f40\u00ef\u00e3\b\u00d3Jh\u00b9\u00d9j\u0017w(o2\u0003z9\u00f8\u00ef\u00ed\u00ab\u00d2\u00db\u00be=\u00f66\u00ae\u00e9G\u00b7r+\u00c1FU\u0001\u00ae\u0005]c@M`\u0083_\u000eS".length();
                            var16_7 = 64;
                            var15_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block13;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = Walker.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block14;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                Walker.y = var20_3;
                Walker.z = new String[22];
                Walker.D = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[3];
                var3_13 = 0;
                var4_14 = "\u00da\u00ddSg\u00d6\u009cg\u00c0\u00a1\u00aa@\u0000M\u00c8\u00d0,\u00e9\u001cD\u008f\u00bc\u008c\u0097\u008c";
                var5_15 = "\u00da\u00ddSg\u00d6\u009cg\u00c0\u00a1\u00aa@\u0000M\u00c8\u00d0,\u00e9\u001cD\u008f\u00bc\u008c\u0097\u008c".length();
                var2_16 = 0;
                while (true) {
                    break block15;
                    break;
                }
lbl76:
                // 1 sources

                while (true) {
                    var6_12[v10] = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
                    if (var2_16 < var5_15) ** continue;
                    break block16;
                    break;
                }
            }
            var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
            v10 = var3_13++;
            var8_18 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            ** while (true)
        }
        Walker.B = var6_12;
        Walker.C = new Integer[3];
    }

    private static NumberFormatException a(NumberFormatException numberFormatException) {
        return numberFormatException;
    }

    private static String b(byte[] byArray) {
        int outIndex = 0;
        int length = byArray.length;
        char[] cArray = new char[length];
        for (int i2 = 0; i2 < length; ++i2) {
            char decodedChar;
            int currentByte = 0xFF & byArray[i2];
            if (currentByte < 192) {
                cArray[outIndex++] = (char)currentByte;
                continue;
            }
            if (currentByte < 224) {
                decodedChar = (char)((char)(currentByte & 0x1F) << 6);
                currentByte = byArray[++i2];
                decodedChar = (char)(decodedChar | (char)(currentByte & 0x3F));
                cArray[outIndex++] = decodedChar;
                continue;
            }
            if (i2 >= length - 2) continue;
            decodedChar = (char)((char)(currentByte & 0xF) << 12);
            currentByte = byArray[++i2];
            decodedChar = (char)(decodedChar | (char)(currentByte & 0x3F) << 6);
            currentByte = byArray[++i2];
            decodedChar = (char)(decodedChar | (char)(currentByte & 0x3F));
            cArray[outIndex++] = decodedChar;
        }
        return new String(cArray, 0, outIndex);
    }

    private static String b(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x4145;
        if (z[n3] == null) {
            Object[] objectArray;
            try {
                Long l3 = Thread.currentThread().threadId();
                objectArray = (Object[])A.get(l3);
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    A.put(l3, objectArray);
                }
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/a/f", exception);
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l2 >>> 56);
            for (int i2 = 1; i2 < 8; ++i2) {
                byArray[i2] = (byte)(l2 << i2 * 8 >>> 56);
            }
            DESKeySpec dESKeySpec = new DESKeySpec(byArray);
            SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
            ((Cipher)objectArray[0]).init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
            byte[] byArray2 = y[n3].getBytes("ISO-8859-1");
            Walker.z[n3] = Walker.b(((Cipher)objectArray[0]).doFinal(byArray2));
        }
        return z[n3];
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        String string2 = Walker.b(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(String.class, string2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return string2;
    }

    private static CallSite b(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/a/f" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static int e(long l2, long l3) {
        int n2;
        int n3;
        int n4 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (F[n4] != null) {
            return n4;
        }
        Object object = E[n4];
        if (!(object instanceof String)) {
            return n4;
        }
        int n5 = 0;
        n5 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 5;
            case 1 -> 39;
            case 2 -> 23;
            case 3 -> 24;
            case 4 -> 38;
            case 5 -> 55;
            case 6 -> 15;
            case 7 -> 45;
            case 8 -> 13;
            case 9 -> 33;
            case 10 -> 37;
            case 11 -> 19;
            case 12 -> 20;
            case 13 -> 11;
            case 14 -> 60;
            case 15 -> 25;
            case 16 -> 8;
            case 17 -> 6;
            case 18 -> 49;
            case 19 -> 0;
            case 20 -> 27;
            case 21 -> 61;
            case 22 -> 57;
            case 23 -> 46;
            case 24 -> 28;
            case 25 -> 54;
            case 26 -> 4;
            case 27 -> 3;
            case 28 -> 42;
            case 29 -> 63;
            case 30 -> 18;
            case 31 -> 41;
            case 32 -> 40;
            case 33 -> 31;
            case 34 -> 59;
            case 35 -> 35;
            case 36 -> 62;
            case 37 -> 36;
            case 38 -> 58;
            case 39 -> 10;
            case 40 -> 22;
            case 41 -> 32;
            case 42 -> 1;
            case 43 -> 7;
            case 44 -> 17;
            case 45 -> 30;
            case 46 -> 2;
            case 47 -> 47;
            case 48 -> 56;
            case 49 -> 16;
            case 50 -> 48;
            case 51 -> 44;
            case 52 -> 43;
            case 53 -> 9;
            case 54 -> 51;
            case 55 -> 26;
            case 56 -> 52;
            case 57 -> 12;
            case 58 -> 34;
            case 59 -> 50;
            case 60 -> 29;
            case 61 -> 21;
            case 62 -> 53;
            default -> 14;
        };
        int[] nArray = new int[6];
        int n6 = 0;
        while (n6 < 6) {
            n3 = 7 * (5 - n6);
            n2 = (int)(l2 >>> n3 & 0x7FL);
            if ((n2 -= n5) < 0) {
                n2 += 128;
            }
            nArray[n6] = n2;
            ++n6;
        }
        char[] cArray = ((String)object).toCharArray();
        n3 = 0;
        while (n3 < cArray.length) {
            n2 = nArray[n3 % nArray.length];
            if (n2 == 0) break;
            cArray[n3] = (char)(cArray[n3] ^ n2);
            ++n3;
        }
        Walker.F[n4] = new String(cArray);
        return n4;
    }

    private static void c() {
        Object[] objectArray = E;
        E[0] = "!,sf\u001a50,j";
        objectArray[1] = "+S_}\u001fK^sTr\u000e\u0004?}_y\n^K";
        objectArray[2] = Void.TYPE;
        Walker.F[2] = "java/lang/Void";
        objectArray[3] = "\rc,\u000ft=\u0006c,\u000fs";
        objectArray[4] = Boolean.TYPE;
        Walker.F[4] = "java/lang/Boolean";
        objectArray[5] = ">UN7.\b5UF";
        objectArray[6] = "n)eeXSe)n";
        objectArray[7] = "P\u001e";
        objectArray[8] = "M\fXqj\u0010D\f[qo";
        objectArray[9] = "i=P&\r%b=P&\u000f";
        objectArray[10] = "\t\u0015(;jc|5#4{,\u0001-03rei";
        objectArray[11] = "i}=%f\u001fbr,j\u0006\u0006n~.6\u000e\u001cqq*0\r\u000b`y;0!\u001cm";
        objectArray[12] = "\u0010d*\u001c$G\u0019d)\u001c(";
        objectArray[13] = "+\u0011\u0006`$x\"\u0011\u0005`/";
        objectArray[14] = "?eY\u00131\u001f6eZ\u00133";
        objectArray[15] = "*CLC\nv_cGL\u001b9\"{TK\u0012pJ";
        objectArray[16] = "\u0019j\u0004w\"A\u0010j\u0007w0";
        objectArray[17] = "\t\u0017X&uY|7S)d\u0016\u001d9X\"`Li";
        objectArray[18] = "E1\u007f,6}T1R";
        objectArray[19] = "v@-V9\u000b\u0003`&Y(Dbn-R,\u001e\u0016";
        objectArray[20] = "\r@DL#T\r@S\u0010/[\u0017\u000bS\u000e/N\u0010z\u0003S~";
        objectArray[21] = "gv8[E;nv;[E";
        objectArray[22] = "(!mmo+#.|\"\u000e%(%xx";
        objectArray[23] = "Qt\u0000.E\u000b$T\u000b!TDEZ\u0000*P\u001e1";
        objectArray[24] = "C\u0017u6/S67~9>\u001cW9u2:F#";
        objectArray[25] = "\u0015<5k#d`\u001c>d2+\u0001\u00125o6qu";
        objectArray[26] = "\u0014\t\u0019t!\u001fa)\u0012{0P\u0000'\u0019p4\nt";
        objectArray[27] = "-a}luKXAvcd\u00049O}h`^M";
        objectArray[28] = "\tw\\V\b'|WWY\u0019h\u001dY\\R\u001d2i";
        objectArray[29] = "\u00197\u001cyNEl\u0017\u0017v_\n\r\u0019\u001c}[Py";
        objectArray[30] = "\nW]$vg\u0001XLk\u000b\u007f\u0012_E\"";
        objectArray[31] = "jC\b\u0004Qo\u001fc\u0003\u000b@ ~m\b\u0000Dz\n";
        objectArray[32] = Integer.TYPE;
        Walker.F[32] = "java/lang/Integer";
        objectArray[33] = ",\u0016vz;o'\u0016qz7";
        objectArray[34] = "e\u001am}\u000bs\u0010:fr\u001a<q4my\u001ef\u0005";
        objectArray[35] = "Pe2\u0015V\u0006\u0015>a\u0003/\u0013j8s\t\u0010TQ$oUHkS `\u0016\u0014S\u0004ncR/";
        objectArray[36] = "8r-M~\u0019>$b\u0006C\u001f\u0006rl\u00163Kjaw\u0010{u";
        objectArray[37] = "\u0002*-\u0011IrGq~\u00070z8wl\r\u000f \u0003kpQW\u001f\u0001o\u007f\u0012\u000b'V!|V0";
        objectArray[38] = "KWwZuh\u0012E~^\u0019;-]6Y&m\u0016A*\u0005~R\u0014E%F\"jC\u000b&\u0002\u0019";
        objectArray[39] = "\u000eFd+YSK\u001d7= G4Llb\\[\n\r?0]";
        objectArray[40] = "P\u0014\u000e>t\u0007\u0015O](\r\u0010jF\u0000\"l\t\t\u0014S#b";
        objectArray[41] = "\n*0tQ\nOqcb(\u00000{ll\u0010\u000e@py4C";
        objectArray[42] = "6Rlgg1!\u0018kyY7X\u00075r&g2\u0010gp)^";
        objectArray[43] = "\u0000T\u000b->1E\u000fX;G':\u0006\u00051&?YTV0(";
        objectArray[44] = "!\u0003\u0018\u0004\u0007\u000fdXK\u0012~\u0004\u001b^Y\u0018A] BED\u0019b\"FJ\u0007EZu\bIC~";
        objectArray[45] = "6,~q!~->zJ/\u000667puy=*+,-F?.$oq~h`'+J";
        objectArray[46] = "{sAG\u000bLh,N\u000fjZ\u0017(]QU\f,4A\r\r3,%\u0012_\u000e\u000b~r\u0016\nj";
        objectArray[47] = "\u00187\u00187+{C9\u000evU*$kB<6<\u001bb@w0";
        objectArray[48] = "k\u000e\u001f\u0019N`j\r\u001e\u0000wN\u0017\"h9:M\f|\u001e\u000eMni\u0017\u001f\rLw";
        objectArray[49] = "\u0019\u0002t4`W\\Y'\"\u0019]#_5(&\u0005\u0018C)t~:\u001aG&7\"\u0002M\t%s\u0019";
        objectArray[50] = "zs.nr\r?(}x\u000b\u001e@st)a\u0004x!#-4";
        objectArray[51] = "t\u001a\u001c3xu/\u0014\nr\u0006'H\u0016G2|}1@\u0001vkM";
        objectArray[52] = "Qty\u0000\u0010\u0002\u0014/*\u0016i\u0017kr3\u001bR\f\u0013\u007f!\u0002X";
        objectArray[53] = "yD>\u0005\u000f\u001cbV:>\u0002dy_0\u0001W_eClYh]aL/\u0005P\n/Ok>";
        objectArray[54] = "\u0016kpBH\u0007S0#T1\u0003,o'\u0001LWU2,E[j\u00136zG\f\u0013N=>P1";
        objectArray[55] = "d;T\f$\u0012!`\u0007\u001a]\u0003^0\u0000\u0011g\u0003!g\u001eE<";
        objectArray[56] = "K$cv_\u001e\u000e\u007f0`&\u000eq/7k\u001c\u000f\u000ex)?G";
        objectArray[57] = "\u0015\ri/0\u007f\u0013[&d\ry+\r(t}-G\u001e3r5\u0013\u0012\u001a:o6+ET9+\r";
        objectArray[58] = "=\u0002Xt%)xY\u000bb\\-\u0007_\u0019hc{<C\u00054;DbX\tm8 y[\u0005=\\";
        objectArray[59] = "1-yas\u0013tv*w\n\u0001\u000b-#&`\u001a3\u007ft\"5";
        objectArray[60] = "*\u000f/8A]oT|.8V\u0010\u0005'qDU.Dt#E";
        objectArray[61] = "\u0001Z\u0000\u0015C2D\u0001S\u0003:6;\u0007A\t\u0005`\u0000\u001b]U]_\u0000\n\u000e\u0007^gR]\nR:";
        objectArray[62] = "P\u000e3\u0017p\u000b\u0015U`\u0001\t\u0003j\u000eiPc\u0002R\\>T6";
        objectArray[63] = "h\u0012U`d\b3\u001cC!\u001aTTEB}%\u000foY^!}0m]Qb!\b:\u0013R&\u001a";
        Object[] objectArray2 = objectArray;
        objectArray[64] = "5`w\\{ap;$J\u0002e\u000f=6@=34!*\u001ce\fkb4Ba=5)'H\u0002";
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n2 = Walker.e(l2, l3);
            object = E[n2];
            try {
                if (!(object instanceof String)) break block2;
                Walker.E[n2] = clazz = Class.forName(F[n2]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = Walker.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = Walker.d(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Field g(long l2, long l3) {
        int n2 = Walker.e(l2, l3);
        Object object = E[n2];
        if (object instanceof String) {
            String string = F[n2];
            int n3 = string.indexOf(8);
            Class clazz = Walker.f(Long.parseLong(string.substring(0, n3), 36), 0L);
            int n4 = string.indexOf(8, ++n3);
            String string2 = string.substring(n3, n4);
            Class clazz2 = Walker.f(Long.parseLong(string.substring(++n4), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = Walker.c(clazz3, string2, clazz2)) != null) {
                    Walker.E[n2] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int i2 = 0; i2 < classArray.length; ++i2) {
                        field = Walker.d(classArray[i2], string2, clazz2);
                        if (field == null) continue;
                        Walker.E[n2] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = Walker.f(1578794187079041L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n2) continue;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n2, Class[] classArray) {
        Method method = Walker.c(clazz, string, clazz2, n2, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = Walker.d(classArray2[i2], string, clazz2, n2, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n2 = Walker.e(l2, l3);
        Object object = E[n2];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n3;
            String string;
            Class clazz3;
            block10: {
                String string2 = F[n2];
                int n4 = string2.indexOf(8);
                clazz3 = Walker.f(Long.parseLong(string2.substring(0, n4), 36), 0L);
                int n5 = string2.indexOf(8, ++n4);
                string = string2.substring(n4, n5);
                int n6 = -1;
                int n7 = n5;
                do {
                    ++n6;
                    ++n7;
                } while ((n7 = string2.indexOf(8, n7)) > -1);
                n3 = n6 - 1;
                classArray2 = new Class[n3];
                clazz2 = null;
                n7 = n5 + 1;
                for (int i2 = 0; i2 < n6; ++i2) {
                    int n8 = string2.indexOf(8, n7);
                    clazz2 = Walker.f(Long.parseLong(string2.substring(n7, n8), 36), 0L);
                    if (i2 < n3) {
                        classArray2[i2] = clazz2;
                    }
                    n7 = n8 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = Walker.c(clazz, string, clazz2, n3, classArray2)) != null) {
                        Walker.E[n2] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = Walker.f(1578794187079041L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int i3 = 0; i3 < classArray.length; ++i3) {
                        Method method = Walker.d(classArray[i3], string, clazz2, n3, classArray2);
                        if (method == null) continue;
                        Walker.E[n2] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = Walker.f(1578794187079041L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n9 = 0;
            while (n9 < n3) {
                stringBuffer.append(classArray2[n9].getName());
                if (++n9 >= n3) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c2 = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c2 == 'I' || c2 == 'X' || c2 == 'Q' || c2 == '\u00c7') {
                field = Walker.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c2 == 'I' ? lookup.findGetter(clazz, string2, clazz2) : (c2 == 'X' ? lookup.findSetter(clazz, string2, clazz2) : (c2 == 'Q' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = Walker.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c2 == 'K' ? lookup.findVirtual(clazz, string3, methodType2) : (c2 == 'B' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, new Class[]{Long.TYPE, Long.TYPE});
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n2 = objectArray.length - 2;
        long l2 = (Long)objectArray[n2];
        long l3 = (Long)objectArray[++n2];
        MethodHandle methodHandle = Walker.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite d(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/a/f" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(Walker.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(Walker.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

