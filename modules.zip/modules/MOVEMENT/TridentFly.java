// === Kuzi module: TridentFly ===
// Category   : MOVEMENT
// Description: Undetectable Trident Fly. Requires Rain, RipTide
// Payload    : a.a.a.j.d.s (verified: True)

package kuzi.modules.movement;

import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.h.b.v;
import kuzi.obf.j.d.b;
import kuzi.obf.m.r;
import kuzi.obf.p.x_0;
import net.minecraft.LivingEntity;
import net.minecraft.ItemStack;
import net.minecraft.Items;
import net.minecraft.Enchantment;
import net.minecraft.EnchantmentHelper;
import net.minecraft.Enchantments;
import net.minecraft.Registry;
import net.minecraft.Minecraft;
import net.minecraft.Holder;
import net.minecraft.LocalPlayer;
import net.minecraft.Registries;

public class TridentFly
extends BaseModule {
    private boolean keyHeld = false;
    private boolean releaseScheduled = false;
    private int previousSlot = -1;
    private int releaseTicks = 0;
    private long lastTickNanos;
    private static final long r;
    private static final String[] s;
    private static final String[] t;
    private static final Map u;
    private static final long[] v;
    private static final Integer[] w;
    private static final Map x;
    private static final Object[] y;
    private static final String[] z;

    public TridentFly() {
        super("TridentFly", "Undetectable Trident Fly. Requires Rain, RipTide", Category.MOVEMENT);
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public void d() {
        v0 = var1_1 = TridentFly.r ^ 68351866691881L;
        var3_2 = v0 ^ 3052575939383L;
        var5_3 = v0 ^ 115242566454011L;
        super.d();
        this.keyHeld = false;
        var7_4 = kuzi.obf.j.d.b.b();
        this.releaseScheduled = false;
        this.previousSlot = -1;
        this.releaseTicks = 0;
        if (var7_4 != 0) {
            if (BaseModule.a.player != null) {
                v1 = this;
                if (var7_4 != 0) {
                    v2 = new Object[1];
                    v2[0] = var3_2;
                    if (!v1.a(v2)) {
                        v3 = new Object[2];
                        v3[1] = var5_3;
                        v3[0] = "No riptide trident found in hotbar!";
                        x_0.c(v3);
                        this.j();
                        return;
                    } else {
                        ** GOTO lbl-1000
                    }
                }
            } else lbl-1000:
            // 3 sources

            {
                v1 = this;
            }
            v1.lastTickNanos = System.nanoTime();
        }
    }

    @Override
    public void e() {
        block5: {
            LocalPlayer player;
            block6: {
                int n2 = kuzi.obf.j.d.b.b();
                super.e();
                int guard = n2;
                int n4 = BaseModule.a.options.keyUse.isDown();
                if (guard != 0) {
                    if (n4 != 0) {
                        BaseModule.a.options.keyUse.setDown(false);
                    }
                    n4 = this.previousSlot;
                }
                if (n4 == -1) break block5;
                player = BaseModule.a.player;
                if (guard == 0) break block6;
                if (player == null) break block5;
                player = BaseModule.a.player;
            }
            player.getInventory().setSelectedSlot(this.previousSlot);
            this.previousSlot = -1;
        }
    }

    @Override
    public void i() {
        block19: {
            block20: {
                TridentFly tridentFly;
                block21: {
                    Minecraft mc;
                    int n2;
                    block24: {
                        int n3;
                        block22: {
                            block23: {
                                boolean bl;
                                int n4;
                                block16: {
                                    block17: {
                                        block18: {
                                            int remainingDurability;
                                            ItemStack heldItem;
                                            long l2;
                                            block14: {
                                                block15: {
                                                    int n6;
                                                    block13: {
                                                        long l3;
                                                        long l4 = l3 = r ^ 0x26313C2F2605L;
                                                        long l5 = l4 ^ 0x1ADDEF209C1BL;
                                                        l2 = l4 ^ 0x70CB54A84DD7L;
                                                        n2 = kuzi.obf.j.d.b.b();
                                                        if (BaseModule.a.player == null) {
                                                            return;
                                                        }
                                                        long now = System.nanoTime();
                                                        float elapsedSeconds = (float)(now - this.lastTickNanos) / 1.0E9f;
                                                        this.lastTickNanos = now;
                                                        Minecraft mcRef = BaseModule.a;
                                                        if (n2 != 0) {
                                                            if (mcRef.level.getRainLevel(elapsedSeconds) == 0.0f) {
                                                                Object[] objectArray = new Object[2];
                                                                objectArray[1] = l2;
                                                                objectArray[0] = "It needs to be raining to use this!";
                                                                x_0.c(objectArray);
                                                                this.j();
                                                                return;
                                                            }
                                                            mcRef = BaseModule.a;
                                                        }
                                                        heldItem = mcRef.player.getMainHandItem();
                                                        Object[] objectArray = new Object[1];
                                                        objectArray[0] = l5;
                                                        n6 = this.a(objectArray);
                                                        if (n2 != 0) {
                                                            if (n6 == 0) {
                                                                Object[] objectArray2 = new Object[2];
                                                                objectArray2[1] = l2;
                                                                objectArray2[0] = "No riptide trident found in hotbar!";
                                                                x_0.c(objectArray2);
                                                                this.j();
                                                                return;
                                                            }
                                                            n6 = heldItem.isDamageableItem();
                                                        }
                                                        if (n2 == 0) break block13;
                                                        if (n6 == 0) break block14;
                                                        n6 = heldItem.getMaxDamage();
                                                    }
                                                    int maxDamage = n6;
                                                    int damage = heldItem.getDamageValue();
                                                    remainingDurability = maxDamage - damage;
                                                    double durabilityPercent = (double)remainingDurability / (double)maxDamage * 100.0;
                                                    if (n2 == 0) break block15;
                                                    if (!(durabilityPercent <= 20.0)) break block14;
                                                    Object[] objectArray = new Object[2];
                                                    objectArray[1] = l2;
                                                    objectArray[0] = "Trident durability too low!";
                                                    x_0.c(objectArray);
                                                    this.j();
                                                }
                                                return;
                                            }
                                            Registry enchantmentRegistry = BaseModule.a.getConnection().registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
                                            Holder riptideHolder = enchantmentRegistry.getOptional(Enchantments.RIPTIDE).map(arg_0 -> ((Registry)enchantmentRegistry).wrapAsHolder(arg_0)).orElseThrow();
                                            int n7 = EnchantmentHelper.getItemEnchantmentLevel((Holder)riptideHolder, (ItemStack)heldItem);
                                            if (n2 != 0) {
                                                if (n7 == 0) {
                                                    Object[] objectArray = new Object[2];
                                                    objectArray[1] = l2;
                                                    objectArray[0] = "No riptide trident found in hotbar!";
                                                    x_0.c(objectArray);
                                                    this.j();
                                                    return;
                                                }
                                                n7 = heldItem.getUseDuration((LivingEntity)BaseModule.a.player);
                                            }
                                            int useDuration = n7;
                                            int remainingUseTicks = BaseModule.a.player.getUseItemRemainingTicks();
                                            n4 = useDuration - remainingUseTicks;
                                            bl = this.releaseScheduled;
                                            if (n2 == 0) break block16;
                                            if (!bl) break block17;
                                            ++this.releaseTicks;
                                            TridentFly tridentFly2 = this;
                                            if (n2 == 0) break block18;
                                            if (tridentFly2.releaseTicks < 1) break block19;
                                            this.releaseScheduled = false;
                                            tridentFly2 = this;
                                        }
                                        tridentFly2.keyHeld = true;
                                        BaseModule.a.options.keyUse.setDown(true);
                                        if (n2 != 0) break block19;
                                    }
                                    tridentFly = this;
                                    if (n2 == 0) break block20;
                                    bl = tridentFly.keyHeld;
                                }
                                if (!bl) break block21;
                                n3 = BaseModule.a.player.isUsingItem();
                                if (n2 == 0) break block22;
                                if (n3 == 0) break block23;
                                n3 = n4;
                                if (n2 == 0) break block22;
                                if (n3 < 10) break block23;
                                BaseModule.a.options.keyUse.setDown(false);
                                this.keyHeld = false;
                                this.releaseScheduled = true;
                                this.releaseTicks = 0;
                                if (n2 != 0) break block19;
                            }
                            mc = BaseModule.a;
                            if (n2 == 0) break block24;
                            n3 = mc.player.isUsingItem() ? 1 : 0;
                        }
                        if (n3 != 0) break block19;
                        mc = BaseModule.a;
                    }
                    mc.options.keyUse.setDown(true);
                    if (n2 != 0) break block19;
                }
                tridentFly = this;
            }
            tridentFly.keyHeld = true;
            BaseModule.a.options.keyUse.setDown(true);
        }
    }

    /*
     * Unable to fully structure code
     */
    private boolean a(Object[] payload) {
        block9: {
            block11: {
                block10: {
                    token = (Long)payload[0];
                    token = TridentFly.r ^ token;
                    guard = kuzi.obf.j.d.b.b();
                    if (BaseModule.a.player == null) {
                        return false;
                    }
                    savedSlot = this.previousSlot;
                    restoreSlot = guard;
                    if (token <= 0L) break block10;
                    if (restoreSlot == 0) break block11;
                    restoreSlot = -1;
                }
                if (savedSlot == restoreSlot) {
                    this.previousSlot = BaseModule.a.player.getInventory().getSelectedSlot();
                }
                savedSlot = slotIndex = 0;
            }
            while (slotIndex < TridentFly.c("g", (int)6576, (long)(8112081262159875887L ^ token))) {
                block15: {
                    block13: {
                        block14: {
                            block12: {
                                slotItem = BaseModule.a.player.getInventory().getItem(slotIndex);
                                found = guard;
                                if (token <= 0L) break block12;
                                if (found == 0) break block13;
                                found = (int)slotItem.is(Items.TRIDENT);
                            }
                            if (guard == 0) break block9;
                            if (found == 0) break block14;
                            enchantmentRegistry = BaseModule.a.getConnection().registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
                            riptideHolder = enchantmentRegistry.getOptional(Enchantments.RIPTIDE).map((Function<Enchantment, Holder>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Ljava/lang/Object;, wrapAsHolder(java.lang.Object ), (Lnet/minecraft/Enchantment;)Lnet/minecraft/Holder;)((Registry)enchantmentRegistry)).orElseThrow();
                            riptideLevel = EnchantmentHelper.getItemEnchantmentLevel((Holder)riptideHolder, (ItemStack)slotItem);
                            guardCopy = guard;
                            if (token < 0L) break block15;
                            if (guardCopy != 0) {
                                if (riptideLevel > 0) {
                                    BaseModule.a.player.getInventory().setSelectedSlot(slotIndex);
                                    return true;
                                } else {
                                    ** GOTO lbl39
                                }
                            }
                            break block13;
                        }
                        ++slotIndex;
                    }
                    guardCopy = guard;
                }
                if (guardCopy != 0) continue;
            }
            found = 0;
        }
        return (boolean)found;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block16: {
            block15: {
                block14: {
                    block13: {
                        TridentFly.r = kuzi.obf.h.b.v.a(470034328221904264L, 1806538510884484498L, MethodHandles.lookup().lookupClass()).a(243314592165473L);
                        TridentFly.y = new Object[26];
                        TridentFly.z = new String[26];
                        TridentFly.c();
                        TridentFly.u = new HashMap<K, V>(13);
                        var11 = TridentFly.r ^ 41810188797696L;
                        var13_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                        v0 = SecretKeyFactory.getInstance("DES");
                        v1 = new byte[8];
                        v2 = v1;
                        v1[0] = (byte)(var11 >>> 56);
                        for (var14_2 = 1; var14_2 < 8; ++var14_2) {
                            v2 = v2;
                            v2[var14_2] = (byte)(var11 << var14_2 * 8 >>> 56);
                        }
                        var13_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                        var20_3 = new String[6];
                        var18_4 = 0;
                        var17_5 = "\u00f9w3\u0097\u008e~_\u00d9M\u0017\u008a\u00dc=5D\u00dfrST\u0002p\u00c3\u001bc<d\u00a2_\u00c4\u001d\u00942\u00ed$\n\u0083^\u00fd\u001c)LF\u001b\u00ccG\u00cf\u00fd7:\u00c5kc\u00cb\u00a6tD\u00fe\u000e\u0013\u00ee\u00e4\u0003\u0014\u00c00\u000bW\u00d9\u008e\u00f9\u00b9\u0097\u0096\u0091l~C&;4\u001e\u008e\u0005\b-.\u00c2\u0085\u00fd\u0082d\u00d0B\u00afR0?\u00da?/\u001b\u0002\u00d4\u0093]O\u00b8\u00c0\u00b4@\u00fe\u0086HX#>\u00c3D\u00e6\u0001\u00f7\u00cf\u00ff\u00cf\u00a6E\u0011^\u00b0\u00e7\u00fc\u00fe\u00a09S\tJ\u001e\u0091\u00fe\u00f2\u00e4\u00de\u00b1\u0015!\u001b +1\u009bP\u00d5\u0089\u0093\u00c0\u00d3\\%\u00d4T%\u00e9\u00e3\u0015\u00bf\u0004\u00b43n9\u00b3\u00a3\u00ac\u00be|\u00d9\u00bc\u00fb!<#f\u00feN\u00e4r\u009d9\u0099n\u0085\u00f0\u0018\u00e5;\\\u00f7_\u00c5{\u0085\u0018\u00ed2\u009c\u00bd\u00f5\u00f5\u00e1\u00ff\u0083\u00ab\u00c4G4^E\u00b0\u00d5S\u00b1\u008dS\u0097\u00e0\u00bf";
                        var19_6 = "\u00f9w3\u0097\u008e~_\u00d9M\u0017\u008a\u00dc=5D\u00dfrST\u0002p\u00c3\u001bc<d\u00a2_\u00c4\u001d\u00942\u00ed$\n\u0083^\u00fd\u001c)LF\u001b\u00ccG\u00cf\u00fd7:\u00c5kc\u00cb\u00a6tD\u00fe\u000e\u0013\u00ee\u00e4\u0003\u0014\u00c00\u000bW\u00d9\u008e\u00f9\u00b9\u0097\u0096\u0091l~C&;4\u001e\u008e\u0005\b-.\u00c2\u0085\u00fd\u0082d\u00d0B\u00afR0?\u00da?/\u001b\u0002\u00d4\u0093]O\u00b8\u00c0\u00b4@\u00fe\u0086HX#>\u00c3D\u00e6\u0001\u00f7\u00cf\u00ff\u00cf\u00a6E\u0011^\u00b0\u00e7\u00fc\u00fe\u00a09S\tJ\u001e\u0091\u00fe\u00f2\u00e4\u00de\u00b1\u0015!\u001b +1\u009bP\u00d5\u0089\u0093\u00c0\u00d3\\%\u00d4T%\u00e9\u00e3\u0015\u00bf\u0004\u00b43n9\u00b3\u00a3\u00ac\u00be|\u00d9\u00bc\u00fb!<#f\u00feN\u00e4r\u009d9\u0099n\u0085\u00f0\u0018\u00e5;\\\u00f7_\u00c5{\u0085\u0018\u00ed2\u009c\u00bd\u00f5\u00f5\u00e1\u00ff\u0083\u00ab\u00c4G4^E\u00b0\u00d5S\u00b1\u008dS\u0097\u00e0\u00bf".length();
                        var16_7 = 64;
                        var15_8 = -1;
lbl23:
                        // 2 sources

                        while (true) {
                            v3 = ++var15_8;
                            v4 = var17_5.substring(v3, v3 + var16_7);
                            v5 = -1;
                            break block13;
                            break;
                        }
lbl28:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = TridentFly.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            var17_5 = "\u00a3fHt)\u00c7p\u00b5@<\u00c0\u00af\u008d\u001b_O\u00cf\u00c6\u0090G\u00adA\u0014\u0084\u00df8\u00ea\u00b0\u0003\u00c44|Ul\u0015\u00b2\u00b7\u0005\u001c\u00bep\u0006\u00f1\u0016\u00e0Zm\u00cfs\u00bauCD\u0001\u00e06q\u00cb\u00a7\nk$\u00b1\u00af8\u00f8.\u00f7\u008d\u0001y\u00e8\u00adONDO\u00d2\u00f8^\u0094}\u00cb\u0002\u0093h\t57\u00b6\u009c\u0013\u00da\u00e1\u00d5\u00b3L\u00c0x$(\u00df\u0004r\u00aa\n\u00a0C=\u00c4\u0087\u000f>\u0018\u00b9\u00c3,\u0016\u00df\u00ee\u00b6";
                            var19_6 = "\u00a3fHt)\u00c7p\u00b5@<\u00c0\u00af\u008d\u001b_O\u00cf\u00c6\u0090G\u00adA\u0014\u0084\u00df8\u00ea\u00b0\u0003\u00c44|Ul\u0015\u00b2\u00b7\u0005\u001c\u00bep\u0006\u00f1\u0016\u00e0Zm\u00cfs\u00bauCD\u0001\u00e06q\u00cb\u00a7\nk$\u00b1\u00af8\u00f8.\u00f7\u008d\u0001y\u00e8\u00adONDO\u00d2\u00f8^\u0094}\u00cb\u0002\u0093h\t57\u00b6\u009c\u0013\u00da\u00e1\u00d5\u00b3L\u00c0x$(\u00df\u0004r\u00aa\n\u00a0C=\u00c4\u0087\u000f>\u0018\u00b9\u00c3,\u0016\u00df\u00ee\u00b6".length();
                            var16_7 = 64;
                            var15_8 = -1;
lbl37:
                            // 2 sources

                            while (true) {
                                v6 = ++var15_8;
                                v4 = var17_5.substring(v6, v6 + var16_7);
                                v5 = 0;
                                break block13;
                                break;
                            }
                            break;
                        }
lbl42:
                        // 1 sources

                        while (true) {
                            var20_3[var18_4++] = TridentFly.b(var21_9).intern();
                            if ((var15_8 += var16_7) < var19_6) {
                                var16_7 = var17_5.charAt(var15_8);
                                ** continue;
                            }
                            break block14;
                            break;
                        }
                    }
                    var21_9 = var13_1.doFinal(v4.getBytes("ISO-8859-1"));
                    switch (v5) {
                        default: {
                            ** continue;
                        }
                        ** case 0:
lbl54:
                        // 1 sources

                        ** continue;
                    }
                }
                TridentFly.s = var20_3;
                TridentFly.t = new String[6];
                TridentFly.x = new HashMap<K, V>(13);
                var0_10 = Cipher.getInstance("DES/CBC/NoPadding");
                v7 = SecretKeyFactory.getInstance("DES");
                v8 = new byte[8];
                v9 = v8;
                v8[0] = (byte)(var11 >>> 56);
                for (var1_11 = 1; var1_11 < 8; ++var1_11) {
                    v9 = v9;
                    v9[var1_11] = (byte)(var11 << var1_11 * 8 >>> 56);
                }
                var0_10.init(2, (Key)v7.generateSecret(new DESKeySpec(v9)), new IvParameterSpec(new byte[8]));
                var6_12 = new long[2];
                var3_13 = 0;
                var4_14 = "\u0015`\u00ff\u00c1\u00f3es\u00e3\u0080\u0084\u00ca\u0090\u00f8\u00e3B\u0019";
                var5_15 = "\u0015`\u00ff\u00c1\u00f3es\u00e3\u0080\u0084\u00ca\u0090\u00f8\u00e3B\u0019".length();
                var2_16 = 0;
                while (true) {
                    break block15;
                    break;
                }
lbl76:
                // 1 sources

                while (true) {
                    var6_12[v10] = ((long)var10_19[0] & 255L) << 56 | ((long)var10_19[1] & 255L) << 48 | ((long)var10_19[2] & 255L) << 40 | ((long)var10_19[3] & 255L) << 32 | ((long)var10_19[4] & 255L) << 24 | ((long)var10_19[5] & 255L) << 16 | ((long)var10_19[6] & 255L) << 8 | (long)var10_19[7] & 255L;
                    if (var2_16 < var5_15) ** continue;
                    break block16;
                    break;
                }
            }
            var7_17 = var4_14.substring(var2_16, var2_16 += 8).getBytes("ISO-8859-1");
            v10 = var3_13++;
            var8_18 = ((long)var7_17[0] & 255L) << 56 | ((long)var7_17[1] & 255L) << 48 | ((long)var7_17[2] & 255L) << 40 | ((long)var7_17[3] & 255L) << 32 | ((long)var7_17[4] & 255L) << 24 | ((long)var7_17[5] & 255L) << 16 | ((long)var7_17[6] & 255L) << 8 | (long)var7_17[7] & 255L;
            var10_19 = var0_10.doFinal(new byte[]{(byte)(var8_18 >>> 56), (byte)(var8_18 >>> 48), (byte)(var8_18 >>> 40), (byte)(var8_18 >>> 32), (byte)(var8_18 >>> 24), (byte)(var8_18 >>> 16), (byte)(var8_18 >>> 8), (byte)var8_18});
            ** while (true)
        }
        TridentFly.v = var6_12;
        TridentFly.w = new Integer[2];
    }

    private static r a(r value) {
        return value;
    }

    private static String b(byte[] byArray) {
        int outIndex = 0;
        int inputLength = byArray.length;
        char[] cArray = new char[inputLength];
        for (int index = 0; index < inputLength; ++index) {
            char ch;
            int byteValue = 0xFF & byArray[index];
            if (byteValue < 192) {
                cArray[outIndex++] = (char)byteValue;
                continue;
            }
            if (byteValue < 224) {
                ch = (char)((char)(byteValue & 0x1F) << 6);
                byteValue = byArray[++index];
                ch = (char)(ch | (char)(byteValue & 0x3F));
                cArray[outIndex++] = ch;
                continue;
            }
            if (index >= inputLength - 2) continue;
            ch = (char)((char)(byteValue & 0xF) << 12);
            byteValue = byArray[++index];
            ch = (char)(ch | (char)(byteValue & 0x3F) << 6);
            byteValue = byArray[++index];
            ch = (char)(ch | (char)(byteValue & 0x3F));
            cArray[outIndex++] = ch;
        }
        return new String(cArray, 0, outIndex);
    }

    private static int c(int n2, long l2) {
        int n3 = n2 ^ (int)(l2 & 0x7FFFL) ^ 0x6C81;
        if (w[n3] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = v[n3];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])x.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    x.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("a/a/a/j/d/s", exception);
            }
            int n4 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            TridentFly.w[n3] = n4;
        }
        return w[n3];
    }

    private static int c(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n2 = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n3 = TridentFly.c(n2, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n3);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, new Class[]{Integer.TYPE, Long.TYPE}));
        return n3;
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("a/a/a/j/d/s" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static void c() {
        Object[] objectArray = y;
        y[0] = "AHu\u0011'\u0010JHp\u0011$";
        objectArray[1] = Integer.TYPE;
        TridentFly.z[1] = "java/lang/Integer";
        objectArray[2] = "\u000bBwo\u007f\f\u0000B|";
        objectArray[3] = "\fzd\u000f_]\fzsSSR\u00161sMSG\u0011@#\u0010\u0002";
        objectArray[4] = Void.TYPE;
        TridentFly.z[4] = "java/lang/Void";
        objectArray[5] = "9QkB/\u00162QnB=";
        objectArray[6] = Boolean.TYPE;
        TridentFly.z[6] = "java/lang/Boolean";
        objectArray[7] = "\u0000=&[?Hu\u001d-T.\u0007\u0014\u0013&_*]`";
        objectArray[8] = "\u0000BI1\u0002i\fBZ";
        objectArray[9] = "9\b\u0004\u00175v(\b\u001d";
        objectArray[10] = "\u000f\u001e\u0007rqsz>\f}`<\u001b0\u0007vdfo";
        objectArray[11] = Long.TYPE;
        TridentFly.z[11] = "java/lang/Long";
        objectArray[12] = "\bnj2\u0017o\u0003nb";
        objectArray[13] = "K9F Q\u0015@6Wo0\u001bK=S5";
        objectArray[14] = "c5e[\u001fD1hs5\u0005)~/e_QOba?5";
        objectArray[15] = ":,_V)*9!Z@T8\u0003yG\u001dl#f,\u0018J5";
        objectArray[16] = ";\u00150Wgz}\u001d(\u0000\r\u007f\u0005Og\u001dbz~\u0002<]`\u0014>\u0019h\u000bn(4\u001clV\r";
        objectArray[17] = "$\u0002<eU4}N(3,w\u001fOy Kls\u0004|8Q";
        objectArray[18] = "Y|u\u001d\u001a,Zqp\u000bg5`(bY\u00004\\\"g]]W";
        objectArray[19] = "_t\u0000PBj\u00068\u0014\u0006;6d5N\u0014^<\u0004l\u0004\u0016Y";
        objectArray[20] = "q\u001a\u0015b@\b(V\u000149UJ\u0015\u0014<S\f,\tZf";
        objectArray[21] = "\u0011\u0006kf%d\u001d\u001eo}H@f IG\u0005C}~4z'aL\u001f8b#z";
        objectArray[22] = "`!p@^79md\u0016'd[c?\u000bHc .dKJ\rglp\u001fKm>&r\u0018'";
        objectArray[23] = "h\u0016l\u0000\u0000\u00041ZxVy[SW\"D\u001cR3\u000ehF\u001b";
        objectArray[24] = "\rH\boG+T\u0004\u001c9>x6\u000bK7FoV\f\u0010hQ\u0011\b\b\u0014-@q\u000fSK:>";
        Object[] objectArray2 = objectArray;
        objectArray[25] = "1MT\"^\u0006h\u0001@t'D\nBU|M\u0002l^\u001b&";
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = TridentFly.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int index = 0; index < classArray.length; ++index) {
                field = TridentFly.d(classArray[index], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int parameterCount, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != parameterCount) continue;
            for (int index = 0; index < parameterCount; ++index) {
                if (classArray2[index] != classArray[index]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int parameterCount, Class[] classArray) {
        Method method = TridentFly.c(clazz, string, clazz2, parameterCount, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int index = 0; index < classArray2.length; ++index) {
                method = TridentFly.d(classArray2[index], string, clazz2, parameterCount, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(TridentFly.class, "c", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

