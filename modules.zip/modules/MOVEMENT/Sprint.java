// === Kuzi module: Sprint ===
// Category   : MOVEMENT
// Description: Automatically sprints to save your pinky finger.
// Payload    : a.a.a.j.e.af (verified: True)

package kuzi.modules.movement;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import kuzi.core.Client;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.modules.combat.Criticals;
import kuzi.obf.g.a.b;
import kuzi.obf.g.a.n;
import kuzi.obf.j.e.am;
import kuzi.obf.m.r;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import net.minecraft.EntityHitResult;
import net.minecraft.LocalPlayer;

public class Sprint
extends BaseModule
implements n {
    private final BoolSetting stopOnHit;
    public boolean n;
    private int hitCooldownTicks;
    private int hitPauseTicks;
    private static final long q = 95785684622345L;
    private static final Object[] x = new Object[]{"\"\u000f\u0005)`G)\u000f\u000e", "^\t\\ 4\u0011^\tK|8\u001eDBKb8\u000bC3\u001b?i", "'\u0003yD\u001fX,\u0003}D\u001f\u001b", "\u0002]E\u0012\u0006\u001b\tRT]{\u0003\u001aU]\u0014", "rw=a\u0017eyw9a\u0017-", "\u0012\r\\5e\u0013\u001e\rO", Integer.TYPE, "\u00005s5\u000b\u001c\t5p5\t", "7\u001ce)Cs>\u001cf)C", "8\u0015!\u001d\u0003c3\u001a0Rbm8\u00114\b", Boolean.TYPE, "]zU1\u00169Vz]", "*(Z\u001en\u0003_\bQ\u0011\u007fL>\u0006Z\u001a{\u0016J", Void.TYPE, "\u000bNw\u0014\u0005b~n|\u001b\u0014-\u001f`w\u0010\u0010wk", "Tq_2\u001f\u0019!QT=\u000eV@__6\n\f4", "t\u000b\u001a\u000evj\u007f\u000b\u0018\u000e^", "\u0001\u0016\u0010yt t6\u001bveo\u00158\u0010}a5a", "\u0015VjlR\u0010JE.v2\u0010/\u0017hwC\u0016OS:3\t", "^\u0005y\u0014EL\u0001\u0016=\u000e%SdD{\u000fTJ\u0004\u0000)K\u001e", "D\u0006>_c\n\u001b\u0015zE\u0003\u0003~\u00108\nc\u001d\u001e\u0005=U{mA\u0018`H{\u0010\u0011FgH\u0003", "ylBT\u00178eg@.\u001fD'f\u001f\u0015\u0016>\"3W\u0011", "/6W_FPr7\u000fF,\u0006\u0016bWHRRf`\\_Kl", "oPk\r%/0\u0011kYUR\u0017pGs\u0018Q\f.5H4, \u0016j\t4x", "!V\u00194\u007fV~E].\u001fT\u001b\u0016J?']w\u0010\u0019;c", "cYhLs$<J,V\u0013*YOn\u0019s39ZkFkCfG6[k>6\u00191[\u0013", "p4\u001e]\u000bxswBVdv\u001a%\u0018W\u0004oz0\u001d\b\u001c\u001f%-@\u0015\u001cbusG\u0015d", "@\nf\u0011\"<\u001f\u0019\"\u000bB=zH:\u00150#\u0007\u0018d\u00120", "\u0012<gv9=M/#lY3(z?u9*P&b#=Z\u0013&>s)\"O{hwY", "w_>Mq;7]$\u0010\u0016hJ\u0011<\u0016x\u007f#P2Mm\u0001", "aY]YI\u0018}R_#Ldm\u0006\nCX\u0004x\u0003U[(U:\u0000_\u001e\u0015\u00008]T#"};
    private static final String[] y = new String[]{null, null, null, null, null, null, "java/lang/Integer", null, null, null, "java/lang/Boolean", null, null, "java/lang/Void", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null};

    public Sprint() {
        long l2 = q ^ 0x2990C1E1A2ABL;
        long l3 = l2 ^ 0x5F6E1D28E5B7L;
        super("Sprint", "Automatically sprints to save your pinky finger.", Category.MOVEMENT);
        this.stopOnHit = new BoolSetting("Stop On Hit", true);
        this.hitCooldownTicks = 0;
        this.hitPauseTicks = 0;
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.stopOnHit};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    @Override
    public void a(b event) {
        if (!((Boolean)this.stopOnHit.a()).booleanValue() || BaseModule.a.player == null) {
            return;
        }
        this.hitCooldownTicks = 3;
        this.hitPauseTicks = 60;
    }

    private boolean a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = q ^ l2;
        return BaseModule.a.hitResult instanceof EntityHitResult;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean f(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = q ^ l2;
        String stringTable = am.b();
        LocalPlayer player = BaseModule.a.player;
        if (stringTable != null) {
            if (player == null) {
                return false;
            }
            player = BaseModule.a.player;
        }
        int checkFlag = player.onGround();
        String guard = stringTable;
        if (l2 >= 0L) {
            if (guard != null) {
                if (checkFlag != 0) return 0 != 0;
                double deltaY = BaseModule.a.player.getDeltaMovement().y - 0.0;
                checkFlag = deltaY == 0.0 ? 0 : (deltaY < 0.0 ? -1 : 1);
            }
            guard = stringTable;
        }
        if (l2 > 0L) {
            if (guard != null) {
                if (checkFlag >= 0) return 0 != 0;
                checkFlag = BaseModule.a.player.isInWater() ? 1 : 0;
            }
            guard = stringTable;
        }
        if (l2 > 0L) {
            if (guard != null) {
                if (checkFlag != 0) return 0 != 0;
                checkFlag = BaseModule.a.player.isFallFlying() ? 1 : 0;
            }
            guard = stringTable;
        }
        if (l2 > 0L) {
            if (guard != null) {
                if (checkFlag != 0) return 0 != 0;
                checkFlag = BaseModule.a.player.getAbilities().flying ? 1 : 0;
            }
            guard = stringTable;
        }
        if (l2 >= 0L) {
            if (guard != null) {
                if (checkFlag != 0) return 0 != 0;
                checkFlag = BaseModule.a.player.onClimbable() ? 1 : 0;
            }
            guard = stringTable;
        }
        if (guard == null) return checkFlag != 0;
        if (checkFlag != 0) return 0 != 0;
        return 1 != 0;
    }

    @Override
    public void i() {
        block22: {
            block20: {
                int n2;
                block24: {
                    String string;
                    long l2;
                    block23: {
                        block21: {
                            block19: {
                                block17: {
                                    int n3;
                                    block14: {
                                        Criticals criticals;
                                        long l3;
                                        block18: {
                                            Criticals criticals2;
                                            BaseModule baseModule;
                                            block15: {
                                                block16: {
                                                    long l4;
                                                    long l5 = l4 = q ^ 0x248B3F56BCE8L;
                                                    long l6 = l5 ^ 0x2675D5B10020L;
                                                    l3 = l5 ^ 0x2FAA5298DDAEL;
                                                    l2 = l5 ^ 0x4C1E24E97807L;
                                                    string = am.b();
                                                    Object object = BaseModule.a.player;
                                                    if (string != null) {
                                                        if (object == null) {
                                                            return;
                                                        }
                                                        object = BaseModule.a.options.toggleSprint().get();
                                                    }
                                                    int hasToggledSprint = ((Boolean)object).booleanValue();
                                                    if (string != null) {
                                                        if (hasToggledSprint != 0) {
                                                            BaseModule.a.options.toggleSprint().set((Object)false);
                                                        }
                                                        hasToggledSprint = this.hitCooldownTicks;
                                                    }
                                                    if (string != null) {
                                                        if (hasToggledSprint > 0) {
                                                            --this.hitCooldownTicks;
                                                        }
                                                        hasToggledSprint = this.hitPauseTicks;
                                                    }
                                                    if (string != null) {
                                                        if (hasToggledSprint > 0) {
                                                            --this.hitPauseTicks;
                                                        }
                                                        hasToggledSprint = n3 = 0;
                                                    }
                                                    if (Client.a() == null) break block14;
                                                    baseModule = this;
                                                    if (string == null) break block15;
                                                    if (baseModule.hitPauseTicks > 0) break block16;
                                                    Object[] objectArray = new Object[1];
                                                    objectArray[0] = l6;
                                                    n2 = this.a(objectArray) ? 1 : 0;
                                                    if (string == null) break block17;
                                                    if (n2 == 0) break block14;
                                                }
                                                baseModule = Client.a().a(Criticals.class);
                                            }
                                            criticals = criticals2 = (Criticals)baseModule;
                                            if (string == null) break block18;
                                            if (criticals == null) break block14;
                                            criticals = criticals2;
                                        }
                                        Object[] objectArray = new Object[1];
                                        objectArray[0] = l3;
                                        n3 = criticals.a(objectArray) ? 1 : 0;
                                    }
                                    n2 = n3;
                                }
                                if (string == null) break block19;
                                if (n2 != 0) break block20;
                                n2 = ((Boolean)this.stopOnHit.a()).booleanValue() ? 1 : 0;
                            }
                            if (string == null) break block21;
                            if (n2 == 0) break block22;
                            n2 = this.hitCooldownTicks;
                        }
                        if (string == null) break block23;
                        if (n2 > 0) break block20;
                        n2 = this.hitPauseTicks;
                    }
                    if (string == null) break block24;
                    if (n2 <= 0) break block22;
                    Object[] objectArray = new Object[1];
                    objectArray[0] = l2;
                    n2 = this.f(objectArray) ? 1 : 0;
                }
                if (n2 == 0) break block22;
            }
            BaseModule.a.options.keySprint.setDown(false);
            return;
        }
        BaseModule.a.options.keySprint.setDown(true);
    }

    @Override
    public void d() {
        this.n = (Boolean)BaseModule.a.options.toggleSprint().get();
        BaseModule.a.options.toggleSprint().set((Object)false);
        Client.c.a(n.class, this);
        super.d();
    }

    @Override
    public void e() {
        Client.c.b(n.class, this);
        BaseModule.a.options.toggleSprint().set((Object)this.n);
        BaseModule.a.options.keySprint.setDown(false);
        this.hitCooldownTicks = 0;
        this.hitPauseTicks = 0;
        super.e();
    }

    private static r a(r value) {
        return value;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = Sprint.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int index = 0; index < classArray.length; ++index) {
                field = Sprint.d(classArray[index], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int parameterCount, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != parameterCount) continue;
            for (int index = 0; index < parameterCount; ++index) {
                if (classArray2[index] != classArray[index]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method d(Class clazz, String string, Class clazz2, int parameterCount, Class[] classArray) {
        Method method = Sprint.c(clazz, string, clazz2, parameterCount, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int index = 0; index < classArray2.length; ++index) {
                method = Sprint.d(classArray2[index], string, clazz2, parameterCount, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }
}

