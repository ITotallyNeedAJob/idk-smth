// === Kuzi module: FastTrident ===
// Category   : MOVEMENT
// Description: Riptide out of water and a shorter trident charge.
// Payload    : a.a.a.j.d.o (verified: True)

package kuzi.modules.movement;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import kuzi.core.Client;
import kuzi.mixin.MixinExposed;
import kuzi.module.BaseModule;
import kuzi.module.Category;
import kuzi.obf.e.i;
import kuzi.obf.j.d.b;
import kuzi.obf.m.r;
import kuzi.settings.BoolSetting;
import kuzi.settings.Setting;
import kuzi.settings.SliderSetting;

public final class FastTrident
extends BaseModule {
    private final SliderSetting chargeScale;
    private final BoolSetting noWater;
    private static final long o = 239973527384L;
    private static final Object[] s = new Object[]{"y\u001fg8\u0013Fr\u001fb8\u001d", "x\tw5r\u0016t\td", "\u001c\\kir\u0010\u0017\\niq", Integer.TYPE, "\u0018hg\u0006F\u0016\u0011hd\u0006J", "u*MV\u0016g~*E", "(N.\tKS!N-\tI", "Ww#!r\u007f\\w(", "g{\u0002+h&\u0012[\t$yisU\u0002/}3\u0007", Void.TYPE, Boolean.TYPE, "x\u001d1UN\u0005q\u001d2UN", "X.zZ6>S!k\u0015W0X*oO", ":\u001egm_BO>lbN\r.0giJWZ", "\n0\u000e{=WM<\u00190ES3t\b<;\u0003\u000b.\u00191;9", "%x\\\"D\u000b#r\u0010S\u001c7q#@>AZzi\u0019c", "\u0017.RNo\u0003\u0014'\\\u0015\u0016!lI\u007fj[\"w\u0017\u000e\u0016v\u0005Rp\r\u001fx^", "\u000ewFEif\b}\n4=Z\u001fe[Um?_q_4*\"\u0000|\u0003Qj6\u0004\u001d", ":%?p\u0010lmy:<-f\n(3<\u0014j3s*8S\u000f", "\u0000\u0003BfNv\u0006\t\u000e\u0017\u001aJ^\n\u0000l\u0014(\u0002S\u0001&s%\u0005\u0015O*O#\u000fY>", "%3I!?q#9\u0005PdMv5\b/r\"2f\u000f\"", "=\n>\u000b\t#\u007f\n{\u0007s{\u0001De\\\bxc\u0018<]B\u001f?\r6R\u001f!?\fc\u001ds", "3!`-P\u0002t-wf(\u0007\nefjVV2?wgVl", ",:i\n\u000f)n:,\u0006uy\u0010zn\u0004\u0010lk k\f\u0016\u0015"};
    private static final String[] t = new String[]{null, null, null, "java/lang/Integer", null, null, null, null, null, "java/lang/Void", "java/lang/Boolean", null, null, null, null, null, null, null, null, null, null, null, null, null};

    public FastTrident() {
        long l2 = o ^ 0x6289BCFC49E5L;
        long l3 = l2 ^ 0x435D6808BDA8L;
        super("FastTrident", "Riptide out of water and a shorter trident charge.", Category.MOVEMENT);
        this.chargeScale = new SliderSetting("Charge Scale", 0.4, 0.0, 1.0, 0.05);
        this.noWater = new BoolSetting("No Water", true);
        Object[] objectArray = new Object[2];
        objectArray[1] = new Setting[]{this.chargeScale, this.noWater};
        objectArray[0] = l3;
        this.l(objectArray);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static FastTrident a(Object[] objectArray) {
        long l2 = (Long)objectArray[0];
        l2 = o ^ l2;
        int n2 = kuzi.obf.j.d.b.c();
        i client = Client.a;
        if (n2 == 0) {
            if (client == null) {
                return null;
            }
            client = Client.a;
        }
        FastTrident fastTrident = (FastTrident)client.a(FastTrident.class);
        return fastTrident;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @MixinExposed
    public static boolean a() {
        long l2 = o ^ 0x5B0AD8DADBA2L;
        long l3 = l2 ^ 0x1BA3FEFFD1CAL;
        Object[] objectArray = new Object[1];
        objectArray[0] = l3;
        FastTrident fastTrident = FastTrident.a(objectArray);
        int n2 = kuzi.obf.j.d.b.b();
        FastTrident fastTrident2 = fastTrident;
        if (n2 != 0) {
            if (fastTrident2 == null) return false;
            fastTrident2 = fastTrident;
        }
        boolean result = fastTrident2.d();
        if (n2 != 0) {
            if (!result) return false;
            result = (Boolean)fastTrident.n.a();
        }
        if (n2 == 0) return result;
        if (!result) return false;
        return true;
    }

    @MixinExposed
    public static int a(int chargeTicks) {
        int tickResult;
        block4: {
            FastTrident fastTrident;
            block5: {
                block3: {
                    FastTrident fastTrident2;
                    int n4;
                    block2: {
                        long l2 = o ^ 0x6114B0DA513AL;
                        long l3 = l2 ^ 0x21BD96FF5B52L;
                        Object[] objectArray = new Object[1];
                        objectArray[0] = l3;
                        fastTrident = FastTrident.a(objectArray);
                        n4 = kuzi.obf.j.d.b.b();
                        fastTrident2 = fastTrident;
                        if (n4 == 0) break block2;
                        if (fastTrident2 == null) break block3;
                        fastTrident2 = fastTrident;
                    }
                    tickResult = fastTrident2.d();
                    if (n4 == 0) break block4;
                    if (tickResult != 0) break block5;
                }
                return chargeTicks;
            }
            tickResult = Math.max(1, (int)Math.round((double)chargeTicks * (Double)fastTrident.m.a()));
        }
        return tickResult;
    }

    private static r a(r r2) {
        return r2;
    }

    private static Field findDeclaredField(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Field findFieldInHierarchy(Class clazz, String string, Class clazz2) {
        Field field = FastTrident.findDeclaredField(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int i2 = 0; i2 < classArray.length; ++i2) {
                field = FastTrident.findFieldInHierarchy(classArray[i2], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method findDeclaredMethod(Class clazz, String string, Class clazz2, int parameterCount, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != parameterCount) continue;
            for (int i2 = 0; i2 < parameterCount; ++i2) {
                if (classArray2[i2] != classArray[i2]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method findMethodInHierarchy(Class clazz, String string, Class clazz2, int parameterCount, Class[] classArray) {
        Method method = FastTrident.findDeclaredMethod(clazz, string, clazz2, parameterCount, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int i2 = 0; i2 < classArray2.length; ++i2) {
                method = FastTrident.findMethodInHierarchy(classArray2[i2], string, clazz2, parameterCount, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }
}

